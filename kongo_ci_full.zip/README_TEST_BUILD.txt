TEST BUILD ONLY. pubspec.yaml here was rebuilt from the imports in lib/ (your real one was never
sent to me), and the Android folder is a fresh template plus the ko!ngo manifest and ring sound.
DriverOnlineService.kt is NOT included. Use your own project for real releases.
