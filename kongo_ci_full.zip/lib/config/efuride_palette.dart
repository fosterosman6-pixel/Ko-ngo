// lib/config/efuride_palette.dart

import 'package:flutter/material.dart';

class EfuridePalette {
  // ── Brand blues (headers) ──
  static const blue = Color(0xFF1E88E5);
  static const blueDeep = Color(0xFF1565C0);
  static const navy = Color(0xFF0B1E3F);
  static const navyDeep = Color(0xFF071630);

  // ── Accent (gold) ──
  static const gold = Color(0xFFF2B705);
  static const goldInk = Color(0xFF0B1220);

  // ── Aliases used across every screen ──
  // Several screens reference `accent` / `accentInk` directly.
  // Pointing them at the gold pair means one source of truth.
  static const accent = gold;
  static const accentInk = goldInk;

  // ── Surfaces ──
  static const white = Colors.white;
  static const cream = Color(0xFFFAF6EE);
  static const lightBlue = Color(0xFFEBF5FF);
  static const divider = Color(0xFFE8E2D5);
  static const greyBg = Color(0xFFF3F3F3);

  // ── Semantic ──
  static const online = Color(0xFF22C55E);
  static const onlineDeep = Color(0xFF16A34A);
  static const pickup = Color(0xFF34C759);
  static const dropoff = Color(0xFFE53935);
  static const danger = dropoff;
  static const ink = Color(0xFF1A1A1A);
  static const inkMuted = Color(0xFF575047);

  // ── Role accents ──
  static const shopperAccent = Color(0xFF7B5BD6);
  static const merchantAccent = Color(0xFFE88A1A);
}
