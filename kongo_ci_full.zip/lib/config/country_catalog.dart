// lib/config/country_catalog.dart
//
// Countries ko!ngo runs in, with each country's languages.
// The FIRST language is the default when someone picks that country;
// the others are offered as one-tap alternatives.
//
//   Congo-Brazzaville, DR Congo → French (+ Lingala)
//   Kenya → English (+ Swahili) · South Africa → English (+ Afrikaans) …

import 'package:efuride_app/config/country_config.dart';
import 'package:efuride_app/l10n/app_strings.dart';

class KongoCountry {
  final String iso;
  final String name;
  final String flag;
  final List<AppLang> languages;
  const KongoCountry(this.iso, this.name, this.flag, this.languages);

  /// Languages that actually have translations in this build.
  List<AppLang> get usableLanguages {
    final out = <AppLang>[];
    for (final l in languages) {
      if (AppLang.available.contains(l) && !out.contains(l)) out.add(l);
    }
    if (out.isEmpty) out.add(AppLang.en);
    return out;
  }

  AppLang get defaultLanguage => usableLanguages.first;

  String get phonePrefix => CountryConfig.byIso(iso)?.phonePrefix ?? '';
}

class CountryCatalog {
  CountryCatalog._();

  static const List<KongoCountry> all = [
    KongoCountry('CG', 'Congo-Brazzaville', '🇨🇬',
        [AppLang.fr, AppLang.ln, AppLang.en]),
    KongoCountry('CD', 'RD Congo (Kinshasa)', '🇨🇩',
        [AppLang.fr, AppLang.ln, AppLang.sw, AppLang.en]),
    KongoCountry('ZA', 'South Africa', '🇿🇦', [AppLang.en, AppLang.af]),
    KongoCountry('KE', 'Kenya', '🇰🇪', [AppLang.en, AppLang.sw]),
    KongoCountry('TZ', 'Tanzania', '🇹🇿', [AppLang.sw, AppLang.en]),
    KongoCountry('UG', 'Uganda', '🇺🇬', [AppLang.en, AppLang.sw]),
    KongoCountry('RW', 'Rwanda', '🇷🇼', [AppLang.en, AppLang.fr, AppLang.sw]),
    KongoCountry('BI', 'Burundi', '🇧🇮', [AppLang.fr, AppLang.sw, AppLang.en]),
    KongoCountry('MW', 'Malawi', '🇲🇼', [AppLang.en, AppLang.ny]),
    KongoCountry('ZM', 'Zambia', '🇿🇲', [AppLang.en, AppLang.ny]),
    KongoCountry('ZW', 'Zimbabwe', '🇿🇼', [AppLang.en]),
    KongoCountry('AO', 'Angola', '🇦🇴', [AppLang.en, AppLang.fr]),
    KongoCountry('NG', 'Nigeria', '🇳🇬', [AppLang.en]),
  ];

  static KongoCountry? byIso(String? iso) {
    if (iso == null) return null;
    final up = iso.toUpperCase();
    for (final c in all) {
      if (c.iso == up) return c;
    }
    return null;
  }
}
