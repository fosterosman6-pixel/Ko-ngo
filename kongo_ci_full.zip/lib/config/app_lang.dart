// lib/config/app_lang.dart
//
// Language resolution helpers. AppLang enum lives in app_strings.dart.
//
// Policy (per product spec):
//   1. If the user has explicitly chosen a language, use it.
//   2. Otherwise, use the device locale.
//   3. Fall back to English.

import 'dart:ui' show PlatformDispatcher;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:efuride_app/l10n/app_strings.dart';

class AppLangStore {
  AppLangStore._();

  static const _kKey = 'app_lang_user_choice';

  static Future<AppLang?> loadUserChoice() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_kKey);
    if (raw == null) return null;
    for (final l in AppLang.values) {
      if (l.code == raw) return l.usable;
    }
    return null;
  }

  static Future<void> saveUserChoice(AppLang lang) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_kKey, lang.code);
  }

  static Future<void> clearUserChoice() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_kKey);
  }

  /// Priority: explicit choice → db value → device → English.
  static AppLang resolve({AppLang? dbValue, AppLang? explicitChoice}) {
    if (explicitChoice != null) return explicitChoice;
    if (dbValue != null)        return dbValue;
    return fromDevice();
  }

  static AppLang fromDevice() {
    final code = PlatformDispatcher.instance.locale.languageCode;
    return AppLang.fromCode(code);
  }

  static bool isSupported(String code) =>
      AppLang.values.any((l) => l.code == code);

  static List<AppLang> get supported => AppLang.available;
}
