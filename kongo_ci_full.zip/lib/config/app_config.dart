﻿// lib/config/app_config.dart

class AppConfig {
  AppConfig._();

  // ============================================================
  // SUPABASE
  // ============================================================
  static const String supabaseUrl =
      'https://dgvixtutbfteitnvoxcz.supabase.co';
  static const String supabaseAnonKey =
      'sb_publishable_Toz5HpDJEw2ao2-iH92UVg_okA3Nmmh';

  // ============================================================
  // MAPS
  // ============================================================
  // Android Maps SDK key — restricted to package + SHA-1.
  static const String googleMapsAndroidKey =
      'AIzaSyCNJrxoiFO8JNvDSit6P2qdhcsso3mpwhA';

  /// Android key, used only by the native map widget. Search, address
  /// lookup and routes go through the `google-maps` Supabase function,
  /// which holds its own server key (see supabase/functions/google-maps).
  static const String googleMapsApiKey = googleMapsAndroidKey;

  // Tile URL for flutter_map.
  static const String mapTilerStreetsUrl =
      'https://tile.openstreetmap.org/{z}/{x}/{y}.png';

  // ============================================================
  // BRAND
  // ============================================================
  static const int brandBlue      = 0xFF1E5A96;
  static const int brandBlueLight = 0xFF4A90C2;
  static const int brandOrange    = 0xFFE88A1A;
  static const int brandCream     = 0xFFFAF6EE;

  // ============================================================
  // ASSETS
  // ============================================================
  static const String logoAsset      = 'assets/images/kongo_logo.png';
  static const String carMarkerAsset = 'assets/images/car_top_view.png';

  // ============================================================
  // APP META
  // ============================================================
  static const String appName            = 'ko!ngo';
  static const String tagline            = 'Move Smarter';
  static const String version            = '1.0.0';
  static const String userAgentPackageName = 'com.example.efuride_app';
}
