// lib/config/app_images.dart

class AppImages {
  AppImages._();

  // ── Vehicles ─────────────────────────────────────────────────
  static const rideMinibus   = 'assets/images/ride_minibus.png';
  static const deliveryTruck = 'assets/images/delivery_truck.png';
  static const driverCar     = 'assets/images/driver_car.png';
  static const driverBike    = 'assets/images/driver_bike.png';
  static const driverTruck   = 'assets/images/driver_truck.png';
  static const driverVan     = 'assets/images/driver_van.png';
  static const driverSedan   = 'assets/images/driver_sedan.png';

  // ── Account / settings ───────────────────────────────────────
  static const bank          = 'assets/images/bank.png';
  static const lock          = 'assets/images/lock.png';
  static const shieldInfo    = 'assets/images/shield_info.png';
  static const globe         = 'assets/images/globe.png';
  static const textSize      = 'assets/images/text_size.png';
  static const calendar      = 'assets/images/calendar.png';
  static const speaker       = 'assets/images/speaker.png';
  static const barChart      = 'assets/images/bar_chart.png';
  static const briefcase     = 'assets/images/briefcase.png';
  static const family        = 'assets/images/family.png';
  static const percentTag    = 'assets/images/percent_tag.png';
  static const share         = 'assets/images/share.png';
  static const plus          = 'assets/images/plus.png';
  static const gear          = 'assets/images/gear.png';
  static const mapPin        = 'assets/images/map_pin_blue.png';
  static const mapPinUser    = 'assets/images/map_pin_user.png';
  static const shieldCheck   = 'assets/images/shield_check.png';
  static const headset       = 'assets/images/headset.png';
  static const card          = 'assets/images/card.png';
  static const userBlue      = 'assets/images/user_blue.png';
  static const userGrey      = 'assets/images/user_grey.png';
  static const walletBlue    = 'assets/images/wallet_blue.png';
  static const walletGrey    = 'assets/images/wallet_grey.png';
  static const coinsBlue     = 'assets/images/coins_blue.png';
  static const coinsGrey     = 'assets/images/coins_grey.png';
  static const chatBubble    = 'assets/images/chat_bubble.png';
  static const clipboardClock= 'assets/images/clipboard_clock.png';
  static const homeBlue      = 'assets/images/home_blue.png';
  static const homeGrey      = 'assets/images/home_grey.png';
  static const gift          = 'assets/images/gift.png';
  static const logout        = 'assets/images/logout.png';

  // ── Brand (ko!ngo) ───────────────────────────────────────────
  static const kongoLogo     = 'assets/images/kongo_logo.png';   // full logo with wordmark
  static const leopardLogo   = 'assets/images/leopard_logo.png'; // leopard head, for round badges
}
