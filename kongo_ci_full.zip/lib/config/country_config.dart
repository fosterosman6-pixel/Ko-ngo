// lib/config/country_config.dart
//
// Single source of truth for currency, phone prefix, and locale.
//
// Resolution priority:
//   1. lat/lng (bounding-box lookup)
//   2. Device locale (Locale.countryCode)
//   3. Fallback (USD)

import 'dart:ui' show Locale;

class CountryData {
  final String isoCode;
  final String currencyCode;
  final String currencySymbol;
  final int    decimalDigits;
  final String phonePrefix;

  const CountryData({
    required this.isoCode,
    required this.currencyCode,
    required this.currencySymbol,
    required this.decimalDigits,
    required this.phonePrefix,
  });
}

class CountryConfig {
  CountryConfig._();

  static CountryData _current = _default;
  static CountryData get current => _current;

  static const CountryData _default = CountryData(
    isoCode: 'US',
    currencyCode: 'USD',
    currencySymbol: r'$',
    decimalDigits: 2,
    phonePrefix: '+1',
  );

  static const Map<String, CountryData> _countries = {
    'RW': CountryData(isoCode: 'RW', currencyCode: 'RWF', currencySymbol: 'FRw', decimalDigits: 0, phonePrefix: '+250'),
    'BI': CountryData(isoCode: 'BI', currencyCode: 'BIF', currencySymbol: 'FBu', decimalDigits: 0, phonePrefix: '+257'),
    'KE': CountryData(isoCode: 'KE', currencyCode: 'KES', currencySymbol: 'KSh', decimalDigits: 0, phonePrefix: '+254'),
    'UG': CountryData(isoCode: 'UG', currencyCode: 'UGX', currencySymbol: 'USh', decimalDigits: 0, phonePrefix: '+256'),
    'TZ': CountryData(isoCode: 'TZ', currencyCode: 'TZS', currencySymbol: 'TSh', decimalDigits: 0, phonePrefix: '+255'),
    'ZA': CountryData(isoCode: 'ZA', currencyCode: 'ZAR', currencySymbol: 'R',   decimalDigits: 2, phonePrefix: '+27'),
    'CD': CountryData(isoCode: 'CD', currencyCode: 'CDF', currencySymbol: 'FC',  decimalDigits: 0, phonePrefix: '+243'),
    'CG': CountryData(isoCode: 'CG', currencyCode: 'XAF', currencySymbol: 'XAF', decimalDigits: 0, phonePrefix: '+242'),
    'AO': CountryData(isoCode: 'AO', currencyCode: 'AOA', currencySymbol: 'Kz',  decimalDigits: 0, phonePrefix: '+244'),
    'ZM': CountryData(isoCode: 'ZM', currencyCode: 'ZMW', currencySymbol: 'ZK',  decimalDigits: 2, phonePrefix: '+260'),
    'ZW': CountryData(isoCode: 'ZW', currencyCode: 'USD', currencySymbol: r'$',  decimalDigits: 2, phonePrefix: '+263'),
    'NG': CountryData(isoCode: 'NG', currencyCode: 'NGN', currencySymbol: '₦',   decimalDigits: 2, phonePrefix: '+234'),
    'MW': CountryData(isoCode: 'MW', currencyCode: 'MWK', currencySymbol: 'MK',  decimalDigits: 0, phonePrefix: '+265'),
  };

  /// [minLat, minLng, maxLat, maxLng]
  ///
  /// Boxes overlap, so ORDER MATTERS: smaller countries are checked
  /// before the large ones that surround them (Congo-Brazzaville before
  /// DRC, Malawi before Tanzania/Zambia, Rwanda/Burundi before DRC).
  static const Map<String, List<double>> _boxes = {
    'CG': [-5.05,  11.10,  3.75,  18.70],
    'MW': [-17.15, 32.65, -9.35,  35.95],
    'RW': [-2.85,  28.85, -1.05,  30.90],
    'BI': [-4.47,  29.00, -2.30,  30.85],
    'KE': [-4.70,  33.90,  5.03,  41.90],
    'UG': [-1.48,  29.55,  4.23,  35.04],
    'TZ': [-11.75, 29.32, -0.99,  40.45],
    'ZA': [-34.85, 16.45, -22.10, 32.95],
    'CD': [-13.50, 12.00,  5.40,  31.35],
    'AO': [-18.05, 11.65, -4.35,  24.10],
    'ZM': [-18.10, 21.95, -8.20,  33.75],
    'ZW': [-22.45, 25.20, -15.60, 33.10],
    'NG': [ 4.25,   2.65, 13.90,  14.70],
  };

  /// Country data for an ISO code (e.g. 'KE'), or null if not served.
  static CountryData? byIso(String? iso) =>
      iso == null ? null : _countries[iso.toUpperCase()];

  /// Use this country now (e.g. picked at sign-up).
  static CountryData setCountry(String iso) {
    final c = byIso(iso);
    if (c != null) _current = c;
    return _current;
  }

  /// Priority: where the person is (GPS) → the country they chose at
  /// sign-up → the phone's region → default.
  static CountryData resolve({
    double? lat,
    double? lng,
    Locale? locale,
    String? profileCountry,
  }) {
    if (lat != null && lng != null) {
      final byCoord = _countryFor(lat, lng);
      if (byCoord != null) { _current = byCoord; return byCoord; }
    }
    final chosen = byIso(profileCountry);
    if (chosen != null) { _current = chosen; return chosen; }
    final iso = locale?.countryCode?.toUpperCase();
    if (iso != null && _countries.containsKey(iso)) {
      _current = _countries[iso]!;
      return _current;
    }
    _current = _default;
    return _current;
  }

  /// ISO code for a point, or null when it is outside every known box.
  static String? isoFor(double lat, double lng) =>
      _countryFor(lat, lng)?.isoCode;

  static CountryData? _countryFor(double lat, double lng) {
    // Brazzaville and Kinshasa face each other across the Congo River,
    // so boxes alone can't separate them. Around Pool Malebo, use the
    // river line: north/west bank = Congo-Brazzaville, south/east = DRC.
    if (lat > -4.6 && lat < -3.9 && lng > 15.0 && lng < 15.65) {
      final riverLat = lng <= 15.30
          ? -4.315
          : -4.28 + (lng - 15.30) * (0.33 / 0.32);
      return _countries[lat > riverLat ? 'CG' : 'CD'];
    }
    for (final e in _boxes.entries) {
      final b = e.value;
      if (lat >= b[0] && lng >= b[1] && lat <= b[2] && lng <= b[3]) {
        return _countries[e.key];
      }
    }
    return null;
  }

  /// Format a monetary amount in the current country's currency.
  ///   CD → '1 234 FC'
  ///   KE → 'KSh 1,234'
  ///   ZA → 'R 1,234.50'
  static String money(num amount) {
    final c = _current;
    final fixed = amount.toStringAsFixed(c.decimalDigits);
    final split = fixed.split('.');
    final intPart = split[0];
    final decPart = split.length > 1 ? split[1] : null;

    final buf = StringBuffer();
    for (int i = 0; i < intPart.length; i++) {
      if (i > 0 && (intPart.length - i) % 3 == 0) buf.write(',');
      buf.write(intPart[i]);
    }
    final formatted = (decPart != null && c.decimalDigits > 0)
        ? '${buf.toString()}.$decPart'
        : buf.toString();

    if (c.isoCode == 'ZA' || c.isoCode == 'NG') {
      return '${c.currencySymbol} $formatted';
    }
    return '$formatted ${c.currencySymbol}';
  }

  static String get symbol        => _current.currencySymbol;
  static String get currencyCode  => _current.currencyCode;
  static String get phonePrefix   => _current.phonePrefix;
  static String get isoCode       => _current.isoCode;

  /// Lowercase ISO code of the country the user is in, or null when it
  /// is not one we serve (the built-in default does not count).
  static String? get servedIso =>
      _countries.containsKey(_current.isoCode) ? _current.isoCode.toLowerCase() : null;
}
