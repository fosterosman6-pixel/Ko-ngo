// File: lib/firebase_options.dart
// Generated manually using Firebase Console values and google-services.json.

import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;
import 'package:flutter/foundation.dart'
    show defaultTargetPlatform, kIsWeb, TargetPlatform;

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    if (kIsWeb) {
      return web;
    }
    switch (defaultTargetPlatform) {
      case TargetPlatform.android:
        return android;
      case TargetPlatform.iOS:
        return ios;
      default:
        throw UnsupportedError(
          'DefaultFirebaseOptions are not supported for this platform.',
        );
    }
  }

  // NOTE: For Web, you need to manually grab the WEB apiKey/appId from the Firebase Console. 
  // If your project doesn't have a Web app created yet, please create one in the Console.
  static const FirebaseOptions web = FirebaseOptions(
    apiKey: 'AIzaSyDg_5NeS8lEJLS8Wae37VADUHnQnbKDGyE', // This is your Android key, but it may work for web if you haven't set up a separate one.
    appId: '1:171726157114:web:YOUR_WEB_APP_ID', // Replace this with your actual Web app ID (starts with 1:171726157114:web:...)
    messagingSenderId: '171726157114',
    projectId: 'efuride-a29f1',
    authDomain: 'efuride-a29f1.firebaseapp.com',
    databaseURL: 'https://efuride-a29f1-default-rtdb.firebaseio.com',
    storageBucket: 'efuride-a29f1.firebasestorage.app',
  );

  static const FirebaseOptions android = FirebaseOptions(
    apiKey: 'AIzaSyDg_5NeS8lEJLS8Wae37VADUHnQnbKDGyE',
    appId: '1:171726157114:android:9aac9ee173865153f8cc03',
    messagingSenderId: '171726157114',
    projectId: 'efuride-a29f1',
    databaseURL: 'https://efuride-a29f1-default-rtdb.firebaseio.com',
    storageBucket: 'efuride-a29f1.firebasestorage.app',
  );

  static const FirebaseOptions ios = FirebaseOptions(
    apiKey: 'AIzaSyDg_5NeS8lEJLS8Wae37VADUHnQnbKDGyE',
    appId: '1:171726157114:ios:YOUR_IOS_APP_ID', // Replace with your iOS App ID if you have one
    messagingSenderId: '171726157114',
    projectId: 'efuride-a29f1',
    databaseURL: 'https://efuride-a29f1-default-rtdb.firebaseio.com',
    storageBucket: 'efuride-a29f1.firebasestorage.app',
  );
}
