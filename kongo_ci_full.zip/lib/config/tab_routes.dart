// lib/config/tab_routes.dart

class TabRoute {
  /// URL key → tab index for each role shell.
  /// Used by router + FCM payload parsing.
  static const Map<String, Map<String, int>> _tabs = {
    'driver': {
      'home': 0,
      'trips': 1,
      'earnings': 2,
      'more': 3,
    },
    'customer': {
      'home': 0,
      'rides': 1,
      'orders': 2,
      'settings': 3,
      'profile': 3,
    },
    'shopper': {
      'home': 0,
      'tasks': 1,
      'pay': 2,
      'settings': 3,
    },
    'merchant': {
      'dashboard': 0,
      'orders': 1,
      'menu': 2,
      'payouts': 3,
    },
  };

  /// Resolve a tab name to an index. Falls back to 0.
  static int indexFor(String role, String? tab) {
    if (tab == null || tab.isEmpty) return 0;
    return _tabs[role]?[tab.toLowerCase()] ?? 0;
  }

  /// Resolve index back to a tab name (for building share links, etc).
  static String? nameFor(String role, int index) {
    final map = _tabs[role];
    if (map == null) return null;
    for (final e in map.entries) {
      if (e.value == index) return e.key;
    }
    return null;
  }

  /// All valid tab names for a role.
  static List<String> namesFor(String role) =>
      (_tabs[role] ?? {}).keys.toList();
}
