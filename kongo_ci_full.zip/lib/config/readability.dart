// lib/config/readability.dart
//
// Readability for people with low vision.
//
//  • App font: Atkinson Hyperlegible (Braille Institute) — designed so
//    similar letters (I l 1, O 0, rn m, b d p q) can't be confused.
//  • Text size: the phone's own text-size setting is always honoured, and
//    the app adds its own "Text size" choice on top (Settings → Text size).
//    The choice is remembered on the device.

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class Readability {
  Readability._();

  static const fontFamily = 'AtkinsonHyperlegible';

  static const _prefKey = 'app_text_scale';

  /// Standard, Large, Larger, Largest.
  static const scales = <double>[1.0, 1.15, 1.3, 1.5];

  /// Translation keys for [scales], same order.
  static const scaleLabelKeys = <String>[
    'ts_standard',
    'ts_large',
    'ts_larger',
    'ts_largest',
  ];

  /// Extra scale chosen in the app (multiplies the phone's setting).
  static final ValueNotifier<double> textScale = ValueNotifier<double>(1.0);

  static Future<void> load() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final v = prefs.getDouble(_prefKey);
      if (v != null && scales.contains(v)) textScale.value = v;
    } catch (_) {/* keep default */}
  }

  static Future<void> setScale(double v) async {
    textScale.value = v;
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setDouble(_prefKey, v);
    } catch (_) {/* still applied for this session */}
  }

  static String labelKeyFor(double v) {
    final i = scales.indexOf(v);
    return scaleLabelKeys[i < 0 ? 0 : i];
  }

  /// Wraps the app: phone text size × app text size.
  static Widget apply(BuildContext context, Widget child) {
    return ValueListenableBuilder<double>(
      valueListenable: textScale,
      builder: (context, extra, _) {
        final mq = MediaQuery.of(context);
        if (extra == 1.0) return child;
        // Phone's effective factor at body size, times the app's choice.
        final phone = mq.textScaler.scale(14) / 14;
        return MediaQuery(
          data: mq.copyWith(textScaler: TextScaler.linear(phone * extra)),
          child: child,
        );
      },
    );
  }
}
