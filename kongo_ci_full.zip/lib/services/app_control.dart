// lib/services/app_control.dart
//
// Live switches set by ko!ngo admins (app_settings row id = 1):
//   • maintenance mode + message      → every role app shows a pause screen
//   • roles_enabled {customer, driver, shopper, merchant}
//   • services_enabled {ride, food, grocery, pharmacy, parcel}
//   • support phone / email / WhatsApp
//
// Changes arrive in real time (and every 2 minutes as a fallback).
// If the settings can't be read, everything stays ON — the app never
// locks people out because of a network error.

import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

@immutable
class AppControlState {
  final bool maintenance;
  final String? maintenanceMessage;
  final Map<String, bool> services;
  final Map<String, bool> roles;
  final String? supportPhone;
  final String? supportEmail;
  final String? supportWhatsapp;

  const AppControlState({
    this.maintenance = false,
    this.maintenanceMessage,
    this.services = const {},
    this.roles = const {},
    this.supportPhone,
    this.supportEmail,
    this.supportWhatsapp,
  });

  /// Unknown or missing = enabled.
  bool serviceEnabled(String key) => services[key.toLowerCase()] ?? true;
  bool roleEnabled(String role) => roles[role.toLowerCase()] ?? true;

  static Map<String, bool> _flags(dynamic v) {
    if (v is! Map) return const {};
    return {
      for (final e in v.entries)
        e.key.toString().toLowerCase(): e.value != false,
    };
  }

  static String? _text(dynamic v) {
    final s = v?.toString().trim() ?? '';
    return s.isEmpty ? null : s;
  }

  factory AppControlState.fromRow(Map<String, dynamic> r) => AppControlState(
        maintenance: r['maintenance_mode'] == true,
        maintenanceMessage: _text(r['maintenance_message']),
        services: _flags(r['services_enabled']),
        roles: _flags(r['roles_enabled']),
        supportPhone: _text(r['support_phone']),
        supportEmail: _text(r['support_email']),
        supportWhatsapp: _text(r['support_whatsapp']),
      );
}

class AppControl {
  AppControl._();

  static final ValueNotifier<AppControlState> state =
      ValueNotifier<AppControlState>(const AppControlState());

  static AppControlState get current => state.value;

  static RealtimeChannel? _channel;
  static Timer? _poll;
  static bool _started = false;

  static const _columns = 'maintenance_mode, maintenance_message, '
      'services_enabled, roles_enabled, support_phone, support_email, '
      'support_whatsapp';

  /// Call once after Supabase.initialize().
  static Future<void> start() async {
    if (_started) return;
    _started = true;
    await refresh();
    try {
      _channel = Supabase.instance.client
          .channel('app_control')
          .onPostgresChanges(
            event: PostgresChangeEvent.update,
            schema: 'public',
            table: 'app_settings',
            callback: (_) => refresh(),
          )
          .subscribe();
    } catch (e) {
      debugPrint('AppControl realtime unavailable: $e');
    }
    _poll = Timer.periodic(const Duration(minutes: 2), (_) => refresh());
  }

  static Future<void> refresh() async {
    try {
      final row = await Supabase.instance.client
          .from('app_settings')
          .select(_columns)
          .eq('id', 1)
          .maybeSingle()
          .timeout(const Duration(seconds: 10));
      if (row != null) state.value = AppControlState.fromRow(row);
    } catch (e) {
      // Columns not migrated yet, or offline: keep the last known state.
      debugPrint('AppControl refresh skipped: $e');
    }
  }

  static Future<void> stop() async {
    _poll?.cancel();
    final c = _channel;
    _channel = null;
    _started = false;
    if (c != null) await Supabase.instance.client.removeChannel(c);
  }
}
