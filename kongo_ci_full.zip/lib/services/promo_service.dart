import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:efuride_app/config/country_config.dart';
import 'package:efuride_app/utils/log.dart';
import 'package:efuride_app/l10n/app_strings.dart';

class PromoResult {
  final bool valid;
  final String? message;
  final double discountAmount;
  final double fareAfterDiscount;
  final Map<String, dynamic>? promo;

  const PromoResult({
    required this.valid,
    this.message,
    this.discountAmount = 0,
    this.fareAfterDiscount = 0,
    this.promo,
  });
}

class PromoService {
  PromoService._();
  static const _tag = 'PromoService';
  static final _client = Supabase.instance.client;


  // ============================================================
  // VALIDATION  (the server checks the code; the app never lists codes)
  // Needs step57_promo_codes.sql.
  // ============================================================
  static Future<PromoResult> validate({
    required String code,
    required double fare,
  }) async {
    final trimmed = code.trim().toUpperCase();
    if (trimmed.isEmpty) {
      return PromoResult(valid: false, message: tr('Enter a code.'));
    }

    try {
      final user = _client.auth.currentUser;
      if (user == null) {
        return PromoResult(valid: false, message: tr('Please sign in.'));
      }

      final res = await _client.rpc('validate_promo', params: {
        'p_code': trimmed,
        'p_fare': fare,
      });
      final map = Map<String, dynamic>.from(res as Map);

      if (map['valid'] != true) {
        return PromoResult(
          valid: false,
          message: (map['message'] ?? tr('Code not found.')).toString(),
        );
      }

      var discount = (map['discount'] as num?)?.toDouble() ?? 0;
      if (discount > fare) discount = fare;
      if (discount < 0) discount = 0;
      final fareAfter =
          (fare - discount).clamp(0.0, double.infinity).toDouble();

      return PromoResult(
        valid: true,
        message:
            tr('Promo applied! You save {0}.', [CountryConfig.money(discount)]),
        discountAmount: discount,
        fareAfterDiscount: fareAfter,
        promo: map['promo'] == null
            ? null
            : Map<String, dynamic>.from(map['promo'] as Map),
      );
    } catch (e) {
      Log.e(_tag, 'validate failed', e);
      return PromoResult(
        valid: false,
        message: tr('Couldn\'t validate this code. Try again.'),
      );
    }
  }

  // ============================================================
  // REDEMPTION  (records the use and counts it in one server step)
  // ============================================================
  static Future<void> recordRedemption({
    required int promoId,
    required String rideId,
    required double discountApplied,
  }) async {
    final user = _client.auth.currentUser;
    if (user == null) return;

    try {
      await _client.rpc('redeem_promo', params: {
        'p_promo_id': promoId,
        'p_ride_id': rideId,
        'p_discount': discountApplied,
      });
    } catch (e) {
      Log.e(_tag, 'recordRedemption failed', e);
    }
  }
}
