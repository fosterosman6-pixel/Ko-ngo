// lib/services/ring_service.dart

import 'dart:async';
import 'dart:typed_data';
import 'dart:io' show Platform;
import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:efuride_app/utils/log.dart';

// ============================================================
// TAP HANDLER — top-level + @pragma for background isolate
// ============================================================
final ValueNotifier<String?> pendingRideFromNotification =
    ValueNotifier<String?>(null);

// Set by ChatScreen while it's open, cleared on dispose. Lets both
// NotificationService and RealtimeNotifications skip popups for a
// conversation the user is already looking at.
final ValueNotifier<String?> activeChatRideId = ValueNotifier<String?>(null);

// Global flag: true while an incoming-ride ring screen is showing.
// Shared between the FCM path (main.dart) and the Supabase Realtime
// path (driver_home_screen.dart) so the same ride can't open two rings.
final ValueNotifier<bool> globalRingShowing = ValueNotifier<bool>(false);

// Other requests that arrived while one is ringing. The ring screen shows
// them so the driver can choose which one to take (one at a time).
final ValueNotifier<List<Map<String, dynamic>>> globalOfferQueue =
    ValueNotifier<List<Map<String, dynamic>>>(<Map<String, dynamic>>[]);

@pragma('vm:entry-point')
void _onNotificationTapped(NotificationResponse response) {
  final payload = response.payload;
  if (payload == null || payload.isEmpty) return;
  pendingRideFromNotification.value = payload;
  Log.i('RingService', 'notification tapped: payload=$payload');
}

class RingService {
  RingService._();
  static final RingService instance = RingService._();
  static const _tag = 'RingService';

  final AudioPlayer _player = AudioPlayer();
  final FlutterLocalNotificationsPlugin _local =
      FlutterLocalNotificationsPlugin();

  bool _ringing = false;
  bool _notifReady = false;
  bool _audioReady = false;

  // v3 (v2 may exist silent on phones): created here (not by native code) with our own ring sound
  // (android/app/src/main/res/raw/kongo_ring.wav) and "ringtone" volume,
  // so it rings on the lock screen and when the app is hidden or closed.
  // A channel's sound can't change after it exists, hence the new id.
  static const _rideChannelId = 'kongo_ring_v4';
  static const _rideChannelName = 'Incoming requests (ringing)';
  static const _rideChannelDesc =
      'Rings for new rides, deliveries and store orders, even when the phone is locked';
  static const _ringSound = RawResourceAndroidNotificationSound('kongo_ring');
  static final _ringVibration = Int64List.fromList([0, 800, 600, 800, 600, 800]);

  static const _chatChannelId = 'chat_messages_channel';
  static const _chatChannelName = 'Chat Messages';
  static const _chatChannelDesc = 'New chat messages during a trip';

  static const int _ringNotificationId = 9812;

  // ============================================================
  // INIT
  // ============================================================
  Future<void> init() async {
    await _initNotifications();
    await _initAudio();
  }

  Future<void> _initNotifications() async {
    if (_notifReady) return;

    final android = _local.resolvePlatformSpecificImplementation<
        AndroidFlutterLocalNotificationsPlugin>();

    // NOTE: the `incoming_ride_channel` is created EXCLUSIVELY by the
    // native EfurideFirebaseMessagingService.kt so there's a single source
    // of truth for its importance + sound. Creating it here as well caused
    // "first creator wins" conflicts where the Dart side (which may lack
    // the raw ringtone resource) would silently define a mute channel.
    //
    try {
      await android?.createNotificationChannel(
        AndroidNotificationChannel(
          _rideChannelId,
          _rideChannelName,
          description: _rideChannelDesc,
          importance: Importance.max,
          playSound: true,
          sound: _ringSound,
          enableVibration: true,
          vibrationPattern: _ringVibration,
          audioAttributesUsage: AudioAttributesUsage.notificationRingtone,
        ),
      );
    } catch (e) {
      Log.e(_tag, 'create ring channel failed', e);
    }
    try {
      await android?.createNotificationChannel(
        const AndroidNotificationChannel(
          _chatChannelId,
          _chatChannelName,
          description: _chatChannelDesc,
          importance: Importance.high,
          playSound: true,
          enableVibration: true,
        ),
      );
    } catch (e) {
      Log.e(_tag, 'createNotificationChannel failed', e);
    }

    const initSettings = InitializationSettings(
      android: AndroidInitializationSettings('@mipmap/ic_launcher'),
      iOS: DarwinInitializationSettings(
        requestSoundPermission: true,
        requestBadgePermission: true,
        requestAlertPermission: true,
      ),
    );

    try {
      await _local.initialize(
        initSettings,
        onDidReceiveNotificationResponse: _onNotificationTapped,
        onDidReceiveBackgroundNotificationResponse: _onNotificationTapped,
      );
      _notifReady = true;
    } catch (e) {
      Log.e(_tag, 'initialize failed', e);
    }
  }

  Future<void> _initAudio() async {
    if (_audioReady) return;
    try {
      await _player.setReleaseMode(ReleaseMode.loop);
      _audioReady = true;
    } catch (e) {
      Log.e(_tag, 'setReleaseMode failed', e);
    }
  }

  // ============================================================
  // RING — FOREGROUND
  // ============================================================
  /// [untilAnswered]: keep ringing with no time limit (shop-order
  /// deliveries ring until a driver accepts or the customer cancels).
  Future<void> startRing({bool untilAnswered = false}) async {
    if (!_notifReady) await _initNotifications();
    if (!_audioReady) await _initAudio();
    if (_ringing) return;
    _ringing = true;
    _untilAnswered = untilAnswered;

    try {
      await _player.stop();
      await _player.play(AssetSource('ringtone.wav'));
    } catch (e) {
      Log.e(_tag, 'audio start failed', e);
    }

    try {
      await HapticFeedback.heavyImpact();
    } catch (_) {}

    await _showForegroundRingNotification();
  }

  bool _untilAnswered = false;

  Future<void> stopRing() async {
    _ringing = false;
    _untilAnswered = false;
    try {
      await _player.stop();
    } catch (e) {
      Log.e(_tag, 'audio stop failed', e);
    }
    try {
      await _local.cancel(_ringNotificationId);
    } catch (e) {
      Log.e(_tag, 'cancel failed', e);
    }
  }

  Future<void> _showForegroundRingNotification() async {
    final android = AndroidNotificationDetails(
      _rideChannelId,
      _rideChannelName,
      channelDescription: _rideChannelDesc,
      importance: Importance.max,
      priority: Priority.max,
      playSound: false, // the app is open: the in-app ringtone plays
      fullScreenIntent: true,
      category: AndroidNotificationCategory.call,
      ongoing: true,
      autoCancel: false,
      enableVibration: true,
      visibility: NotificationVisibility.public,
      // Orders: no time limit, and the sound repeats (FLAG_INSISTENT = 4)
      // until the notification is removed (accepted / cancelled).
      timeoutAfter: _untilAnswered ? null : 60000,
      additionalFlags: _untilAnswered ? Int32List.fromList([4]) : null,
    );

    const ios = DarwinNotificationDetails(
      presentAlert: true,
      presentBadge: true,
      presentSound: true,
      sound: 'ringtone.caf',
      interruptionLevel: InterruptionLevel.timeSensitive,
    );

    try {
      await _local.show(
        _ringNotificationId,
        'New ride request',
        'You have a new trip waiting — tap to respond.',
        NotificationDetails(android: android, iOS: ios),
      );
    } catch (e) {
      Log.e(_tag, 'foreground ring notify failed', e);
    }
  }

  // ============================================================
  // RING — BACKGROUND (called from FCM background isolate)
  // ============================================================
  /// [payload]: what tapping / the full-screen ring opens —
  /// a ride id, or "order:<id>" for a store order.
  Future<void> showBackgroundRingNotification({
    required String rideId,
    String title = 'New ride request',
    String body = 'You have a new trip waiting — tap to respond.',
    String? payload,
    Duration ringFor = const Duration(seconds: 60),
  }) async {
    await _initNotifications();

    if (Platform.isAndroid) {
      final canUse = await _canUseFullScreenIntentSafe();
      if (!canUse) {
        Log.w(_tag,
            'full-screen intent not permitted on this device — '
            'ring will appear as heads-up notification');
      }
    }

    final android = AndroidNotificationDetails(
      _rideChannelId,
      _rideChannelName,
      channelDescription: _rideChannelDesc,
      importance: Importance.max,
      priority: Priority.max,
      playSound: true,
      sound: _ringSound,
      audioAttributesUsage: AudioAttributesUsage.notificationRingtone,
      fullScreenIntent: true,
      category: AndroidNotificationCategory.call,
      ongoing: true,
      autoCancel: true,
      enableVibration: true,
      vibrationPattern: _ringVibration,
      visibility: NotificationVisibility.public,
      ticker: title,
      timeoutAfter: ringFor.inMilliseconds,
      // FLAG_INSISTENT (4): the sound keeps repeating like a phone call
      // until it is answered, dismissed or times out.
      additionalFlags: Int32List.fromList([4]),
    );

    const ios = DarwinNotificationDetails(
      presentAlert: true,
      presentBadge: true,
      presentSound: true,
      interruptionLevel: InterruptionLevel.timeSensitive,
    );

    try {
      await _local.show(
        _ringNotificationId,
        title,
        body,
        NotificationDetails(android: android, iOS: ios),
        payload: payload ?? rideId,
      );
      Log.i(_tag, 'bg ring notification shown for ${payload ?? rideId}');
    } catch (e) {
      Log.e(_tag, 'bg ring notify failed', e);
    }
  }

  /// Stops a ringing notification (e.g. the store opened its orders).
  Future<void> cancelRingNotification() async {
    try {
      await _local.cancel(_ringNotificationId);
    } catch (_) {}
  }

  /// When the app was opened by tapping the ring (or the ring opened it
  /// full-screen on the lock screen), what it was for.
  Future<String?> launchPayload() async {
    try {
      final d = await _local.getNotificationAppLaunchDetails();
      if (d?.didNotificationLaunchApp ?? false) {
        final p = d!.notificationResponse?.payload;
        if (p != null && p.isNotEmpty) return p;
      }
    } catch (e) {
      Log.e(_tag, 'launch details failed', e);
    }
    return null;
  }

  /// Ask once for what ringing needs: showing notifications (Android 13+)
  /// and full-screen rings on the lock screen (Android 14+). The
  /// full-screen request opens a settings page, so it is asked at most
  /// every 3 days.
  Future<void> requestRingPermissions() async {
    if (kIsWeb) return;
    if (!_notifReady) await _initNotifications();
    try {
      if (Platform.isAndroid) {
        final android = _local.resolvePlatformSpecificImplementation<
            AndroidFlutterLocalNotificationsPlugin>();
        await android?.requestNotificationsPermission();
        if (!await _canUseFullScreenIntentSafe()) {
          final prefs = await SharedPreferences.getInstance();
          final last = prefs.getInt('kongo_fsi_asked') ?? 0;
          final now = DateTime.now().millisecondsSinceEpoch;
          if (now - last > const Duration(days: 3).inMilliseconds) {
            await prefs.setInt('kongo_fsi_asked', now);
            await requestFullScreenIntentPermission();
          }
        }
      } else if (Platform.isIOS) {
        final ios = _local.resolvePlatformSpecificImplementation<
            IOSFlutterLocalNotificationsPlugin>();
        await ios?.requestPermissions(alert: true, badge: true, sound: true);
      }
    } catch (e) {
      Log.e(_tag, 'ring permissions failed', e);
    }
  }

  Future<bool> _canUseFullScreenIntentSafe() async {
    try {
      final android = _local.resolvePlatformSpecificImplementation<
          AndroidFlutterLocalNotificationsPlugin>();
      if (android == null) return true;

      final dynamic dynamicAndroid = android;
      final result = await dynamicAndroid.canUseFullScreenIntent();
      return (result as bool?) ?? true;
    } catch (e) {
      return true;
    }
  }

  Future<void> requestFullScreenIntentPermission() async {
    if (!Platform.isAndroid) return;
    try {
      final android = _local.resolvePlatformSpecificImplementation<
          AndroidFlutterLocalNotificationsPlugin>();
      if (android == null) return;

      final dynamic dynamicAndroid = android;
      await dynamicAndroid.requestFullScreenIntentPermission();
    } catch (e) {
      Log.i(_tag,
          'requestFullScreenIntentPermission not available on this plugin version');
    }
  }

  // ============================================================
  // CHAT
  // ============================================================
  Future<void> showChatNotification({
    required String title,
    required String body,
    String? rideId,
  }) async {
    if (!_notifReady) await _initNotifications();

    final android = AndroidNotificationDetails(
      _chatChannelId,
      _chatChannelName,
      channelDescription: _chatChannelDesc,
      importance: Importance.high,
      priority: Priority.high,
      playSound: true,
      enableVibration: true,
      autoCancel: true,
      styleInformation: BigTextStyleInformation(body),
    );

    const ios = DarwinNotificationDetails(
      presentAlert: true,
      presentBadge: true,
      presentSound: true,
      interruptionLevel: InterruptionLevel.active,
    );

    try {
      await _local.show(
        DateTime.now().millisecondsSinceEpoch ~/ 1000,
        title,
        body,
        NotificationDetails(android: android, iOS: ios),
        payload: rideId,
      );
    } catch (e) {
      Log.e(_tag, 'chat notify failed', e);
    }
  }
}
