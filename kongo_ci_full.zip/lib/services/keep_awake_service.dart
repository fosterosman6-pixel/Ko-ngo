// lib/services/keep_awake_service.dart
//
// While a driver is online the phone's screen stays on, so the ring and the
// request screen are always seen. Turned off when the driver goes offline
// or signs out. Needs the wakelock_plus package.

import 'package:flutter/foundation.dart' show kIsWeb, debugPrint;
import 'package:wakelock_plus/wakelock_plus.dart';

class KeepAwake {
  KeepAwake._();

  static Future<void> on() async {
    if (kIsWeb) return;
    try {
      await WakelockPlus.enable();
    } catch (e) {
      debugPrint('keep awake on failed: $e');
    }
  }

  static Future<void> off() async {
    if (kIsWeb) return;
    try {
      await WakelockPlus.disable();
    } catch (e) {
      debugPrint('keep awake off failed: $e');
    }
  }
}
