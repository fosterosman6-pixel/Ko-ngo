// lib/services/hiring_service.dart
//
// Hiring Hub: jobs people post, applications workers send.
// Tables: job_categories, jobs, job_applications (step35_hiring_hub.sql).

import 'package:flutter/foundation.dart' show debugPrint;
import 'package:supabase_flutter/supabase_flutter.dart';

/// Pictures that ship inside the app. The admin can replace any of them
/// with an uploaded photo (job_categories.image_url).
const Map<String, String> kJobCategoryAssets = {
  'rides_delivery': 'assets/images/delivery_bike.png',
  'cleaning': 'assets/images/job_cleaning.png',
  'construction': 'assets/images/job_construction.png',
  'retail': 'assets/images/job_hospitality.png',
  'tutoring': 'assets/images/job_tutoring.png',
  'admin_office': 'assets/images/job_office.png',
  'beauty': 'assets/images/cat_beauty.png',
  'other': 'assets/images/job_hiring.png',
};

/// Soft background colour behind each category picture.
const Map<String, int> kJobCategoryTint = {
  'rides_delivery': 0xFFFFF1CC,
  'cleaning': 0xFFE3F0FF,
  'construction': 0xFFFFE9D6,
  'retail': 0xFFFFDDE6,
  'tutoring': 0xFFEBE0FF,
  'admin_office': 0xFFDDF6E7,
  'beauty': 0xFFFFE0EE,
  'other': 0xFFEDEDED,
};

class JobCategory {
  final String key;
  final String name;
  final String? imageUrl;
  const JobCategory(this.key, this.name, this.imageUrl);

  factory JobCategory.fromMap(Map<String, dynamic> m) => JobCategory(
        (m['key'] ?? 'other').toString(),
        (m['name'] ?? '').toString(),
        (m['image_url'] ?? '').toString().isEmpty
            ? null
            : m['image_url'].toString(),
      );
}

class Job {
  final String id;
  final String employerId;
  final String title;
  final String categoryKey;
  final String description;
  final String payType; // hour | day | fixed
  final double amount;
  final String duration; // today | week | ongoing
  final String location;
  final double? lat;
  final double? lng;
  final int workersNeeded;
  final bool reqVerifiedId;
  final bool reqExperience;
  final bool reqOwnTools;
  final bool reqOwnTransport;
  final String? photoUrl;
  final bool urgent;
  final String status; // pending | open | filled | closed | rejected
  final String? rejectReason;
  final DateTime createdAt;
  final int applicantCount;
  final String? myApplication; // my application status for this job, if any
  final DateTime? boostedUntil;

  /// Urgent badge + pinned on top: only while the boost is running.
  bool get isBoosted =>
      urgent && (boostedUntil == null || boostedUntil!.isAfter(DateTime.now()));

  const Job({
    required this.id,
    required this.employerId,
    required this.title,
    required this.categoryKey,
    required this.description,
    required this.payType,
    required this.amount,
    required this.duration,
    required this.location,
    required this.lat,
    required this.lng,
    required this.workersNeeded,
    required this.reqVerifiedId,
    required this.reqExperience,
    required this.reqOwnTools,
    required this.reqOwnTransport,
    required this.photoUrl,
    required this.urgent,
    required this.status,
    required this.rejectReason,
    required this.createdAt,
    this.applicantCount = 0,
    this.myApplication,
    this.boostedUntil,
  });

  factory Job.fromMap(Map<String, dynamic> m,
      {int applicants = 0, String? mine}) {
    double? d(dynamic v) => v == null ? null : double.tryParse(v.toString());
    return Job(
      id: m['id'].toString(),
      employerId: (m['employer_id'] ?? '').toString(),
      title: (m['title'] ?? '').toString(),
      categoryKey: (m['category_key'] ?? 'other').toString(),
      description: (m['description'] ?? '').toString(),
      payType: (m['pay_type'] ?? 'hour').toString(),
      amount: d(m['amount']) ?? 0,
      duration: (m['duration'] ?? 'today').toString(),
      location: (m['location_text'] ?? '').toString(),
      lat: d(m['lat']),
      lng: d(m['lng']),
      workersNeeded: int.tryParse('${m['workers_needed']}') ?? 1,
      reqVerifiedId: m['req_verified_id'] == true,
      reqExperience: m['req_experience'] == true,
      reqOwnTools: m['req_own_tools'] == true,
      reqOwnTransport: m['req_own_transport'] == true,
      photoUrl: (m['photo_url'] ?? '').toString().isEmpty
          ? null
          : m['photo_url'].toString(),
      urgent: m['urgent'] == true,
      status: (m['status'] ?? 'pending').toString(),
      rejectReason: m['reject_reason']?.toString(),
      createdAt:
          DateTime.tryParse('${m['created_at']}')?.toLocal() ?? DateTime.now(),
      applicantCount: applicants,
      myApplication: mine,
      boostedUntil: m['boosted_until'] == null
          ? null
          : DateTime.tryParse('${m['boosted_until']}')?.toLocal(),
    );
  }
}

/// What posting costs in this country (set by the admin; off by default).
class JobFees {
  final bool enabled;
  final double postFee;
  final double boostFee;
  final int boostDays;
  final double balance;
  const JobFees({
    this.enabled = false,
    this.postFee = 0,
    this.boostFee = 0,
    this.boostDays = 3,
    this.balance = 0,
  });

  double total(bool urgent) => enabled ? postFee + (urgent ? boostFee : 0) : 0;
}

class JobApplicant {
  final String id;
  final String workerId;
  final String status;
  final String message;
  final String name;
  final String phone;
  final String? avatarUrl;
  final DateTime createdAt;
  final bool verified;
  final String headline;
  final String skills;
  final int experienceYears;
  final String about;
  final double ratingAvg;
  final int ratingCount;
  final int? myStars; // what I (the employer) already gave this worker
  const JobApplicant({
    required this.id,
    required this.workerId,
    required this.status,
    required this.message,
    required this.name,
    required this.phone,
    required this.avatarUrl,
    required this.createdAt,
    this.verified = false,
    this.headline = '',
    this.skills = '',
    this.experienceYears = 0,
    this.about = '',
    this.ratingAvg = 0,
    this.ratingCount = 0,
    this.myStars,
  });
}

/// What a worker saves about themselves once; employers see it on applications.
class WorkerProfile {
  final String headline;
  final String skills;
  final int experienceYears;
  final String about;
  const WorkerProfile({
    this.headline = '',
    this.skills = '',
    this.experienceYears = 0,
    this.about = '',
  });
}

class HiringService {
  HiringService._();
  static final HiringService instance = HiringService._();

  SupabaseClient get _sb => Supabase.instance.client;
  String? get _uid => _sb.auth.currentUser?.id;

  // ── categories ────────────────────────────────────────────────
  Future<List<JobCategory>> categories() async {
    try {
      final rows = await _sb
          .from('job_categories')
          .select('key,name,image_url')
          .eq('active', true)
          .order('sort');
      final list = (rows as List)
          .map((r) => JobCategory.fromMap(Map<String, dynamic>.from(r)))
          .toList();
      if (list.isNotEmpty) return list;
    } catch (e) {
      debugPrint('HiringService.categories: $e');
    }
    return kJobCategoryAssets.keys
        .map((k) => JobCategory(k, k, null))
        .toList();
  }

  // ── jobs for workers ──────────────────────────────────────────
  Future<List<Job>> openJobs({String? category, String query = ''}) async {
    try {
      var q = _sb.from('jobs').select().eq('status', 'open');
      if (category != null && category.isNotEmpty) {
        q = q.eq('category_key', category);
      }
      final text = query.trim().replaceAll(RegExp(r'[%,()]'), ' ');
      if (text.isNotEmpty) {
        q = q.or('title.ilike.%$text%,description.ilike.%$text%');
      }
      final rows = await q.order('created_at', ascending: false).limit(100);
      final mine = await _myApplicationMap();
      final list = (rows as List)
          .map((r) {
            final m = Map<String, dynamic>.from(r);
            return Job.fromMap(m, mine: mine[m['id'].toString()]);
          })
          .where((j) => j.employerId != _uid)
          .toList();
      // Boosted (paid urgent) jobs first; the rest stay newest first.
      final boosted = list.where((j) => j.isBoosted).toList();
      final rest = list.where((j) => !j.isBoosted).toList();
      return [...boosted, ...rest];
    } catch (e) {
      debugPrint('HiringService.openJobs: $e');
      rethrow;
    }
  }

  Future<Map<String, String>> _myApplicationMap() async {
    final uid = _uid;
    if (uid == null) return {};
    final rows = await _sb
        .from('job_applications')
        .select('job_id,status')
        .eq('worker_id', uid);
    return {
      for (final r in rows as List)
        r['job_id'].toString(): r['status'].toString()
    };
  }

  Future<String> employerName(String jobId) async {
    try {
      final r = await _sb.rpc('kongo_job_employer_name',
          params: {'p_job': jobId});
      return (r ?? '').toString();
    } catch (_) {
      return '';
    }
  }

  Future<bool> employerVerified(String jobId) async {
    try {
      final r = await _sb.rpc('kongo_job_employer_verified',
          params: {'p_job': jobId});
      return r == true;
    } catch (_) {
      return false;
    }
  }

  // ── worker profile ─────────────────────────────────────────────
  Future<WorkerProfile> myProfile() async {
    final uid = _uid;
    if (uid == null) return const WorkerProfile();
    try {
      final r = await _sb
          .from('worker_profiles')
          .select()
          .eq('user_id', uid)
          .maybeSingle();
      if (r == null) return const WorkerProfile();
      return WorkerProfile(
        headline: (r['headline'] ?? '').toString(),
        skills: (r['skills'] ?? '').toString(),
        experienceYears: int.tryParse('${r['experience_years']}') ?? 0,
        about: (r['about'] ?? '').toString(),
      );
    } catch (e) {
      debugPrint('HiringService.myProfile: $e');
      return const WorkerProfile();
    }
  }

  Future<void> saveProfile(WorkerProfile p) async {
    final uid = _uid;
    if (uid == null) throw Exception('Please sign in again');
    await _sb.from('worker_profiles').upsert({
      'user_id': uid,
      'headline': p.headline.trim(),
      'skills': p.skills.trim(),
      'experience_years': p.experienceYears,
      'about': p.about.trim(),
      'updated_at': DateTime.now().toUtc().toIso8601String(),
    }, onConflict: 'user_id');
  }

  // ── ratings ───────────────────────────────────────────────────
  Future<void> rate(String jobId, String rateeId, int stars,
      String comment) async {
    await _sb.rpc('kongo_rate_job', params: {
      'p_job': jobId,
      'p_ratee': rateeId,
      'p_stars': stars,
      'p_comment': comment,
    });
  }

  /// Stars I already gave this person for this job (null = not rated yet).
  Future<int?> myRatingFor(String jobId, String rateeId) async {
    final uid = _uid;
    if (uid == null) return null;
    try {
      final r = await _sb
          .from('job_ratings')
          .select('stars')
          .eq('job_id', jobId)
          .eq('rater_id', uid)
          .eq('ratee_id', rateeId)
          .maybeSingle();
      return r == null ? null : int.tryParse('${r['stars']}');
    } catch (_) {
      return null;
    }
  }

  /// (average, count) of the employer of this job.
  Future<(double, int)> employerRating(String jobId) async {
    try {
      final r = await _sb
          .rpc('kongo_job_employer_rating', params: {'p_job': jobId});
      final m = Map<String, dynamic>.from(r as Map);
      return (double.tryParse('${m['avg']}') ?? 0, int.tryParse('${m['count']}') ?? 0);
    } catch (_) {
      return (0.0, 0);
    }
  }

  // ── apply / withdraw ──────────────────────────────────────────
  Future<void> apply(String jobId, String message) async {
    final uid = _uid;
    if (uid == null) throw Exception('Please sign in again');
    await _sb.from('job_applications').upsert({
      'job_id': jobId,
      'worker_id': uid,
      'message': message.trim(),
      'status': 'applied',
    }, onConflict: 'job_id,worker_id');
  }

  Future<void> withdraw(String jobId) async {
    final uid = _uid;
    if (uid == null) return;
    await _sb
        .from('job_applications')
        .update({'status': 'withdrawn'})
        .eq('job_id', jobId)
        .eq('worker_id', uid);
  }

  /// My applications with the job each one is for.
  Future<List<Map<String, dynamic>>> myApplications() async {
    final uid = _uid;
    if (uid == null) return [];
    final rows = await _sb
        .from('job_applications')
        .select('id,status,message,created_at,jobs(*)')
        .eq('worker_id', uid)
        .order('created_at', ascending: false);
    return (rows as List)
        .map((r) => Map<String, dynamic>.from(r))
        .where((r) => r['jobs'] != null)
        .toList();
  }

  // ── employer side ─────────────────────────────────────────────
  Future<List<Job>> myJobs() async {
    final uid = _uid;
    if (uid == null) return [];
    final rows = await _sb
        .from('jobs')
        .select('*, job_applications(status)')
        .eq('employer_id', uid)
        .order('created_at', ascending: false);
    return (rows as List).map((r) {
      final m = Map<String, dynamic>.from(r);
      final apps = (m['job_applications'] as List? ?? [])
          .where((a) => a['status'] != 'withdrawn')
          .length;
      return Job.fromMap(m, applicants: apps);
    }).toList();
  }

  Future<JobFees> fees() async {
    try {
      final r = await _sb.rpc('kongo_job_fees');
      final m = Map<String, dynamic>.from(r as Map);
      double d(dynamic v) => double.tryParse('$v') ?? 0;
      return JobFees(
        enabled: m['enabled'] == true,
        postFee: d(m['post_fee']),
        boostFee: d(m['boost_fee']),
        boostDays: int.tryParse('${m['boost_days']}') ?? 3,
        balance: d(m['balance']),
      );
    } catch (e) {
      debugPrint('HiringService.fees: $e');
      return const JobFees();
    }
  }

  Future<void> postJob(Map<String, dynamic> data) async {
    final uid = _uid;
    if (uid == null) throw Exception('Please sign in again');
    await _sb.from('jobs').insert({...data, 'employer_id': uid});
  }

  Future<void> closeJob(String jobId, {bool filled = false}) async {
    await _sb
        .from('jobs')
        .update({'status': filled ? 'filled' : 'closed'}).eq('id', jobId);
  }

  Future<List<JobApplicant>> applicants(String jobId) async {
    final rows = await _sb.rpc('kongo_job_applicants',
        params: {'p_job': jobId});
    return (rows as List).map((r) {
      final m = Map<String, dynamic>.from(r);
      return JobApplicant(
        id: m['id'].toString(),
        workerId: m['worker_id'].toString(),
        status: (m['status'] ?? 'applied').toString(),
        message: (m['message'] ?? '').toString(),
        name: (m['name'] ?? 'Worker').toString(),
        phone: (m['phone'] ?? '').toString(),
        avatarUrl: (m['avatar_url'] ?? '').toString().isEmpty
            ? null
            : m['avatar_url'].toString(),
        createdAt: DateTime.tryParse('${m['created_at']}')?.toLocal() ??
            DateTime.now(),
        verified: m['is_verified'] == true,
        headline: (m['headline'] ?? '').toString(),
        skills: (m['skills'] ?? '').toString(),
        experienceYears: int.tryParse('${m['experience_years']}') ?? 0,
        about: (m['about'] ?? '').toString(),
        ratingAvg: double.tryParse('${m['rating_avg']}') ?? 0,
        ratingCount: int.tryParse('${m['rating_count']}') ?? 0,
        myStars: int.tryParse('${m['my_stars']}'),
      );
    }).toList();
  }

  Future<void> setApplicantStatus(String appId, String status) async {
    await _sb
        .from('job_applications')
        .update({'status': status}).eq('id', appId);
  }
}
