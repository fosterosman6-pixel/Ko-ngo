﻿// lib/services/notification_service.dart
//
// Outgoing notifications. Every send writes a `notifications` row
// with a standard payload shape so the router can navigate on tap:
//
//   type   — 'ride_request' | 'ride_accepted' | 'substitution' | ...
//   data   — { route, tab, params: { ... } }
//
// Also owns device token registration/unregistration for FCM delivery.
//
// Legacy call sites that used `data:` should switch to `params:`.
// The `data` named parameter was removed; if you still have files
// calling it, either rename the arg or add a thin compatibility
// wrapper at the bottom of this file.

import 'dart:async';
import 'package:flutter/foundation.dart' show kIsWeb, debugPrint;
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class NotificationService {
  NotificationService._();
  static final NotificationService instance = NotificationService._();

  StreamSubscription<String>? _tokenRefreshSub;

  // Legacy callbacks kept for main.dart compatibility.
  void Function(String rideId)? onRideRequest;
  void Function(String rideId)? onChatOpen;

  // ═══════════════════════════════════════════════════════════
  // DEVICE TOKEN REGISTRATION
  // ═══════════════════════════════════════════════════════════
  Future<void> register() async {
    if (kIsWeb) return;
    try {
      final token = await FirebaseMessaging.instance.getToken();
      if (token == null || token.isEmpty) return;
      await _persistToken(token, platform: _platformName());

      _tokenRefreshSub?.cancel();
      _tokenRefreshSub =
          FirebaseMessaging.instance.onTokenRefresh.listen((newToken) async {
        await _persistToken(newToken, platform: _platformName());
      });
    } catch (e) {
      debugPrint('NotificationService.register failed: $e');
    }
  }

  Future<void> unregister() async {
    if (kIsWeb) return;
    try {
      final token = await FirebaseMessaging.instance.getToken();
      if (token == null || token.isEmpty) return;
      final uid = Supabase.instance.client.auth.currentUser?.id;
      if (uid == null) return;
      await Supabase.instance.client
          .from('device_tokens')
          .delete()
          .eq('user_id', uid)
          .eq('token', token);
      await _tokenRefreshSub?.cancel();
      _tokenRefreshSub = null;
    } catch (e) {
      debugPrint('NotificationService.unregister failed: $e');
    }
  }

  Future<void> _persistToken(String token, {required String platform}) async {
    final uid = Supabase.instance.client.auth.currentUser?.id;
    if (uid == null) return;
    try {
      await Supabase.instance.client.from('device_tokens').upsert({
        'user_id': uid,
        'token': token,
        'platform': platform,
        'updated_at': DateTime.now().toUtc().toIso8601String(),
      }, onConflict: 'user_id,token');
    } catch (e) {
      debugPrint('persistToken failed: $e');
    }
  }

  String _platformName() {
    if (kIsWeb) return 'web';
    return 'native';
  }

  // ═══════════════════════════════════════════════════════════
  // SENDING
  // ═══════════════════════════════════════════════════════════

  /// Write a notification row. The DB trigger handles FCM fan-out.
  static Future<void> send({
    required String toUserId,
    required String type,
    String? title,
    String? body,
    String? route,
    String? tab,
    Map<String, dynamic>? params,
    // Legacy alias — old call sites pass `data:`. Treated the same as
    // `params:` so the compile error disappears without a caller edit.
    Map<String, dynamic>? data,
  }) async {
    final effectiveParams = params ?? data;

    final payload = <String, dynamic>{
      if (route != null) 'route': route,
      if (tab != null) 'tab': tab,
      if (effectiveParams != null) 'params': effectiveParams,
    };

    try {
      await Supabase.instance.client.from('notifications').insert({
        'user_id': toUserId,
        'title': title ?? _fallbackTitle(type),
        'body': body ?? _fallbackBody(type),
        'type': type,
        'data': payload.isEmpty ? null : payload,
        'read': false,
      });
    } catch (e) {
      debugPrint('NotificationService.send failed: $e');
    }
  }

  static String _fallbackTitle(String type) {
    switch (type) {
      case 'ride_request':
        return 'New ride request';
      case 'ride_accepted':
        return 'Driver on the way';
      case 'ride_cancelled':
        return 'Ride cancelled';
      case 'substitution':
        return 'Item unavailable';
      case 'order_status':
        return 'Order update';
      case 'chat_message':
        return 'New message';
      default:
        return 'ko!ngo';
    }
  }

  static String _fallbackBody(String type) {
    switch (type) {
      case 'ride_request':
        return 'A passenger needs a ride.';
      case 'ride_accepted':
        return 'Your driver accepted your request.';
      case 'ride_cancelled':
        return 'The ride was cancelled.';
      case 'substitution':
        return 'Your shopper suggests a replacement.';
      case 'order_status':
        return 'Tap to see the latest status.';
      case 'chat_message':
        return 'You have a new message.';
      default:
        return '';
    }
  }
}
