// lib/services/notification_router.dart

import 'dart:convert';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter/material.dart';
import 'package:efuride_app/main.dart' show globalNavigatorKey, globalMessengerKey;
import 'package:efuride_app/l10n/app_strings.dart';
import 'package:efuride_app/providers/notification_provider.dart';
import 'package:efuride_app/services/ring_service.dart';

class NotificationRouter {
  NotificationRouter._();
  static final NotificationRouter instance = NotificationRouter._();

  bool _initialised = false;
  bool _initialHandled = false;

  void init() {
    if (_initialised) return;
    _initialised = true;

    if (kIsWeb) return;

    FirebaseMessaging.instance
        .getInitialMessage()
        .then((msg) {
      if (msg == null || _initialHandled) return;
      _initialHandled = true;
      _handleFcm(msg);
    });

    FirebaseMessaging.onMessageOpenedApp.listen(_handleFcm);

    FirebaseMessaging.onMessage.listen((msg) {
      // Foreground: NotificationProvider handles most via realtime.
      // A new store order still rings, so the store doesn't miss it.
      final d = msg.data;
      final orderId = d['order_id']?.toString() ?? '';
      if (d['type'] == 'order_new' &&
          orderId.isNotEmpty &&
          NotificationProvider.instance.currentRole == 'merchant') {
        RingService.instance.showBackgroundRingNotification(
          rideId: '',
          payload: 'order:$orderId',
          title: d['title']?.toString() ?? tr('New order'),
          body: d['body']?.toString() ?? '',
          ringFor: const Duration(minutes: 3),
        );
      } else if (d['type'] == 'task_new' &&
          orderId.isNotEmpty &&
          NotificationProvider.instance.currentRole == 'shopper') {
        RingService.instance.showBackgroundRingNotification(
          rideId: '',
          payload: 'shop:$orderId',
          title: d['title']?.toString() ?? tr('New shopping task'),
          body: d['body']?.toString() ?? '',
          ringFor: const Duration(minutes: 3),
        );
      }
    });
  }

  void _handleFcm(RemoteMessage msg) {
    final data = msg.data;
    final route = data['route']?.toString();
    final tab = data['tab']?.toString();
    final role = data['role']?.toString() ?? 'customer'; // <--- Read role
    final params = _decodeParams(data['params']);

    // 🛑 Ignore FCM if role doesn't match current active role
    if (role != NotificationProvider.instance.currentRole) {
      debugPrint('Ignoring FCM for role $role (current: ${NotificationProvider.instance.currentRole})');
      return;
    }

    if (route == null || route.isEmpty) {
      final rideId = data['ride_id']?.toString();
      if (rideId != null && rideId.isNotEmpty) {
        _push('/order_tracking', {'order_id': rideId});
      }
      return;
    }

    _push(route, {'tab': tab, ...params});
  }

  Map<String, dynamic> _decodeParams(dynamic raw) {
    if (raw == null) return const {};
    if (raw is Map) return Map<String, dynamic>.from(raw);
    if (raw is String && raw.isNotEmpty) {
      try {
        final decoded = jsonDecode(raw);
        if (decoded is Map) return Map<String, dynamic>.from(decoded);
      } catch (_) {}
    }
    return const {};
  }

  void handleInApp(AppNotification n) {
    // 🛑 Ignore if role doesn't match
    if (n.role != NotificationProvider.instance.currentRole) return;

    final ctx = globalNavigatorKey.currentContext;
    if (ctx == null) return;

    final title = n.localizedTitle(ctx);
    final body = n.localizedBody(ctx);

    globalMessengerKey.currentState?.showSnackBar(
      SnackBar(
        behavior: SnackBarBehavior.floating,
        backgroundColor: Colors.white,
        elevation: 6,
        margin: const EdgeInsets.all(12),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(14),
          side: BorderSide(color: Colors.grey.shade200),
        ),
        duration: const Duration(seconds: 5),
        content: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: _accentFor(n.type).withValues(alpha: 0.12),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Icon(_iconFor(n.type),
                  color: _accentFor(n.type), size: 20),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(title,
                      style: const TextStyle(
                        color: Color(0xFF1A1A1A),
                        fontWeight: FontWeight.bold,
                        fontSize: 14,
                      )),
                  if (body.isNotEmpty) ...[
                    const SizedBox(height: 2),
                    Text(body,
                        style: const TextStyle(
                          color: Color(0xFF575047),
                          fontSize: 14,
                        )),
                  ],
                ],
              ),
            ),
          ],
        ),
        action: SnackBarAction(
          label: S.of(ctx).t('open'),
          textColor: const Color(0xFF1E88E5),
          onPressed: () => _navigateFromNotification(n),
        ),
      ),
    );
  }

  void _push(String route, Map<String, dynamic> args) {
    final nav = globalNavigatorKey.currentState;
    if (nav == null) return;

    if (_isShellRoute(route)) {
      final tab = args['tab']?.toString();
      final uri = Uri(
        path: route,
        queryParameters: {
          if (tab != null && tab.isNotEmpty) 'tab': tab,
        },
      ).toString();
      nav.pushNamed(uri, arguments: args);
      return;
    }

    nav.pushNamed(route, arguments: args);
  }

  bool _isShellRoute(String r) =>
      r == '/customer' || r == '/driver' ||
      r == '/shopper' || r == '/merchant';

  void _navigateFromNotification(AppNotification n) {
    final route = n.route;
    final tab = n.tab;
    final params = n.params;

    if (route != null && route.isNotEmpty) {
      _push(route, {'tab': tab, ...params});
      return;
    }

    switch (n.type) {
      case 'ride_request':
      case 'ride_accepted':
      case 'ride_cancelled':
        final rideId = params['ride_id'];
        if (rideId != null) {
          _push('/order_tracking', {'order_id': rideId});
        }
        break;
      case 'substitution':
        final subId = params['substitution_id'];
        if (subId != null) {
          _push('/substitution', params);
        }
        break;
      case 'order_status':
        final orderId = params['order_id'];
        if (orderId != null) {
          _push('/order_tracking', {'order_id': orderId});
        }
        break;
      case 'support':
        _push('/support', const {});
        break;
    }
  }

  IconData _iconFor(String type) {
    switch (type) {
      case 'ride_request': return Icons.local_taxi_outlined;
      case 'ride_accepted': return Icons.check_circle_outline;
      case 'ride_cancelled': return Icons.cancel_outlined;
      case 'substitution': return Icons.swap_horiz;
      case 'order_status': return Icons.receipt_long_outlined;
      case 'chat_message': return Icons.chat_bubble_outline;
      default: return Icons.notifications_none;
    }
  }

  Color _accentFor(String type) {
    switch (type) {
      case 'ride_request': return const Color(0xFFF2B705);
      case 'ride_accepted': return const Color(0xFF22C55E);
      case 'ride_cancelled': return const Color(0xFFE53935);
      case 'substitution': return const Color(0xFF7B5BD6);
      case 'order_status': return const Color(0xFFE88A1A);
      default: return const Color(0xFF1E88E5);
    }
  }
}
