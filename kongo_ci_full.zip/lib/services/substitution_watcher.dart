// lib/services/substitution_watcher.dart
//
// Watches the `substitutions` table for new pending rows whose order
// belongs to the current customer. When one arrives, invokes
// `onPending` with a payload the /substitution route understands.

import 'dart:async';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:efuride_app/utils/log.dart';

class SubstitutionWatcher {
  SubstitutionWatcher._();
  static final SubstitutionWatcher instance = SubstitutionWatcher._();

  static const _tag = 'SubstitutionWatcher';

  RealtimeChannel? _channel;
  bool _running = false;

  void start({
    required Future<void> Function(Map<String, dynamic> sub) onPending,
  }) {
    if (_running) return;
    _running = true;

    try {
      _channel = Supabase.instance.client
          .channel('cust_sub_watch')
          .onPostgresChanges(
            event: PostgresChangeEvent.insert,
            schema: 'public',
            table: 'substitutions',
            callback: (payload) async {
              final row = payload.newRecord;
              if ((row['status'] ?? '') != 'pending') return;

              final uid =
                  Supabase.instance.client.auth.currentUser?.id;
              if (uid == null) return;

              // Confirm the substitution belongs to one of *my* orders.
              final itemId = row['order_item_id']?.toString();
              if (itemId == null || itemId.isEmpty) return;

              try {
                final item = await Supabase.instance.client
                    .from('order_items')
                    .select('order_id, orders!inner(customer_id)')
                    .eq('id', itemId)
                    .maybeSingle();

                final custId =
                    item?['orders']?['customer_id']?.toString();
                if (custId != uid) return;

                await onPending({
                  ...row,
                  'order_id': (item?['order_id'] ?? row['order_id'])
                      ?.toString(),
                });
              } catch (e) {
                Log.w(_tag, 'sub lookup failed: $e');
              }
            },
          )
          .subscribe();

      Log.i(_tag, 'started');
    } catch (e, s) {
      Log.e(_tag, 'start failed', e, s);
      _running = false;
    }
  }

  void stop() {
    if (!_running) return;
    _running = false;
    _channel?.unsubscribe();
    _channel = null;
    Log.i(_tag, 'stopped');
  }
}
