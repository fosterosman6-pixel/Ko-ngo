import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:efuride_app/utils/log.dart';

class LoyaltyService {
  LoyaltyService._();
  static const _tag = 'LoyaltyService';
  static final _client = Supabase.instance.client;

  // ============================================================
  // TIER LOGIC
  // ============================================================
  static String tierForPoints(int points) {
    if (points >= 500) return 'Platinum';
    if (points >= 300) return 'Gold';
    if (points >= 150) return 'Silver';
    return 'Bronze';
  }

  static int pointsPerRide(String tier) {
    switch (tier.toLowerCase()) {
      case 'platinum':
        return 25;
      case 'gold':
        return 20;
      case 'silver':
        return 15;
      default:
        return 10;
    }
  }

  static String promoCodeForTier(String tier) {
    switch (tier.toLowerCase()) {
      case 'platinum':
        return 'TIER_PLATINUM';
      case 'gold':
        return 'TIER_GOLD';
      case 'silver':
        return 'TIER_SILVER';
      default:
        return 'TIER_BRONZE';
    }
  }

  // ============================================================
  // CURRENT USER
  // ============================================================
  static Future<({int points, String tier})> myTier() async {
    final user = _client.auth.currentUser;
    if (user == null) return (points: 0, tier: 'Bronze');

    try {
      final row = await _client
          .from('profiles')
          .select('loyalty_points')
          .eq('id', user.id)
          .maybeSingle();

      final pts = (row?['loyalty_points'] as num?)?.toInt() ?? 0;
      return (points: pts, tier: tierForPoints(pts));
    } catch (e) {
      Log.e(_tag, 'myTier failed', e);
      return (points: 0, tier: 'Bronze');
    }
  }

  // ============================================================
  // AWARD
  // ============================================================
  /// Awards points for a completed ride. Uses an atomic server-side RPC
  /// to prevent double-award on races.
  static Future<void> awardForCompletedRide(String rideId) async {
    final user = _client.auth.currentUser;
    if (user == null) return;

    try {
      final me = await myTier();
      final earned = pointsPerRide(me.tier);

      await _client.rpc('award_loyalty_points', params: {
        'p_ride_id': rideId,
        'p_points': earned,
      });

      Log.i(_tag, 'awarded $earned points for ride $rideId');
    } catch (e) {
      // If the RPC isn't installed, fall back to the old logic — but
      // log the warning so you know to run the migration.
      Log.e(_tag, 'awardForCompletedRide failed', e);
    }
  }
}
