// lib/services/road_reports_service.dart
//
// Drivers report police, accidents, hazards and traffic jams; other drivers
// are warned as they come near. Reports expire after 2 hours.
// Table: public.road_reports (see step48_road_reports.sql).

import 'package:flutter/foundation.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:supabase_flutter/supabase_flutter.dart' hide MapType;

class RoadReport {
  final String id;
  final String kind; // police | accident | hazard | jam
  final LatLng pos;
  const RoadReport(this.id, this.kind, this.pos);
}

class RoadReportsService {
  RoadReportsService._();
  static SupabaseClient get _sb => Supabase.instance.client;

  static const kinds = ['police', 'accident', 'hazard', 'jam'];

  /// Live reports inside a box of about [radiusKm] around [c].
  static Future<List<RoadReport>> near(LatLng c, {double radiusKm = 6}) async {
    try {
      final d = radiusKm / 111.0;
      final rows = await _sb
          .from('road_reports')
          .select('id, kind, lat, lng')
          .gte('expires_at', DateTime.now().toUtc().toIso8601String())
          .gte('lat', c.latitude - d)
          .lte('lat', c.latitude + d)
          .gte('lng', c.longitude - d)
          .lte('lng', c.longitude + d)
          .limit(100);
      return [
        for (final r in rows as List)
          RoadReport(
            r['id'].toString(),
            r['kind'].toString(),
            LatLng((r['lat'] as num).toDouble(), (r['lng'] as num).toDouble()),
          ),
      ];
    } catch (e) {
      debugPrint('RoadReportsService.near failed: $e');
      return const [];
    }
  }

  static Future<void> report(String kind, LatLng pos) async {
    await _sb.from('road_reports').insert({
      'kind': kind,
      'lat': pos.latitude,
      'lng': pos.longitude,
    });
  }
}
