import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:efuride_app/utils/app_error.dart';

/// Result of a wallet write operation. Prefer this over `bool` so callers
/// can differentiate "insert succeeded but notification failed" from
/// "insert failed".
class WalletResult {
  final bool success;
  final String? message;
  final String? insertedId;

  const WalletResult({
    required this.success,
    this.message,
    this.insertedId,
  });

  factory WalletResult.ok({String? id, String? message}) =>
      WalletResult(success: true, insertedId: id, message: message);

  factory WalletResult.fail([String? message]) =>
      WalletResult(success: false, message: message);
}

class WalletService {
  WalletService._();

  static final _client = Supabase.instance.client;

  // ============================================================
  // COMMISSION
  // ============================================================
  /// Cached for 60s. Falls back to 15 if the read fails.
  static int? _cachedCommissionPercent;
  static DateTime? _cachedAt;

  static Future<int> getCommissionPercent() async {
    final now = DateTime.now();
    if (_cachedCommissionPercent != null &&
        _cachedAt != null &&
        now.difference(_cachedAt!).inSeconds < 60) {
      return _cachedCommissionPercent!;
    }

    try {
      final s = await _client
          .from('app_settings')
          .select('commission_percent')
          .eq('id', 1)
          .maybeSingle()
          .timeout(const Duration(seconds: 8));

      final pct = (s?['commission_percent'] as num?)?.toInt() ?? 15;
      _cachedCommissionPercent = pct;
      _cachedAt = now;
      return pct;
    } catch (_) {
      return _cachedCommissionPercent ?? 15;
    }
  }

  /// Multiplier to apply to a fare to get the driver's net.
  /// 15% commission → 0.85
  static double commissionMultiplier(int pct) => (100 - pct) / 100.0;

  // ============================================================
  // READS
  // ============================================================
  static Future<List<Map<String, dynamic>>> listTransactions() async {
    final user = _client.auth.currentUser;
    if (user == null) return [];
    try {
      final rows = await _client
          .from('wallet_transactions')
          .select()
          .eq('user_id', user.id)
          .order('created_at', ascending: false)
          .limit(100);
      return List<Map<String, dynamic>>.from(rows);
    } catch (_) {
      return [];
    }
  }

  static Future<List<Map<String, dynamic>>> listMyTopups() async {
    final user = _client.auth.currentUser;
    if (user == null) return [];
    try {
      final rows = await _client
          .from('topup_requests')
          .select()
          .eq('user_id', user.id)
          .order('created_at', ascending: false)
          .limit(50);
      return List<Map<String, dynamic>>.from(rows);
    } catch (_) {
      return [];
    }
  }

  static Future<List<Map<String, dynamic>>> listMyPayouts() async {
    final user = _client.auth.currentUser;
    if (user == null) return [];
    try {
      final rows = await _client
          .from('payout_requests')
          .select()
          .eq('driver_id', user.id)
          .order('created_at', ascending: false)
          .limit(50);
      return List<Map<String, dynamic>>.from(rows);
    } catch (_) {
      return [];
    }
  }

  /// Balance, money held for payouts, money owed — worked out on the server.
  static Future<MyWallet> myWallet() async {
    final res = await _client.rpc('my_wallet').timeout(const Duration(seconds: 10));
    if (res is Map) return MyWallet.fromMap(res);
    return const MyWallet(
        balance: 0, held: 0, available: 0, owed: 0, earnedThisWeek: 0);
  }

  /// Wallet lines of one kind ('earning', 'sale', 'shopping', 'payout').
  static Future<List<Map<String, dynamic>>> listLines(String kind,
      {int limit = 40}) async {
    final user = _client.auth.currentUser;
    if (user == null) return [];
    try {
      final rows = await _client
          .from('wallet_transactions')
          .select()
          .eq('user_id', user.id)
          .like('notes', '[$kind]%')
          .order('created_at', ascending: false)
          .limit(limit);
      return List<Map<String, dynamic>>.from(rows);
    } catch (_) {
      return [];
    }
  }

  /// Text after the "[kind] " tag the server puts on each line.
  static String lineText(Map<String, dynamic> t) {
    final n = (t['notes'] ?? '').toString();
    final i = n.indexOf('] ');
    return n.startsWith('[') && i > 0 ? n.substring(i + 2) : n;
  }

  /// Reads the wallet balance and pending driver earnings in one shot.
  static Future<WalletSnapshot> getSnapshot({required bool isDriver}) async {
    final user = _client.auth.currentUser;
    if (user == null) {
      return const WalletSnapshot(balance: 0, pending: 0);
    }

    double balance = 0;
    try {
      final p = await _client
          .from('profiles')
          .select('wallet_balance')
          .eq('id', user.id)
          .maybeSingle()
          .timeout(const Duration(seconds: 8));
      balance = (p?['wallet_balance'] as num?)?.toDouble() ?? 0;
    } catch (_) {}

    double pending = 0;
    // Since step 21 the server credits every trip to the wallet, so there is
    // nothing "pending" to add. The old sum below only runs if my_wallet
    // isn't there yet (step 21 not run).
    bool serverLedger = false;
    try {
      await _client.rpc('my_wallet');
      serverLedger = true;
    } catch (_) {}
    if (isDriver && !serverLedger) {
      try {
        final pct = await getCommissionPercent();
        final mult = commissionMultiplier(pct);

        final rows = await _client
            .from('rides')
            .select('fare, payment_method')
            .eq('driver_id', user.id)
            .eq('status', 'completed')
            .neq('payout_status', 'paid')
            .timeout(const Duration(seconds: 8));

        for (final r in rows) {
          final fare = (r['fare'] as num?)?.toDouble() ?? 0;
          if ((r['payment_method'] ?? 'cash') == 'cash') {
            // Driver already has the cash; ko!ngo's fee comes off.
            pending -= fare * (1 - mult);
          } else {
            // Paid in the app (wallet / card): ko!ngo owes the driver.
            pending += fare * mult;
          }
        }
      } catch (_) {}
    }

    return WalletSnapshot(balance: balance, pending: pending);
  }

  // ============================================================
  // WRITES
  // ============================================================
  static Future<WalletResult> requestTopup({
    required double amount,
    required String method,
    String? reference,
  }) async {
    final user = _client.auth.currentUser;
    if (user == null) return WalletResult.fail('Not signed in');

    try {
      final inserted = await _client
          .from('topup_requests')
          .insert({
            'user_id': user.id,
            'amount': amount,
            'method': method,
            'reference': reference,
            'status': 'pending',
            'created_at': DateTime.now().toUtc().toIso8601String(),
          })
          .select()
          .single();

      return WalletResult.ok(id: inserted['id']?.toString());
    } catch (e) {
      // Friendly text only (rules written by ko!ngo are kept as they are).
      return WalletResult.fail(AppError.from(e).message);
    }
  }

  static Future<WalletResult> requestPayout({
    required double amount,
    required String bankName,
    required String accountNumber,
    required String accountHolder,
  }) async {
    final user = _client.auth.currentUser;
    if (user == null) return WalletResult.fail('Not signed in');

    try {
      // Save bank details so the driver doesn't re-enter them next time.
      try {
        await _client.from('profiles').update({
          'bank_name': bankName,
          'bank_account_number': accountNumber,
          'bank_account_holder': accountHolder,
        }).eq('id', user.id);
      } catch (_) {
        // Non-fatal — the payout still goes through.
      }

      final inserted = await _client
          .from('payout_requests')
          .insert({
            'driver_id': user.id,
            'amount': amount,
            'bank_name': bankName,
            'account_number': accountNumber,
            'account_holder': accountHolder,
            'status': 'pending',
            'created_at': DateTime.now().toUtc().toIso8601String(),
          })
          .select()
          .single();

      return WalletResult.ok(id: inserted['id']?.toString());
    } catch (e) {
      // Friendly text only (rules written by ko!ngo are kept as they are).
      return WalletResult.fail(AppError.from(e).message);
    }
  }

  /// Reads the driver's saved bank details (if any) for pre-filling.
  static Future<Map<String, String>?> getSavedBankDetails() async {
    final user = _client.auth.currentUser;
    if (user == null) return null;
    try {
      final p = await _client
          .from('profiles')
          .select('bank_name, bank_account_number, bank_account_holder')
          .eq('id', user.id)
          .maybeSingle();

      final name = p?['bank_name']?.toString() ?? '';
      final acct = p?['bank_account_number']?.toString() ?? '';
      final holder = p?['bank_account_holder']?.toString() ?? '';

      if (name.isEmpty && acct.isEmpty && holder.isEmpty) return null;
      return {
        'bank_name': name,
        'account_number': acct,
        'account_holder': holder,
      };
    } catch (_) {
      return null;
    }
  }
}

/// The wallet as the server sees it (step 21): what can be withdrawn,
/// what is waiting in payout requests, and what is owed to ko!ngo.
class MyWallet {
  final double balance;
  final double held;
  final double available;
  final double owed;
  final double earnedThisWeek;
  const MyWallet({
    required this.balance,
    required this.held,
    required this.available,
    required this.owed,
    required this.earnedThisWeek,
  });

  static double _d(dynamic v) => (v as num?)?.toDouble() ?? 0;

  factory MyWallet.fromMap(Map m) => MyWallet(
        balance: _d(m['balance']),
        held: _d(m['held']),
        available: _d(m['available']),
        owed: _d(m['owed']),
        earnedThisWeek: _d(m['earned_this_week']),
      );
}

class WalletSnapshot {
  final double balance;
  final double pending;
  const WalletSnapshot({required this.balance, required this.pending});
}
