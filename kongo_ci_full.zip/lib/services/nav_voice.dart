// lib/services/nav_voice.dart
//
// Speaks navigation messages ("In 200 metres, turn right").
// Needs the flutter_tts package (add to pubspec.yaml).

import 'package:flutter/foundation.dart';
import 'package:flutter_tts/flutter_tts.dart';

class NavVoice {
  NavVoice._();
  static final NavVoice instance = NavVoice._();

  final FlutterTts _tts = FlutterTts();
  bool _ready = false;
  String? _lang;

  /// Phone voices exist for these. Lingala uses French; Chichewa has no
  /// voice on most phones, so it falls back to English.
  static String localeFor(String code) {
    switch (code) {
      case 'fr':
      case 'ln':
        return 'fr-FR';
      case 'sw':
        return 'sw-KE';
      case 'af':
        return 'af-ZA';
      default:
        return 'en-ZA';
    }
  }

  Future<void> speak(String text, String appLangCode) async {
    if (text.trim().isEmpty) return;
    try {
      if (!_ready) {
        await _tts.setSpeechRate(0.5);
        await _tts.setVolume(1.0);
        _ready = true;
      }
      final l = localeFor(appLangCode);
      if (l != _lang) {
        await _tts.setLanguage(l);
        _lang = l;
      }
      await _tts.speak(text);
    } catch (e) {
      debugPrint('NavVoice.speak failed: $e');
    }
  }

  Future<void> stop() async {
    try {
      await _tts.stop();
    } catch (_) {}
  }
}
