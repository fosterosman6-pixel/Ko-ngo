// lib/services/order_service.dart
//
// Customer-side reads + writes for the Food/Grocery/Pharmacy verticals.
// Merchant-side actions live in MerchantService.

import 'dart:async';
import 'dart:math' as math;
import 'package:flutter/foundation.dart';
import 'package:geolocator/geolocator.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:efuride_app/models/cart_line.dart';
import 'package:efuride_app/models/order.dart';
import 'package:efuride_app/models/partner.dart';
import 'package:efuride_app/models/product.dart';
import 'package:efuride_app/services/pricing_service.dart';
import 'package:efuride_app/utils/search_match.dart';

class OrderService {
  OrderService._();
  static final OrderService instance = OrderService._();

  SupabaseClient get _sb => Supabase.instance.client;
  String? get _uid => _sb.auth.currentUser?.id;

  // ════════════════════════════════════════════════════════════
  // PARTNERS
  // ════════════════════════════════════════════════════════════

  Future<List<Partner>> fetchPartners({
    required String category,  // 'restaurant' | 'grocery' | 'pharmacy'
    int limit = 200,
  }) async {
    List rows;
    try {
      rows = await _sb
          .from('partners')
          .select()
          // Ignore capitals: 'Grocery' and 'grocery' are the same store type.
          .ilike('category', category)
          .eq('is_active', true)
          .order('is_open', ascending: false)
          .order('rating',   ascending: false)
          .order('total_orders', ascending: false)
          .limit(limit)
          .timeout(const Duration(seconds: 20));
    } on PostgrestException catch (e) {
      // A sort column missing in this database: load without sorting
      // rather than showing "could not load".
      debugPrint('fetchPartners sorted query failed, retrying plain: $e');
      rows = await _sb
          .from('partners')
          .select()
          .ilike('category', category)
          .limit(limit)
          .timeout(const Duration(seconds: 20));
      rows = rows.where((r) => r['is_active'] != false).toList();
    }
    final list = <Partner>[];
    for (final r in rows) {
      try {
        list.add(Partner.fromMap(Map<String, dynamic>.from(r as Map)));
      } catch (e) {
        debugPrint('skipping a store that could not be read: $e');
      }
    }
    list.sort((a, b) => (b.isOpen ? 1 : 0).compareTo(a.isOpen ? 1 : 0));
    final nearby = await _onlyNearby(list);
    // Paid sponsored stores that are open go first; the rest keep their order.
    final top = nearby.where((p) => p.isSponsored && p.isOpen).toList();
    final rest = nearby.where((p) => !(p.isSponsored && p.isOpen)).toList();
    return [...top, ...rest];
  }

  /// Only stores around the customer: within the distance the admin set
  /// for this country (15 km by default), nearest first. Without a
  /// location the full list is shown rather than an empty screen.
  Future<List<Partner>> _onlyNearby(List<Partner> all) async {
    Position? pos;
    try {
      pos = await Geolocator.getLastKnownPosition();
      pos ??= await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.medium,
        timeLimit: const Duration(seconds: 6),
      );
    } catch (_) {}
    if (pos == null) return all;
    double km(double aLat, double aLng, double bLat, double bLng) {
      const r = 6371.0;
      final dLat = (bLat - aLat) * math.pi / 180;
      final dLng = (bLng - aLng) * math.pi / 180;
      final h = math.sin(dLat / 2) * math.sin(dLat / 2) +
          math.cos(aLat * math.pi / 180) *
              math.cos(bLat * math.pi / 180) *
              math.sin(dLng / 2) *
              math.sin(dLng / 2);
      return 2 * r * math.asin(math.sqrt(h));
    }

    var radius = PricingService.last.serviceRadiusKm;
    if (radius <= 0) radius = 15;
    final scored = <MapEntry<Partner, double>>[];
    for (final p in all) {
      if (p.lat == null || p.lng == null) {
        // No pin set yet: can't tell where it is, so keep it last.
        scored.add(MapEntry(p, 9999));
        continue;
      }
      final d = km(pos.latitude, pos.longitude, p.lat!, p.lng!);
      if (d <= radius) scored.add(MapEntry(p, d));
    }
    scored.sort((a, b) {
      final open = (b.key.isOpen ? 1 : 0).compareTo(a.key.isOpen ? 1 : 0);
      return open != 0 ? open : a.value.compareTo(b.value);
    });
    return [for (final e in scored) e.key];
  }

  /// Ids of stores that sell something matching [text] (product name).
  Future<Set<String>> storeIdsSellingProduct(String text) async {
    final q = ilikeSafe(text);
    if (q.length < 2) return {};
    try {
      final rows = await _sb
          .from('products')
          .select('partner_id')
          .eq('is_available', true)
          .ilike('name', '%$q%')
          .limit(300)
          .timeout(const Duration(seconds: 10));
      return {for (final r in rows as List) r['partner_id'].toString()};
    } catch (e) {
      debugPrint('storeIdsSellingProduct failed: $e');
      return {};
    }
  }

  /// Search every kind of store near the customer by store name, address,
  /// description or a product it sells.
  Future<List<Partner>> searchPartners(String text) async {
    final q = ilikeSafe(text);
    if (q.length < 2) return const [];
    try {
      final byName = await _sb
          .from('partners')
          .select()
          .eq('is_active', true)
          .ilike('name', '%$q%')
          .limit(60)
          .timeout(const Duration(seconds: 10));
      final ids = await storeIdsSellingProduct(text);
      final byProduct = ids.isEmpty
          ? <dynamic>[]
          : await _sb
              .from('partners')
              .select()
              .eq('is_active', true)
              .inFilter('id', ids.take(60).toList())
              .timeout(const Duration(seconds: 10));
      final seen = <String>{};
      final list = <Partner>[];
      for (final r in [...(byName as List), ...byProduct]) {
        try {
          final p = Partner.fromMap(Map<String, dynamic>.from(r as Map));
          if (seen.add(p.id)) list.add(p);
        } catch (_) {}
      }
      return _onlyNearby(list);
    } catch (e) {
      debugPrint('searchPartners failed: $e');
      return const [];
    }
  }

  Future<Partner?> fetchPartner(String partnerId) async {
    try {
      final row = await _sb
          .from('partners')
          .select()
          .eq('id', partnerId)
          .maybeSingle();
      return row == null ? null : Partner.fromMap(Map<String, dynamic>.from(row));
    } catch (e) {
      debugPrint('OrderService.fetchPartner failed: $e');
      return null;
    }
  }

  // ════════════════════════════════════════════════════════════
  // PRODUCTS
  // ════════════════════════════════════════════════════════════

  Future<List<Product>> fetchProducts(String partnerId) async {
    try {
      final rows = await _sb
          .from('products')
          .select()
          .eq('partner_id', partnerId)
          .eq('is_available', true)
          .order('display_order', ascending: true)
          .order('is_featured',   ascending: false)
          .order('name',          ascending: true)
          .timeout(const Duration(seconds: 15));

      return (rows as List)
          .map((r) => Product.fromMap(Map<String, dynamic>.from(r)))
          .toList();
    } catch (e) {
      debugPrint('OrderService.fetchProducts failed: $e');
      rethrow;
    }
  }

  // ════════════════════════════════════════════════════════════
  // ORDER CREATION
  // ════════════════════════════════════════════════════════════

  /// Insert an order + its line items and return the new order id.
  ///
  /// Does NOT touch wallet balance — the caller is expected to do
  /// that via [chargeWallet] after this succeeds.
  Future<String> createOrder({
    required String customerId,
    required Partner partner,
    required String serviceType,   // 'Food' | 'Grocery' | 'Pharmacy'
    required List<CartLine> lines,
    required String paymentMethod, // 'wallet' | 'momo' | 'airtel' | 'cash'
    double serviceFee = 0.0,
    double discountAmount = 0.0,
    String? promoCode,
    bool contactless = false,
    bool substitutionsAllowed = true,
    String? deliveryAddress,
    double? deliveryLat,
    double? deliveryLng,
    String? deliveryNote,
    String? recipientName,
    String? recipientPhone,
    bool requiresPrescription = false,
    String? prescriptionUrl,
  }) async {
    if (lines.isEmpty) {
      throw StateError('Cannot create order with empty cart');
    }

    final subtotal = lines.fold<double>(0, (s, l) => s + l.lineTotal);
    final total = (subtotal + serviceFee + partner.deliveryFee - discountAmount)
        .clamp(0, double.infinity);

    // 1. Insert order header
    final orderRow = await _sb
        .from('orders')
        .insert({
          'customer_id':           customerId,
          'partner_id':            partner.id,
          'service_type':          serviceType,
          'status':                'pending',
          'subtotal':              subtotal,
          'service_fee':           serviceFee,
          'delivery_fee':          partner.deliveryFee,
          'discount_amount':       discountAmount,
          'total':                 total,
          'promo_code':            promoCode,
          'payment_method':        paymentMethod,
          'payment_status':        paymentMethod == 'cash'
                                       ? 'pending'
                                       : 'pending', // 'paid' set after charge
          'contactless':           contactless,
          'substitutions_allowed': substitutionsAllowed,
          'delivery_address':      deliveryAddress,
          'delivery_lat':          deliveryLat,
          'delivery_lng':          deliveryLng,
          'delivery_note':         deliveryNote,
          'recipient_name':        recipientName,
          'recipient_phone':       recipientPhone,
          'requires_prescription': requiresPrescription,
          'prescription_url':      prescriptionUrl,
        })
        .select('id')
        .single()
        .timeout(const Duration(seconds: 20));

    final orderId = orderRow['id'].toString();

    // 2. Insert line items
    final itemsPayload = [
      for (final l in lines)
        {
          'order_id':    orderId,
          'product_id':  l.productId,
          'name':        l.name,
          'description': l.description,
          'emoji':       l.emoji,
          'qty':         l.qty,
          'unit_price':  l.unitPrice,
          'line_total':  l.lineTotal,
        },
    ];

    await _sb
        .from('order_items')
        .insert(itemsPayload)
        .timeout(const Duration(seconds: 20));

    return orderId;
  }

  /// Deduct from wallet + write a wallet_transactions row.
  /// The DB trigger `wallet_tx_sync` updates profiles.wallet_balance.
  Future<void> chargeWallet({
    required String userId,
    required double amount,
    required String reference,   // 'order:<orderId>'
  }) async {
    if (amount <= 0) return;

    await _sb.from('wallet_transactions').insert({
      'user_id':   userId,
      'type':      'debit',
      'amount':    -amount,       // negative = debit
      'reference': reference,
      'method':    'wallet',
      'status':    'completed',
      'notes':     'Order payment',
    }).timeout(const Duration(seconds: 15));
  }

  /// Pay an order from the wallet. The server takes exactly the order
  /// total it worked out, once, and marks the order paid.
  /// Throws (insufficient_balance) when the wallet doesn't cover it.
  Future<void> payFromWallet(String orderId) async {
    await _sb.rpc('pay_order_from_wallet', params: {'p_order': orderId})
        .timeout(const Duration(seconds: 20));
  }

  /// Kept for older callers: payment now goes through [payFromWallet].
  @Deprecated('Use payFromWallet')
  Future<void> markOrderPaid(String orderId) => payFromWallet(orderId);

  Future<void> cancelOrder({
    required String orderId,
    required String reason,
    required String cancelledBy,  // 'customer' | 'merchant' | 'system'
  }) async {
    await _sb.from('orders').update({
      'status':              'cancelled',
      'cancellation_reason': reason,
      'cancelled_by':        cancelledBy,
      'cancelled_at':        DateTime.now().toUtc().toIso8601String(),
    }).eq('id', orderId).timeout(const Duration(seconds: 15));
  }

  // ════════════════════════════════════════════════════════════
  // READS
  // ════════════════════════════════════════════════════════════

  Future<Order?> fetchOrder(String orderId) async {
    try {
      final row = await _sb
          .from('orders')
          .select()
          .eq('id', orderId)
          .maybeSingle();
      if (row == null) return null;

      final itemRows = await _sb
          .from('order_items')
          .select()
          .eq('order_id', orderId)
          .order('created_at', ascending: true);

      final lines = (itemRows as List)
          .map((r) => OrderLine.fromMap(Map<String, dynamic>.from(r)))
          .toList();

      return Order.fromMap(Map<String, dynamic>.from(row), lines: lines);
    } catch (e) {
      debugPrint('OrderService.fetchOrder failed: $e');
      return null;
    }
  }

  /// Realtime stream of a single order (with lines hydrated on each tick).
  Stream<Order?> streamOrder(String orderId) {
    return _sb
        .from('orders')
        .stream(primaryKey: ['id'])
        .eq('id', orderId)
        .asyncMap((rows) async {
      if (rows.isEmpty) return null;
      final row = Map<String, dynamic>.from(rows.first);

      try {
        final itemRows = await _sb
            .from('order_items')
            .select()
            .eq('order_id', orderId)
            .order('created_at', ascending: true);
        final lines = (itemRows as List)
            .map((r) => OrderLine.fromMap(Map<String, dynamic>.from(r)))
            .toList();
        return Order.fromMap(row, lines: lines);
      } catch (_) {
        return Order.fromMap(row);
      }
    });
  }

  static const _doneStatuses = {
    'delivered', 'cancelled', 'refunded', 'returned', 'returning', 'completed'
  };
  static const _pastStatuses = {'delivered', 'cancelled', 'refunded', 'returned'};

  // One query for both lists. The status is checked here, not in the
  // database filter, so a status the database does not know (an enum
  // without 'refunded', say) can no longer make the whole request fail.
  Future<List<Map<String, dynamic>>> _fetchCustomerRows(
      String customerId, int limit) async {
    final rows = await _sb
        .from('orders')
        .select()
        .eq('customer_id', customerId)
        .order('created_at', ascending: false)
        .limit(limit)
        .timeout(const Duration(seconds: 15));
    return (rows as List).map((r) => Map<String, dynamic>.from(r)).toList();
  }

  /// Active orders for the current customer.
  Future<List<Order>> fetchActiveOrders(String customerId) async {
    final rows = await _fetchCustomerRows(customerId, 200);
    return rows
        .where((m) => !_doneStatuses.contains(
            (m['status'] ?? '').toString().toLowerCase()))
        .map((m) => Order.fromMap(m))
        .toList();
  }

  /// Completed orders for the current customer.
  Future<List<Order>> fetchOrderHistory(
    String customerId, {
    int limit = 50,
  }) async {
    final rows = await _fetchCustomerRows(customerId, 200);
    return rows
        .where((m) => _pastStatuses.contains(
            (m['status'] ?? '').toString().toLowerCase()))
        .take(limit)
        .map((m) => Order.fromMap(m))
        .toList();
  }
}
