import 'dart:async';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:efuride_app/utils/log.dart';

class RideWatchdogService {
  RideWatchdogService._();
  static final RideWatchdogService instance = RideWatchdogService._();
  static const _tag = 'RideWatchdog';

  Timer? _timer;
  bool _isRunning = false;

  static const Duration _pendingTimeout = Duration(minutes: 5);
  static const Duration _pollEvery = Duration(seconds: 30);

  void start() {
    if (_isRunning) return;
    _isRunning = true;
    _timer?.cancel();
    _timer = Timer.periodic(_pollEvery, (_) => _sweep());
    _sweep();
    Log.i(_tag, 'started');
  }

  void stop() {
    _timer?.cancel();
    _timer = null;
    _isRunning = false;
    Log.i(_tag, 'stopped');
  }

  /// Registers a ride to be swept. The sweep runs on its next tick.
  /// (Kept async for backwards compat with call sites.)
  Future<void> watchForTimeout(String rideId) async {
    // Fast-path: check once, ~30s later, then let the periodic sweep handle
    // it if still pending.
    await Future.delayed(const Duration(seconds: 30));
    await _maybeCancel(rideId);
  }

  // ============================================================
  // INTERNALS
  // ============================================================
  Future<void> _sweep() async {
    final user = Supabase.instance.client.auth.currentUser;
    if (user == null) return;

    try {
      final cutoff = DateTime.now()
          .toUtc()
          .subtract(_pendingTimeout)
          .toIso8601String();

      // Shop deliveries (order_id) wait in the drivers' pile until
      // someone takes them, so they are never timed out here.
      final rows = await Supabase.instance.client
          .from('rides')
          .select('id')
          .eq('customer_id', user.id)
          .eq('status', 'pending')
          .filter('order_id', 'is', null)
          .lt('created_at', cutoff);

      for (final row in rows) {
        final id = row['id']?.toString();
        if (id != null) {
          await _maybeCancel(id);
        }
      }
    } catch (e) {
      Log.e(_tag, 'sweep failed', e);
    }
  }

  Future<void> _maybeCancel(String rideId) async {
    try {
      // Re-check status (race safety — a driver might have just accepted).
      final current = await Supabase.instance.client
          .from('rides')
          .select('status, created_at, dispatched_at, order_id, bid_status')
          .eq('id', rideId)
          .maybeSingle();

      if (current == null) return;
      if ((current['status'] ?? '').toString() != 'pending') return;
      if (current['order_id'] != null) return;
      // The customer is looking at a driver's price: let them answer.
      if (current['bid_status'] == 'countered') return;

      // Count from the latest send-out (scheduled rides, released trips).
      final created = DateTime.tryParse(
          (current['dispatched_at'] ?? current['created_at'])?.toString() ??
              '');
      if (created == null) return;
      if (DateTime.now().toUtc().difference(created.toUtc()) < _pendingTimeout) {
        return;
      }

      await Supabase.instance.client.from('rides').update({
        'status': 'cancelled',
        'cancelled_by': 'system',
        'cancellation_reason': 'No driver accepted within 5 minutes',
        'cancelled_at': DateTime.now().toUtc().toIso8601String(),
      }).eq('id', rideId).eq('status', 'pending');

      Log.i(_tag, 'cancelled stale ride $rideId');
    } catch (e) {
      Log.e(_tag, 'cancel failed for $rideId', e);
    }
  }
}
