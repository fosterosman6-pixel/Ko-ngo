// lib/services/shopper_service.dart
//
// All shopper-side queries + realtime subscriptions.
// Matches the schema created in Phases 1–2C.

import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

// ============================================================
// MODELS
// ============================================================

class ShopperTask {
  final String id;
  final String orderId;
  final String? shopperId;
  final String? hubId;
  final String storeName;
  final String status;
  final int itemCount;
  final int itemsPicked;
  final double estimatedTotal;
  final double actualTotal;
  final String? receiptUrl;
  final String? packageQr;
  final DateTime? assignedAt;
  final DateTime? acceptedAt;
  final DateTime? startedAt;
  final DateTime? packedAt;
  final DateTime? completedAt;

  ShopperTask({
    required this.id,
    required this.orderId,
    this.shopperId,
    this.hubId,
    required this.storeName,
    required this.status,
    required this.itemCount,
    required this.itemsPicked,
    required this.estimatedTotal,
    required this.actualTotal,
    this.receiptUrl,
    this.packageQr,
    this.assignedAt,
    this.acceptedAt,
    this.startedAt,
    this.packedAt,
    this.completedAt,
  });

  factory ShopperTask.fromMap(Map<String, dynamic> m) => ShopperTask(
        id: m['id'] as String,
        orderId: m['order_id'] as String,
        shopperId: m['shopper_id'] as String?,
        hubId: m['hub_id'] as String?,
        storeName: (m['store_name'] ?? '').toString(),
        status: (m['status'] ?? 'assigned').toString(),
        itemCount: (m['item_count'] as num?)?.toInt() ?? 0,
        itemsPicked: (m['items_picked'] as num?)?.toInt() ?? 0,
        estimatedTotal: (m['estimated_total'] as num?)?.toDouble() ?? 0,
        actualTotal: (m['actual_total'] as num?)?.toDouble() ?? 0,
        receiptUrl: m['receipt_url'] as String?,
        packageQr: m['package_qr'] as String?,
        assignedAt: _parseDate(m['assigned_at']),
        acceptedAt: _parseDate(m['accepted_at']),
        startedAt: _parseDate(m['started_at']),
        packedAt: _parseDate(m['packed_at']),
        completedAt: _parseDate(m['completed_at']),
      );

  double get progress => itemCount == 0 ? 0 : itemsPicked / itemCount;

  /// Still being worked on. Note: `packed` is NOT active — that task
  /// has been handed off and is awaiting driver pickup. See [isPacked].
  bool get isActive =>
      status == 'assigned' ||
      status == 'accepted' ||
      status == 'in_progress' ||
      status == 'substitution_pending';

  /// Package sealed + QR generated, waiting on the driver.
  bool get isPacked => status == 'packed';

  bool get isDone => status == 'completed';
}

/// An order no shopper has taken yet (shown in the shopper's pool).
class OpenOrder {
  final String id;
  final String serviceType;
  final String storeName;
  final String storeAddress;
  final double? storeLat;
  final double? storeLng;
  final String deliveryAddress;
  final int itemCount;
  final double subtotal;
  final DateTime? createdAt;

  const OpenOrder({
    required this.id,
    required this.serviceType,
    required this.storeName,
    required this.storeAddress,
    this.storeLat,
    this.storeLng,
    required this.deliveryAddress,
    required this.itemCount,
    required this.subtotal,
    this.createdAt,
  });

  factory OpenOrder.fromMap(Map<String, dynamic> m) => OpenOrder(
        id: m['id'].toString(),
        serviceType: (m['service_type'] ?? 'Food').toString(),
        storeName: (m['store_name'] ?? '').toString(),
        storeAddress: (m['store_address'] ?? '').toString(),
        storeLat: (m['store_lat'] as num?)?.toDouble(),
        storeLng: (m['store_lng'] as num?)?.toDouble(),
        deliveryAddress: (m['delivery_address'] ?? '').toString(),
        itemCount: (m['item_count'] as num?)?.toInt() ?? 0,
        subtotal: (m['subtotal'] as num?)?.toDouble() ?? 0,
        createdAt: m['created_at'] == null
            ? null
            : DateTime.tryParse(m['created_at'].toString())?.toLocal(),
      );
}

/// Store location for navigating the shopper to the shop.
class StoreLocation {
  final String name;
  final String address;
  final double? lat;
  final double? lng;
  const StoreLocation(
      {required this.name, required this.address, this.lat, this.lng});
}

class Substitution {
  final String id;
  final String taskId;
  final String orderItemId;
  final String originalName;
  final double originalPrice;
  final String proposedName;
  final double proposedPrice;
  final String? proposedEmoji;
  final String? photoUrl;
  final double priceDelta;
  final String status;
  final DateTime expiresAt;
  final DateTime? respondedAt;

  Substitution({
    required this.id,
    required this.taskId,
    required this.orderItemId,
    required this.originalName,
    required this.originalPrice,
    required this.proposedName,
    required this.proposedPrice,
    this.proposedEmoji,
    this.photoUrl,
    required this.priceDelta,
    required this.status,
    required this.expiresAt,
    this.respondedAt,
  });

  factory Substitution.fromMap(Map<String, dynamic> m) => Substitution(
        id: m['id'] as String,
        taskId: m['task_id'] as String,
        orderItemId: m['order_item_id'] as String,
        originalName: (m['original_name'] ?? '').toString(),
        originalPrice: (m['original_price'] as num?)?.toDouble() ?? 0,
        proposedName: (m['proposed_name'] ?? '').toString(),
        proposedPrice: (m['proposed_price'] as num?)?.toDouble() ?? 0,
        proposedEmoji: m['proposed_emoji'] as String?,
        photoUrl: m['photo_url'] as String?,
        priceDelta: (m['price_delta'] as num?)?.toDouble() ?? 0,
        status: (m['status'] ?? 'pending').toString(),
        expiresAt: _parseDate(m['expires_at']) ?? DateTime.now(),
        respondedAt: _parseDate(m['responded_at']),
      );

  int get secondsLeft =>
      expiresAt.difference(DateTime.now()).inSeconds.clamp(0, 999);
}

class ShopperPayout {
  final String id;
  final DateTime periodStart;
  final DateTime periodEnd;
  final int minutesOnline;
  final int tasksCompleted;
  final double basePay;
  final double qualityBonus;
  final double adjustments;
  final double netPayout;
  final String status;
  final String? reference;
  final DateTime? paidAt;

  ShopperPayout({
    required this.id,
    required this.periodStart,
    required this.periodEnd,
    required this.minutesOnline,
    required this.tasksCompleted,
    required this.basePay,
    required this.qualityBonus,
    required this.adjustments,
    required this.netPayout,
    required this.status,
    this.reference,
    this.paidAt,
  });

  factory ShopperPayout.fromMap(Map<String, dynamic> m) => ShopperPayout(
        id: m['id'] as String,
        periodStart: _parseDate(m['period_start']) ?? DateTime.now(),
        periodEnd: _parseDate(m['period_end']) ?? DateTime.now(),
        minutesOnline: (m['minutes_online'] as num?)?.toInt() ?? 0,
        tasksCompleted: (m['tasks_completed'] as num?)?.toInt() ?? 0,
        basePay: (m['base_pay'] as num?)?.toDouble() ?? 0,
        qualityBonus: (m['quality_bonus'] as num?)?.toDouble() ?? 0,
        adjustments: (m['adjustments'] as num?)?.toDouble() ?? 0,
        netPayout: (m['net_payout'] as num?)?.toDouble() ?? 0,
        status: (m['status'] ?? 'pending').toString(),
        reference: m['reference'] as String?,
        paidAt: _parseDate(m['paid_at']),
      );
}

class ShopperStats {
  final int tasksToday;
  final int tasksThisWeek;
  final double hoursThisWeek;
  final double rating;
  final double qualityBonusThisWeek;

  const ShopperStats({
    required this.tasksToday,
    required this.tasksThisWeek,
    required this.hoursThisWeek,
    required this.rating,
    required this.qualityBonusThisWeek,
  });
}

DateTime? _parseDate(dynamic d) =>
    d == null ? null : DateTime.tryParse(d.toString())?.toLocal();

// ============================================================
// SERVICE
// ============================================================

class ShopperService {
  ShopperService._();
  static final ShopperService instance = ShopperService._();

  SupabaseClient get _sb => Supabase.instance.client;
  String? get _uid => _sb.auth.currentUser?.id;

  // ------------------------------------------------------------
  // PROFILE / GREETING
  // ------------------------------------------------------------

  /// Returns the shopper's display first name for the home header.
  /// Falls back to the first word of `full_name`, then null.
  Future<String?> loadProfileFirstName() async {
    final uid = _uid;
    if (uid == null) return null;
    try {
      final row = await _sb
          .from('profiles')
          .select('first_name, full_name')
          .eq('id', uid)
          .maybeSingle();
      if (row == null) return null;

      final first = (row['first_name'] ?? '').toString().trim();
      if (first.isNotEmpty) return first;

      final full = (row['full_name'] ?? '').toString().trim();
      if (full.isEmpty) return null;
      return full.split(' ').first;
    } catch (e) {
      debugPrint('loadProfileFirstName failed: $e');
      return null;
    }
  }

  // ------------------------------------------------------------
  // ONLINE STATE
  //
  // Shoppers share `profiles.is_online` with drivers. The home screen
  // reads it on mount and toggles it via the pill in the header.
  // ------------------------------------------------------------

  /// Reads the current user's `is_online` flag from their profile.
  /// Returns false on any error (never throws) so the UI can render.
  Future<bool> loadOnline() async {
    final uid = _uid;
    if (uid == null) return false;
    try {
      final row = await _sb
          .from('profiles')
          .select('is_online')
          .eq('id', uid)
          .maybeSingle();
      return row?['is_online'] == true;
    } catch (e) {
      debugPrint('loadOnline failed: $e');
      return false;
    }
  }

  /// Writes the `is_online` flag on the current user's profile.
  Future<void> setOnline(bool value) async {
    final uid = _uid;
    if (uid == null) throw Exception('Not signed in');
    await _sb.from('profiles').update({
      'is_online': value,
    }).eq('id', uid);
  }

  // ------------------------------------------------------------
  // TASKS
  // ------------------------------------------------------------

  // ------------------------------------------------------------
  // OPEN ORDERS (pool) → CLAIM → DELIVERY REQUEST
  // ------------------------------------------------------------

  /// Orders waiting for a shopper. Server function so shoppers only see
  /// what they need (store + drop-off area), not customer details.
  Future<List<OpenOrder>> loadOpenOrders() async {
    final rows = await _sb
        .rpc('list_open_orders')
        .timeout(const Duration(seconds: 15));
    return ((rows as List?) ?? const [])
        .map((r) => OpenOrder.fromMap(Map<String, dynamic>.from(r as Map)))
        .toList();
  }

  /// Fires when one of this shopper's orders changes. Shoppers can't read
  /// other people's unassigned orders directly (privacy), so the pool is
  /// also refreshed on a timer by the screen.
  RealtimeChannel watchOpenOrders(void Function() onChange) {
    return _sb
        .channel('open_orders_${DateTime.now().millisecondsSinceEpoch}')
        .onPostgresChanges(
          event: PostgresChangeEvent.all,
          schema: 'public',
          table: 'orders',
          callback: (_) => onChange(),
        )
        .subscribe();
  }

  /// Take an order. Atomic on the server: fails if another shopper got
  /// it first. Returns the new shopping task id.
  Future<String> claimOrder(String orderId) async {
    final res = await _sb.rpc('claim_order', params: {'p_order_id': orderId});
    final id = res?.toString() ?? '';
    if (id.isEmpty) throw Exception('Order already taken');
    return id;
  }

  /// After sealing: ask for a driver. Creates the delivery job (from the
  /// store to the customer) and returns {ride_id, pickup_otp}.
  /// [lat]/[lng] = shopper's position, used as the pickup point only if
  /// the store has no map position yet.
  Future<Map<String, dynamic>> requestDelivery(
    String orderId, {
    double? lat,
    double? lng,
  }) async {
    final res = await _sb.rpc('request_order_delivery', params: {
      'p_order_id': orderId,
      'p_pickup_lat': lat,
      'p_pickup_lng': lng,
    });
    final list = res is List ? res : [res];
    if (list.isEmpty || list.first == null) {
      throw Exception('Delivery request failed');
    }
    return Map<String, dynamic>.from(list.first as Map);
  }

  /// Live delivery job for an order (driver, status, pickup code).
  Stream<Map<String, dynamic>?> streamDeliveryForOrder(String orderId) {
    return _sb
        .from('rides')
        .stream(primaryKey: ['id'])
        .eq('order_id', orderId)
        .order('created_at', ascending: false)
        .map((rows) => rows.isEmpty
            ? null
            : Map<String, dynamic>.from(rows.first));
  }

  /// Where the shop is, for "Go to store".
  Future<StoreLocation?> loadStoreForOrder(String orderId) async {
    final o = await _sb
        .from('orders')
        .select('partner_id')
        .eq('id', orderId)
        .maybeSingle();
    final pid = o?['partner_id'];
    if (pid == null) return null;
    final p = await _sb
        .from('partners')
        .select('name, address, lat, lng')
        .eq('id', pid)
        .maybeSingle();
    if (p == null) return null;
    return StoreLocation(
      name: (p['name'] ?? '').toString(),
      address: (p['address'] ?? '').toString(),
      lat: (p['lat'] as num?)?.toDouble(),
      lng: (p['lng'] as num?)?.toDouble(),
    );
  }

  /// Fetch active tasks for the current shopper.
  Future<List<ShopperTask>> loadActiveTasks() async {
    final uid = _uid;
    if (uid == null) throw Exception('Not signed in');

    final rows = await _sb
        .from('shopping_tasks')
        .select()
        .eq('shopper_id', uid)
        .inFilter(
            'status',
            ['assigned', 'accepted', 'in_progress', 'substitution_pending'])
        .order('assigned_at', ascending: false)
        .timeout(const Duration(seconds: 15));

    return (rows as List)
        .map((r) => ShopperTask.fromMap(Map<String, dynamic>.from(r)))
        .toList();
  }

  /// Fetch completed tasks history.
  Future<List<ShopperTask>> loadCompletedTasks({int limit = 50}) async {
    final uid = _uid;
    if (uid == null) throw Exception('Not signed in');

    final rows = await _sb
        .from('shopping_tasks')
        .select()
        .eq('shopper_id', uid)
        .eq('status', 'completed')
        .order('completed_at', ascending: false)
        .limit(limit)
        .timeout(const Duration(seconds: 15));

    return (rows as List)
        .map((r) => ShopperTask.fromMap(Map<String, dynamic>.from(r)))
        .toList();
  }

  /// Load a single task by id.
  Future<ShopperTask?> loadTask(String taskId) async {
    final row = await _sb
        .from('shopping_tasks')
        .select()
        .eq('id', taskId)
        .maybeSingle();
    if (row == null) return null;
    return ShopperTask.fromMap(Map<String, dynamic>.from(row));
  }

  /// Load order items for a given task's order.
  Future<List<Map<String, dynamic>>> loadOrderItems(String orderId) async {
    final rows = await _sb
        .from('order_items')
        .select()
        .eq('order_id', orderId)
        .order('created_at', ascending: true);
    return List<Map<String, dynamic>>.from(rows);
  }

  /// Accept an assigned task.
  Future<void> acceptTask(String taskId) async {
    final uid = _uid;
    if (uid == null) throw Exception('Not signed in');

    await _sb.from('shopping_tasks').update({
      'status': 'accepted',
      'shopper_id': uid,
      'accepted_at': DateTime.now().toUtc().toIso8601String(),
    }).eq('id', taskId);

    // Sync to order
    final task = await loadTask(taskId);
    if (task != null) {
      await _sb.from('orders').update({
        'shopper_id': uid,
        'status': 'shopping',
      }).eq('id', task.orderId);
    }
  }

  /// Decline / cancel a task.
  Future<void> declineTask(String taskId, {String? reason}) async {
    await _sb.from('shopping_tasks').update({
      'status': 'cancelled',
      'cancellation_reason': reason ?? 'Declined by shopper',
    }).eq('id', taskId);
  }

  /// Begin shopping — moves task to in_progress.
  Future<void> startShopping(String taskId) async {
    await _sb.from('shopping_tasks').update({
      'status': 'in_progress',
      'started_at': DateTime.now().toUtc().toIso8601String(),
    }).eq('id', taskId);
  }

  /// Mark an item as picked. Increments items_picked.
  Future<void> markItemPicked({
    required String taskId,
    required String orderItemId,
    required double actualPrice,
    double? weightKg,
    String? notes,
  }) async {
    await _sb.from('order_items').update({
      'actual_price': actualPrice,
      if (weightKg != null) 'weight_kg': weightKg,
      if (notes != null) 'notes': notes,
    }).eq('id', orderItemId);

    // Bump task counter
    final task = await loadTask(taskId);
    if (task != null) {
      await _sb.from('shopping_tasks').update({
        'items_picked': task.itemsPicked + 1,
      }).eq('id', taskId);
    }
  }

  /// Reverses a pick — clears actual_price / weight / notes and
  /// decrements the task's picked counter.
  Future<void> markItemUnpicked({
    required String taskId,
    required String orderItemId,
  }) async {
    await _sb.from('order_items').update({
      'actual_price': null,
      'weight_kg': null,
      'notes': null,
    }).eq('id', orderItemId);

    final task = await loadTask(taskId);
    if (task != null) {
      final next = (task.itemsPicked - 1).clamp(0, 9999);
      await _sb.from('shopping_tasks').update({
        'items_picked': next,
      }).eq('id', taskId);
    }
  }

  // ------------------------------------------------------------
  // SUBSTITUTIONS
  // ------------------------------------------------------------

  /// Propose a substitution. Auto-expires in 2 minutes.
  Future<Substitution> proposeSubstitution({
    required String taskId,
    required String orderItemId,
    required String originalName,
    required double originalPrice,
    required String proposedName,
    required double proposedPrice,
    String? proposedEmoji,
    String? photoUrl,
  }) async {
    final row = await _sb.from('substitutions').insert({
      'task_id': taskId,
      'order_item_id': orderItemId,
      'original_name': originalName,
      'original_price': originalPrice,
      'proposed_name': proposedName,
      'proposed_price': proposedPrice,
      if (proposedEmoji != null) 'proposed_emoji': proposedEmoji,
      if (photoUrl != null) 'photo_url': photoUrl,
      'status': 'pending',
      'expires_at': DateTime.now()
          .add(const Duration(minutes: 2))
          .toUtc()
          .toIso8601String(),
    }).select().single();

    // Move task status while awaiting customer response
    await _sb.from('shopping_tasks').update({
      'status': 'substitution_pending',
    }).eq('id', taskId);

    return Substitution.fromMap(Map<String, dynamic>.from(row));
  }

  /// Watch a substitution for customer's decision (or timeout).
  Stream<Substitution> watchSubstitution(String substitutionId) {
    return _sb
        .from('substitutions')
        .stream(primaryKey: ['id'])
        .eq('id', substitutionId)
        .map((rows) {
      if (rows.isEmpty) throw Exception('Substitution not found');
      return Substitution.fromMap(Map<String, dynamic>.from(rows.first));
    });
  }

  // ------------------------------------------------------------
  // PACKAGING
  // ------------------------------------------------------------

  /// Capture receipt URL + finalize task totals.
  Future<void> attachReceipt({
    required String taskId,
    required String receiptUrl,
    required double actualTotal,
  }) async {
    await _sb.from('shopping_tasks').update({
      'receipt_url': receiptUrl,
      'actual_total': actualTotal,
    }).eq('id', taskId);

    // Record what was actually paid at the store. The order's total is
    // settled on the server (fees + any difference vs the estimate).
    final task = await loadTask(taskId);
    if (task != null) {
      await _sb.from('orders').update({
        'actual_subtotal': actualTotal,
      }).eq('id', task.orderId);
    }
  }

  /// Seal the package — creates packages row (QR auto-generated by trigger).
  Future<String> sealPackage({
    required String taskId,
    required String orderId,
    String? notes,
  }) async {
    final uid = _uid;
    if (uid == null) throw Exception('Not signed in');

    final row = await _sb.from('packages').insert({
      'order_id': orderId,
      'sealed_by': uid,
      'sealed_at': DateTime.now().toUtc().toIso8601String(),
      'status': 'sealed',
      if (notes != null) 'notes': notes,
    }).select().single();

    final qr = (row['qr_code'] ?? '').toString();

    // Update task + order
    await _sb.from('shopping_tasks').update({
      'status': 'packed',
      'package_qr': qr,
      'packed_at': DateTime.now().toUtc().toIso8601String(),
    }).eq('id', taskId);

    await _sb.from('orders').update({
      'status': 'ready',
      'ready_at': DateTime.now().toUtc().toIso8601String(),
    }).eq('id', orderId);

    return qr;
  }

  // ------------------------------------------------------------
  // EARNINGS + STATS
  // ------------------------------------------------------------

  Future<List<ShopperPayout>> loadPayouts({int limit = 20}) async {
    final uid = _uid;
    if (uid == null) throw Exception('Not signed in');

    final rows = await _sb
        .from('shopper_payouts')
        .select()
        .eq('shopper_id', uid)
        .order('period_start', ascending: false)
        .limit(limit);

    return (rows as List)
        .map((r) => ShopperPayout.fromMap(Map<String, dynamic>.from(r)))
        .toList();
  }

  Future<ShopperStats> loadStats() async {
    final uid = _uid;
    if (uid == null) throw Exception('Not signed in');

    final now = DateTime.now();
    final todayStart = DateTime(now.year, now.month, now.day).toUtc();
    final weekStart =
        todayStart.subtract(Duration(days: now.weekday - 1));

    final tasks = await _sb
        .from('shopping_tasks')
        .select('id, status, completed_at')
        .eq('shopper_id', uid)
        .eq('status', 'completed')
        .gte('completed_at', weekStart.toIso8601String());

    int today = 0;
    int week = 0;
    for (final t in tasks) {
      final when = DateTime.tryParse(t['completed_at']?.toString() ?? '');
      if (when == null) continue;
      week++;
      if (when.isAfter(todayStart)) today++;
    }

    final profile = await _sb
        .from('profiles')
        .select('shopper_rating, shopper_quality_bonus')
        .eq('id', uid)
        .maybeSingle();

    return ShopperStats(
      tasksToday: today,
      tasksThisWeek: week,
      hoursThisWeek: week * 0.75, // placeholder: wire to real tracked minutes
      rating: (profile?['shopper_rating'] as num?)?.toDouble() ?? 5.0,
      qualityBonusThisWeek:
          (profile?['shopper_quality_bonus'] as num?)?.toDouble() ?? 0,
    );
  }

  // ------------------------------------------------------------
  // REALTIME
  // ------------------------------------------------------------

  /// Stream new + updated tasks assigned to this shopper.
  Stream<List<ShopperTask>> streamTasks() {
    final uid = _uid;
    if (uid == null) {
      return const Stream.empty();
    }
    return _sb
        .from('shopping_tasks')
        .stream(primaryKey: ['id'])
        .eq('shopper_id', uid)
        .order('assigned_at')
        .map((rows) => rows
            .map((r) => ShopperTask.fromMap(Map<String, dynamic>.from(r)))
            .toList());
  }

  /// Stream the single active substitution for a task.
  Stream<List<Substitution>> streamSubstitutionsForTask(String taskId) {
    return _sb
        .from('substitutions')
        .stream(primaryKey: ['id'])
        .eq('task_id', taskId)
        .order('created_at')
        .map((rows) => rows
            .map((r) => Substitution.fromMap(Map<String, dynamic>.from(r)))
            .toList());
  }

  // ------------------------------------------------------------
  // STORAGE
  // ------------------------------------------------------------

  /// Upload a receipt photo. Returns the public URL.
  Future<String?> uploadReceipt({
    required String taskId,
    required List<int> bytes,
    required String ext,
  }) async {
    try {
      final path =
          'receipts/$taskId-${DateTime.now().millisecondsSinceEpoch}.$ext';
      await _sb.storage.from('receipts').uploadBinary(
            path,
            Uint8List.fromList(bytes),
            fileOptions: const FileOptions(upsert: true),
          );
      return _sb.storage.from('receipts').getPublicUrl(path);
    } catch (e) {
      debugPrint('uploadReceipt failed: $e');
      return null;
    }
  }

  /// Upload a substitution photo. Returns the public URL.
  Future<String?> uploadSubstitutionPhoto({
    required String substitutionId,
    required List<int> bytes,
    required String ext,
  }) async {
    try {
      final path =
          'substitutions/$substitutionId-${DateTime.now().millisecondsSinceEpoch}.$ext';
      await _sb.storage.from('substitutions').uploadBinary(
            path,
            Uint8List.fromList(bytes),
            fileOptions: const FileOptions(upsert: true),
          );
      return _sb.storage.from('substitutions').getPublicUrl(path);
    } catch (e) {
      debugPrint('uploadSubstitutionPhoto failed: $e');
      return null;
    }
  }
}
