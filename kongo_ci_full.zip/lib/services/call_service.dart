// lib/services/call_service.dart
//
// Voice calls inside the app, between the customer and the driver of a
// trip (WebRTC audio, nothing leaves the app, numbers stay private).
//
//   CallService.instance.attach(rideId, myName: 'Osman');   // trip screen opens
//   CallService.instance.call();                            // 📞 button
//   CallService.instance.detach();                          // trip screen closes
//
// Signalling goes over a Supabase Realtime broadcast channel named after
// the ride. Both people must have the trip open (the usual case during a
// trip); the other side shows an "Incoming call" screen.
//
// Needs the `flutter_webrtc` package and the RECORD_AUDIO permission
// (see CALLS_SETUP.md).

import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter_webrtc/flutter_webrtc.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

enum CallPhase { idle, ringingOut, ringingIn, connecting, connected }

class CallService {
  CallService._();
  static final CallService instance = CallService._();

  final ValueNotifier<CallPhase> phase = ValueNotifier(CallPhase.idle);
  final ValueNotifier<String> otherName = ValueNotifier('');
  final ValueNotifier<bool> muted = ValueNotifier(false);
  final ValueNotifier<bool> speaker = ValueNotifier(false);

  /// Called when someone is calling us (the app opens the call screen).
  void Function()? onIncoming;

  /// Called when a call starts (we dialled) so the app opens the screen.
  void Function()? onOutgoing;

  String? _rideId;
  String _myName = '';
  String get _me => Supabase.instance.client.auth.currentUser?.id ?? '';
  RealtimeChannel? _ch;
  RTCPeerConnection? _pc;
  MediaStream? _local;
  final List<RTCIceCandidate> _pendingIce = [];
  bool _remoteSet = false;
  Timer? _ringTimeout;
  Timer? _connectTimeout;
  Timer? _discTimer;

  /// Why the last call ended, in plain words (empty = normal hang-up).
  /// The call screen shows it once when it closes.
  final ValueNotifier<String> note = ValueNotifier('');

  /// Small status line for the call screen: shows which step the call is
  /// on, so a stuck call can be diagnosed from a screenshot.
  final ValueNotifier<String> step = ValueNotifier('');
  int _locHost = 0, _locSrflx = 0, _locRelay = 0, _remoteCount = 0;
  String _iceKind = '';
  void _log(String m) {
    debugPrint('call: $m');
    step.value = m;
  }

  void _summary() {
    step.value =
        '$_iceKind | mine h$_locHost s$_locSrflx r$_locRelay | theirs $_remoteCount';
  }

  static const _defaultIce = <Map<String, dynamic>>[
    {'urls': 'stun:stun.l.google.com:19302'},
    {'urls': 'stun:stun1.l.google.com:19302'},
  ];

  // ── Trip screen hooks ───────────────────────────────────────────
  Future<void> attach(String rideId, {String myName = ''}) async {
    if (_rideId == rideId && _ch != null) return;
    await detach();
    _rideId = rideId;
    _myName = myName;
    _ch = Supabase.instance.client
        .channel('call_$rideId',
            opts: const RealtimeChannelConfig(self: false))
        .onBroadcast(event: 'invite', callback: (p) => _onInvite(p))
        .onBroadcast(event: 'accept', callback: (p) => _onAccept(p))
        .onBroadcast(event: 'offer', callback: (p) => _onOffer(p))
        .onBroadcast(event: 'answer', callback: (p) => _onAnswer(p))
        .onBroadcast(event: 'ice', callback: (p) => _onIce(p))
        .onBroadcast(event: 'end', callback: (p) => _onEnd(p))
        .subscribe();
  }

  Future<void> detach() async {
    if (phase.value != CallPhase.idle) await hangUp();
    try {
      await _ch?.unsubscribe();
    } catch (_) {}
    _ch = null;
    _rideId = null;
  }

  bool get attached => _ch != null;

  // ── Caller ──────────────────────────────────────────────────────
  Future<void> call({String toName = ''}) async {
    if (_ch == null || phase.value != CallPhase.idle) return;
    otherName.value = toName;
    step.value = '';
    phase.value = CallPhase.ringingOut;
    onOutgoing?.call();
    _send('invite', {'name': _myName});
    _ringTimeout?.cancel();
    _ringTimeout = Timer(const Duration(seconds: 45), () {
      if (phase.value == CallPhase.ringingOut) {
        note.value =
            'No answer. The other person must have the trip open in the app.';
        hangUp();
      }
    });
  }

  // ── Callee ──────────────────────────────────────────────────────
  void _onInvite(Map<String, dynamic> p) {
    if (phase.value != CallPhase.idle) {
      _send('end', {'reason': 'busy'});
      return;
    }
    otherName.value = (p['name'] ?? '').toString();
    phase.value = CallPhase.ringingIn;
    onIncoming?.call();
    _ringTimeout?.cancel();
    _ringTimeout = Timer(const Duration(seconds: 45), () {
      if (phase.value == CallPhase.ringingIn) hangUp();
    });
  }

  void _startConnectTimeout() {
    _connectTimeout?.cancel();
    _connectTimeout = Timer(const Duration(seconds: 25), () {
      if (phase.value == CallPhase.connecting) {
        note.value =
            "Couldn't connect the call. Check that both phones have internet and try again.";
        hangUp();
      }
    });
  }

  Future<void> answer() async {
    if (phase.value != CallPhase.ringingIn) return;
    _ringTimeout?.cancel();
    note.value = '';
    step.value = '';
    phase.value = CallPhase.connecting;
    _startConnectTimeout();
    final ok = await _openPeer();
    if (!ok) {
      note.value =
          "Couldn't start the microphone. Allow microphone access for ko!ngo in your phone settings.";
      await hangUp();
      return;
    }
    _send('accept', {});
  }

  Future<void> decline() async {
    _send('end', {'reason': 'declined'});
    await _cleanup();
  }

  // ── Signalling ──────────────────────────────────────────────────
  Future<void> _onAccept(Map<String, dynamic> p) async {
    if (phase.value != CallPhase.ringingOut) return;
    _ringTimeout?.cancel();
    note.value = '';
    phase.value = CallPhase.connecting;
    _startConnectTimeout();
    if (!await _openPeer()) {
      note.value =
          "Couldn't start the microphone. Allow microphone access for ko!ngo in your phone settings.";
      await hangUp();
      return;
    }
    try {
      _log('making offer');
      final offer = await _pc!.createOffer({'offerToReceiveAudio': 1});
      await _pc!.setLocalDescription(offer);
      _send('offer', {'sdp': offer.sdp, 'type': offer.type});
      _log('offer sent, waiting for answer');
    } catch (e) {
      _log('offer failed: $e');
    }
  }

  Future<void> _onOffer(Map<String, dynamic> p) async {
    // The callee may get the offer a moment before its peer is ready.
    for (var i = 0; i < 40 && _pc == null; i++) {
      await Future.delayed(const Duration(milliseconds: 100));
    }
    if (_pc == null) {
      _log('offer arrived but no peer');
      return;
    }
    try {
      _log('got offer');
      await _pc!.setRemoteDescription(
          RTCSessionDescription(p['sdp']?.toString(), p['type']?.toString()));
      _remoteSet = true;
      await _flushIce();
      final ans = await _pc!.createAnswer({'offerToReceiveAudio': 1});
      await _pc!.setLocalDescription(ans);
      _send('answer', {'sdp': ans.sdp, 'type': ans.type});
      _log('answer sent');
    } catch (e) {
      _log('answer failed: $e');
    }
  }

  Future<void> _onAnswer(Map<String, dynamic> p) async {
    if (_pc == null) return;
    try {
      await _pc!.setRemoteDescription(
          RTCSessionDescription(p['sdp']?.toString(), p['type']?.toString()));
      _remoteSet = true;
      await _flushIce();
      _log('got answer');
    } catch (e) {
      _log('answer failed: $e');
    }
  }

  Future<void> _onIce(Map<String, dynamic> p) async {
    _remoteCount++;
    _summary();
    final c = RTCIceCandidate(
      p['candidate']?.toString(),
      p['sdpMid']?.toString(),
      (p['sdpMLineIndex'] as num?)?.toInt(),
    );
    if (_pc == null || !_remoteSet) {
      _pendingIce.add(c);
    } else {
      try {
        await _pc!.addCandidate(c);
      } catch (_) {}
    }
  }

  Future<void> _flushIce() async {
    for (final c in _pendingIce) {
      try {
        await _pc?.addCandidate(c);
      } catch (_) {}
    }
    _pendingIce.clear();
  }

  Future<void> _onEnd(Map<String, dynamic> p) async => _cleanup();

  // ── Audio + peer connection ─────────────────────────────────────
  Future<List<Map<String, dynamic>>> _iceServers() async {
    // 1. Short-lived relay (TURN) details from our server (best).
    try {
      final res = await Supabase.instance.client.functions
          .invoke('call-ice')
          .timeout(const Duration(seconds: 6));
      final d = res.data;
      final list = d is Map ? d['iceServers'] : null;
      if (list is List && list.isNotEmpty) {
        _iceKind = 'relay ok';
        return [for (final e in list) Map<String, dynamic>.from(e as Map)];
      }
      _iceKind = 'relay empty';
    } catch (e) {
      debugPrint('call: relay details not available: $e');
      _iceKind = 'relay failed';
    }
    // 2. A fixed list the admin saved in app_settings.
    try {
      final row = await Supabase.instance.client
          .from('app_settings')
          .select('call_ice_servers')
          .eq('id', 1)
          .maybeSingle()
          .timeout(const Duration(seconds: 4));
      final v = row?['call_ice_servers'];
      if (v is List && v.isNotEmpty) {
        return [for (final e in v) Map<String, dynamic>.from(e as Map)];
      }
    } catch (_) {}
    // 3. Plain Google STUN (works only when the phones can see each other).
    _iceKind += ' (STUN only)';
    return _defaultIce;
  }

  Future<bool> _openPeer() async {
    try {
      _locHost = _locSrflx = _locRelay = _remoteCount = 0;
      _iceKind = '';
      _log('opening microphone');
      _local = await navigator.mediaDevices
          .getUserMedia({'audio': true, 'video': false}).timeout(
              const Duration(seconds: 12));
      _log('getting relay details');
      final servers = await _iceServers();
      _log('creating connection');
      _pc = await createPeerConnection({
        'iceServers': servers,
        'sdpSemantics': 'unified-plan',
      }).timeout(const Duration(seconds: 10));
      _log('connection ready');
      for (final t in _local!.getAudioTracks()) {
        await _pc!.addTrack(t, _local!);
      }
      _pc!.onIceCandidate = (c) {
        if (c.candidate == null) return;
        final cs = c.candidate!;
        if (cs.contains(' typ relay')) {
          _locRelay++;
        } else if (cs.contains(' typ srflx')) {
          _locSrflx++;
        } else {
          _locHost++;
        }
        _summary();
        _send('ice', {
          'candidate': c.candidate,
          'sdpMid': c.sdpMid,
          'sdpMLineIndex': c.sdpMLineIndex,
        });
      };
      void markConnected() {
        _connectTimeout?.cancel();
        _discTimer?.cancel();
        if (phase.value == CallPhase.connecting) {
          phase.value = CallPhase.connected;
        }
      }

      _pc!.onConnectionState = (s) {
        debugPrint('call: connection state $s');
        step.value = '${step.value.split(' | state').first} | state ${s.name.replaceAll('RTCPeerConnectionState', '')}';
        if (s == RTCPeerConnectionState.RTCPeerConnectionStateConnected) {
          markConnected();
        } else if (s ==
                RTCPeerConnectionState.RTCPeerConnectionStateFailed ||
            s == RTCPeerConnectionState.RTCPeerConnectionStateClosed) {
          if (phase.value != CallPhase.idle) {
            if (phase.value == CallPhase.connecting) {
              note.value =
                  "Couldn't connect the call. Check that both phones have internet and try again.";
            }
            hangUp();
          }
        } else if (s ==
            RTCPeerConnectionState.RTCPeerConnectionStateDisconnected) {
          // A short drop is normal on mobile data: wait before giving up.
          _discTimer?.cancel();
          _discTimer = Timer(const Duration(seconds: 8), () {
            if (phase.value != CallPhase.idle) hangUp();
          });
        }
      };
      // Some phones report the call as connected here first.
      _pc!.onIceConnectionState = (s) {
        debugPrint('call: ice state $s');
        if (s == RTCIceConnectionState.RTCIceConnectionStateConnected ||
            s == RTCIceConnectionState.RTCIceConnectionStateCompleted) {
          markConnected();
        }
      };
      muted.value = false;
      speaker.value = false;
      return true;
    } catch (e) {
      debugPrint('call: could not open audio: $e');
      return false;
    }
  }

  void setMuted(bool m) {
    muted.value = m;
    for (final t in _local?.getAudioTracks() ?? const <MediaStreamTrack>[]) {
      t.enabled = !m;
    }
  }

  Future<void> setSpeaker(bool on) async {
    speaker.value = on;
    try {
      await Helper.setSpeakerphoneOn(on);
    } catch (_) {}
  }

  // ── End ─────────────────────────────────────────────────────────
  Future<void> hangUp() async {
    if (phase.value != CallPhase.idle) _send('end', {'reason': 'hangup'});
    await _cleanup();
  }

  Future<void> _cleanup() async {
    _ringTimeout?.cancel();
    _connectTimeout?.cancel();
    _discTimer?.cancel();
    _pendingIce.clear();
    _remoteSet = false;
    // Let go of the audio and the connection first and close the screen
    // right away; the phone's audio system is then shut down in the
    // background (it can be slow, and must never keep the call screen up).
    final local = _local;
    final pc = _pc;
    _local = null;
    _pc = null;
    phase.value = CallPhase.idle;
    try {
      for (final t in local?.getTracks() ?? const <MediaStreamTrack>[]) {
        await t.stop().timeout(const Duration(seconds: 3));
      }
      await local?.dispose().timeout(const Duration(seconds: 3));
    } catch (_) {}
    try {
      await pc?.close().timeout(const Duration(seconds: 3));
    } catch (_) {}
  }

  void _send(String event, Map<String, dynamic> payload) {
    try {
      _ch?.sendBroadcastMessage(
          event: event, payload: {...payload, 'from': _me});
    } catch (e) {
      debugPrint('call signal failed: $e');
    }
  }
}
