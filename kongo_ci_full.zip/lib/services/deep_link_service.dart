// lib/services/deep_link_service.dart

import 'package:efuride_app/config/tab_routes.dart';

/// What the app should do with an incoming link.
class ResolvedDeepLink {
  final String routePath;   // e.g. '/driver'
  final int tabIndex;       // e.g. 2
  final Map<String, String> params; // passthrough query params
  final bool isRoleShell;   // true when it's a tab switch on a shell

  const ResolvedDeepLink({
    required this.routePath,
    required this.tabIndex,
    required this.params,
    required this.isRoleShell,
  });
}

class DeepLinkService {
  /// Parse a URI like:
  ///   efuride://driver?tab=earnings&ride_id=abc
  ///   https://app.efuride.com/customer?tab=wallet
  ///   /driver?tab=trips
  /// Returns null if the path isn't a known shell.
  static ResolvedDeepLink? resolve(Uri uri) {
    // Normalize path: strip leading scheme + host if https-style
    String path = uri.path;
    if (path.isEmpty) {
      // Might be host-only: efuride://driver
      path = uri.host;
    }
    path = '/${path.replaceAll(RegExp(r'^/+'), '')}';

    const shellPaths = {
      '/driver': 'driver',
      '/customer': 'customer',
      '/shopper': 'shopper',
      '/merchant': 'merchant',
    };

    final role = shellPaths[path];
    if (role == null) return null;

    final tab = uri.queryParameters['tab'];
    final tabIndex = TabRoute.indexFor(role, tab);

    return ResolvedDeepLink(
      routePath: path,
      tabIndex: tabIndex,
      params: uri.queryParameters,
      isRoleShell: true,
    );
  }

  /// Resolve directly from an FCM data payload.
  /// Expected keys:
  ///   - route: '/driver' | '/customer' | ...
  ///   - tab:   'earnings' | 'wallet' | ...
  ///   - plus any other passthrough keys (ride_id, order_id, ...)
  static ResolvedDeepLink? resolveFromFcm(Map<String, dynamic> data) {
    final route = data['route']?.toString();
    if (route == null || route.isEmpty) return null;

    final uri = Uri(
      path: route,
      queryParameters: {
        if (data['tab'] != null) 'tab': data['tab'].toString(),
        // Copy remaining payload keys as query params
        for (final e in data.entries)
          if (e.key != 'route' && e.key != 'tab')
            e.key: e.value.toString(),
      },
    );
    return resolve(uri);
  }
}
