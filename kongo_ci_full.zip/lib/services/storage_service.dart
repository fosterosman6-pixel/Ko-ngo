// lib/services/storage_service.dart
//
// Single entry point for every file upload in the app.
//
// Buckets (must exist in the Supabase dashboard):
//   • avatars         — public read, user-scoped write
//   • public-assets   — public read, merchant-scoped write
//   • package-photos  — public read, customer-scoped write
//   • receipts        — private, task-scoped write
//   • substitutions   — private, task-scoped write
//   • documents       — private (driver KYC, prescriptions)

import 'dart:async';
import 'dart:typed_data';
import 'package:flutter/foundation.dart' show debugPrint;
import 'package:image_picker/image_picker.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class StorageService {
  StorageService._();
  static final StorageService instance = StorageService._();

  SupabaseClient get _sb => Supabase.instance.client;

  // ═══════════════════════════════════════════════════════════
  // PICKERS
  // ═══════════════════════════════════════════════════════════
  Future<XFile?> pickImage({
    bool fromCamera = false,
    int maxWidth = 1600,
    int imageQuality = 75,
  }) async {
    try {
      final picker = ImagePicker();
      return await picker.pickImage(
        source: fromCamera ? ImageSource.camera : ImageSource.gallery,
        maxWidth: maxWidth.toDouble(),
        maxHeight: maxWidth.toDouble(),
        imageQuality: imageQuality,
      );
    } catch (e) {
      debugPrint('StorageService.pickImage failed: $e');
      return null;
    }
  }

  // ═══════════════════════════════════════════════════════════
  // AVATARS — public
  // ═══════════════════════════════════════════════════════════
  Future<String?> uploadAvatar({
    required String userId,
    required XFile file,
  }) async {
    try {
      final ext = _ext(file.name);
      final bytes = await file.readAsBytes();
      final path = '$userId/avatar-${_stamp()}.$ext';

      await _sb.storage.from('avatars').uploadBinary(
            path,
            bytes,
            fileOptions: FileOptions(
              upsert: true,
              contentType: _contentType(ext),
            ),
          );

      final url = _sb.storage.from('avatars').getPublicUrl(path);

      await _sb.from('profiles').update({
        'profile_picture_url': url,
        'avatar_url': url,
      }).eq('id', userId);

      return url;
    } catch (e) {
      debugPrint('StorageService.uploadAvatar failed: $e');
      return null;
    }
  }

  // ═══════════════════════════════════════════════════════════
  // PUBLIC ASSETS — product images, merchant logo/cover
  // ═══════════════════════════════════════════════════════════
  Future<String?> uploadProductImage({
    required String partnerId,
    required String productId,
    required XFile file,
  }) async {
    try {
      final ext = _ext(file.name);
      final bytes = await file.readAsBytes();
      final path = 'products/$partnerId/$productId-${_stamp()}.$ext';
      return _uploadToPublicBucket(
        bucket: 'public-assets',
        path: path,
        bytes: bytes,
        contentType: _contentType(ext),
      );
    } catch (e) {
      debugPrint('StorageService.uploadProductImage failed: $e');
      return null;
    }
  }

  Future<String?> uploadMerchantLogo({
    required String partnerId,
    required XFile file,
  }) async {
    try {
      final ext = _ext(file.name);
      final bytes = await file.readAsBytes();
      final path = 'partners/$partnerId/logo-${_stamp()}.$ext';
      return _uploadToPublicBucket(
        bucket: 'public-assets',
        path: path,
        bytes: bytes,
        contentType: _contentType(ext),
      );
    } catch (e) {
      debugPrint('StorageService.uploadMerchantLogo failed: $e');
      return null;
    }
  }

  Future<String?> uploadMerchantCover({
    required String partnerId,
    required XFile file,
  }) async {
    try {
      final ext = _ext(file.name);
      final bytes = await file.readAsBytes();
      final path = 'partners/$partnerId/cover-${_stamp()}.$ext';
      return _uploadToPublicBucket(
        bucket: 'public-assets',
        path: path,
        bytes: bytes,
        contentType: _contentType(ext),
      );
    } catch (e) {
      debugPrint('StorageService.uploadMerchantCover failed: $e');
      return null;
    }
  }

  // ═══════════════════════════════════════════════════════════
  // PACKAGE PHOTOS — public (parcel/ride delivery)
  // ═══════════════════════════════════════════════════════════
  // HIRING HUB — job photo (public)
  // ═══════════════════════════════════════════════════════════
  Future<String?> uploadJobPhoto(XFile file) async {
    try {
      final userId = _sb.auth.currentUser?.id;
      if (userId == null) return null;
      final ext = _ext(file.name);
      final bytes = await file.readAsBytes();
      return _uploadToPublicBucket(
        bucket: 'job-photos',
        path: '$userId/job-${_stamp()}.$ext',
        bytes: bytes,
        contentType: _contentType(ext),
      );
    } catch (e) {
      debugPrint('StorageService.uploadJobPhoto failed: $e');
      return null;
    }
  }

  // ═══════════════════════════════════════════════════════════
  Future<String?> uploadPackagePhoto(XFile file, String rideId) async {
    try {
      final userId = _sb.auth.currentUser?.id;
      if (userId == null) return null;

      final ext = _ext(file.name);
      final bytes = await file.readAsBytes();
      final path = '$rideId/$userId-${_stamp()}.$ext';

      return _uploadToPublicBucket(
        bucket: 'package-photos',
        path: path,
        bytes: bytes,
        contentType: _contentType(ext),
      );
    } catch (e) {
      debugPrint('StorageService.uploadPackagePhoto failed: $e');
      return null;
    }
  }

  // ═══════════════════════════════════════════════════════════
  // RECEIPTS — private
  // ═══════════════════════════════════════════════════════════
  Future<String?> uploadReceipt({
    required String taskId,
    required XFile file,
  }) async {
    try {
      final ext = _ext(file.name);
      final bytes = await file.readAsBytes();
      final path = 'receipts/$taskId-${_stamp()}.$ext';
      return _uploadToPrivateBucket(
        bucket: 'receipts',
        path: path,
        bytes: bytes,
        contentType: _contentType(ext),
      );
    } catch (e) {
      debugPrint('StorageService.uploadReceipt failed: $e');
      return null;
    }
  }

  Future<String?> uploadReceiptBytes({
    required String taskId,
    required Uint8List bytes,
    required String ext,
  }) async {
    try {
      final path = 'receipts/$taskId-${_stamp()}.$ext';
      return _uploadToPrivateBucket(
        bucket: 'receipts',
        path: path,
        bytes: bytes,
        contentType: _contentType(ext),
      );
    } catch (e) {
      debugPrint('StorageService.uploadReceiptBytes failed: $e');
      return null;
    }
  }

  // ═══════════════════════════════════════════════════════════
  // SUBSTITUTION PHOTOS — private
  // ═══════════════════════════════════════════════════════════
  Future<String?> uploadSubstitutionPhoto({
    required String substitutionId,
    required XFile file,
  }) async {
    try {
      final ext = _ext(file.name);
      final bytes = await file.readAsBytes();
      final path = 'substitutions/$substitutionId-${_stamp()}.$ext';
      return _uploadToPrivateBucket(
        bucket: 'substitutions',
        path: path,
        bytes: bytes,
        contentType: _contentType(ext),
      );
    } catch (e) {
      debugPrint('StorageService.uploadSubstitutionPhoto failed: $e');
      return null;
    }
  }

  Future<String?> uploadSubstitutionPhotoBytes({
    required String substitutionId,
    required Uint8List bytes,
    required String ext,
  }) async {
    try {
      final path = 'substitutions/$substitutionId-${_stamp()}.$ext';
      return _uploadToPrivateBucket(
        bucket: 'substitutions',
        path: path,
        bytes: bytes,
        contentType: _contentType(ext),
      );
    } catch (e) {
      debugPrint('StorageService.uploadSubstitutionPhotoBytes failed: $e');
      return null;
    }
  }

  // ═══════════════════════════════════════════════════════════
  // DOCUMENTS — private (driver KYC, prescriptions)
  // ═══════════════════════════════════════════════════════════
  Future<String?> uploadDriverDocument({
    required String driverId,
    required String kind,
    required XFile file,
  }) async {
    try {
      final ext = _ext(file.name);
      final bytes = await file.readAsBytes();
      final path = 'drivers/$driverId/$kind-${_stamp()}.$ext';
      return _uploadToPrivateBucket(
        bucket: 'documents',
        path: path,
        bytes: bytes,
        contentType: _contentType(ext),
      );
    } catch (e) {
      debugPrint('StorageService.uploadDriverDocument failed: $e');
      return null;
    }
  }

  Future<String?> uploadPrescription({
    required String userId,
    required XFile file,
  }) async {
    try {
      final ext = _ext(file.name);
      final bytes = await file.readAsBytes();
      final path = 'prescriptions/$userId/${_stamp()}.$ext';
      return _uploadToPrivateBucket(
        bucket: 'documents',
        path: path,
        bytes: bytes,
        contentType: _contentType(ext),
      );
    } catch (e) {
      debugPrint('StorageService.uploadPrescription failed: $e');
      return null;
    }
  }

  // ═══════════════════════════════════════════════════════════
  // READ
  // ═══════════════════════════════════════════════════════════
  Future<String?> signedUrl({
    required String bucket,
    required String path,
    int expiresInSeconds = 3600,
  }) async {
    try {
      return await _sb.storage
          .from(bucket)
          .createSignedUrl(path, expiresInSeconds);
    } catch (e) {
      debugPrint('StorageService.signedUrl failed: $e');
      return null;
    }
  }

  String publicUrl({required String bucket, required String path}) {
    return _sb.storage.from(bucket).getPublicUrl(path);
  }

  // ═══════════════════════════════════════════════════════════
  // DELETE
  // ═══════════════════════════════════════════════════════════
  Future<void> delete({
    required String bucket,
    required List<String> paths,
  }) async {
    if (paths.isEmpty) return;
    try {
      await _sb.storage.from(bucket).remove(paths);
    } catch (e) {
      debugPrint('StorageService.delete failed: $e');
    }
  }

  // ═══════════════════════════════════════════════════════════
  // INTERNALS
  // ═══════════════════════════════════════════════════════════
  /// Why the last upload failed (shown to the user), or null.
  String? lastUploadError;

  Future<String?> _uploadToPublicBucket({
    required String bucket,
    required String path,
    required Uint8List bytes,
    required String contentType,
  }) async {
    lastUploadError = null;
    try {
      // Each path is new (it has a timestamp), so a plain upload is enough;
      // upsert would also need "update" permission on storage.
      await _sb.storage
          .from(bucket)
          .uploadBinary(
            path,
            bytes,
            fileOptions: FileOptions(
              upsert: false,
              contentType: contentType,
            ),
          )
          .timeout(const Duration(seconds: 45));
      return _sb.storage.from(bucket).getPublicUrl(path);
    } on TimeoutException {
      lastUploadError = 'The upload took too long. Check your connection.';
      debugPrint('upload to $bucket timed out');
      return null;
    } catch (e) {
      // Never show storage details to people; a plain reason only.
      final m = e.toString().toLowerCase();
      lastUploadError = m.contains('row-level security') ||
              m.contains('row level security') ||
              m.contains('403') ||
              m.contains('unauthorized')
          ? 'Pictures can\'t be saved for this store yet. Please contact ko!ngo support.'
          : m.contains('socket') || m.contains('host lookup') || m.contains('network')
              ? 'No internet connection. Check your network and try again.'
              : 'The picture could not be saved. Please try again.';
      debugPrint('upload to $bucket failed: $e');
      return null;
    }
  }

  Future<String?> _uploadToPrivateBucket({
    required String bucket,
    required String path,
    required Uint8List bytes,
    required String contentType,
  }) async {
    try {
      await _sb.storage.from(bucket).uploadBinary(
            path,
            bytes,
            fileOptions: FileOptions(
              upsert: true,
              contentType: contentType,
            ),
          );
      return path;
    } catch (e) {
      debugPrint('upload to $bucket failed: $e');
      return null;
    }
  }

  String _ext(String name) {
    final dot = name.lastIndexOf('.');
    if (dot <= 0 || dot >= name.length - 1) return 'jpg';
    return name.substring(dot + 1).toLowerCase();
  }

  String _stamp() => DateTime.now().millisecondsSinceEpoch.toString();

  String _contentType(String ext) {
    switch (ext) {
      case 'png':
        return 'image/png';
      case 'webp':
        return 'image/webp';
      case 'gif':
        return 'image/gif';
      case 'heic':
        return 'image/heic';
      case 'pdf':
        return 'application/pdf';
      case 'jpg':
      case 'jpeg':
      default:
        return 'image/jpeg';
    }
  }
}
