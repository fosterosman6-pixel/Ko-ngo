// lib/services/merchant_service.dart
//
// All merchant-side queries + realtime subscriptions.
// Matches the schema created in Phases 1–2C.

import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

// ============================================================
// MODELS
// ============================================================

class MerchantOrderLine {
  final String name;
  final int qty;
  final double price;
  final String? emoji;

  MerchantOrderLine({
    required this.name,
    required this.qty,
    required this.price,
    this.emoji,
  });

  factory MerchantOrderLine.fromMap(Map<String, dynamic> m) =>
      MerchantOrderLine(
        name: (m['name'] ?? '').toString(),
        qty: (m['qty'] as num?)?.toInt() ?? 1,
        price: (m['unit_price'] as num?)?.toDouble() ?? 0,
        emoji: m['emoji'] as String?,
      );

  double get lineTotal => qty * price;
}

class MerchantOrder {
  final String id;
  final String? partnerId;
  final String customerId;
  final String? customerName;
  final String? customerPhone;
  final String serviceType;
  final String status;
  final double subtotal;
  final double serviceFee;
  final double deliveryFee;
  final double discountAmount;
  final double total;
  final String? deliveryAddress;
  final String? deliveryNote;
  final bool requiresPrescription;
  final String? prescriptionUrl;
  final String? driverId;
  final String? driverName;
  final DateTime createdAt;
  final DateTime? acceptedAt;
  final DateTime? readyAt;
  final DateTime? pickedUpAt;
  final DateTime? deliveredAt;
  final DateTime? cancelledAt;

  List<MerchantOrderLine> lines;

  MerchantOrder({
    required this.id,
    this.partnerId,
    required this.customerId,
    this.customerName,
    this.customerPhone,
    required this.serviceType,
    required this.status,
    required this.subtotal,
    required this.serviceFee,
    required this.deliveryFee,
    required this.discountAmount,
    required this.total,
    this.deliveryAddress,
    this.deliveryNote,
    required this.requiresPrescription,
    this.prescriptionUrl,
    this.driverId,
    this.driverName,
    required this.createdAt,
    this.acceptedAt,
    this.readyAt,
    this.pickedUpAt,
    this.deliveredAt,
    this.cancelledAt,
    this.lines = const [],
  });

  factory MerchantOrder.fromMap(
    Map<String, dynamic> m, {
    List<MerchantOrderLine> lines = const [],
  }) =>
      MerchantOrder(
        id: m['id'] as String,
        partnerId: m['partner_id'] as String?,
        customerId: m['customer_id'] as String,
        customerName: m['customer_name'] as String?,
        customerPhone: m['customer_phone'] as String?,
        serviceType: (m['service_type'] ?? 'Food').toString(),
        status: (m['status'] ?? 'pending').toString(),
        subtotal: (m['subtotal'] as num?)?.toDouble() ?? 0,
        serviceFee: (m['service_fee'] as num?)?.toDouble() ?? 0,
        deliveryFee: (m['delivery_fee'] as num?)?.toDouble() ?? 0,
        discountAmount: (m['discount_amount'] as num?)?.toDouble() ?? 0,
        total: (m['total'] as num?)?.toDouble() ?? 0,
        deliveryAddress: m['delivery_address'] as String?,
        deliveryNote: m['delivery_note'] as String?,
        requiresPrescription: m['requires_prescription'] == true,
        prescriptionUrl: m['prescription_url'] as String?,
        driverId: m['driver_id'] as String?,
        driverName: m['driver_name'] as String?,
        createdAt: _parseDate(m['created_at']) ?? DateTime.now(),
        acceptedAt: _parseDate(m['accepted_at']),
        readyAt: _parseDate(m['ready_at']),
        pickedUpAt: _parseDate(m['picked_up_at']),
        deliveredAt: _parseDate(m['delivered_at']),
        cancelledAt: _parseDate(m['cancelled_at']),
        lines: lines,
      );

  bool get isIncoming => status == 'pending';
  bool get isActive =>
      status == 'pending' ||
      status == 'confirmed' ||
      status == 'shopping' ||
      status == 'preparing' ||
      status == 'ready' ||
      status == 'picked_up' ||
      status == 'in_transit' ||
      status == 'returning';
  bool get isTerminal =>
      status == 'delivered' ||
      status == 'cancelled' ||
      status == 'returned';
}

class MerchantProduct {
  final String id;
  final String partnerId;
  final String name;
  final String? description;
  final String? category;
  final double price;
  final String? emoji;
  final String? imageUrl;
  final int prepMinutes;
  final int? stockLeft;
  final bool isAvailable;
  final bool isFeatured;
  final int displayOrder;

  MerchantProduct({
    required this.id,
    required this.partnerId,
    required this.name,
    this.description,
    this.category,
    required this.price,
    this.emoji,
    this.imageUrl,
    required this.prepMinutes,
    this.stockLeft,
    required this.isAvailable,
    required this.isFeatured,
    required this.displayOrder,
  });

  factory MerchantProduct.fromMap(Map<String, dynamic> m) =>
      MerchantProduct(
        id: m['id'] as String,
        partnerId: m['partner_id'] as String,
        name: (m['name'] ?? '').toString(),
        description: m['description'] as String?,
        category: m['category'] as String?,
        price: (m['price'] as num?)?.toDouble() ?? 0,
        emoji: m['emoji'] as String?,
        imageUrl: m['image_url'] as String?,
        prepMinutes: (m['prep_minutes'] as num?)?.toInt() ?? 10,
        stockLeft: (m['stock_left'] as num?)?.toInt(),
        isAvailable: m['is_available'] == true,
        isFeatured: m['is_featured'] == true,
        displayOrder: (m['display_order'] as num?)?.toInt() ?? 0,
      );
}

class MerchantSettlement {
  final String id;
  final DateTime periodStart;
  final DateTime periodEnd;
  final int orderCount;
  final double grossSales;
  final double commissionAmount;
  final double netPayout;
  final String status;
  final String? reference;
  final DateTime? paidAt;
  final String? failureReason;

  MerchantSettlement({
    required this.id,
    required this.periodStart,
    required this.periodEnd,
    required this.orderCount,
    required this.grossSales,
    required this.commissionAmount,
    required this.netPayout,
    required this.status,
    this.reference,
    this.paidAt,
    this.failureReason,
  });

  factory MerchantSettlement.fromMap(Map<String, dynamic> m) =>
      MerchantSettlement(
        id: m['id'] as String,
        periodStart: _parseDate(m['period_start']) ?? DateTime.now(),
        periodEnd: _parseDate(m['period_end']) ?? DateTime.now(),
        orderCount: (m['order_count'] as num?)?.toInt() ?? 0,
        grossSales: (m['gross_sales'] as num?)?.toDouble() ?? 0,
        commissionAmount:
            (m['commission_amount'] as num?)?.toDouble() ?? 0,
        netPayout: (m['net_payout'] as num?)?.toDouble() ?? 0,
        status: (m['status'] ?? 'pending').toString(),
        reference: m['reference'] as String?,
        paidAt: _parseDate(m['paid_at']),
        failureReason: m['failure_reason'] as String?,
      );
}

class MerchantStats {
  final int ordersToday;
  final double revenueToday;
  final double netToday;
  final int activeOrders;
  final double weeklyRevenue;
  final double walletBalance;

  const MerchantStats({
    required this.ordersToday,
    required this.revenueToday,
    required this.netToday,
    required this.activeOrders,
    required this.weeklyRevenue,
    required this.walletBalance,
  });
}

DateTime? _parseDate(dynamic d) =>
    d == null ? null : DateTime.tryParse(d.toString())?.toLocal();

// ============================================================
// SERVICE
// ============================================================

class MerchantService {
  MerchantService._();
  static final MerchantService instance = MerchantService._();

  SupabaseClient get _sb => Supabase.instance.client;
  String? get _uid => _sb.auth.currentUser?.id;

  String? _cachedPartnerId;

  // ------------------------------------------------------------
  // PARTNER RESOLUTION
  // ------------------------------------------------------------

  static const _kSelectedShop = 'merchant_selected_shop';

  /// The merchant's shops (a merchant can own several), oldest first.
  Future<List<Map<String, dynamic>>> myShops() async {
    final uid = _uid;
    if (uid == null) return const [];
    final rows = await _sb
        .from('partners')
        .select('id, name, category, address, city, is_open, logo_url')
        .eq('owner_id', uid)
        .order('created_at', ascending: true);
    return [for (final r in rows as List) Map<String, dynamic>.from(r as Map)];
  }

  /// Switch the dashboard, orders and menu to another shop of this merchant.
  Future<void> selectShop(String id) async {
    _cachedPartnerId = id;
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('${_kSelectedShop}_${_uid ?? ''}', id);
    } catch (_) {}
  }

  /// Get the shop the merchant is working in (cached). When there are
  /// several, the one picked last time, else the oldest.
  Future<String?> getPartnerId({bool refresh = false}) async {
    if (_cachedPartnerId != null && !refresh) return _cachedPartnerId;
    final uid = _uid;
    if (uid == null) return null;
    final shops = await myShops();
    if (shops.isEmpty) {
      _cachedPartnerId = null;
      return null;
    }
    String? chosen;
    try {
      final prefs = await SharedPreferences.getInstance();
      chosen = prefs.getString('${_kSelectedShop}_$uid');
    } catch (_) {}
    final ids = [for (final r in shops) r['id'].toString()];
    _cachedPartnerId =
        (chosen != null && ids.contains(chosen)) ? chosen : ids.first;
    return _cachedPartnerId;
  }

  /// Load the full partner profile.
  Future<Map<String, dynamic>?> loadPartner() async {
    final pid = await getPartnerId();
    if (pid == null) return null;
    final row = await _sb
        .from('partners')
        .select()
        .eq('id', pid)
        .maybeSingle();
    return row == null ? null : Map<String, dynamic>.from(row);
  }

  /// Toggle the "accepting orders" state.
  Future<void> setOpen(bool open) async {
    final pid = await getPartnerId();
    if (pid == null) throw Exception('No partner account');
    await _sb.from('partners').update({'is_open': open}).eq('id', pid);
  }

  // ------------------------------------------------------------
  // ORDERS
  // ------------------------------------------------------------

  /// Load active orders. Pulls customer name + line items in one pass.
  Future<List<MerchantOrder>> loadActiveOrders() async {
    final pid = await getPartnerId();
    if (pid == null) throw Exception('No partner account');

    final rows = await _sb
        .from('orders')
        .select()
        .eq('partner_id', pid)
        .inFilter(
            'status',
            ['pending', 'confirmed', 'shopping', 'preparing', 'ready',
             'picked_up', 'in_transit', 'returning'])
        .order('created_at', ascending: false)
        .timeout(const Duration(seconds: 15));

    return _hydrateOrders(rows as List);
  }

  Future<List<MerchantOrder>> loadOrderHistory({int limit = 50}) async {
    final pid = await getPartnerId();
    if (pid == null) throw Exception('No partner account');

    final rows = await _sb
        .from('orders')
        .select()
        .eq('partner_id', pid)
        .inFilter('status', ['delivered', 'cancelled'])
        .order('created_at', ascending: false)
        .limit(limit);

    return _hydrateOrders(rows as List);
  }

  /// Enrich order rows with customer name + line items.
  Future<List<MerchantOrder>> _hydrateOrders(List rows) async {
    if (rows.isEmpty) return const [];

    final orderIds = rows.map((r) => r['id'] as String).toList();
    final customerIds =
        rows.map((r) => r['customer_id']).whereType<String>().toSet().toList();
    final driverIds =
        rows.map((r) => r['driver_id']).whereType<String>().toSet().toList();

    // Line items
    final itemRows = await _sb
        .from('order_items')
        .select()
        .inFilter('order_id', orderIds);

    final itemsByOrder = <String, List<MerchantOrderLine>>{};
    for (final r in itemRows) {
      final oid = r['order_id'] as String;
      itemsByOrder
          .putIfAbsent(oid, () => [])
          .add(MerchantOrderLine.fromMap(Map<String, dynamic>.from(r)));
    }

    // Customer names
    final customersById = <String, Map<String, dynamic>>{};
    if (customerIds.isNotEmpty) {
      final profiles = await _sb
          .from('profiles')
          .select('id, first_name, surname, full_name, phone_number')
          .inFilter('id', customerIds);
      for (final p in profiles) {
        customersById[p['id']] = Map<String, dynamic>.from(p);
      }
    }

    // Driver names
    final driversById = <String, Map<String, dynamic>>{};
    if (driverIds.isNotEmpty) {
      final drivers = await _sb
          .from('profiles')
          .select('id, first_name, surname, full_name')
          .inFilter('id', driverIds);
      for (final d in drivers) {
        driversById[d['id']] = Map<String, dynamic>.from(d);
      }
    }

    return rows.map((r) {
      final m = Map<String, dynamic>.from(r);
      final custId = m['customer_id'] as String?;
      final driverId = m['driver_id'] as String?;

      if (custId != null && customersById.containsKey(custId)) {
        final c = customersById[custId]!;
        final first = (c['first_name'] ?? '').toString().trim();
        final surname = (c['surname'] ?? '').toString().trim();
        final full = (c['full_name'] ?? '').toString().trim();
        m['customer_name'] = first.isNotEmpty
            ? '$first $surname'.trim()
            : full;
        m['customer_phone'] = c['phone_number'];
      }

      if (driverId != null && driversById.containsKey(driverId)) {
        final d = driversById[driverId]!;
        final first = (d['first_name'] ?? '').toString().trim();
        final surname = (d['surname'] ?? '').toString().trim();
        final full = (d['full_name'] ?? '').toString().trim();
        m['driver_name'] = first.isNotEmpty
            ? '$first $surname'.trim()
            : full;
      }

      return MerchantOrder.fromMap(
        m,
        lines: itemsByOrder[m['id']] ?? const [],
      );
    }).toList();
  }

  /// Accept an incoming order.
  Future<void> acceptOrder(String orderId) async {
    await _sb.from('orders').update({
      'status': 'confirmed',
      'accepted_at': DateTime.now().toUtc().toIso8601String(),
    }).eq('id', orderId);
  }

  /// Reject an incoming order (system reroutes).
  Future<void> rejectOrder(String orderId, {String? reason}) async {
    await _sb.from('orders').update({
      'status': 'cancelled',
      'cancelled_by': 'merchant',
      'cancellation_reason': reason ?? 'Rejected by merchant',
      'cancelled_at': DateTime.now().toUtc().toIso8601String(),
    }).eq('id', orderId);
  }

  /// Mark order as preparing.
  Future<void> markPreparing(String orderId) async {
    await _sb.from('orders').update({
      'status': 'preparing',
    }).eq('id', orderId);
  }

  /// Mark order as ready for pickup.
  Future<void> markReady(String orderId) async {
    await _sb.from('orders').update({
      'status': 'ready',
      'ready_at': DateTime.now().toUtc().toIso8601String(),
    }).eq('id', orderId);
  }

  /// Merchant confirms driver pickup (usually triggered by scanning
  /// the driver's handoff QR).
  Future<void> markPickedUp(String orderId, String driverId) async {
    await _sb.from('orders').update({
      'status': 'picked_up',
      'driver_id': driverId,
      'picked_up_at': DateTime.now().toUtc().toIso8601String(),
    }).eq('id', orderId);
  }

  // ------------------------------------------------------------
  // MENU
  // ------------------------------------------------------------

  Future<List<MerchantProduct>> loadMenu() async {
    final pid = await getPartnerId();
    if (pid == null) throw Exception('No partner account');

    final rows = await _sb
        .from('products')
        .select()
        .eq('partner_id', pid)
        .order('display_order', ascending: true)
        .order('created_at', ascending: false);

    return (rows as List)
        .map((r) => MerchantProduct.fromMap(Map<String, dynamic>.from(r)))
        .toList();
  }

  Future<MerchantProduct> upsertProduct({
    String? id,
    required String name,
    String? description,
    String? category,
    required double price,
    String? emoji,
    String? imageUrl,
    int prepMinutes = 10,
    int? stockLeft,
    bool isAvailable = true,
    bool isFeatured = false,
  }) async {
    final pid = await getPartnerId();
    if (pid == null) throw Exception('No partner account');

    final payload = {
      'partner_id': pid,
      'name': name,
      'description': description,
      'category': category,
      'price': price,
      'emoji': emoji,
      'image_url': imageUrl,
      'prep_minutes': prepMinutes,
      'stock_left': stockLeft,
      'is_available': isAvailable,
      'is_featured': isFeatured,
    };

    // Explicit if/else — Dart doesn't promote `id` to non-null inside
    // the else branch of a `x == null ? ... : ...` when the branches
    // span SDK calls. Pinning to `existingId` makes flow analysis happy.
    final Map<String, dynamic> row;
    if (id == null) {
      row = await _sb.from('products').insert(payload).select().single();
    } else {
      final existingId = id;
      row = await _sb
          .from('products')
          .update(payload)
          .eq('id', existingId)
          .select()
          .single();
    }

    return MerchantProduct.fromMap(Map<String, dynamic>.from(row));
  }

  Future<void> toggleProductAvailability(
      String productId, bool available) async {
    await _sb.from('products').update({
      'is_available': available,
    }).eq('id', productId);
  }

  Future<void> deleteProduct(String productId) async {
    await _sb.from('products').delete().eq('id', productId);
  }

  // ------------------------------------------------------------
  // PAYOUTS
  // ------------------------------------------------------------

  Future<List<MerchantSettlement>> loadSettlements({int limit = 20}) async {
    final pid = await getPartnerId();
    if (pid == null) throw Exception('No partner account');

    final rows = await _sb
        .from('merchant_settlements')
        .select()
        .eq('partner_id', pid)
        .order('period_start', ascending: false)
        .limit(limit);

    return (rows as List)
        .map((r) =>
            MerchantSettlement.fromMap(Map<String, dynamic>.from(r)))
        .toList();
  }

  // ------------------------------------------------------------
  // STATS
  // ------------------------------------------------------------

  Future<MerchantStats> loadTodayStats() async {
    final pid = await getPartnerId();
    if (pid == null) throw Exception('No partner account');

    // Today's delivered orders
    final now = DateTime.now();
    final todayStart = DateTime(now.year, now.month, now.day).toUtc();
    final weekStart =
        todayStart.subtract(Duration(days: now.weekday - 1));

    final delivered = await _sb
        .from('orders')
        .select('total, delivered_at')
        .eq('partner_id', pid)
        .eq('status', 'delivered')
        .gte('delivered_at', todayStart.toIso8601String());

    double today = 0;
    for (final r in delivered) {
      today += (r['total'] as num?)?.toDouble() ?? 0;
    }

    // Active orders count
    final activeRes = await _sb
        .from('orders')
        .select('id')
        .eq('partner_id', pid)
        .inFilter(
            'status',
            ['pending', 'confirmed', 'shopping', 'preparing', 'ready',
             'picked_up', 'in_transit', 'returning']);
    final active = (activeRes as List).length;

    // Weekly revenue
    final weeklyRes = await _sb
        .from('orders')
        .select('total')
        .eq('partner_id', pid)
        .eq('status', 'delivered')
        .gte('delivered_at', weekStart.toIso8601String());
    double week = 0;
    for (final r in weeklyRes) {
      week += (r['total'] as num?)?.toDouble() ?? 0;
    }

    // Wallet from profile.
    //
    // FIX (line ~616): `_uid` is `String?`. Dart's flow analysis will
    // NOT promote a getter's return value across an SDK `.eq()` call,
    // because the getter can return a different value each invocation.
    // Bind it to a local `final` first so the compiler treats it as a
    // definite non-null `String`.
    final uid = _uid;
    if (uid == null) throw Exception('Not signed in');

    final profile = await _sb
        .from('profiles')
        .select('wallet_balance')
        .eq('id', uid)
        .maybeSingle();

    final commission = 25.0; // could pull from partners table
    return MerchantStats(
      ordersToday: (delivered as List).length,
      revenueToday: today,
      netToday: today * (100 - commission) / 100,
      activeOrders: active,
      weeklyRevenue: week,
      walletBalance:
          (profile?['wallet_balance'] as num?)?.toDouble() ?? 0,
    );
  }

  // ------------------------------------------------------------
  // REALTIME
  // ------------------------------------------------------------

  /// Stream incoming + active orders for this partner.
  Stream<List<MerchantOrder>> streamOrders() {
    // Same promotion issue as above: bind the cached partner id to a
    // local `final` so `.eq()` sees a definite `String`, not `String?`.
    final cached = _cachedPartnerId;
    if (cached == null) return const Stream.empty();
    final pid = cached;

    return _sb
        .from('orders')
        .stream(primaryKey: ['id'])
        .eq('partner_id', pid)
        .order('created_at')
        .asyncMap((rows) => _hydrateOrders(rows));
  }

  /// Stream menu products for this partner.
  Stream<List<MerchantProduct>> streamMenu() {
    final cached = _cachedPartnerId;
    if (cached == null) return const Stream.empty();
    final pid = cached;

    return _sb
        .from('products')
        .stream(primaryKey: ['id'])
        .eq('partner_id', pid)
        .map((rows) => rows
            .map((r) => MerchantProduct.fromMap(Map<String, dynamic>.from(r)))
            .toList());
  }

  // ------------------------------------------------------------
  // STORAGE
  // ------------------------------------------------------------

  Future<String?> uploadProductImage({
    required String productId,
    required List<int> bytes,
    required String ext,
  }) async {
    try {
      final path =
          'products/$productId-${DateTime.now().millisecondsSinceEpoch}.$ext';
      await _sb.storage.from('public-assets').uploadBinary(
            path,
            Uint8List.fromList(bytes),
            fileOptions: const FileOptions(upsert: true),
          );
      return _sb.storage.from('public-assets').getPublicUrl(path);
    } catch (e) {
      debugPrint('uploadProductImage failed: $e');
      return null;
    }
  }

  /// Clear cached partner id — useful after sign out.
  void resetCache() {
    _cachedPartnerId = null;
  }
}
