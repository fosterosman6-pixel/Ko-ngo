// lib/services/google_places_service.dart

import 'dart:async';
import 'dart:convert';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:http/http.dart' as http;
import 'package:efuride_app/config/app_config.dart';

/// One autocomplete suggestion returned by Google Places.
class PlacePrediction {
  final String placeId;
  final String primaryText;
  final String secondaryText;
  final String fullDescription;
  final List<String> types;

  const PlacePrediction({
    required this.placeId,
    required this.primaryText,
    required this.secondaryText,
    required this.fullDescription,
    required this.types,
  });
}

/// Fully-resolved place with coordinates + parsed address.
class PlaceDetails {
  final String placeId;
  final double lat;
  final double lng;
  final String formattedAddress;
  final String? name;
  final String? houseNumber;
  final String? street;
  final String? suburb;
  final String? city;
  final String? postcode;

  const PlaceDetails({
    required this.placeId,
    required this.lat,
    required this.lng,
    required this.formattedAddress,
    this.name,
    this.houseNumber,
    this.street,
    this.suburb,
    this.city,
    this.postcode,
  });

  /// Short, human-readable line for list rows ("23 Milagro St").
  String get shortLabel {
    final parts = <String>[];
    if (houseNumber != null && houseNumber!.isNotEmpty && street != null) {
      parts.add('$houseNumber $street');
    } else if (street != null && street!.isNotEmpty) {
      parts.add(street!);
    } else if (name != null && name!.isNotEmpty) {
      parts.add(name!);
    }
    return parts.isEmpty ? formattedAddress : parts.join(' ');
  }

  /// Secondary line ("Waterstone Village, Cape Town").
  String get contextLabel {
    final parts = <String>[];
    if (suburb != null && suburb!.isNotEmpty) parts.add(suburb!);
    if (city != null && city!.isNotEmpty && city != suburb) parts.add(city!);
    if (postcode != null && postcode!.isNotEmpty) parts.add(postcode!);
    return parts.join(', ');
  }

  LatLng get latLng => LatLng(lat, lng);
}

/// Central wrapper around Google Places (Autocomplete + Details).
///
/// Uses a per-session token so Google bills the autocomplete + details
/// pair as one session — significantly cheaper than per-keystroke
/// billing. Call [resetSession] after a successful Details fetch.
class GooglePlacesService {
  static const String _autocompleteUrl =
      'https://maps.googleapis.com/maps/api/place/autocomplete/json';
  static const String _detailsUrl =
      'https://maps.googleapis.com/maps/api/place/details/json';

  static String? _sessionToken;

  static String _ensureSession() {
    _sessionToken ??=
        DateTime.now().microsecondsSinceEpoch.toRadixString(36);
    return _sessionToken!;
  }

  static void resetSession() {
    _sessionToken = null;
  }

  static Future<List<PlacePrediction>> autocomplete({
    required String query,
    required LatLng origin,
    int radiusMeters = 40000,
    String? countryCode, // ISO-3166-1 alpha-2, lowercase. null = no bias.
  }) async {
    final trimmed = query.trim();
    if (trimmed.isEmpty) return const [];

    final params = <String, String>{
      'input': trimmed,
      'key': AppConfig.googleMapsApiKey,
      'sessiontoken': _ensureSession(),
      'location': '${origin.latitude},${origin.longitude}',
      'radius': radiusMeters.toString(),
      'language': 'en',
      'types': 'geocode|establishment',
      if (countryCode != null && countryCode.isNotEmpty)
        'components': 'country:$countryCode',
    };

    final uri = Uri.parse(_autocompleteUrl).replace(queryParameters: params);
    final res = await http.get(uri).timeout(const Duration(seconds: 10));

    if (res.statusCode != 200) {
      throw Exception('Places autocomplete HTTP ${res.statusCode}');
    }

    final body = json.decode(res.body) as Map<String, dynamic>;
    final status = body['status'] as String? ?? 'UNKNOWN';
    if (status != 'OK' && status != 'ZERO_RESULTS') {
      throw Exception('Places autocomplete: $status');
    }

    final preds = (body['predictions'] as List? ?? const []);
    return preds.map((raw) {
      final p = raw as Map<String, dynamic>;
      final formatted = (p['structured_formatting'] as Map?) ?? const {};
      return PlacePrediction(
        placeId: p['place_id'] as String,
        primaryText: (formatted['main_text'] ?? '') as String,
        secondaryText: (formatted['secondary_text'] ?? '') as String,
        fullDescription: (p['description'] ?? '') as String,
        types: List<String>.from((p['types'] as List?) ?? const []),
      );
    }).toList(growable: false);
  }

  static Future<PlaceDetails?> details(String placeId) async {
    final params = <String, String>{
      'place_id': placeId,
      'key': AppConfig.googleMapsApiKey,
      'sessiontoken': _ensureSession(),
      'language': 'en',
      'fields': 'place_id,geometry,formatted_address,name,address_components',
    };

    final uri = Uri.parse(_detailsUrl).replace(queryParameters: params);
    final res = await http.get(uri).timeout(const Duration(seconds: 10));

    if (res.statusCode != 200) return null;

    final body = json.decode(res.body) as Map<String, dynamic>;
    if (body['status'] != 'OK') return null;

    final result = (body['result'] as Map?) ?? const {};
    final geometry = (result['geometry'] as Map?) ?? const {};
    final location = (geometry['location'] as Map?) ?? const {};
    final lat = (location['lat'] as num?)?.toDouble();
    final lng = (location['lng'] as num?)?.toDouble();
    if (lat == null || lng == null) return null;

    // Session ends once Details is called — reset for the next search.
    resetSession();

    String? houseNumber, street, suburb, city, postcode;
    final components = (result['address_components'] as List? ?? const []);
    for (final raw in components) {
      final c = raw as Map<String, dynamic>;
      final types = List<String>.from((c['types'] as List?) ?? const []);
      final long = (c['long_name'] ?? '') as String;
      if (long.isEmpty) continue;
      if (types.contains('street_number')) houseNumber = long;
      if (types.contains('route')) street = long;
      if (types.contains('sublocality') ||
          types.contains('sublocality_level_1')) {
        suburb ??= long;
      }
      if (types.contains('locality')) city ??= long;
      if (types.contains('postal_code')) postcode = long;
    }

    return PlaceDetails(
      placeId: placeId,
      lat: lat,
      lng: lng,
      formattedAddress: (result['formatted_address'] ?? '') as String,
      name: result['name'] as String?,
      houseNumber: houseNumber,
      street: street,
      suburb: suburb,
      city: city,
      postcode: postcode,
    );
  }
}
