// lib/services/device_guard.dart
//
// One phone per account for drivers, shoppers and merchants.
// Customers are never touched.
//
//   • On sign-in the phone "claims" the account (claim_device) and asks
//     Supabase to end every other login of that account.
//   • Every phone watches its account's row; when the row names another
//     phone, this phone signs itself out at once and says why.
//   • A 60-second check (main.dart) catches a missed live update.
//
// Needs step50_one_device.sql.

import 'dart:async';
import 'dart:math';

import 'package:efuride_app/l10n/app_strings.dart';
import 'package:efuride_app/main.dart' show globalNavigatorKey;
import 'package:efuride_app/utils/app_error.dart';
import 'package:efuride_app/utils/error_ui.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class DeviceGuard {
  DeviceGuard._();
  static final DeviceGuard instance = DeviceGuard._();

  static const _prefKey = 'kongo_device_id';

  /// Roles that may use only one phone at a time.
  static bool appliesTo(String role) =>
      role == 'driver' || role == 'shopper' || role == 'merchant';

  /// True while a sign-in is running: the watcher must not act yet.
  bool signingIn = false;

  String? _mine;
  String? _watchingUid;
  RealtimeChannel? _ch;
  bool _kicking = false;

  SupabaseClient get _db => Supabase.instance.client;

  Future<String> _deviceId() async {
    if (_mine != null) return _mine!;
    try {
      final p = await SharedPreferences.getInstance();
      var id = p.getString(_prefKey);
      if (id == null || id.length < 16) {
        final r = Random.secure();
        id = List.generate(
            24, (_) => r.nextInt(16).toRadixString(16)).join();
        await p.setString(_prefKey, id);
      }
      _mine = id;
    } catch (_) {
      // No storage: use an id that lasts until the app closes.
      final r = Random.secure();
      _mine = List.generate(24, (_) => r.nextInt(16).toRadixString(16)).join();
    }
    return _mine!;
  }

  /// This phone becomes the one phone; all other logins end.
  Future<void> claim() async {
    final uid = _db.auth.currentUser?.id;
    if (uid == null) return;
    try {
      final id = await _deviceId();
      final ok = await _db.rpc('claim_device', params: {'p_device': id});
      if (ok != true) return;
      try {
        await _db.auth.signOut(scope: SignOutScope.others);
      } catch (e) {
        debugPrint('device guard: sign out others failed: $e');
      }
      _watch(uid);
    } catch (e) {
      // step50 not run yet, or no connection: do not block the sign-in.
      debugPrint('device guard: claim failed: $e');
    }
  }

  /// Start watching for a restored session (app reopened).
  void startIfNeeded(String uid, String role) {
    if (signingIn) return;
    if (!appliesTo(role)) {
      stop();
      return;
    }
    if (_watchingUid == uid && _ch != null) return;
    _watch(uid);
  }

  void _watch(String uid) {
    _ch?.unsubscribe();
    _watchingUid = uid;
    _ch = _db
        .channel('device_$uid')
        .onPostgresChanges(
          event: PostgresChangeEvent.all,
          schema: 'public',
          table: 'active_devices',
          filter: PostgresChangeFilter(
              type: PostgresChangeFilterType.eq,
              column: 'user_id',
              value: uid),
          callback: (payload) async {
            final other = payload.newRecord['device_id']?.toString();
            if (other == null) return;
            if (other != await _deviceId()) _kick();
          },
        )
        .subscribe();
    check();
  }

  /// Ask the server who the one phone is. Quiet when offline.
  Future<void> check() async {
    final uid = _db.auth.currentUser?.id;
    if (uid == null || signingIn || _watchingUid != uid) return;
    try {
      final row = await _db
          .from('active_devices')
          .select('device_id')
          .eq('user_id', uid)
          .maybeSingle();
      final id = await _deviceId();
      // No record yet (signed in before this feature): leave the phone
      // alone. Only a new sign-in on another phone changes the record.
      if (row == null) return;
      if (row['device_id']?.toString() != id) _kick();
    } catch (_) {}
  }

  Future<void> _kick() async {
    if (_kicking) return;
    _kicking = true;
    stop();
    try {
      await _db.auth.signOut(scope: SignOutScope.local);
    } catch (_) {}
    Future.delayed(const Duration(milliseconds: 900), () {
      final ctx = globalNavigatorKey.currentContext;
      if (ctx != null) {
        ErrorUI.showSnack(
          ctx,
          AppError(
            title: tr('Signed in on another phone'),
            message: tr(
                'Your account was opened on another phone, so this one was signed out.'),
            icon: Icons.phonelink_lock_outlined,
          ),
        );
      }
      _kicking = false;
    });
  }

  void stop() {
    _ch?.unsubscribe();
    _ch = null;
    _watchingUid = null;
  }
}
