// lib/services/pricing_service.dart
//
// Prices for the country the user is in, in that country's currency.
// Set by ko!ngo admins (admin app → Pricing), stored in `country_pricing`.
//
//   final p = await PricingService.current();
//   final fare = p.rideFare(km: 7.2, multiplier: 1.0);
//
// Lookup order: this country → "US" row (any other country) →
// the old single app_settings row → built-in defaults.

import 'package:flutter/foundation.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'package:efuride_app/config/country_config.dart';

/// One way to pay ko!ngo when topping up the wallet in this country.
class TopupMethod {
  final String id; // mpesa, mtn_momo, eft, cash …
  final String name; // "M-Pesa"
  final String details; // where to pay, e.g. "Paybill 123456, account: phone"
  const TopupMethod(this.id, this.name, this.details);

  bool get isMobileMoney => !const {'eft', 'cash', 'bank'}.contains(id);

  static List<TopupMethod> listFrom(dynamic raw) {
    if (raw is! List) return const [];
    return [
      for (final m in raw)
        if (m is Map && (m['id'] ?? '').toString().isNotEmpty)
          TopupMethod(
            m['id'].toString(),
            (m['name'] ?? m['id']).toString(),
            (m['details'] ?? '').toString().trim(),
          ),
    ];
  }
}

class CountryPricing {
  final String countryCode;
  final double baseFare;
  final double perKmRate;
  final double minimumFare;
  final double surge;
  final double parcelSmall;
  final double parcelMedium;
  final double parcelLarge;
  final double parcelXl;
  final double fragileFee;
  final double urgentFee;
  final double shopperHourlyRate;
  final List<TopupMethod> topupMethods;

  /// Card payments switched on for this country (needs a card provider).
  final bool cardEnabled;

  /// Set by admin per country (step 21).
  final double driverCommissionPct;
  final double merchantCommissionPct;
  final double deliveryBaseFee;
  final double deliveryPerKm;
  final double groceryServiceFeePct;
  final double shopperTaskFee;

  /// How far from the customer shops and merchants are shown (km). Admin.
  final double serviceRadiusKm;

  /// Driver wallet balance under which a low-balance warning shows.
  /// 0 = not set: twice the minimum fare is used.
  final double driverLowBalance;

  double get lowBalanceLevel =>
      driverLowBalance > 0 ? driverLowBalance : minimumFare * 2;

  const CountryPricing({
    required this.countryCode,
    required this.baseFare,
    required this.perKmRate,
    required this.minimumFare,
    required this.surge,
    required this.parcelSmall,
    required this.parcelMedium,
    required this.parcelLarge,
    required this.parcelXl,
    required this.fragileFee,
    required this.urgentFee,
    required this.shopperHourlyRate,
    this.topupMethods = const [],
    this.cardEnabled = false,
    this.driverCommissionPct = 15,
    this.merchantCommissionPct = 15,
    this.deliveryBaseFee = 0,
    this.deliveryPerKm = 0,
    this.groceryServiceFeePct = 15,
    this.shopperTaskFee = 0,
    this.serviceRadiusKm = 15,
    this.driverLowBalance = 0,
  });

  /// Used only when nothing could be loaded at all.
  static const fallback = CountryPricing(
    countryCode: '',
    baseFare: 25,
    perKmRate: 12,
    minimumFare: 25,
    surge: 1,
    parcelSmall: 40,
    parcelMedium: 75,
    parcelLarge: 140,
    parcelXl: 225,
    fragileFee: 25,
    urgentFee: 40,
    shopperHourlyRate: 60,
    topupMethods: [
      TopupMethod('eft', 'Bank transfer', ''),
      TopupMethod('cash', 'Cash deposit', ''),
    ],
  );

  factory CountryPricing.fromRow(Map<String, dynamic> m,
      {CountryPricing base = fallback}) {
    double d(String k, double or) => (m[k] as num?)?.toDouble() ?? or;
    return CountryPricing(
      countryCode: (m['country_code'] ?? base.countryCode).toString(),
      baseFare: d('base_fare', base.baseFare),
      perKmRate: d('per_km_rate', base.perKmRate),
      minimumFare: d('minimum_fare', base.minimumFare),
      surge: d('surge_multiplier', base.surge),
      parcelSmall: d('parcel_small', base.parcelSmall),
      parcelMedium: d('parcel_medium', base.parcelMedium),
      parcelLarge: d('parcel_large', base.parcelLarge),
      parcelXl: d('parcel_xl', base.parcelXl),
      fragileFee: d('fragile_fee', base.fragileFee),
      urgentFee: d('urgent_fee', base.urgentFee),
      shopperHourlyRate: d('shopper_hourly_rate', base.shopperHourlyRate),
      topupMethods: TopupMethod.listFrom(m['topup_methods']).isNotEmpty
          ? TopupMethod.listFrom(m['topup_methods'])
          : base.topupMethods,
      cardEnabled: m['card_enabled'] == true,
      driverCommissionPct:
          d('driver_commission_pct', base.driverCommissionPct),
      merchantCommissionPct:
          d('merchant_commission_pct', base.merchantCommissionPct),
      deliveryBaseFee: d('delivery_base_fee', base.deliveryBaseFee),
      deliveryPerKm: d('delivery_per_km', base.deliveryPerKm),
      groceryServiceFeePct:
          d('grocery_service_fee_pct', base.groceryServiceFeePct),
      shopperTaskFee: d('shopper_task_fee', base.shopperTaskFee),
      serviceRadiusKm: d('service_radius_km', base.serviceRadiusKm),
      driverLowBalance: d('driver_low_balance', base.driverLowBalance),
    );
  }

  /// Ride fare: (base + km × rate) × surge × vehicle multiplier,
  /// never below the minimum fare.
  double rideFare({required double km, double multiplier = 1.0}) {
    final fare = (baseFare + km * perKmRate) * surge * multiplier;
    return fare < minimumFare ? minimumFare : fare;
  }
}

class PricingService {
  PricingService._();

  static CountryPricing? _cached;
  static String? _cachedFor;
  static DateTime? _cachedAt;

  /// Bumps every time the admin changes prices (or settings), so open
  /// screens can redraw at once. Listen with addListener.
  static final ValueNotifier<int> changes = ValueNotifier<int>(0);
  static RealtimeChannel? _live;

  /// Listens for admin price changes. Safe to call many times.
  static void startLive() {
    if (_live != null) return;
    try {
      final db = Supabase.instance.client;
      _live = db
          .channel('kongo_prices_live')
          .onPostgresChanges(
            event: PostgresChangeEvent.all,
            schema: 'public',
            table: 'country_pricing',
            callback: (_) => _refreshNow(),
          )
          .subscribe();
    } catch (e) {
      debugPrint('price live updates unavailable: $e');
    }
  }

  /// Stop listening (sign-out).
  static void stopLive() {
    try {
      _live?.unsubscribe();
    } catch (_) {}
    _live = null;
  }

  static Future<void> _refreshNow() async {
    await current(force: true);
    changes.value++;
  }

  /// Last prices loaded (or the built-in defaults). Never waits.
  static CountryPricing get last => _cached ?? CountryPricing.fallback;

  /// Prices for the user's current country. Cached for 2 minutes.
  static Future<CountryPricing> current({bool force = false}) async {
    final iso = CountryConfig.isoCode;
    startLive();
    final fresh = _cachedAt != null &&
        DateTime.now().difference(_cachedAt!) < const Duration(seconds: 30);
    if (!force && _cached != null && _cachedFor == iso && fresh) {
      return _cached!;
    }

    final db = Supabase.instance.client;
    CountryPricing? result;

    try {
      final rows = List<Map<String, dynamic>>.from(await db
          .from('country_pricing')
          .select()
          .inFilter('country_code', [iso, 'US'])
          .timeout(const Duration(seconds: 15)));
      Map<String, dynamic>? pick(String code) {
        for (final r in rows) {
          if (r['country_code'] == code && r['active'] != false) return r;
        }
        return null;
      }

      final row = pick(iso) ?? pick('US');
      if (row != null) result = CountryPricing.fromRow(row);
    } catch (e) {
      debugPrint('country_pricing not available: $e');
    }

    if (result == null) {
      try {
        final s = await db
            .from('app_settings')
            .select('base_fare, per_km_rate, minimum_fare, surge_multiplier')
            .eq('id', 1)
            .maybeSingle()
            .timeout(const Duration(seconds: 15));
        if (s != null) result = CountryPricing.fromRow(s);
      } catch (e) {
        debugPrint('app_settings pricing not available: $e');
      }
    }

    result ??= _cached ?? CountryPricing.fallback;
    _cached = result;
    _cachedFor = iso;
    _cachedAt = DateTime.now();
    return result;
  }
}
