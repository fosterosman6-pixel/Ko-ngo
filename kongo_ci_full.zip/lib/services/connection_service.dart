// lib/services/connection_service.dart
//
// Knows when the phone can't reach ko!ngo (no data, no Wi‑Fi, weak signal).
//   • Any network failure anywhere in the app marks it offline
//     (AppError.from calls reportOffline).
//   • While offline it checks every 5 seconds and comes back online by
//     itself; a bar at the top of every screen says so (OfflineBanner).
//   • Important buttons call ensureOnline() first, so people get a clear
//     "No internet" message at once instead of a long spinner.
// No extra packages: the check is a tiny request to our own server, so it
// works the same on Android, iOS and web.

import 'dart:async';

import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'package:efuride_app/l10n/app_strings.dart';

class ConnectionService {
  ConnectionService._();
  static final ConnectionService instance = ConnectionService._();

  /// true = we can reach the server.
  final ValueNotifier<bool> online = ValueNotifier<bool>(true);

  Timer? _retry;
  bool _checking = false;

  /// Called when a request failed because of the network.
  void reportOffline() {
    if (online.value) online.value = false;
    _retry ??= Timer.periodic(const Duration(seconds: 5), (_) => check());
  }

  /// One quick request to the server. Returns true when it answered.
  Future<bool> check({Duration timeout = const Duration(seconds: 4)}) async {
    if (_checking) return online.value;
    _checking = true;
    try {
      await Supabase.instance.client
          .from('country_pricing')
          .select('country_code')
          .limit(1)
          .timeout(timeout);
      _setOnline();
      return true;
    } on PostgrestException {
      // The server answered (even with an error): we are online.
      _setOnline();
      return true;
    } catch (_) {
      if (online.value) online.value = false;
      _retry ??= Timer.periodic(const Duration(seconds: 5), (_) => check());
      return false;
    } finally {
      _checking = false;
    }
  }

  void _setOnline() {
    _retry?.cancel();
    _retry = null;
    if (!online.value) online.value = true;
  }

  /// Use before an important action. When offline it checks once more;
  /// if still offline it tells the person and returns false.
  Future<bool> ensureOnline(BuildContext context) async {
    if (online.value) return true;
    final ok = await check(timeout: const Duration(seconds: 3));
    if (ok) return true;
    if (context.mounted) {
      ScaffoldMessenger.maybeOf(context)?.showSnackBar(SnackBar(
        behavior: SnackBarBehavior.floating,
        backgroundColor: const Color(0xFF1A1A1A),
        content: Row(
          children: [
            const Icon(Icons.wifi_off_rounded, color: Colors.white, size: 20),
            const SizedBox(width: 10),
            Expanded(
              child: Text(
                tr('You\'re offline. Check your data or Wi‑Fi and try again.'),
                style: const TextStyle(color: Colors.white),
              ),
            ),
          ],
        ),
      ));
    }
    return false;
  }
}

/// Thin bar at the top of every screen while there's no connection.
class OfflineBanner extends StatelessWidget {
  final Widget child;
  const OfflineBanner({super.key, required this.child});

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<bool>(
      valueListenable: ConnectionService.instance.online,
      builder: (context, isOnline, _) {
        return Stack(
          children: [
            child,
            if (!isOnline)
              Positioned(
                left: 0,
                right: 0,
                top: 0,
                child: Material(
                  color: const Color(0xFF1A1A1A),
                  child: SafeArea(
                    bottom: false,
                    child: InkWell(
                      onTap: () => ConnectionService.instance.check(),
                      child: Padding(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 16, vertical: 8),
                        child: Row(
                          children: [
                            const Icon(Icons.wifi_off_rounded,
                                color: Colors.white, size: 18),
                            const SizedBox(width: 10),
                            Expanded(
                              child: Text(
                                tr('No internet. Reconnecting…'),
                                style: const TextStyle(
                                    color: Colors.white,
                                    fontSize: 13.5,
                                    fontWeight: FontWeight.w600),
                              ),
                            ),
                            const SizedBox(
                              width: 14,
                              height: 14,
                              child: CircularProgressIndicator(
                                  strokeWidth: 2, color: Colors.white70),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ),
          ],
        );
      },
    );
  }
}
