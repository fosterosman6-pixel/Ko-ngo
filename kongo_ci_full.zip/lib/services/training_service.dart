// lib/services/training_service.dart

import 'package:flutter/foundation.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'package:efuride_app/l10n/app_strings.dart' show currentAppLang;

/// Text for the driver's language when the module has a translation for
/// it (training_modules.translations = {"fr": {"title": …}}), else English.
String _pick(Map<String, dynamic> m, String field) {
  final base = (m[field] ?? '').toString();
  try {
    final code = currentAppLang.code;
    final t = m['translations'];
    if (t is Map && t[code] is Map) {
      final v = (t[code] as Map)[field]?.toString();
      if (v != null && v.trim().isNotEmpty) return v;
    }
  } catch (_) {}
  return base;
}

class TrainingModule {
  final int id;
  final String slug;
  final String title;
  final String? description;
  final String? content;
  final String? videoUrl;
  final int durationMinutes;
  final bool isRequired;
  final int displayOrder;

  const TrainingModule({
    required this.id,
    required this.slug,
    required this.title,
    this.description,
    this.content,
    this.videoUrl,
    required this.durationMinutes,
    required this.isRequired,
    required this.displayOrder,
  });

  factory TrainingModule.fromMap(Map<String, dynamic> m) => TrainingModule(
        id: (m['id'] as num).toInt(),
        slug: (m['slug'] ?? '').toString(),
        title: _pick(m, 'title'),
        description: m['description'] == null ? null : _pick(m, 'description'),
        content: m['content'] == null ? null : _pick(m, 'content'),
        videoUrl: m['video_url']?.toString(),
        durationMinutes: (m['duration_minutes'] as num?)?.toInt() ?? 5,
        isRequired: m['is_required'] == true,
        displayOrder: (m['display_order'] as num?)?.toInt() ?? 0,
      );
}

class QuizQuestion {
  final int id;
  final int moduleId;
  final String question;
  final String optionA;
  final String optionB;
  final String optionC;
  final String optionD;
  final String correctOption;

  const QuizQuestion({
    required this.id,
    required this.moduleId,
    required this.question,
    required this.optionA,
    required this.optionB,
    required this.optionC,
    required this.optionD,
    required this.correctOption,
  });

  factory QuizQuestion.fromMap(Map<String, dynamic> m) => QuizQuestion(
        id: (m['id'] as num).toInt(),
        moduleId: (m['module_id'] as num).toInt(),
        question: _pick(m, 'question'),
        optionA: _pick(m, 'option_a'),
        optionB: _pick(m, 'option_b'),
        optionC: _pick(m, 'option_c'),
        optionD: _pick(m, 'option_d'),
        correctOption: (m['correct_option'] ?? 'a').toString(),
      );
}

class TrainingProgress {
  final int moduleId;
  final String status;
  final int? quizScore;

  const TrainingProgress({
    required this.moduleId,
    required this.status,
    this.quizScore,
  });

  factory TrainingProgress.fromMap(Map<String, dynamic> m) => TrainingProgress(
        moduleId: (m['module_id'] as num).toInt(),
        status: (m['status'] ?? 'not_started').toString(),
        quizScore: (m['quiz_score'] as num?)?.toInt(),
      );
}

class TrainingSnapshot {
  final List<TrainingModule> modules;
  final Map<int, TrainingProgress> progress;
  final int requiredCompleted;
  final int requiredTotal;

  const TrainingSnapshot({
    required this.modules,
    required this.progress,
    required this.requiredCompleted,
    required this.requiredTotal,
  });

  bool get isCertified =>
      requiredTotal > 0 && requiredCompleted >= requiredTotal;

  double get progressFraction =>
      requiredTotal == 0 ? 0 : requiredCompleted / requiredTotal;

  TrainingProgress? progressFor(int moduleId) => progress[moduleId];
}

class TrainingService {
  TrainingService._();
  static final instance = TrainingService._();

  /// Load every active module + this driver's progress in one go.
  Future<TrainingSnapshot> load() async {
    final userId = Supabase.instance.client.auth.currentUser?.id;
    if (userId == null) {
      return const TrainingSnapshot(
        modules: [],
        progress: {},
        requiredCompleted: 0,
        requiredTotal: 0,
      );
    }

    // Modules
    final rawModules = await Supabase.instance.client
        .from('training_modules')
        .select()
        .order('display_order', ascending: true);

    final modules = (rawModules as List)
        .map((m) => TrainingModule.fromMap(Map<String, dynamic>.from(m)))
        .toList();

    // Progress (only this driver's rows)
    List progressRows = const [];
    try {
      progressRows = await Supabase.instance.client
          .from('driver_training_progress')
          .select()
          .eq('driver_id', userId);
    } catch (e) {
      debugPrint('progress fetch failed: $e');
    }

    final progress = <int, TrainingProgress>{};
    for (final p in progressRows) {
      final row = Map<String, dynamic>.from(p);
      final tp = TrainingProgress.fromMap(row);
      progress[tp.moduleId] = tp;
    }

    // Counts
    final requiredModules =
        modules.where((m) => m.isRequired).toList();
    var requiredCompleted = 0;
    for (final m in requiredModules) {
      if (progress[m.id]?.status == 'completed') {
        requiredCompleted++;
      }
    }

    return TrainingSnapshot(
      modules: modules,
      progress: progress,
      requiredCompleted: requiredCompleted,
      requiredTotal: requiredModules.length,
    );
  }

  /// Fetch the quiz questions for a module.
  Future<List<QuizQuestion>> loadQuiz(int moduleId) async {
    final rows = await Supabase.instance.client
        .from('training_quiz_questions')
        .select()
        .eq('module_id', moduleId)
        .order('display_order', ascending: true);

    return (rows as List)
        .map((r) => QuizQuestion.fromMap(Map<String, dynamic>.from(r)))
        .toList();
  }

  /// Mark a module as started.
  Future<void> markStarted(int moduleId) async {
    final userId = Supabase.instance.client.auth.currentUser?.id;
    if (userId == null) return;

    try {
      // Upsert — if a row exists for this (driver, module), update only if
      // it was still not_started.
      final existing = await Supabase.instance.client
          .from('driver_training_progress')
          .select('id, status')
          .eq('driver_id', userId)
          .eq('module_id', moduleId)
          .maybeSingle();

      if (existing == null) {
        await Supabase.instance.client
            .from('driver_training_progress')
            .insert({
          'driver_id': userId,
          'module_id': moduleId,
          'status': 'in_progress',
          'started_at': DateTime.now().toUtc().toIso8601String(),
        });
      } else if (existing['status'] != 'completed') {
        await Supabase.instance.client
            .from('driver_training_progress')
            .update({
          'status': 'in_progress',
          'started_at': DateTime.now().toUtc().toIso8601String(),
        }).eq('id', existing['id']);
      }
    } catch (e) {
      debugPrint('markStarted failed: $e');
    }
  }

  /// Save the quiz score. 80%+ marks the module completed.
  Future<void> markCompleted({
    required int moduleId,
    required int scorePercent,
  }) async {
    final userId = Supabase.instance.client.auth.currentUser?.id;
    if (userId == null) return;

    final passed = scorePercent >= 80;

    final existing = await Supabase.instance.client
        .from('driver_training_progress')
        .select('id')
        .eq('driver_id', userId)
        .eq('module_id', moduleId)
        .maybeSingle();

    final payload = {
      'driver_id': userId,
      'module_id': moduleId,
      'status': passed ? 'completed' : 'in_progress',
      'quiz_score': scorePercent,
      if (passed)
        'completed_at': DateTime.now().toUtc().toIso8601String(),
    };

    if (existing == null) {
      await Supabase.instance.client
          .from('driver_training_progress')
          .insert(payload);
    } else {
      await Supabase.instance.client
          .from('driver_training_progress')
          .update(payload)
          .eq('id', existing['id']);
    }
  }

  /// Convenience: is this driver certified to go online?
  Future<bool> isCertified() async {
    final snap = await load();
    return snap.isCertified;
  }
}
