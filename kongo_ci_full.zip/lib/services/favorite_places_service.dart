import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:efuride_app/utils/log.dart';
import 'package:efuride_app/utils/search_match.dart';

class FavoritePlacesService {
  FavoritePlacesService._();
  static const _tag = 'FavoritePlaces';
  static final _client = Supabase.instance.client;

  /// Adjust these two constants if your DB uses British spellings.
  static const _favoritesTable = 'favorite_places';
  static const _recentsTable = 'recent_destinations';

  // ============================================================
  // FAVORITES
  // ============================================================
  static Future<List<Map<String, dynamic>>> listFavorites() async {
    final user = _client.auth.currentUser;
    if (user == null) return [];
    try {
      final rows = await _client
          .from(_favoritesTable)
          .select()
          .eq('user_id', user.id)
          .order('created_at', ascending: true);
      return List<Map<String, dynamic>>.from(rows);
    } catch (e) {
      Log.e(_tag, 'listFavorites failed', e);
      return [];
    }
  }

  /// Words people use for "Home" in the app's languages.
  static const _homeWords = [
    'home', 'maison', 'nyumba', 'kaya', 'ndako', 'huis', 'thuis'
  ];

  static bool isHomeLabel(String label) {
    final x = searchNorm(label);
    return _homeWords.any(x.contains);
  }

  /// Saved places that fit [query] (all of them when it is empty), with
  /// Home first. Typing "home" also finds a place saved as "Maison".
  static List<Map<String, dynamic>> filter(
      List<Map<String, dynamic>> all, String query) {
    final q = query.trim();
    final qn = searchNorm(q);
    final asksHome = qn.isNotEmpty && _homeWords.any((w) => w.startsWith(qn));
    final out = all.where((r) {
      if (r['lat'] == null || r['lng'] == null) return false;
      final label = (r['label'] ?? r['name'] ?? '').toString();
      if (q.isEmpty) return true;
      if (asksHome && isHomeLabel(label)) return true;
      return searchMatches(q, [label, r['address']?.toString()]);
    }).toList();
    out.sort((a, b) {
      final ah = isHomeLabel((a['label'] ?? '').toString()) ? 0 : 1;
      final bh = isHomeLabel((b['label'] ?? '').toString()) ? 0 : 1;
      return ah.compareTo(bh);
    });
    return out;
  }

  static Future<void> saveFavorite({
    required String label,
    required String address,
    required double lat,
    required double lng,
  }) async {
    final user = _client.auth.currentUser;
    if (user == null) return;

    try {
      await _client.from(_favoritesTable).upsert({
        'user_id': user.id,
        'label': label,
        'name': label,
        'address': address,
        'lat': lat,
        'lng': lng,
        'updated_at': DateTime.now().toUtc().toIso8601String(),
      }, onConflict: 'user_id,label');
    } catch (e) {
      Log.e(_tag, 'saveFavorite failed', e);
      rethrow;
    }
  }

  static Future<void> deleteFavorite(int id) async {
    try {
      await _client.from(_favoritesTable).delete().eq('id', id);
    } catch (e) {
      Log.e(_tag, 'deleteFavorite failed', e);
      rethrow;
    }
  }

  // ============================================================
  // RECENTS
  // ============================================================
  static Future<List<Map<String, dynamic>>> listRecents({
    int limit = 5,
  }) async {
    final user = _client.auth.currentUser;
    if (user == null) return [];
    try {
      final rows = await _client
          .from(_recentsTable)
          .select()
          .eq('user_id', user.id)
          .order('last_used_at', ascending: false)
          .limit(limit);
      return List<Map<String, dynamic>>.from(rows);
    } catch (e) {
      Log.e(_tag, 'listRecents failed', e);
      return [];
    }
  }

  static Future<void> recordRecent({
    required String address,
    required double lat,
    required double lng,
  }) async {
    final user = _client.auth.currentUser;
    if (user == null) return;

    try {
      await _client.from(_recentsTable).upsert({
        'user_id': user.id,
        'address': address,
        'lat': lat,
        'lng': lng,
        'last_used_at': DateTime.now().toUtc().toIso8601String(),
      }, onConflict: 'user_id,address');
    } catch (e) {
      Log.e(_tag, 'recordRecent failed', e);
    }
  }
}
