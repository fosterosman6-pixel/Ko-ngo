﻿import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:geolocator/geolocator.dart';
import 'package:latlong2/latlong.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

/// Pushes the driver's live location to Supabase.
///
/// Two channels are updated:
///   1. `profiles.lat/lng`  — always, while the driver is online
///      (used by the customer's "nearby drivers" markers)
///   2. `rides.driver_lat/lng` — only while the driver has an active ride
///      (used by the customer's ETA + polyline)
///
/// Call [start] when the driver goes online, and [stop] when they go offline.
class DriverLocationService {
  DriverLocationService._();
  static final DriverLocationService instance = DriverLocationService._();

  StreamSubscription<Position>? _positionSub;
  Timer? _profilePushTimer;
  Timer? _ridePushTimer;

  LatLng? _lastProfilePush;
  LatLng? _lastRidePush;

  String? _activeRideId;

  /// Minimum distance the driver must have moved before pushing again.
  static const double _minProfileMoveMeters = 15;
  static const double _minRideMoveMeters = 10;

  /// Force-push heartbeat even if stationary.
  static const Duration _profileHeartbeat = Duration(seconds: 30);
  static const Duration _rideHeartbeat = Duration(seconds: 10);

  bool get isRunning => _positionSub != null;

  /// Begin streaming the driver's location.
  Future<void> start() async {
    if (_positionSub != null) return;

    final hasPermission = await _ensurePermission();
    if (!hasPermission) {
      debugPrint('[DriverLocationService] location permission denied');
      return;
    }

    const settings = LocationSettings(
      accuracy: LocationAccuracy.high,
      distanceFilter: 5,
    );

    _positionSub = Geolocator.getPositionStream(locationSettings: settings)
        .listen(_onPosition, onError: (e) {
      debugPrint('[DriverLocationService] stream error: $e');
    });

    _profilePushTimer = Timer.periodic(_profileHeartbeat, (_) async {
      if (_lastProfilePush != null) {
        await _pushProfile(_lastProfilePush!);
      }
    });

    _ridePushTimer = Timer.periodic(_rideHeartbeat, (_) async {
      if (_activeRideId != null && _lastRidePush != null) {
        await _pushRide(_lastRidePush!);
      }
    });
  }

  Future<void> stop() async {
    await _positionSub?.cancel();
    _positionSub = null;
    _profilePushTimer?.cancel();
    _profilePushTimer = null;
    _ridePushTimer?.cancel();
    _ridePushTimer = null;
    _activeRideId = null;
    _lastProfilePush = null;
    _lastRidePush = null;
  }

  /// Call whenever the driver accepts / starts / ends a ride.
  void setActiveRide(String? rideId) {
    _activeRideId = rideId;
    if (rideId != null && _lastRidePush != null) {
      _pushRide(_lastRidePush!);
    }
  }

  // ---------------------------------------------------------------------------
  // Internals
  // ---------------------------------------------------------------------------

  Future<bool> _ensurePermission() async {
    bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) return false;

    LocationPermission permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
    }
    return permission == LocationPermission.always ||
        permission == LocationPermission.whileInUse;
  }

  void _onPosition(Position position) {
    final loc = LatLng(position.latitude, position.longitude);

    final shouldProfilePush = _lastProfilePush == null ||
        Geolocator.distanceBetween(
              _lastProfilePush!.latitude,
              _lastProfilePush!.longitude,
              loc.latitude,
              loc.longitude,
            ) >=
            _minProfileMoveMeters;

    if (shouldProfilePush) _pushProfile(loc);

    if (_activeRideId != null) {
      final shouldRidePush = _lastRidePush == null ||
          Geolocator.distanceBetween(
                _lastRidePush!.latitude,
                _lastRidePush!.longitude,
                loc.latitude,
                loc.longitude,
              ) >=
              _minRideMoveMeters;

      if (shouldRidePush) _pushRide(loc);
    }
  }

  Future<void> _pushProfile(LatLng loc) async {
    final userId = Supabase.instance.client.auth.currentUser?.id;
    if (userId == null) return;
    try {
      await Supabase.instance.client.from('profiles').update({
        'lat': loc.latitude,
        'lng': loc.longitude,
        'last_location_update': DateTime.now().toIso8601String(),
      }).eq('id', userId);
      _lastProfilePush = loc;
      debugPrint('[DriverLocationService] profile push ok');
    } catch (e) {
      debugPrint('[DriverLocationService] profile push failed: $e');
    }
  }

  Future<void> _pushRide(LatLng loc) async {
    final rideId = _activeRideId;
    if (rideId == null) return;
    try {
      await Supabase.instance.client.from('rides').update({
        'driver_lat': loc.latitude,
        'driver_lng': loc.longitude,
        'driver_location_updated_at': DateTime.now().toIso8601String(),
      }).eq('id', rideId);
      _lastRidePush = loc;
      debugPrint('[DriverLocationService] ride push ok -> $rideId');
    } catch (e) {
      debugPrint('[DriverLocationService] ride push failed: $e');
    }
  }
}
