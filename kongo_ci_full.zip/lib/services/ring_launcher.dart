// lib/services/ring_launcher.dart
//
// "Display over other apps": when a ride request arrives and the app is in
// the background, ko!ngo opens itself on top of whatever the driver is doing
// and shows the request. Android only allows this when the driver has
// switched on "Display over other apps" for ko!ngo (Settings → Apps →
// ko!ngo), so the first step is to send the driver to that page.
//
// Flow: the background push handler calls wakeApp(); the app opens; the main
// app calls consumePending() and shows the request like a tapped ring.
// Needs the android_intent_plus package and the SYSTEM_ALERT_WINDOW
// permission in AndroidManifest.xml.

import 'dart:io' show Platform;

import 'package:android_intent_plus/android_intent.dart';
import 'package:android_intent_plus/flag.dart';
import 'package:flutter/foundation.dart' show kIsWeb, debugPrint;
import 'package:shared_preferences/shared_preferences.dart';

import 'package:efuride_app/services/ring_service.dart';

class RingLauncher {
  RingLauncher._();

  /// The app's Android package (applicationId). Must match
  /// android/app/build.gradle(.kts).
  static const _appId = 'com.example.efuride_deli_app';
  static const _prefKey = 'kongo_pending_ring';
  static const _maxAge = Duration(seconds: 75);

  static bool get _android => !kIsWeb && Platform.isAndroid;

  /// Runs in the background push handler: remember the request, then bring
  /// the app to the front. Silent if Android does not allow it.
  static Future<void> wakeApp(String payload) async {
    if (!_android || payload.isEmpty) return;
    try {
      final p = await SharedPreferences.getInstance();
      await p.setString(
          _prefKey, '$payload|${DateTime.now().millisecondsSinceEpoch}');
    } catch (e) {
      debugPrint('ring launcher: save failed: $e');
    }
    try {
      await const AndroidIntent(
        action: 'android.intent.action.MAIN',
        category: 'android.intent.category.LAUNCHER',
        package: _appId,
        flags: <int>[Flag.FLAG_ACTIVITY_NEW_TASK],
      ).launch();
    } catch (e) {
      debugPrint('ring launcher: open app failed: $e');
    }
  }

  /// Runs in the main app (start and resume): a request that woke the app
  /// is shown like a tapped ring.
  static Future<void> consumePending() async {
    if (!_android) return;
    try {
      final p = await SharedPreferences.getInstance();
      await p.reload(); // written by the background isolate
      final raw = p.getString(_prefKey);
      if (raw == null || raw.isEmpty) return;
      await p.remove(_prefKey);
      final cut = raw.lastIndexOf('|');
      if (cut <= 0) return;
      final payload = raw.substring(0, cut);
      final at = int.tryParse(raw.substring(cut + 1)) ?? 0;
      final age = DateTime.now()
          .difference(DateTime.fromMillisecondsSinceEpoch(at));
      if (age > _maxAge) return;
      pendingRideFromNotification.value = payload;
    } catch (e) {
      debugPrint('ring launcher: read failed: $e');
    }
  }

  /// Opens the phone's "Display over other apps" page for ko!ngo.
  static Future<void> openOverlaySettings() async {
    if (!_android) return;
    try {
      await const AndroidIntent(
        action: 'android.settings.action.MANAGE_OVERLAY_PERMISSION',
        data: 'package:$_appId',
      ).launch();
    } catch (e) {
      debugPrint('ring launcher: settings failed: $e');
    }
  }
}

/// Remembers the last few steps of a push that reached this phone, so the
/// driver (or ko!ngo support) can see where a ring stopped:
/// Settings → "Check last ring".
class PushDiag {
  PushDiag._();
  static const _key = 'kongo_push_diag';

  static Future<void> note(String step) async {
    try {
      final p = await SharedPreferences.getInstance();
      await p.reload();
      final list = p.getStringList(_key) ?? <String>[];
      list.add('${DateTime.now().toIso8601String().substring(0, 19)}  $step');
      while (list.length > 12) {
        list.removeAt(0);
      }
      await p.setStringList(_key, list);
    } catch (_) {}
  }

  static Future<List<String>> read() async {
    try {
      final p = await SharedPreferences.getInstance();
      await p.reload();
      return p.getStringList(_key) ?? <String>[];
    } catch (_) {
      return <String>[];
    }
  }
}
