// lib/services/driver_location_service.dart

import 'dart:async';
import 'package:flutter/foundation.dart'
    show kIsWeb, defaultTargetPlatform, TargetPlatform;
import 'package:geolocator/geolocator.dart';
import 'package:latlong2/latlong.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:efuride_app/utils/log.dart';

/// Pushes the driver's live location to Supabase.
///
/// Two channels are updated:
///   1. `profiles.lat/lng` — always, while the driver is online.
///      Used by the customer's "nearby drivers" markers.
///   2. `rides.driver_lat/lng` — only while the driver has an active ride.
///      Used by the customer's ETA + polyline.
///
/// Call [start] when the driver goes online, [stop] when they go offline.
class DriverLocationService {
  DriverLocationService._();
  static final DriverLocationService instance = DriverLocationService._();
  static const _tag = 'DriverLocation';

  StreamSubscription<Position>? _positionSub;
  Timer? _profilePushTimer;
  Timer? _ridePushTimer;

  LatLng? _lastProfilePush;
  LatLng? _lastRidePush;

  String? _activeRideId;

  bool _starting = false;

  // Minimum movement before pushing again.
  // (GPS gives about one fix per second; sending every fix while waiting
  // would only add server load, so small moves are batched.)
  static const double _minProfileMoveMeters = 5;
  static const double _minRideMoveMeters = 3;

  // Force-push heartbeat when stationary.
  static const Duration _profileHeartbeat = Duration(seconds: 10);
  static const Duration _rideHeartbeat = Duration(seconds: 3);

  bool get isRunning => _positionSub != null;

  // ============================================================
  // LIFECYCLE
  // ============================================================
  Future<void> start() async {
    if (_positionSub != null) return;
    if (_starting) return;
    _starting = true;

    try {
      final result = await _ensurePermission();
      if (result != _PermissionResult.granted) {
        Log.w(_tag, 'location permission not granted ($result) — '
            'service not started');
        return;
      }

      // Every GPS fix (about once a second), no minimum distance.
      final LocationSettings settings =
          !kIsWeb && defaultTargetPlatform == TargetPlatform.android
              ? AndroidSettings(
                  accuracy: LocationAccuracy.bestForNavigation,
                  distanceFilter: 0,
                  intervalDuration: const Duration(milliseconds: 1000),
                )
              : const LocationSettings(
                  accuracy: LocationAccuracy.bestForNavigation,
                  distanceFilter: 0,
                );

      _positionSub = Geolocator.getPositionStream(locationSettings: settings)
          .listen(
        _onPosition,
        onError: (e) => Log.e(_tag, 'position stream error', e),
      );

      _profilePushTimer = Timer.periodic(_profileHeartbeat, (_) async {
        if (_positionSub == null) return;
        final last = _lastProfilePush;
        if (last != null) await _pushProfile(last);
      });

      _ridePushTimer = Timer.periodic(_rideHeartbeat, (_) async {
        if (_positionSub == null) return;
        final rideId = _activeRideId;
        final last = _lastKnown ?? _lastRidePush;
        if (rideId != null && last != null) await _pushRide(last);
      });

      Log.i(_tag, 'started');
    } finally {
      _starting = false;
    }
  }

  Future<void> stop() async {
    await _positionSub?.cancel();
    _positionSub = null;
    _profilePushTimer?.cancel();
    _profilePushTimer = null;
    _ridePushTimer?.cancel();
    _ridePushTimer = null;
    _activeRideId = null;
    _lastProfilePush = null;
    _lastRidePush = null;
    Log.i(_tag, 'stopped');
  }

  /// Full stop + restart. Use when the app resumes from background and the
  /// underlying stream may have silently died (Android Doze).
  Future<void> restart() async {
    final wasRunning = isRunning;
    if (!wasRunning) return;
    Log.i(_tag, 'restarting…');
    await stop();
    await start();
  }

  /// Called whenever the driver accepts / starts / ends a ride.
  void setActiveRide(String? rideId) {
    _activeRideId = rideId;
    // Send where the driver is right away, so the customer sees the car
    // and the route as soon as the trip is accepted.
    final here = _lastKnown ?? _lastRidePush ?? _lastProfilePush;
    if (rideId != null && here != null) {
      _pushRide(here);
    }
    Log.i(_tag, 'active ride = ${rideId ?? 'none'}');
  }

  // ============================================================
  // INTERNALS
  // ============================================================
  Future<_PermissionResult> _ensurePermission() async {
    final serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) return _PermissionResult.serviceDisabled;

    LocationPermission permission = await Geolocator.checkPermission();

    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
    }

    if (permission == LocationPermission.deniedForever) {
      return _PermissionResult.deniedForever;
    }
    if (permission == LocationPermission.denied) {
      return _PermissionResult.denied;
    }

    return _PermissionResult.granted;
  }

  /// Latest GPS fix, whether or not it was sent yet.
  LatLng? _lastKnown;

  void _onPosition(Position position) {
    final loc = LatLng(position.latitude, position.longitude);
    _lastKnown = loc;

    final shouldProfilePush = _lastProfilePush == null ||
        Geolocator.distanceBetween(
              _lastProfilePush!.latitude,
              _lastProfilePush!.longitude,
              loc.latitude,
              loc.longitude,
            ) >=
            _minProfileMoveMeters;

    if (shouldProfilePush) _pushProfile(loc);

    if (_activeRideId != null) {
      final shouldRidePush = _lastRidePush == null ||
          Geolocator.distanceBetween(
                _lastRidePush!.latitude,
                _lastRidePush!.longitude,
                loc.latitude,
                loc.longitude,
              ) >=
              _minRideMoveMeters;

      if (shouldRidePush) _pushRide(loc);
    }
  }

  Future<void> _pushProfile(LatLng loc) async {
    final userId = Supabase.instance.client.auth.currentUser?.id;
    if (userId == null) return;
    try {
      await Supabase.instance.client.from('profiles').update({
        'lat': loc.latitude,
        'lng': loc.longitude,
        'last_location_update':
            DateTime.now().toUtc().toIso8601String(),
      }).eq('id', userId);
      _lastProfilePush = loc;
    } catch (e) {
      Log.e(_tag, 'profile push failed', e);
    }
  }

  Future<void> _pushRide(LatLng loc) async {
    final rideId = _activeRideId;
    if (rideId == null) return;
    try {
      await Supabase.instance.client.from('rides').update({
        'driver_lat': loc.latitude,
        'driver_lng': loc.longitude,
        'driver_location_updated_at':
            DateTime.now().toUtc().toIso8601String(),
      }).eq('id', rideId);
      _lastRidePush = loc;
    } catch (e) {
      Log.e(_tag, 'ride push failed', e);
    }
  }
}

enum _PermissionResult {
  granted,
  denied,
  deniedForever,
  serviceDisabled,
}
