// lib/services/photo_check_service.dart
//
// Weekly live selfie check for drivers. The server (step51) picks a random
// moment each week; until the driver sends a selfie the app will not let
// them go online. Any failure here means "not due": a bad connection must
// never lock a driver out.

import 'dart:typed_data';

import 'package:flutter/foundation.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class PhotoCheckService {
  PhotoCheckService._();

  static SupabaseClient get _db => Supabase.instance.client;

  /// True when this driver must send a selfie now.
  static Future<bool> isDue() async {
    try {
      final r = await _db
          .rpc('my_photo_check_due')
          .timeout(const Duration(seconds: 8));
      return r == true;
    } catch (e) {
      debugPrint('photo check: could not ask the server: $e');
      return false;
    }
  }

  /// Uploads the selfie and records it. Throws when it fails, so the screen
  /// can say so.
  static Future<void> submit(Uint8List bytes) async {
    final uid = _db.auth.currentUser?.id;
    if (uid == null) throw StateError('Not signed in');
    final path = '$uid/livecheck-${DateTime.now().millisecondsSinceEpoch}.jpg';
    await _db.storage.from('driver_documents').uploadBinary(
          path,
          bytes,
          fileOptions:
              const FileOptions(contentType: 'image/jpeg', upsert: false),
        );
    await _db.rpc('submit_photo_check', params: {'p_path': path});
  }
}
