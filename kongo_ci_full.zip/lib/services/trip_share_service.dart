import 'dart:math';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:efuride_app/utils/log.dart';

class TripShareService {
  TripShareService._();
  static const _tag = 'TripShare';
  static final _client = Supabase.instance.client;

  /// Base URL for the public trip viewer.
  /// Update this if your hosted viewer is elsewhere.
  static const String _baseUrl = 'https://efuride.app/trip';

  // ============================================================
  // CREATE
  // ============================================================
  static Future<String?> createShareLink({
    required String rideId,
    Duration validity = const Duration(hours: 4),
  }) async {
    final user = _client.auth.currentUser;
    if (user == null) return null;

    for (var attempt = 0; attempt < 5; attempt++) {
      final code = _generateCode();
      try {
        await _client.from('trip_share_links').insert({
          'ride_id': rideId,
          'share_code': code,
          'created_by': user.id,
          'expires_at':
              DateTime.now().toUtc().add(validity).toIso8601String(),
          'revoked': false,
          'created_at': DateTime.now().toUtc().toIso8601String(),
        });
        return code;
      } on PostgrestException catch (e) {
        final msg = e.message.toLowerCase();
        // Duplicate share code — retry with a new code.
        if (msg.contains('share_code') && msg.contains('duplicate')) {
          continue;
        }
        // Any other error — abort and log.
        Log.e(_tag, 'createShareLink failed', e);
        return null;
      } catch (e) {
        Log.e(_tag, 'createShareLink failed', e);
        return null;
      }
    }

    Log.w(_tag, 'exhausted retries for code collision');
    return null;
  }

  // ============================================================
  // REVOKE
  // ============================================================
  static Future<void> revokeAllForRide(String rideId) async {
    if (rideId.isEmpty) return;
    try {
      await _client
          .from('trip_share_links')
          .update({
            'revoked': true,
            'revoked_at': DateTime.now().toUtc().toIso8601String(),
          })
          .eq('ride_id', rideId)
          .eq('revoked', false);
    } catch (e) {
      Log.e(_tag, 'revokeAllForRide failed', e);
    }
  }

  // ============================================================
  // URL
  // ============================================================
  static String buildUrl(String code) => '$_baseUrl/$code';

  // ============================================================
  // INTERNALS
  // ============================================================
  static String _generateCode() {
    const chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
    final rnd = Random.secure();
    final buf = StringBuffer();
    for (var i = 0; i < 8; i++) {
      buf.write(chars[rnd.nextInt(chars.length)]);
    }
    return buf.toString();
  }
}
