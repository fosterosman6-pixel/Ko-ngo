// lib/services/google_maps_service.dart
//
// ko!ngo · single entry point for Google Maps data:
//   • autocomplete  – place search suggestions
//   • details       – coordinates + parsed address for a suggestion
//   • reverseGeocode – address for a map point
//   • route         – road route, distance, ETA and turn-by-turn steps
//
// All calls go through the `google-maps` Supabase Edge Function, which
// holds the server key. This works the same on Android, iOS and web.

import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/foundation.dart' show debugPrint;
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'package:efuride_app/config/country_config.dart';

// ════════════════════════════════════════════════════════════════
// MODELS
// ════════════════════════════════════════════════════════════════

/// One autocomplete suggestion.
class PlacePrediction {
  final String placeId;
  final String primaryText;
  final String secondaryText;
  final String fullDescription;
  final List<String> types;
  final double? distanceKm;

  const PlacePrediction({
    required this.placeId,
    required this.primaryText,
    required this.secondaryText,
    required this.fullDescription,
    required this.types,
    this.distanceKm,
  });

  /// True for a bare street (no house number) — worth asking for one.
  bool get isStreetOnly => types.contains('route');
}

/// A resolved place: coordinates plus a parsed address.
class PlaceDetails {
  final String placeId;
  final double lat;
  final double lng;
  final String formattedAddress;
  final String? name;
  final String? houseNumber;
  final String? street;
  final String? suburb;
  final String? city;
  final String? postcode;
  final String? countryCode;

  const PlaceDetails({
    required this.placeId,
    required this.lat,
    required this.lng,
    required this.formattedAddress,
    this.name,
    this.houseNumber,
    this.street,
    this.suburb,
    this.city,
    this.postcode,
    this.countryCode,
  });

  /// Short line for lists ("23 Avenue de la Paix").
  String get shortLabel {
    if (houseNumber != null && houseNumber!.isNotEmpty && street != null) {
      return '$houseNumber $street';
    }
    if (street != null && street!.isNotEmpty) return street!;
    if (name != null && name!.isNotEmpty) return name!;
    return formattedAddress;
  }

  /// Secondary line ("Poto-Poto, Brazzaville").
  String get contextLabel {
    final parts = <String>[];
    if (suburb != null && suburb!.isNotEmpty) parts.add(suburb!);
    if (city != null && city!.isNotEmpty && city != suburb) parts.add(city!);
    return parts.join(', ');
  }

  /// Best single-line address to store and show.
  String get displayAddress =>
      formattedAddress.isNotEmpty ? formattedAddress : shortLabel;

  LatLng get latLng => LatLng(lat, lng);

  static PlaceDetails fromProxy(Map data, {String fallbackId = ''}) {
    final c = Map<String, dynamic>.from((data['components'] as Map?) ?? {});
    String? pick(List<String> keys) {
      for (final k in keys) {
        final v = c[k]?.toString();
        if (v != null && v.isNotEmpty) return v;
      }
      return null;
    }

    return PlaceDetails(
      placeId: (data['place_id'] ?? fallbackId).toString(),
      lat: (data['lat'] as num).toDouble(),
      lng: (data['lng'] as num).toDouble(),
      formattedAddress: (data['formatted_address'] ?? '').toString(),
      name: data['name']?.toString(),
      houseNumber: pick(['street_number']),
      street: pick(['route']),
      suburb: pick(['sublocality_level_1', 'sublocality', 'neighborhood']),
      city: pick(['locality', 'administrative_area_level_2']),
      postcode: pick(['postal_code']),
      countryCode: pick(['country']),
    );
  }
}

/// One turn-by-turn instruction.
class RouteStep {
  final double distanceM;
  final int durationS;
  final String instruction;
  final String maneuver;
  final LatLng? end;

  const RouteStep({
    required this.distanceM,
    required this.durationS,
    required this.instruction,
    required this.maneuver,
    this.end,
  });
}

/// A driving route.
class RouteResult {
  final List<LatLng> points;
  final double distanceKm;
  final int durationMin;
  final List<RouteStep> steps;

  /// Extra minutes caused by traffic (with-traffic time minus free-road time).
  final int delayMin;

  /// Start of each stretch where traffic is at a standstill, in route order.
  final List<LatLng> jamSpots;

  /// True when Google couldn't give a road route and this is a straight
  /// line with an estimated distance/time (so the map still shows a line).
  final bool estimated;

  const RouteResult({
    required this.points,
    required this.distanceKm,
    required this.durationMin,
    required this.steps,
    this.delayMin = 0,
    this.jamSpots = const [],
    this.estimated = false,
  });
}

/// Raised when the Maps proxy is unreachable or Google refuses a call.
class GoogleMapsException implements Exception {
  final String message;
  const GoogleMapsException(this.message);
  @override
  String toString() => 'GoogleMapsException: $message';
}

// ════════════════════════════════════════════════════════════════
// SERVICE
// ════════════════════════════════════════════════════════════════
class GoogleMapsService {
  GoogleMapsService._();

  static const _function = 'google-maps';

  /// App language (set from main.dart when the language changes).
  /// Google has no Lingala / Chiyawo / Chichewa; those fall back.
  static String _language = 'en';
  static String get language => _language;
  static set languageCode(String code) {
    switch (code) {
      case 'fr':
      case 'ln': // Lingala speakers read French addresses
        _language = 'fr';
        break;
      case 'sw':
        _language = 'sw';
        break;
      case 'af':
        _language = 'af';
        break;
      default:
        _language = 'en';
    }
  }

  // Places bills autocomplete + details as one session when they share
  // a token. Reset after each details call.
  static String? _session;
  static String _ensureSession() =>
      _session ??= DateTime.now().microsecondsSinceEpoch.toRadixString(36);
  static void resetSession() => _session = null;

  static Future<Map<String, dynamic>> _call(Map<String, dynamic> body,
      {Duration timeout = const Duration(seconds: 12)}) async {
    try {
      final res = await Supabase.instance.client.functions
          .invoke(_function, body: body)
          .timeout(timeout);
      final data = res.data;
      if (data is Map && data['error'] != null) {
        throw GoogleMapsException(data['error'].toString());
      }
      if (data is! Map) {
        throw const GoogleMapsException('Unexpected response');
      }
      return Map<String, dynamic>.from(data);
    } on GoogleMapsException {
      rethrow;
    } on TimeoutException {
      throw const GoogleMapsException('Maps request timed out');
    } catch (e) {
      debugPrint('GoogleMapsService ${body['action']} failed: $e');
      throw GoogleMapsException(e.toString());
    }
  }

  /// ISO country code (lowercase) for a point, used to keep search
  /// results inside the user's country. Null when unknown.
  static String? regionFor(LatLng p) {
    final c = CountryConfig.isoFor(p.latitude, p.longitude);
    return c?.toLowerCase();
  }

  // ── Autocomplete ───────────────────────────────────────────────
  static Future<List<PlacePrediction>> autocomplete({
    required String query,
    required LatLng origin,
    int radiusMeters = 50000,
    String? countryCode,
  }) async {
    final q = query.trim();
    if (q.isEmpty) return const [];
    final data = await _call({
      'action': 'autocomplete',
      'input': q,
      'lat': origin.latitude,
      'lng': origin.longitude,
      'radius': radiusMeters,
      // Per country: the person's own country first, then where the
      // phone is.
      'region': countryCode ?? CountryConfig.servedIso ?? regionFor(origin),
      'language': _language,
      'session': _ensureSession(),
    });
    final list = (data['predictions'] as List?) ?? const [];
    return list.map((raw) {
      final p = Map<String, dynamic>.from(raw as Map);
      final dm = (p['distance_m'] as num?)?.toDouble();
      return PlacePrediction(
        placeId: p['place_id'].toString(),
        primaryText: (p['primary'] ?? '').toString(),
        secondaryText: (p['secondary'] ?? '').toString(),
        fullDescription: (p['description'] ?? '').toString(),
        types: List<String>.from((p['types'] as List?) ?? const []),
        distanceKm: dm == null ? null : dm / 1000.0,
      );
    }).toList(growable: false);
  }

  // ── Details ────────────────────────────────────────────────────
  static Future<PlaceDetails?> details(String placeId) async {
    try {
      final data = await _call({
        'action': 'details',
        'place_id': placeId,
        'language': _language,
        'session': _ensureSession(),
      });
      if (data['lat'] == null || data['lng'] == null) return null;
      return PlaceDetails.fromProxy(data, fallbackId: placeId);
    } finally {
      resetSession();
    }
  }

  // ── Reverse geocode ────────────────────────────────────────────
  static Future<PlaceDetails?> reverseGeocode(LatLng point) async {
    try {
      final data = await _call({
        'action': 'reverse',
        'lat': point.latitude,
        'lng': point.longitude,
        'language': _language,
      });
      if ((data['formatted_address'] ?? '').toString().isEmpty) return null;
      data['lat'] ??= point.latitude;
      data['lng'] ??= point.longitude;
      return PlaceDetails.fromProxy(data);
    } catch (e) {
      debugPrint('reverseGeocode failed: $e');
      return null;
    }
  }

  // ── Route ──────────────────────────────────────────────────────
  /// Returns null when no road route exists or the call fails, so
  /// callers can fall back to a straight-line estimate.
  static Future<RouteResult?> route(
    LatLng from,
    LatLng to, {
    bool twoWheeler = false,
  }) async {
    try {
      final data = await _call({
        'action': 'route',
        'origin': {'lat': from.latitude, 'lng': from.longitude},
        'destination': {'lat': to.latitude, 'lng': to.longitude},
        'mode': twoWheeler ? 'two_wheeler' : 'drive',
        'language': _language,
      });
      if (data['found'] != true) return _straightLine(from, to);
      final steps = ((data['steps'] as List?) ?? const []).map((raw) {
        final s = Map<String, dynamic>.from(raw as Map);
        final lat = (s['end_lat'] as num?)?.toDouble();
        final lng = (s['end_lng'] as num?)?.toDouble();
        return RouteStep(
          distanceM: (s['distance_m'] as num?)?.toDouble() ?? 0,
          durationS: (s['duration_s'] as num?)?.toInt() ?? 0,
          instruction: (s['instruction'] ?? '').toString(),
          maneuver: (s['maneuver'] ?? '').toString(),
          end: (lat != null && lng != null) ? LatLng(lat, lng) : null,
        );
      }).toList(growable: false);
      final pts = decodePolyline((data['polyline'] ?? '').toString());
      final withTraffic = ((data['duration_s'] as num?)?.toDouble() ?? 0);
      final free = ((data['static_duration_s'] as num?)?.toDouble() ?? 0);
      final delay =
          free > 0 ? ((withTraffic - free) / 60.0).round() : 0;
      final jams = <LatLng>[];
      for (final raw in (data['jams'] as List?) ?? const []) {
        final i = (raw as Map)['s'];
        if (i is int && i >= 0 && i < pts.length) jams.add(pts[i]);
      }
      return RouteResult(
        points: pts,
        distanceKm: ((data['distance_m'] as num?)?.toDouble() ?? 0) / 1000.0,
        durationMin: (withTraffic / 60.0).round(),
        steps: steps,
        delayMin: delay < 0 ? 0 : delay,
        jamSpots: jams,
      );
    } catch (e) {
      // Routes service off / no signal: still draw a line and estimate,
      // so customer and driver always see each other's way.
      debugPrint('route failed, using straight line: $e');
      return _straightLine(from, to);
    }
  }

  static RouteResult _straightLine(LatLng a, LatLng b) {
    const r = 6371.0;
    double rad(double d) => d * math.pi / 180;
    final dLat = rad(b.latitude - a.latitude);
    final dLng = rad(b.longitude - a.longitude);
    final h = math.pow(math.sin(dLat / 2), 2) +
        math.cos(rad(a.latitude)) *
            math.cos(rad(b.latitude)) *
            math.pow(math.sin(dLng / 2), 2);
    final km = 2 * r * math.asin(math.sqrt(h)) * 1.3; // roads aren't straight
    return RouteResult(
      points: [a, b],
      distanceKm: km,
      durationMin: math.max(1, (km / 30 * 60).round()), // ~30 km/h in town
      steps: const [],
      estimated: true,
    );
  }

  /// Decodes a Google encoded polyline.
  static List<LatLng> decodePolyline(String encoded) {
    final points = <LatLng>[];
    int index = 0, lat = 0, lng = 0;
    while (index < encoded.length) {
      int shift = 0, result = 0, b;
      do {
        b = encoded.codeUnitAt(index++) - 63;
        result |= (b & 0x1f) << shift;
        shift += 5;
      } while (b >= 0x20 && index < encoded.length);
      lat += (result & 1) != 0 ? ~(result >> 1) : (result >> 1);

      shift = 0;
      result = 0;
      do {
        b = encoded.codeUnitAt(index++) - 63;
        result |= (b & 0x1f) << shift;
        shift += 5;
      } while (b >= 0x20 && index < encoded.length);
      lng += (result & 1) != 0 ? ~(result >> 1) : (result >> 1);

      points.add(LatLng(lat / 1e5, lng / 1e5));
    }
    return points;
  }
}
