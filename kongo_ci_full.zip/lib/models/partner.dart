// lib/models/partner.dart

class Partner {
  final String id;
  final String? ownerId;
  final String name;
  final String category;      // 'restaurant' | 'grocery' | 'pharmacy' | ...
  final String? description;
  final String? address;
  final String? landmark;
  final double? lat;
  final double? lng;
  final String city;
  final String? phone;
  final String? email;
  final String? logoUrl;
  final String? coverUrl;
  final double commissionPct;
  final double deliveryFee;
  final double minOrder;
  final int prepMinutes;
  final bool isOpen;
  final bool isActive;
  final bool isVerified;
  final double rating;
  final int totalRatings;
  final int totalOrders;
  final DateTime? sponsoredUntil;

  /// Paid "Sponsored" spot: listed first while the date is in the future.
  bool get isSponsored =>
      sponsoredUntil != null && sponsoredUntil!.isAfter(DateTime.now());

  const Partner({
    required this.id,
    this.ownerId,
    required this.name,
    required this.category,
    this.description,
    this.address,
    this.landmark,
    this.lat,
    this.lng,
    required this.city,
    this.phone,
    this.email,
    this.logoUrl,
    this.coverUrl,
    required this.commissionPct,
    required this.deliveryFee,
    required this.minOrder,
    required this.prepMinutes,
    required this.isOpen,
    required this.isActive,
    required this.isVerified,
    required this.rating,
    required this.totalRatings,
    required this.totalOrders,
    this.sponsoredUntil,
  });

  /// Numbers can arrive as text (e.g. a column stored as text): read both.
  static num? _num(dynamic v) =>
      v is num ? v : (v == null ? null : num.tryParse(v.toString()));

  factory Partner.fromMap(Map<String, dynamic> m) => Partner(
        id:            (m['id'] ?? '').toString(),
        ownerId:       m['owner_id']?.toString(),
        name:          (m['name'] ?? '').toString(),
        category:      (m['category'] ?? '').toString(),
        description:   m['description']?.toString(),
        address:       m['address']?.toString(),
        landmark:      m['landmark']?.toString(),
        lat:           _num(m['lat'])?.toDouble(),
        lng:           _num(m['lng'])?.toDouble(),
        city:          (m['city'] ?? 'Brazzaville').toString(),
        phone:         m['phone']?.toString(),
        email:         m['email']?.toString(),
        logoUrl:       m['logo_url']?.toString(),
        coverUrl:      m['cover_url']?.toString(),
        commissionPct: _num(m['commission_pct'])?.toDouble() ?? 25.0,
        deliveryFee:   _num(m['delivery_fee'])?.toDouble() ?? 0.0,
        minOrder:      _num(m['min_order'])?.toDouble() ?? 0.0,
        prepMinutes:   _num(m['prep_minutes'])?.toInt()    ?? 15,
        isOpen:        m['is_open']   == true,
        isActive:      m['is_active'] == true,
        isVerified:    m['is_verified'] == true,
        rating:        _num(m['rating'])?.toDouble() ?? 5.0,
        totalRatings:  _num(m['total_ratings'])?.toInt() ?? 0,
        totalOrders:   _num(m['total_orders'])?.toInt() ?? 0,
        sponsoredUntil: m['sponsored_until'] == null
            ? null
            : DateTime.tryParse(m['sponsored_until'].toString())?.toLocal(),
      );

  String get categoryLabel {
    switch (category.toLowerCase()) {
      case 'restaurant': return 'Restaurant';
      case 'grocery':    return 'Grocery';
      case 'pharmacy':   return 'Pharmacy';
      case 'bakery':     return 'Bakery';
      case 'fashion':    return 'Fashion';
      case 'electronics':return 'Electronics';
      case 'home_living':return 'Home & Living';
      case 'beauty':     return 'Beauty';
      case 'butchery':   return 'Butchery';
      case 'general_retail': return 'General Retail';
      case 'other':      return 'Other';
      default:           return category;
    }
  }

  bool get isAvailable => isActive && isOpen;
}
