﻿import 'package:latlong2/latlong.dart';
import 'ride_status.dart';
import 'service_mode.dart';

/// Full-fidelity ride model.
///
/// Every field the app reads or writes is represented here, parsed
/// defensively so a single bad row never crashes a realtime stream.
class Ride {
  // ---------------- Identity ----------------
  final String id;
  final String customerId;
  final String? driverId;

  // ---------------- Service ----------------
  final ServiceMode serviceMode;
  final String serviceType; // raw DB value: 'Ride' | 'Delivery'
  final String vehicleType;

  // ---------------- Route ----------------
  final String pickupAddress;
  final String dropoffAddress;
  final double pickupLat;
  final double pickupLng;
  final double dropoffLat;
  final double dropoffLng;

  // ---------------- Status ----------------
  final RideStatus status;

  // ---------------- Money ----------------
  final double fare;
  final double? originalFare;
  final double? discountApplied;
  final double? surgeMultiplier;
  final String? promoCode;

  // ---------------- OTP ----------------
  final String? pickupOtp;
  final bool pickupOtpVerified;

  // ---------------- Bidding ----------------
  final bool isBidding;
  final String bidStatus; // 'none' | 'pending' | 'countered' | 'accepted' | 'rejected'
  final double? customerBid;
  final double? driverCounter;
  final String? counterDriverId;

  // ---------------- Trip metadata ----------------
  final double? distanceKm;
  final int? etaMinutes;
  final String? customerNote;

  // ---------------- Delivery ----------------
  final String? recipientName;
  final String? recipientPhone;
  final String? packagePhotoUrl;

  // ---------------- Live driver location ----------------
  final double? driverLat;
  final double? driverLng;

  // ---------------- Ratings ----------------
  final int? customerRating;
  final DateTime? customerRatedAt;
  final int? driverRating;
  final DateTime? driverRatedAt;

  // ---------------- Payout ----------------
  final String payoutStatus; // 'pending' | 'paid'

  // ---------------- Cancellation ----------------
  final String? cancellationReason;
  final String? cancelledBy;
  final DateTime? cancelledAt;

  // ---------------- Timestamps ----------------
  final DateTime createdAt;
  final DateTime? updatedAt;
  final DateTime? acceptedAt;
  final DateTime? startedAt;
  final DateTime? completedAt;

  const Ride({
    required this.id,
    required this.customerId,
    this.driverId,
    required this.serviceMode,
    required this.serviceType,
    required this.vehicleType,
    required this.pickupAddress,
    required this.dropoffAddress,
    required this.pickupLat,
    required this.pickupLng,
    required this.dropoffLat,
    required this.dropoffLng,
    required this.status,
    required this.fare,
    this.originalFare,
    this.discountApplied,
    this.surgeMultiplier,
    this.promoCode,
    this.pickupOtp,
    this.pickupOtpVerified = false,
    this.isBidding = false,
    this.bidStatus = 'none',
    this.customerBid,
    this.driverCounter,
    this.counterDriverId,
    this.distanceKm,
    this.etaMinutes,
    this.customerNote,
    this.recipientName,
    this.recipientPhone,
    this.packagePhotoUrl,
    this.driverLat,
    this.driverLng,
    this.customerRating,
    this.customerRatedAt,
    this.driverRating,
    this.driverRatedAt,
    this.payoutStatus = 'pending',
    this.cancellationReason,
    this.cancelledBy,
    this.cancelledAt,
    required this.createdAt,
    this.updatedAt,
    this.acceptedAt,
    this.startedAt,
    this.completedAt,
  });

  // ============================================================
  // FROM JSON — every field defended against nulls
  // ============================================================
  factory Ride.fromJson(Map<String, dynamic> json) {
    final serviceTypeRaw = (json['service_type'] ?? 'Ride').toString();

    return Ride(
      id: (json['id'] ?? '').toString(),
      customerId: (json['customer_id'] ?? '').toString(),
      driverId: _strOrNull(json['driver_id']),

      serviceMode: ServiceMode.fromString(serviceTypeRaw),
      serviceType: serviceTypeRaw,
      vehicleType: (json['vehicle_type'] ?? 'standard').toString(),

      pickupAddress: (json['pickup_address'] ?? '').toString(),
      dropoffAddress: (json['dropoff_address'] ?? '').toString(),
      pickupLat: _doubleOr(json['pickup_lat'], 0),
      pickupLng: _doubleOr(json['pickup_lng'], 0),
      dropoffLat: _doubleOr(json['dropoff_lat'], 0),
      dropoffLng: _doubleOr(json['dropoff_lng'], 0),

      status: RideStatus.fromString(json['status']?.toString()),

      fare: _doubleOr(json['fare'], 0),
      originalFare: _doubleOrNull(json['original_fare']),
      discountApplied: _doubleOrNull(json['discount_applied']),
      surgeMultiplier: _doubleOrNull(json['surge_multiplier']),
      promoCode: _strOrNull(json['promo_code']),

      pickupOtp: _strOrNull(json['pickup_otp']),
      pickupOtpVerified: json['pickup_otp_verified'] == true,

      isBidding: json['is_bidding'] == true,
      bidStatus: (json['bid_status'] ?? 'none').toString(),
      customerBid: _doubleOrNull(json['customer_bid']),
      driverCounter: _doubleOrNull(json['driver_counter']),
      counterDriverId: _strOrNull(json['counter_driver_id']),

      distanceKm: _doubleOrNull(json['distance_km']),
      etaMinutes: _intOrNull(json['eta_minutes']),
      customerNote: _strOrNull(json['customer_note']),

      recipientName: _strOrNull(json['recipient_name']),
      recipientPhone: _strOrNull(json['recipient_phone']),
      packagePhotoUrl: _strOrNull(json['package_photo_url']),

      driverLat: _doubleOrNull(json['driver_lat']),
      driverLng: _doubleOrNull(json['driver_lng']),

      customerRating: _intOrNull(json['customer_rating']),
      customerRatedAt: _dateOrNull(json['customer_rated_at']),
      driverRating: _intOrNull(json['driver_rating']),
      driverRatedAt: _dateOrNull(json['driver_rated_at']),

      payoutStatus: (json['payout_status'] ?? 'pending').toString(),

      cancellationReason: _strOrNull(json['cancellation_reason']),
      cancelledBy: _strOrNull(json['cancelled_by']),
      cancelledAt: _dateOrNull(json['cancelled_at']),

      createdAt: _dateOr(json['created_at'], DateTime.now()),
      updatedAt: _dateOrNull(json['updated_at']),
      acceptedAt: _dateOrNull(json['accepted_at']),
      startedAt: _dateOrNull(json['started_at']),
      completedAt: _dateOrNull(json['completed_at']),
    );
  }

  // ============================================================
  // TO JSON — full representation for writes / caching
  // ============================================================
  Map<String, dynamic> toJson() => {
        'id': id,
        'customer_id': customerId,
        'driver_id': driverId,
        'service_type': serviceType,
        'vehicle_type': vehicleType,
        'pickup_address': pickupAddress,
        'dropoff_address': dropoffAddress,
        'pickup_lat': pickupLat,
        'pickup_lng': pickupLng,
        'dropoff_lat': dropoffLat,
        'dropoff_lng': dropoffLng,
        'status': status.dbValue,
        'fare': fare,
        'original_fare': originalFare,
        'discount_applied': discountApplied,
        'surge_multiplier': surgeMultiplier,
        'promo_code': promoCode,
        'pickup_otp': pickupOtp,
        'pickup_otp_verified': pickupOtpVerified,
        'is_bidding': isBidding,
        'bid_status': bidStatus,
        'customer_bid': customerBid,
        'driver_counter': driverCounter,
        'counter_driver_id': counterDriverId,
        'distance_km': distanceKm,
        'eta_minutes': etaMinutes,
        'customer_note': customerNote,
        'recipient_name': recipientName,
        'recipient_phone': recipientPhone,
        'package_photo_url': packagePhotoUrl,
        'driver_lat': driverLat,
        'driver_lng': driverLng,
        'customer_rating': customerRating,
        'customer_rated_at': customerRatedAt?.toUtc().toIso8601String(),
        'driver_rating': driverRating,
        'driver_rated_at': driverRatedAt?.toUtc().toIso8601String(),
        'payout_status': payoutStatus,
        'cancellation_reason': cancellationReason,
        'cancelled_by': cancelledBy,
        'cancelled_at': cancelledAt?.toUtc().toIso8601String(),
        'created_at': createdAt.toUtc().toIso8601String(),
        'updated_at': updatedAt?.toUtc().toIso8601String(),
        'accepted_at': acceptedAt?.toUtc().toIso8601String(),
        'started_at': startedAt?.toUtc().toIso8601String(),
        'completed_at': completedAt?.toUtc().toIso8601String(),
      };

  /// Sparse update payload — only non-null fields, so partial writes never
  /// clobber existing DB values with null.
  Map<String, dynamic> toUpdateJson({
    bool includeNull = false,
  }) {
    final full = toJson();
    if (includeNull) return full;

    final out = <String, dynamic>{};
    full.forEach((k, v) {
      if (v != null) out[k] = v;
    });
    // Never send `id` in an update payload.
    out.remove('id');
    return out;
  }

  // ============================================================
  // COPY-WITH
  // ============================================================
  Ride copyWith({
    String? id,
    String? customerId,
    Object? driverId = _sentinel,
    ServiceMode? serviceMode,
    String? serviceType,
    String? vehicleType,
    String? pickupAddress,
    String? dropoffAddress,
    double? pickupLat,
    double? pickupLng,
    double? dropoffLat,
    double? dropoffLng,
    RideStatus? status,
    double? fare,
    Object? originalFare = _sentinel,
    Object? discountApplied = _sentinel,
    Object? surgeMultiplier = _sentinel,
    Object? promoCode = _sentinel,
    Object? pickupOtp = _sentinel,
    bool? pickupOtpVerified,
    bool? isBidding,
    String? bidStatus,
    Object? customerBid = _sentinel,
    Object? driverCounter = _sentinel,
    Object? counterDriverId = _sentinel,
    Object? distanceKm = _sentinel,
    Object? etaMinutes = _sentinel,
    Object? customerNote = _sentinel,
    Object? recipientName = _sentinel,
    Object? recipientPhone = _sentinel,
    Object? packagePhotoUrl = _sentinel,
    Object? driverLat = _sentinel,
    Object? driverLng = _sentinel,
    Object? customerRating = _sentinel,
    Object? customerRatedAt = _sentinel,
    Object? driverRating = _sentinel,
    Object? driverRatedAt = _sentinel,
    String? payoutStatus,
    Object? cancellationReason = _sentinel,
    Object? cancelledBy = _sentinel,
    Object? cancelledAt = _sentinel,
    DateTime? createdAt,
    Object? updatedAt = _sentinel,
    Object? acceptedAt = _sentinel,
    Object? startedAt = _sentinel,
    Object? completedAt = _sentinel,
  }) {
    return Ride(
      id: id ?? this.id,
      customerId: customerId ?? this.customerId,
      driverId: driverId == _sentinel ? this.driverId : driverId as String?,
      serviceMode: serviceMode ?? this.serviceMode,
      serviceType: serviceType ?? this.serviceType,
      vehicleType: vehicleType ?? this.vehicleType,
      pickupAddress: pickupAddress ?? this.pickupAddress,
      dropoffAddress: dropoffAddress ?? this.dropoffAddress,
      pickupLat: pickupLat ?? this.pickupLat,
      pickupLng: pickupLng ?? this.pickupLng,
      dropoffLat: dropoffLat ?? this.dropoffLat,
      dropoffLng: dropoffLng ?? this.dropoffLng,
      status: status ?? this.status,
      fare: fare ?? this.fare,
      originalFare: originalFare == _sentinel
          ? this.originalFare
          : originalFare as double?,
      discountApplied: discountApplied == _sentinel
          ? this.discountApplied
          : discountApplied as double?,
      surgeMultiplier: surgeMultiplier == _sentinel
          ? this.surgeMultiplier
          : surgeMultiplier as double?,
      promoCode:
          promoCode == _sentinel ? this.promoCode : promoCode as String?,
      pickupOtp:
          pickupOtp == _sentinel ? this.pickupOtp : pickupOtp as String?,
      pickupOtpVerified: pickupOtpVerified ?? this.pickupOtpVerified,
      isBidding: isBidding ?? this.isBidding,
      bidStatus: bidStatus ?? this.bidStatus,
      customerBid: customerBid == _sentinel
          ? this.customerBid
          : customerBid as double?,
      driverCounter: driverCounter == _sentinel
          ? this.driverCounter
          : driverCounter as double?,
      counterDriverId: counterDriverId == _sentinel
          ? this.counterDriverId
          : counterDriverId as String?,
      distanceKm: distanceKm == _sentinel
          ? this.distanceKm
          : distanceKm as double?,
      etaMinutes:
          etaMinutes == _sentinel ? this.etaMinutes : etaMinutes as int?,
      customerNote: customerNote == _sentinel
          ? this.customerNote
          : customerNote as String?,
      recipientName: recipientName == _sentinel
          ? this.recipientName
          : recipientName as String?,
      recipientPhone: recipientPhone == _sentinel
          ? this.recipientPhone
          : recipientPhone as String?,
      packagePhotoUrl: packagePhotoUrl == _sentinel
          ? this.packagePhotoUrl
          : packagePhotoUrl as String?,
      driverLat:
          driverLat == _sentinel ? this.driverLat : driverLat as double?,
      driverLng:
          driverLng == _sentinel ? this.driverLng : driverLng as double?,
      customerRating: customerRating == _sentinel
          ? this.customerRating
          : customerRating as int?,
      customerRatedAt: customerRatedAt == _sentinel
          ? this.customerRatedAt
          : customerRatedAt as DateTime?,
      driverRating: driverRating == _sentinel
          ? this.driverRating
          : driverRating as int?,
      driverRatedAt: driverRatedAt == _sentinel
          ? this.driverRatedAt
          : driverRatedAt as DateTime?,
      payoutStatus: payoutStatus ?? this.payoutStatus,
      cancellationReason: cancellationReason == _sentinel
          ? this.cancellationReason
          : cancellationReason as String?,
      cancelledBy: cancelledBy == _sentinel
          ? this.cancelledBy
          : cancelledBy as String?,
      cancelledAt: cancelledAt == _sentinel
          ? this.cancelledAt
          : cancelledAt as DateTime?,
      createdAt: createdAt ?? this.createdAt,
      updatedAt:
          updatedAt == _sentinel ? this.updatedAt : updatedAt as DateTime?,
      acceptedAt: acceptedAt == _sentinel
          ? this.acceptedAt
          : acceptedAt as DateTime?,
      startedAt:
          startedAt == _sentinel ? this.startedAt : startedAt as DateTime?,
      completedAt: completedAt == _sentinel
          ? this.completedAt
          : completedAt as DateTime?,
    );
  }

  // ============================================================
  // CONVENIENCE HELPERS
  // ============================================================
  bool get isPending => status == RideStatus.pending;
  bool get isAccepted => status == RideStatus.accepted;
  bool get isInProgress => status == RideStatus.inProgress;
  bool get isCompleted => status == RideStatus.completed;
  bool get isCancelled => status == RideStatus.cancelled;
  bool get isActive => status.isActive;
  bool get isFinished => status.isFinished;
  bool get isDelivery => serviceMode == ServiceMode.delivery;

  /// "Pickup → Dropoff" summary for display.
  String get routeSummary {
    String short(String s) {
      if (s.isEmpty) return '—';
      return s.split(',').first.trim();
    }

    return '${short(pickupAddress)} → ${short(dropoffAddress)}';
  }

  /// First 8 chars of the ID, good for showing in a receipt or log.
  String get shortId => id.length >= 8 ? id.substring(0, 8) : id;

  LatLng? get pickupLatLng =>
      pickupLat == 0 && pickupLng == 0 ? null : LatLng(pickupLat, pickupLng);

  LatLng? get dropoffLatLng => dropoffLat == 0 && dropoffLng == 0
      ? null
      : LatLng(dropoffLat, dropoffLng);

  LatLng? get driverLatLng => driverLat == null || driverLng == null
      ? null
      : LatLng(driverLat!, driverLng!);

  // ============================================================
  // EQUALITY
  // ============================================================
  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
    return other is Ride &&
        other.id == id &&
        other.status == status &&
        other.fare == fare &&
        other.driverId == driverId &&
        other.updatedAt == updatedAt;
  }

  @override
  int get hashCode =>
      Object.hash(id, status, fare, driverId, updatedAt);

  @override
  String toString() =>
      'Ride($id, ${status.name}, fare=$fare, ${routeSummary})';

  // ============================================================
  // PARSING HELPERS
  // ============================================================
  static String? _strOrNull(dynamic v) {
    if (v == null) return null;
    final s = v.toString().trim();
    return s.isEmpty ? null : s;
  }

  static double _doubleOr(dynamic v, double fallback) {
    if (v == null) return fallback;
    if (v is double) return v;
    if (v is num) return v.toDouble();
    return double.tryParse(v.toString()) ?? fallback;
  }

  static double? _doubleOrNull(dynamic v) {
    if (v == null) return null;
    if (v is double) return v;
    if (v is num) return v.toDouble();
    return double.tryParse(v.toString());
  }

  static int? _intOrNull(dynamic v) {
    if (v == null) return null;
    if (v is int) return v;
    if (v is num) return v.toInt();
    return int.tryParse(v.toString());
  }

  static DateTime _dateOr(dynamic v, DateTime fallback) {
    final parsed = _dateOrNull(v);
    return parsed ?? fallback;
  }

  static DateTime? _dateOrNull(dynamic v) {
    if (v == null) return null;
    try {
      return DateTime.parse(v.toString()).toUtc();
    } catch (_) {
      return null;
    }
  }

  static const Object _sentinel = Object();
}
