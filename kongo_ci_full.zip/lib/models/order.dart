// lib/models/order.dart

class OrderLine {
  final String id;
  final String orderId;
  final String? productId;
  final String name;
  final String? description;
  final String? emoji;
  final int qty;
  final double unitPrice;
  final double lineTotal;
  final double? actualPrice;
  final double? weightKg;
  final String? notes;

  const OrderLine({
    required this.id,
    required this.orderId,
    this.productId,
    required this.name,
    this.description,
    this.emoji,
    required this.qty,
    required this.unitPrice,
    required this.lineTotal,
    this.actualPrice,
    this.weightKg,
    this.notes,
  });

  factory OrderLine.fromMap(Map<String, dynamic> m) => OrderLine(
        id: (m['id'] ?? '').toString(),
        orderId: (m['order_id'] ?? '').toString(),
        productId: m['product_id']?.toString(),
        name: (m['name'] ?? '').toString(),
        description: m['description']?.toString(),
        emoji: m['emoji']?.toString(),
        qty: (m['qty'] as num?)?.toInt() ?? 1,
        unitPrice: (m['unit_price'] as num?)?.toDouble() ?? 0.0,
        lineTotal: (m['line_total'] as num?)?.toDouble() ?? 0.0,
        actualPrice: (m['actual_price'] as num?)?.toDouble(),
        weightKg: (m['weight_kg'] as num?)?.toDouble(),
        notes: m['notes']?.toString(),
      );
}

enum OrderStatus {
  pending,
  confirmed,
  shopping,
  preparing,
  ready,
  pickedUp,
  inTransit,
  delivered,
  returning,
  returned,
  cancelled,
  refunded;

  static OrderStatus fromString(String? s) {
    switch ((s ?? '').toLowerCase()) {
      case 'pending':
        return OrderStatus.pending;
      case 'confirmed':
        return OrderStatus.confirmed;
      case 'shopping':
        return OrderStatus.shopping;
      case 'preparing':
        return OrderStatus.preparing;
      case 'ready':
        return OrderStatus.ready;
      case 'picked_up':
        return OrderStatus.pickedUp;
      case 'in_transit':
        return OrderStatus.inTransit;
      case 'delivered':
        return OrderStatus.delivered;
      case 'returning':
        return OrderStatus.returning;
      case 'returned':
        return OrderStatus.returned;
      case 'cancelled':
        return OrderStatus.cancelled;
      case 'refunded':
        return OrderStatus.refunded;
      default:
        return OrderStatus.pending;
    }
  }

  String get dbValue {
    switch (this) {
      case OrderStatus.pending:
        return 'pending';
      case OrderStatus.confirmed:
        return 'confirmed';
      case OrderStatus.shopping:
        return 'shopping';
      case OrderStatus.preparing:
        return 'preparing';
      case OrderStatus.ready:
        return 'ready';
      case OrderStatus.pickedUp:
        return 'picked_up';
      case OrderStatus.inTransit:
        return 'in_transit';
      case OrderStatus.delivered:
        return 'delivered';
      case OrderStatus.returning:
        return 'returning';
      case OrderStatus.returned:
        return 'returned';
      case OrderStatus.cancelled:
        return 'cancelled';
      case OrderStatus.refunded:
        return 'refunded';
    }
  }
}

class Order {
  final String id;
  final String customerId;
  final String? partnerId;
  final String? partnerName;
  final String serviceType; // 'Food' | 'Grocery' | 'Pharmacy'
  final OrderStatus status;
  final double subtotal;
  final double serviceFee;
  final double deliveryFee;
  final double discountAmount;
  final double total;
  final String? promoCode;
  final String paymentMethod; // 'wallet' | 'momo' | 'airtel' | 'cash'
  final String paymentStatus; // 'pending' | 'paid' | 'failed' | 'refunded'
  final bool contactless;
  final bool substitutionsAllowed;
  final String? deliveryAddress;
  final double? deliveryLat;
  final double? deliveryLng;
  final String? deliveryNote;
  final String? recipientName;
  final String? recipientPhone;
  final bool requiresPrescription;
  final String? prescriptionUrl;
  final String? driverId;
  final String? shopperId;
  final DateTime createdAt;
  final DateTime? acceptedAt;
  final DateTime? readyAt;
  final DateTime? pickedUpAt;
  final DateTime? deliveredAt;
  final DateTime? cancelledAt;
  final String? cancellationReason;
  final String? cancelledBy;

  /// Present only when the caller joins `order_items`.
  final List<OrderLine> lines;

  const Order({
    required this.id,
    required this.customerId,
    this.partnerId,
    this.partnerName,
    required this.serviceType,
    required this.status,
    required this.subtotal,
    required this.serviceFee,
    required this.deliveryFee,
    required this.discountAmount,
    required this.total,
    this.promoCode,
    required this.paymentMethod,
    required this.paymentStatus,
    required this.contactless,
    required this.substitutionsAllowed,
    this.deliveryAddress,
    this.deliveryLat,
    this.deliveryLng,
    this.deliveryNote,
    this.recipientName,
    this.recipientPhone,
    required this.requiresPrescription,
    this.prescriptionUrl,
    this.driverId,
    this.shopperId,
    required this.createdAt,
    this.acceptedAt,
    this.readyAt,
    this.pickedUpAt,
    this.deliveredAt,
    this.cancelledAt,
    this.cancellationReason,
    this.cancelledBy,
    this.lines = const [],
  });

  factory Order.fromMap(
    Map<String, dynamic> m, {
    List<OrderLine> lines = const [],
  }) =>
      Order(
        id: (m['id'] ?? '').toString(),
        customerId: (m['customer_id'] ?? '').toString(),
        partnerId: m['partner_id']?.toString(),
        partnerName: m['partner_name']?.toString(),
        serviceType: (m['service_type'] ?? 'Food').toString(),
        status: OrderStatus.fromString(m['status']?.toString()),
        subtotal: (m['subtotal'] as num?)?.toDouble() ?? 0,
        serviceFee: (m['service_fee'] as num?)?.toDouble() ?? 0,
        deliveryFee: (m['delivery_fee'] as num?)?.toDouble() ?? 0,
        discountAmount: (m['discount_amount'] as num?)?.toDouble() ?? 0,
        total: (m['total'] as num?)?.toDouble() ?? 0,
        promoCode: m['promo_code']?.toString(),
        paymentMethod: (m['payment_method'] ?? 'wallet').toString(),
        paymentStatus: (m['payment_status'] ?? 'pending').toString(),
        contactless: m['contactless'] == true,
        substitutionsAllowed: m['substitutions_allowed'] != false,
        deliveryAddress: m['delivery_address']?.toString(),
        deliveryLat: (m['delivery_lat'] as num?)?.toDouble(),
        deliveryLng: (m['delivery_lng'] as num?)?.toDouble(),
        deliveryNote: m['delivery_note']?.toString(),
        recipientName: m['recipient_name']?.toString(),
        recipientPhone: m['recipient_phone']?.toString(),
        requiresPrescription: m['requires_prescription'] == true,
        prescriptionUrl: m['prescription_url']?.toString(),
        driverId: m['driver_id']?.toString(),
        shopperId: m['shopper_id']?.toString(),
        createdAt: _parseDate(m['created_at']) ?? DateTime.now(),
        acceptedAt: _parseDate(m['accepted_at']),
        readyAt: _parseDate(m['ready_at']),
        pickedUpAt: _parseDate(m['picked_up_at']),
        deliveredAt: _parseDate(m['delivered_at']),
        cancelledAt: _parseDate(m['cancelled_at']),
        cancellationReason: m['cancellation_reason']?.toString(),
        cancelledBy: m['cancelled_by']?.toString(),
        lines: lines,
      );

  bool get isActive =>
      status != OrderStatus.delivered &&
      status != OrderStatus.returned &&
      status != OrderStatus.cancelled &&
      status != OrderStatus.refunded;

  /// The customer may cancel only before a shopper has started buying.
  bool get canCustomerCancel =>
      status == OrderStatus.pending || status == OrderStatus.confirmed;

  static DateTime? _parseDate(dynamic d) =>
      d == null ? null : DateTime.tryParse(d.toString())?.toLocal();
}
