/// The two top-level service modes. Matches `rides.service_type` in the DB.
///
/// Do NOT add vehicle categories here (sedan, xl, van). Vehicle categories
/// are admin-managed via the `vehicle_types` table and are not fixed at
/// compile time.
enum ServiceMode {
  ride,
  delivery;

  static ServiceMode fromString(String? raw) {
    switch ((raw ?? '').toLowerCase().trim()) {
      case 'delivery':
      case 'parcel':
        return ServiceMode.delivery;
      case 'ride':
      default:
        return ServiceMode.ride;
    }
  }

  /// DB-storable value.
  String get dbValue => this == ServiceMode.delivery ? 'Delivery' : 'Ride';

  String get label => this == ServiceMode.delivery ? 'Send a parcel' : 'Book a ride';

  String get shortLabel => this == ServiceMode.delivery ? 'Delivery' : 'Ride';
}
