﻿import 'package:flutter/material.dart';
enum VehicleType {
  standard,
  comfort,
  xl,
  delivery,
}

extension VehicleTypeExtension on VehicleType {
  String get displayName {
    switch (this) {
      case VehicleType.standard:
        return 'Standard (4-Seater)';
      case VehicleType.comfort:
        return 'Comfort (Premium)';
      case VehicleType.xl:
        return 'XL (6-Seater)';
      case VehicleType.delivery:
        return 'Delivery (Package)';
    }
  }

  double get baseFare {
    switch (this) {
      case VehicleType.standard:
        return 25.0;
      case VehicleType.comfort:
        return 40.0;
      case VehicleType.xl:
        return 50.0;
      case VehicleType.delivery:
        return 35.0;
    }
  }

  double get perKmRate {
    switch (this) {
      case VehicleType.standard:
        return 12.0;
      case VehicleType.comfort:
        return 18.0;
      case VehicleType.xl:
        return 22.0;
      case VehicleType.delivery:
        return 15.0;
    }
  }
  IconData get icon {
    switch (this) {
      case VehicleType.standard:
        return Icons.directions_car;
      case VehicleType.comfort:
        return Icons.directions_car_filled;
      case VehicleType.xl:
        return Icons.directions_car_filled_sharp;
      case VehicleType.delivery:
        return Icons.local_shipping;
    }
  }
}
