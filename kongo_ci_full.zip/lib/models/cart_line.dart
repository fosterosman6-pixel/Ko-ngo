// lib/models/cart_line.dart

class CartLine {
  final String  productId;
  final String  name;
  final String? description;
  final String? emoji;
  final String? imageUrl;
  final double  unitPrice;
  int           qty;

  CartLine({
    required this.productId,
    required this.name,
    this.description,
    this.emoji,
    this.imageUrl,
    required this.unitPrice,
    required this.qty,
  });

  double get lineTotal => unitPrice * qty;

  Map<String, dynamic> toMap() => {
        'product_id':  productId,
        'name':        name,
        'description': description,
        'emoji':       emoji,
        'image_url':   imageUrl,
        'unit_price':  unitPrice,
        'qty':         qty,
      };

  factory CartLine.fromMap(Map<String, dynamic> m) => CartLine(
        productId:   (m['product_id'] ?? '').toString(),
        name:        (m['name'] ?? '').toString(),
        description: m['description']?.toString(),
        emoji:       m['emoji']?.toString(),
        imageUrl:    m['image_url']?.toString(),
        unitPrice:   (m['unit_price'] as num?)?.toDouble() ?? 0.0,
        qty:         (m['qty'] as num?)?.toInt() ?? 1,
      );
}
