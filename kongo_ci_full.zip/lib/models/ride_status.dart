/// Canonical ride statuses used across the app.
///
/// Keep in sync with the `rides.status` column. When adding a new status,
/// add it here first, then update screens that switch on it.
enum RideStatus {
  pending,
  accepted,
  inProgress,
  completed,
  returning,
  returned,
  cancelled,
  unknown;

  /// Parse from the DB value (case-insensitive).
  static RideStatus fromString(String? raw) {
    switch ((raw ?? '').toLowerCase().trim()) {
      case 'pending':
        return RideStatus.pending;
      case 'accepted':
        return RideStatus.accepted;
      case 'in_progress':
      case 'inprogress':
      case 'in-progress':
        return RideStatus.inProgress;
      case 'completed':
        return RideStatus.completed;
      case 'returning':
        return RideStatus.returning;
      case 'returned':
        return RideStatus.returned;
      case 'cancelled':
      case 'canceled':
        return RideStatus.cancelled;
      default:
        return RideStatus.unknown;
    }
  }

  /// DB-storable string. `unknown` maps back to `pending` so a stray
  /// status never leaves the ride in an unsaveable state.
  String get dbValue {
    switch (this) {
      case RideStatus.pending:
        return 'pending';
      case RideStatus.accepted:
        return 'accepted';
      case RideStatus.inProgress:
        return 'in_progress';
      case RideStatus.completed:
        return 'completed';
      case RideStatus.returning:
        return 'returning';
      case RideStatus.returned:
        return 'returned';
      case RideStatus.cancelled:
        return 'cancelled';
      case RideStatus.unknown:
        return 'pending';
    }
  }

  /// Human-readable label for UI.
  String get label {
    switch (this) {
      case RideStatus.pending:
        return 'Pending';
      case RideStatus.accepted:
        return 'Driver on the way';
      case RideStatus.inProgress:
        return 'In progress';
      case RideStatus.completed:
        return 'Completed';
      case RideStatus.returning:
        return 'Returning to office';
      case RideStatus.returned:
        return 'Returned to office';
      case RideStatus.cancelled:
        return 'Cancelled';
      case RideStatus.unknown:
        return 'Unknown';
    }
  }

  bool get isActive =>
      this == RideStatus.accepted ||
      this == RideStatus.inProgress ||
      this == RideStatus.returning;

  bool get isFinished =>
      this == RideStatus.completed ||
      this == RideStatus.returned ||
      this == RideStatus.cancelled;

  bool get isPreTrip =>
      this == RideStatus.pending || this == RideStatus.accepted;
}
