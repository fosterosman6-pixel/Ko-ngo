import 'package:flutter/material.dart';
import 'service_mode.dart';
/// A vehicle category loaded from the `vehicle_types` table.
///
/// This is NOT an enum because vehicle categories are admin-managed in the
/// DB and can change without an app update. Fares come from the DB, not
/// from this class.
class VehicleCategory {
  final String name;
  final String serviceType; // 'Ride' | 'Delivery'
  final String? icon;
  final int? seats;
  final int? capacity;
  final int? etaOffset;
  final double? multiplier;

  /// Snapshot of the fare fields for display, but the source of truth
  /// remains `app_settings` on the server.
  final double? baseFare;
  final double? perKmRate;

  const VehicleCategory({
    required this.name,
    required this.serviceType,
    this.icon,
    this.seats,
    this.capacity,
    this.etaOffset,
    this.multiplier,
    this.baseFare,
    this.perKmRate,
  });

  factory VehicleCategory.fromJson(Map<String, dynamic> json) {
    return VehicleCategory(
      name: (json['name'] ?? '').toString(),
      serviceType: (json['service_type'] ?? 'Ride').toString(),
      icon: json['icon']?.toString(),
      seats: _intOrNull(json['seats']),
      capacity: _intOrNull(json['capacity']),
      etaOffset: _intOrNull(json['eta_offset']),
      multiplier: _doubleOrNull(json['multiplier']),
      baseFare: _doubleOrNull(json['base_fare']),
      perKmRate: _doubleOrNull(json['per_km_rate']),
    );
  }

  ServiceMode get mode => ServiceMode.fromString(serviceType);

  /// Icon to render for this category.
  ///
  /// Falls back to a sensible default based on the DB `icon` string.
  IconData get iconData {
    switch ((icon ?? '').toLowerCase()) {
      case 'car':
        return Icons.directions_car_filled;
      case 'taxi':
        return Icons.local_taxi;
      case 'bus':
        return Icons.airport_shuttle;
      case 'truck':
        return Icons.local_shipping;
      case 'bike':
      case 'motorcycle':
        return Icons.two_wheeler;
      default:
        return mode == ServiceMode.delivery
            ? Icons.local_shipping
            : Icons.directions_car_filled;
    }
  }

  String get subtitle {
    final s = seats ?? capacity;
    if (s != null) return '$s seats · $serviceType';
    return serviceType;
  }

  static int? _intOrNull(dynamic v) {
    if (v == null) return null;
    if (v is int) return v;
    if (v is num) return v.toInt();
    return int.tryParse(v.toString());
  }

  static double? _doubleOrNull(dynamic v) {
    if (v == null) return null;
    if (v is double) return v;
    if (v is num) return v.toDouble();
    return double.tryParse(v.toString());
  }
}
