// lib/models/product.dart

class Product {
  final String  id;
  final String  partnerId;
  final String  name;
  final String? description;
  final String? category;
  final double  price;
  final String? imageUrl;
  final String? emoji;
  final int     prepMinutes;
  final int?    stockLeft;
  final bool    isAvailable;
  final bool    isFeatured;
  final int     displayOrder;
  final List<String> tags;

  const Product({
    required this.id,
    required this.partnerId,
    required this.name,
    this.description,
    this.category,
    required this.price,
    this.imageUrl,
    this.emoji,
    required this.prepMinutes,
    this.stockLeft,
    required this.isAvailable,
    required this.isFeatured,
    required this.displayOrder,
    required this.tags,
  });

  factory Product.fromMap(Map<String, dynamic> m) => Product(
        id:           (m['id'] ?? '').toString(),
        partnerId:    (m['partner_id'] ?? '').toString(),
        name:         (m['name'] ?? '').toString(),
        description:  m['description']?.toString(),
        category:     m['category']?.toString(),
        price:        (m['price'] as num?)?.toDouble() ?? 0.0,
        imageUrl:     m['image_url']?.toString(),
        emoji:        m['emoji']?.toString(),
        prepMinutes:  (m['prep_minutes'] as num?)?.toInt() ?? 10,
        stockLeft:    (m['stock_left']   as num?)?.toInt(),
        isAvailable:  m['is_available']  == true,
        isFeatured:   m['is_featured']   == true,
        displayOrder: (m['display_order'] as num?)?.toInt() ?? 0,
        tags:         (m['tags'] is List)
                          ? List<String>.from(m['tags'])
                          : const <String>[],
      );

  bool get inStock => isAvailable && (stockLeft == null || stockLeft! > 0);
}
