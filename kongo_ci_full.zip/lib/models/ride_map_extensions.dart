import 'ride.dart';
import 'ride_status.dart';
import 'service_mode.dart';

/// Bridge for screens still working with raw `Map<String, dynamic>` payloads
/// (e.g. Supabase realtime callbacks).
///
/// Prefer the typed `Ride` model where you can. This extension exists so you
/// can migrate gradually without rewriting every screen at once.
extension RideMapX on Map<String, dynamic> {
  String get rideId => (this['id'] ?? '').toString();

  String get customerId => (this['customer_id'] ?? '').toString();

  String? get driverId {
    final v = this['driver_id'];
    if (v == null) return null;
    final s = v.toString().trim();
    return s.isEmpty ? null : s;
  }

  ServiceMode get serviceMode =>
      ServiceMode.fromString(this['service_type']?.toString());

  RideStatus get rideStatus =>
      RideStatus.fromString(this['status']?.toString());

  bool get isActiveRide {
    final s = rideStatus;
    return s == RideStatus.accepted || s == RideStatus.inProgress;
  }

  bool get isFinishedRide {
    final s = rideStatus;
    return s == RideStatus.completed || s == RideStatus.cancelled;
  }

  double get fareAmount {
    final v = this['fare'];
    if (v is num) return v.toDouble();
    if (v == null) return 0;
    return double.tryParse(v.toString()) ?? 0;
  }

  String get pickupAddress => (this['pickup_address'] ?? '').toString();

  String get dropoffAddress => (this['dropoff_address'] ?? '').toString();

  String get routeSummary {
    String short(String s) {
      if (s.isEmpty) return '—';
      return s.split(',').first.trim();
    }

    return '${short(pickupAddress)} → ${short(dropoffAddress)}';
  }

  /// Convert to the typed model. Safe to call — never throws.
  Ride get asRide => Ride.fromJson(this);
}
