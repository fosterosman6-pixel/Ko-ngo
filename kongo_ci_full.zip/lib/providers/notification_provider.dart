// lib/providers/notification_provider.dart
//
// One and only realtime subscription for notifications. Every screen
// that shows an unread badge or an inbox reads from here.
//
// The DB writes:
//   • type   — 'ride_request' | 'substitution' | 'order_status' | ...
//   • data   — { route, tab, params }
//   • title  — English fallback (kept for admin broadcasts)
//   • body   — English fallback
//
// This provider renders localized display text from `type` + `data`
// when it can, and falls back to `title` / `body` otherwise.

import 'dart:async';
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:efuride_app/l10n/app_strings.dart';
import 'package:efuride_app/services/notification_router.dart';

class AppNotification {
  final String id;
  final String type;
  final String title;
  final String body;
  final Map<String, dynamic> data;
  final bool read;
  final DateTime createdAt;

  const AppNotification({
    required this.id,
    required this.type,
    required this.title,
    required this.body,
    required this.data,
    required this.read,
    required this.createdAt,
  });

  factory AppNotification.fromMap(Map<String, dynamic> m) {
    final rawData = m['data'];
    final data = rawData is Map
        ? Map<String, dynamic>.from(rawData)
        : <String, dynamic>{};

    return AppNotification(
      id:        (m['id'] ?? '').toString(),
      type:      (m['type'] ?? '').toString(),
      title:     (m['title'] ?? '').toString(),
      body:      (m['body'] ?? '').toString(),
      data:      data,
      read:      m['read'] == true,
      createdAt: DateTime.tryParse(m['created_at']?.toString() ?? '')
                     ?.toLocal() ?? DateTime.now(),
    );
  }

  /// Route params extracted from the standard shape.
  String?  get route  => data['route']?.toString();
  String?  get tab    => data['tab']?.toString();
  String? get role => data['role']?.toString();
  Map<String, dynamic> get params =>
      data['params'] is Map
          ? Map<String, dynamic>.from(data['params'] as Map)
          : <String, dynamic>{};

  /// Localized title, resolved from `type` when possible.
  /// Falls back to whatever the DB stored.
  String localizedTitle(BuildContext ctx) {
    final t = S.of(ctx);
    switch (type) {
      case 'ride_request':    return t.t('notif_ride_request_title');
      case 'ride_accepted':   return t.t('notif_ride_accepted_title');
      case 'ride_cancelled':  return t.t('notif_ride_cancelled_title');
      case 'order_status':    return title.isNotEmpty
                                    ? title
                                    : t.t('notif_order_status_title');
      case 'substitution':    return t.t('notif_substitution_title');
      case 'chat_message':    return title;
      default:                return title.isNotEmpty
                                    ? title
                                    : t.t('notif_default_title');
    }
  }

  String localizedBody(BuildContext ctx) {
    final t = S.of(ctx);
    switch (type) {
      case 'ride_request':
        return t.t('notif_ride_request_body');
      case 'ride_accepted':
        return t.t('notif_ride_accepted_body');
      case 'ride_cancelled':
        return t.t('notif_ride_cancelled_body');
      case 'substitution':
        return t.t('notif_substitution_body');
      case 'order_status':
        // The DB trigger already set a short English body per status;
        // use it unless we have a localized key for it.
        final status = params['status']?.toString();
        if (status != null && status.isNotEmpty) {
          final key = 'notif_order_$status';
          final v = t.t(key);
          if (v != key) return v;
        }
        return body;
      default:
        return body;
    }
  }
}

class NotificationProvider extends ChangeNotifier {
  NotificationProvider._();
  String _currentRole ='customer';
  String get currentRole => _currentRole;

  void setRole(String role) {
    if(role == _currentRole) return;
    _currentRole =role;
    notifyListeners();
  }
  static final NotificationProvider instance = NotificationProvider._();

  RealtimeChannel? _channel;
  String? _userId;
  AppLang _lang = AppLang.en;

  final List<AppNotification> _items = [];
  int _unread = 0;
  bool _loaded = false;

  List<AppNotification> get items   => List.unmodifiable(_items);
  int                   get unread  => _unread;
  bool                  get loaded  => _loaded;

  void setLanguage(AppLang lang) {
    if (lang == _lang) return;
    _lang = lang;
    notifyListeners();
  }

  Future<void> start({
    required String userId,
    required AppLang language,
  }) async {
    if (_userId == userId && _channel != null) {
      setLanguage(language);
      return;
    }
    await stop();

    _userId = userId;
    _lang   = language;

    await _loadInitial(userId);
    _subscribe(userId);
  }

  Future<void> stop() async {
    await _channel?.unsubscribe();
    _channel = null;
    _userId  = null;
    _items.clear();
    _unread  = 0;
    _loaded  = false;
    notifyListeners();
  }

  Future<void> refresh() async {
    final uid = _userId;
    if (uid == null) return;
    await _loadInitial(uid);
  }

  Future<void> _loadInitial(String userId) async {
    try {
      final rows = await Supabase.instance.client
          .from('notifications')
          .select()
          .eq('user_id', userId)
          .order('created_at', ascending: false)
          .limit(100);

      _items
        ..clear()
        ..addAll(
          (rows as List)
              .map((r) => AppNotification.fromMap(
                    Map<String, dynamic>.from(r),
                  )),
        );

      _unread = _items.where((n) => !n.read).length;
      _loaded = true;
      notifyListeners();
    } catch (e) {
      debugPrint('NotificationProvider._loadInitial failed: $e');
      _loaded = true;
      notifyListeners();
    }
  }

  void _subscribe(String userId) {
    _channel?.unsubscribe();
    _channel = Supabase.instance.client
        .channel('notifications_$userId')
        .onPostgresChanges(
          event: PostgresChangeEvent.all,
          schema: 'public',
          table: 'notifications',
          filter: PostgresChangeFilter(
            type: PostgresChangeFilterType.eq,
            column: 'user_id',
            value: userId,
          ),
          callback: (payload) {
            final event = payload.eventType;
            if (event == PostgresChangeEvent.insert) {
              _onInsert(payload.newRecord);
            } else if (event == PostgresChangeEvent.update) {
              _onUpdate(payload.newRecord);
            } else if (event == PostgresChangeEvent.delete) {
              _onDelete(payload.oldRecord);
            }
          },
        )
        .subscribe();
  }

  void _onInsert(Map<String, dynamic> row) {
    final n = AppNotification.fromMap(Map<String, dynamic>.from(row));
    _items.insert(0, n);
    if (!n.read) _unread += 1;
    if (_items.length > 200) _items.removeLast();
    notifyListeners();
    NotificationRouter.instance.handleInApp(n);
  }

  void _onUpdate(Map<String, dynamic> row) {
    final idx = _items.indexWhere((n) => n.id == row['id'].toString());
    if (idx < 0) return;
    final wasUnread = !_items[idx].read;
    final next = AppNotification.fromMap(Map<String, dynamic>.from(row));
    _items[idx] = next;
    if (wasUnread && next.read) _unread = (_unread - 1).clamp(0, 999);
    if (!wasUnread && !next.read) _unread += 1;
    notifyListeners();
  }

  void _onDelete(Map<String, dynamic> row) {
    final id = row['id']?.toString();
    if (id == null) return;
    final idx = _items.indexWhere((n) => n.id == id);
    if (idx < 0) return;
    final wasUnread = !_items[idx].read;
    _items.removeAt(idx);
    if (wasUnread) _unread = (_unread - 1).clamp(0, 999);
    notifyListeners();
  }

  Future<void> markRead(String id) async {
    final idx = _items.indexWhere((n) => n.id == id);
    if (idx < 0 || _items[idx].read) return;

    final uid = _userId;
    if (uid == null) return;

    // Optimistic
    final n = _items[idx];
    _items[idx] = AppNotification(
      id: n.id, type: n.type, title: n.title, body: n.body,
      data: n.data, read: true, createdAt: n.createdAt,
    );
    _unread = (_unread - 1).clamp(0, 999);
    notifyListeners();

    try {
      await Supabase.instance.client
          .from('notifications')
          .update({'read': true})
          .eq('id', id)
          .eq('user_id', uid);
    } catch (e) {
      debugPrint('markRead failed: $e');
    }
  }

  Future<void> markAllRead() async {
    final uid = _userId;
    if (uid == null) return;
    try {
      await Supabase.instance.client
          .from('notifications')
          .update({'read': true})
          .eq('user_id', uid)
          .eq('read', false);
      for (var i = 0; i < _items.length; i++) {
        final n = _items[i];
        if (!n.read) {
          _items[i] = AppNotification(
            id: n.id, type: n.type, title: n.title, body: n.body,
            data: n.data, read: true, createdAt: n.createdAt,
          );
        }
      }
      _unread = 0;
      notifyListeners();
    } catch (e) {
      debugPrint('markAllRead failed: $e');
    }
  }
}
