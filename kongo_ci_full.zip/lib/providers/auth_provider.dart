﻿// lib/providers/auth_provider.dart
//
// Owns the session, the profile row, and the derived per-user state:
// role, display name, avatar, wallet, language, country/currency.
// Screens read from here instead of hitting Supabase directly.

import 'dart:async';
import 'package:efuride_app/main.dart' show appLanguageNotifier;
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:efuride_app/config/app_lang.dart';
import 'package:efuride_app/config/country_config.dart';
import 'package:efuride_app/l10n/app_strings.dart';
import 'package:efuride_app/providers/notification_provider.dart';
import 'package:efuride_app/services/device_guard.dart';
import 'package:efuride_app/services/keep_awake_service.dart';
import 'package:efuride_app/services/pricing_service.dart';
import 'package:efuride_app/utils/roles.dart';

class AuthProvider extends ChangeNotifier {
  AuthProvider() {
    _session = Supabase.instance.client.auth.currentSession;
    _user = Supabase.instance.client.auth.currentUser;
    _sub = Supabase.instance.client.auth.onAuthStateChange.listen(_onAuth);
    if (_user != null) _loadProfile();
  }

  StreamSubscription<AuthState>? _sub;
  Session? _session;
  User? _user;

  Session? get session => _session;
  User? get user => _user;
  bool get isSignedIn => _user != null;

  Map<String, dynamic>? _profile;
  bool _loadingProfile = false;
  Object? _profileError;

  Map<String, dynamic>? get profile => _profile;
  bool get loadingProfile => _loadingProfile;
  Object? get profileError => _profileError;

  String get role => (_profile?['role'] ?? '').toString();

  String get displayName {
    final first = (_profile?['first_name'] ?? '').toString().trim();
    final sur = (_profile?['surname'] ?? '').toString().trim();
    final full = (_profile?['full_name'] ?? '').toString().trim();
    final joined = '$first $sur'.trim();
    if (joined.isNotEmpty) return joined;
    if (full.isNotEmpty) return full;
    return 'User';
  }

  String? get avatarUrl {
    final p = (_profile?['profile_picture_url'] ?? '').toString().trim();
    if (p.isNotEmpty) return p;
    final a = (_profile?['avatar_url'] ?? '').toString().trim();
    return a.isEmpty ? null : a;
  }

  double get walletBalance =>
      (_profile?['wallet_balance'] as num?)?.toDouble() ?? 0;

  bool get isOnline => _profile?['is_online'] == true;
  bool get isActive => _profile?['is_active'] == true;

  AppLang _lang = AppLang.en;
  AppLang get lang => _lang;

  CountryData _country = CountryConfig.current;
  CountryData get country => _country;

  // ─── Error state for auth screens ───────────────────────────
  Object? _lastError;
  Object? get lastError => _lastError;

  String? _blockedReason;
  String? get blockedReason => _blockedReason;

  Locale get _deviceLocale {
    final views = WidgetsBinding.instance.platformDispatcher.views;
    return views.isEmpty
        ? const Locale('en')
        : views.first.platformDispatcher.locale;
  }

  void _onAuth(AuthState state) {
    _session = state.session;
    _user = state.session?.user;

    if (_user == null) {
      _profile = null;
      _lang = AppLang.en;
      _country = CountryConfig.resolve(locale: _deviceLocale);
      NotificationProvider.instance.stop();
      DeviceGuard.instance.stop();
      KeepAwake.off();
      notifyListeners();
      return;
    }
    _loadProfile();
  }

  Future<void> _loadProfile() async {
    final uid = _user?.id;
    if (uid == null) return;

    _loadingProfile = true;
    _profileError = null;
    notifyListeners();

    try {
      final row = await Supabase.instance.client
          .from('profiles')
          .select()
          .eq('id', uid)
          .maybeSingle();

      if (row == null) throw StateError('Profile row missing for $uid');

      _profile = Map<String, dynamic>.from(row);
      // Drivers, shoppers and merchants: one phone only (not customers).
      DeviceGuard.instance
          .startIfNeeded(uid, normalizeRole(_profile!['role']?.toString()));

      final stored = await AppLangStore.loadUserChoice();
      final dbLang = AppLang.fromCode(_profile!['language']?.toString());
      _lang = AppLangStore.resolve(
        dbValue: _profile!['language'] != null ? dbLang : null,
        explicitChoice: stored,
      );

      final lat = (_profile!['lat'] as num?)?.toDouble();
      final lng = (_profile!['lng'] as num?)?.toDouble();
      _country = CountryConfig.resolve(
        lat: lat,
        lng: lng,
        locale: _deviceLocale,
        profileCountry: _profile!['country_code']?.toString(),
      );

      await NotificationProvider.instance.start(
        userId: uid,
        language: _lang,
      );
    } catch (e) {
      _profileError = e;
      debugPrint('AuthProvider._loadProfile failed: $e');
    } finally {
      _loadingProfile = false;
      notifyListeners();
    }
  }

  Future<void> refresh() => _loadProfile();

  Future<void> setLanguage(AppLang lang) async {
    _lang = lang;
    notifyListeners();
    // Switch the running app right away (no sign-out needed).
    appLanguageNotifier.value = lang;
    await AppLangStore.saveUserChoice(lang);

    final uid = _user?.id;
    if (uid == null) return;
    try {
      await Supabase.instance.client
          .from('profiles')
          .update({'language': lang.code})
          .eq('id', uid);
    } catch (e) {
      debugPrint('setLanguage db write failed: $e');
    }
  }

  void updateCountryFromPosition(double lat, double lng) {
    final next = CountryConfig.resolve(
      lat: lat,
      lng: lng,
      locale: _deviceLocale,
    );
    if (next.isoCode == _country.isoCode) return;
    _country = next;
    // New country: prices, payment methods and top-up options change too.
    PricingService.current(force: true);
    notifyListeners();
  }

  // ═══════════════════════════════════════════════════════════════
  // SIGN UP
  // ═══════════════════════════════════════════════════════════════
  /// Returns:
  ///   'driver_pending' | 'shopper' | 'merchant' | 'customer' | 'error'
  Future<String> signUp({
    required String email,
    required String password,
    required String firstName,
    required String surname,
    required String gender,
    required String phone,
    required String role,
    String? countryCode,
  }) async {
    _lastError = null;
    try {
      final res = await Supabase.instance.client.auth.signUp(
        email: email.trim(),
        password: password,
      );

      final user = res.user;
      if (user == null) {
        _lastError = 'Sign-up did not return a user.';
        return 'error';
      }

      // Email confirmation is required — cannot proceed yet.
      if (res.session == null) {
        _lastError =
            'Please check your email to confirm your account, then sign in.';
        return 'error';
      }

      _user = user;
      _session = res.session;

      final normalizedRole = role.toLowerCase();
      // Drivers require admin approval; everyone else is active immediately.
      final isActive = normalizedRole != 'driver';

      try {
        await Supabase.instance.client.from('profiles').upsert({
          'id': user.id,
          'first_name': firstName,
          'surname': surname,
          'full_name': '$firstName $surname'.trim(),
          'gender': gender,
          'phone': phone,
          'role': normalizedRole,
          'language': _lang.code,
          if (countryCode != null) 'country_code': countryCode,
          'is_active': isActive,
          'is_blocked': false,
          'wallet_balance': 0,
        });
      } catch (e) {
        debugPrint('signUp profile upsert failed: $e');
        _lastError = e;
        return 'error';
      }

      await _loadProfile();

      switch (normalizedRole) {
        case 'driver':
          return 'driver_pending';
        case 'shopper':
          return 'shopper';
        case 'merchant':
          return 'merchant';
        case 'customer':
        default:
          return 'customer';
      }
    } catch (e) {
      debugPrint('signUp failed: $e');
      _lastError = e;
      return 'error';
    }
  }

  // ═══════════════════════════════════════════════════════════════
  // SIGN IN
  // ═══════════════════════════════════════════════════════════════
  /// Returns:
  ///   'customer' | 'driver' | 'shopper' | 'merchant' | 'inactive' | 'blocked' | 'error'
  Future<String> signInWithPassword({
    required String email,
    required String password,
  }) async {
    _lastError = null;
    _blockedReason = null;
    DeviceGuard.instance.signingIn = true;

    try {
      final res = await Supabase.instance.client.auth.signInWithPassword(
        email: email.trim(),
        password: password,
      );

      if (res.user == null) {
        _lastError = 'Sign-in did not return a user.';
        return 'error';
      }

      _user = res.user;
      _session = res.session;
      await _loadProfile();

      final p = _profile;
      if (p == null) {
        _lastError = 'Profile not found for this account.';
        await Supabase.instance.client.auth.signOut();
        return 'error';
      }

      if (p['is_blocked'] == true) {
        _blockedReason =
            p['blocked_reason']?.toString() ?? 'Account has been blocked.';
        await Supabase.instance.client.auth.signOut();
        return 'blocked';
      }

      // The account's role decides which app opens — not the door the
      // user picked on the start screen.
      final r = normalizeRole(p['role']?.toString());
      if (!isAppRole(r)) {
        _lastError = 'This account has no access to the ko!ngo app.';
        await Supabase.instance.client.auth.signOut();
        return 'error';
      }

      if (p['is_active'] != true) {
        return 'inactive';
      }
      // One phone per account for drivers, shoppers, merchants: this phone
      // takes over and every other login of the account is ended.
      if (DeviceGuard.appliesTo(r)) await DeviceGuard.instance.claim();
      return r;
    } catch (e) {
      debugPrint('signInWithPassword failed: $e');
      _lastError = e;
      return 'error';
    } finally {
      DeviceGuard.instance.signingIn = false;
    }
  }

  // ═══════════════════════════════════════════════════════════════
  // CHECK EXISTING SESSION (used by SplashScreen)
  // ═══════════════════════════════════════════════════════════════
  /// Returns:
  ///   'customer' | 'driver' | 'shopper' | 'merchant' | 'inactive' | 'blocked' | 'none'
  Future<String> checkSession() async {
    try {
      final session = Supabase.instance.client.auth.currentSession;
      if (session == null) return 'none';

      _user = session.user;
      _session = session;
      await _loadProfile();

      final p = _profile;
      if (p == null) return 'none';
      if (p['is_blocked'] == true) return 'blocked';

      final r = normalizeRole(p['role']?.toString());
      if (!isAppRole(r)) return 'none';
      if (p['is_active'] != true) return 'inactive';
      return r;
    } catch (e) {
      debugPrint('checkSession failed: $e');
      return 'none';
    }
  }

  // ═══════════════════════════════════════════════════════════════
  // PASSWORD RESET
  // ═══════════════════════════════════════════════════════════════
  Future<bool> sendPasswordReset(String email) async {
    _lastError = null;
    try {
      await Supabase.instance.client.auth
          .resetPasswordForEmail(email.trim());
      return true;
    } catch (e) {
      debugPrint('sendPasswordReset failed: $e');
      _lastError = e;
      return false;
    }
  }

  // ═══════════════════════════════════════════════════════════════
  // SIGN OUT
  // ═══════════════════════════════════════════════════════════════
  Future<void> signOut() async {
    try {
      await Supabase.instance.client.auth.signOut();
    } catch (e) {
      debugPrint('signOut failed: $e');
    } finally {
      _profile = null;
      _user = null;
      _session = null;
      _lastError = null;
      _blockedReason = null;
      notifyListeners();
    }
  }

  @override
  void dispose() {
    _sub?.cancel();
    super.dispose();
  }
}
