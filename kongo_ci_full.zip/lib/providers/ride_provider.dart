﻿import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../utils/app_error.dart';
import '../utils/log.dart';
import '../models/ride.dart';

/// Canonical trip states for the driver-side flow.
enum TripState {
  enRouteToPickup,
  inProgress,
  completed,
}

extension TripStateX on TripState {
  String get dbValue {
    switch (this) {
      case TripState.enRouteToPickup:
        return 'en_route_to_pickup';
      case TripState.inProgress:
        return 'in_progress';
      case TripState.completed:
        return 'completed';
    }
  }

  static TripState fromString(String? raw) {
    switch ((raw ?? '').trim()) {
      case 'in_progress':
        return TripState.inProgress;
      case 'completed':
        return TripState.completed;
      case 'en_route_to_pickup':
      default:
        return TripState.enRouteToPickup;
    }
  }
}

class RideProvider extends ChangeNotifier {
  static const _tag = 'RideProvider';

  // ============================================================
  // ACTIVE RIDES (customer)
  // ============================================================
  List<Map<String, dynamic>> _activeRides = [];
  List<Map<String, dynamic>> get activeRides => _activeRides;

  /// Typed view — new code should prefer this.
  List<Ride> get activeRidesTyped =>
      _activeRides.map(Ride.fromJson).toList(growable: false);

  bool _isLoading = false;
  bool get isLoading => _isLoading;

  /// Populated when [fetchActiveRides] fails. Screens can render
  /// `ErrorUI.inline(error!)` and offer retry.
  AppError? _error;
  AppError? get error => _error;

  /// Guards against overlapping fetches.
  bool _fetching = false;

  // ============================================================
  // DRIVER-SIDE TRIP STATE
  // ============================================================
  LatLng? _driverPosition;
  LatLng? get driverPosition => _driverPosition;

  LatLng? _customerPosition;
  LatLng? get customerPosition => _customerPosition;

  List<LatLng> _routePolylinePoints = [];
  List<LatLng> get routePolylinePoints => _routePolylinePoints;

  /// String form, kept for backwards compatibility with existing screens
  /// (e.g. `active_trip_execution_screen.dart` compares against
  /// `'en_route_to_pickup'`). New code should use [tripState].
  String _currentTripState = 'en_route_to_pickup';
  String get currentTripState => _currentTripState;

  /// Enum form — new code should use this.
  TripState get tripState => TripStateX.fromString(_currentTripState);

  bool _hasAcceptedShown = false;
  bool get hasAcceptedShown => _hasAcceptedShown;

  double? _tripDistanceKm;
  double? get tripDistanceKm => _tripDistanceKm;

  // ============================================================
  // CUSTOMER FETCH
  // ============================================================
  Future<void> fetchActiveRides(String userId) async {
    if (_fetching) return;
    _fetching = true;

    _isLoading = true;
    _error = null;
    notifyListeners();

    try {
      final response = await Supabase.instance.client
          .from('rides')
          .select()
          .eq('customer_id', userId)
          .inFilter('status', ['pending', 'accepted', 'in_progress'])
          .order('created_at', ascending: false);

      _activeRides = List<Map<String, dynamic>>.from(response);
    } catch (e, s) {
      Log.e(_tag, 'fetchActiveRides failed', e, s);
      _error = AppError.from(e, onRetry: () => fetchActiveRides(userId));
    } finally {
      _fetching = false;
      _isLoading = false;
      notifyListeners();
    }
  }

  // ============================================================
  // SETTERS
  // ============================================================
  void updateDriverPosition(LatLng? newPosition) {
    _driverPosition = newPosition;
    notifyListeners();
  }

  void updateCustomerPosition(LatLng? newPosition) {
    _customerPosition = newPosition;
    notifyListeners();
  }

  void updateRoutePoints(List<LatLng> newPoints) {
    _routePolylinePoints = newPoints;
    notifyListeners();
  }

  /// Accepts the string form (`'en_route_to_pickup'` etc.) — existing
  /// screens call it this way and will keep working.
  void updateTripStatus(String newStatus) {
    _currentTripState = TripStateX.fromString(newStatus).dbValue;
    notifyListeners();
  }

  /// Enum form for new code.
  void updateTripState(TripState state) {
    _currentTripState = state.dbValue;
    notifyListeners();
  }

  void setAcceptedShown(bool value) {
    _hasAcceptedShown = value;
    notifyListeners();
  }

  void updateTripDistance(double? km) {
    _tripDistanceKm = km;
    notifyListeners();
  }

  // ============================================================
  // RESET
  // ============================================================
  /// Clears the driver-side trip data only — leaves active rides intact.
  void clearTripData() {
    _driverPosition = null;
    _customerPosition = null;
    _routePolylinePoints = [];
    _currentTripState = 'en_route_to_pickup';
    _hasAcceptedShown = false;
    _tripDistanceKm = null;
    notifyListeners();
  }

  /// Full reset — call on logout / account switch.
  void reset() {
    _activeRides = [];
    _isLoading = false;
    _fetching = false;
    _error = null;
    _driverPosition = null;
    _customerPosition = null;
    _routePolylinePoints = [];
    _currentTripState = 'en_route_to_pickup';
    _hasAcceptedShown = false;
    _tripDistanceKm = null;
    notifyListeners();
  }
}
