// lib/providers/cart_provider.dart
//
// Shared cart state for Food/Grocery/Pharmacy. Scoped to one partner
// at a time: adding an item from a different partner clears the cart
// and starts a new one (with a dialog warning in the UI layer).

import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:efuride_app/models/cart_line.dart';
import 'package:efuride_app/models/partner.dart';
import 'package:efuride_app/models/product.dart';

class CartProvider extends ChangeNotifier {
  CartProvider() {
    _restore();
  }

  static const _kKey = 'cart_v1';

  String? _partnerId;
  String? _partnerName;
  String? _serviceType; // 'Food' | 'Grocery' | 'Pharmacy'
  double _deliveryFee = 0;
  double _minOrder = 0;
  String? _prescriptionUrl;
  final List<CartLine> _lines = [];

  String? get partnerId => _partnerId;
  String? get partnerName => _partnerName;
  String? get serviceType => _serviceType;
  double get deliveryFee => _deliveryFee;
  double get minOrder => _minOrder;
  String? get prescriptionUrl => _prescriptionUrl;

  List<CartLine> get lines => List.unmodifiable(_lines);

  bool get isEmpty => _lines.isEmpty;
  bool get isNotEmpty => _lines.isNotEmpty;

  int get itemCount => _lines.fold(0, (s, l) => s + l.qty);

  double get subtotal =>
      _lines.fold<double>(0, (s, l) => s + l.lineTotal);

  double get total => subtotal + _deliveryFee;

  bool get meetsMinOrder => subtotal >= _minOrder;

  /// Re-read the store's current delivery fee and minimum order, so a
  /// saved cart never shows old amounts after the merchant changes them.
  Future<void> refreshPartnerFees(
      Future<Partner?> Function(String id) fetch) async {
    final id = _partnerId;
    if (id == null) return;
    try {
      final p = await fetch(id);
      if (p == null || p.id != _partnerId) return;
      if (p.deliveryFee == _deliveryFee && p.minOrder == _minOrder) return;
      _deliveryFee = p.deliveryFee;
      _minOrder = p.minOrder;
      _partnerName = p.name;
      _persist();
      notifyListeners();
    } catch (e) {
      debugPrint('CartProvider.refreshPartnerFees failed: $e');
    }
  }

  // ────────────────────────────────────────────────────────────
  // MUTATIONS
  // ────────────────────────────────────────────────────────────

  /// Bind the cart to a partner. Returns false if a conflicting
  /// partner is already active — the caller decides whether to warn.
  bool bindTo(Partner partner, String serviceType) {
    if (_partnerId == null || _partnerId == partner.id) {
      _partnerId = partner.id;
      _partnerName = partner.name;
      _serviceType = serviceType;
      _deliveryFee = partner.deliveryFee;
      _minOrder = partner.minOrder;
      _persist();
      notifyListeners();
      return true;
    }
    return false;
  }

  /// Replace the current cart with this partner's fresh cart.
  void resetTo(Partner partner, String serviceType) {
    _lines.clear();
    _partnerId = partner.id;
    _partnerName = partner.name;
    _serviceType = serviceType;
    _deliveryFee = partner.deliveryFee;
    _minOrder = partner.minOrder;
    _persist();
    notifyListeners();
  }

  void add(Product product, {int qty = 1}) {
    final idx = _lines.indexWhere((l) => l.productId == product.id);
    if (idx >= 0) {
      _lines[idx].qty = (_lines[idx].qty + qty).clamp(1, 99);
    } else {
      _lines.add(CartLine(
        productId: product.id,
        name: product.name,
        description: product.description,
        emoji: product.emoji,
        imageUrl: product.imageUrl,
        unitPrice: product.price,
        qty: qty.clamp(1, 99),
      ));
    }
    _persist();
    notifyListeners();
  }

  void setQty(String productId, int qty) {
    final idx = _lines.indexWhere((l) => l.productId == productId);
    if (idx < 0) return;
    if (qty <= 0) {
      _lines.removeAt(idx);
    } else {
      _lines[idx].qty = qty.clamp(1, 99);
    }
    _persist();
    notifyListeners();
  }

  void increment(String productId) {
    final idx = _lines.indexWhere((l) => l.productId == productId);
    if (idx < 0) return;
    _lines[idx].qty = (_lines[idx].qty + 1).clamp(1, 99);
    _persist();
    notifyListeners();
  }

  void decrement(String productId) {
    final idx = _lines.indexWhere((l) => l.productId == productId);
    if (idx < 0) return;
    final next = _lines[idx].qty - 1;
    if (next <= 0) {
      _lines.removeAt(idx);
    } else {
      _lines[idx].qty = next;
    }
    _persist();
    notifyListeners();
  }

  void remove(String productId) {
    _lines.removeWhere((l) => l.productId == productId);
    _persist();
    notifyListeners();
  }

  void setPrescriptionUrl(String? url) {
    _prescriptionUrl = url;
    _persist();
    notifyListeners();
  }

  void clear() {
    _lines.clear();
    _partnerId = null;
    _partnerName = null;
    _serviceType = null;
    _deliveryFee = 0;
    _minOrder = 0;
    _prescriptionUrl = null;
    _persist();
    notifyListeners();
  }

  int qtyFor(String productId) {
    final idx = _lines.indexWhere((l) => l.productId == productId);
    return idx < 0 ? 0 : _lines[idx].qty;
  }

  // ────────────────────────────────────────────────────────────
  // PERSISTENCE
  // ────────────────────────────────────────────────────────────
  Future<void> _persist() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final payload = {
        'partner_id': _partnerId,
        'partner_name': _partnerName,
        'service_type': _serviceType,
        'delivery_fee': _deliveryFee,
        'min_order': _minOrder,
        'prescription_url': _prescriptionUrl,
        'lines': _lines.map((l) => l.toMap()).toList(),
      };
      await prefs.setString(_kKey, jsonEncode(payload));
    } catch (e) {
      debugPrint('CartProvider._persist failed: $e');
    }
  }

  Future<void> _restore() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final raw = prefs.getString(_kKey);
      if (raw == null || raw.isEmpty) return;

      final m = jsonDecode(raw) as Map<String, dynamic>;
      _partnerId = m['partner_id']?.toString();
      _partnerName = m['partner_name']?.toString();
      _serviceType = m['service_type']?.toString();
      _deliveryFee = (m['delivery_fee'] as num?)?.toDouble() ?? 0;
      _minOrder = (m['min_order'] as num?)?.toDouble() ?? 0;
      _prescriptionUrl = m['prescription_url']?.toString();

      final rawLines = m['lines'];
      if (rawLines is List) {
        _lines
          ..clear()
          ..addAll(
            rawLines
                .whereType<Map>()
                .map((e) => CartLine.fromMap(Map<String, dynamic>.from(e))),
          );
      }
      notifyListeners();
    } catch (e) {
      debugPrint('CartProvider._restore failed: $e');
    }
  }
}
