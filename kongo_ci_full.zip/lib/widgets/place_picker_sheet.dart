// lib/widgets/place_picker_sheet.dart
//
// Pick a real place (Google search) — returns its address AND map point,
// so drivers can navigate there. Used where a plain text box used to be.
//
//   final place = await showPlacePicker(context,
//       title: 'Pickup from', near: myLatLng);
//   if (place != null) { place.address; place.latLng; }

import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

import 'package:efuride_app/config/efuride_palette.dart';
import 'package:efuride_app/config/country_config.dart';
import 'package:efuride_app/l10n/app_strings.dart';
import 'package:efuride_app/services/google_maps_service.dart';
import 'package:efuride_app/widgets/debouncer.dart';
import 'package:efuride_app/widgets/k_icon.dart';

class PickedPlace {
  final String label;   // short: "12 Main Rd"
  final String address; // full
  final LatLng latLng;
  const PickedPlace(this.label, this.address, this.latLng);
}

Future<PickedPlace?> showPlacePicker(
  BuildContext context, {
  required String title,
  LatLng? near,
  bool offerCurrentLocation = true,
}) {
  return showModalBottomSheet<PickedPlace>(
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.white,
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
    ),
    builder: (_) => _PlacePicker(
      title: title,
      near: near,
      offerCurrentLocation: offerCurrentLocation,
    ),
  );
}

/// Current GPS position as a place (address looked up), or null.
Future<PickedPlace?> currentPlace() async {
  try {
    final perm = await Geolocator.checkPermission();
    if (perm == LocationPermission.denied ||
        perm == LocationPermission.deniedForever) {
      return null;
    }
    Position? pos;
    if (!kIsWeb) {
      try {
        pos = await Geolocator.getLastKnownPosition();
      } catch (_) {}
    }
    pos ??= await Geolocator.getCurrentPosition(
      desiredAccuracy: LocationAccuracy.medium,
      timeLimit: const Duration(seconds: 20),
    );
    final at = LatLng(pos.latitude, pos.longitude);
    final place = await GoogleMapsService.reverseGeocode(at);
    if (place == null) {
      return PickedPlace(tr('Current location'), tr('Current location'), at);
    }
    return PickedPlace(place.shortLabel, place.displayAddress, at);
  } catch (_) {
    return null;
  }
}

class _PlacePicker extends StatefulWidget {
  final String title;
  final LatLng? near;
  final bool offerCurrentLocation;
  const _PlacePicker({
    required this.title,
    required this.near,
    required this.offerCurrentLocation,
  });

  @override
  State<_PlacePicker> createState() => _PlacePickerState();
}

class _PlacePickerState extends State<_PlacePicker> {
  final _ctrl = TextEditingController();
  final _debouncer = Debouncer(milliseconds: 350);
  List<PlacePrediction> _results = [];
  bool _busy = false;
  bool _searched = false;
  int _rid = 0;

  @override
  void dispose() {
    _debouncer.dispose();
    _ctrl.dispose();
    super.dispose();
  }

  /// Only makes nearby places come first; search works without it.
  Future<LatLng?> _origin() async {
    if (widget.near != null) return widget.near;
    if (!kIsWeb) {
      try {
        final last = await Geolocator.getLastKnownPosition();
        if (last != null) return LatLng(last.latitude, last.longitude);
      } catch (_) {}
    }
    return const LatLng(-15.0, 25.0); // middle of the countries we serve
  }

  void _search(String q) {
    final text = q.trim();
    final rid = ++_rid;
    if (text.isEmpty) {
      setState(() {
        _results = [];
        _busy = false;
        _searched = false;
      });
      return;
    }
    setState(() => _busy = true);
    _debouncer.debounce(() async {
      try {
        final origin = await _origin();
        final res = origin == null
            ? const <PlacePrediction>[]
            : await GoogleMapsService.autocomplete(
                query: text,
                origin: origin,
                radiusMeters: 50000,
                // No GPS: keep results in the customer's own country.
                countryCode: CountryConfig.servedIso);
        if (!mounted || rid != _rid) return;
        setState(() {
          _results = res;
          _busy = false;
          _searched = true;
        });
      } catch (_) {
        if (!mounted || rid != _rid) return;
        setState(() {
          _busy = false;
          _searched = true;
        });
      }
    });
  }

  Future<void> _pick(PlacePrediction p) async {
    setState(() => _busy = true);
    final d = await GoogleMapsService.details(p.placeId);
    if (!mounted) return;
    setState(() => _busy = false);
    if (d == null) return;
    Navigator.pop(context, PickedPlace(d.shortLabel, d.displayAddress, d.latLng));
  }

  Future<void> _useCurrent() async {
    setState(() => _busy = true);
    final here = await currentPlace();
    if (!mounted) return;
    setState(() => _busy = false);
    if (here != null) Navigator.pop(context, here);
  }

  @override
  Widget build(BuildContext context) {
    final bottom = MediaQuery.of(context).viewInsets.bottom;
    return Padding(
      padding: EdgeInsets.fromLTRB(16, 12, 16, bottom + 16),
      child: SizedBox(
        height: MediaQuery.of(context).size.height * 0.75,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Center(
              child: Container(
                width: 44,
                height: 5,
                decoration: BoxDecoration(
                  color: EfuridePalette.divider,
                  borderRadius: BorderRadius.circular(3),
                ),
              ),
            ),
            const SizedBox(height: 14),
            Text(widget.title,
                style: const TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.w800,
                    color: EfuridePalette.ink)),
            const SizedBox(height: 12),
            TextField(
              controller: _ctrl,
              autofocus: true,
              onChanged: _search,
              style: const TextStyle(fontSize: 16),
              decoration: InputDecoration(
                hintText: tr('Street, suburb or landmark'),
                prefixIcon: const Icon(Icons.search),
                filled: true,
                fillColor: EfuridePalette.greyBg,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(14),
                  borderSide: BorderSide.none,
                ),
                suffixIcon: _busy
                    ? const Padding(
                        padding: EdgeInsets.all(14),
                        child: SizedBox(
                            width: 18,
                            height: 18,
                            child: CircularProgressIndicator(strokeWidth: 2)),
                      )
                    : null,
              ),
            ),
            const SizedBox(height: 8),
            if (widget.offerCurrentLocation)
              ListTile(
                contentPadding: EdgeInsets.zero,
                leading: const CircleAvatar(
                  backgroundColor: EfuridePalette.lightBlue,
                  child: Icon(Icons.my_location, color: EfuridePalette.blue),
                ),
                title: Text(tr('Use my current location'),
                    style: const TextStyle(
                        fontSize: 16, fontWeight: FontWeight.w700)),
                onTap: _busy ? null : _useCurrent,
              ),
            const Divider(height: 1),
            Expanded(
              child: _results.isEmpty
                  ? (_searched && !_busy
                      ? Center(
                          child: Text(
                            tr('No places found. Try a street name or landmark.'),
                            textAlign: TextAlign.center,
                            style: const TextStyle(
                                fontSize: 15, color: EfuridePalette.inkMuted),
                          ),
                        )
                      : const SizedBox.shrink())
                  : ListView.separated(
                      itemCount: _results.length,
                      separatorBuilder: (_, __) => const Divider(height: 1),
                      itemBuilder: (_, i) {
                        final p = _results[i];
                        return ListTile(
                          contentPadding: EdgeInsets.zero,
                          leading: const KIcon(Icons.location_on_outlined,
                              color: EfuridePalette.inkMuted),
                          title: Text(
                            p.primaryText.isNotEmpty
                                ? p.primaryText
                                : p.fullDescription,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                                fontSize: 15.5, fontWeight: FontWeight.w700),
                          ),
                          subtitle: p.secondaryText.isEmpty
                              ? null
                              : Text(p.secondaryText,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(fontSize: 14)),
                          onTap: _busy ? null : () => _pick(p),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }
}
