// lib/widgets/private_image.dart
//
// Shows a picture from a PRIVATE storage folder (driver and vehicle
// documents). Those files have no public link; this asks the server for a
// temporary link (1 hour) that only works for people allowed to see the
// file (the owner, or admin). Links stored before the folders became
// private are converted automatically. Any other picture is shown as is.

import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class PrivateFile {
  static const privateBuckets = {'driver_documents', 'vehicle_documents'};
  static final Map<String, (String, DateTime)> _cache = {};
  static final _re = RegExp(
      r'/storage/v1/object/(?:public|sign|authenticated)/([^/]+)/([^?]+)');

  /// A link that can be opened now.
  static Future<String> resolve(String url) async {
    final m = _re.firstMatch(url);
    if (m == null) return url;
    final bucket = m.group(1)!;
    if (!privateBuckets.contains(bucket)) return url;
    final path = Uri.decodeComponent(m.group(2)!);
    final key = '$bucket/$path';
    final hit = _cache[key];
    if (hit != null && hit.$2.isAfter(DateTime.now())) return hit.$1;
    final signed = await Supabase.instance.client.storage
        .from(bucket)
        .createSignedUrl(path, 3600);
    _cache[key] = (signed, DateTime.now().add(const Duration(minutes: 50)));
    return signed;
  }
}

class PrivateImage extends StatelessWidget {
  final String url;
  final BoxFit? fit;
  final double? width;
  final double? height;
  final Widget Function(BuildContext, Object, StackTrace?)? errorBuilder;

  const PrivateImage({
    super.key,
    required this.url,
    this.fit,
    this.width,
    this.height,
    this.errorBuilder,
  });

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<String>(
      future: PrivateFile.resolve(url),
      builder: (context, snap) {
        if (snap.hasError) {
          return errorBuilder?.call(context, snap.error!, snap.stackTrace) ??
              SizedBox(width: width, height: height,
                  child: const Center(child: Icon(Icons.broken_image_outlined)));
        }
        if (!snap.hasData) {
          return SizedBox(
            width: width,
            height: height,
            child: const Center(
              child: SizedBox(
                  width: 18, height: 18,
                  child: CircularProgressIndicator(strokeWidth: 2)),
            ),
          );
        }
        return Image.network(snap.data!,
            fit: fit, width: width, height: height, errorBuilder: errorBuilder);
      },
    );
  }
}
