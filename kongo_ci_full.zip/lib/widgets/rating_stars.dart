﻿import 'package:flutter/material.dart';

class _Palette {
  static const accent = Color(0xFFF2B705);
  static const inkMuted = Color(0xFF8C8378);
  static const divider = Color(0xFFE8E2D5);
}

/// Display-only star rating.
///
/// Supports fractional ratings (e.g. 4.7) with a half-star for the
/// fractional part. Non-interactive — use a `Slider` or custom control
/// for input.
///
/// Example:
///
/// ```dart
/// RatingStars(rating: 4.5)                    // 4.5 out of 5
/// RatingStars(rating: 3.0, size: 16)          // smaller
/// RatingStars(rating: 5.0, showEmpty: false)  // 5 solid, no empty outlines
/// ```
class RatingStars extends StatelessWidget {
  /// Rating value. Clamped to `[0, maxRating]`.
  final double rating;

  /// Total star positions to render.
  final int maxRating;

  /// Icon size.
  final double size;

  /// Colour of filled stars.
  final Color filledColor;

  /// Colour of empty stars.
  final Color emptyColor;

  /// Spacing between stars.
  final double spacing;

  /// If false, empty positions are hidden.
  final bool showEmpty;

  /// Optional semantic label. Defaults to "X out of Y stars".
  final String? semanticLabel;

  const RatingStars({
    super.key,
    required this.rating,
    this.maxRating = 5,
    this.size = 20,
    this.filledColor = _Palette.accent,
    this.emptyColor = _Palette.divider,
    this.spacing = 2,
    this.showEmpty = true,
    this.semanticLabel,
  });

  @override
  Widget build(BuildContext context) {
    final safeRating = rating.clamp(0, maxRating).toDouble();
    final label = semanticLabel ??
        '${safeRating.toStringAsFixed(1)} out of $maxRating stars';

    return Semantics(
      label: label,
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: List.generate(maxRating, (i) {
          final diff = safeRating - i;
          if (diff >= 1) {
            return _star(Icons.star, filledColor);
          }
          if (diff >= 0.25 && diff < 0.75) {
            return _star(Icons.star_half, filledColor);
          }
          if (diff >= 0.75) {
            return _star(Icons.star, filledColor);
          }
          // Empty position
          if (!showEmpty) return const SizedBox.shrink();
          return _star(Icons.star_border, emptyColor);
        }),
      ),
    );
  }

  Widget _star(IconData icon, Color color) {
    return Padding(
      padding: EdgeInsets.only(right: spacing),
      child: Icon(icon, color: color, size: size),
    );
  }
}
