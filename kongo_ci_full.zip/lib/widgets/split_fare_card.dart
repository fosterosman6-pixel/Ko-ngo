// lib/widgets/split_fare_card.dart
//
// "Split the fare": choose how many people ride together, see what each one
// pays, and send that to friends (WhatsApp, SMS...). No money moves through
// the app: each person pays the driver their share.

import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';
import 'package:efuride_app/config/country_config.dart';
import 'package:efuride_app/config/efuride_palette.dart';
import 'package:efuride_app/l10n/app_strings.dart';

class SplitFareCard extends StatefulWidget {
  final double total;
  const SplitFareCard({super.key, required this.total});

  @override
  State<SplitFareCard> createState() => _SplitFareCardState();
}

class _SplitFareCardState extends State<SplitFareCard> {
  int _people = 1;

  double get _each => _people <= 0 ? widget.total : widget.total / _people;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: EfuridePalette.divider),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [
            const Icon(Icons.groups_2_outlined, color: EfuridePalette.ink),
            const SizedBox(width: 10),
            Expanded(
              child: Text(tr('Split the fare'),
                  style: const TextStyle(
                      fontSize: 16.5, fontWeight: FontWeight.w900)),
            ),
            IconButton(
              onPressed:
                  _people > 1 ? () => setState(() => _people--) : null,
              icon: const Icon(Icons.remove_circle_outline),
            ),
            SizedBox(
              width: 24,
              child: Text('$_people',
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                      fontSize: 18, fontWeight: FontWeight.w900)),
            ),
            IconButton(
              onPressed:
                  _people < 6 ? () => setState(() => _people++) : null,
              icon: const Icon(Icons.add_circle_outline),
            ),
          ]),
          if (_people > 1) ...[
            const SizedBox(height: 4),
            Text(tr('Each person pays {0}', [CountryConfig.money(_each)]),
                style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w900,
                    color: EfuridePalette.ink)),
            const SizedBox(height: 2),
            Text(
                tr('Each person pays the driver their share. Nothing is taken from your wallet for others.'),
                style: const TextStyle(
                    fontSize: 13, color: EfuridePalette.inkMuted)),
            const SizedBox(height: 8),
            OutlinedButton.icon(
              onPressed: () => Share.share(tr(
                  'Our ko!ngo ride costs {0} in total. With {1} of us, each pays {2}.',
                  [
                    CountryConfig.money(widget.total),
                    '$_people',
                    CountryConfig.money(_each)
                  ])),
              icon: const Icon(Icons.share_outlined),
              label: Text(tr('Send to friends')),
            ),
          ],
        ],
      ),
    );
  }
}
