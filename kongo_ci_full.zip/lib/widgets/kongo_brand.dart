// lib/widgets/kongo_brand.dart
//
// The ko!ngo logo row used at the top of every home screen (customer,
// driver, shopper, merchant): the leopard badge, the "ko!ngo" wordmark and
// a small role line under it, on the cream background.

import 'package:flutter/material.dart';

import 'package:efuride_app/config/efuride_palette.dart';

class KongoBrand extends StatelessWidget {
  /// Small line under the wordmark, e.g. "Driver" or "Shopper".
  final String? role;
  final double size;

  const KongoBrand({super.key, this.role, this.size = 40});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: size,
          height: size,
          decoration: const BoxDecoration(
            color: Colors.black,
            shape: BoxShape.circle,
          ),
          child: ClipOval(
            child: Image.asset(
              'assets/images/leopard_logo.png',
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => const Icon(Icons.pets,
                  color: EfuridePalette.accent, size: 22),
            ),
          ),
        ),
        const SizedBox(width: 10),
        Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            RichText(
              text: const TextSpan(
                style: TextStyle(
                  color: EfuridePalette.ink,
                  fontSize: 20,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 0.6,
                  height: 1.05,
                ),
                children: [
                  TextSpan(text: 'ko'),
                  TextSpan(
                    text: '!',
                    style: TextStyle(color: EfuridePalette.accent),
                  ),
                  TextSpan(text: 'ngo'),
                ],
              ),
            ),
            if ((role ?? '').isNotEmpty) ...[
              const SizedBox(height: 2),
              Text(
                role!,
                style: const TextStyle(
                  color: EfuridePalette.inkMuted,
                  fontSize: 13,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ],
        ),
      ],
    );
  }
}
