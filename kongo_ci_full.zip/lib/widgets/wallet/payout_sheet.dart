// lib/widgets/wallet/payout_sheet.dart
//
// "Request payout" sheet shared by drivers, shoppers and merchants.
// The server checks the amount again (balance minus requests waiting).

import 'package:flutter/material.dart';

import 'package:efuride_app/config/country_config.dart';
import 'package:efuride_app/config/efuride_palette.dart';
import 'package:efuride_app/l10n/app_strings.dart';
import 'package:efuride_app/services/wallet_service.dart';
import 'package:efuride_app/utils/app_error.dart';
import 'package:efuride_app/utils/error_ui.dart';
import 'package:efuride_app/utils/money.dart';
import 'package:efuride_app/services/connection_service.dart';

/// Returns true when a request was sent.
Future<bool> showPayoutSheet(BuildContext context, double available) async {
  if (available <= 0) {
    ErrorUI.showSnack(
      context,
      AppError(
        title: tr('Nothing to withdraw'),
        message: tr('You don\'t have a balance to pay out yet.'),
        icon: Icons.info_outline,
      ),
    );
    return false;
  }

  final saved = await WalletService.getSavedBankDetails();
  final amountCtrl = TextEditingController(text: available.toStringAsFixed(2));
  final bankCtrl = TextEditingController(text: saved?['bank_name'] ?? '');
  final acctCtrl = TextEditingController(text: saved?['account_number'] ?? '');
  final nameCtrl = TextEditingController(text: saved?['account_holder'] ?? '');

  try {
    if (!context.mounted) return false;
    final ok = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      backgroundColor: EfuridePalette.cream,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (ctx) => Padding(
        padding: EdgeInsets.only(
          left: 16,
          right: 16,
          top: 20,
          bottom: MediaQuery.of(ctx).viewInsets.bottom + 20,
        ),
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text(tr('Request payout'),
                  style: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: EfuridePalette.ink)),
              const SizedBox(height: 6),
              Text(tr('Available: {0}', [fmtMoney(available)]),
                  style: const TextStyle(
                      color: EfuridePalette.inkMuted, fontSize: 14)),
              const SizedBox(height: 16),
              TextField(
                controller: amountCtrl,
                keyboardType:
                    const TextInputType.numberWithOptions(decimal: true),
                decoration: InputDecoration(
                  labelText: tr('Amount'),
                  border: const OutlineInputBorder(),
                  prefixText: '${CountryConfig.symbol} ',
                ),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: bankCtrl,
                decoration: InputDecoration(
                    labelText: tr('Bank or mobile money'),
                    border: const OutlineInputBorder()),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: acctCtrl,
                decoration: InputDecoration(
                    labelText: tr('Account or phone number'),
                    border: const OutlineInputBorder()),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: nameCtrl,
                decoration: InputDecoration(
                    labelText: tr('Account holder name'),
                    border: const OutlineInputBorder()),
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: EfuridePalette.accent,
                  foregroundColor: EfuridePalette.accentInk,
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12)),
                ),
                onPressed: () {
                  final amt = double.tryParse(
                          amountCtrl.text.trim().replaceAll(',', '.')) ??
                      0;
                  if (amt <= 0 || amt > available) {
                    ErrorUI.showSnack(
                      ctx,
                      AppError(
                        title: tr('Invalid amount'),
                        message: tr(
                            'Enter an amount within your available balance.'),
                        icon: Icons.info_outline,
                      ),
                    );
                    return;
                  }
                  if (bankCtrl.text.trim().isEmpty ||
                      acctCtrl.text.trim().isEmpty ||
                      nameCtrl.text.trim().isEmpty) {
                    ErrorUI.showSnack(
                      ctx,
                      AppError(
                        title: tr('Missing bank details'),
                        message: tr('Fill in all your bank information.'),
                        icon: Icons.info_outline,
                      ),
                    );
                    return;
                  }
                  Navigator.pop(ctx, true);
                },
                child: Text(tr('Submit payout request'),
                    style: const TextStyle(fontWeight: FontWeight.bold)),
              ),
            ],
          ),
        ),
      ),
    );
    if (ok != true) return false;

    final amount =
        double.tryParse(amountCtrl.text.trim().replaceAll(',', '.')) ?? 0;
    if (!context.mounted ||
        !await ConnectionService.instance.ensureOnline(context)) {
      return false;
    }
    final result = await WalletService.requestPayout(
      amount: amount,
      bankName: bankCtrl.text.trim(),
      accountNumber: acctCtrl.text.trim(),
      accountHolder: nameCtrl.text.trim(),
    );
    if (!context.mounted) return result.success;
    ErrorUI.showSnack(
      context,
      result.success
          ? AppError(
              title: tr('Payout requested'),
              message: tr('ko!ngo will send it and let you know.'),
              icon: Icons.check_circle_outline,
            )
          : AppError(
              title: tr('Couldn\'t submit payout'),
              message: (result.message ?? '')
                  .replaceFirst(RegExp(r'^kongo_\w+:\s*'), ''),
              icon: Icons.error_outline,
            ),
    );
    return result.success;
  } finally {
    amountCtrl.dispose();
    bankCtrl.dispose();
    acctCtrl.dispose();
    nameCtrl.dispose();
  }
}
