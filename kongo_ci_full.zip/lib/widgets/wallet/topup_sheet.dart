// lib/widgets/wallet/topup_sheet.dart
//
// "Top up your wallet": pick an amount and how you paid, then send the
// request. ko!ngo checks the payment and the balance goes up (admin app →
// Top-ups). Used by the driver wallet and the driver home warning.
// Returns true when a request was sent.

import 'package:flutter/material.dart';

import 'package:efuride_app/config/country_config.dart';
import 'package:efuride_app/config/efuride_palette.dart';
import 'package:efuride_app/l10n/app_strings.dart';
import 'package:efuride_app/services/pricing_service.dart';
import 'package:efuride_app/services/wallet_service.dart';
import 'package:efuride_app/utils/app_error.dart';
import 'package:efuride_app/utils/error_ui.dart';

List<double> _quickAmounts() {
  final base = PricingService.last.minimumFare;
  double nice(double v) {
    if (v >= 1000) return (v / 500).round() * 500;
    if (v >= 100) return (v / 50).round() * 50;
    if (v >= 10) return (v / 10).round() * 10;
    return v.roundToDouble().clamp(1, double.infinity);
  }

  return <double>{
    for (final m in [2, 4, 8, 20]) nice(base * m),
  }.toList()
    ..sort();
}

IconData _methodIcon(TopupMethod m) {
  switch (m.id) {
    case 'eft':
    case 'bank':
      return Icons.account_balance;
    case 'cash':
      return Icons.payments_outlined;
    case 'snapscan':
      return Icons.qr_code_2;
    case 'card':
      return Icons.credit_card;
    default:
      return Icons.phone_android; // mobile money
  }
}

Future<bool> showTopupSheet(BuildContext context,
    {double? suggested}) async {
  try {
    await PricingService.current();
  } catch (_) {}
  if (!context.mounted) return false;

  final amountCtrl = TextEditingController(
      text: suggested != null && suggested > 0
          ? suggested.toStringAsFixed(suggested == suggested.roundToDouble() ? 0 : 2)
          : '');
  final refCtrl = TextEditingController();
  final methods = PricingService.last.topupMethods.isNotEmpty
      ? PricingService.last.topupMethods
      : CountryPricing.fallback.topupMethods;
  var method = methods.first.id;
  TopupMethod picked() =>
      methods.firstWhere((m) => m.id == method, orElse: () => methods.first);
  final quick = _quickAmounts();

  try {
    final ok = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setS) => Padding(
          padding: EdgeInsets.fromLTRB(
              20, 20, 20, MediaQuery.of(ctx).viewInsets.bottom + 20),
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Text(tr('Top up your wallet'),
                    style: const TextStyle(
                        fontSize: 21, fontWeight: FontWeight.w800)),
                const SizedBox(height: 6),
                Text(
                  tr('Pay ko!ngo with one of the methods below, then send this request. Your balance goes up when ko!ngo confirms the payment.'),
                  style: const TextStyle(
                      fontSize: 15, height: 1.4, color: EfuridePalette.inkMuted),
                ),
                const SizedBox(height: 16),
                TextField(
                  controller: amountCtrl,
                  autofocus: true,
                  keyboardType:
                      const TextInputType.numberWithOptions(decimal: true),
                  style: const TextStyle(
                      fontSize: 22, fontWeight: FontWeight.w800),
                  decoration: InputDecoration(
                    labelText: tr('Amount'),
                    prefixText: '${CountryConfig.symbol} ',
                    filled: true,
                    fillColor: EfuridePalette.greyBg,
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: BorderSide.none,
                    ),
                  ),
                ),
                const SizedBox(height: 10),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    for (final a in quick)
                      ActionChip(
                        label: Text(CountryConfig.money(a),
                            style: const TextStyle(
                                fontSize: 15, fontWeight: FontWeight.w700)),
                        onPressed: () => setS(() => amountCtrl.text =
                            a == a.roundToDouble()
                                ? a.toStringAsFixed(0)
                                : a.toString()),
                      ),
                  ],
                ),
                const SizedBox(height: 16),
                Text(tr('How did you pay?'),
                    style: const TextStyle(
                        fontSize: 15, fontWeight: FontWeight.w700)),
                const SizedBox(height: 8),
                for (final m in methods)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 8),
                    child: Material(
                      color: method == m.id
                          ? EfuridePalette.accent.withValues(alpha: 0.12)
                          : Colors.white,
                      borderRadius: BorderRadius.circular(12),
                      child: InkWell(
                        borderRadius: BorderRadius.circular(12),
                        onTap: () => setS(() => method = m.id),
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 14, vertical: 14),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(
                              color: method == m.id
                                  ? EfuridePalette.accent
                                  : EfuridePalette.divider,
                              width: method == m.id ? 1.6 : 1,
                            ),
                          ),
                          child: Row(children: [
                            Icon(_methodIcon(m), color: EfuridePalette.ink),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Text(tr(m.name),
                                  style: const TextStyle(
                                      fontSize: 16,
                                      fontWeight: FontWeight.w700)),
                            ),
                            Icon(
                              method == m.id
                                  ? Icons.radio_button_checked
                                  : Icons.radio_button_off,
                              color: method == m.id
                                  ? EfuridePalette.ink
                                  : EfuridePalette.inkMuted,
                            ),
                          ]),
                        ),
                      ),
                    ),
                  ),
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: EfuridePalette.greyBg,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Icon(Icons.info_outline,
                          size: 20, color: EfuridePalette.inkMuted),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Text(
                          picked().details.isNotEmpty
                              ? tr('Pay to: {0}', [picked().details])
                              : tr('Contact ko!ngo support for the {0} payment details.',
                                  [tr(picked().name)]),
                          style:
                              const TextStyle(fontSize: 15, height: 1.35),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: refCtrl,
                  style: const TextStyle(fontSize: 16),
                  decoration: InputDecoration(
                    labelText: picked().isMobileMoney
                        ? tr('Transaction code (from the SMS)')
                        : tr('Payment reference (optional)'),
                    filled: true,
                    fillColor: EfuridePalette.greyBg,
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: BorderSide.none,
                    ),
                  ),
                ),
                const SizedBox(height: 18),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: EfuridePalette.accent,
                    foregroundColor: EfuridePalette.accentInk,
                    minimumSize: const Size(0, 54),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(14)),
                  ),
                  onPressed: () {
                    final amt = double.tryParse(
                            amountCtrl.text.trim().replaceAll(',', '.')) ??
                        0;
                    if (amt <= 0) return;
                    Navigator.pop(ctx, true);
                  },
                  child: Text(tr('Send top-up request'),
                      style: const TextStyle(
                          fontSize: 17, fontWeight: FontWeight.w900)),
                ),
              ],
            ),
          ),
        ),
      ),
    );

    if (ok != true) return false;
    final amount =
        double.tryParse(amountCtrl.text.trim().replaceAll(',', '.')) ?? 0;
    if (amount <= 0) return false;

    final result = await WalletService.requestTopup(
      amount: amount,
      method: method,
      reference: refCtrl.text.trim().isEmpty ? null : refCtrl.text.trim(),
    );
    if (!context.mounted) return result.success;
    ErrorUI.showSnack(
      context,
      result.success
          ? AppError(
              title: tr('Top-up request sent'),
              message: tr('Your balance goes up when ko!ngo confirms it.'),
              icon: Icons.check_circle_outline,
            )
          : AppError(
              title: tr('Couldn\'t send request'),
              message: result.message ?? tr('Please try again in a moment.'),
              icon: Icons.error_outline,
            ),
    );
    return result.success;
  } finally {
    amountCtrl.dispose();
    refCtrl.dispose();
  }
}
