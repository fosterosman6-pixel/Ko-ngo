// lib/widgets/wallet/wallet_balance_card.dart

import 'package:flutter/material.dart';
import 'package:efuride_app/config/app_images.dart';
import 'package:efuride_app/widgets/app_image.dart';
import 'package:efuride_app/utils/money.dart';

class WalletBalanceCard extends StatelessWidget {
  final String label;
  final double amount;
  final String? secondaryLine;
  final String actionLabel;
  final IconData actionIcon;
  final String? actionAsset;
  final VoidCallback onAction;
  final List<Color>? gradient;

  const WalletBalanceCard({
    super.key,
    required this.label,
    required this.amount,
    this.secondaryLine,
    required this.actionLabel,
    required this.actionIcon,
    this.actionAsset,
    required this.onAction,
    this.gradient,
  });

  @override
  Widget build(BuildContext context) {
    final grad = gradient ??
        const [Color(0xFF1E88E5), Color(0xFF1565C0)];

    return Padding(
      padding: const EdgeInsets.all(16),
      child: Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: grad,
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(20),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              label,
              style: const TextStyle(
                color: Colors.white70,
                fontSize: 14,
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 6),
            Text(
              fmtMoney(amount),
              style: const TextStyle(
                color: Colors.white,
                fontSize: 32,
                fontWeight: FontWeight.bold,
              ),
            ),
            if (secondaryLine != null) ...[
              const SizedBox(height: 6),
              Text(
                secondaryLine!,
                style: const TextStyle(
                  color: Colors.white70,
                  fontSize: 13,
                  height: 1.4,
                ),
              ),
            ],
            const SizedBox(height: 16),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.white,
                  foregroundColor: grad.first,
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                onPressed: onAction,
                icon: actionAsset != null
                    ? AppImage(
                        actionAsset!,
                        size: 18,
                        fallbackIcon: actionIcon,
                      )
                    : Icon(actionIcon, size: 18),
                label: Text(
                  actionLabel,
                  style: const TextStyle(fontWeight: FontWeight.bold),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
