import 'package:flutter/material.dart';

class WalletStatusBadge extends StatelessWidget {
  final String status;

  const WalletStatusBadge({super.key, required this.status});

  Color get _color {
    switch (status.toLowerCase()) {
      case 'approved':
      case 'paid':
      case 'completed':
        return const Color(0xFF34C759);
      case 'rejected':
      case 'cancelled':
      case 'failed':
        return const Color(0xFFE53935);
      case 'processing':
        return const Color(0xFF1E88E5);
      case 'pending':
      default:
        return const Color(0xFFF2B705);
    }
  }

  @override
  Widget build(BuildContext context) {
    final c = _color;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: c.withOpacity(0.15),
        borderRadius: BorderRadius.circular(6),
      ),
      child: Text(
        status.toUpperCase(),
        style: TextStyle(
          color: c,
          fontSize: 12,
          fontWeight: FontWeight.bold,
          letterSpacing: 0.4,
        ),
      ),
    );
  }
}
