// lib/widgets/verified_badge.dart
//
// The blue tick shown next to a driver, worker, employer or store that
// ko!ngo has checked (the admin marks them verified).

import 'package:flutter/material.dart';
import 'package:efuride_app/l10n/app_strings.dart';

class VerifiedBadge extends StatelessWidget {
  final double size;

  /// Show the word "Verified" next to the tick.
  final bool label;
  const VerifiedBadge({super.key, this.size = 17, this.label = false});

  static const _blue = Color(0xFF1E88E5);

  @override
  Widget build(BuildContext context) {
    final icon = Icon(Icons.verified, size: size, color: _blue);
    if (!label) return Tooltip(message: tr('Verified by ko!ngo'), child: icon);
    return Row(mainAxisSize: MainAxisSize.min, children: [
      icon,
      const SizedBox(width: 4),
      Text(tr('Verified'),
          style: const TextStyle(
              fontSize: 13, fontWeight: FontWeight.w800, color: _blue)),
    ]);
  }
}
