// lib/widgets/product_thumb.dart
//
// Product picture for customer screens (store page, menu, cart).
// Shows the photo the store uploaded; if there is none or it can't load,
// shows the emoji or icon instead.

import 'package:flutter/material.dart';

class ProductThumb extends StatelessWidget {
  final String? imageUrl;
  final Widget fallback;
  final double size;
  final Color background;

  const ProductThumb({
    super.key,
    required this.imageUrl,
    required this.fallback,
    required this.background,
    this.size = 60,
  });

  @override
  Widget build(BuildContext context) {
    final url = (imageUrl ?? '').trim();
    final hasPic = url.startsWith('http');
    return Container(
      width: size,
      height: size,
      clipBehavior: Clip.antiAlias,
      decoration: BoxDecoration(
        color: background,
        borderRadius: BorderRadius.circular(10),
      ),
      child: hasPic
          ? Image.network(
              url,
              fit: BoxFit.cover,
              width: size,
              height: size,
              loadingBuilder: (c, child, progress) => progress == null
                  ? child
                  : Center(
                      child: SizedBox(
                        width: 18,
                        height: 18,
                        child: CircularProgressIndicator(
                            strokeWidth: 2, color: Colors.grey.shade400),
                      ),
                    ),
              errorBuilder: (_, __, ___) => Center(child: fallback),
            )
          : Center(child: fallback),
    );
  }
}
