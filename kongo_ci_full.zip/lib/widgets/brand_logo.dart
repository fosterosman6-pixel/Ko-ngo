// lib/widgets/brand_logo.dart

import 'package:flutter/material.dart';
import 'package:efuride_app/config/app_config.dart';
import 'package:efuride_app/widgets/k_icon.dart';

/// Renders the official EfuRide logo.
///
/// Falls back to a text wordmark if the asset fails to load, so the
/// brand is always visible even on a bad build.
class BrandLogo extends StatelessWidget {
  final double height;
  final Color? fallbackColor;

  const BrandLogo({
    super.key,
    this.height = 48,
    this.fallbackColor,
  });

  @override
  Widget build(BuildContext context) {
    return Image.asset(
      AppConfig.logoAsset,
      height: height,
      fit: BoxFit.contain,
      filterQuality: FilterQuality.high,
      errorBuilder: (_, __, ___) => _fallback(),
    );
  }

  Widget _fallback() {
    final color = fallbackColor ?? const Color(AppConfig.brandBlue);
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        KIcon(
          Icons.directions_car_filled,
          color: color,
          size: height * 0.6,
        ),
        const SizedBox(width: 6),
        Text(
          AppConfig.appName,
          style: TextStyle(
            fontSize: height * 0.42,
            fontWeight: FontWeight.w900,
            color: color,
            letterSpacing: -0.5,
          ),
        ),
      ],
    );
  }
}
