// lib/widgets/voice_mic_button.dart
//
// A microphone button for search boxes: tap, speak, the words appear in the
// box. Uses the phone's own speech recognition (package speech_to_text).
// If the phone has no speech service or the permission is refused, a short
// friendly message is shown instead of an error.

import 'package:flutter/material.dart';
import 'package:speech_to_text/speech_to_text.dart';
import 'package:efuride_app/config/efuride_palette.dart';
import 'package:efuride_app/l10n/app_strings.dart';

class VoiceMicButton extends StatefulWidget {
  /// Called with the recognised words (while speaking and when finished).
  final void Function(String text) onText;
  const VoiceMicButton({super.key, required this.onText});

  @override
  State<VoiceMicButton> createState() => _VoiceMicButtonState();
}

class _VoiceMicButtonState extends State<VoiceMicButton> {
  final SpeechToText _stt = SpeechToText();
  bool _ready = false;
  bool _listening = false;

  /// Languages phones usually have a speech engine for; others use the
  /// phone's default language.
  String? get _locale {
    switch (currentAppLang) {
      case AppLang.en:
        return 'en_US';
      case AppLang.fr:
        return 'fr_FR';
      case AppLang.sw:
        return 'sw_KE';
      case AppLang.af:
        return 'af_ZA';
      default:
        return null;
    }
  }

  void _say(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }

  Future<void> _toggle() async {
    if (_listening) {
      await _stt.stop();
      if (mounted) setState(() => _listening = false);
      return;
    }
    try {
      if (!_ready) {
        _ready = await _stt.initialize(
          onStatus: (s) {
            if ((s == 'done' || s == 'notListening') && mounted) {
              setState(() => _listening = false);
            }
          },
          onError: (_) {
            if (mounted) setState(() => _listening = false);
          },
        );
      }
      if (!_ready) {
        _say(tr('Voice search is not available on this phone.'));
        return;
      }
      setState(() => _listening = true);
      await _stt.listen(
        localeId: _locale,
        listenFor: const Duration(seconds: 12),
        pauseFor: const Duration(seconds: 3),
        onResult: (r) => widget.onText(r.recognizedWords),
      );
    } catch (_) {
      if (mounted) setState(() => _listening = false);
      _say(tr('Voice search is not available on this phone.'));
    }
  }

  @override
  void dispose() {
    _stt.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return IconButton(
      tooltip: tr('Speak to search'),
      onPressed: _toggle,
      icon: Icon(_listening ? Icons.mic : Icons.mic_none_rounded,
          color: _listening ? EfuridePalette.dropoff : EfuridePalette.ink),
    );
  }
}
