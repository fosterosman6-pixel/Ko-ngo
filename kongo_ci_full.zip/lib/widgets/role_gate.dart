// lib/widgets/role_gate.dart
//
// Guards each role app (customer, driver, shopper, merchant).
//
// The role a user picks on the start screen is only a door — the account's
// real role comes from `profiles.role`. Whatever route opens a shell (sign-in,
// splash, web URL, back button, notification, "switch role" link), this gate
// checks the signed-in account and redirects:
//   • not signed in            → /role_select
//   • blocked                  → signed out → /role_select
//   • not yet approved         → /pending_approval
//   • a different role         → that role's app (with a short notice)
//   • admin / unknown role     → signed out → /role_select

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'package:efuride_app/config/efuride_palette.dart';
import 'package:efuride_app/l10n/app_strings.dart';
import 'package:efuride_app/providers/auth_provider.dart';
import 'package:efuride_app/services/app_control.dart';
import 'package:efuride_app/utils/app_error.dart';
import 'package:efuride_app/utils/error_ui.dart';
import 'package:efuride_app/utils/roles.dart';

export 'package:efuride_app/utils/roles.dart';

class RoleGate extends StatefulWidget {
  /// The role this shell is for.
  final String role;
  final Widget child;

  const RoleGate({super.key, required this.role, required this.child});

  @override
  State<RoleGate> createState() => _RoleGateState();
}

class _RoleGateState extends State<RoleGate> {
  bool _redirecting = false;
  bool _refreshRequested = false;

  void _go(String route, {AppError? notice, bool signOut = false}) {
    if (_redirecting) return;
    _redirecting = true;
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      if (!mounted) return;
      if (signOut) {
        await context.read<AuthProvider>().signOut();
        if (!mounted) return;
      }
      if (notice != null) ErrorUI.showSnack(context, notice);
      Navigator.of(context).pushNamedAndRemoveUntil(route, (_) => false);
    });
  }

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    final t = S.of(context);

    if (!auth.isSignedIn) {
      _go('/role_select');
      return const _GateLoading();
    }

    final profile = auth.profile;
    if (profile == null) {
      // Session restored but profile not loaded yet: load it once.
      if (!auth.loadingProfile && !_refreshRequested) {
        _refreshRequested = true;
        WidgetsBinding.instance
            .addPostFrameCallback((_) => auth.refresh());
      } else if (!auth.loadingProfile && auth.profileError != null) {
        // Only sign out when the account really has no profile. A bad
        // connection or a server hiccup must NOT log the person out:
        // show "try again" instead.
        if (auth.profileError is StateError) {
          _go('/role_select', signOut: true);
        } else {
          return _GateRetry(
            error: AppError.from(auth.profileError!),
            onRetry: () {
              _refreshRequested = false;
              auth.refresh();
            },
          );
        }
      }
      return const _GateLoading();
    }

    if (profile['is_blocked'] == true) {
      _go(
        '/role_select',
        signOut: true,
        notice: AppError(
          title: t.t('account_blocked'),
          message: (profile['blocked_reason'] ?? t.t('account_blocked_msg'))
              .toString(),
          icon: Icons.block_outlined,
        ),
      );
      return const _GateLoading();
    }

    final actual = normalizeRole(auth.role);

    if (!isAppRole(actual)) {
      _go(
        '/role_select',
        signOut: true,
        notice: AppError(
          title: t.t('rg_no_app_title'),
          message: t.t('rg_no_app_msg'),
          icon: Icons.admin_panel_settings_outlined,
        ),
      );
      return const _GateLoading();
    }

    if (profile['is_active'] != true) {
      _go('/pending_approval');
      return const _GateLoading();
    }

    if (actual != widget.role) {
      // Right account, wrong app: open the app for this account's role.
      _go(
        '/$actual',
        notice: AppError(
          title: '${t.t('rg_detected')} ${t.t(roleLabelKey(actual))}',
          message: t.t('rg_opening_app'),
          icon: Icons.switch_account_outlined,
        ),
      );
      return const _GateLoading();
    }

    // Admin switches: maintenance mode, or this role's app paused.
    return ValueListenableBuilder<AppControlState>(
      valueListenable: AppControl.state,
      child: widget.child,
      builder: (context, control, child) {
        if (control.maintenance) {
          return _PausedScreen(
            icon: Icons.build_circle_outlined,
            title: t.t('ac_maint_title'),
            message: control.maintenanceMessage ?? t.t('ac_maint_msg'),
          );
        }
        if (!control.roleEnabled(widget.role)) {
          return _PausedScreen(
            icon: Icons.pause_circle_outline,
            title: t.t('ac_paused_title'),
            message: t.t('ac_paused_msg'),
          );
        }
        return child!;
      },
    );
  }
}

/// Full-screen notice while ko!ngo is paused by an admin.
class _PausedScreen extends StatefulWidget {
  final IconData icon;
  final String title;
  final String message;

  const _PausedScreen({
    required this.icon,
    required this.title,
    required this.message,
  });

  @override
  State<_PausedScreen> createState() => _PausedScreenState();
}

class _PausedScreenState extends State<_PausedScreen> {
  bool _checking = false;

  Future<void> _retry() async {
    setState(() => _checking = true);
    await AppControl.refresh();
    if (mounted) setState(() => _checking = false);
  }

  @override
  Widget build(BuildContext context) {
    final t = S.of(context);
    return Scaffold(
      backgroundColor: EfuridePalette.cream,
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(28),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(widget.icon, size: 72, color: EfuridePalette.blue),
                const SizedBox(height: 20),
                Text(
                  widget.title,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.w800,
                    color: EfuridePalette.ink,
                  ),
                ),
                const SizedBox(height: 12),
                Text(
                  widget.message,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    fontSize: 17,
                    height: 1.45,
                    color: EfuridePalette.inkMuted,
                  ),
                ),
                const SizedBox(height: 28),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton.icon(
                    onPressed: _checking ? null : _retry,
                    icon: _checking
                        ? const SizedBox(
                            width: 18,
                            height: 18,
                            child: CircularProgressIndicator(strokeWidth: 2),
                          )
                        : const Icon(Icons.refresh),
                    label: Text(t.t('ac_try_again')),
                  ),
                ),
                const SizedBox(height: 8),
                TextButton(
                  onPressed: () async {
                    await context.read<AuthProvider>().signOut();
                    if (!context.mounted) return;
                    Navigator.of(context)
                        .pushNamedAndRemoveUntil('/role_select', (_) => false);
                  },
                  child: Text(t.t('sign_out')),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

/// Shown when the profile could not be loaded (usually a weak connection).
/// The person stays signed in and can try again.
class _GateRetry extends StatelessWidget {
  final AppError error;
  final VoidCallback onRetry;
  const _GateRetry({required this.error, required this.onRetry});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: EfuridePalette.cream,
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(28),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.wifi_off_rounded,
                    size: 72, color: EfuridePalette.blue),
                const SizedBox(height: 20),
                Text(
                  error.title,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.w800,
                    color: EfuridePalette.ink,
                  ),
                ),
                const SizedBox(height: 12),
                Text(
                  error.message,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    fontSize: 16,
                    height: 1.45,
                    color: EfuridePalette.inkMuted,
                  ),
                ),
                const SizedBox(height: 28),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton.icon(
                    onPressed: onRetry,
                    icon: const Icon(Icons.refresh),
                    label: Text(tr('Retry')),
                  ),
                ),
                const SizedBox(height: 8),
                TextButton(
                  onPressed: () async {
                    await context.read<AuthProvider>().signOut();
                    if (!context.mounted) return;
                    Navigator.of(context)
                        .pushNamedAndRemoveUntil('/role_select', (_) => false);
                  },
                  child: Text(tr('Sign out')),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _GateLoading extends StatelessWidget {
  const _GateLoading();

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      backgroundColor: EfuridePalette.cream,
      body: Center(
        child: CircularProgressIndicator(color: EfuridePalette.blue),
      ),
    );
  }
}
