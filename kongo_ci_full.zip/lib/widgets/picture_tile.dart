// lib/widgets/picture_tile.dart
//
// A soft coloured card with a picture on top and a label underneath —
// used for the Marketplace and Hiring categories. The picture is a
// photo/illustration, not an icon. If the admin has uploaded a picture
// (networkUrl) it is shown; otherwise the picture that ships in the app.

import 'package:flutter/material.dart';
import 'package:efuride_app/config/efuride_palette.dart';

class PictureTile extends StatelessWidget {
  final String label;
  final String asset;
  final String? networkUrl;
  final Color tint;
  final VoidCallback? onTap;
  final double imageSize;
  final bool selected;

  const PictureTile({
    super.key,
    required this.label,
    required this.asset,
    required this.tint,
    this.networkUrl,
    this.onTap,
    this.imageSize = 58,
    this.selected = false,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: tint,
      borderRadius: BorderRadius.circular(18),
      child: InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.fromLTRB(6, 10, 6, 8),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(18),
            border: Border.all(
                color: selected ? EfuridePalette.accent : Colors.transparent,
                width: 2.2),
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Expanded(
                child: Center(
                  child: PictureImage(
                      asset: asset, networkUrl: networkUrl, size: imageSize),
                ),
              ),
              const SizedBox(height: 6),
              Text(label,
                  maxLines: 2,
                  textAlign: TextAlign.center,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                      fontSize: 13,
                      height: 1.15,
                      fontWeight: FontWeight.w800,
                      color: EfuridePalette.ink)),
            ],
          ),
        ),
      ),
    );
  }
}

/// The picture itself: admin-uploaded photo first, app picture otherwise.
class PictureImage extends StatelessWidget {
  final String asset;
  final String? networkUrl;
  final double size;
  final BoxFit fit;

  const PictureImage({
    super.key,
    required this.asset,
    this.networkUrl,
    this.size = 58,
    this.fit = BoxFit.contain,
  });

  @override
  Widget build(BuildContext context) {
    final fallback = Image.asset(asset,
        width: size,
        height: size,
        fit: fit,
        errorBuilder: (_, __, ___) =>
            Icon(Icons.image_outlined, size: size * 0.6, color: Colors.grey));
    final url = networkUrl;
    if (url == null || url.isEmpty) return fallback;
    return Image.network(url,
        width: size,
        height: size,
        fit: fit,
        errorBuilder: (_, __, ___) => fallback,
        loadingBuilder: (_, child, p) => p == null ? child : fallback);
  }
}


/// Pictures for the Marketplace categories (shipped in assets/images).
String marketPictureAsset(String key) {
  switch (key) {
    case 'fashion':
      return 'assets/images/cat_fashion.png';
    case 'electronics':
      return 'assets/images/cat_electronics.png';
    case 'home_living':
      return 'assets/images/cat_home.png';
    case 'beauty':
      return 'assets/images/cat_beauty.png';
    case 'butchery':
      return 'assets/images/cat_butchery.png';
    case 'bakery':
      return 'assets/images/cat_bakery.png';
    case 'general_retail':
      return 'assets/images/cat_retail.png';
    case 'other':
      return 'assets/images/cat_other.png';
    case 'grocery':
      return 'assets/images/grocery.png';
    case 'pharmacy':
      return 'assets/images/pharmacy.png';
    case 'food':
      return 'assets/images/food.png';
    default:
      return 'assets/images/cat_other.png';
  }
}

Color marketPictureTint(String key) {
  switch (key) {
    case 'fashion':
      return const Color(0xFFFFE0E6);
    case 'electronics':
      return const Color(0xFFE0EEFF);
    case 'home_living':
      return const Color(0xFFFFEBD0);
    case 'beauty':
      return const Color(0xFFFFE0EE);
    case 'butchery':
      return const Color(0xFFFFE3E0);
    case 'bakery':
      return const Color(0xFFFFF0D2);
    case 'general_retail':
    case 'grocery':
      return const Color(0xFFDDF6E7);
    case 'pharmacy':
      return const Color(0xFFFFE0E0);
    case 'food':
      return const Color(0xFFFFE6D0);
    default:
      return const Color(0xFFEBE0FF);
  }
}
