// lib/widgets/partner_landing_screen.dart
//
// Shared landing widget for Grocery + Pharmacy. Renders a header
// (accent-colored), an optional top card (Rx upload for pharmacy),
// and a list of partner cards fetched from the DB.

import 'dart:async';
import 'package:flutter/material.dart';
import 'package:efuride_app/utils/search_match.dart';
import 'package:efuride_app/widgets/verified_badge.dart';
import 'package:efuride_app/widgets/voice_mic_button.dart';
import 'package:efuride_app/config/country_config.dart';
import 'package:efuride_app/config/efuride_palette.dart';
import 'package:efuride_app/utils/app_error.dart';
import 'package:efuride_app/l10n/app_strings.dart';
import 'package:efuride_app/models/partner.dart';
import 'package:efuride_app/services/order_service.dart';

class PartnerLandingScreen extends StatefulWidget {
  final String  category;       // 'grocery' | 'pharmacy'
  final String  serviceType;    // 'Grocery' | 'Pharmacy'
  final Color   accent;
  final IconData headerIcon;
  final String  headerKicker;
  final String  headerTitle;
  final String  headerSubtitle;
  final String  searchHint;
  final Widget? topCard;
  final String? headerImage; // picture shown in the banner and on stores without a logo

  const PartnerLandingScreen({
    super.key,
    required this.category,
    required this.serviceType,
    required this.accent,
    required this.headerIcon,
    required this.headerKicker,
    required this.headerTitle,
    required this.headerSubtitle,
    required this.searchHint,
    this.topCard,
    this.headerImage,
  });

  @override
  State<PartnerLandingScreen> createState() => _PartnerLandingScreenState();
}

class _PartnerLandingScreenState extends State<PartnerLandingScreen> {
  final _searchCtrl = TextEditingController();
  Timer? _debounce;
  List<Partner> _all = [];
  bool _loading = true;
  Object? _error;

  @override
  void initState() {
    super.initState();
    _load();
    _searchCtrl.addListener(_onSearch);
  }

  @override
  void dispose() {
    _debounce?.cancel();
    _searchCtrl.removeListener(_onSearch);
    _searchCtrl.dispose();
    super.dispose();
  }

  void _onSearch() {
    _debounce?.cancel();
    _debounce = Timer(const Duration(milliseconds: 250), () {
      if (mounted) {
        setState(() {});
        _loadProductHits(_searchCtrl.text.trim());
      }
    });
  }

  Future<void> _load() async {
    setState(() { _loading = true; _error = null; });
    try {
      final rows = await OrderService.instance.fetchPartners(
        category: widget.category,
      );
      if (!mounted) return;
      setState(() { _all = rows; _loading = false; });
    } catch (e) {
      if (!mounted) return;
      setState(() { _error = e; _loading = false; });
    }
  }

  /// Stores that sell a product matching the search (filled after typing).
  Set<String> _productHits = {};
  String _hitsFor = '';

  Future<void> _loadProductHits(String q) async {
    if (q.trim().length < 2) {
      if (_productHits.isNotEmpty) setState(() => _productHits = {});
      _hitsFor = '';
      return;
    }
    _hitsFor = q;
    final ids = await OrderService.instance.storeIdsSellingProduct(q);
    if (!mounted || _hitsFor != q) return;
    setState(() => _productHits = ids);
  }

  List<Partner> get _filtered {
    final q = _searchCtrl.text.trim();
    if (q.isEmpty) return _all;
    return _all
        .where((p) =>
            searchMatches(q, [p.name, p.address, p.description]) ||
            _productHits.contains(p.id))
        .toList();
  }

  void _openPartner(Partner p) {
    Navigator.pushNamed(
      context,
      '/customer_store',
      arguments: {
        'id':           p.id,
        'name':         p.name,
        'address':      p.address ?? '',
        'service_type': widget.serviceType,
      },
    );
  }

  // Plain and calm: a normal app bar, a search box, then a simple
  // list of stores. (It also needs its own Scaffold — without one the
  // page showed black with yellow underlined text.)
  @override
  Widget build(BuildContext context) {
    final t = S.of(context);
    final title = widget.category == 'pharmacy'
        ? t.t('svc_pharmacy')
        : widget.category == 'grocery'
            ? t.t('svc_grocery')
            : tr(widget.headerTitle);
    return Scaffold(
      backgroundColor: EfuridePalette.cream,
      appBar: AppBar(
        backgroundColor: EfuridePalette.cream,
        foregroundColor: EfuridePalette.ink,
        elevation: 0,
        scrolledUnderElevation: 0,
        title: Text(
          title,
          style: const TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.w800,
            color: EfuridePalette.ink,
          ),
        ),
      ),
      body: Column(
        children: [
          _header(t),
          Expanded(
            child: RefreshIndicator(
              color: widget.accent,
              onRefresh: _load,
              child: _body(t),
            ),
          ),
        ],
      ),
    );
  }

  // ── Search box ────────────────────────────────────────────────
  Widget _header(S t) {
    final pic = widget.headerImage;
    return Column(children: [
      if (pic != null)
        Container(
          margin: const EdgeInsets.fromLTRB(16, 0, 16, 10),
          padding: const EdgeInsets.fromLTRB(16, 12, 10, 12),
          decoration: BoxDecoration(
            color: widget.accent.withValues(alpha: 0.12),
            borderRadius: BorderRadius.circular(20),
          ),
          child: Row(children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(tr(widget.headerTitle),
                      style: const TextStyle(
                          fontSize: 19,
                          fontWeight: FontWeight.w900,
                          color: EfuridePalette.ink,
                          height: 1.15)),
                  const SizedBox(height: 4),
                  Text(tr(widget.headerSubtitle),
                      style: const TextStyle(
                          fontSize: 13.5, color: EfuridePalette.inkMuted)),
                ],
              ),
            ),
            Image.asset(pic, width: 84, height: 84),
          ]),
        ),
      _searchBox(t),
    ]);
  }

  Widget _searchBox(S t) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
      child: TextField(
        controller: _searchCtrl,
        style: const TextStyle(fontSize: 16, color: EfuridePalette.ink),
        decoration: InputDecoration(
          hintText: widget.searchHint,
          hintStyle: const TextStyle(
              fontSize: 16, color: EfuridePalette.inkMuted),
          prefixIcon:
              const Icon(Icons.search, color: EfuridePalette.inkMuted),
          suffixIcon: VoiceMicButton(onText: (t) {
            _searchCtrl.text = t;
            _searchCtrl.selection = TextSelection.collapsed(offset: t.length);
          }),
          filled: true,
          fillColor: Colors.white,
          contentPadding: const EdgeInsets.symmetric(vertical: 14),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: const BorderSide(color: EfuridePalette.divider),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: const BorderSide(color: EfuridePalette.divider),
          ),
        ),
      ),
    );
  }

  // ── Body ──────────────────────────────────────────────────────
  Widget _body(S t) {
    if (_loading) {
      return Center(
        child: CircularProgressIndicator(color: widget.accent),
      );
    }

    if (_error != null) {
      return ListView(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.all(24),
        children: [
          const SizedBox(height: 60),
          Icon(Icons.wifi_off_rounded,
              size: 56, color: Colors.grey.shade400),
          const SizedBox(height: 16),
          Center(
            child: Text(tr('Could not load {0} stores', [widget.serviceType.toLowerCase()]),
                style: const TextStyle(
                    fontSize: 15, fontWeight: FontWeight.w700)),
          ),
          const SizedBox(height: 6),
          Center(
            child: Text(AppError.from(_error!).message,
                textAlign: TextAlign.center,
                style: const TextStyle(
                    fontSize: 13.5, color: EfuridePalette.inkMuted)),
          ),
          const SizedBox(height: 8),
          Center(child: TextButton(onPressed: _load, child: Text(tr('Retry')))),
        ],
      );
    }

    final list = _filtered;
    final hasTopCard = widget.topCard != null;

    return ListView(
      physics: const AlwaysScrollableScrollPhysics(),
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
      children: [
        if (hasTopCard) ...[
          widget.topCard!,
          const SizedBox(height: 16),
        ],
        if (_all.isEmpty)
          _emptyState(t)
        else if (list.isEmpty)
          _noResults(t)
        else ...[
          Padding(
            padding: const EdgeInsets.only(left: 4, bottom: 10),
            child: Text(
              widget.category == 'pharmacy'
                  ? tr('Nearby pharmacies')
                  : tr('Stores near you'),
              style: const TextStyle(
                fontSize: 15,
                fontWeight: FontWeight.w800,
                color: EfuridePalette.ink,
              ),
            ),
          ),
          ...list.map(_partnerCard),
        ],
      ],
    );
  }

  Widget _emptyState(S t) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 60),
        child: Column(
          children: [
            Icon(Icons.storefront_outlined,
                size: 56, color: Colors.grey.shade400),
            const SizedBox(height: 16),
            Text(tr('No {0} stores nearby', [widget.category]),
                style: const TextStyle(
                    fontSize: 15, fontWeight: FontWeight.w700)),
            const SizedBox(height: 6),
            Text(tr('Check back soon'),
                style: TextStyle(fontSize: 14, color: Color(0xFF575047))),
          ],
        ),
      );

  Widget _noResults(S t) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 60),
        child: Column(
          children: [
            Icon(Icons.search_off_rounded,
                size: 56, color: Colors.grey.shade400),
            const SizedBox(height: 16),
            Text(tr('No matches'),
                style: TextStyle(
                    fontSize: 15, fontWeight: FontWeight.w700)),
          ],
        ),
      );

  // ── Store row ─────────────────────────────────────────────────
  /// Street address only — never raw map coordinates.
  String _place(Partner p) {
    final a = (p.address ?? '').trim();
    final coords = RegExp(r'^-?\d+(\.\d+)?\s*,\s*-?\d+(\.\d+)?$');
    if (a.isNotEmpty && !coords.hasMatch(a)) return a;
    final city = (p.landmark ?? '').trim().isNotEmpty
        ? p.landmark!.trim()
        : p.city.trim();
    return city;
  }

  Widget _partnerCard(Partner p) {
    final t = S.of(context);
    final place = _place(p);
    final hasLogo = p.logoUrl != null && p.logoUrl!.isNotEmpty;
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Material(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        child: InkWell(
          onTap: () => _openPartner(p),
          borderRadius: BorderRadius.circular(14),
          child: Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: EfuridePalette.divider),
            ),
            child: Row(
              children: [
                // Logo, or the store's first letter.
                Container(
                  width: 56,
                  height: 56,
                  decoration: BoxDecoration(
                    color: widget.accent.withValues(alpha: 0.10),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  clipBehavior: Clip.antiAlias,
                  child: hasLogo
                      ? Image.network(p.logoUrl!, fit: BoxFit.cover)
                      : widget.headerImage != null
                          ? Padding(
                              padding: const EdgeInsets.all(6),
                              child: Image.asset(widget.headerImage!,
                                  fit: BoxFit.contain),
                            )
                          : Center(
                              child: Text(
                                p.name.isEmpty ? '?' : p.name[0].toUpperCase(),
                                style: TextStyle(
                                  fontSize: 24,
                                  fontWeight: FontWeight.w800,
                                  color: widget.accent,
                                ),
                              ),
                            ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: Row(children: [
                              Flexible(
                                child: Text(
                                  p.name,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(
                                    fontSize: 16.5,
                                    fontWeight: FontWeight.w800,
                                    color: EfuridePalette.ink,
                                  ),
                                ),
                              ),
                              if (p.isVerified) ...[
                                const SizedBox(width: 5),
                                const VerifiedBadge(),
                              ],
                            ]),
                          ),
                          if (p.isSponsored && p.isOpen)
                            Container(
                              margin: const EdgeInsets.only(left: 6),
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 8, vertical: 3),
                              decoration: BoxDecoration(
                                color: EfuridePalette.accent
                                    .withValues(alpha: 0.25),
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: Text(
                                tr('Sponsored'),
                                style: const TextStyle(
                                  fontSize: 12,
                                  fontWeight: FontWeight.w800,
                                  color: EfuridePalette.ink,
                                ),
                              ),
                            ),
                          if (!p.isOpen)
                            Text(
                              tr('Closed'),
                              style: const TextStyle(
                                fontSize: 13.5,
                                fontWeight: FontWeight.w700,
                                color: EfuridePalette.dropoff,
                              ),
                            ),
                        ],
                      ),
                      if (place.isNotEmpty) ...[
                        const SizedBox(height: 2),
                        Text(
                          place,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            fontSize: 14.5,
                            color: EfuridePalette.inkMuted,
                          ),
                        ),
                      ],
                      const SizedBox(height: 6),
                      Text(
                        [
                          '★ ${p.rating.toStringAsFixed(1)}',
                          '${p.prepMinutes} ${t.t('min')}',
                          '${t.t('delivery_fee')} ${CountryConfig.money(p.deliveryFee)}',
                          if (p.minOrder > 0)
                            '${t.t('min_order')} ${CountryConfig.money(p.minOrder)}',
                        ].join('  ·  '),
                        maxLines: 2,
                        style: const TextStyle(
                          fontSize: 13.5,
                          fontWeight: FontWeight.w600,
                          color: EfuridePalette.ink,
                        ),
                      ),
                    ],
                  ),
                ),
                const Icon(Icons.chevron_right,
                    color: EfuridePalette.inkMuted),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _meta(IconData i, String label) => Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(i, size: 12, color: EfuridePalette.inkMuted),
          const SizedBox(width: 4),
          Text(label,
              style: const TextStyle(
                  fontSize: 13,
                  color: EfuridePalette.inkMuted,
                  fontWeight: FontWeight.w600)),
        ],
      );
}
