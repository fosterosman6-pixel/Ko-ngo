// lib/widgets/payment_choice.dart
//
// "How will you pay?" — used for rides, deliveries and shop orders.
//
//   Cash    always
//   Wallet  when the ko!ngo wallet has money; greyed out (with a Top up
//           link) when it holds less than the amount due
//   Card    only in countries where card payments are switched on
//           (admin app → Pricing → card_enabled)
//
// Values stored in the database: 'cash' | 'wallet' | 'card'.

import 'package:flutter/material.dart';

import 'package:efuride_app/config/country_config.dart';
import 'package:efuride_app/config/efuride_palette.dart';
import 'package:efuride_app/l10n/app_strings.dart';
import 'package:efuride_app/services/pricing_service.dart';

class PaymentChoice extends StatelessWidget {
  final String value;
  final ValueChanged<String> onChanged;
  final double amountDue;
  final double walletBalance;

  /// Line under "Cash", e.g. "Pay the driver" or "Pay when it arrives".
  final String cashHint;

  const PaymentChoice({
    super.key,
    required this.value,
    required this.onChanged,
    required this.amountDue,
    required this.walletBalance,
    required this.cashHint,
  });

  static bool get cardAvailable => PricingService.last.cardEnabled;

  /// The best default: wallet when it covers the amount, otherwise cash.
  static String suggested(double amountDue, double walletBalance) =>
      walletBalance > 0 && walletBalance >= amountDue ? 'wallet' : 'cash';

  @override
  Widget build(BuildContext context) {
    final walletOk = walletBalance > 0 && walletBalance >= amountDue;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Text(tr('How will you pay?'),
            style: const TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w800,
                color: EfuridePalette.ink)),
        const SizedBox(height: 8),
        if (walletBalance > 0)
          _tile(
            context,
            id: 'wallet',
            icon: Icons.account_balance_wallet_outlined,
            title: tr('ko!ngo wallet'),
            sub: walletOk
                ? tr('Balance {0}', [CountryConfig.money(walletBalance)])
                : tr('Balance {0}: not enough for this',
                    [CountryConfig.money(walletBalance)]),
            enabled: walletOk,
            trailing: walletOk
                ? null
                : TextButton(
                    onPressed: () => Navigator.pushNamed(context, '/wallet'),
                    child: Text(tr('Top up'),
                        style: const TextStyle(
                            fontSize: 15, fontWeight: FontWeight.w800)),
                  ),
          ),
        _tile(
          context,
          id: 'cash',
          icon: Icons.payments_outlined,
          title: tr('Cash'),
          sub: cashHint,
          enabled: true,
        ),
        if (cardAvailable)
          _tile(
            context,
            id: 'card',
            icon: Icons.credit_card,
            title: tr('Card'),
            sub: tr('Visa or Mastercard'),
            enabled: true,
          ),
      ],
    );
  }

  Widget _tile(
    BuildContext context, {
    required String id,
    required IconData icon,
    required String title,
    required String sub,
    required bool enabled,
    Widget? trailing,
  }) {
    final selected = value == id && enabled;
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Material(
        color: selected
            ? EfuridePalette.accent.withValues(alpha: 0.12)
            : Colors.white,
        borderRadius: BorderRadius.circular(12),
        child: InkWell(
          borderRadius: BorderRadius.circular(12),
          onTap: enabled ? () => onChanged(id) : null,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: selected ? EfuridePalette.accent : EfuridePalette.divider,
                width: selected ? 1.6 : 1,
              ),
            ),
            child: Row(
              children: [
                Icon(icon,
                    color: enabled
                        ? EfuridePalette.ink
                        : EfuridePalette.inkMuted),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(title,
                          style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w700,
                              color: enabled
                                  ? EfuridePalette.ink
                                  : EfuridePalette.inkMuted)),
                      const SizedBox(height: 2),
                      Text(sub,
                          style: const TextStyle(
                              fontSize: 14, color: EfuridePalette.inkMuted)),
                    ],
                  ),
                ),
                trailing ??
                    Icon(
                      selected
                          ? Icons.radio_button_checked
                          : Icons.radio_button_off,
                      color: selected
                          ? EfuridePalette.ink
                          : EfuridePalette.inkMuted,
                    ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
