// lib/widgets/map_markers.dart

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:efuride_app/config/app_config.dart';

/// Shared marker icons so we don't rebuild BitmapDescriptors on every frame.
class MapMarkers {
  MapMarkers._();

  static BitmapDescriptor? _carLarge;
  static BitmapDescriptor? _carSmall;

  /// Vehicle asset used on the driver marker.
  static Future<BitmapDescriptor> carTop({double size = 96}) async {
    try {
      if (size <= 60) {
        _carSmall ??= await BitmapDescriptor.asset(
          const ImageConfiguration(size: Size(48, 48)),
          AppConfig.carMarkerAsset,
        );
        return _carSmall!;
      }
      _carLarge ??= await BitmapDescriptor.asset(
        const ImageConfiguration(size: Size(96, 96)),
        AppConfig.carMarkerAsset,
      );
      return _carLarge!;
    } catch (e) {
      debugPrint('carTop marker load failed: $e');
      return BitmapDescriptor.defaultMarker;
    }
  }

  /// Pickup marker — blue pin.
  static BitmapDescriptor pickup() =>
      BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueAzure);

  /// Dropoff marker — red pin.
  static BitmapDescriptor dropoff() =>
      BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueRed);

  /// Customer marker — green pin.
  static BitmapDescriptor customer() =>
      BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueGreen);
}
