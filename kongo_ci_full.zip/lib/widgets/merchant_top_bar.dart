// lib/widgets/merchant_top_bar.dart
//
// Plain top bar for every merchant screen: title + subtitle on the cream
// background, like the customer and driver screens.
//
// Shows the menu button when the screen is a tab inside the merchant shell
// (which has the drawer), and a back arrow when the screen was opened on
// its own (e.g. from a dashboard shortcut). Before, the tabs always called
// Scaffold.of(context).openDrawer, which crashed ("Something went wrong")
// when they were opened on their own.

import 'package:flutter/material.dart';

import 'package:efuride_app/config/efuride_palette.dart';
import 'package:efuride_app/widgets/kongo_brand.dart';

class MerchantTopBar extends StatelessWidget {
  final String title;
  final String? subtitle;
  final List<Widget> actions;

  /// Optional row under the title (e.g. the open/closed switch).
  final Widget? bottom;

  /// Home screen: show the ko!ngo logo row on top, with this role line.
  final String? brandRole;

  /// Right end of the title row (e.g. the profile photo).
  final Widget? trailing;

  const MerchantTopBar({
    super.key,
    required this.title,
    this.subtitle,
    this.actions = const [],
    this.bottom,
    this.brandRole,
    this.trailing,
  });

  /// The nearest Scaffold above us that has a drawer (the merchant shell).
  static ScaffoldState? _drawerHost(BuildContext context) {
    ScaffoldState? found;
    context.visitAncestorElements((e) {
      if (e is StatefulElement &&
          e.state is ScaffoldState &&
          (e.state as ScaffoldState).hasDrawer) {
        found = e.state as ScaffoldState;
        return false;
      }
      return true;
    });
    return found;
  }

  @override
  Widget build(BuildContext context) {
    // Inside the merchant shell (tabs): always the menu, which holds
    // Profile, Settings, Messages, Support and Sign out — even when the
    // shell itself was opened on top of another page. A screen opened on
    // its own (from a shortcut) gets a back arrow.
    final host = _drawerHost(context);
    final canPop = ModalRoute.of(context)?.canPop ?? false;

    Widget? leading;
    if (host != null) {
      leading = IconButton(
        icon: const Icon(Icons.menu, color: EfuridePalette.ink),
        onPressed: host.openDrawer,
      );
    } else if (canPop) {
      leading = IconButton(
        icon: const Icon(Icons.arrow_back, color: EfuridePalette.ink),
        onPressed: () => Navigator.maybePop(context),
      );
    }

    return Material(
      color: EfuridePalette.cream,
      child: SafeArea(
        bottom: false,
        child: Padding(
          padding: EdgeInsets.fromLTRB(leading == null ? 20 : 4, 8, 12, 10),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              if (brandRole != null) ...[
                Row(
                  children: [
                    if (leading != null) ...[leading, const SizedBox(width: 4)],
                    KongoBrand(role: brandRole),
                    const Spacer(),
                    ...actions,
                  ],
                ),
                const SizedBox(height: 12),
              ],
              Row(
                children: [
                  if (leading != null && brandRole == null) ...[
                    leading,
                    const SizedBox(width: 4)
                  ],
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          title,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            fontSize: 22,
                            fontWeight: FontWeight.w800,
                            color: EfuridePalette.ink,
                          ),
                        ),
                        if (subtitle != null && subtitle!.isNotEmpty) ...[
                          const SizedBox(height: 2),
                          Text(
                            subtitle!,
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              fontSize: 14.5,
                              color: EfuridePalette.inkMuted,
                            ),
                          ),
                        ],
                      ],
                    ),
                  ),
                  if (brandRole == null) ...actions,
                  if (trailing != null) ...[
                    const SizedBox(width: 10),
                    trailing!,
                  ],
                ],
              ),
              if (bottom != null) ...[
                const SizedBox(height: 10),
                Padding(
                  padding: EdgeInsets.only(left: leading == null ? 0 : 12),
                  child: bottom!,
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}
