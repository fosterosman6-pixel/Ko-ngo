// lib/widgets/k_icon.dart
//
// Drop-in for Icon(Icons.x). Shows the glossy ko!ngo PNG icon when one exists
// for that icon, otherwise the normal Material icon. Loud colours (white on a
// button, red errors, green ticks) and tiny sizes keep the normal icon so
// they stay readable.
import 'package:flutter/material.dart';

class KIcon extends StatelessWidget {
  final IconData icon;
  final double? size;
  final Color? color;
  final String? semanticLabel;

  const KIcon(this.icon, {super.key, this.size, this.color, this.semanticLabel});

  static final Map<int, String> _png = <int, String>{
    Icons.person.codePoint: 'user_blue',
    Icons.person_outline.codePoint: 'user_blue',
    Icons.account_balance.codePoint: 'blue_bank',
    Icons.account_balance_outlined.codePoint: 'blue_bank',
    Icons.account_balance_wallet.codePoint: 'wallet_blue',
    Icons.account_balance_wallet_outlined.codePoint: 'wallet_blue',
    Icons.local_offer_outlined.codePoint: 'percent_tag',
    Icons.lock.codePoint: 'lock',
    Icons.lock_outline.codePoint: 'lock',
    Icons.shield_outlined.codePoint: 'shield_check',
    Icons.verified_user.codePoint: 'shield_check',
    Icons.verified_user_outlined.codePoint: 'shield_check',
    Icons.local_shipping.codePoint: 'delivery_truck',
    Icons.local_shipping_outlined.codePoint: 'delivery_truck',
    Icons.delivery_dining.codePoint: 'delivery_bike',
    Icons.directions_car.codePoint: 'ride',
    Icons.directions_car_filled.codePoint: 'ride',
    Icons.directions_car_outlined.codePoint: 'ride',
    Icons.local_taxi.codePoint: 'ride',
    Icons.local_taxi_outlined.codePoint: 'ride',
    Icons.inventory_2.codePoint: 'parcel',
    Icons.inventory_2_outlined.codePoint: 'parcel',
    Icons.inventory_2_rounded.codePoint: 'parcel',
    Icons.restaurant.codePoint: 'food',
    Icons.restaurant_rounded.codePoint: 'food',
    Icons.medical_services_rounded.codePoint: 'pharmacy',
    Icons.shopping_basket.codePoint: 'grocery',
    Icons.chat_bubble_outline.codePoint: 'chat_bubble',
    Icons.support_agent.codePoint: 'headset',
    Icons.payments_outlined.codePoint: 'card',
    Icons.credit_card.codePoint: 'card',
    Icons.receipt_long.codePoint: 'blue_clipboard',
    Icons.receipt_long_outlined.codePoint: 'blue_clipboard',
    Icons.share.codePoint: 'share',
    Icons.ios_share.codePoint: 'share',
    Icons.card_giftcard.codePoint: 'gift',
    Icons.event.codePoint: 'calendar',
    Icons.trending_up.codePoint: 'bar_chart',
    Icons.settings_outlined.codePoint: 'gear',
    Icons.work_outline.codePoint: 'briefcase',
    Icons.location_on.codePoint: 'map_pin_blue',
    Icons.location_on_outlined.codePoint: 'map_pin_blue',
    Icons.language.codePoint: 'globe',
    Icons.public.codePoint: 'globe',
    Icons.home_outlined.codePoint: 'blue_home',
    Icons.home_rounded.codePoint: 'blue_home',
    Icons.school_outlined.codePoint: 'ki_school',
    Icons.tune.codePoint: 'ki_tune',
    Icons.camera_alt.codePoint: 'ki_camera',
    Icons.camera_alt_outlined.codePoint: 'ki_camera',
    Icons.photo_library_outlined.codePoint: 'ki_photos',
    Icons.schedule.codePoint: 'ki_clock',
    Icons.access_time.codePoint: 'ki_clock',
    Icons.logout.codePoint: 'logout',
    Icons.notifications_none.codePoint: 'ki_bell',
    Icons.notifications_none_rounded.codePoint: 'ki_bell',
    Icons.notifications_outlined.codePoint: 'ki_bell',
    Icons.notifications.codePoint: 'ki_bell',
    Icons.help_outline.codePoint: 'ki_help',
    Icons.help.codePoint: 'ki_help',
    Icons.swap_horiz.codePoint: 'ki_swap',
    Icons.map_outlined.codePoint: 'ki_map',
    Icons.map.codePoint: 'ki_map',
    Icons.mail_outline.codePoint: 'ki_mail',
    Icons.email_outlined.codePoint: 'ki_mail',
    Icons.chat_bubble_outline_rounded.codePoint: 'chat_bubble',
    Icons.chat_bubble_rounded.codePoint: 'chat_bubble',
    Icons.chat_outlined.codePoint: 'chat_bubble',
    Icons.chat.codePoint: 'chat_bubble',
    Icons.chat_rounded.codePoint: 'chat_bubble',
    Icons.mode_comment_outlined.codePoint: 'chat_bubble',
    Icons.forum_outlined.codePoint: 'chat_bubble',
  };

  // Icons drawn to fill most of the picture: shown at normal size.
  static const _full = <String>{'ki_school','ki_tune','ki_bookmark','ki_camera','ki_photos','ki_clock','ki_star','ki_bell','ki_help','ki_swap','ki_map','ki_mail'};

  static bool _loud(Color c) {
    final hsl = HSLColor.fromColor(c);
    if (hsl.lightness > 0.88 && hsl.saturation < 0.4) return true; // white-ish
    if (c.opacity < 0.5) return true;                               // faded
    final blueish = hsl.hue >= 190 && hsl.hue <= 260;
    return hsl.saturation > 0.35 && !blueish;                       // red, green, amber...
  }

  @override
  Widget build(BuildContext context) {
    final theme = IconTheme.of(context);
    final s = size ?? theme.size ?? 24.0;
    final c = color ?? theme.color;
    final asset = _png[icon.codePoint];
    final plain = Icon(icon, size: size, color: color, semanticLabel: semanticLabel);
    if (asset == null || s < 16 || (c != null && _loud(c))) return plain;
    return SizedBox(
      width: s,
      height: s,
      child: Transform.scale(
        scale: _full.contains(asset) ? 1.0 : 1.15,
        child: Image.asset(
          'assets/images/$asset.png',
          width: s,
          height: s,
          fit: BoxFit.contain,
          semanticLabel: semanticLabel,
          errorBuilder: (_, __, ___) => plain,
        ),
      ),
    );
  }
}
