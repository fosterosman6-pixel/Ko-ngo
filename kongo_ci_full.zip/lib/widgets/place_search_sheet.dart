// lib/widgets/place_search_sheet.dart
//
// Reusable Google address picker (bottom sheet).
//
//   final place = await showPlaceSearchSheet(context, near: myLatLng);
//   if (place != null) { place.displayAddress; place.latLng; }
//
// Offers "Use my current location" plus Google Places search biased to
// [near] and kept inside its country. Returns null when dismissed.

import 'package:flutter/material.dart';
import 'package:efuride_app/services/favorite_places_service.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

import 'package:efuride_app/config/efuride_palette.dart';
import 'package:efuride_app/l10n/app_strings.dart';
import 'package:efuride_app/services/google_maps_service.dart';
import 'package:efuride_app/widgets/debouncer.dart';
import 'package:efuride_app/widgets/k_icon.dart';

Future<PlaceDetails?> showPlaceSearchSheet(
  BuildContext context, {
  LatLng? near,
  String? title,
  String? initialQuery,
  bool includeSaved = false, // customer's own Home / Work places
}) {
  return showModalBottomSheet<PlaceDetails>(
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.white,
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
    ),
    builder: (_) => _PlaceSearchSheet(
      near: near,
      title: title,
      initialQuery: initialQuery,
      includeSaved: includeSaved,
    ),
  );
}

class _PlaceSearchSheet extends StatefulWidget {
  final LatLng? near;
  final String? title;
  final String? initialQuery;
  final bool includeSaved;

  const _PlaceSearchSheet(
      {this.near, this.title, this.initialQuery, this.includeSaved = false});

  @override
  State<_PlaceSearchSheet> createState() => _PlaceSearchSheetState();
}

class _PlaceSearchSheetState extends State<_PlaceSearchSheet> {
  final _ctrl = TextEditingController();
  final _debouncer = Debouncer(milliseconds: 350);
  List<PlacePrediction> _results = [];
  bool _searching = false;
  bool _resolving = false;
  String? _error;
  int _requestId = 0;
  LatLng? _origin;
  List<Map<String, dynamic>> _saved = [];

  @override
  void initState() {
    super.initState();
    if (widget.includeSaved) {
      FavoritePlacesService.listFavorites().then((l) {
        if (mounted) setState(() => _saved = l);
      });
    }
    _origin = widget.near;
    if (widget.initialQuery?.isNotEmpty == true) {
      _ctrl.text = widget.initialQuery!;
      WidgetsBinding.instance
          .addPostFrameCallback((_) => _search(_ctrl.text));
    }
    if (_origin == null) _locate(silent: true);
  }

  @override
  void dispose() {
    _ctrl.dispose();
    _debouncer.dispose();
    super.dispose();
  }

  Future<LatLng?> _locate({bool silent = false}) async {
    try {
      var perm = await Geolocator.checkPermission();
      if (perm == LocationPermission.denied) {
        perm = await Geolocator.requestPermission();
      }
      if (perm == LocationPermission.denied ||
          perm == LocationPermission.deniedForever) {
        return null;
      }
      final pos = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high,
        timeLimit: const Duration(seconds: 8),
      );
      final here = LatLng(pos.latitude, pos.longitude);
      if (mounted) setState(() => _origin ??= here);
      return here;
    } catch (_) {
      if (!silent && mounted) {
        setState(() => _error = S.of(context).t('ps_location_failed'));
      }
      return null;
    }
  }

  void _search(String q) {
    final query = q.trim();
    final rid = ++_requestId;
    if (query.isEmpty) {
      setState(() {
        _results = [];
        _searching = false;
        _error = null;
      });
      return;
    }
    setState(() {
      _searching = true;
      _error = null;
    });
    _debouncer.debounce(() async {
      try {
        // Without a location, bias to Brazzaville until GPS answers.
        final origin = _origin ?? const LatLng(-4.2634, 15.2429);
        final res = await GoogleMapsService.autocomplete(
          query: query,
          origin: origin,
          radiusMeters: 50000,
        );
        if (!mounted || rid != _requestId) return;
        setState(() {
          _results = res;
          _searching = false;
        });
      } catch (_) {
        if (!mounted || rid != _requestId) return;
        setState(() {
          _searching = false;
          _error = S.of(context).t('sd_search_failed_hint');
        });
      }
    });
  }

  Future<void> _pick(PlacePrediction p) async {
    setState(() => _resolving = true);
    final d = await GoogleMapsService.details(p.placeId);
    if (!mounted) return;
    setState(() => _resolving = false);
    if (d == null) {
      setState(() => _error = S.of(context).t('sd_search_failed_hint'));
      return;
    }
    Navigator.pop(context, d);
  }

  Future<void> _useCurrent() async {
    setState(() {
      _resolving = true;
      _error = null;
    });
    final here = await _locate();
    if (here == null) {
      if (mounted) {
        setState(() {
          _resolving = false;
          _error ??= S.of(context).t('ps_location_failed');
        });
      }
      return;
    }
    final place = await GoogleMapsService.reverseGeocode(here) ??
        PlaceDetails(
          placeId: '',
          lat: here.latitude,
          lng: here.longitude,
          formattedAddress:
              '${here.latitude.toStringAsFixed(5)}, ${here.longitude.toStringAsFixed(5)}',
        );
    if (!mounted) return;
    Navigator.pop(context, place);
  }

  @override
  Widget build(BuildContext context) {
    final t = S.of(context);
    final height = MediaQuery.of(context).size.height * 0.85;
    final saved = widget.includeSaved
        ? FavoritePlacesService.filter(_saved, _ctrl.text).take(4).toList()
        : const <Map<String, dynamic>>[];
    return Padding(
      padding:
          EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
      child: SizedBox(
        height: height,
        child: Column(
          children: [
            const SizedBox(height: 10),
            Container(
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                color: EfuridePalette.divider,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 14, 12, 6),
              child: Row(
                children: [
                  Expanded(
                    child: Text(
                      widget.title ?? t.t('ps_title'),
                      style: const TextStyle(
                          fontSize: 17, fontWeight: FontWeight.w800),
                    ),
                  ),
                  IconButton(
                    onPressed: () => Navigator.pop(context),
                    icon: const Icon(Icons.close),
                  ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: TextField(
                controller: _ctrl,
                autofocus: widget.initialQuery == null,
                onChanged: (v) {
                  setState(() {});
                  _search(v);
                },
                decoration: InputDecoration(
                  hintText: t.t('ps_hint'),
                  prefixIcon: const Icon(Icons.search),
                  filled: true,
                  fillColor: EfuridePalette.greyBg,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(14),
                    borderSide: BorderSide.none,
                  ),
                ),
              ),
            ),
            ListTile(
              leading: const CircleAvatar(
                backgroundColor: EfuridePalette.lightBlue,
                child: Icon(Icons.my_location, color: EfuridePalette.blue),
              ),
              title: Text(t.t('sd_use_current'),
                  style: const TextStyle(fontWeight: FontWeight.w600)),
              onTap: _resolving ? null : _useCurrent,
            ),
            const Divider(height: 1),
            for (final r in saved)
              ListTile(
                leading: Icon(
                    FavoritePlacesService.isHomeLabel(
                            (r['label'] ?? '').toString())
                        ? Icons.home_rounded
                        : Icons.star_rounded,
                    color: EfuridePalette.ink),
                title: Text((r['label'] ?? r['name'] ?? '').toString(),
                    style: const TextStyle(fontWeight: FontWeight.w700)),
                subtitle: Text((r['address'] ?? '').toString(),
                    maxLines: 1, overflow: TextOverflow.ellipsis),
                onTap: () => Navigator.pop(
                  context,
                  PlaceDetails(
                    placeId: '',
                    lat: (r['lat'] as num).toDouble(),
                    lng: (r['lng'] as num).toDouble(),
                    formattedAddress: (r['address'] ?? '').toString(),
                    name: (r['label'] ?? '').toString(),
                  ),
                ),
              ),
            if (saved.isNotEmpty) const Divider(height: 1),
            if (_error != null)
              Padding(
                padding: const EdgeInsets.all(12),
                child: Text(_error!,
                    style: const TextStyle(color: EfuridePalette.danger)),
              ),
            Expanded(
              child: (_searching || _resolving)
                  ? const Center(
                      child: CircularProgressIndicator(
                          color: EfuridePalette.blue))
                  : ListView.separated(
                      itemCount: _results.length,
                      separatorBuilder: (_, __) =>
                          const Divider(height: 1, indent: 64),
                      itemBuilder: (_, i) {
                        final p = _results[i];
                        final d = p.distanceKm;
                        return ListTile(
                          leading: const KIcon(Icons.location_on_outlined),
                          title: Text(
                            p.primaryText.isNotEmpty
                                ? p.primaryText
                                : p.fullDescription,
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                            style:
                                const TextStyle(fontWeight: FontWeight.w600),
                          ),
                          subtitle: p.secondaryText.isEmpty
                              ? null
                              : Text(p.secondaryText,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis),
                          trailing: d == null
                              ? null
                              : Text(
                                  d < 1
                                      ? '${(d * 1000).round()} m'
                                      : '${d.toStringAsFixed(1)} km',
                                  style: const TextStyle(
                                      fontSize: 13.5,
                                      color: EfuridePalette.inkMuted),
                                ),
                          onTap: () => _pick(p),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }
}
