﻿import 'dart:async';
import 'package:flutter/foundation.dart';

/// Coalesces rapid calls into a single delayed invocation.
///
/// Typical use:
///
/// ```dart
/// final _debouncer = Debouncer(milliseconds: 300);
/// // ...
/// TextField(onChanged: (v) => _debouncer.debounce(() => _search(v)));
/// // ...
/// @override
/// void dispose() {
///   _debouncer.dispose();
///   super.dispose();
/// }
/// ```
///
/// - Each call to [debounce] cancels any pending invocation and schedules
///   a new one.
/// - The callback may be `async`; returned futures are ignored.
/// - [cancel] drops any pending invocation.
class Debouncer {
  /// Delay before the callback fires, in milliseconds.
  final int milliseconds;

  Timer? _timer;

  Debouncer({required this.milliseconds});

  /// True while a callback is scheduled and hasn't fired yet.
  bool get isPending => _timer?.isActive == true;

  /// True if a callback has already been scheduled and cancelled since
  /// the last invocation. Informational only.
  bool get isIdle => _timer == null || _timer?.isActive == false;

  /// Schedules [action] to run after [milliseconds].
  ///
  /// If [debounce] is called again before the timer fires, the previous
  /// action is discarded.
  void debounce(FutureOr<void> Function() action) {
    _timer?.cancel();
    _timer = Timer(Duration(milliseconds: milliseconds), () {
      try {
        final result = action();
        if (result is Future) {
          // Fire-and-forget; log uncaught errors so they don't vanish.
          result.catchError((Object e, StackTrace s) {
            debugPrint('Debouncer callback threw: $e\n$s');
          });
        }
      } catch (e, s) {
        debugPrint('Debouncer callback threw: $e\n$s');
      }
    });
  }

  /// Runs [action] immediately and cancels any pending invocation.
  ///
  /// Useful for a "submit" button that flushes a pending search.
  void flush(FutureOr<void> Function() action) {
    _timer?.cancel();
    _timer = null;
    final result = action();
    if (result is Future) {
      result.catchError((Object e, StackTrace s) {
        debugPrint('Debouncer.flush callback threw: $e\n$s');
      });
    }
  }

  /// Cancels any pending invocation.
  void cancel() {
    _timer?.cancel();
    _timer = null;
  }

  /// Alias for [cancel] for backwards compatibility with the old API.
  void dispose() => cancel();
}
