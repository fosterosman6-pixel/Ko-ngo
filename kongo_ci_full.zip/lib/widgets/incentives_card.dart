// lib/widgets/incentives_card.dart
//
// "Earn more": the weekly targets and peak-hour bonuses the admin set for
// this person's country and role, with their progress this week.
// Shows nothing when there are no active rules.

import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:efuride_app/config/country_config.dart';
import 'package:efuride_app/config/efuride_palette.dart';
import 'package:efuride_app/l10n/app_strings.dart';

class IncentivesCard extends StatefulWidget {
  /// 'trips' for drivers, 'tasks' for shoppers (only changes the wording).
  final bool tasks;
  const IncentivesCard({super.key, this.tasks = false});

  @override
  State<IncentivesCard> createState() => _IncentivesCardState();
}

class _IncentivesCardState extends State<IncentivesCard> {
  List<Map<String, dynamic>> _rules = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final r = await Supabase.instance.client.rpc('kongo_my_incentives');
      if (!mounted) return;
      setState(() => _rules = [
            for (final e in (r as List)) Map<String, dynamic>.from(e as Map)
          ]);
    } catch (_) {
      // No incentives set up yet (or SQL not run): show nothing.
    }
  }

  String _hour(dynamic h) => '${(int.tryParse('$h') ?? 0) % 24}:00';

  @override
  Widget build(BuildContext context) {
    if (_rules.isEmpty) return const SizedBox.shrink();
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: EfuridePalette.accent.withValues(alpha: 0.16),
        borderRadius: BorderRadius.circular(18),
        border:
            Border.all(color: EfuridePalette.accent.withValues(alpha: 0.5)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [
            const Icon(Icons.emoji_events_outlined,
                color: EfuridePalette.ink),
            const SizedBox(width: 8),
            Text(tr('Earn more'),
                style: const TextStyle(
                    fontSize: 17,
                    fontWeight: FontWeight.w900,
                    color: EfuridePalette.ink)),
          ]),
          for (final r in _rules) ...[
            const SizedBox(height: 12),
            if (r['kind'] == 'weekly_target')
              _weekly(r)
            else
              _peak(r),
          ],
        ],
      ),
    );
  }

  Widget _weekly(Map<String, dynamic> r) {
    final target = int.tryParse('${r['target']}') ?? 1;
    final done = (int.tryParse('${r['done']}') ?? 0).clamp(0, target);
    final bonus = CountryConfig.money(num.tryParse('${r['bonus']}') ?? 0);
    final noun = widget.tasks ? tr('tasks') : tr('trips');
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('${r['title']}',
            style: const TextStyle(
                fontSize: 15, fontWeight: FontWeight.w800)),
        const SizedBox(height: 6),
        ClipRRect(
          borderRadius: BorderRadius.circular(8),
          child: LinearProgressIndicator(
            value: done / target,
            minHeight: 10,
            backgroundColor: Colors.white,
            color: EfuridePalette.accent,
          ),
        ),
        const SizedBox(height: 4),
        Text(
          done >= target
              ? tr('Done! {0} added to your wallet', [bonus])
              : tr('{0} of {1} {2} this week · Bonus {3}',
                  [done, target, noun, bonus]),
          style: const TextStyle(
              fontSize: 13.5, color: EfuridePalette.inkMuted),
        ),
      ],
    );
  }

  Widget _peak(Map<String, dynamic> r) {
    final bonus = CountryConfig.money(num.tryParse('${r['bonus']}') ?? 0);
    return Row(children: [
      const Icon(Icons.bolt, size: 20, color: EfuridePalette.ink),
      const SizedBox(width: 8),
      Expanded(
        child: Text(
          tr('{0}: +{1} for every {2} between {3} and {4}', [
            r['title'],
            bonus,
            widget.tasks ? tr('task') : tr('trip'),
            _hour(r['peak_start']),
            _hour(r['peak_end'])
          ]),
          style:
              const TextStyle(fontSize: 14.5, fontWeight: FontWeight.w700),
        ),
      ),
    ]);
  }
}
