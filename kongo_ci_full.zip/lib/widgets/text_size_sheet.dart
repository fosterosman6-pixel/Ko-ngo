// lib/widgets/text_size_sheet.dart
//
// "Text size" picker used by every role's Settings screen.
//
//   await showTextSizeSheet(context);

import 'package:flutter/material.dart';

import 'package:efuride_app/config/efuride_palette.dart';
import 'package:efuride_app/config/readability.dart';
import 'package:efuride_app/l10n/app_strings.dart';

Future<void> showTextSizeSheet(BuildContext context) {
  return showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.white,
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
    ),
    builder: (_) => const _TextSizeSheet(),
  );
}

class _TextSizeSheet extends StatelessWidget {
  const _TextSizeSheet();

  @override
  Widget build(BuildContext context) {
    final t = S.of(context);
    return SafeArea(
      child: ValueListenableBuilder<double>(
        valueListenable: Readability.textScale,
        builder: (context, current, _) => SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(20, 12, 20, 20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: EfuridePalette.divider,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
              const SizedBox(height: 18),
              Text(
                t.t('text_size'),
                style: const TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.w800,
                  color: EfuridePalette.ink,
                ),
              ),
              const SizedBox(height: 6),
              Text(
                t.t('ts_hint'),
                style: const TextStyle(
                    fontSize: 15, color: EfuridePalette.inkMuted),
              ),
              const SizedBox(height: 16),
              // Live preview at the chosen size.
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: EfuridePalette.cream,
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: EfuridePalette.divider),
                ),
                child: Text(
                  t.t('ts_preview'),
                  style: const TextStyle(
                    fontSize: 16,
                    height: 1.4,
                    color: EfuridePalette.ink,
                  ),
                ),
              ),
              const SizedBox(height: 12),
              for (var i = 0; i < Readability.scales.length; i++)
                _option(
                  context,
                  label: t.t(Readability.scaleLabelKeys[i]),
                  value: Readability.scales[i],
                  selected: Readability.scales[i] == current,
                ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _option(
    BuildContext context, {
    required String label,
    required double value,
    required bool selected,
  }) {
    return Padding(
      padding: const EdgeInsets.only(top: 8),
      child: Material(
        color: selected ? EfuridePalette.lightBlue : Colors.white,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(14),
          side: BorderSide(
            color: selected ? EfuridePalette.blue : EfuridePalette.divider,
            width: selected ? 2 : 1,
          ),
        ),
        child: InkWell(
          borderRadius: BorderRadius.circular(14),
          onTap: () => Readability.setScale(value),
          child: ConstrainedBox(
            constraints: const BoxConstraints(minHeight: 56),
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Row(
                children: [
                  // "Aa" drawn at the size it would produce.
                  SizedBox(
                    width: 52,
                    child: Text(
                      tr('Aa'),
                      textScaler: TextScaler.noScaling,
                      style: TextStyle(
                        fontSize: 16 * value,
                        fontWeight: FontWeight.w700,
                        color: EfuridePalette.ink,
                      ),
                    ),
                  ),
                  Expanded(
                    child: Text(
                      label,
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight:
                            selected ? FontWeight.w700 : FontWeight.w400,
                        color: EfuridePalette.ink,
                      ),
                    ),
                  ),
                  if (selected)
                    const Icon(Icons.check_circle,
                        color: EfuridePalette.blue),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
