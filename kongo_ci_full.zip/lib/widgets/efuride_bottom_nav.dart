// lib/widgets/efuride_bottom_nav.dart

import 'package:flutter/material.dart';
import 'package:efuride_app/config/efuride_palette.dart';
import 'package:efuride_app/l10n/app_strings.dart';

enum EfurideRole { customer, driver, shopper, merchant }

class EfurideNavItem {
  final String iconPath;       // Inactive (Grey) image path
  final String activeIconPath; // Active (Blue) image path
  final String labelKey;       // i18n key
  
  const EfurideNavItem({
    required this.iconPath,
    required this.activeIconPath,
    required this.labelKey,
  });
}

class EfurideBottomNav extends StatelessWidget {
  final int currentIndex;
  final ValueChanged<int> onTap;
  final List<EfurideNavItem> items;
  final EfurideRole role;
  final Color? accentOverride;

  const EfurideBottomNav({
    super.key,
    required this.currentIndex,
    required this.onTap,
    required this.items,
    required this.role,
    this.accentOverride,
  });

  Color get _accent {
    if (accentOverride != null) return accentOverride!;
    switch (role) {
      case EfurideRole.driver:   return EfuridePalette.blueDeep;
      case EfurideRole.shopper:  return EfuridePalette.shopperAccent;
      case EfurideRole.merchant: return EfuridePalette.merchantAccent;
      case EfurideRole.customer:
      default:                   return EfuridePalette.blueDeep;
    }
  }

  @override
  Widget build(BuildContext context) {
    final t = S.of(context);
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        border: const Border(top: BorderSide(color: EfuridePalette.divider)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.04),
            blurRadius: 8,
            offset: const Offset(0, -2),
          ),
        ],
      ),
      child: SafeArea(
        top: false,
        // Grows with large text instead of clipping the labels.
        child: ConstrainedBox(
          constraints: const BoxConstraints(minHeight: 68),
          // IntrinsicHeight lets every tab's tap area be as tall as the
          // tallest label without stretching to the screen height.
          child: IntrinsicHeight(
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: List.generate(items.length, (i) {
              final active = i == currentIndex;
              final item = items[i];
              
              return Expanded(
                child: InkWell(
                  onTap: () => onTap(i),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(
                        vertical: 8, horizontal: 2),
                    child: Column(
                    mainAxisSize: MainAxisSize.min,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      // ── USING YOUR CUSTOM IMAGES ──
                      Image.asset(
                        active ? item.activeIconPath : item.iconPath,
                        width: 24,
                        height: 24,
                        fit: BoxFit.contain,
                        // Never show a red error box in the nav bar.
                        errorBuilder: (_, __, ___) => Icon(
                          Icons.circle_outlined,
                          size: 22,
                          color: active ? _accent : EfuridePalette.inkMuted,
                        ),
                      ),
                      const SizedBox(height: 3),
                      Text(
                        t.t(item.labelKey),
                        maxLines: 2,
                        textAlign: TextAlign.center,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          fontSize: 13,
                          fontWeight: active ? FontWeight.w800 : FontWeight.w500,
                          color: active ? _accent : EfuridePalette.inkMuted,
                        ),
                      ),
                    ],
                  ),
                  ),
                ),
              );
            }),
          ),
          ),
        ),
      ),
    );
  }
}

// ── Standard tab sets per role ────────────────────────────────────
// Every nav icon follows the same naming rule:
//   assets/images/grey_<name>.png  → inactive
//   assets/images/blue_<name>.png  → active
// Both files must exist for every <name> used below.

const List<EfurideNavItem> kCustomerTabs = [
  EfurideNavItem(
    iconPath: 'assets/images/grey_home.png',
    activeIconPath: 'assets/images/blue_home.png',
    labelKey: 'home',
  ),
  EfurideNavItem(
    iconPath: 'assets/images/grey_car.png',
    activeIconPath: 'assets/images/blue_car.png',
    labelKey: 'rides',
  ),
  // Orders (shop orders); the wallet lives on the Profile page.
  EfurideNavItem(
    iconPath: 'assets/images/grey_clipboard.png',
    activeIconPath: 'assets/images/blue_clipboard.png',
    labelKey: 'orders',
  ),
  EfurideNavItem(
    // Settings (profile, language, wallet … all in one place).
    iconPath: 'assets/images/grey_gear.png',
    activeIconPath: 'assets/images/blue_gear.png',
    labelKey: 'settings',
  ),
];

const List<EfurideNavItem> kDriverTabs = [
  EfurideNavItem(
    iconPath: 'assets/images/grey_home.png',
    activeIconPath: 'assets/images/blue_home.png',
    labelKey: 'home',
  ),
  EfurideNavItem(
    iconPath: 'assets/images/grey_clipboard_clock.png',
    activeIconPath: 'assets/images/blue_clipboard_clock.png',
    labelKey: 'trips',
  ),
  EfurideNavItem(
    iconPath: 'assets/images/grey_wallet.png',
    activeIconPath: 'assets/images/blue_wallet.png',
    labelKey: 'earnings',
  ),
  EfurideNavItem(
    iconPath: 'assets/images/grey_dots.png',
    activeIconPath: 'assets/images/blue_dots.png',
    labelKey: 'more',
  ),
];

const List<EfurideNavItem> kShopperTabs = [
  EfurideNavItem(
    iconPath: 'assets/images/grey_home.png',
    activeIconPath: 'assets/images/blue_home.png',
    labelKey: 'home',
  ),
  EfurideNavItem(
    iconPath: 'assets/images/grey_clipboard.png',
    activeIconPath: 'assets/images/blue_clipboard.png',
    labelKey: 'tasks',
  ),
  EfurideNavItem(
    iconPath: 'assets/images/grey_wallet.png',
    activeIconPath: 'assets/images/blue_wallet.png',
    labelKey: 'pay',
  ),
  EfurideNavItem(
    iconPath: 'assets/images/grey_gear.png',
    activeIconPath: 'assets/images/blue_gear.png',
    labelKey: 'settings',
  ),
];

const List<EfurideNavItem> kMerchantTabs = [
  EfurideNavItem(
    iconPath: 'assets/images/grey_bar_chart.png',
    activeIconPath: 'assets/images/blue_bar_chart.png',
    labelKey: 'dashboard',
  ),
  EfurideNavItem(
    iconPath: 'assets/images/grey_clipboard_clock.png',
    activeIconPath: 'assets/images/blue_clipboard_clock.png',
    labelKey: 'orders',
  ),
  EfurideNavItem(
    iconPath: 'assets/images/grey_clipboard.png',
    activeIconPath: 'assets/images/blue_clipboard.png',
    labelKey: 'menu',
  ),
  EfurideNavItem(
    iconPath: 'assets/images/grey_bank.png',
    activeIconPath: 'assets/images/blue_bank.png',
    labelKey: 'payouts',
  ),
];
