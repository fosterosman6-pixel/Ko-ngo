import 'package:flutter/material.dart';

class AppImage extends StatelessWidget {
  final String path;
  final double size;
  final Color? tint;
  final BoxFit fit;
  final IconData fallbackIcon;

  const AppImage(
    this.path, {
    super.key,
    this.size = 24,
    this.tint,
    this.fit = BoxFit.contain,
    this.fallbackIcon = Icons.image_not_supported_outlined,
  });

  @override
  Widget build(BuildContext context) {
    return Image.asset(
      path,
      width: size,
      height: size,
      fit: fit,
      color: tint,
      errorBuilder: (_, __, ___) => Icon(
        fallbackIcon,
        size: size,
        color: tint ?? Colors.grey,
      ),
    );
  }
}
