// lib/widgets/photo_source_sheet.dart
//
// Asks "Take a photo now" or "Choose from gallery", then returns the picture.
// Camera = live capture, so the photo is of the real thing right now.

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:efuride_app/config/efuride_palette.dart';
import 'package:efuride_app/l10n/app_strings.dart';
import 'package:efuride_app/services/storage_service.dart';
import 'package:efuride_app/widgets/k_icon.dart';

Future<XFile?> pickPhotoLiveOrGallery(
  BuildContext context, {
  int maxWidth = 1600,
  int imageQuality = 75,
}) async {
  final fromCamera = await showModalBottomSheet<bool>(
    context: context,
    backgroundColor: Colors.white,
    shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
    builder: (ctx) => SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(8, 12, 8, 12),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.photo_camera_rounded,
                  color: EfuridePalette.ink, size: 30),
              title: Text(tr('Take a photo now'),
                  style: const TextStyle(
                      fontSize: 17, fontWeight: FontWeight.w800)),
              onTap: () => Navigator.pop(ctx, true),
            ),
            ListTile(
              leading: const KIcon(Icons.photo_library_outlined,
                  color: EfuridePalette.ink, size: 30),
              title: Text(tr('Choose from gallery'),
                  style: const TextStyle(
                      fontSize: 17, fontWeight: FontWeight.w600)),
              onTap: () => Navigator.pop(ctx, false),
            ),
          ],
        ),
      ),
    ),
  );
  if (fromCamera == null) return null;
  return StorageService.instance.pickImage(
    fromCamera: fromCamera,
    maxWidth: maxWidth,
    imageQuality: imageQuality,
  );
}
