/// Pure address formatting. No network calls here.
class AddressFormatter {
  AddressFormatter._();

  /// Builds a clean, human-readable address from Nominatim's `address` map.
  ///
  /// Example:
  ///   "11, 2nd Street, Firgrove, Cape Town, 7130"
  static String format(Map<String, dynamic> addressObj) {
    final addr = (addressObj['address'] ?? {}) as Map;
    final parts = _collectParts(addr);
    if (parts.isEmpty) {
      return (addressObj['display_name'] ?? 'Location').toString();
    }
    return parts.join(', ');
  }

  /// Short one-line label for maps and chips:
  ///   "11 2nd Street, Firgrove" (drops city + postcode)
  static String short(Map<String, dynamic> addressObj) {
    final addr = (addressObj['address'] ?? {}) as Map;
    final house = _str(addr['house_number']);
    final road = _road(addr);
    final suburb = _suburb(addr);

    final line1 = [house, road].where((s) => s.isNotEmpty).join(' ');
    final parts = [if (line1.isNotEmpty) line1, suburb];
    if (parts.isEmpty) {
      return _firstLineOf((addressObj['display_name'] ?? '').toString());
    }
    return parts.join(', ');
  }

  /// "Pickup → Dropoff" style summary from two address strings.
  /// Takes only the first comma-separated chunk of each.
  static String routeSummary(String pickup, String dropoff) {
    String chunk(String s) {
      if (s.trim().isEmpty) return '—';
      return s.split(',').first.trim();
    }

    return '${chunk(pickup)} → ${chunk(dropoff)}';
  }

  /// Street + house number only. `"11 2nd Street"`.
  static String streetLine(Map<String, dynamic> addr) {
    final house = _str(addr['house_number']);
    final road = _road(addr);
    return [house, road].where((s) => s.isNotEmpty).join(' ');
  }

  // ============================================================
  // INTERNALS
  // ============================================================
  static List<String> _collectParts(Map addr) {
    final parts = <String>[];

    final house = _str(addr['house_number']);
    final road = _road(addr);
    final suburb = _suburb(addr);
    final city = _city(addr);
    final postcode = _str(addr['postcode']);

    final street = [house, road].where((s) => s.isNotEmpty).join(' ');
    if (street.isNotEmpty) parts.add(street);
    if (suburb.isNotEmpty) parts.add(suburb);
    if (city.isNotEmpty && city != suburb) parts.add(city);
    if (postcode.isNotEmpty) parts.add(postcode);

    return parts;
  }

  static String _road(Map addr) {
    for (final key in const [
      'road',
      'pedestrian',
      'footway',
      'path',
      'cycleway',
      'street',
      'avenue',
    ]) {
      final v = _str(addr[key]);
      if (v.isNotEmpty) return v;
    }
    return '';
  }

  static String _suburb(Map addr) {
    for (final key in const [
      'suburb',
      'neighbourhood',
      'quarter',
      'village',
      'hamlet',
    ]) {
      final v = _str(addr[key]);
      if (v.isNotEmpty) return v;
    }
    return '';
  }

  static String _city(Map addr) {
    for (final key in const [
      'city',
      'town',
      'municipality',
      'county',
      'state_district',
      'state',
    ]) {
      final v = _str(addr[key]);
      if (v.isNotEmpty) return v;
    }
    return '';
  }

  static String _str(dynamic v) {
    if (v == null) return '';
    return v.toString().trim();
  }

  static String _firstLineOf(String s) {
    final t = s.trim();
    if (t.isEmpty) return 'Location';
    final first = t.split(',').first.trim();
    return first.isEmpty ? t : first;
  }
}
