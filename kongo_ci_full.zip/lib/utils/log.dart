import 'package:flutter/foundation.dart';

class Log {
  Log._();

  /// Log an informational message.
  static void i(String tag, String message) {
    if (!kDebugMode) return;
    debugPrint('[$tag] $message');
  }

  /// Log a warning.
  static void w(String tag, String message) {
    debugPrint('⚠️ [$tag] $message');
  }

  /// Log an error with optional stack trace.
  static void e(String tag, String message, [Object? error, StackTrace? st]) {
    debugPrint('❌ [$tag] $message');
    if (error != null) debugPrint('   $error');
    if (st != null && kDebugMode) debugPrint('   $st');
  }
}
