import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:latlong2/latlong.dart';

import 'package:efuride_app/config/country_config.dart';
import 'package:efuride_app/utils/constants.dart';

/// A search result returned by Nominatim.
class GeoResult {
  final String name;
  final String fullAddress;
  final String suburb;
  final String city;
  final double lat;
  final double lng;
  final double distanceKm;

  const GeoResult({
    required this.name,
    required this.fullAddress,
    required this.suburb,
    required this.city,
    required this.lat,
    required this.lng,
    required this.distanceKm,
  });

  LatLng get latLng => LatLng(lat, lng);

  @override
  String toString() => 'GeoResult($name, ${distanceKm.toStringAsFixed(2)}km)';
}

/// Nominatim search and reverse geocoding.
///
/// - Uses a proper User-Agent (required by OSM policy).
/// - Applies timeouts.
/// - Filters malformed rows instead of crashing.
/// - Deduplicates by rounded lat/lng.
/// - Sorts by distance from the search center.
class GeoSearch {
  GeoSearch._();

  static const _base = 'https://nominatim.openstreetmap.org';
  static final _headers = {
    'User-Agent': AppConstants.nominatimUserAgent,
    'Accept-Language': 'en',
  };

  // ============================================================
  // SEARCH
  // ============================================================
  static Future<List<GeoResult>> search(
    String query, {
    LatLng? near,
    String? viewbox,
    bool bounded = false,
    int limit = AppConstants.maxSearchResults,
  }) async {
    final trimmed = query.trim();
    if (trimmed.isEmpty) return const [];

    try {
      final params = <String, String>{
        'q': trimmed,
        'format': 'json',
        'addressdetails': '1',
        'limit': '$limit',
        'countrycodes': CountryConfig.servedIso ?? AppConstants.searchCountryCode,
        'accept-language': 'en',
        'dedupe': '1',
      };

      if (viewbox != null && viewbox.isNotEmpty) {
        params['viewbox'] = viewbox;
        if (bounded) params['bounded'] = '1';
      }

      final url = Uri.https(
        'nominatim.openstreetmap.org',
        '/search',
        params,
      );

      final res = await http
          .get(url, headers: _headers)
          .timeout(AppConstants.geoTimeout);

      if (res.statusCode != 200) {
        debugPrint('GeoSearch.search HTTP ${res.statusCode}');
        return const [];
      }

      final data = json.decode(res.body);
      if (data is! List) return const [];

      return _parseSearchResults(data, near: near);
    } on TimeoutException {
      debugPrint('GeoSearch.search timed out for "$trimmed"');
      return const [];
    } catch (e) {
      debugPrint('GeoSearch.search failed: $e');
      return const [];
    }
  }

  /// Convenience: search near the given LatLng using Cape Town's viewbox.
  static Future<List<GeoResult>> searchNear(
    String query,
    LatLng center, {
    bool bounded = true,
    int limit = AppConstants.maxSearchResults,
  }) {
    return search(
      query,
      near: center,
      viewbox: _viewboxAround(center, AppConstants.searchRadiusKm),
      bounded: bounded,
      limit: limit,
    );
  }

  // ============================================================
  // REVERSE
  // ============================================================
  static Future<Map<String, dynamic>?> reverse(
    double lat,
    double lng,
  ) async {
    try {
      final url = Uri.https(
        'nominatim.openstreetmap.org',
        '/reverse',
        {
          'lat': '$lat',
          'lon': '$lng',
          'format': 'json',
          'addressdetails': '1',
          'zoom': '18',
          'accept-language': 'en',
        },
      );

      final res = await http
          .get(url, headers: _headers)
          .timeout(AppConstants.geoTimeout);

      if (res.statusCode != 200) {
        debugPrint('GeoSearch.reverse HTTP ${res.statusCode}');
        return null;
      }

      final data = json.decode(res.body);
      if (data is Map<String, dynamic>) return data;
      return null;
    } on TimeoutException {
      debugPrint('GeoSearch.reverse timed out');
      return null;
    } catch (e) {
      debugPrint('GeoSearch.reverse failed: $e');
      return null;
    }
  }

  // ============================================================
  // INTERNALS
  // ============================================================
  static List<GeoResult> _parseSearchResults(
    List raw, {
    LatLng? near,
  }) {
    final seen = <String>{};
    final out = <GeoResult>[];

    for (final item in raw) {
      if (item is! Map) continue;

      final lat = double.tryParse('${item['lat']}');
      final lng = double.tryParse('${item['lon']}');
      if (lat == null || lng == null) continue;

      final key = '${lat.toStringAsFixed(5)},${lng.toStringAsFixed(5)}';
      if (seen.contains(key)) continue;
      seen.add(key);

      final addr = (item['address'] ?? {}) as Map;

      final name = _shortName(addr, item);
      final full = _fullAddress(addr, item);
      final suburb = _pick(addr, const [
        'suburb',
        'neighbourhood',
        'quarter',
        'village',
        'hamlet',
      ]);
      final city = _pick(addr, const [
        'city',
        'town',
        'municipality',
        'county',
      ]);

      final dist = near == null ? 0.0 : _distanceKm(near, lat, lng);

      out.add(GeoResult(
        name: name,
        fullAddress: full,
        suburb: suburb,
        city: city,
        lat: lat,
        lng: lng,
        distanceKm: dist,
      ));
    }

    if (near != null) {
      out.sort((a, b) => a.distanceKm.compareTo(b.distanceKm));
    }
    return out;
  }

  static String _shortName(Map addr, Map item) {
    final house = _pick(addr, const ['house_number']);
    final road = _pick(addr, const [
      'road',
      'pedestrian',
      'footway',
      'path',
      'street',
    ]);
    final suburb = _pick(addr, const [
      'suburb',
      'neighbourhood',
      'village',
    ]);

    final street = [house, road].where((s) => s.isNotEmpty).join(' ');
    final parts = [if (street.isNotEmpty) street, suburb];
    if (parts.isNotEmpty) return parts.join(', ');

    return (item['display_name'] ?? 'Location').toString();
  }

  static String _fullAddress(Map addr, Map item) {
    final parts = <String>[];

    final house = _pick(addr, const ['house_number']);
    final road = _pick(addr, const [
      'road',
      'pedestrian',
      'footway',
      'path',
      'street',
    ]);
    final suburb = _pick(addr, const [
      'suburb',
      'neighbourhood',
      'quarter',
      'village',
    ]);
    final city = _pick(addr, const [
      'city',
      'town',
      'municipality',
      'county',
    ]);
    final postcode = _pick(addr, const ['postcode']);

    final street = [house, road].where((s) => s.isNotEmpty).join(' ');
    if (street.isNotEmpty) parts.add(street);
    if (suburb.isNotEmpty) parts.add(suburb);
    if (city.isNotEmpty && city != suburb) parts.add(city);
    if (postcode.isNotEmpty) parts.add(postcode);

    if (parts.isEmpty) {
      return (item['display_name'] ?? '').toString();
    }
    return parts.join(', ');
  }

  static String _pick(Map addr, List<String> keys) {
    for (final k in keys) {
      final v = addr[k];
      if (v == null) continue;
      final s = v.toString().trim();
      if (s.isNotEmpty) return s;
    }
    return '';
  }

  /// `left,top,right,bottom` = `minLng,maxLat,maxLng,minLat`.
  static String _viewboxAround(LatLng center, double radiusKm) {
    const kmPerDegLat = 111.32;
    final dLat = radiusKm / kmPerDegLat;
    final dLng = radiusKm /
        (kmPerDegLat * math.cos(center.latitude * math.pi / 180));

    final left = center.longitude - dLng;
    final right = center.longitude + dLng;
    final top = center.latitude + dLat;
    final bottom = center.latitude - dLat;

    return '${left.toStringAsFixed(4)},${top.toStringAsFixed(4)},'
        '${right.toStringAsFixed(4)},${bottom.toStringAsFixed(4)}';
  }

  static double _distanceKm(LatLng a, double lat, double lng) {
    const R = 6371.0;
    final dLat = (lat - a.latitude) * math.pi / 180;
    final dLng = (lng - a.longitude) * math.pi / 180;
    final h = math.sin(dLat / 2) * math.sin(dLat / 2) +
        math.cos(a.latitude * math.pi / 180) *
            math.cos(lat * math.pi / 180) *
            math.sin(dLng / 2) *
            math.sin(dLng / 2);
    return 2 * R * math.asin(math.sqrt(h));
  }
}
