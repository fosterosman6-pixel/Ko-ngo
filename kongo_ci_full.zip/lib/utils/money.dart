import 'package:intl/intl.dart';

import 'package:efuride_app/config/country_config.dart';

/// Money in the user's own country currency (see CountryConfig).
///
/// ZA `1234.5` → `"R 1,234.50"`, CG → `"1,235 XAF"`, KE → `"1,235 KSh"`
/// Negative amounts get a leading minus: `"-R 50.00"`.
String fmtMoney(num value) {
  final body = CountryConfig.money(value.abs());
  return value < 0 ? '-$body' : body;
}

/// Timestamp formatting.
///
/// `now - 30s`   → `"Just now"`
/// `now - 5m`    → `"5m ago"`
/// `today`       → `"Today, 14:32"`
/// `yesterday`   → `"Yesterday, 09:10"`
/// `older`       → `"12 Sep, 18:04"`
/// `last year`   → `"12 Sep 2024, 18:04"`
String fmtDate(dynamic value) {
  if (value == null) return '';
  try {
    final dt = DateTime.parse(value.toString()).toLocal();
    final now = DateTime.now();
    final diff = now.difference(dt);

    if (diff.inSeconds < 60) return 'Just now';
    if (diff.inMinutes < 60) return '${diff.inMinutes}m ago';
    if (diff.inHours < 24 && _isSameDay(now, dt)) {
      return 'Today, ${DateFormat('HH:mm').format(dt)}';
    }

    final yesterday = now.subtract(const Duration(days: 1));
    if (_isSameDay(yesterday, dt)) {
      return 'Yesterday, ${DateFormat('HH:mm').format(dt)}';
    }

    if (dt.year == now.year) {
      return DateFormat('d MMM, HH:mm').format(dt);
    }
    return DateFormat('d MMM yyyy, HH:mm').format(dt);
  } catch (_) {
    return '';
  }
}

/// Short date — no time. `"23 Sep"` or `"23 Sep 2024"`.
String fmtDateShort(dynamic value) {
  if (value == null) return '';
  try {
    final dt = DateTime.parse(value.toString()).toLocal();
    final now = DateTime.now();
    if (dt.year == now.year) return DateFormat('d MMM').format(dt);
    return DateFormat('d MMM yyyy').format(dt);
  } catch (_) {
    return '';
  }
}

/// Parse a user-typed money string into a number.
///
/// Handles: `"R 100"`, `"100.50"`, `"1 234,50"`, `"1,234.50"`, `" 100 "`.
/// Returns `null` if the input can't be parsed.
double? parseMoney(String? raw) {
  if (raw == null) return null;
  var s = raw.trim();
  if (s.isEmpty) return null;

  // Strip currency and spaces.
  s = s.replaceAll(RegExp(r'[^0-9,.\-]'), '');

  // European-style `1.234,50` → `1234.50`
  final hasComma = s.contains(',');
  final hasDot = s.contains('.');
  if (hasComma && hasDot) {
    // Whichever comes last is the decimal separator.
    if (s.lastIndexOf(',') > s.lastIndexOf('.')) {
      s = s.replaceAll('.', '').replaceAll(',', '.');
    } else {
      s = s.replaceAll(',', '');
    }
  } else if (hasComma) {
    s = s.replaceAll(',', '.');
  }

  return double.tryParse(s);
}

bool _isSameDay(DateTime a, DateTime b) =>
    a.year == b.year && a.month == b.month && a.day == b.day;
