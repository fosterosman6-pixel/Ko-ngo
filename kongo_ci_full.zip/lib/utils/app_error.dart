import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:efuride_app/config/country_config.dart';
import 'package:efuride_app/l10n/app_strings.dart';
import 'package:efuride_app/services/connection_service.dart';

/// A friendly, user-facing error with an optional retry action.
class AppError {
  final String title;
  final String message;
  final String? actionLabel;
  final VoidCallback? onRetry;
  final IconData icon;

  const AppError({
    required this.title,
    required this.message,
    this.actionLabel,
    this.onRetry,
    this.icon = Icons.error_outline,
  });

  /// Server rules are written in English; show them in the person's
  /// language. Messages with a number in them are matched by their shape.
  static String _serverText(String m) {
    final withdraw = RegExp(r'^You can withdraw up to (.+)$').firstMatch(m);
    if (withdraw != null) {
      final n = double.tryParse(withdraw.group(1)!);
      return tr('You can withdraw up to {0}',
          [n == null ? withdraw.group(1)! : CountryConfig.money(n)]);
    }
    final weeks = RegExp(r'^Choose between 1 and (\d+) weeks$').firstMatch(m);
    if (weeks != null) {
      return tr('Choose between 1 and {0} weeks', [weeks.group(1)!]);
    }
    return tr(m);
  }

  /// Maps any exception to a friendly AppError.
  static AppError from(Object error, {VoidCallback? onRetry}) {
    debugPrint('🔴 AppError: $error');

    // ---- Network ----
    // No signal / no data often arrives wrapped (ClientException,
    // AuthRetryableFetchException when the sign-in refreshes, …), so look
    // at the text too. Never show those raw messages to people.
    final raw = error.toString();

    // The sign-in server answered with a server error (for example "Database
    // error saving new user"). That is NOT a network problem, so don't say
    // "No internet".
    if (raw.contains('AuthRetryableFetchException') &&
        (RegExp(r'statusCode:\s*5\d\d').hasMatch(raw) ||
            raw.toLowerCase().contains('database error'))) {
      debugPrint('Auth server error: $raw');
      return AppError(
        title: tr('Sign-up problem on our side'),
        message: tr('Our server could not finish this. Please try again in a moment, or contact ko!ngo support.'),
        actionLabel: onRetry != null ? tr('Retry') : null,
        onRetry: onRetry,
        icon: Icons.cloud_off_rounded,
      );
    }
    const offline = [
      'SocketException',
      'Failed host lookup',
      'ClientException',
      'Network is unreachable',
      'Connection refused',
      'Connection reset',
      'Connection closed',
      'Connection timed out',
      'HandshakeException',
      'AuthRetryableFetchException',
      'No address associated with hostname',
    ];
    if (error is SocketException || offline.any(raw.contains)) {
      ConnectionService.instance.reportOffline();
      return AppError(
        title: tr('No internet connection'),
        message: tr('Please check your network and try again.'),
        actionLabel: tr('Retry'),
        onRetry: onRetry,
        icon: Icons.wifi_off_rounded,
      );
    }
    if (error is TimeoutException) {
      return AppError(
        title: tr('Request timed out'),
        message: tr('The server took too long to respond. Try again.'),
        actionLabel: tr('Retry'),
        onRetry: onRetry,
        icon: Icons.timer_off_outlined,
      );
    }
    if (error is HttpException) {
      return AppError(
        title: tr('Something went wrong'),
        message: tr('We couldn\'t reach our servers. Please try again.'),
        actionLabel: tr('Retry'),
        onRetry: onRetry,
        icon: Icons.cloud_off_rounded,
      );
    }

    // ---- Supabase / Postgres ----
    if (error is PostgrestException) {
      final code = error.code ?? '';
      final msg = error.message.toLowerCase();

      // Server price checks (step 6).
      if (msg.contains('card_not_available')) {
        return AppError(
          title: tr('Card not available'),
          message: tr('Card payments are not available here yet. Please choose cash or wallet.'),
          icon: Icons.credit_card_off_outlined,
        );
      }
      if (msg.contains('kongo_fare_too_low')) {
        final m = RegExp(r'([0-9]+(?:\.[0-9]+)?)\s*$').firstMatch(error.message);
        final low = m == null ? null : double.tryParse(m.group(1)!);
        return AppError(
          title: tr('The price has changed'),
          message: low == null
              ? tr('Please go back and check the price again.')
              : tr('The lowest price for this trip is {0}. Please go back and check the price again.',
                  [CountryConfig.money(low)]),
          actionLabel: tr('Retry'),
          onRetry: onRetry,
          icon: Icons.price_change_outlined,
        );
      }
      if (msg.contains('kongo_job_closed')) {
        return AppError(
          title: tr('This job is closed'),
          message: tr('This job is no longer taking applications.'),
          icon: Icons.work_off_outlined,
        );
      }
      if (msg.contains('kongo_own_job')) {
        return AppError(
          title: tr('Not possible'),
          message: tr('You cannot apply to your own job.'),
          icon: Icons.info_outline,
        );
      }
      if (msg.contains('kongo_not_available')) {
        return AppError(
          title: tr('Not available'),
          message: tr('This is not available right now.'),
          icon: Icons.info_outline,
        );
      }
      if (msg.contains('insufficient_balance')) {
        return AppError(
          title: tr('Not enough money in your wallet'),
          message: tr('Top up your wallet or choose another way to pay.'),
          icon: Icons.account_balance_wallet_outlined,
        );
      }

      if (msg.contains('duplicate') || code == '23505') {
        return AppError(
          title: tr('Already exists'),
          message: tr('This record already exists. Try a different value.'),
          icon: Icons.info_outline,
        );
      }
      if (msg.contains('violates foreign key') || code == '23503') {
        return AppError(
          title: tr('Missing information'),
          message: tr('Some required details are missing. Please try again.'),
          onRetry: onRetry,
        );
      }
      if (msg.contains('row level security') ||
          msg.contains('row-level security') ||
          code == '42501') {
        return AppError(
          title: tr('Access denied'),
          message: tr('You don\'t have permission for this action. Try signing in again.'),
          icon: Icons.lock_outline,
        );
      }
      if (msg.contains('jwt') || msg.contains('expired')) {
        return AppError(
          title: tr('Session expired'),
          message: tr('Please sign in again to continue.'),
          icon: Icons.lock_clock_outlined,
        );
      }
      // A rule on the server said no (raise exception): its message is
      // written for people, so show it instead of a generic error.
      if (code == 'P0001' && error.message.trim().isNotEmpty) {
        final clean = error.message
            .replaceFirst(RegExp(r'^[a-z_]+:\s*'), '')
            .trim();
        return AppError(
          title: tr('Couldn\'t complete request'),
          message: _serverText(clean),
          actionLabel: tr('Retry'),
          onRetry: onRetry,
        );
      }
      // Anything else: friendly text and a short code only (never the
      // database's own message, which can reveal internal details).
      debugPrint('Postgrest error ${error.code}: ${error.message}');
      return AppError(
        title: tr('Couldn\'t complete request'),
        message: code.isEmpty
            ? tr('Something went wrong on our side. Please try again.')
            : '${tr('Something went wrong on our side. Please try again.')} (${tr('code')} $code)',
        actionLabel: tr('Retry'),
        onRetry: onRetry,
      );
    }

    // ---- File uploads ----
    if (error is StorageException) {
      debugPrint('Storage error ${error.statusCode}: ${error.message}');
      final m = error.message.toLowerCase();
      final denied = m.contains('row-level security') ||
          m.contains('row level security') ||
          error.statusCode == '403' ||
          error.statusCode == '401';
      return AppError(
        title: tr('Upload failed'),
        message: denied
            ? tr('Pictures can\'t be saved for this account yet. Please contact ko!ngo support.')
            : tr('The picture could not be saved. Please try again.'),
        actionLabel: denied ? null : tr('Retry'),
        onRetry: denied ? null : onRetry,
        icon: Icons.image_not_supported_outlined,
      );
    }

    if (error is AuthException) {
      final msg = error.message.toLowerCase();
      if (msg.contains('invalid') && msg.contains('login')) {
        return AppError(
          title: tr('Wrong email or password'),
          message: tr('Please check your details and try again.'),
          icon: Icons.key_off_outlined,
        );
      }
      if (msg.contains('already')) {
        return AppError(
          title: tr('Already registered'),
          message: tr('This email is already in use. Try signing in.'),
          icon: Icons.person_outline,
        );
      }
      return AppError(
        title: tr('Please sign in again'),
        message: tr('Your session ended. Sign in again to continue.'),
        actionLabel: tr('Retry'),
        onRetry: onRetry,
        icon: Icons.lock_outline,
      );
    }

    // ---- Location ----
    final errStr = error.toString();
    if (errStr.contains('LocationService')) {
      return AppError(
        title: tr('Location is off'),
        message: tr('Please turn on GPS so we can find you.'),
        actionLabel: tr('Open Settings'),
        onRetry: onRetry,
        icon: Icons.location_off_outlined,
      );
    }
    if (errStr.contains('LocationPermission')) {
      return AppError(
        title: tr('Location permission needed'),
        message: tr('ko!ngo needs your location to find nearby drivers.'),
        actionLabel: tr('Open Settings'),
        onRetry: onRetry,
        icon: Icons.location_disabled_outlined,
      );
    }

    // ---- Fallback ----
    return AppError(
      title: tr('Something went wrong'),
      message: tr('Please try again in a moment.'),
      actionLabel: onRetry != null ? tr('Retry') : null,
      onRetry: onRetry,
    );
  }
}
