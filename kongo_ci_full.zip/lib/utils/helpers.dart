﻿import 'package:efuride_app/utils/address_formatter.dart';
import 'package:efuride_app/utils/geo_search.dart';
import 'package:latlong2/latlong.dart';
/// Legacy facade — prefer `AddressFormatter` and `GeoSearch` directly.
///
/// Kept so old call sites keep compiling while you migrate.
@Deprecated('Use AddressFormatter.format or GeoSearch.search instead')
class Helpers {
  Helpers._();

  static String formatAddress(Map<String, dynamic> addressObj) =>
      AddressFormatter.format(addressObj);

  @Deprecated('Use GeoSearch.searchNear instead')
  static Future<List<Map<String, dynamic>>> searchLocation(
    String query, {
    // New signature keeps the query parameter honest.
    // Old callers that didn't pass near get Cape Town bias by default.
    double? nearLat,
    double? nearLng,
  }) async {
    if (query.trim().isEmpty) return const [];

    // ignore: avoid_redundant_argument_values
    final results = nearLat != null && nearLng != null
        ? await GeoSearch.searchNear(
            query,
            LatLng(nearLat, nearLng),
          )
        : await GeoSearch.search(query);

    // Preserve the old map shape so callers don't break.
    return results
        .map((r) => <String, dynamic>{
              'name': r.name,
              'full_address': r.fullAddress,
              'lat': r.lat,
              'lng': r.lng,
              'suburb': r.suburb,
              'city': r.city,
              'distance_km': r.distanceKm,
            })
        .toList();
  }
}
