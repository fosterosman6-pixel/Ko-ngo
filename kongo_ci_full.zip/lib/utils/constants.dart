﻿import 'package:latlong2/latlong.dart';

/// Geographic and non-secret app constants.
///
/// Secrets belong in `AppConfig`. App name / version should be read from
/// `AppConfig` or `pubspec.yaml`, not duplicated here.
class AppConstants {
  AppConstants._();

  // ============================================================
  // GEOGRAPHY — CAPE TOWN & WESTERN CAPE BOUNDS
  // ============================================================

  /// Fallback center when we can't get the user's location.
  /// Cape Town CBD.
  static const LatLng defaultCenter = LatLng(-33.9249, 18.4241);

  /// Default zoom for the fallback center.
  static const double defaultZoom = 14.0;

  /// Zoom used when we have a specific pickup / dropoff.
  static const double detailZoom = 16.0;

  /// Maximum distance (km) from a search center that results are allowed.
  /// Used to bias Nominatim search to a bounded viewbox.
  static const double searchRadiusKm = 50.0;

  /// Nominatim `viewbox` for Cape Town metro area.
  ///
  /// Format: `left,top,right,bottom` = `minLng,maxLat,maxLng,minLat`.
  static const String capeTownViewbox = '18.30,-33.60,19.10,-34.30';

  /// Nominatim `viewbox` for the whole Western Cape.
  ///
  /// Format: `left,top,right,bottom` = `minLng,maxLat,maxLng,minLat`.
  static const String westernCapeViewbox = '17.50,-30.00,24.30,-34.80';

  // ============================================================
  // SEARCH / NETWORK
  // ============================================================

  /// Nominatim requires a contact in the User-Agent.
  /// See: https://operations.osmfoundation.org/policies/nominatim/
  static const String nominatimUserAgent =
      'kongo/1.0 (ko!ngo app)';

  /// Timeout for geocoding / routing requests.
  static const Duration geoTimeout = Duration(seconds: 10);

  /// Max results returned by a location search.
  static const int maxSearchResults = 12;

  // ============================================================
  // COUNTRIES
  // ============================================================

  /// Default country for address searches.
  static const String searchCountryCode = 'za';

  /// Human-readable fallback label.
  static const String defaultLocationLabel = 'Cape Town, South Africa';
}
