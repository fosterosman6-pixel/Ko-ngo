/// Small helpers for phone numbers: normalisation + masking.
///
/// Centralised so both the chat screen and the SOS setup screen use the
/// same rules. Defaults to South Africa (+27) when the number looks local.
class PhoneUtils {
  PhoneUtils._();

  /// Turns a user-entered phone string into an E.164-ish number.
  /// Returns `null` if it can't be normalised.
  ///
  /// Handles:
  ///   "082 123 4567"       → "+27821234567"
  ///   "0821234567"         → "+27821234567"
  ///   "0027 82 123 4567"   → "+27821234567"
  ///   "+27 82 123 4567"    → "+27821234567"
  ///   "27821234567"        → "+27821234567"
  static String? normalise(String raw, {String defaultCountryCode = '27'}) {
    var cleaned = raw.replaceAll(RegExp(r'[\s\-\(\)\.]'), '');
    if (cleaned.isEmpty) return null;

    // 00xx international prefix → +
    if (cleaned.startsWith('00')) {
      cleaned = '+${cleaned.substring(2)}';
    }

    // Local leading 0 → +27
    if (cleaned.startsWith('0')) {
      cleaned = '+$defaultCountryCode${cleaned.substring(1)}';
    }

    // Bare digits that look like a local mobile (9-10 digits) → +27
    if (!cleaned.startsWith('+') &&
        cleaned.length >= 9 &&
        cleaned.length <= 10) {
      cleaned = '+$defaultCountryCode$cleaned';
    }

    // Must be + followed by 9-15 digits
    if (!RegExp(r'^\+\d{9,15}$').hasMatch(cleaned)) return null;
    return cleaned;
  }

  /// Masks the middle of the number for UI display.
  /// `+27821234567` → `+278 •••• 67`
  static String mask(String phone) {
    final cleaned = phone.replaceAll(RegExp(r'[\s\-\(\)]'), '');
    if (cleaned.length < 6) return '••••••';
    final start = cleaned.substring(0, 4);
    final end = cleaned.substring(cleaned.length - 2);
    return '$start •••• $end';
  }

  /// Basic validity check on an already-normalised number.
  static bool isValid(String normalised) =>
      RegExp(r'^\+\d{9,15}$').hasMatch(normalised);
}
