// lib/utils/search_match.dart
//
// Forgiving text search: ignores capitals, accents (é = e), punctuation
// (coca-cola = coca cola) and word order. Every word typed must be found.

const _from = 'àáâãäåçèéêëìíîïñòóôõöùúûüýÿœæ';
const _to = 'aaaaaaceeeeiiiinooooouuuuyyoa';

String searchNorm(String s) {
  final b = StringBuffer();
  for (final r in s.toLowerCase().runes) {
    final c = String.fromCharCode(r);
    final i = _from.indexOf(c);
    if (i >= 0) {
      b.write(_to[i]);
    } else if (RegExp(r'[a-z0-9]').hasMatch(c) || r > 127) {
      b.write(c);
    } else {
      b.write(' ');
    }
  }
  return b.toString().replaceAll(RegExp(r'\s+'), ' ').trim();
}

/// True when every word of [query] appears in any of [fields].
bool searchMatches(String query, Iterable<String?> fields) {
  final words = searchNorm(query).split(' ').where((w) => w.isNotEmpty);
  if (words.isEmpty) return true;
  final hay = searchNorm(fields.where((f) => f != null).join(' '));
  return words.every(hay.contains);
}

/// Makes text safe to put inside an ilike pattern.
String ilikeSafe(String s) =>
    s.replaceAll(RegExp(r'[%_\\,()*]'), ' ').trim();
