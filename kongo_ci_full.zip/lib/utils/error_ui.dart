import 'package:flutter/material.dart';
import 'app_error.dart';

class ErrorUI {
  ErrorUI._();

  /// Floating snackbar for non-blocking errors.
  static void showSnack(
    BuildContext context,
    AppError error, {
    SnackBarAction? extraAction,
  }) {
    ScaffoldMessenger.of(context).hideCurrentSnackBar();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        behavior: SnackBarBehavior.floating,
        backgroundColor: Colors.white,
        elevation: 6,
        margin: const EdgeInsets.all(12),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(14),
          side: const BorderSide(color: Color(0xFFE8E2D5)),
        ),
        duration: const Duration(seconds: 4),
        content: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: const Color(0xFFE53935).withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Icon(error.icon,
                  color: const Color(0xFFE53935), size: 20),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    error.title,
                    style: const TextStyle(
                      color: Color(0xFF1A1A1A),
                      fontWeight: FontWeight.bold,
                      fontSize: 14,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    error.message,
                    style: const TextStyle(
                      color: Color(0xFF575047),
                      fontSize: 14,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
        action: extraAction ??
            (error.onRetry != null
                ? SnackBarAction(
                    label: error.actionLabel ?? 'Retry',
                    textColor: const Color(0xFFF2B705),
                    onPressed: error.onRetry!,
                  )
                : null),
      ),
    );
  }

  /// Blocking dialog for critical errors (e.g. booking failed).
  ///
  /// Named `showErrorDialog` (not `showDialog`) to avoid colliding with
  /// Flutter's top-level `showDialog`.
  static Future<void> showErrorDialog(
    BuildContext context,
    AppError error,
  ) async {
    return showDialog(
      context: context,
      barrierDismissible: true,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
        ),
        contentPadding: const EdgeInsets.fromLTRB(24, 24, 24, 12),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: const Color(0xFFE53935).withValues(alpha: 0.1),
                shape: BoxShape.circle,
              ),
              child: Icon(error.icon,
                  color: const Color(0xFFE53935), size: 36),
            ),
            const SizedBox(height: 16),
            Text(
              error.title,
              textAlign: TextAlign.center,
              style: const TextStyle(
                fontSize: 17,
                fontWeight: FontWeight.bold,
                color: Color(0xFF1A1A1A),
              ),
            ),
            const SizedBox(height: 8),
            Text(
              error.message,
              textAlign: TextAlign.center,
              style: const TextStyle(
                fontSize: 14.5,
                color: Color(0xFF575047),
                height: 1.4,
              ),
            ),
          ],
        ),
        actionsAlignment: MainAxisAlignment.center,
        actions: [
          if (error.onRetry != null)
            OutlinedButton(
              onPressed: () {
                Navigator.pop(ctx);
                error.onRetry!();
              },
              style: OutlinedButton.styleFrom(
                minimumSize: const Size(120, 44),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
              child: Text(error.actionLabel ?? 'Retry'),
            ),
          ElevatedButton(
            onPressed: () => Navigator.pop(ctx),
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFFF2B705),
              foregroundColor: const Color(0xFF0B1220),
              minimumSize: const Size(120, 44),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
            ),
            child: const Text('OK',
                style: TextStyle(fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }

  /// Inline error state for full-screen load failures.
  static Widget inline(
    AppError error, {
    EdgeInsets padding = const EdgeInsets.all(24),
  }) {
    return Center(
      child: Padding(
        padding: padding,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(error.icon, size: 48, color: const Color(0xFF575047)),
            const SizedBox(height: 16),
            Text(
              error.title,
              textAlign: TextAlign.center,
              style: const TextStyle(
                fontSize: 15,
                fontWeight: FontWeight.bold,
                color: Color(0xFF1A1A1A),
              ),
            ),
            const SizedBox(height: 6),
            Text(
              error.message,
              textAlign: TextAlign.center,
              style: const TextStyle(
                fontSize: 14,
                color: Color(0xFF575047),
              ),
            ),
            if (error.onRetry != null) ...[
              const SizedBox(height: 20),
              OutlinedButton.icon(
                onPressed: error.onRetry,
                icon: const Icon(Icons.refresh, size: 18),
                label: Text(error.actionLabel ?? 'Retry'),
                style: OutlinedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 24, vertical: 12),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
