import 'package:flutter/material.dart';

class _Palette {
  static const inkMuted = Color(0xFF8C8378);
}

/// Three-dot typing indicator with a smooth staggered animation.
///
/// Used in the chat screen, but generic enough for any "user is typing"
/// context.
class TypingDots extends StatefulWidget {
  final Color color;
  final double dotSize;

  const TypingDots({
    super.key,
    this.color = _Palette.inkMuted,
    this.dotSize = 6,
  });

  @override
  State<TypingDots> createState() => _TypingDotsState();
}

class _TypingDotsState extends State<TypingDots>
    with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    )..repeat();
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Semantics(
      label: 'Typing',
      child: AnimatedBuilder(
        animation: _ctrl,
        builder: (_, __) {
          final v = _ctrl.value;
          return Row(
            mainAxisSize: MainAxisSize.min,
            children: List.generate(3, (i) {
              final phase = (v + i * 0.2) % 1.0;
              final scale = 0.6 + 0.6 * (1 - (phase - 0.5).abs() * 2);
              return Padding(
                padding: const EdgeInsets.symmetric(horizontal: 1.5),
                child: Transform.scale(
                  scale: scale,
                  child: Container(
                    width: widget.dotSize,
                    height: widget.dotSize,
                    decoration: BoxDecoration(
                      color: widget.color,
                      shape: BoxShape.circle,
                    ),
                  ),
                ),
              );
            }),
          );
        },
      ),
    );
  }
}
