// lib/utils/roles.dart
//
// Account roles. The role picked on the start screen is only a door;
// the account's real role is profiles.role.

const _appRoles = {'customer', 'driver', 'shopper', 'merchant'};

/// Canonical role from a profile value ("Passenger" → "customer").
String normalizeRole(String? raw) {
  final r = (raw ?? '').trim().toLowerCase();
  switch (r) {
    case 'passenger':
    case 'rider':
    case 'client':
      return 'customer';
    default:
      return r;
  }
}

/// True when [role] is one of the four app roles.
bool isAppRole(String role) => _appRoles.contains(role);

/// Label key for a role, for messages like "This is a driver account".
String roleLabelKey(String role) {
  switch (role) {
    case 'driver':
      return 'role_driver';
    case 'shopper':
      return 'role_shopper';
    case 'merchant':
      return 'role_merchant';
    default:
      return 'role_customer';
  }
}
