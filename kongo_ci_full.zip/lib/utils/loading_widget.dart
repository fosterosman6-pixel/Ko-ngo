import 'package:flutter/material.dart';
import 'package:shimmer/shimmer.dart';

class _Palette {
  static const cream = Color(0xFFFAF6EE);
  static const inkMuted = Color(0xFF8C8378);
  static const divider = Color(0xFFE8E2D5);
}

/// A single shimmer placeholder block.
///
/// Use this for one loader shape. For lists of shimmer rows, use
/// [LoadingList] or [LoadingCardList].
class LoadingWidget extends StatelessWidget {
  /// Height of the placeholder. Defaults to 100.
  final double? height;

  /// Width of the placeholder. Defaults to fill available space.
  final double? width;

  /// Corner radius of the placeholder. Defaults to 12.
  final double borderRadius;

  /// Optional override for the shimmer base colour.
  final Color? baseColor;

  /// Optional override for the shimmer highlight colour.
  final Color? highlightColor;

  /// Screen-reader label. Defaults to "Loading".
  final String semanticLabel;

  const LoadingWidget({
    super.key,
    this.height = 100,
    this.width,
    this.borderRadius = 12,
    this.baseColor,
    this.highlightColor,
    this.semanticLabel = 'Loading',
  });

  @override
  Widget build(BuildContext context) {
    return Semantics(
      label: semanticLabel,
      container: true,
      child: Shimmer.fromColors(
        baseColor: baseColor ?? _Palette.divider,
        highlightColor: highlightColor ?? _Palette.cream,
        child: Container(
          height: height,
          width: width ?? double.infinity,
          decoration: BoxDecoration(
            color: _Palette.cream,
            borderRadius: BorderRadius.circular(borderRadius),
          ),
        ),
      ),
    );
  }
}

/// A vertical list of shimmer rows for list / feed loading states.
///
/// For lists of many items, prefer a static grey placeholder over shimmer
/// (each `Shimmer` widget keeps a running animation ticker).
class LoadingList extends StatelessWidget {
  final int itemCount;
  final double itemHeight;
  final double spacing;
  final EdgeInsets padding;

  const LoadingList({
    super.key,
    this.itemCount = 5,
    this.itemHeight = 72,
    this.spacing = 8,
    this.padding = const EdgeInsets.all(16),
  });

  @override
  Widget build(BuildContext context) {
    return Semantics(
      label: 'Loading list',
      container: true,
      child: ListView.separated(
        padding: padding,
        physics: const NeverScrollableScrollPhysics(),
        itemCount: itemCount,
        separatorBuilder: (_, __) => SizedBox(height: spacing),
        itemBuilder: (_, __) => LoadingWidget(
          height: itemHeight,
          borderRadius: 12,
        ),
      ),
    );
  }
}

/// A card-style skeleton with an avatar, two text lines, and a trailing
/// value chip — matches the layout of wallet / earnings tiles.
class LoadingCardList extends StatelessWidget {
  final int itemCount;
  final EdgeInsets padding;

  const LoadingCardList({
    super.key,
    this.itemCount = 5,
    this.padding = const EdgeInsets.all(16),
  });

  @override
  Widget build(BuildContext context) {
    return Semantics(
      label: 'Loading cards',
      container: true,
      child: ListView.separated(
        padding: padding,
        physics: const NeverScrollableScrollPhysics(),
        itemCount: itemCount,
        separatorBuilder: (_, __) => const SizedBox(height: 8),
        itemBuilder: (_, __) => const _CardSkeleton(),
      ),
    );
  }
}

class _CardSkeleton extends StatelessWidget {
  const _CardSkeleton();

  @override
  Widget build(BuildContext context) {
    return Shimmer.fromColors(
      baseColor: _Palette.divider,
      highlightColor: _Palette.cream,
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: _Palette.divider),
        ),
        child: Row(
          children: [
            // Avatar
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: _Palette.cream,
                borderRadius: BorderRadius.circular(10),
              ),
            ),
            const SizedBox(width: 12),
            // Two text lines
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    height: 12,
                    width: double.infinity,
                    decoration: BoxDecoration(
                      color: _Palette.cream,
                      borderRadius: BorderRadius.circular(6),
                    ),
                  ),
                  const SizedBox(height: 8),
                  Container(
                    height: 10,
                    width: 140,
                    decoration: BoxDecoration(
                      color: _Palette.cream,
                      borderRadius: BorderRadius.circular(6),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 12),
            // Value
            Container(
              height: 16,
              width: 60,
              decoration: BoxDecoration(
                color: _Palette.cream,
                borderRadius: BorderRadius.circular(6),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
