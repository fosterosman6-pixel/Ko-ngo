// lib/l10n/tr_ny.dart
//
// Chichewa for text written directly in the screens (see tr_fr.dart).
// Machine-assisted translation: have a native speaker review before release.

const Map<String, String> trNy = {
  '% OFF':
      '% KUCHOTSERA',
  '6-digit code':
      'Khodi ya manambala 6',
  'A minimum fare of R {0} is required.':
      'Mtengo wochepa wa {0} ukufunika.',
  'A profile photo is required to continue. You can skip for now, but you won\'t be able to book or accept rides.':
      'Chithunzi cha mbiri chikufunika kuti mupitirize. Mutha kudumpha pano, koma simungathe kuyitanitsa kapena kulandira maulendo.',
  'Access denied':
      'Simuloledwa',
  'Account':
      'Akaunti',
  'Account blocked':
      'Akaunti yatsekedwa',
  'Account holder':
      'Mwini akaunti',
  'Account holder name':
      'Dzina la mwini akaunti',
  'Account number':
      'Nambala ya akaunti',
  'Account type':
      'Mtundu wa akaunti',
  'Account verification':
      'Kutsimikizira akaunti',
  'Active sessions':
      'Magawo omwe alipo',
  'Add Vehicle':
      'Onjezani galimoto',
  'Add an extra layer of security':
      'Onjezani chitetezo china',
  'Add at least one contact so SOS can reach someone.':
      'Onjezani munthu mmodzi osachepera kuti SOS ifike kwa winawake.',
  'Add contact':
      'Onjezani munthu',
  'Add contacts so SOS can reach someone':
      'Onjezani anthu kuti SOS ifike kwa winawake',
  'Add emergency contacts who will be notified when you trigger SOS.':
      'Onjezani anthu adzidzidzi omwe adzadziwitsidwa mukadina SOS.',
  'Add your vehicle or bike to start accepting rides and deliveries.':
      'Onjezani galimoto kapena njinga yamoto kuti muyambe kulandira maulendo ndi zotumiza.',
  'Add, edit, or remove':
      'Onjezani, sinthani kapena chotsani',
  'Allow drivers to see your pickup location during trips.':
      'Lolani madalaivala kuwona malo okutengerani paulendo.',
  'Already added':
      'Yawonjezedwa kale',
  'Already exists':
      'Ilipo kale',
  'Already have an account? ':
      'Muli ndi akaunti kale? ',
  'Already rated':
      'Mwapereka kale maksi',
  'Already registered':
      'Mwalembetsa kale',
  'Ambulance':
      'Ambulansi',
  'Amount (R)':
      'Ndalama',
  'An admin hasn\'t reviewed your account yet. Try again later.':
      'Woyang\'anira sanawonebe akaunti yanu. Yesaninso pambuyo pake.',
  'Analytics':
      'Ziwerengero',
  'Answer every question':
      'Yankhani funso lililonse',
  'Apply Code':
      'Gwiritsani khodi',
  'Approve swap':
      'Vomerezani kusintha',
  'Are you safe?':
      'Muli otetezeka?',
  'Are you sure you want to delete "{0}"? This cannot be undone.':
      'Mukutsimikiza kuti mukufuna kuchotsa "{0}"? Izi sizingabwezedwe.',
  'At least 8 characters':
      'Zilembo 8 osachepera',
  'Authentication failed':
      'Kutsimikizira kwalephera',
  'Available balance':
      'Ndalama zomwe zilipo',
  'Available to withdraw':
      'Zitha kutulutsidwa',
  'Available: {0}':
      'Zilipo: {0}',
  'Await admin approval.':
      'Dikirani chilolezo cha woyang\'anira.',
  'Awaiting admin approval':
      'Ikudikira chilolezo cha woyang\'anira',
  'Back':
      'Bwererani',
  'Back to home':
      'Bwererani kunyumba',
  'Back to start':
      'Bwererani poyambira',
  'Bank':
      'Banki',
  'Bank details':
      'Zambiri za banki',
  'Bank details saved':
      'Zambiri za banki zasungidwa',
  'Bank name':
      'Dzina la banki',
  'Bank reference (optional)':
      'Nambala ya banki (mwakufuna)',
  'Become a driver or courier':
      'Khalani dalaivala kapena wonyamula katundu',
  'Blue Toyota Corolla — see you soon':
      'Toyota Corolla yabuluu — tikuonana posachedwa',
  'Book a ride, order food,\ngroceries or send parcels.':
      'Itanitsani ulendo, chakudya,\nzogulitsa kapena tumizani phukusi.',
  'Branch code (optional)':
      'Khodi ya nthambi (mwakufuna)',
  'Brief summary of your issue':
      'Chidule cha vuto lanu',
  'By continuing, you agree to our ':
      'Popitiriza, mukuvomereza ',
  'By continuing, you agree to our Terms of Service and Privacy Policy.':
      'Popitiriza, mukuvomereza Malamulo a Ntchito ndi Mfundo za Zachinsinsi.',
  'CANCEL — I\'M SAFE':
      'LETSANI — NDILI OTETEZEKA',
  'CLOSED':
      'YATSEKEDWA',
  'Calendar':
      'Kalendala',
  'Call':
      'Imbani',
  'Call support':
      'Imbani thandizo',
  'Call us at {0}':
      'Tiyimbireni pa {0}',
  'Call {0}':
      'Imbani {0}',
  'Call {0} manually.':
      'Imbani {0} nokha.',
  'Call {0}?':
      'Kuyimbira {0}?',
  'Camera':
      'Kamera',
  'Can\'t call':
      'Sizingatheke kuyimba',
  'Cancel':
      'Letsani',
  'Cancel ride':
      'Letsani ulendo',
  'Cancel scheduled ride?':
      'Letsani ulendo wokonzedwa?',
  'Cancel this order?':
      'Letsani oda iyi?',
  'Card (coming soon)':
      'Khadi (ikubwera)',
  'Cash deposit':
      'Kuyika ndalama',
  'Change email':
      'Sinthani imelo',
  'Change password':
      'Sinthani mawu achinsinsi',
  'Change phone number':
      'Sinthani nambala ya foni',
  'Chat':
      'Macheza',
  'Chat messages':
      'Mauthenga a macheza',
  'Check back soon':
      'Bwerani posachedwa',
  'Check back soon — we\'ll notify you when there\'s an offer.':
      'Bwerani posachedwa — tidzakudziwitsani pakakhala zotsatsa.',
  'Check your connection and try again.':
      'Onani intaneti yanu ndipo yesaninso.',
  'Check your inbox':
      'Onani bokosi lanu la imelo',
  'Choose at least Ride or Delivery.':
      'Sankhani Ulendo kapena Kutumiza osachepera.',
  'Choose what notifications you receive.':
      'Sankhani zidziwitso zomwe mumalandira.',
  'Choose your role':
      'Sankhani udindo wanu',
  'Close':
      'Tsekani',
  'Code copied':
      'Khodi yakopedwa',
  'Code not found.':
      'Khodi sinapezeke.',
  'Code: ':
      'Khodi: ',
  'Colour':
      'Mtundu',
  'Coming soon':
      'Ikubwera posachedwa',
  'Communication':
      'Kulumikizana',
  'Complete all three steps before submitting.':
      'Malizani masitepe onse atatu musanatumize.',
  'Complete your profile':
      'Malizitsani mbiri yanu',
  'Confirm':
      'Tsimikizirani',
  'Confirm Password':
      'Tsimikizirani mawu achinsinsi',
  'Confirm deletion':
      'Tsimikizirani kuchotsa',
  'Confirm new password':
      'Tsimikizirani mawu achinsinsi atsopano',
  'Connecting you to a better journey':
      'Tikukulumikizani ku ulendo wabwino',
  'Contact added':
      'Munthu wawonjezedwa',
  'Contact details are unavailable right now.':
      'Zambiri zolumikizirana sizikupezeka pano.',
  'Contact name':
      'Dzina la munthu',
  'Contact removed':
      'Munthu wachotsedwa',
  'Contact support':
      'Lumikizanani ndi thandizo',
  'Contact support for more information.':
      'Lumikizanani ndi thandizo kuti mudziwe zambiri.',
  'Continue':
      'Pitirizani',
  'Control how new ride requests interrupt you.':
      'Sankhani momwe mapempho atsopano amakusokonezerani.',
  'Control what alerts you receive while you\'re online.':
      'Sankhani zidziwitso zomwe mumalandira muli pa intaneti.',
  'Copy':
      'Kopani',
  'Corporate Accounts':
      'Maakaunti a makampani',
  'Corporate Travel':
      'Maulendo a ntchito',
  'Could not load orders':
      'Sizinatheke kutsegula ma oda',
  'Could not load preview':
      'Sizinatheke kuwonetsa',
  'Could not load restaurants':
      'Sizinatheke kutsegula malo odyera',
  'Could not load the menu':
      'Sizinatheke kutsegula menyu',
  'Could not load {0} stores':
      'Sizinatheke kutsegula masitolo a {0}',
  'Couldn\'t complete request':
      'Sizinatheke kumaliza pempho',
  'Couldn\'t dial':
      'Sizinatheke kuyimba',
  'Couldn\'t open dialer':
      'Sizinatheke kutsegula foni',
  'Couldn\'t open email':
      'Sizinatheke kutsegula imelo',
  'Couldn\'t save':
      'Sizinatheke kusunga',
  'Couldn\'t send request':
      'Sizinatheke kutumiza pempho',
  'Couldn\'t submit payout':
      'Sizinatheke kutumiza pempho la malipiro',
  'Couldn\'t validate this code. Try again.':
      'Sizinatheke kutsimikizira khodi iyi. Yesaninso.',
  'Current password':
      'Mawu achinsinsi apano',
  'Current session:':
      'Gawo lapano:',
  'Customer':
      'Kasitomala',
  'DELETE':
      'CHOTSANI',
  'DONE':
      'ZATHA',
  'Day':
      'Tsiku',
  'Delete':
      'Chotsani',
  'Delete account':
      'Chotsani akaunti',
  'Delete account?':
      'Chotsani akaunti?',
  'Delete forever':
      'Chotsani kwamuyaya',
  'Delete vehicle?':
      'Chotsani galimoto?',
  'Deliveries':
      'Zotumiza',
  'Describe what happened in detail':
      'Fotokozani mwatsatanetsatane zomwe zachitika',
  'Details':
      'Zambiri',
  'Disc':
      'Kuch.',
  'Discounts, referral bonuses, and seasonal deals.':
      'Kuchotsera, mabonasi oitana anzanu ndi zotsatsa za nyengo.',
  'Documents (upload pictures)':
      'Zikalata (kwezani zithunzi)',
  'Done':
      'Zatha',
  'Driver':
      'Dalaivala',
  'Driver Academy':
      'Sukulu ya madalaivala',
  'Driver Terms':
      'Malamulo a dalaivala',
  'Driver Terms of Service':
      'Malamulo a ntchito a dalaivala',
  'Driver assigned, arriving, and trip status.':
      'Dalaivala wapatsidwa, akufika, ndi momwe ulendo ulili.',
  'Driver: {0}':
      'Dalaivala: {0}',
  'Drivers and couriers must complete KYC documentation.':
      'Madalaivala ndi onyamula katundu ayenera kupereka zikalata za umboni.',
  'Drop-off':
      'Potsitsira',
  'Dropoff location':
      'Potsitsira',
  'EFT / Bank transfer':
      'Kutumiza ndalama ku banki',
  'Earn R50 for each referral':
      'Pezani bonasi pa munthu aliyense amene mwamuitana',
  'Earn money by driving\nor delivering.':
      'Pezani ndalama poyendetsa\nkapena kutumiza.',
  'Earn with ko!ngo':
      'Pezani ndalama ndi ko!ngo',
  'Earnings':
      'Ndalama zopezedwa',
  'Earnings & payouts':
      'Ndalama ndi malipiro',
  'Edit':
      'Sinthani',
  'Edit name':
      'Sinthani dzina',
  'Email receipts':
      'Ma risiti pa imelo',
  'Email support':
      'Tumizani imelo ku thandizo',
  'Email us at {0}':
      'Tilembereni pa {0}',
  'Emergency SOS':
      'SOS yadzidzidzi',
  'Emergency contacts':
      'Anthu adzidzidzi',
  'Emergency services and {0} have been alerted.':
      'Opulumutsa ndi {0} adziwitsidwa.',
  'Enter a code.':
      'Lowetsani khodi.',
  'Enter a valid amount':
      'Lowetsani ndalama zolondola',
  'Enter an amount greater than zero.':
      'Lowetsani ndalama zoposa ziro.',
  'Enter an amount within your available balance.':
      'Lowetsani ndalama zosapitirira zomwe muli nazo.',
  'Enter both a name and phone number.':
      'Lowetsani dzina ndi nambala ya foni.',
  'Even with sound off, the full-screen ring still appears so you won\'t miss a ride.':
      'Ngakhale phokoso litazimitsidwa, kulira kwa sikirini yonse kumawonekabe kuti musaphonye ulendo.',
  'Expense your rides':
      'Bwezeretsani ndalama za maulendo',
  'Expires: ':
      'Zitha: ',
  'Expires: {0}':
      'Zitha: {0}',
  'Family Profile':
      'Mbiri ya banja',
  'Family Profile will be available soon.':
      'Mbiri ya banja ipezeka posachedwa.',
  'Favorite Places':
      'Malo omwe mumakonda',
  'Favorite removed':
      'Malo achotsedwa',
  'Fill bank details':
      'Lembani zambiri za banki',
  'Fill in all your bank information.':
      'Lembani zambiri zonse za banki yanu.',
  'First name':
      'Dzina loyamba',
  'First name required':
      'Dzina loyamba likufunika',
  'Food delivery':
      'Kubweretsa chakudya',
  'Gallery':
      'Zithunzi',
  'Get promotions based on your trips and favourite routes.':
      'Landirani zotsatsa potengera maulendo ndi njira zomwe mumakonda.',
  'Get smart ride suggestions':
      'Landirani malingaliro a maulendo',
  'Get smart ride suggestions based on your calendar events.':
      'Landirani malingaliro a maulendo potengera kalendala yanu.',
  'Great, I\'ll be at the gate':
      'Chabwino, ndikhala pageti',
  'Have a prescription?':
      'Muli ndi kalata ya dokotala?',
  'Help us improve ko!ngo with anonymous usage data.':
      'Tithandizeni kukonza ko!ngo ndi zambiri zogwiritsira ntchito zopanda dzina.',
  'Hi! I\'m 5 minutes away':
      'Moni! Ndatsala ndi mphindi 5',
  'High':
      'Kwambiri',
  'How would you like to use KO!NGO?':
      'Mukufuna kugwiritsa ntchito KO!NGO bwanji?',
  'I\'m safe':
      'Ndili otetezeka',
  'I\'m safe — end alert':
      'Ndili otetezeka — siyitsani chenjezo',
  'ID, licence, logbook':
      'Chiphaso, layisensi, buku la galimoto',
  'If the store has already started preparing, you may be charged a fee.':
      'Ngati sitolo yayamba kale kukonza, mutha kulipiritsidwa.',
  'In an emergency, tap the button below.':
      'Pakachitika ngozi, dinani batani ili m\'munsimu.',
  'Interested? Email support@efuride.com to join the waitlist.':
      'Mukufuna? Lumikizanani ndi thandizo kuti mulowe pa mndandanda wodikira.',
  'Invalid amount':
      'Ndalama zolakwika',
  'Invalid email':
      'Imelo yolakwika',
  'Invalid number':
      'Nambala yolakwika',
  'Invalid phone':
      'Foni yolakwika',
  'Invalid phone number':
      'Nambala ya foni yolakwika',
  'Item unavailable':
      'Katundu palibe',
  'KYC documents':
      'Zikalata za umboni',
  'Keep':
      'Sungani',
  'Keep active':
      'Siyani ikugwira',
  'Keep alert active':
      'Siyani chenjezo likugwira',
  'Keep it':
      'Sungani',
  'Keep old cart':
      'Sungani dengu lakale',
  'Keep signed in':
      'Khalani olowa',
  'Kenyatta Avenue, Nairobi':
      'Avenue de la Paix, Brazzaville',
  'LIVE':
      'POMPOPOMPO',
  'Language':
      'Chilankhulo',
  'Language updated':
      'Chilankhulo chakonzedwa',
  'Legal':
      'Zamalamulo',
  'Licenses':
      'Malayisensi',
  'Limit reached':
      'Malire afika',
  'Loading cards':
      'Kutsegula makhadi',
  'Loading list':
      'Kutsegula mndandanda',
  'Location is off':
      'Malo azimitsidwa',
  'Location permission needed':
      'Chilolezo cha malo chikufunika',
  'Log in':
      'Lowani',
  'Log out':
      'Tulukani',
  'Log out?':
      'Tulukani?',
  'Low':
      'Pang\'ono',
  'Loyalty':
      'Kukhulupirika',
  'Loyalty points':
      'Mapointi a kukhulupirika',
  'Make (e.g. Toyota)':
      'Mtundu (mwachitsanzo Toyota)',
  'Make and plate number are required.':
      'Mtundu ndi nambala ya galimoto zikufunika.',
  'Make sure both passwords are identical.':
      'Onetsetsani kuti mawu achinsinsi onse awiri ali ofanana.',
  'Manage and pay for your family\'s rides':
      'Yang\'anirani ndi kulipira maulendo a banja lanu',
  'Manage business travel for your company — team members, consolidated billing, and reporting.':
      'Yang\'anirani maulendo a ntchito a kampani yanu — antchito, bilu imodzi ndi malipoti.',
  'Manage contacts':
      'Yang\'anirani anthu',
  'Manage devices signed in to your account':
      'Yang\'anirani zipangizo zolowa mu akaunti yanu',
  'Manage emergency contacts':
      'Yang\'anirani anthu adzidzidzi',
  'Manage permission settings':
      'Yang\'anirani zilolezo',
  'Manage store':
      'Yang\'anirani sitolo',
  'Manage your data and permissions':
      'Yang\'anirani zambiri zanu ndi zilolezo',
  'Mark yourself as safe?':
      'Mukufuna kunena kuti muli otetezeka?',
  'Marked safe':
      'Mwalembedwa otetezeka',
  'Medium':
      'Pakati',
  'Merchant':
      'Wamalonda',
  'Merchant · Orders':
      'Wamalonda · Ma oda',
  'Merchant · Payouts':
      'Wamalonda · Malipiro',
  'Message':
      'Uthenga',
  'Message copied':
      'Uthenga wakopedwa',
  'Messages from customers during an active trip.':
      'Mauthenga ochokera kwa makasitomala paulendo.',
  'Messages from drivers during an active trip.':
      'Mauthenga ochokera kwa madalaivala paulendo.',
  'Min {0} XAF':
      'Pang\'ono {0} XAF',
  'Missing bank details':
      'Zambiri za banki palibe',
  'Missing details':
      'Zambiri zikusowa',
  'Missing documents':
      'Zikalata zikusowa',
  'Missing information':
      'Zambiri zikusowa',
  'Missing vehicle photo':
      'Chithunzi cha galimoto chikusowa',
  'Model (e.g. Corolla)':
      'Mtundu (mwachitsanzo Corolla)',
  'Month':
      'Mwezi',
  'My Rides':
      'Maulendo anga',
  'My Vehicles':
      'Magalimoto anga',
  'My vehicles':
      'Magalimoto anga',
  'NOTIFIED':
      'WADZIWITSIDWA',
  'Name too short':
      'Dzina ndi lalifupi kwambiri',
  'Name updated':
      'Dzina lakonzedwa',
  'Navigation app':
      'Pulogalamu ya mapu',
  'Never miss a trip':
      'Musaphonye ulendo',
  'New email':
      'Imelo yatsopano',
  'New messages':
      'Mauthenga atsopano',
  'New password':
      'Mawu achinsinsi atsopano',
  'New ride requests':
      'Mapempho atsopano a maulendo',
  'New to ko!ngo':
      'Watsopano pa ko!ngo',
  'Next settlement: Friday, in 3 days':
      'Malipiro otsatira: Lachisanu, pakapita masiku 3',
  'No active conversation.':
      'Palibe macheza.',
  'No active ride':
      'Palibe ulendo womwe ukuchitika',
  'No balance to withdraw.':
      'Palibe ndalama zotulutsa.',
  'No completed trips yet':
      'Palibe maulendo omalizidwa',
  'No emergency contacts yet':
      'Palibe anthu adzidzidzi',
  'No favorite places yet':
      'Palibe malo omwe mumakonda',
  'No internet connection':
      'Palibe intaneti',
  'No items on the menu yet':
      'Palibe katundu pa menyu',
  'No items yet':
      'Palibe katundu',
  'No matches':
      'Palibe chofanana',
  'No messages yet':
      'Palibe mauthenga',
  'No payout requests':
      'Palibe mapempho a malipiro',
  'No phone number':
      'Palibe nambala ya foni',
  'No promotions right now':
      'Palibe zotsatsa pano',
  'No quiz for this module. It will be marked complete when you finish reading.':
      'Palibe mayeso a phunziroli. Lidzalembedwa kuti latha mukamaliza kuwerenga.',
  'No restaurants nearby yet':
      'Palibe malo odyera apafupi',
  'No scheduled rides':
      'Palibe maulendo okonzedwa',
  'No top-up requests':
      'Palibe mapempho owonjezera ndalama',
  'No transactions yet':
      'Palibe zochitika za ndalama',
  'No trip to rate':
      'Palibe ulendo wopereka maksi',
  'No trusted contacts yet':
      'Palibe anthu odalirika',
  'No vehicles added':
      'Palibe magalimoto owonjezedwa',
  'No {0} orders':
      'Palibe ma oda a {0}',
  'No {0} stores nearby':
      'Palibe masitolo a {0} apafupi',
  'Not signed in':
      'Simunalowe',
  'Nothing to rate':
      'Palibe chopereka maksi',
  'Nothing to withdraw':
      'Palibe chotulutsa',
  'Notifications':
      'Zidziwitso',
  'Offers & codes':
      'Zotsatsa ndi makhodi',
  'Ok!':
      'Chabwino!',
  'Onboarding progress':
      'Momwe kulembetsa kukuyendera',
  'Once you complete rides, they\'ll show up here with your net earnings.':
      'Mukamaliza maulendo, adzawonekera apa ndi ndalama zanu.',
  'One last step':
      'Gawo lomaliza',
  'Only drivers can request payouts':
      'Madalaivala okha ndi omwe angapemphe malipiro',
  'Open Settings':
      'Tsegulani zokonda',
  'Order cancelled':
      'Oda yaletsedwa',
  'Order not found':
      'Oda sinapezeke',
  'Order timeline':
      'Momwe oda ikuyendera',
  'Orders':
      'Ma oda',
  'Other ways to reach us':
      'Njira zina zotipezera',
  'Our team typically responds within a few hours.':
      'Gulu lathu nthawi zambiri limayankha pasanathe maola ochepa.',
  'Our team will respond within a few hours.':
      'Gulu lathu liyankha pasanathe maola ochepa.',
  'Owner doc':
      'Chikalata cha mwini',
  'Page not found':
      'Tsamba silinapezeke',
  'Passenger':
      'Wokwera',
  'Passkeys and verification':
      'Makiyi achinsinsi ndi kutsimikizira',
  'Password changed':
      'Mawu achinsinsi asinthidwa',
  'Password must be at least 8 characters.':
      'Mawu achinsinsi ayenera kukhala ndi zilembo 8 osachepera.',
  'Password too short':
      'Mawu achinsinsi ndi aafupi kwambiri',
  'Password, sessions, 2FA':
      'Mawu achinsinsi, magawo, kutsimikizira kawiri',
  'Passwords don\'t match':
      'Mawu achinsinsi sakufanana',
  'Payment':
      'Malipiro',
  'Payment method':
      'Njira yolipirira',
  'Payout account':
      'Akaunti yolandirira malipiro',
  'Payout confirmations':
      'Zitsimikizo za malipiro',
  'Payout failed — verify bank details and retry.':
      'Malipiro alephera — onani zambiri za banki ndipo yesaninso.',
  'Payout requested':
      'Malipiro apemphedwa',
  'Payouts':
      'Malipiro',
  'Payouts, tips, and fare credits will appear here.':
      'Malipiro, mphatso ndi ndalama zobwezedwa ziwonekera apa.',
  'Peak-hour bonuses, referral rewards, and ko!ngo news.':
      'Mabonasi a nthawi yotanganidwa, mphotho zoitana anzanu ndi nkhani za ko!ngo.',
  'Pending admin review.':
      'Ikudikira kuwonedwa ndi woyang\'anira.',
  'Permanently remove your account':
      'Chotsani akaunti yanu kwamuyaya',
  'Personalised offers':
      'Zotsatsa zanu',
  'Phone number':
      'Nambala ya foni',
  'Phone updated':
      'Foni yakonzedwa',
  'Photo from your shopper':
      'Chithunzi chochokera kwa wogula wanu',
  'Photo required':
      'Chithunzi chikufunika',
  'Photo saved':
      'Chithunzi chasungidwa',
  'Photo selected':
      'Chithunzi chasankhidwa',
  'Photo updated':
      'Chithunzi chakonzedwa',
  'Pick a future time':
      'Sankhani nthawi yamtsogolo',
  'Pick a rating':
      'Sankhani maksi',
  'Pick a service':
      'Sankhani ntchito',
  'Pick a time':
      'Sankhani nthawi',
  'Pickup':
      'Kotengera',
  'Pickup location':
      'Malo otengera',
  'Plate Number (e.g. CA123-45)':
      'Nambala ya galimoto (mwachitsanzo BZ-1234-AB)',
  'Plate: {0}':
      'Nambala: {0}',
  'Play an audible alert when a new ride comes in.':
      'Imbani chenjezo ulendo watsopano ukabwera.',
  'Please check the number and try again.':
      'Onani nambala ndipo yesaninso.',
  'Please check your details and try again.':
      'Onani zambiri zanu ndipo yesaninso.',
  'Please check your network and try again.':
      'Onani intaneti yanu ndipo yesaninso.',
  'Please choose an option for each.':
      'Sankhani yankho limodzi pa chilichonse.',
  'Please enter a valid email address.':
      'Lowetsani imelo yolondola.',
  'Please enter a valid phone number.':
      'Lowetsani nambala ya foni yolondola.',
  'Please enter at least 2 characters.':
      'Lowetsani zilembo 2 osachepera.',
  'Please enter both pickup and dropoff.':
      'Lowetsani malo otengera ndi otsitsira.',
  'Please enter your first name.':
      'Lowetsani dzina lanu loyamba.',
  'Please fill in both the subject and message.':
      'Lembani mutu ndi uthenga.',
  'Please select when you want the ride.':
      'Sankhani nthawi yomwe mukufuna ulendo.',
  'Please sign in again to continue.':
      'Lowaninso kuti mupitirize.',
  'Please sign in again.':
      'Lowaninso.',
  'Please sign in to use chat.':
      'Lowani kuti mugwiritse ntchito macheza.',
  'Please sign in.':
      'Lowani.',
  'Please try again in a moment.':
      'Yesaninso pakapita kanthawi.',
  'Please turn on GPS so we can find you.':
      'Yatsani GPS kuti tikupezeni.',
  'Please upload a photo of the vehicle.':
      'Kwezani chithunzi cha galimoto.',
  'Please upload all required documents first.':
      'Kwezani zikalata zonse zofunikira poyamba.',
  'Police':
      'Apolisi',
  'Prescription on file':
      'Kalata ya dokotala yasungidwa',
  'Price impact':
      'Zotsatira pa mtengo',
  'Priority':
      'Choyamba',
  'Privacy':
      'Zachinsinsi',
  'Privacy Policy':
      'Mfundo za zachinsinsi',
  'Profile':
      'Mbiri',
  'Profile not found':
      'Mbiri sinapezeke',
  'Promo applied! You save {0}.':
      'Zotsatsa zagwira! Mwasunga {0}.',
  'Promo code  applied!':
      'Khodi ya zotsatsa yagwira!',
  'Promo codes, offers, and savings':
      'Makhodi a zotsatsa, zotsatsa ndi kusunga',
  'Promotions':
      'Zotsatsa',
  'Promotions & Offers':
      'Zotsatsa ndi mwayi',
  'Promotions and bonuses':
      'Zotsatsa ndi mabonasi',
  'Promotions and offers':
      'Zotsatsa ndi mwayi',
  'QUICK QUIZ':
      'MAYESO AFUPI',
  'R50 credited after your friend\'s first completed ride.':
      'Bonasi idzaperekedwa mnzanu akamaliza ulendo wake woyamba.',
  'Rate trip':
      'Perekani maksi pa ulendo',
  'Rating':
      'Maksi',
  'Ref: {0}':
      'Nambala: {0}',
  'Refer & Earn':
      'Itanani ndipo pezani',
  'Refer a Friend':
      'Itanani mnzanu',
  'Refer a friend':
      'Itanani mnzanu',
  'Refresh':
      'Tsitsimutsani',
  'Rejected — please edit and resubmit.':
      'Yakanidwa — sinthani ndipo tumizaninso.',
  'Remove':
      'Chotsani',
  'Remove contact?':
      'Chotsani munthu?',
  'Remove favorite?':
      'Chotsani malo omwe mumakonda?',
  'Replace':
      'Sinthanitsani',
  'Request Payout':
      'Pemphani malipiro',
  'Request a payout and we\'ll show its status here.':
      'Pemphani malipiro ndipo tidzaonetsa momwe zilili apa.',
  'Request payout':
      'Pemphani malipiro',
  'Request timed out':
      'Nthawi ya pempho yatha',
  'Required':
      'Chofunikira',
  'Resend code':
      'Tumizaninso khodi',
  'Resend code in {0}s':
      'Tumizaninso khodi pakapita masekondi {0}',
  'Retry':
      'Yesaninso',
  'Retry payout':
      'Yesaninso malipiro',
  'Review my documents':
      'Onani zikalata zanga',
  'Ride  •  Deliver  •  Move':
      'Yendani  •  Tumizani  •  Pitani',
  'Ride not found':
      'Ulendo sunapezeke',
  'Ride removed':
      'Ulendo wachotsedwa',
  'Ride requests, chat, bonuses':
      'Mapempho a maulendo, macheza, mabonasi',
  'Ride scheduled':
      'Ulendo wakonzedwa',
  'Ride updates':
      'Nkhani za maulendo',
  'Rides':
      'Maulendo',
  'Rides you pay for and top-ups you make will appear here.':
      'Maulendo omwe mwalipira ndi ndalama zomwe mwawonjezera ziwonekera apa.',
  'Ring + push when a customer books nearby. Turn off and you won\'t see new rides.':
      'Kulira + chidziwitso kasitomala wapafupi akayitanitsa. Mukazimitsa, simudzawona maulendo atsopano.',
  'Ring sound':
      'Phokoso la kulira',
  'SHOPPER SUGGESTS':
      'WOGULA AKUPEREKA',
  'SOS ACTIVE':
      'SOS IKUGWIRA NTCHITO',
  'STEP {0}':
      'GAWO {0}',
  'Safety':
      'Chitetezo',
  'Safety center':
      'Malo a chitetezo',
  'Save':
      'Sungani',
  'Save & continue to vehicle':
      'Sungani ndi kupitiriza ku galimoto',
  'Save draft':
      'Sungani zolemba',
  'Save frequently visited places for faster booking.':
      'Sungani malo omwe mumapita kawirikawiri kuti muyitanitse msanga.',
  'Save on every ride':
      'Sungani ndalama pa ulendo uliwonse',
  'Saved bank details will be used next time.':
      'Zambiri za banki zosungidwa zidzagwiritsidwa ntchito nthawi ina.',
  'Saved places':
      'Malo osungidwa',
  'Say hi to {0} to coordinate pickup.':
      'Moni {0} kuti mukonze kutengedwa.',
  'Schedule':
      'Konzani',
  'Schedule a Ride':
      'Konzani ulendo',
  'Schedule a ride':
      'Konzani ulendo',
  'Schedule a ride for later':
      'Konzani ulendo wa mtsogolo',
  'Scheduled Rides':
      'Maulendo okonzedwa',
  'Seats / capacity':
      'Mipando / kuchuluka',
  'See your ride statistics':
      'Onani ziwerengero za maulendo anu',
  'Send an EFT to the business account, then submit this form with your reference. Admin will confirm.':
      'Tumizani ndalama ku akaunti ya bizinesi, kenako tumizani fomuyi ndi nambala yanu. Woyang\'anira adzatsimikiza.',
  'Send code':
      'Tumizani khodi',
  'Send link':
      'Tumizani ulalo',
  'Send trip summaries to your registered email.':
      'Tumizani chidule cha maulendo ku imelo yanu.',
  'Services this vehicle can serve':
      'Ntchito zomwe galimotoyi ingachite',
  'Session expired':
      'Gawo latha',
  'Settings':
      'Zokonda',
  'Settlement history':
      'Mbiri ya malipiro',
  'Setup is available from your Supabase dashboard. Coming to the app soon.':
      'Kukonza kumapezeka pa dashibodi. Kukubwera ku pulogalamu posachedwa.',
  'Share Referral Link':
      'Gawani ulalo woitanira',
  'Share it with a friend to earn R50.':
      'Gawani ndi mnzanu kuti mupeze bonasi.',
  'Share link: efuride://track/{0}':
      'Ulalo: efuride://track/{0}',
  'Share live location':
      'Gawani malo anu pompopompo',
  'Share more feedback (optional)':
      'Perekani maganizo ena (mwakufuna)',
  'Share your code and earn R50 for each friend who takes their first ride.':
      'Gawani khodi yanu ndipo pezani bonasi pa mnzanu aliyense amene wapanga ulendo wake woyamba.',
  'Shop & pick':
      'Gulani ndi kusankha',
  'Shopper':
      'Wogula',
  'Sign Out':
      'Tulukani',
  'Sign in and security':
      'Kulowa ndi chitetezo',
  'Sign out':
      'Tulukani',
  'Sign out?':
      'Tulukani?',
  'Skip':
      'Dumphani',
  'Skip for now':
      'Dumphani pano',
  'Skip item':
      'Dumphani katundu',
  'Some required details are missing. Please try again.':
      'Zambiri zina zofunikira zikusowa. Yesaninso.',
  'Something went wrong':
      'Pali vuto',
  'Something went wrong on our side. Please try again.':
      'Pali vuto kumbali yathu. Yesaninso.',
  'Sound & alerts':
      'Phokoso ndi machenjezo',
  'Standard SMS rates may apply. We\'ll never share your number.':
      'Mitengo ya SMS ingagwire ntchito. Sitidzagawana nambala yanu.',
  'Start a new cart?':
      'Yambani dengu latsopano?',
  'Start new':
      'Yambani zatsopano',
  'Stay':
      'Khalani',
  'Stay where you are. Help is on the way.':
      'Khalani komwe muli. Thandizo likubwera.',
  'Step 1 · Upload your documents':
      'Gawo 1 · Kwezani zikalata zanu',
  'Still pending':
      'Ikudikirabe',
  'Subject':
      'Mutu',
  'Submit a support ticket':
      'Tumizani pempho la thandizo',
  'Submit for admin approval':
      'Tumizani kuti woyang\'anira avomereze',
  'Submit for approval':
      'Tumizani kuti zivomerezedwe',
  'Submit payout request':
      'Tumizani pempho la malipiro',
  'Submit rating':
      'Tumizani maksi',
  'Substitution':
      'Katundu wina',
  'Substitution request':
      'Pempho losinthanitsa katundu',
  'Suggest rides ahead of your meetings and appointments.':
      'Perekani malingaliro a maulendo musanapite ku misonkhano.',
  'Support':
      'Thandizo',
  'Surname':
      'Dzina la banja',
  'Sync calendar':
      'Gwirizanitsani kalendala',
  'TAP FOR SOS':
      'DINANI KUTI SOS',
  'TEAM MEMBER SIGN-IN':
      'KULOWA KWA OGWIRA NTCHITO',
  'TRIGGER SOS':
      'YATSANI SOS',
  'TRIGGERING SOS':
      'SOS IKUYATSIDWA',
  'Take a clear selfie so drivers and passengers can recognise you during trips.':
      'Jambulani chithunzi chanu chowoneka bwino kuti madalaivala ndi okwera akudziweni paulendo.',
  'Take a selfie to continue.':
      'Jambulani chithunzi chanu kuti mupitirize.',
  'Take your photo':
      'Jambulani chithunzi chanu',
  'Tap a star to rate your customer.':
      'Dinani nyenyezi kuti mupereke maksi kwa kasitomala wanu.',
  'Tap a star to rate your driver.':
      'Dinani nyenyezi kuti mupereke maksi kwa dalaivala wanu.',
  'Tap a star to rate your experience.':
      'Dinani nyenyezi kuti mupereke maksi pa zomwe mwakumana nazo.',
  'Tap once — we handle the rest':
      'Dinani kamodzi — ife tichita zotsalazo',
  'Tell us more about your experience':
      'Tiuzeni zambiri za zomwe mwakumana nazo',
  'Terms':
      'Malamulo',
  'Terms of Service':
      'Malamulo a ntchito',
  'Thanks for rating!':
      'Zikomo popereka maksi!',
  'Thanks for riding with ko!ngo.':
      'Zikomo poyenda ndi ko!ngo.',
  'Thanks — your rating was recorded.':
      'Zikomo — maksi anu asungidwa.',
  'That number is already in your list.':
      'Nambala imeneyo ili kale pa mndandanda wanu.',
  'The place has been removed from your list.':
      'Malo achotsedwa pa mndandanda wanu.',
  'The scheduled time must be in the future.':
      'Nthawi yokonzedwa iyenera kukhala yamtsogolo.',
  'The server took too long to respond. Try again.':
      'Seva yatenga nthawi yaitali kuyankha. Yesaninso.',
  'The store has been notified.':
      'Sitolo yadziwitsidwa.',
  'There\'s no trip to chat about yet.':
      'Palibe ulendo wochezera pano.',
  'They will no longer be notified.':
      'Sadzadziwitsidwanso.',
  'They\'ll be notified when you trigger SOS.':
      'Adzadziwitsidwa mukadina SOS.',
  'This action cannot be undone.':
      'Izi sizingabwezedwe.',
  'This device':
      'Chipangizochi',
  'This email is already in use. Try signing in.':
      'Imelo iyi ikugwiritsidwa ntchito kale. Yesani kulowa.',
  'This permanently deletes your account, trip history, and saved data.':
      'Izi zichotsa kwamuyaya akaunti yanu, mbiri ya maulendo ndi zosungidwa.',
  'This place will be removed from your list.':
      'Malowa adzachotsedwa pa mndandanda wanu.',
  'This promo has expired.':
      'Zotsatsazi zatha nthawi.',
  'This promo has reached its limit.':
      'Zotsatsazi zafika malire.',
  'This promo hasn\'t started yet.':
      'Zotsatsazi sizinayambe.',
  'This promo is not active right now.':
      'Zotsatsazi sizikugwira ntchito pano.',
  'This record already exists. Try a different value.':
      'Zolembedwazi zilipo kale. Yesani china.',
  'This scheduled ride will be removed and will not be booked.':
      'Ulendo wokonzedwawu udzachotsedwa ndipo sudzayitanitsidwa.',
  'This trip may have been removed.':
      'Ulendowu mwina wachotsedwa.',
  'This will alert your emergency contacts and our support team with your location. Use only in a real emergency.':
      'Izi zidziwitsa anthu anu adzidzidzi ndi gulu lathu la thandizo komwe muli. Gwiritsani ntchito pangozi yeniyeni yokha.',
  'This will end the SOS alert. Your contacts will be told you\'re safe.':
      'Izi zithetsa chenjezo la SOS. Anthu anu adzauzidwa kuti muli otetezeka.',
  'This will open your phone\'s dialer with the number pre-filled.':
      'Izi zitsegula foni yanu ndi nambala yolembedwa kale.',
  'Ticket submitted':
      'Pempho latumizidwa',
  'Tier benefits':
      'Ubwino wa magawo',
  'Top up':
      'Onjezani ndalama',
  'Top up now':
      'Onjezani ndalama tsopano',
  'Top up your wallet':
      'Onjezani ndalama m\'chikwama chanu',
  'Top-up request sent':
      'Pempho lowonjezera ndalama latumizidwa',
  'Top-ups':
      'Zowonjezera ndalama',
  'Total':
      'Zonse',
  'Tracking services':
      'Ntchito zotsatira',
  'Transactions':
      'Zochitika za ndalama',
  'Trigger SOS':
      'Yatsani SOS',
  'Trigger SOS?':
      'Yatsani SOS?',
  'Trip complete':
      'Ulendo watha',
  'Trip completed':
      'Ulendo watha',
  'Trip completed!':
      'Ulendo watha!',
  'Try again':
      'Yesaninso',
  'Two-factor authentication':
      'Kutsimikizira kawiri',
  'Type DELETE in capitals to confirm.':
      'Lembani CHOTSANI m\'zilembo zazikulu kuti mutsimikize.',
  'Type a message...':
      'Lembani uthenga…',
  'Type a message…':
      'Lembani uthenga…',
  'Typing':
      'Akulemba',
  'Unlock exclusive benefits':
      'Pezani ubwino wapadera',
  'Update the email on your account':
      'Sinthani imelo ya akaunti yanu',
  'Update your account password':
      'Sinthani mawu achinsinsi a akaunti yanu',
  'Uploaded':
      'Zakwezedwa',
  'Usage analytics':
      'Ziwerengero za kagwiritsidwe',
  'Use your new password next time you log in.':
      'Gwiritsani mawu achinsinsi atsopano mukadzalowanso.',
  'VERIFIED':
      'YATSIMIKIZIDWA',
  'Vehicle':
      'Galimoto',
  'Vehicle class':
      'Gulu la galimoto',
  'Vehicle deleted':
      'Galimoto yachotsedwa',
  'Vehicle photo':
      'Chithunzi cha galimoto',
  'Verify & continue':
      'Tsimikizirani ndi kupitiriza',
  'View uploaded file':
      'Onani fayilo yokwezedwa',
  'View your tier and rewards':
      'Onani gawo lanu ndi mphotho',
  'Wallet':
      'Chikwama',
  'Wallet balance':
      'Ndalama za m\'chikwama',
  'We can\'t dial that phone number.':
      'Sitingathe kuyimbira nambala imeneyo.',
  'We couldn\'t find a completed ride.':
      'Sitinapeze ulendo womalizidwa.',
  'We couldn\'t reach our servers. Please try again.':
      'Sitinathe kufikira maseva athu. Yesaninso.',
  'We never sell your personal data.':
      'Sitigulitsa konse zambiri zanu.',
  'We sent a confirmation link to your new email address.':
      'Tatumiza ulalo wotsimikizira ku imelo yanu yatsopano.',
  'We use your phone for trip updates and driver contact.':
      'Timagwiritsa ntchito foni yanu pa nkhani za maulendo ndi kulumikizana ndi dalaivala.',
  'We\'ll dispatch a driver near the time.':
      'Tidzatumiza dalaivala nthawi ikayandikira.',
  'We\'ll process it within 2 business days.':
      'Tidzachita izi pasanathe masiku 2 a ntchito.',
  'Week':
      'Sabata',
  'Weekly settlement':
      'Malipiro a sabata iliyonse',
  'Weekly settlement · PawaPay':
      'Malipiro a sabata iliyonse · PawaPay',
  'Welcome aboard. Taking you to your dashboard.':
      'Takulandirani. Tikukutengerani ku dashibodi yanu.',
  'Welcome to ko!ngo Academy':
      'Takulandirani ku Sukulu ya ko!ngo',
  'What you\'ll be able to do':
      'Zomwe mudzatha kuchita',
  'When a payout is processed or rejected.':
      'Malipiro akachitika kapena kukanidwa.',
  'When you submit a top-up, you\'ll be able to track its approval here.':
      'Mukatumiza pempho lowonjezera ndalama, mudzatha kutsatira chivomerezo chake apa.',
  'Which app should open when you tap "Start trip"?':
      'Ndi pulogalamu iti yomwe itseguke mukadina "Yambani ulendo"?',
  'Work Profile':
      'Mbiri ya ntchito',
  'Wrong email or password':
      'Imelo kapena mawu achinsinsi olakwika',
  'YOU ORDERED':
      'MUNAYITANITSA',
  'Year':
      'Chaka',
  'You':
      'Inu',
  'You can save up to {0} contacts.':
      'Mutha kusunga anthu mpaka {0}.',
  'You can sign back in anytime to check your approval status.':
      'Mutha kulowanso nthawi iliyonse kuti muwone momwe chivomerezo chanu chilili.',
  'You don\'t have a balance to pay out yet.':
      'Mulibe ndalama zolipira pano.',
  'You have arrived!':
      'Mwafika!',
  'You will stop receiving new orders until you sign in again.':
      'Simudzalandira ma oda atsopano mpaka mutalowanso.',
  'You\'ll need to sign in again to book rides.':
      'Muyenera kulowanso kuti muyitanitse maulendo.',
  'You\'ll stop receiving ride requests until you sign in again.':
      'Simudzalandira mapempho a maulendo mpaka mutalowanso.',
  'You\'re all set.':
      'Zonse zakonzeka.',
  'You\'re approved!':
      'Mwavomerezedwa!',
  'You\'re not a participant in this trip.':
      'Simuli nawo paulendowu.',
  'You\'ve already rated this trip. Thanks for the feedback!':
      'Mwapereka kale maksi pa ulendowu. Zikomo chifukwa cha maganizo anu!',
  'You\'ve already used this promo.':
      'Mwagwiritsa kale zotsatsazi.',
  'Your contacts have been notified.':
      'Anthu anu adziwitsidwa.',
  'Your data export':
      'Kutulutsa zambiri zanu',
  'Your device may not have a phone app. Please dial manually.':
      'Chipangizo chanu mwina chilibe pulogalamu ya foni. Imbani nokha.',
  'Your documents have been submitted. An administrator will review them shortly — usually within a few hours.':
      'Zikalata zanu zatumizidwa. Woyang\'anira adzaziwona posachedwa — nthawi zambiri pasanathe maola ochepa.',
  'Your earnings have been added to your wallet.':
      'Ndalama zanu zawonjezedwa m\'chikwama chanu.',
  'Your emergency contacts':
      'Anthu anu adzidzidzi',
  'Your emergency contacts and our support team have been alerted with your location.':
      'Anthu anu adzidzidzi ndi gulu lathu la thandizo adziwitsidwa komwe muli.',
  'Your emergency contacts and our support team will be notified with your location.':
      'Anthu anu adzidzidzi ndi gulu lathu la thandizo adzadziwitsidwa komwe muli.',
  'Your feedback helps improve ko!ngo.':
      'Maganizo anu amathandiza kukonza ko!ngo.',
  'Your feedback helps keep ko!ngo safe.':
      'Maganizo anu amathandiza ko!ngo kukhala yotetezeka.',
  'Your name has been saved.':
      'Dzina lanu lasungidwa.',
  'Your new profile photo is live.':
      'Chithunzi chanu chatsopano chili pa intaneti.',
  'Your number stays hidden. Only the call is connected.':
      'Nambala yanu imabisika. Kuyimba kokha ndiko kumalumikizidwa.',
  'Your personal data':
      'Zambiri zanu',
  'Your phone number has been saved.':
      'Nambala yanu ya foni yasungidwa.',
  'Your photo is visible to drivers and passengers during trips.':
      'Chithunzi chanu chimawoneka kwa madalaivala ndi okwera paulendo.',
  'Your scheduled ride has been cancelled.':
      'Ulendo wanu wokonzedwa waletsedwa.',
  'Your trips will appear here':
      'Maulendo anu adzawonekera apa',
  'Your vehicle has been removed.':
      'Galimoto yanu yachotsedwa.',
  'Your vehicle will be reviewed by an admin before it becomes active.':
      'Galimoto yanu idzawonedwa ndi woyang\'anira isanayambe kugwira ntchito.',
  'e.g. 11 2nd Street, Firgrove':
      'mwachitsanzo 11 rue Mbochi, Moungali',
  'e.g. 45 Main Rd, CBD':
      'mwachitsanzo 45 avenue de la Paix, Pakati pa tauni',
  'ko!ngo Plus will be available soon.':
      'ko!ngo Plus ipezeka posachedwa.',
  'ko!ngo needs your location to find nearby drivers.':
      'ko!ngo ikufuna malo anu kuti ipeze madalaivala apafupi.',
  'typing…':
      'akulemba…',
  '{0} XAF pending':
      '{0} XAF ikudikira',
  '{0} active':
      '{0} zikugwira ntchito',
  '{0} has a suggestion':
      '{0} ali ndi lingaliro',
  '{0} hasn\'t added a phone number to their profile.':
      '{0} sanawonjezere nambala ya foni pa mbiri yake.',
  '{0} is ready to paste.':
      '{0} yakonzeka kuikidwa.',
  '{0} is typing…':
      '{0} akulemba…',
  '{0} min':
      'mph {0}',
  '{0} new':
      '{0} zatsopano',
  '{0} of {1} complete':
      '{0} mwa {1} zatha',
  '{0} of {1} modules complete':
      'Maphunziro {0} mwa {1} atha',
  '{0} points':
      'Mapointi {0}',
  '{0} points to {1}':
      'Mapointi {0} kufika {1}',
  '💬 New message from {0}':
      '💬 Uthenga watsopano kuchokera kwa {0}',
  '🚨 SOS activated':
      '🚨 SOS yayatsidwa',
  'Are you sure you want to remove "{0}"?':
      'Mukutsimikiza kuti mukufuna kuchotsa "{0}"?',
  'The price has changed':
      'Mtengo wasintha',
  'Please go back and check the price again.':
      'Chonde bwererani mukaone mtengo kachiwiri.',
  'The lowest price for this trip is {0}. Please go back and check the price again.':
      'Mtengo wotsika kwambiri wa ulendowu ndi {0}. Chonde bwererani mukaone mtengo kachiwiri.',
  'Not enough money in your wallet':
      'Ndalama sizikukwanira mu chikwama chanu',
  'Top up your wallet or choose another way to pay.':
      'Onjezani ndalama mu chikwama kapena sankhani njira ina yolipira.',
  'The picture could not be uploaded':
      'Chithunzi sichinakwezedwe',
  '{0}\n\nYou can save the product now and add the picture later.':
      '{0}\n\nMutha kusunga katunduyu tsopano ndi kuwonjezera chithunzi pambuyo pake.',
  'Save without picture':
      'Sungani popanda chithunzi',
  'OK':
      'Chabwino',
  'Choose on map':
      'Sankhani pa mapu',
  'Tap the map where you want to be picked up':
      'Dinani pa mapu pamene mukufuna kutengedwa',
  'Tap the map where you are going':
      'Dinani pa mapu pamene mukupita',
  'Pinned location':
      'Malo osankhidwa',
  'Clear':
      'Chotsani',
  'Use my current location':
      'Gwiritsani ntchito malo anga apano',
  'Street, suburb or landmark':
      'Msewu, dera kapena chizindikiro',
  'No places found. Try a street name or landmark.':
      'Palibe malo opezeka. Yesani dzina la msewu kapena chizindikiro.',
  'Current location':
      'Malo apano',
  'Closed':
      'Yatsekedwa',
  'Nearby pharmacies':
      'Ma pharmacy apafupi',
  'Stores near you':
      'Masitolo apafupi nanu',
  'Country':
      'Dziko',
  'Choose your country':
      'Sankhani dziko lanu',
  'Add a place':
      'Onjezani malo',
  'Name this place':
      'Patsani dzina malo awa',
  'Home':
      'Kunyumba',
  'Work':
      'Kuntchito',
  'e.g. Mom\'s place':
      'mwachitsanzo Kwa amayi',
  'Place':
      'Malo',
  'Drivers, shoppers and store owners use a separate ko!ngo account, with a different email address. Your customer account stays as it is.':
      'Oyendetsa, ogula ndi eni masitolo amagwiritsa ntchito akaunti ina ya ko!ngo, ndi imelo ina. Akaunti yanu ya kasitomala imakhalabe momwemo.',
  'To create it, you will be signed out of this account. You can sign back in any time.':
      'Kuti muyipange, mudzatulutsidwa mu akaunti iyi. Mutha kulowanso nthawi iliyonse.',
  'Sign out and create partner account':
      'Tulukani ndi kupanga akaunti ya mnzake',
  'Stay signed in':
      'Khalani mkati',
  'Invite friends and earn ride credit':
      'Itanani anzanu ndipo mulandire ngongole ya ulendo',
  'No offers right now':
      'Palibe zotsatsa pano',
  'New promo codes will show here.':
      'Ma code atsopano adzawonekera apa.',
  '{0}% off':
      'Kuchotsera {0}%',
  '{0} off':
      'Kuchotsera {0}',
  'Valid until {0}':
      'Ikugwira mpaka {0}',
  'Minimum {0}':
      'Pang\'ono {0}',
  'Code {0} copied. Paste it when you book or check out.':
      'Code {0} yakoperedwa. Iikeni mukamasungitsa kapena kulipira.',
  'My orders':
      'Ma oda anga',
  'Active':
      'Zomwe zikuchitika',
  'Past':
      'Zakale',
  'No active orders':
      'Palibe ma oda omwe akuchitika',
  'No past orders yet':
      'Palibe ma oda akale',
  'Order food, groceries or medicine from the Home tab.':
      'Odani chakudya, zogula kapena mankhwala kuchokera ku Kunyumba.',
  '{0} items':
      'Zinthu {0}',
  'Order placed':
      'Oda yaikidwa',
  'Being prepared':
      'Ikukonzedwa',
  'Ready for pickup':
      'Yakonzeka kutengedwa',
  'On the way':
      'Ili m\'njira',
  'Delivered':
      'Yaperekedwa',
  'Returned to office':
      'Yabwezedwa ku ofesi',
  'Cancelled':
      'Yaletsedwa',
  'Refunded':
      'Ndalama zabwezedwa',
  'Order payment':
      'Malipiro a oda',
  'Ride payment':
      'Malipiro a ulendo',
  'Refund':
      'Kubweza ndalama',
  'Bonus':
      'Bonasi',
  'Top-up':
      'Kuonjezera ndalama',
  'Amount':
      'Ndalama',
  'How did you pay?':
      'Munalipira bwanji?',
  'Bank transfer':
      'Kutumiza ku banki',
  'Payment reference (optional)':
      'Nambala ya malipiro (mwakufuna)',
  'Send top-up request':
      'Tumizani pempho',
  'Pay ko!ngo by bank transfer or cash, then send this request. Your balance goes up when ko!ngo confirms the payment.':
      'Lipirani ko!ngo ku banki kapena ndalama, kenako tumizani pempholi. Ndalama zanu zidzakwera ko!ngo ikatsimikiza.',
  'Your balance goes up when ko!ngo confirms it.':
      'Ndalama zanu zidzakwera ko!ngo ikatsimikiza.',
  'Waiting for approval':
      'Zikuyembekezera kuvomerezedwa',
  'Activity':
      'Zochitika',
  '{0} waiting for approval':
      '{0} zikuyembekezera kuvomerezedwa',
  'Add money to pay for rides and orders without cash.':
      'Onjezani ndalama kuti mulipire maulendo ndi ma oda popanda ndalama m\'manja.',
  'Payments, top-ups and refunds will show here.':
      'Malipiro, kuonjezera ndi kubweza zidzawonekera apa.',
  'Wallet & payouts':
      'Chikwama ndi malipiro',
  'Payouts on the way':
      'Malipiro omwe akubwera',
  'Trip earnings':
      'Zopeza pa ulendo',
  'Past payouts':
      'Malipiro akale',
  'Wallet {0} · Unpaid trips {1}':
      'Chikwama {0} · Maulendo osalipidwa {1}',
  'ko!ngo fee {0}% · {1} completed trips':
      'Ndalama ya ko!ngo {0}% · maulendo {1} omalizidwa',
  'Completed trips and what you earned on each will show here.':
      'Maulendo omwe mwamaliza ndi zomwe mwapeza zidzawonekera apa.',
  'Payout':
      'Malipiro',
  'Tip':
      'Mphatso',
  'Credit':
      'Ngongole',
  'Deduction':
      'Kuchotsedwa',
  'Rewards':
      'Mphoto',
  'App':
      'Pulogalamu',
  'More':
      'Zina',
  'Privacy and security':
      'Zachinsinsi ndi chitetezo',
  'Edit profile':
      'Sinthani mbiri',
  '{0} ratings':
      'Mavoti {0}',
  'Your profile':
      'Mbiri yanu',
  'Signing out…':
      'Mukutuluka…',
  'Wallet & payment':
      'Chikwama ndi malipiro',
  'Balance, top up and activity':
      'Ndalama, kuwonjezera ndi zochitika',
  'Home, work and favourites':
      'Kunyumba, kuntchito ndi zokondedwa',
  'Emergency contacts and SOS':
      'Anthu adzidzidzi ndi SOS',
  'Get help with a trip or order':
      'Pezani thandizo pa ulendo kapena oda',
  'Notifications and email receipts':
      'Zidziwitso ndi malisiti a imelo',
  'Password, email and sessions':
      'Mawu achinsinsi, imelo ndi magawo',
  'Terms and privacy policy':
      'Malamulo ndi ndondomeko yachinsinsi',
  'Pay ko!ngo with one of the methods below, then send this request. Your balance goes up when ko!ngo confirms the payment.':
      'Lipirani ko!ngo ndi njira imodzi ili m’munsimu, kenako tumizani pempholi. Ndalama zanu zidzakwera ko!ngo ikatsimikiza malipiro.',
  'Pay to: {0}':
      'Lipirani ku: {0}',
  'Contact ko!ngo support for the {0} payment details.':
      'Lumikizanani ndi thandizo la ko!ngo kuti mupeze zambiri zolipirira {0}.',
  'Transaction code (from the SMS)':
      'Nambala ya malipiro (kuchokera mu SMS)',
  'Bank transfer (EFT)':
      'Kutumiza kudzera ku banki (EFT)',
  'Customers can order now':
      'Makasitomala angathe kuyitanitsa tsopano',
  'Closed: customers cannot order':
      'Totseka: makasitomala sangathe kuyitanitsa',
  'New and active orders':
      'Maoda atsopano ndi omwe akuchitika',
  'How will you pay?':
      'Mulipira bwanji?',
  'ko!ngo wallet':
      'Chikwama cha ko!ngo',
  'Balance {0}':
      'Ndalama {0}',
  'Balance {0}: not enough for this':
      'Ndalama {0}: sizikwanira',
  'Cash':
      'Ndalama za m\u2019manja',
  'Card':
      'Khadi',
  'Visa or Mastercard':
      'Visa kapena Mastercard',
  'Not enough in your wallet':
      'Ndalama sizikwanira',
  'Top up your wallet or choose cash.':
      'Onjezani ndalama kapena sankhani ndalama za m\u2019manja.',
  'Not enough in your wallet. Top up or choose cash.':
      'Ndalama sizikwanira. Onjezani kapena sankhani ndalama za m\u2019manja.',
  'Pay the courier':
      'Lipirani wonyamula',
  'Pay the driver at the end of the trip':
      'Lipirani dalaivala kumapeto kwa ulendo',
  'Pay the courier at pickup':
      'Lipirani wonyamula potenga',
  'Pay the driver when it arrives':
      'Lipirani dalaivala akafika',
  'Paid from wallet':
      'Zalipidwa ndi chikwama',
  'Paid by card':
      'Zalipidwa ndi khadi',
  'Cash: collect from customer':
      'Ndalama: tengani kwa kasitomala',
  'Collect {0} cash from the customer':
      'Tengani {0} ndalama kwa kasitomala',
  'Paid from the customer\'s wallet. No cash to collect.':
      'Zalipidwa ndi chikwama cha kasitomala. Palibe ndalama yotenga.',
  'Paid in the app. No cash to collect.':
      'Zalipidwa mu pulogalamu. Palibe ndalama yotenga.',
  'Card not available':
      'Khadi silikupezeka',
  'Card payments are not available here yet. Please choose cash or wallet.':
      'Kulipira ndi khadi sikunapezeke pano. Sankhani ndalama kapena chikwama.',
  'New message to support':
      'Uthenga watsopano kwa thandizo',
  'What is it about?':
      'Ndi za chiyani?',
  'e.g. Payment, a trip, an order':
      'mwachitsanzo Malipiro, ulendo, oda',
  'Tell us what happened':
      'Tiuzeni zomwe zinachitika',
  'Send':
      'Tumizani',
  'Solved':
      'Zathetsedwa',
  'Answered':
      'Zayankhidwa',
  'Waiting for support':
      'Zikudikira thandizo',
  'Message support':
      'Lemberani thandizo',
  'Chat with the ko!ngo team. We reply here and you get a notification.':
      'Lankhulani ndi gulu la ko!ngo. Timayankha pano ndipo mudzalandira chidziwitso.',
  'Your conversations':
      'Zokambirana zanu',
  'No conversations yet. Tap "Message support" to start one.':
      'Palibe zokambirana. Dinani "Lemberani thandizo" kuti muyambe.',
  'WhatsApp':
      'WhatsApp',
  'ko!ngo support':
      'Thandizo la ko!ngo',
  'Our team will reply here. You will get a notification.':
      'Gulu lathu liyankha pano. Mudzalandira chidziwitso.',
  'Write a message':
      'Lembani uthenga',
  'This is a {0} account':
      'Iyi ndi akaunti ya {0}',
  'These details belong to a {0} account, so they can\'t be used on the {1} login. Please sign in from the {0} login.':
      'Zambirizi ndi za akaunti ya {0}, kotero sizingagwiritsidwe ntchito polowa ngati {1}. Chonde lowani kudzera polowa ngati {0}.',
  'Go to {0} login':
      'Pitani polowa ngati {0}',
  'Where to?':
      'Mukupita kuti?',
  'Later':
      'Pambuyo pake',
  'Add home':
      'Onjezani kunyumba',
  'You are here · {0} cars nearby':
      'Muli pano · magalimoto {0} pafupi',
  'You are here':
      'Muli pano',
  'Tap to copy the code':
      'Dinani kuti mukopere khodi',
  'Offers and promo codes':
      'Zotsatsa ndi makhodi ochotsera',
  'See what is on today':
      'Onani zomwe zilipo lero',
  'Take a photo':
      'Jambulani chithunzi',
  'Choose from gallery':
      'Sankhani mu zithunzi',
  'Send a photo':
      'Tumizani chithunzi',
  'Sedan (up to 4 seats)':
      'Sedan (mipando 4)',
  'XL (6 seats, SUV / minivan)':
      'XL (mipando 6, SUV / minivan)',
  'Van / minibus (up to 14 seats)':
      'Van / minibasi (mipando 14)',
  'Large van (cargo)':
      'Van yayikulu (katundu)',
  'Truck':
      'Galimoto yonyamula katundu',
  'Motorbike / Scooter':
      'Njinga yamoto / sikuta',
  'Money in your wallet':
      'Ndalama mu chikwama chanu',
  'You still have {0} in your ko!ngo wallet. If you delete your account now, this money is lost. Contact support first if you want it back.':
      'Muli ndi {0} mu chikwama chanu cha ko!ngo. Mukachotsa akaunti tsopano, ndalamazi zitayika. Lumikizanani ndi thandizo kaye ngati mukufuna kuzibweza.',
  'Keep my account':
      'Sungani akaunti yanga',
  'Delete anyway':
      'Chotsani ngakhale zili choncho',
  'Not yet':
      'Osati pano',
  'Finish or cancel your current trip first.':
      'Malizani kapena letsani ulendo wanu kaye.',
  'Wait until your order is delivered or cancel it first.':
      'Dikirani mpaka oda yanu ifike kapena ileketseni kaye.',
  'Your driver':
      'Dalaivala wanu',
  'Chat opens once a driver has your order.':
      'Macheza amatseguka dalaivala akatenga oda yanu.',
  'Orders waiting for a driver':
      'Maoda akudikira dalaivala',
  'Tap an order to see it and accept it.':
      'Dinani oda kuti muione ndi kuivomereza.',
  'No orders waiting right now':
      'Palibe maoda akudikira pano',
  'away':
      'kutali',
  'waiting {0} min':
      'ikudikira mphindi {0}',
  '{0} orders waiting':
      'Maoda {0} akudikira',
  'NO ANSWER':
      'PALIBE YANKHO',
  'The customer didn\'t answer. Pick the original item or leave it out.':
      'Kasitomala sanayankhe. Tengani chinthu choyambirira kapena chisiyeni.',
  'OK, continue shopping':
      'Chabwino, pitirizani kugula',
  'Your trip has started. Only the driver can end it now.':
      'Ulendo wanu wayamba. Dalaivala yekha ndiye angauthetse tsopano.',
  'Trip already started':
      'Ulendo wayamba kale',
  'This trip was cancelled.':
      'Ulendowu walephereka.',
  'See all':
      'Onani zonse',
  'View':
      'Onani',
  'Messages':
      'Mauthenga',
  'Yesterday':
      'Dzulo',
  'Trips and deliveries':
      'Maulendo ndi zotumiza',
  'Chats from your trips show here. Chats close when a trip ends and stay readable for 7 days.':
      'Macheza a maulendo anu amaonekera apa. Amatsekedwa ulendo ukatha ndipo amawerengeka masiku 7.',
  'ko!ngo Support':
      'Thandizo la ko!ngo',
  'Questions, problems, payments: we reply here.':
      'Mafunso, mavuto, malipiro: timayankha pano.',
  'Photo':
      'Chithunzi',
  'Trip ended':
      'Ulendo watha',
  'This trip has ended, so the chat is closed.':
      'Ulendowu watha, choncho macheza atsekedwa.',
  'Ride booked':
      'Ulendo wasungidwa',
  "We'll start finding a driver 10 minutes before.":
      'Tiyamba kufufuza dalaivala mphindi 10 zisanachitike.',
  "{0}. We'll start finding a driver 10 minutes before.":
      '{0}. Tiyamba kufufuza dalaivala mphindi 10 zisanachitike.',
  'Price offer withdrawn':
      'Mtengo wochotsedwa',
  "We're still looking for a driver at your price.":
      'Tikufufuzabe dalaivala pa mtengo wanu.',
  'Your driver had to cancel':
      'Dalaivala wanu waletsa',
  "We're finding you another driver.":
      'Tikukufunirani dalaivala wina.',
  'No driver found':
      'Palibe dalaivala',
  'Trip cancelled':
      'Ulendo waletsedwa',
  'No driver was free just now. Please try again.':
      'Palibe dalaivala amene anali womasuka. Yesaninso.',
  'Your driver cancelled the trip.':
      'Dalaivala wanu waletsa ulendo.',
  'ko!ngo support cancelled this trip.':
      'Thandizo la ko!ngo laletsa ulendowu.',
  'Offer declined':
      'Mwakana mtengo',
  'Pick a later time':
      'Sankhani nthawi ina pambuyo',
  'Book at least 20 minutes ahead, or choose Now.':
      'Sungitsani mphindi 20 zisanakwane, kapena sankhani Tsopano.',
  'When':
      'Liti',
  'Now':
      'Tsopano',
  "We'll start finding a driver 10 minutes before. You can cancel any time before then.":
      'Tiyamba kufufuza dalaivala mphindi 10 zisanachitike. Mungaletse nthawi iliyonse isanafike.',
  'Today {0}':
      'Lero {0}',
  'Tomorrow {0}':
      'Mawa {0}',
  '{0} km':
      '{0} km',
  'Book for later':
      'Sungitsani pambuyo',
  'Book a ride ahead — we find your driver 10 minutes before.':
      'Sungitsani ulendo msanga — timakupezerani dalaivala mphindi 10 zisanachitike.',
  'Time unknown':
      'Nthawi sidziwika',
  'Paid from your wallet':
      'Mwalipira kuchokera ku chikwama',
  'Pay the courier in cash':
      'Lipirani wotumiza ndalama',
  'Pay the driver in cash':
      'Lipirani dalaivala ndalama',
  'Parcel delivered!':
      'Katundu wafika!',
  'Thanks for sending with ko!ngo.':
      'Zikomo potumiza ndi ko!ngo.',
  'Distance':
      'Mtunda',
  'Trip ID':
      'Nambala ya ulendo',
  'Rate {0}':
      'Perekani {0} nyenyezi',
  'Rate your driver':
      'Perekani dalaivala wanu nyenyezi',
  'Another driver has already sent a price. Try again in a moment.':
      'Dalaivala wina watumiza kale mtengo. Yesaninso posachedwa.',
  'Wallet {0} · Waiting payouts {1}':
      'Chikwama {0} · Malipiro odikira {1}',
  'You owe ko!ngo {0} from cash you collected. It comes off your next earnings, or pay it at a ko!ngo office.':
      'Muli ndi ngongole ya {0} ku ko!ngo kuchokera ku ndalama zomwe munalandira. Zidzachotsedwa pa malipiro anu otsatira, kapena lipirani ku ofesi ya ko!ngo.',
  'Cash you kept':
      'Ndalama zomwe munasunga',
  'Bank or mobile money':
      'Banki kapena ndalama pa foni',
  'Account or phone number':
      'Nambala ya akaunti kapena foni',
  'ko!ngo will send it and let you know.':
      'ko!ngo idzatumiza ndi kukudziwitsani.',
  'Available {0} · Waiting payouts {1}':
      'Zilipo {0} · Malipiro odikira {1}',
  'Sales credited':
      'Malonda olowetsedwa',
  'Please sign in again':
      'Chonde lowani kachiwiri',
  'Your session ended. Sign in again to continue.':
      'Nthawi yanu yatha. Lowaninso kuti mupitirize.',
  "Couldn't get your location. Allow location for ko!ngo, or type your street above.":
      'Sitinapeze komwe muli. Lolani ko!ngo kudziwa malo, kapena lembani msewu wanu pamwambapa.',
  'Pick an address from the list, or tap "Use my current location".':
      'Sankhani adilesi pamndandanda, kapena dinani "Gwiritsani malo omwe ndili".',
  "You don't have permission for this action. Try signing in again.":
      'Mulibe chilolezo cha izi. Yesani kulowanso.',
  'code':
      'nambala',
  'Upload failed':
      'Kutumiza kwalephera',
  "Pictures can't be saved for this account yet. Please contact ko!ngo support.":
      'Zithunzi sizingasungidwe pa akaunti iyi pakadali pano. Lumikizanani ndi thandizo la ko!ngo.',
  "Pictures can't be saved for this store yet. Please contact ko!ngo support.":
      'Zithunzi sizingasungidwe pa sitolo iyi pakadali pano. Lumikizanani ndi thandizo la ko!ngo.',
  'The picture could not be saved. Please try again.':
      'Chithunzi sichinasungidwe. Yesaninso.',
  'No internet connection. Check your network and try again.':
      'Palibe intaneti. Onani netiweki yanu ndipo yesaninso.',
  'The upload took too long. Check your connection.':
      'Kutumiza kwatenga nthawi yayitali. Onani intaneti yanu.',
  'Could not load this item swap. Please try again.':
      'Sitinathe kutsegula chosinthachi. Yesaninso.',
  "You're offline. Check your data or Wi‑Fi and try again.":
      'Mulibe intaneti. Onani data kapena Wi‑Fi ndipo yesaninso.',
  'No internet. Reconnecting…':
      'Palibe intaneti. Tikulumikizanso…',
  'New order':
      'Oda yatsopano',
  'My trips':
      'Maulendo anga',
  'Every trip you took, in order':
      'Ulendo uliwonse womwe mudapanga, motsatana',
  'Booked':
      'Zosungitsidwa',
  'No trip in progress':
      'Palibe ulendo womwe ukuchitika',
  'No rides booked for later':
      'Palibe maulendo osungitsidwa',
  'No finished trips yet':
      'Palibe maulendo omalizidwa',
  'No cancelled trips':
      'Palibe maulendo oletsedwa',
  'Going to pickup':
      'Mukupita kukatenga',
  'At pickup':
      'Pomwe mukutenga',
  'Returning parcel':
      'Kubweza phukusi',
  'Completed':
      'Zatha',
  'Returned':
      'Zabwezedwa',
  'Expired':
      'Nthawi yatha',
  'Delivery':
      'Kutumiza',
  'Ride':
      'Ulendo',
  'Tap to go back to this trip':
      'Dinani kuti mubwerere ku ulendowu',
  'Today':
      'Lero',
  'Tomorrow':
      'Mawa',
  'Status':
      'Mkhalidwe',
  'Price':
      'Mtengo',
  'Booked for':
      'Zosungitsidwa pa',
  'Requested':
      'Zopemphedwa',
  'Accepted':
      'Zavomerezedwa',
  'Finished':
      'Zatha',
  'Reason':
      'Chifukwa',
  'Your rating from the customer':
      'Mavoti anu kuchokera kwa kasitomala',
  'Trip prices {0} · ko!ngo fee {1}%':
      'Mitengo ya maulendo {0} · ndalama ya ko!ngo {1}%',
  'Trip price':
      'Mtengo wa ulendo',
  'Pinned on the map':
      'Zolembedwa pa mapu',
  '{0} ({1} ratings)':
      '{0} (mavoti {1})',
  'No ratings yet':
      'Palibe mavoti pano',
  'New customer · first trip':
      'Kasitomala watsopano · ulendo woyamba',
  '1 trip with ko!ngo':
      'Ulendo 1 ndi ko!ngo',
  '{0} trips with ko!ngo':
      'Maulendo {0} ndi ko!ngo',
  'New shopping task':
      'Ntchito yatsopano yogula',
  '…':
      '…',
  'ko!ngo':
      'ko!ngo',
  'Calling…':
      'Ikuyimba…',
  'Incoming call':
      'Foni ikubwera',
  'Connecting…':
      'Ikulumikiza…',
  'Decline':
      'Kukana',
  'Answer':
      'Yankha',
  'Mute':
      'Zimitsani',
  'End':
      'Malizani',
  'Speaker':
      'Sipika',
  'KO!NGO':
      'KO!NGO',
  'x{0} · {1}':
      'x{0} · {1}',
  'Share it with a friend to earn ride credit.':
      'Gawanani ndi mnzanu kuti mupeze ngongole ya ulendo.',
  'Share your code and earn ride credit for each friend who takes their first ride.':
      'Gawanani khodi yanu ndi kupeza ngongole kwa mnzanu aliyense amene wayenda ulendo woyamba.',
  "Credit is added after your friend's first completed ride.":
      'Ngongole imawonjezedwa mnzanu atamaliza ulendo wake woyamba.',
  'ko!ngo v1.0.0':
      'ko!ngo v1.0.0',
  'Interested? Contact ko!ngo support to join the waitlist.':
      'Mukufuna? Lumikizanani ndi thandizo la ko!ngo kuti mulowe pa mndandanda wodikira.',
  'Your driver has arrived':
      'Dalaivala wanu wafika',
  'Transport':
      'Mayendedwe',
  'Marketplace':
      'Msika',
  'Book a ride in minutes · Fast & reliable':
      'Sungani ulendo mu mphindi zochepa · Wachangu ndi wodalirika',
  'Send a package · Track delivery':
      'Tumizani phukusi · Tsatirani kutumiza',
  'Search shops and categories':
      'Sakani masitolo ndi magulu',
  'Groceries':
      'Zakudya',
  'Fashion':
      'Mafashoni',
  'Electronics':
      'Zamagetsi',
  'Home & Living':
      'Nyumba ndi moyo',
  'Beauty':
      'Kukongola',
  'Butchery':
      'Nyama',
  'Bakery':
      'Buledi',
  'General Retail':
      'Malonda wamba',
  'Other':
      'Zina',
  'No categories match your search.':
      'Palibe gulu logwirizana ndi kusaka kwanu.',
  'Nearby drivers · {0} nearby':
      'Madalaivala apafupi · {0} pafupi',
  'Your new photo is saved.':
      'Chithunzi chanu chatsopano chasungidwa.',
  'Customers see this photo when you shop for them.':
      'Makasitomala amawona chithunzichi mukawagulira.',
  'Change photo':
      'Sinthani chithunzi',
  'All':
      'Zonse',
  'Restaurant':
      'Lesitilanti',
  'Pharmacy':
      'Pharmacy',
  'Marketplace: delivery requests from shops and stores':
      'Msika: zopempha zotumiza kuchokera ku masitolo',
  'No shop deliveries right now. New ones appear here and ring your phone.':
      'Palibe zotumiza za masitolo pano. Zatsopano zidzaoneka pano ndi kuyimba foni yanu.',
  'Go online to receive shop deliveries.':
      'Pitani pa intaneti kuti mulandire zotumiza za masitolo.',
  'Passed · {0}%':
      'Mwapambana · {0}%',
  'Score {0}% · 80% to pass':
      'Chiwerengero {0}% · 80% kuti mupambane',
  'Well done. This module is now complete.':
      'Zabwino. Gawo ili latha tsopano.',
  'Review the answers above and try again.':
      'Onaninso mayankho pamwambapa ndipo yesaninso.',
  'Answer {0} more':
      'Yankhani {0} zina',
  'Submit quiz':
      'Tumizani mayeso',
  'Call customer':
      'Imbirani kasitomala',
  'Recommended':
      'Zovomerezeka',
  "You're certified. Happy driving!":
      'Mwatsimikizidwa. Muyendetse bwino!',
  'Complete all required modules to go online.':
      'Malizani magawo onse ofunikira kuti mupite pa intaneti.',
  'Certificate of completion':
      'Satifiketi yomaliza',
  'Certificate locked':
      'Satifiketi yatsekedwa',
  'You have completed all required training.':
      'Mwamaliza maphunziro onse ofunikira.',
  'Complete all required modules to unlock.':
      'Malizani magawo onse ofunikira kuti mutsegule.',
  'My shops':
      'Masitolo anga',
  'Add another shop':
      'Onjezani sitolo ina',
  '{0} · Business type':
      '{0} · Mtundu wa bizinesi',
  'For {0}':
      'Kwa {0}',
  'Restock':
      'Onjezani katundu',
  'Store profile':
      'Mbiri ya sitolo',
  'Quick Actions':
      'Zochita zachangu',
  '1.0.0 · build 1':
      '1.0.0 · build 1',
  'Aa':
      'Aa',
  'day':
      'tsiku',
  'fixed price':
      'mtengo wokhazikika',
  'hour':
      'ola',
  'This week':
      'Sabata ino',
  'Ongoing':
      'Mosalekeza',
  'Just now':
      'Tsopano lomwe',
  '{0} min ago':
      'mphindi {0} zapitazo',
  '{0} h ago':
      'maola {0} apitawo',
  '{0} d ago':
      'masiku {0} apitawo',
  'Live':
      'Ikugwira ntchito',
  'Filled':
      'Yadzazidwa',
  'Not approved':
      'Sinavomerezedwe',
  'Shortlisted':
      'Wasankhidwa poyamba',
  'Hired':
      'Walembedwa ntchito',
  'Applied':
      'Wapempha',
  'Withdrawn':
      'Wachotsedwa',
  'URGENT':
      'ZOFULUMIRA',
  'Hiring Hub':
      'Malo a Ntchito',
  'Find Work':
      'Pezani ntchito',
  'My Applications':
      'Zopempha zanga',
  'My Jobs':
      'Ntchito zanga',
  'Post a Job':
      'Tumizani ntchito',
  'Search jobs, skills...':
      'Fufuzani ntchito, luso...',
  'Could not load jobs. Pull down to try again.':
      'Sitinathe kutsegula ntchito. Kokani pansi kuyesanso.',
  'No jobs here yet. Be the first to post one!':
      'Palibe ntchito pano. Mukhale woyamba kutumiza!',
  'Apply':
      'Pemphani',
  'You have not applied for any job yet.':
      'Simunapemphe ntchito iliyonse.',
  'Jobs you post will show here.':
      'Ntchito zomwe mutumiza zidzawoneka pano.',
  'applicants':
      'opempha',
  'Application sent. You will be notified.':
      'Pempho latumizidwa. Mudzauzidwa.',
  'Verified ID':
      'Chizindikiritso chotsimikizika',
  'Experience':
      'Chidziwitso',
  'Own tools':
      'Zida zake',
  'Own transport':
      'Zoyendera zake',
  'Employer':
      'Wolemba ntchito',
  '{0} workers needed':
      'Antchito {0} akufunika',
  'Description':
      'Kufotokoza',
  'Requirements':
      'Zofunikira',
  'Your application':
      'Pempho lanu',
  'Withdraw application':
      'Chotsani pempho',
  'Say a few words about yourself (optional)':
      'Lembani mawu ochepa okhudza inu (sizofunikira)',
  'Close this job?':
      'Tsekani ntchito iyi?',
  'Workers will no longer see it.':
      'Antchito sadzaiwonanso.',
  'Close job':
      'Tsekani ntchito',
  'We are checking your job. It will go live as soon as it is approved.':
      'Tikuyang\'ana ntchito yanu. Idzaoneka ikavomerezedwa.',
  'Applicants':
      'Opempha',
  'No applicants yet.':
      'Palibe opempha.',
  'Shortlist':
      'Sankhani poyamba',
  'Hire':
      'Lembani',
  'Allow location to use this.':
      'Lolani malo kuti mugwiritse ntchito izi.',
  'Could not find your location.':
      'Sitinapeze malo anu.',
  'Please enter a job title.':
      'Chonde lembani mutu wa ntchito.',
  'Please enter the pay amount.':
      'Chonde lembani ndalama zolipira.',
  'Please enter where the job is.':
      'Chonde lembani kumene kuli ntchito.',
  'This is how workers will see your job':
      'Umu ndi momwe antchito adzawonera ntchito yanu',
  'The photo could not be uploaded. Try again or post without it.':
      'Chithunzi sichinatumizidwe. Yesaninso kapena tumizani wopanda.',
  'Job sent for approval':
      'Ntchito yatumizidwa kuti ivomerezedwe',
  'We will check it and let you know as soon as it is live.':
      'Tidzayang\'ana ndikukuuzani ikayamba kuwoneka.',
  'Post a Job - Hire in minutes':
      'Tumizani ntchito - Lembani mu mphindi',
  'Fill out the details and connect with trusted workers near you':
      'Lembani zambiri ndipo mulumikizane ndi antchito odalirika pafupi ndi inu',
  'Job Title':
      'Mutu wa ntchito',
  'e.g. House Cleaner Needed':
      'mwachitsanzo: Akufunika woyeretsa nyumba',
  'Category':
      'Gulu',
  'Describe the job, what you need done, and any important details...':
      'Fotokozani ntchito, zomwe zikufunika kuchitika, ndi zina zofunika...',
  'Pay Type':
      'Mtundu wolipira',
  'Per Hour':
      'Pa ola',
  'Per Day':
      'Pa tsiku',
  'Fixed Price':
      'Mtengo wokhazikika',
  'Amount ({0})':
      'Ndalama ({0})',
  'Location':
      'Malo',
  'Where is the job?':
      'Ntchito ili kuti?',
  'Use my location':
      'Gwiritsani ntchito malo anga',
  'Duration':
      'Nthawi',
  'Workers needed':
      'Antchito ofunikira',
  'Mark as urgent':
      'Lembani kuti ndi yofulumira',
  'Upload photo':
      'Tumizani chithunzi',
  'optional':
      'sizofunikira',
  'Add a photo to help workers understand the job':
      'Onjezani chithunzi kuthandiza antchito kumvetsa ntchito',
  'Your first name will be visible to workers. Your job is checked before it goes live.':
      'Dzina lanu loyamba lidzawoneka kwa antchito. Ntchito yanu imawunikidwa isanayambe kuwoneka.',
  'Preview Job':
      'Yang\'anirani ntchito',
  'Post Job Now':
      'Tumizani ntchito tsopano',
  'Hiring Hub - Find work, hire talent':
      'Malo a Ntchito - Pezani ntchito, lembani anthu aluso',
  'Trusted workers and jobs near you':
      'Antchito odalirika ndi ntchito pafupi ndi inu',
  'See All':
      'Onani zonse',
  'Latest jobs':
      'Ntchito zaposachedwa',
  'Hiring':
      'Ntchito',
  'Rides & Delivery':
      'Kukwera ndi Kutumiza',
  'Cleaning & Home':
      'Kuyeretsa ndi Kunyumba',
  'Construction':
      'Zomanga',
  'Retail & Hospitality':
      'Kugulitsa ndi Kulandira alendo',
  'Tutoring':
      'Maphunziro owonjezera',
  'Admin & Office':
      'Utsogoleri ndi Ofesi',
  'This job is closed':
      'Ntchito iyi yatsekedwa',
  'This job is no longer taking applications.':
      'Ntchito iyi sikulandiranso zopempha.',
  'Not possible':
      'Sizotheka',
  'You cannot apply to your own job.':
      'Simungathe kupempha ntchito yanu yomwe.',
  'Your wallet needs {0} to post this job. Top up and try again.':
      'Chikwama chanu chikufuna {0} kuti mutumize ntchito iyi. Onjezerani ndalama ndipo yesaninso.',
  '+{0} · shown first for {1} days':
      '+{0} · iwoneka patsogolo masiku {1}',
  'Shown first for {0} days':
      'Iwoneka patsogolo masiku {0}',
  'Posting fee':
      'Ndalama yotumiza ntchito',
  'Urgent boost':
      'Kuyika patsogolo mwachangu',
  'Total from your wallet':
      'Chiwerengero chochotsedwa m\'chikwama chanu',
  'Your wallet':
      'Chikwama chanu',
  'If we do not approve your job, the fee is returned to your wallet.':
      'Ngati sitivomereza ntchito yanu, ndalamayo imabwezedwa m\'chikwama chanu.',
  'Top up wallet':
      'Onjezerani ndalama m\'chikwama',
  'Fresh picks, fast':
      'Zatsopano, mwachangu',
  'Our shoppers pick the best for you':
      'Ogula athu amakusankhirani zabwino',
  'Verified pharmacies':
      'Mafamu otsimikizika',
  'Cold-chain ready · pharmacist-verified':
      'Yokonzeka kuzizira · yatsimikizidwa ndi katswiri wa mankhwala',
  'Shops near you':
      'Masitolo pafupi ndi inu',
  'Get around with KO!NGO':
      'Yendani ndi KO!NGO',
  'Fast':
      'Mwachangu',
  'Safe':
      'Otetezeka',
  'Reliable':
      'Odalirika',
  'Book a Ride':
      'Pemphani kukwera',
  'Shop from a wide range':
      'Gulani zinthu zosiyanasiyana',
  'Groceries, food, pharmacy, fashion and more, brought to your door':
      'Zakudya, mankhwala, zovala ndi zina, zobweretsedwa pakhomo panu',
  'Promote my store':
      'Kwezani sitolo yanga',
  'Be listed first and get more orders':
      'Onekani koyamba ndi kulandira maoda ambiri',
  'Sponsored':
      'Yothandizidwa',
  'Sponsored until {0}':
      'Yothandizidwa mpaka {0}',
  'Your store appears first in the list with a Sponsored label.':
      'Sitolo yanu imawoneka koyamba pamndandanda ndi chizindikiro cha Yothandizidwa.',
  'Your store is now sponsored':
      'Sitolo yanu tsopano yathandizidwa',
  'Sponsored spots are not available in your country yet.':
      'Malo othandizidwa sakupezeka m\'dziko lanu panobe.',
  'How many weeks?':
      'Milungu ingati?',
  'week':
      'sabata',
  'weeks':
      'masabata',
  'Price per week':
      'Mtengo pa sabata',
  'Sponsor my store · {0}':
      'Thandizani sitolo yanga · {0}',
  'Not available':
      'Sizikupezeka',
  'This is not available right now.':
      'Izi sizikupezeka pakali pano.',
  'Earn more':
      'Pezani zambiri',
  'tasks':
      'ntchito',
  'trips':
      'maulendo',
  'task':
      'ntchito',
  'trip':
      'ulendo',
  'Done! {0} added to your wallet':
      'Mwamaliza! {0} yawonjezedwa mu chikwama chanu',
  '{0} of {1} {2} this week · Bonus {3}':
      '{0} pa {1} {2} sabata ino · Bonasi {3}',
  '{0}: +{1} for every {2} between {3} and {4}':
      '{0}: +{1} pa {2} iliyonse pakati pa {3} ndi {4}',
  'Verified by ko!ngo':
      'Yatsimikiziridwa ndi ko!ngo',
  'Verified':
      'Yatsimikiziridwa',
  'Signed in on another phone':
      'Walowa pa foni ina',
  'Your account was opened on another phone, so this one was signed out.':
      'Akaunti yanu yatsegulidwa pa foni ina, choncho foni iyi yatuluka.',
  'Recommendations':
      'Malangizo',
  'Add your vehicle':
      'Onjezani galimoto yanu',
  'You owe ko!ngo {0}':
      'Muli ndi ngongole ya {0} kwa ko!ngo',
  'Add your profile picture':
      'Onjezani chithunzi chanu',
  'Upload your papers ({0} missing)':
      'Tumizani zikalata zanu ({0} zikusowa)',
  'Your papers are being checked':
      'Zikalata zanu zikuwunikidwa',
  'Add your bank details to get paid':
      'Onjezani zambiri za banki kuti mulipidwe',
  'Finish driver academy':
      'Malizitsani sukulu ya madalaivala',
  'You are all set. Nothing to fix.':
      'Zonse zili bwino. Palibe choyenera kukonza.',
  'Tap to see what to fix':
      'Dinani kuti muwone zoyenera kukonza',
  'Quick photo check':
      'Kuyang\'ana chithunzi mwachangu',
  'Take a live selfie now so we know it is you. This takes a few seconds.':
      'Jambulani selfie tsopano kuti tidziwe kuti ndinu. Zimatenga masekondi ochepa.',
  'Your face must be clearly visible. Photos from the gallery are not accepted.':
      'Nkhope yanu iyenera kuwoneka bwino. Zithunzi za mu gallery sizilandiridwa.',
  'Take selfie':
      'Jambulani selfie',
  'Send photo':
      'Tumizani chithunzi',
  'Retake':
      'Jambulaninso',
  'Sending…':
      'Ikutumiza…',
  'Photo check sent. Thank you.':
      'Chithunzi chatumizidwa. Zikomo.',
  'Photo check needed before you go online':
      'Kuyang\'ana chithunzi kukufunika musanalowe pa intaneti',
  'Take your weekly selfie check':
      'Jambulani selfie yanu ya sabata',
  'Could not send the photo. Check your internet and try again.':
      'Sitinathe kutumiza chithunzi. Onani intaneti yanu ndikuyesanso.',
  'Could not open the camera. Allow camera access for ko!ngo in your phone settings.':
      'Sitinathe kutsegula kamera. Lolani ko!ngo kugwiritsa ntchito kamera mu zokonda za foni.',
  'Your balance is low. Top up so you can keep working without interruption.': 'Ndalama zanu ndi zochepa. Onjezerani kuti mupitirize kugwira ntchito popanda kusokonezedwa.',
  'Your balance is low ({0}). Top up.': 'Ndalama zanu ndi zochepa ({0}). Onjezerani.',
  'Daily goal': 'Cholinga cha lero',
  'Set a daily goal': 'Ikani cholinga cha lero',
  'Goal reached!': 'Cholinga chakwaniritsidwa!',
  '{0} of {1}': '{0} mwa {1}',
  'Amount you want to earn today': 'Ndalama zomwe mukufuna kupeza lero',
  'Trips': 'Maulendo',
  'Up {0}% on last week': 'Kukwera ndi {0}% kuposa sabata yatha',
  'Down {0}% on last week': 'Kutsika ndi {0}% kuposa sabata yatha',
  'Same as last week': 'Chimodzimodzi ndi sabata yatha',
  'No trips yet this week': 'Palibe maulendo sabata ino',
  'Pop-up over other apps': 'Zenera pamwamba pa mapulogalamu ena',
  'Lets a ride request open ko!ngo on top of other apps. Switch it on for ko!ngo on the page that opens.': 'Limalola pempho la ulendo kutsegula ko!ngo pamwamba pa mapulogalamu ena. Yatsani ko!ngo patsamba lomwe likutsegukalo.',
  'Open settings': 'Tsegulani zokonda',
  'Not ringing? See what happened to the last request on this phone.': 'Sikulira? Onani zomwe zinachitika ndi pempho lomaliza pa foni iyi.',
  'Check last ring': 'Onani kulira komaliza',
  'No ring has reached this phone yet.': 'Palibe kulira komwe kwafika pa foni iyi.',
  'Tip your driver':
      'Patsani dalaivala mphatso',
  'Send tip':
      'Tumizani mphatso',
  'Tip sent. Thank you!':
      'Mphatso yatumizidwa. Zikomo!',
  'Custom amount':
      'Ndalama zina',
  'Why this rating? (optional)':
      'Chifukwa chiyani chiwerengero ichi? (sikofunikira)',
  'Share receipt':
      'Gawani risiti',
  'Tip amount':
      'Ndalama za mphatso',
  'My worker profile':
      'Mbiri yanga ya wantchito',
  'Other requests':
      'Zopempha zina',
  '{0} other requests waiting. Choose one.':
      'Zopempha zina {0} zikudikira. Sankhani imodzi.',
  'Finish your current trip first':
      'Malizani ulendo wanu wapano choyamba',
  'You can accept one order at a time.':
      'Mungavomere oda imodzi nthawi imodzi.',
  'Shops':
      'Masitolo',
  'Open':
      'Yotsegula',
  'Nothing found. Try another word.':
      'Palibe chopezeka. Yesani mawu ena.',
  'Heavy traffic ahead. About {0} extra minutes.':
      'Pali magalimoto ambiri patsogolo. Pafupifupi mphindi {0} zowonjezera.',
  'Slow traffic in {0} km.':
      'Magalimoto akuyenda pang\'onopang\'ono pa km {0}.',
  'In {0} metres: {1}':
      'Pa mamita {0}: {1}',
  '{0} reported ahead.':
      '{0} yanenedwa patsogolo.',
  'Accident':
      'Ngozi',
  'Hazard on the road':
      'Ngozi pamsewu',
  'Traffic jam':
      'Magalimoto ambiri',
  'Report on the road':
      'Nenani za pamsewu',
  'Thanks, other drivers will be warned.':
      'Zikomo, oyendetsa ena adzachenjezedwa.',
  'Navigation started':
      'Chitsogozo chayamba',
  'Heavy traffic: +{0} min':
      'Magalimoto ambiri: +mphindi {0}',
  'Voice directions':
      'Malangizo a mawu',
  'Take a photo now':
      'Jambulani chithunzi tsopano',
  'Your worker profile is ready':
      'Mbiri yanu ya wantchito yakonzeka',
  'Looking for work?':
      'Mukufuna ntchito?',
  'Tap Apply on any job below.':
      'Dinani Funsira pa ntchito iliyonse pansipa.',
  'Set up your worker profile so employers can see what you do. Then tap Apply on any job.':
      'Konzani mbiri yanu ya wantchito kuti olemba ntchito aone zomwe mumachita. Kenako dinani Funsira.',
  'Set up my profile':
      'Konzani mbiri yanga',
  'No jobs here yet. Check back soon.':
      'Palibe ntchito pano panobe. Bwererani posachedwa.',
  'Need to hire someone? Post a job':
      'Mukufuna kulemba ntchito? Ikani ntchito',
  'Write what work you do, for example "Painter".':
      'Lembani ntchito yomwe mumagwira, mwachitsanzo "Wopenta".',
  'Profile saved':
      'Mbiri yasungidwa',
  'Employers see this when you apply for a job. Save it once.':
      'Olemba ntchito amawona izi mukapempha ntchito. Isungeni kamodzi kokha.',
  'What work do you do?':
      'Mumagwira ntchito yanji?',
  'e.g. Painter, Driver, Cleaner':
      'mwachitsanzo Wopenta, Woyendetsa, Woyeretsa',
  'Your skills':
      'Maluso anu',
  'e.g. painting, walls, roofs':
      'mwachitsanzo kupenta, makoma, madenga',
  'Years of experience':
      'Zaka zogwira ntchito',
  'About you':
      'Za inu',
  'Tell employers why they should choose you':
      'Auzeni olemba ntchito chifukwa chake akusankheni',
  'Save profile':
      'Sungani mbiri',
  'Add a short comment (optional)':
      'Onjezani ndemanga yaifupi (si dwa)',
  'Send rating':
      'Tumizani chiwerengero',
  'Rate the employer':
      'Perekani chiwerengero kwa wolemba ntchito',
  'Thank you for your rating':
      'Zikomo chifukwa cha chiwerengero chanu',
  'years experience':
      'zaka zogwira ntchito',
  'Rate this worker':
      'Perekani chiwerengero kwa wantchito uyu',
  'You rated {0} stars':
      'Munapereka nyenyezi {0}',
  'Voice search is not available on this phone.':
      'Kusaka ndi mawu sikupezeka pa foni iyi.',
  'Speak to search':
      'Lankhulani kuti mufufuze',
  'Split the fare':
      'Gawani ndalama ya ulendo',
  'Each person pays {0}':
      'Munthu aliyense amalipira {0}',
  'Each person pays the driver their share. Nothing is taken from your wallet for others.':
      'Aliyense amalipira dalaivala gawo lake. Palibe chimene chimachotsedwa mu chikwama chanu cha ena.',
  'Our ko!ngo ride costs {0} in total. With {1} of us, each pays {2}.':
      'Ulendo wathu wa ko!ngo umawononga {0} yonse. Tikakhala {1}, aliyense amalipira {2}.',
  'Send to friends':
      'Tumizani kwa anzanu',
  'National ID / Passport':
      'Chitupa cha dziko / Pasipoti',
  'Clear photo of the whole document':
      'Chithunzi chowoneka bwino cha chikalata chonse',
  'Selfie holding your ID':
      'Selfie mutagwira chitupa chanu',
  'Your face and the ID must both be readable':
      'Nkhope yanu ndi chitupa ziwoneke bwino',
  'Driving licence':
      'Laisensi yoyendetsa',
  'Valid, for your type of vehicle':
      'Yogwira ntchito, ya mtundu wa galimoto yanu',
  'Vehicle registration & insurance':
      'Kalembera wa galimoto ndi inshuwaransi',
  'Registration paper and valid insurance':
      'Pepala la kalembera ndi inshuwaransi yogwira ntchito',
  'Police clearance':
      'Chikalata cha apolisi',
  'Criminal record extract, not older than 6 months':
      'Chikalata cha mbiri ya upandu, chosapitirira miyezi 6',
  'Technical inspection':
      'Kuyang\'anira galimoto',
  'Roadworthy certificate':
      'Satifiketi yoti galimoto ndi yabwino',
  'If your vehicle needs one':
      'Ngati galimoto yanu ikufuna',
  'Professional driving permit (PrDP)':
      'Laisensi ya akatswiri (PrDP)',
  'For paid passenger transport':
      'Pa kunyamula anthu olipira',
  'Business registration (RCCM)':
      'Kalembera wa bizinesi (RCCM)',
  'Business registration (CIPC)':
      'Kalembera wa bizinesi (CIPC)',
  'Registration paper of your business':
      'Pepala la kalembera wa bizinesi yanu',
  'Photo of your shop front':
      'Chithunzi cha kutsogolo kwa shopu yanu',
  'Show the sign and the entrance':
      'Onetsani chikwangwani ndi khomo',
  'Tax number (NIU)':
      'Nambala ya msonkho (NIU)',
  'Tax number (SARS)':
      'Nambala ya msonkho (SARS)',
  'Adds trust, not required':
      'Imawonjezera chikhulupiriro, sikofunikira',
  'Health certificate':
      'Satifiketi ya zaumoyo',
  'Food sellers: certificate from your municipality':
      'Ogulitsa chakudya: satifiketi yochokera ku boma lanu',
  'Not accepted':
      'Sinavomerezedwe',
  'Waiting for review':
      'Ikudikira kuwunikidwa',
  'Not uploaded':
      'Sinatumizidwe',
  'Optional':
      'Sikofunikira',
  'Upload':
      'Kwezani',
  'Verify me':
      'Ndiyeseni',
  'You are verified. Customers see your badge.':
      'Mwatsimikiziridwa. Makasitomala amawona chizindikiro chanu.',
  '{0} of {1} required papers accepted. When all are accepted you get the Verified badge.':
      '{0} mwa {1} zofunikira zavomerezedwa. Zonse zikavomerezedwa mulandira chizindikiro cha Watsimikiziridwa.',
  'Your papers are private. Only ko!ngo admin can see them.':
      'Zikalata zanu ndi zachinsinsi. Ndi woyang\'anira wa ko!ngo yekha amene angaziwone.',
  'Verify my business':
      'Tsimikizani bizinesi yanga',
  'Not allowed':
      'Sikuloledwa',
  'Trip not found':
      'Ulendo sunapezeke',
  'This is not your trip':
      'Uwu si ulendo wanu',
  'User not found':
      'Wogwiritsa ntchito sanapezeke',
  'Job not found':
      'Ntchito sinapezeke',
  'Enter the customer\'s PIN to start':
      'Lowetsani PIN ya kasitomala kuti muyambe',
  'The trip has started. Only the driver can end it now.':
      'Ulendo wayamba. Dalaivala yekha ndiye angawumalize.',
  'This trip has already ended':
      'Ulendowu watha kale',
  'This job is finished and cannot be changed':
      'Ntchito iyi yatha ndipo siingasinthidwe',
  'You can book up to 30 days ahead':
      'Mutha kusungitsa mpaka masiku 30 patsogolo',
  'Pick a time at least 15 minutes from now':
      'Sankhani nthawi yosachepera mphindi 15 kuchokera pano',
  'This request is no longer available':
      'Pempholi silikupezekanso',
  'Sponsored spots are not available right now':
      'Malo othandizidwa sakupezeka pano',
  'You can rate after your trip':
      'Mutha kuwerengera mukamaliza ulendo wanu',
  'You can rate after the trip':
      'Mutha kuwerengera ulendo ukatha',
  'You can only rate after a hire on this job':
      'Mutha kuwerengera pokhapokha mutalemba ntchito pa ntchito iyi',
  'This ride is booked for later':
      'Ulendowu wasungitsidwa nthawi ina',
  'This is not your store':
      'Shopu iyi si yanu',
  'Only the driver can release this trip':
      'Dalaivala yekha ndiye angasiye ulendowu',
  'Only the driver can do this':
      'Dalaivala yekha ndiye angachite izi',
  'The price can\'t be changed':
      'Mtengo sungasinthidwe',
  'Shop deliveries have a fixed fee':
      'Kutumiza kwa shopu kuli ndi ndalama yokhazikika',
  'This job is no longer open':
      'Ntchito iyi sinatsegukenso',
  'That price offer is no longer available':
      'Mtengo umenewo sukupezekanso',
  'Cancel the order instead':
      'Letsani oda m\'malo mwake',
  'Start the trip first':
      'Yambani ulendo choyamba',
  'Start the return first':
      'Yambani kubwerera choyamba',
  'Pick up the parcel first':
      'Tengani phukusi choyamba',
  'Enter an amount':
      'Lowetsani ndalama',
  'Enter a price':
      'Lowetsani mtengo',
  'Choose 1 to 5 stars':
      'Sankhani nyenyezi 1 mpaka 5',
  'Pick 1 to 5 stars':
      'Sankhani nyenyezi 1 mpaka 5',
  'Finish or cancel your current trip first':
      'Malizani kapena letsani ulendo wanu wapano choyamba',
  'You can withdraw up to {0}':
      'Mutha kuchotsa mpaka {0}',
  'Choose between 1 and {0} weeks':
      'Sankhani pakati pa masabata 1 ndi {0}',
  'Sign-up problem on our side':
      'Vuto lolembetsa kumbali yathu',
  'Our server could not finish this. Please try again in a moment, or contact ko!ngo support.':
      'Seva yathu sinathe kumaliza izi. Yesaninso pakanthawi kapena lemberani thandizo la ko!ngo.',
  'No answer. The other person must have the trip open in the app.':
      'Palibe yankho. Munthu winayo ayenera kukhala atatsegula ulendo mu pulogalamu.',
  'Couldn\'t connect the call. Check that both phones have internet and try again.':
      'Sitinathe kulumikiza kuyimba. Onetsetsani kuti mafoni onse ali ndi intaneti ndikuyesanso.',
  'Couldn\'t start the microphone. Allow microphone access for ko!ngo in your phone settings.':
      'Sitinathe kuyatsa maikolofoni. Lolani ko!ngo kugwiritsa ntchito maikolofoni mu zokonda za foni.',
};
