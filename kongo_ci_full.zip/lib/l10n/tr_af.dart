// lib/l10n/tr_af.dart
//
// Afrikaans for text written directly in the screens (see tr_fr.dart).
// Machine-assisted translation: have a native speaker review before release.

const Map<String, String> trAf = {
  '% OFF':
      '% AFSLAG',
  '6-digit code':
      '6-syfer-kode',
  'A minimum fare of R {0} is required.':
      '\'n Minimum tarief van {0} word vereis.',
  'A profile photo is required to continue. You can skip for now, but you won\'t be able to book or accept rides.':
      '\'n Profielfoto is nodig om voort te gaan. Jy kan dit vir eers oorslaan, maar jy sal nie ritte kan bespreek of aanvaar nie.',
  'Access denied':
      'Toegang geweier',
  'Account':
      'Rekening',
  'Account blocked':
      'Rekening geblokkeer',
  'Account holder':
      'Rekeninghouer',
  'Account holder name':
      'Naam van rekeninghouer',
  'Account number':
      'Rekeningnommer',
  'Account type':
      'Rekeningtipe',
  'Account verification':
      'Rekeningverifikasie',
  'Active sessions':
      'Aktiewe sessies',
  'Add Vehicle':
      'Voeg voertuig by',
  'Add an extra layer of security':
      'Voeg \'n ekstra laag sekuriteit by',
  'Add at least one contact so SOS can reach someone.':
      'Voeg ten minste een kontak by sodat SOS iemand kan bereik.',
  'Add contact':
      'Voeg kontak by',
  'Add contacts so SOS can reach someone':
      'Voeg kontakte by sodat SOS iemand kan bereik',
  'Add emergency contacts who will be notified when you trigger SOS.':
      'Voeg noodkontakte by wat verwittig word wanneer jy SOS aktiveer.',
  'Add your vehicle or bike to start accepting rides and deliveries.':
      'Voeg jou motor of motorfiets by om ritte en aflewerings te begin aanvaar.',
  'Add, edit, or remove':
      'Voeg by, wysig of verwyder',
  'Allow drivers to see your pickup location during trips.':
      'Laat bestuurders jou oplaaiplek tydens ritte sien.',
  'Already added':
      'Reeds bygevoeg',
  'Already exists':
      'Bestaan reeds',
  'Already have an account? ':
      'Het jy reeds \'n rekening? ',
  'Already rated':
      'Reeds gegradeer',
  'Already registered':
      'Reeds geregistreer',
  'Ambulance':
      'Ambulans',
  'Amount (R)':
      'Bedrag',
  'An admin hasn\'t reviewed your account yet. Try again later.':
      '\'n Admin het jou rekening nog nie nagegaan nie. Probeer later weer.',
  'Analytics':
      'Ontleding',
  'Answer every question':
      'Beantwoord elke vraag',
  'Apply Code':
      'Pas kode toe',
  'Approve swap':
      'Keur ruil goed',
  'Are you safe?':
      'Is jy veilig?',
  'Are you sure you want to delete "{0}"? This cannot be undone.':
      'Is jy seker jy wil "{0}" uitvee? Dit kan nie ontdoen word nie.',
  'At least 8 characters':
      'Ten minste 8 karakters',
  'Authentication failed':
      'Verifikasie het misluk',
  'Available balance':
      'Beskikbare saldo',
  'Available to withdraw':
      'Beskikbaar om te onttrek',
  'Available: {0}':
      'Beskikbaar: {0}',
  'Await admin approval.':
      'Wag vir die admin se goedkeuring.',
  'Awaiting admin approval':
      'Wag op admin-goedkeuring',
  'Back':
      'Terug',
  'Back to home':
      'Terug huis toe',
  'Back to start':
      'Terug na begin',
  'Bank':
      'Bank',
  'Bank details':
      'Bankbesonderhede',
  'Bank details saved':
      'Bankbesonderhede gestoor',
  'Bank name':
      'Banknaam',
  'Bank reference (optional)':
      'Bankverwysing (opsioneel)',
  'Become a driver or courier':
      'Word \'n bestuurder of koerier',
  'Blue Toyota Corolla — see you soon':
      'Blou Toyota Corolla — sien jou nou-nou',
  'Book a ride, order food,\ngroceries or send parcels.':
      'Bespreek \'n rit, bestel kos,\nkruideniersware of stuur pakkies.',
  'Branch code (optional)':
      'Takkode (opsioneel)',
  'Brief summary of your issue':
      'Kort opsomming van jou probleem',
  'By continuing, you agree to our ':
      'Deur voort te gaan, stem jy in tot ons ',
  'By continuing, you agree to our Terms of Service and Privacy Policy.':
      'Deur voort te gaan, stem jy in tot ons Diensbepalings en Privaatheidsbeleid.',
  'CANCEL — I\'M SAFE':
      'KANSELLEER — EK IS VEILIG',
  'CLOSED':
      'GESLUIT',
  'Calendar':
      'Kalender',
  'Call':
      'Bel',
  'Call support':
      'Bel ondersteuning',
  'Call us at {0}':
      'Bel ons by {0}',
  'Call {0}':
      'Bel {0}',
  'Call {0} manually.':
      'Bel {0} self.',
  'Call {0}?':
      'Bel {0}?',
  'Camera':
      'Kamera',
  'Can\'t call':
      'Kan nie bel nie',
  'Cancel':
      'Kanselleer',
  'Cancel ride':
      'Kanselleer rit',
  'Cancel scheduled ride?':
      'Kanselleer geskeduleerde rit?',
  'Cancel this order?':
      'Kanselleer hierdie bestelling?',
  'Card (coming soon)':
      'Kaart (binnekort)',
  'Cash deposit':
      'Kontantdeposito',
  'Change email':
      'Verander e-pos',
  'Change password':
      'Verander wagwoord',
  'Change phone number':
      'Verander foonnommer',
  'Chat':
      'Klets',
  'Chat messages':
      'Kletsboodskappe',
  'Check back soon':
      'Kyk binnekort weer',
  'Check back soon — we\'ll notify you when there\'s an offer.':
      'Kyk binnekort weer — ons laat weet jou wanneer daar \'n aanbod is.',
  'Check your connection and try again.':
      'Kontroleer jou verbinding en probeer weer.',
  'Check your inbox':
      'Kyk in jou inkassie',
  'Choose at least Ride or Delivery.':
      'Kies ten minste Rit of Aflewering.',
  'Choose what notifications you receive.':
      'Kies watter kennisgewings jy ontvang.',
  'Choose your role':
      'Kies jou rol',
  'Close':
      'Maak toe',
  'Code copied':
      'Kode gekopieer',
  'Code not found.':
      'Kode nie gevind nie.',
  'Code: ':
      'Kode: ',
  'Colour':
      'Kleur',
  'Coming soon':
      'Binnekort beskikbaar',
  'Communication':
      'Kommunikasie',
  'Complete all three steps before submitting.':
      'Voltooi al drie stappe voordat jy indien.',
  'Complete your profile':
      'Voltooi jou profiel',
  'Confirm':
      'Bevestig',
  'Confirm Password':
      'Bevestig wagwoord',
  'Confirm deletion':
      'Bevestig uitvee',
  'Confirm new password':
      'Bevestig nuwe wagwoord',
  'Connecting you to a better journey':
      'Verbind jou met \'n beter reis',
  'Contact added':
      'Kontak bygevoeg',
  'Contact details are unavailable right now.':
      'Kontakbesonderhede is nou nie beskikbaar nie.',
  'Contact name':
      'Kontaknaam',
  'Contact removed':
      'Kontak verwyder',
  'Contact support':
      'Kontak ondersteuning',
  'Contact support for more information.':
      'Kontak ondersteuning vir meer inligting.',
  'Continue':
      'Gaan voort',
  'Control how new ride requests interrupt you.':
      'Bepaal hoe nuwe ritversoeke jou onderbreek.',
  'Control what alerts you receive while you\'re online.':
      'Bepaal watter waarskuwings jy ontvang terwyl jy aanlyn is.',
  'Copy':
      'Kopieer',
  'Corporate Accounts':
      'Korporatiewe rekeninge',
  'Corporate Travel':
      'Besigheidsreise',
  'Could not load orders':
      'Kon nie bestellings laai nie',
  'Could not load preview':
      'Kon nie voorskou laai nie',
  'Could not load restaurants':
      'Kon nie restaurante laai nie',
  'Could not load the menu':
      'Kon nie die spyskaart laai nie',
  'Could not load {0} stores':
      'Kon nie {0}-winkels laai nie',
  'Couldn\'t complete request':
      'Kon nie versoek voltooi nie',
  'Couldn\'t dial':
      'Kon nie skakel nie',
  'Couldn\'t open dialer':
      'Kon nie die foon oopmaak nie',
  'Couldn\'t open email':
      'Kon nie e-pos oopmaak nie',
  'Couldn\'t save':
      'Kon nie stoor nie',
  'Couldn\'t send request':
      'Kon nie versoek stuur nie',
  'Couldn\'t submit payout':
      'Kon nie uitbetaling indien nie',
  'Couldn\'t validate this code. Try again.':
      'Kon nie hierdie kode valideer nie. Probeer weer.',
  'Current password':
      'Huidige wagwoord',
  'Current session:':
      'Huidige sessie:',
  'Customer':
      'Kliënt',
  'DELETE':
      'VEE UIT',
  'DONE':
      'KLAAR',
  'Day':
      'Dag',
  'Delete':
      'Vee uit',
  'Delete account':
      'Vee rekening uit',
  'Delete account?':
      'Vee rekening uit?',
  'Delete forever':
      'Vee permanent uit',
  'Delete vehicle?':
      'Vee voertuig uit?',
  'Deliveries':
      'Aflewerings',
  'Describe what happened in detail':
      'Beskryf in detail wat gebeur het',
  'Details':
      'Besonderhede',
  'Disc':
      'Afsl.',
  'Discounts, referral bonuses, and seasonal deals.':
      'Afslag, verwysingsbonusse en seisoenaanbiedinge.',
  'Documents (upload pictures)':
      'Dokumente (laai foto\'s op)',
  'Done':
      'Klaar',
  'Driver':
      'Bestuurder',
  'Driver Academy':
      'Bestuurdersakademie',
  'Driver Terms':
      'Bestuurdersbepalings',
  'Driver Terms of Service':
      'Bestuurders se diensbepalings',
  'Driver assigned, arriving, and trip status.':
      'Bestuurder toegewys, aankoms en ritstatus.',
  'Driver: {0}':
      'Bestuurder: {0}',
  'Drivers and couriers must complete KYC documentation.':
      'Bestuurders en koeriers moet identiteitsdokumente voltooi.',
  'Drop-off':
      'Aflaaipunt',
  'Dropoff location':
      'Aflaaipunt',
  'EFT / Bank transfer':
      'Bankoorplasing',
  'Earn R50 for each referral':
      'Verdien \'n bonus vir elke verwysing',
  'Earn money by driving\nor delivering.':
      'Verdien geld deur te bestuur\nof af te lewer.',
  'Earn with ko!ngo':
      'Verdien met ko!ngo',
  'Earnings':
      'Verdienste',
  'Earnings & payouts':
      'Verdienste en uitbetalings',
  'Edit':
      'Wysig',
  'Edit name':
      'Wysig naam',
  'Email receipts':
      'E-pos-strokies',
  'Email support':
      'E-pos ondersteuning',
  'Email us at {0}':
      'E-pos ons by {0}',
  'Emergency SOS':
      'Nood-SOS',
  'Emergency contacts':
      'Noodkontakte',
  'Emergency services and {0} have been alerted.':
      'Nooddienste en {0} is gewaarsku.',
  'Enter a code.':
      'Voer \'n kode in.',
  'Enter a valid amount':
      'Voer \'n geldige bedrag in',
  'Enter an amount greater than zero.':
      'Voer \'n bedrag groter as nul in.',
  'Enter an amount within your available balance.':
      'Voer \'n bedrag binne jou beskikbare saldo in.',
  'Enter both a name and phone number.':
      'Voer \'n naam en foonnommer in.',
  'Even with sound off, the full-screen ring still appears so you won\'t miss a ride.':
      'Selfs met die klank af verskyn die volskerm-lui steeds sodat jy nie \'n rit mis nie.',
  'Expense your rides':
      'Eis jou ritte terug',
  'Expires: ':
      'Verval: ',
  'Expires: {0}':
      'Verval: {0}',
  'Family Profile':
      'Gesinsprofiel',
  'Family Profile will be available soon.':
      'Gesinsprofiel sal binnekort beskikbaar wees.',
  'Favorite Places':
      'Gunstelingplekke',
  'Favorite removed':
      'Gunsteling verwyder',
  'Fill bank details':
      'Vul bankbesonderhede in',
  'Fill in all your bank information.':
      'Vul al jou bankinligting in.',
  'First name':
      'Voornaam',
  'First name required':
      'Voornaam word vereis',
  'Food delivery':
      'Kosaflewering',
  'Gallery':
      'Galery',
  'Get promotions based on your trips and favourite routes.':
      'Kry promosies gebaseer op jou ritte en gunstelingroetes.',
  'Get smart ride suggestions':
      'Kry slim ritvoorstelle',
  'Get smart ride suggestions based on your calendar events.':
      'Kry slim ritvoorstelle gebaseer op jou kalendergebeure.',
  'Great, I\'ll be at the gate':
      'Lekker, ek sal by die hek wees',
  'Have a prescription?':
      'Het jy \'n voorskrif?',
  'Help us improve ko!ngo with anonymous usage data.':
      'Help ons om ko!ngo te verbeter met anonieme gebruiksdata.',
  'Hi! I\'m 5 minutes away':
      'Hallo! Ek is 5 minute weg',
  'High':
      'Hoog',
  'How would you like to use KO!NGO?':
      'Hoe wil jy KO!NGO gebruik?',
  'I\'m safe':
      'Ek is veilig',
  'I\'m safe — end alert':
      'Ek is veilig — beëindig waarskuwing',
  'ID, licence, logbook':
      'ID, lisensie, registrasie',
  'If the store has already started preparing, you may be charged a fee.':
      'As die winkel reeds begin voorberei het, kan \'n fooi gehef word.',
  'In an emergency, tap the button below.':
      'In \'n noodgeval, tik die knoppie hieronder.',
  'Interested? Email support@efuride.com to join the waitlist.':
      'Belangstel? Kontak ondersteuning om op die waglys te kom.',
  'Invalid amount':
      'Ongeldige bedrag',
  'Invalid email':
      'Ongeldige e-pos',
  'Invalid number':
      'Ongeldige nommer',
  'Invalid phone':
      'Ongeldige foon',
  'Invalid phone number':
      'Ongeldige foonnommer',
  'Item unavailable':
      'Item nie beskikbaar nie',
  'KYC documents':
      'Identiteitsdokumente',
  'Keep':
      'Hou',
  'Keep active':
      'Hou aktief',
  'Keep alert active':
      'Hou waarskuwing aktief',
  'Keep it':
      'Hou dit',
  'Keep old cart':
      'Hou ou mandjie',
  'Keep signed in':
      'Bly aangeteken',
  'Kenyatta Avenue, Nairobi':
      'Avenue de la Paix, Brazzaville',
  'LIVE':
      'REGSTREEKS',
  'Language':
      'Taal',
  'Language updated':
      'Taal opgedateer',
  'Legal':
      'Regsake',
  'Licenses':
      'Lisensies',
  'Limit reached':
      'Limiet bereik',
  'Loading cards':
      'Laai kaarte',
  'Loading list':
      'Laai lys',
  'Location is off':
      'Ligging is af',
  'Location permission needed':
      'Liggingtoestemming nodig',
  'Log in':
      'Teken in',
  'Log out':
      'Teken uit',
  'Log out?':
      'Teken uit?',
  'Low':
      'Laag',
  'Loyalty':
      'Lojaliteit',
  'Loyalty points':
      'Lojaliteitspunte',
  'Make (e.g. Toyota)':
      'Fabrikaat (bv. Toyota)',
  'Make and plate number are required.':
      'Fabrikaat en registrasienommer is verpligtend.',
  'Make sure both passwords are identical.':
      'Maak seker albei wagwoorde is dieselfde.',
  'Manage and pay for your family\'s rides':
      'Bestuur en betaal vir jou gesin se ritte',
  'Manage business travel for your company — team members, consolidated billing, and reporting.':
      'Bestuur besigheidsreise vir jou maatskappy — spanlede, gekonsolideerde fakturering en verslae.',
  'Manage contacts':
      'Bestuur kontakte',
  'Manage devices signed in to your account':
      'Bestuur toestelle wat by jou rekening aangeteken is',
  'Manage emergency contacts':
      'Bestuur noodkontakte',
  'Manage permission settings':
      'Bestuur toestemmings',
  'Manage store':
      'Bestuur winkel',
  'Manage your data and permissions':
      'Bestuur jou data en toestemmings',
  'Mark yourself as safe?':
      'Merk jouself as veilig?',
  'Marked safe':
      'As veilig gemerk',
  'Medium':
      'Medium',
  'Merchant':
      'Handelaar',
  'Merchant · Orders':
      'Handelaar · Bestellings',
  'Merchant · Payouts':
      'Handelaar · Uitbetalings',
  'Message':
      'Boodskap',
  'Message copied':
      'Boodskap gekopieer',
  'Messages from customers during an active trip.':
      'Boodskappe van kliënte tydens \'n rit.',
  'Messages from drivers during an active trip.':
      'Boodskappe van bestuurders tydens \'n rit.',
  'Min {0} XAF':
      'Min {0} XAF',
  'Missing bank details':
      'Bankbesonderhede ontbreek',
  'Missing details':
      'Besonderhede ontbreek',
  'Missing documents':
      'Dokumente ontbreek',
  'Missing information':
      'Inligting ontbreek',
  'Missing vehicle photo':
      'Voertuigfoto ontbreek',
  'Model (e.g. Corolla)':
      'Model (bv. Corolla)',
  'Month':
      'Maand',
  'My Rides':
      'My ritte',
  'My Vehicles':
      'My voertuie',
  'My vehicles':
      'My voertuie',
  'NOTIFIED':
      'VERWITTIG',
  'Name too short':
      'Naam te kort',
  'Name updated':
      'Naam opgedateer',
  'Navigation app':
      'Navigasietoep',
  'Never miss a trip':
      'Moet nooit \'n rit mis nie',
  'New email':
      'Nuwe e-pos',
  'New messages':
      'Nuwe boodskappe',
  'New password':
      'Nuwe wagwoord',
  'New ride requests':
      'Nuwe ritversoeke',
  'New to ko!ngo':
      'Nuut by ko!ngo',
  'Next settlement: Friday, in 3 days':
      'Volgende vereffening: Vrydag, oor 3 dae',
  'No active conversation.':
      'Geen aktiewe gesprek nie.',
  'No active ride':
      'Geen aktiewe rit nie',
  'No balance to withdraw.':
      'Geen saldo om te onttrek nie.',
  'No completed trips yet':
      'Nog geen voltooide ritte nie',
  'No emergency contacts yet':
      'Nog geen noodkontakte nie',
  'No favorite places yet':
      'Nog geen gunstelingplekke nie',
  'No internet connection':
      'Geen internetverbinding nie',
  'No items on the menu yet':
      'Nog geen items op die spyskaart nie',
  'No items yet':
      'Nog geen items nie',
  'No matches':
      'Geen ooreenstemmings nie',
  'No messages yet':
      'Nog geen boodskappe nie',
  'No payout requests':
      'Geen uitbetalingsversoeke nie',
  'No phone number':
      'Geen foonnommer nie',
  'No promotions right now':
      'Geen promosies tans nie',
  'No quiz for this module. It will be marked complete when you finish reading.':
      'Geen vasvra vir hierdie module nie. Dit word as voltooi gemerk wanneer jy klaar gelees het.',
  'No restaurants nearby yet':
      'Nog geen restaurante naby nie',
  'No scheduled rides':
      'Geen geskeduleerde ritte nie',
  'No top-up requests':
      'Geen aanvullingsversoeke nie',
  'No transactions yet':
      'Nog geen transaksies nie',
  'No trip to rate':
      'Geen rit om te gradeer nie',
  'No trusted contacts yet':
      'Nog geen vertroude kontakte nie',
  'No vehicles added':
      'Geen voertuie bygevoeg nie',
  'No {0} orders':
      'Geen {0}-bestellings nie',
  'No {0} stores nearby':
      'Geen {0}-winkels naby nie',
  'Not signed in':
      'Nie aangeteken nie',
  'Nothing to rate':
      'Niks om te gradeer nie',
  'Nothing to withdraw':
      'Niks om te onttrek nie',
  'Notifications':
      'Kennisgewings',
  'Offers & codes':
      'Aanbiedinge en kodes',
  'Ok!':
      'Reg so!',
  'Onboarding progress':
      'Registrasievordering',
  'Once you complete rides, they\'ll show up here with your net earnings.':
      'Wanneer jy ritte voltooi, verskyn hulle hier met jou netto verdienste.',
  'One last step':
      'Nog een stap',
  'Only drivers can request payouts':
      'Slegs bestuurders kan uitbetalings aanvra',
  'Open Settings':
      'Maak instellings oop',
  'Order cancelled':
      'Bestelling gekanselleer',
  'Order not found':
      'Bestelling nie gevind nie',
  'Order timeline':
      'Bestellingsverloop',
  'Orders':
      'Bestellings',
  'Other ways to reach us':
      'Ander maniere om ons te bereik',
  'Our team typically responds within a few hours.':
      'Ons span antwoord gewoonlik binne \'n paar uur.',
  'Our team will respond within a few hours.':
      'Ons span sal binne \'n paar uur antwoord.',
  'Owner doc':
      'Eienaarsdokument',
  'Page not found':
      'Bladsy nie gevind nie',
  'Passenger':
      'Passasier',
  'Passkeys and verification':
      'Wagwoordsleutels en verifikasie',
  'Password changed':
      'Wagwoord verander',
  'Password must be at least 8 characters.':
      'Wagwoord moet ten minste 8 karakters hê.',
  'Password too short':
      'Wagwoord te kort',
  'Password, sessions, 2FA':
      'Wagwoord, sessies, tweestapverifikasie',
  'Passwords don\'t match':
      'Wagwoorde stem nie ooreen nie',
  'Payment':
      'Betaling',
  'Payment method':
      'Betaalmetode',
  'Payout account':
      'Uitbetalingsrekening',
  'Payout confirmations':
      'Uitbetalingsbevestigings',
  'Payout failed — verify bank details and retry.':
      'Uitbetaling het misluk — kontroleer bankbesonderhede en probeer weer.',
  'Payout requested':
      'Uitbetaling aangevra',
  'Payouts':
      'Uitbetalings',
  'Payouts, tips, and fare credits will appear here.':
      'Uitbetalings, fooitjies en tariefkrediete sal hier verskyn.',
  'Peak-hour bonuses, referral rewards, and ko!ngo news.':
      'Spitsuurbonusse, verwysingsbelonings en ko!ngo-nuus.',
  'Pending admin review.':
      'Wag op admin-hersiening.',
  'Permanently remove your account':
      'Verwyder jou rekening permanent',
  'Personalised offers':
      'Persoonlike aanbiedinge',
  'Phone number':
      'Foonnommer',
  'Phone updated':
      'Foon opgedateer',
  'Photo from your shopper':
      'Foto van jou koper',
  'Photo required':
      'Foto vereis',
  'Photo saved':
      'Foto gestoor',
  'Photo selected':
      'Foto gekies',
  'Photo updated':
      'Foto opgedateer',
  'Pick a future time':
      'Kies \'n tyd in die toekoms',
  'Pick a rating':
      'Kies \'n gradering',
  'Pick a service':
      'Kies \'n diens',
  'Pick a time':
      'Kies \'n tyd',
  'Pickup':
      'Oplaai',
  'Pickup location':
      'Oplaaipunt',
  'Plate Number (e.g. CA123-45)':
      'Registrasienommer (bv. CA123-45)',
  'Plate: {0}':
      'Registrasie: {0}',
  'Play an audible alert when a new ride comes in.':
      'Speel \'n klankwaarskuwing wanneer \'n nuwe rit inkom.',
  'Please check the number and try again.':
      'Kontroleer die nommer en probeer weer.',
  'Please check your details and try again.':
      'Kontroleer jou besonderhede en probeer weer.',
  'Please check your network and try again.':
      'Kontroleer jou netwerk en probeer weer.',
  'Please choose an option for each.':
      'Kies \'n opsie vir elkeen.',
  'Please enter a valid email address.':
      'Voer \'n geldige e-posadres in.',
  'Please enter a valid phone number.':
      'Voer \'n geldige foonnommer in.',
  'Please enter at least 2 characters.':
      'Voer ten minste 2 karakters in.',
  'Please enter both pickup and dropoff.':
      'Voer die oplaai- en aflaaipunt in.',
  'Please enter your first name.':
      'Voer jou voornaam in.',
  'Please fill in both the subject and message.':
      'Vul die onderwerp en boodskap in.',
  'Please select when you want the ride.':
      'Kies wanneer jy die rit wil hê.',
  'Please sign in again to continue.':
      'Teken weer in om voort te gaan.',
  'Please sign in again.':
      'Teken weer in.',
  'Please sign in to use chat.':
      'Teken in om klets te gebruik.',
  'Please sign in.':
      'Teken in.',
  'Please try again in a moment.':
      'Probeer oor \'n oomblik weer.',
  'Please turn on GPS so we can find you.':
      'Skakel GPS aan sodat ons jou kan vind.',
  'Please upload a photo of the vehicle.':
      'Laai \'n foto van die voertuig op.',
  'Please upload all required documents first.':
      'Laai eers al die vereiste dokumente op.',
  'Police':
      'Polisie',
  'Prescription on file':
      'Voorskrif op lêer',
  'Price impact':
      'Invloed op prys',
  'Priority':
      'Prioriteit',
  'Privacy':
      'Privaatheid',
  'Privacy Policy':
      'Privaatheidsbeleid',
  'Profile':
      'Profiel',
  'Profile not found':
      'Profiel nie gevind nie',
  'Promo applied! You save {0}.':
      'Promosie toegepas! Jy spaar {0}.',
  'Promo code  applied!':
      'Promosiekode toegepas!',
  'Promo codes, offers, and savings':
      'Promosiekodes, aanbiedinge en besparings',
  'Promotions':
      'Promosies',
  'Promotions & Offers':
      'Promosies en aanbiedinge',
  'Promotions and bonuses':
      'Promosies en bonusse',
  'Promotions and offers':
      'Promosies en aanbiedinge',
  'QUICK QUIZ':
      'VINNIGE VASVRA',
  'R50 credited after your friend\'s first completed ride.':
      'Bonus word gekrediteer ná jou vriend se eerste voltooide rit.',
  'Rate trip':
      'Gradeer rit',
  'Rating':
      'Gradering',
  'Ref: {0}':
      'Verw.: {0}',
  'Refer & Earn':
      'Verwys en verdien',
  'Refer a Friend':
      'Verwys \'n vriend',
  'Refer a friend':
      'Verwys \'n vriend',
  'Refresh':
      'Verfris',
  'Rejected — please edit and resubmit.':
      'Afgekeur — wysig en dien weer in.',
  'Remove':
      'Verwyder',
  'Remove contact?':
      'Verwyder kontak?',
  'Remove favorite?':
      'Verwyder gunsteling?',
  'Replace':
      'Vervang',
  'Request Payout':
      'Vra uitbetaling aan',
  'Request a payout and we\'ll show its status here.':
      'Vra \'n uitbetaling aan en ons wys die status hier.',
  'Request payout':
      'Vra uitbetaling aan',
  'Request timed out':
      'Versoek het uitgetel',
  'Required':
      'Vereis',
  'Resend code':
      'Stuur kode weer',
  'Resend code in {0}s':
      'Stuur kode weer oor {0} s',
  'Retry':
      'Probeer weer',
  'Retry payout':
      'Probeer uitbetaling weer',
  'Review my documents':
      'Gaan my dokumente na',
  'Ride  •  Deliver  •  Move':
      'Ry  •  Lewer af  •  Beweeg',
  'Ride not found':
      'Rit nie gevind nie',
  'Ride removed':
      'Rit verwyder',
  'Ride requests, chat, bonuses':
      'Ritversoeke, klets, bonusse',
  'Ride scheduled':
      'Rit geskeduleer',
  'Ride updates':
      'Ritopdaterings',
  'Rides':
      'Ritte',
  'Rides you pay for and top-ups you make will appear here.':
      'Ritte waarvoor jy betaal en aanvullings wat jy maak, sal hier verskyn.',
  'Ring + push when a customer books nearby. Turn off and you won\'t see new rides.':
      'Lui + kennisgewing wanneer \'n kliënt naby bespreek. Skakel af en jy sien nie nuwe ritte nie.',
  'Ring sound':
      'Luiklank',
  'SHOPPER SUGGESTS':
      'KOPER STEL VOOR',
  'SOS ACTIVE':
      'SOS AKTIEF',
  'STEP {0}':
      'STAP {0}',
  'Safety':
      'Veiligheid',
  'Safety center':
      'Veiligheidsentrum',
  'Save':
      'Stoor',
  'Save & continue to vehicle':
      'Stoor en gaan voort na voertuig',
  'Save draft':
      'Stoor konsep',
  'Save frequently visited places for faster booking.':
      'Stoor plekke wat jy gereeld besoek om vinniger te bespreek.',
  'Save on every ride':
      'Spaar op elke rit',
  'Saved bank details will be used next time.':
      'Gestoorde bankbesonderhede sal volgende keer gebruik word.',
  'Saved places':
      'Gestoorde plekke',
  'Say hi to {0} to coordinate pickup.':
      'Groet {0} om die oplaai te reël.',
  'Schedule':
      'Skeduleer',
  'Schedule a Ride':
      'Skeduleer \'n rit',
  'Schedule a ride':
      'Skeduleer \'n rit',
  'Schedule a ride for later':
      'Skeduleer \'n rit vir later',
  'Scheduled Rides':
      'Geskeduleerde ritte',
  'Seats / capacity':
      'Sitplekke / kapasiteit',
  'See your ride statistics':
      'Sien jou ritstatistiek',
  'Send an EFT to the business account, then submit this form with your reference. Admin will confirm.':
      'Doen \'n bankoorplasing na die besigheidsrekening en dien dan hierdie vorm met jou verwysing in. Die admin sal bevestig.',
  'Send code':
      'Stuur kode',
  'Send link':
      'Stuur skakel',
  'Send trip summaries to your registered email.':
      'Stuur ritopsommings na jou geregistreerde e-pos.',
  'Services this vehicle can serve':
      'Dienste wat hierdie voertuig kan lewer',
  'Session expired':
      'Sessie het verval',
  'Settings':
      'Instellings',
  'Settlement history':
      'Vereffeningsgeskiedenis',
  'Setup is available from your Supabase dashboard. Coming to the app soon.':
      'Opstelling is op die paneelbord beskikbaar. Kom binnekort na die toep.',
  'Share Referral Link':
      'Deel verwysingskakel',
  'Share it with a friend to earn R50.':
      'Deel dit met \'n vriend om \'n bonus te verdien.',
  'Share link: efuride://track/{0}':
      'Deelskakel: efuride://track/{0}',
  'Share live location':
      'Deel regstreekse ligging',
  'Share more feedback (optional)':
      'Gee meer terugvoer (opsioneel)',
  'Share your code and earn R50 for each friend who takes their first ride.':
      'Deel jou kode en verdien \'n bonus vir elke vriend wat sy eerste rit neem.',
  'Shop & pick':
      'Koop en kies',
  'Shopper':
      'Koper',
  'Sign Out':
      'Teken uit',
  'Sign in and security':
      'Aanteken en sekuriteit',
  'Sign out':
      'Teken uit',
  'Sign out?':
      'Teken uit?',
  'Skip':
      'Slaan oor',
  'Skip for now':
      'Slaan vir eers oor',
  'Skip item':
      'Slaan item oor',
  'Some required details are missing. Please try again.':
      'Sommige vereiste besonderhede ontbreek. Probeer weer.',
  'Something went wrong':
      'Iets het skeefgeloop',
  'Something went wrong on our side. Please try again.':
      'Iets het aan ons kant skeefgeloop. Probeer weer.',
  'Sound & alerts':
      'Klank en waarskuwings',
  'Standard SMS rates may apply. We\'ll never share your number.':
      'Standaard SMS-tariewe kan geld. Ons deel nooit jou nommer nie.',
  'Start a new cart?':
      'Begin \'n nuwe mandjie?',
  'Start new':
      'Begin nuut',
  'Stay':
      'Bly',
  'Stay where you are. Help is on the way.':
      'Bly waar jy is. Hulp is op pad.',
  'Step 1 · Upload your documents':
      'Stap 1 · Laai jou dokumente op',
  'Still pending':
      'Steeds hangende',
  'Subject':
      'Onderwerp',
  'Submit a support ticket':
      'Dien \'n ondersteuningsversoek in',
  'Submit for admin approval':
      'Dien in vir admin-goedkeuring',
  'Submit for approval':
      'Dien in vir goedkeuring',
  'Submit payout request':
      'Dien uitbetalingsversoek in',
  'Submit rating':
      'Dien gradering in',
  'Substitution':
      'Plaasvervanger',
  'Substitution request':
      'Plaasvervangerversoek',
  'Suggest rides ahead of your meetings and appointments.':
      'Stel ritte voor voor jou vergaderings en afsprake.',
  'Support':
      'Ondersteuning',
  'Surname':
      'Van',
  'Sync calendar':
      'Sinkroniseer kalender',
  'TAP FOR SOS':
      'TIK VIR SOS',
  'TEAM MEMBER SIGN-IN':
      'SPANLID-AANTEKENING',
  'TRIGGER SOS':
      'AKTIVEER SOS',
  'TRIGGERING SOS':
      'SOS WORD GEAKTIVEER',
  'Take a clear selfie so drivers and passengers can recognise you during trips.':
      'Neem \'n duidelike selfie sodat bestuurders en passasiers jou tydens ritte kan herken.',
  'Take a selfie to continue.':
      'Neem \'n selfie om voort te gaan.',
  'Take your photo':
      'Neem jou foto',
  'Tap a star to rate your customer.':
      'Tik \'n ster om jou kliënt te gradeer.',
  'Tap a star to rate your driver.':
      'Tik \'n ster om jou bestuurder te gradeer.',
  'Tap a star to rate your experience.':
      'Tik \'n ster om jou ervaring te gradeer.',
  'Tap once — we handle the rest':
      'Tik een keer — ons doen die res',
  'Tell us more about your experience':
      'Vertel ons meer oor jou ervaring',
  'Terms':
      'Bepalings',
  'Terms of Service':
      'Diensbepalings',
  'Thanks for rating!':
      'Dankie vir jou gradering!',
  'Thanks for riding with ko!ngo.':
      'Dankie dat jy met ko!ngo gery het.',
  'Thanks — your rating was recorded.':
      'Dankie — jou gradering is aangeteken.',
  'That number is already in your list.':
      'Daardie nommer is reeds in jou lys.',
  'The place has been removed from your list.':
      'Die plek is uit jou lys verwyder.',
  'The scheduled time must be in the future.':
      'Die geskeduleerde tyd moet in die toekoms wees.',
  'The server took too long to respond. Try again.':
      'Die bediener het te lank geneem om te antwoord. Probeer weer.',
  'The store has been notified.':
      'Die winkel is verwittig.',
  'There\'s no trip to chat about yet.':
      'Daar is nog nie \'n rit om oor te klets nie.',
  'They will no longer be notified.':
      'Hulle sal nie meer verwittig word nie.',
  'They\'ll be notified when you trigger SOS.':
      'Hulle sal verwittig word wanneer jy SOS aktiveer.',
  'This action cannot be undone.':
      'Dit kan nie ontdoen word nie.',
  'This device':
      'Hierdie toestel',
  'This email is already in use. Try signing in.':
      'Hierdie e-pos is reeds in gebruik. Probeer aanteken.',
  'This permanently deletes your account, trip history, and saved data.':
      'Dit vee jou rekening, ritgeskiedenis en gestoorde data permanent uit.',
  'This place will be removed from your list.':
      'Hierdie plek sal uit jou lys verwyder word.',
  'This promo has expired.':
      'Hierdie promosie het verval.',
  'This promo has reached its limit.':
      'Hierdie promosie het sy limiet bereik.',
  'This promo hasn\'t started yet.':
      'Hierdie promosie het nog nie begin nie.',
  'This promo is not active right now.':
      'Hierdie promosie is nou nie aktief nie.',
  'This record already exists. Try a different value.':
      'Hierdie rekord bestaan reeds. Probeer \'n ander waarde.',
  'This scheduled ride will be removed and will not be booked.':
      'Hierdie geskeduleerde rit sal verwyder word en nie bespreek word nie.',
  'This trip may have been removed.':
      'Hierdie rit is dalk verwyder.',
  'This will alert your emergency contacts and our support team with your location. Use only in a real emergency.':
      'Dit waarsku jou noodkontakte en ons ondersteuningspan met jou ligging. Gebruik slegs in \'n regte noodgeval.',
  'This will end the SOS alert. Your contacts will be told you\'re safe.':
      'Dit beëindig die SOS-waarskuwing. Jou kontakte sal hoor jy is veilig.',
  'This will open your phone\'s dialer with the number pre-filled.':
      'Dit maak jou foon se skakelaar oop met die nommer reeds ingevul.',
  'Ticket submitted':
      'Versoek ingedien',
  'Tier benefits':
      'Vlakvoordele',
  'Top up':
      'Vul aan',
  'Top up now':
      'Vul nou aan',
  'Top up your wallet':
      'Vul jou beursie aan',
  'Top-up request sent':
      'Aanvullingsversoek gestuur',
  'Top-ups':
      'Aanvullings',
  'Total':
      'Totaal',
  'Tracking services':
      'Opsporingsdienste',
  'Transactions':
      'Transaksies',
  'Trigger SOS':
      'Aktiveer SOS',
  'Trigger SOS?':
      'Aktiveer SOS?',
  'Trip complete':
      'Rit voltooi',
  'Trip completed':
      'Rit voltooi',
  'Trip completed!':
      'Rit voltooi!',
  'Try again':
      'Probeer weer',
  'Two-factor authentication':
      'Tweestapverifikasie',
  'Type DELETE in capitals to confirm.':
      'Tik VEE UIT in hoofletters om te bevestig.',
  'Type a message...':
      'Tik \'n boodskap…',
  'Type a message…':
      'Tik \'n boodskap…',
  'Typing':
      'Tik',
  'Unlock exclusive benefits':
      'Ontsluit eksklusiewe voordele',
  'Update the email on your account':
      'Verander die e-pos op jou rekening',
  'Update your account password':
      'Verander jou rekening se wagwoord',
  'Uploaded':
      'Opgelaai',
  'Usage analytics':
      'Gebruiksontleding',
  'Use your new password next time you log in.':
      'Gebruik jou nuwe wagwoord volgende keer as jy aanteken.',
  'VERIFIED':
      'GEVERIFIEER',
  'Vehicle':
      'Voertuig',
  'Vehicle class':
      'Voertuigklas',
  'Vehicle deleted':
      'Voertuig uitgevee',
  'Vehicle photo':
      'Voertuigfoto',
  'Verify & continue':
      'Verifieer en gaan voort',
  'View uploaded file':
      'Sien opgelaaide lêer',
  'View your tier and rewards':
      'Sien jou vlak en belonings',
  'Wallet':
      'Beursie',
  'Wallet balance':
      'Beursiesaldo',
  'We can\'t dial that phone number.':
      'Ons kan nie daardie nommer skakel nie.',
  'We couldn\'t find a completed ride.':
      'Ons kon nie \'n voltooide rit vind nie.',
  'We couldn\'t reach our servers. Please try again.':
      'Ons kon nie ons bedieners bereik nie. Probeer weer.',
  'We never sell your personal data.':
      'Ons verkoop nooit jou persoonlike data nie.',
  'We sent a confirmation link to your new email address.':
      'Ons het \'n bevestigingskakel na jou nuwe e-posadres gestuur.',
  'We use your phone for trip updates and driver contact.':
      'Ons gebruik jou foon vir ritopdaterings en kontak met die bestuurder.',
  'We\'ll dispatch a driver near the time.':
      'Ons stuur \'n bestuurder naby die tyd.',
  'We\'ll process it within 2 business days.':
      'Ons verwerk dit binne 2 werksdae.',
  'Week':
      'Week',
  'Weekly settlement':
      'Weeklikse vereffening',
  'Weekly settlement · PawaPay':
      'Weeklikse vereffening · PawaPay',
  'Welcome aboard. Taking you to your dashboard.':
      'Welkom aan boord. Ons neem jou na jou paneelbord.',
  'Welcome to ko!ngo Academy':
      'Welkom by die ko!ngo-akademie',
  'What you\'ll be able to do':
      'Wat jy sal kan doen',
  'When a payout is processed or rejected.':
      'Wanneer \'n uitbetaling verwerk of afgekeur word.',
  'When you submit a top-up, you\'ll be able to track its approval here.':
      'Wanneer jy \'n aanvulling indien, kan jy die goedkeuring hier volg.',
  'Which app should open when you tap "Start trip"?':
      'Watter toep moet oopmaak wanneer jy "Begin rit" tik?',
  'Work Profile':
      'Werkprofiel',
  'Wrong email or password':
      'Verkeerde e-pos of wagwoord',
  'YOU ORDERED':
      'JY HET BESTEL',
  'Year':
      'Jaar',
  'You':
      'Jy',
  'You can save up to {0} contacts.':
      'Jy kan tot {0} kontakte stoor.',
  'You can sign back in anytime to check your approval status.':
      'Jy kan enige tyd weer aanteken om jou goedkeuringstatus na te gaan.',
  'You don\'t have a balance to pay out yet.':
      'Jy het nog nie \'n saldo om uit te betaal nie.',
  'You have arrived!':
      'Jy het aangekom!',
  'You will stop receiving new orders until you sign in again.':
      'Jy sal geen nuwe bestellings ontvang totdat jy weer aanteken nie.',
  'You\'ll need to sign in again to book rides.':
      'Jy sal weer moet aanteken om ritte te bespreek.',
  'You\'ll stop receiving ride requests until you sign in again.':
      'Jy sal geen ritversoeke ontvang totdat jy weer aanteken nie.',
  'You\'re all set.':
      'Alles is gereed.',
  'You\'re approved!':
      'Jy is goedgekeur!',
  'You\'re not a participant in this trip.':
      'Jy is nie deel van hierdie rit nie.',
  'You\'ve already rated this trip. Thanks for the feedback!':
      'Jy het hierdie rit reeds gegradeer. Dankie vir die terugvoer!',
  'You\'ve already used this promo.':
      'Jy het hierdie promosie reeds gebruik.',
  'Your contacts have been notified.':
      'Jou kontakte is verwittig.',
  'Your data export':
      'Jou data-uitvoer',
  'Your device may not have a phone app. Please dial manually.':
      'Jou toestel het dalk nie \'n foontoep nie. Skakel self.',
  'Your documents have been submitted. An administrator will review them shortly — usually within a few hours.':
      'Jou dokumente is ingedien. \'n Administrateur sal hulle binnekort nagaan — gewoonlik binne \'n paar uur.',
  'Your earnings have been added to your wallet.':
      'Jou verdienste is by jou beursie gevoeg.',
  'Your emergency contacts':
      'Jou noodkontakte',
  'Your emergency contacts and our support team have been alerted with your location.':
      'Jou noodkontakte en ons ondersteuningspan is met jou ligging gewaarsku.',
  'Your emergency contacts and our support team will be notified with your location.':
      'Jou noodkontakte en ons ondersteuningspan sal met jou ligging verwittig word.',
  'Your feedback helps improve ko!ngo.':
      'Jou terugvoer help om ko!ngo te verbeter.',
  'Your feedback helps keep ko!ngo safe.':
      'Jou terugvoer help om ko!ngo veilig te hou.',
  'Your name has been saved.':
      'Jou naam is gestoor.',
  'Your new profile photo is live.':
      'Jou nuwe profielfoto is aanlyn.',
  'Your number stays hidden. Only the call is connected.':
      'Jou nommer bly versteek. Net die oproep word verbind.',
  'Your personal data':
      'Jou persoonlike data',
  'Your phone number has been saved.':
      'Jou foonnommer is gestoor.',
  'Your photo is visible to drivers and passengers during trips.':
      'Jou foto is tydens ritte sigbaar vir bestuurders en passasiers.',
  'Your scheduled ride has been cancelled.':
      'Jou geskeduleerde rit is gekanselleer.',
  'Your trips will appear here':
      'Jou ritte sal hier verskyn',
  'Your vehicle has been removed.':
      'Jou voertuig is verwyder.',
  'Your vehicle will be reviewed by an admin before it becomes active.':
      'Jou voertuig sal deur \'n admin nagegaan word voordat dit aktief word.',
  'e.g. 11 2nd Street, Firgrove':
      'bv. 11 rue Mbochi, Moungali',
  'e.g. 45 Main Rd, CBD':
      'bv. 45 avenue de la Paix, Middestad',
  'ko!ngo Plus will be available soon.':
      'ko!ngo Plus sal binnekort beskikbaar wees.',
  'ko!ngo needs your location to find nearby drivers.':
      'ko!ngo het jou ligging nodig om bestuurders naby te vind.',
  'typing…':
      'tik…',
  '{0} XAF pending':
      '{0} XAF hangende',
  '{0} active':
      '{0} aktief',
  '{0} has a suggestion':
      '{0} het \'n voorstel',
  '{0} hasn\'t added a phone number to their profile.':
      '{0} het nie \'n foonnommer by hul profiel gevoeg nie.',
  '{0} is ready to paste.':
      '{0} is gereed om te plak.',
  '{0} is typing…':
      '{0} tik…',
  '{0} new':
      '{0} nuut',
  '{0} of {1} complete':
      '{0} van {1} voltooi',
  '{0} of {1} modules complete':
      '{0} van {1} modules voltooi',
  '{0} points':
      '{0} punte',
  '{0} points to {1}':
      '{0} punte tot {1}',
  '💬 New message from {0}':
      '💬 Nuwe boodskap van {0}',
  '🚨 SOS activated':
      '🚨 SOS geaktiveer',
  'Are you sure you want to remove "{0}"?':
      'Is jy seker jy wil "{0}" verwyder?',
  'The price has changed':
      'Die prys het verander',
  'Please go back and check the price again.':
      'Gaan asseblief terug en kyk weer na die prys.',
  'The lowest price for this trip is {0}. Please go back and check the price again.':
      'Die laagste prys vir hierdie rit is {0}. Gaan asseblief terug en kyk weer na die prys.',
  'Not enough money in your wallet':
      'Nie genoeg geld in jou beursie nie',
  'Top up your wallet or choose another way to pay.':
      'Laai jou beursie op of kies \'n ander manier om te betaal.',
  'The picture could not be uploaded':
      'Die prent kon nie opgelaai word nie',
  '{0}\n\nYou can save the product now and add the picture later.':
      '{0}\n\nJy kan die produk nou stoor en die prent later byvoeg.',
  'Save without picture':
      'Stoor sonder prent',
  'OK':
      'OK',
  'Choose on map':
      'Kies op die kaart',
  'Tap the map where you want to be picked up':
      'Tik op die kaart waar jy opgelaai wil word',
  'Tap the map where you are going':
      'Tik op die kaart waarheen jy gaan',
  'Pinned location':
      'Gemerkte ligging',
  'Clear':
      'Vee uit',
  'Use my current location':
      'Gebruik my huidige ligging',
  'Street, suburb or landmark':
      'Straat, voorstad of landmerk',
  'No places found. Try a street name or landmark.':
      'Geen plekke gevind nie. Probeer \'n straatnaam of landmerk.',
  'Current location':
      'Huidige ligging',
  'Closed':
      'Gesluit',
  'Nearby pharmacies':
      'Apteke naby',
  'Stores near you':
      'Winkels naby jou',
  'Country':
      'Land',
  'Choose your country':
      'Kies jou land',
  'Add a place':
      'Voeg \'n plek by',
  'Name this place':
      'Gee hierdie plek \'n naam',
  'Home':
      'Huis',
  'Work':
      'Werk',
  'e.g. Mom\'s place':
      'bv. Ma se plek',
  'Place':
      'Plek',
  'Drivers, shoppers and store owners use a separate ko!ngo account, with a different email address. Your customer account stays as it is.':
      'Bestuurders, kopers en winkeleienaars gebruik \'n aparte ko!ngo-rekening, met \'n ander e-posadres. Jou kliëntrekening bly soos dit is.',
  'To create it, you will be signed out of this account. You can sign back in any time.':
      'Om dit te skep, word jy by hierdie rekening afgemeld. Jy kan enige tyd weer aanmeld.',
  'Sign out and create partner account':
      'Meld af en skep vennootrekening',
  'Stay signed in':
      'Bly aangemeld',
  'Invite friends and earn ride credit':
      'Nooi vriende en verdien ritkrediet',
  'No offers right now':
      'Geen aanbiedinge nou nie',
  'New promo codes will show here.':
      'Nuwe promosiekodes sal hier verskyn.',
  '{0}% off':
      '{0}% af',
  '{0} off':
      '{0} af',
  'Valid until {0}':
      'Geldig tot {0}',
  'Minimum {0}':
      'Minimum {0}',
  'Code {0} copied. Paste it when you book or check out.':
      'Kode {0} gekopieer. Plak dit wanneer jy bespreek of betaal.',
  'My orders':
      'My bestellings',
  'Active':
      'Aktief',
  'Past':
      'Vorige',
  'No active orders':
      'Geen aktiewe bestellings nie',
  'No past orders yet':
      'Nog geen vorige bestellings nie',
  'Order food, groceries or medicine from the Home tab.':
      'Bestel kos, kruideniersware of medisyne op die Tuis-blad.',
  '{0} items':
      '{0} items',
  'Order placed':
      'Bestelling geplaas',
  'Being prepared':
      'Word voorberei',
  'Ready for pickup':
      'Gereed vir afhaal',
  'On the way':
      'Op pad',
  'Delivered':
      'Afgelewer',
  'Returned to office':
      'Terug na kantoor',
  'Cancelled':
      'Gekanselleer',
  'Refunded':
      'Terugbetaal',
  'Order payment':
      'Bestellingbetaling',
  'Ride payment':
      'Ritbetaling',
  'Refund':
      'Terugbetaling',
  'Bonus':
      'Bonus',
  'Top-up':
      'Aanvulling',
  'Amount':
      'Bedrag',
  'How did you pay?':
      'Hoe het jy betaal?',
  'Bank transfer':
      'Bankoorbetaling',
  'Payment reference (optional)':
      'Betalingsverwysing (opsioneel)',
  'Send top-up request':
      'Stuur aanvullingsversoek',
  'Pay ko!ngo by bank transfer or cash, then send this request. Your balance goes up when ko!ngo confirms the payment.':
      'Betaal ko!ngo per bankoorbetaling of kontant en stuur dan hierdie versoek. Jou saldo styg wanneer ko!ngo die betaling bevestig.',
  'Your balance goes up when ko!ngo confirms it.':
      'Jou saldo styg wanneer ko!ngo dit bevestig.',
  'Waiting for approval':
      'Wag vir goedkeuring',
  'Activity':
      'Aktiwiteit',
  '{0} waiting for approval':
      '{0} wag vir goedkeuring',
  'Add money to pay for rides and orders without cash.':
      'Voeg geld by om ritte en bestellings sonder kontant te betaal.',
  'Payments, top-ups and refunds will show here.':
      'Betalings, aanvullings en terugbetalings verskyn hier.',
  'Wallet & payouts':
      'Beursie en uitbetalings',
  'Payouts on the way':
      'Uitbetalings op pad',
  'Trip earnings':
      'Rit-verdienste',
  'Past payouts':
      'Vorige uitbetalings',
  'Wallet {0} · Unpaid trips {1}':
      'Beursie {0} · Onbetaalde ritte {1}',
  'ko!ngo fee {0}% · {1} completed trips':
      'ko!ngo-fooi {0}% · {1} voltooide ritte',
  'Completed trips and what you earned on each will show here.':
      'Voltooide ritte en wat jy op elkeen verdien het, verskyn hier.',
  'Payout':
      'Uitbetaling',
  'Tip':
      'Fooi',
  'Credit':
      'Krediet',
  'Deduction':
      'Aftrekking',
  'Rewards':
      'Belonings',
  'App':
      'Toep',
  'More':
      'Meer',
  'Privacy and security':
      'Privaatheid en sekuriteit',
  'Edit profile':
      'Wysig profiel',
  '{0} ratings':
      '{0} graderings',
  'Your profile':
      'Jou profiel',
  'Signing out…':
      'Teken tans uit…',
  'Wallet & payment':
      'Beursie en betaling',
  'Balance, top up and activity':
      'Saldo, aanvul en aktiwiteit',
  'Home, work and favourites':
      'Huis, werk en gunstelinge',
  'Emergency contacts and SOS':
      'Noodkontakte en SOS',
  'Get help with a trip or order':
      'Kry hulp met ’n rit of bestelling',
  'Notifications and email receipts':
      'Kennisgewings en e-poskwitansies',
  'Password, email and sessions':
      'Wagwoord, e-pos en sessies',
  'Terms and privacy policy':
      'Bepalings en privaatheidsbeleid',
  'Pay ko!ngo with one of the methods below, then send this request. Your balance goes up when ko!ngo confirms the payment.':
      'Betaal ko!ngo met een van die metodes hieronder en stuur dan hierdie versoek. Jou saldo gaan op wanneer ko!ngo die betaling bevestig.',
  'Pay to: {0}':
      'Betaal aan: {0}',
  'Contact ko!ngo support for the {0} payment details.':
      'Kontak ko!ngo-ondersteuning vir die {0}-betaalbesonderhede.',
  'Transaction code (from the SMS)':
      'Transaksiekode (uit die SMS)',
  'Bank transfer (EFT)':
      'Bankoorplasing (EFT)',
  'Customers can order now':
      'Kliënte kan nou bestel',
  'Closed: customers cannot order':
      'Gesluit: kliënte kan nie bestel nie',
  'New and active orders':
      'Nuwe en aktiewe bestellings',
  'How will you pay?':
      'Hoe gaan jy betaal?',
  'ko!ngo wallet':
      'ko!ngo-beursie',
  'Balance {0}':
      'Saldo {0}',
  'Balance {0}: not enough for this':
      'Saldo {0}: nie genoeg nie',
  'Cash':
      'Kontant',
  'Card':
      'Kaart',
  'Visa or Mastercard':
      'Visa of Mastercard',
  'Not enough in your wallet':
      'Nie genoeg in jou beursie nie',
  'Top up your wallet or choose cash.':
      'Vul jou beursie aan of kies kontant.',
  'Not enough in your wallet. Top up or choose cash.':
      'Nie genoeg in jou beursie nie. Vul aan of kies kontant.',
  'Pay the courier':
      'Betaal die koerier',
  'Pay the driver at the end of the trip':
      'Betaal die bestuurder aan die einde van die rit',
  'Pay the courier at pickup':
      'Betaal die koerier by optel',
  'Pay the driver when it arrives':
      'Betaal die bestuurder wanneer dit aankom',
  'Paid from wallet':
      'Betaal uit beursie',
  'Paid by card':
      'Betaal met kaart',
  'Cash: collect from customer':
      'Kontant: vorder van kliënt',
  'Collect {0} cash from the customer':
      'Vorder {0} kontant van die kliënt',
  'Paid from the customer\'s wallet. No cash to collect.':
      'Betaal uit die kliënt se beursie. Geen kontant om te vorder nie.',
  'Paid in the app. No cash to collect.':
      'Betaal in die toep. Geen kontant om te vorder nie.',
  'Card not available':
      'Kaart nie beskikbaar nie',
  'Card payments are not available here yet. Please choose cash or wallet.':
      'Kaartbetalings is nog nie hier beskikbaar nie. Kies kontant of beursie.',
  'New message to support':
      'Nuwe boodskap aan ondersteuning',
  'What is it about?':
      'Waaroor gaan dit?',
  'e.g. Payment, a trip, an order':
      'bv. Betaling, \u2019n rit, \u2019n bestelling',
  'Tell us what happened':
      'Vertel ons wat gebeur het',
  'Send':
      'Stuur',
  'Solved':
      'Opgelos',
  'Answered':
      'Beantwoord',
  'Waiting for support':
      'Wag vir ondersteuning',
  'Message support':
      'Stuur boodskap aan ondersteuning',
  'Chat with the ko!ngo team. We reply here and you get a notification.':
      'Gesels met die ko!ngo-span. Ons antwoord hier en jy kry \u2019n kennisgewing.',
  'Your conversations':
      'Jou gesprekke',
  'No conversations yet. Tap "Message support" to start one.':
      'Nog geen gesprekke nie. Tik "Stuur boodskap aan ondersteuning" om te begin.',
  'WhatsApp':
      'WhatsApp',
  'ko!ngo support':
      'ko!ngo-ondersteuning',
  'Our team will reply here. You will get a notification.':
      'Ons span sal hier antwoord. Jy sal \u2019n kennisgewing kry.',
  'Write a message':
      'Skryf \u2019n boodskap',
  'This is a {0} account':
      'Dit is \u2019n {0}-rekening',
  'These details belong to a {0} account, so they can\'t be used on the {1} login. Please sign in from the {0} login.':
      'Hierdie besonderhede behoort aan \u2019n {0}-rekening en kan nie op die {1}-aanmelding gebruik word nie. Meld asseblief by die {0}-aanmelding aan.',
  'Go to {0} login':
      'Gaan na {0}-aanmelding',
  'Where to?':
      'Waarheen?',
  'Later':
      'Later',
  'Add home':
      'Voeg huis by',
  'You are here · {0} cars nearby':
      'Jy is hier · {0} motors naby',
  'You are here':
      'Jy is hier',
  'Tap to copy the code':
      'Tik om die kode te kopieer',
  'Offers and promo codes':
      'Aanbiedinge en promokodes',
  'See what is on today':
      'Kyk wat is vandag beskikbaar',
  'Take a photo':
      'Neem \u2019n foto',
  'Choose from gallery':
      'Kies uit galery',
  'Send a photo':
      'Stuur \u2019n foto',
  'Sedan (up to 4 seats)':
      'Sedan (tot 4 sitplekke)',
  'XL (6 seats, SUV / minivan)':
      'XL (6 sitplekke, SUV / minibus)',
  'Van / minibus (up to 14 seats)':
      'Bussie / minibus (tot 14 sitplekke)',
  'Large van (cargo)':
      'Groot paneelwa (vrag)',
  'Truck':
      'Vragmotor',
  'Motorbike / Scooter':
      'Motorfiets / bromponie',
  'Money in your wallet':
      'Geld in jou beursie',
  'You still have {0} in your ko!ngo wallet. If you delete your account now, this money is lost. Contact support first if you want it back.':
      'Jy het nog {0} in jou ko!ngo-beursie. As jy jou rekening nou uitvee, is hierdie geld verlore. Kontak eers ondersteuning as jy dit terug wil hê.',
  'Keep my account':
      'Hou my rekening',
  'Delete anyway':
      'Vee in elk geval uit',
  'Not yet':
      'Nog nie',
  'Finish or cancel your current trip first.':
      'Voltooi of kanselleer eers jou huidige rit.',
  'Wait until your order is delivered or cancel it first.':
      'Wag totdat jou bestelling afgelewer is of kanselleer dit eers.',
  'Your driver':
      'Jou bestuurder',
  'Chat opens once a driver has your order.':
      'Klets maak oop sodra \u2019n bestuurder jou bestelling het.',
  'Orders waiting for a driver':
      'Bestellings wat op \u2019n bestuurder wag',
  'Tap an order to see it and accept it.':
      'Tik op \u2019n bestelling om dit te sien en te aanvaar.',
  'No orders waiting right now':
      'Geen bestellings wag nou nie',
  'away':
      'weg',
  'waiting {0} min':
      'wag al {0} min',
  '{0} orders waiting':
      '{0} bestellings wag',
  'NO ANSWER':
      'GEEN ANTWOORD',
  'The customer didn\'t answer. Pick the original item or leave it out.':
      'Die kliënt het nie geantwoord nie. Kies die oorspronklike item of los dit uit.',
  'OK, continue shopping':
      'OK, gaan voort met inkopies',
  'Your trip has started. Only the driver can end it now.':
      'Jou rit het begin. Net die bestuurder kan dit nou beëindig.',
  'Trip already started':
      'Rit het reeds begin',
  'This trip was cancelled.':
      'Hierdie rit is gekanselleer.',
  'See all':
      'Sien alles',
  'View':
      'Kyk',
  'Messages':
      'Boodskappe',
  'Yesterday':
      'Gister',
  'Trips and deliveries':
      'Ritte en aflewerings',
  'Chats from your trips show here. Chats close when a trip ends and stay readable for 7 days.':
      'Kletse van jou ritte verskyn hier. Hulle sluit wanneer \u2019n rit eindig en bly 7 dae leesbaar.',
  'ko!ngo Support':
      'ko!ngo-ondersteuning',
  'Questions, problems, payments: we reply here.':
      'Vrae, probleme, betalings: ons antwoord hier.',
  'Photo':
      'Foto',
  'Trip ended':
      'Rit verby',
  'This trip has ended, so the chat is closed.':
      'Hierdie rit is verby, dus is die klets gesluit.',
  'Ride booked':
      'Rit bespreek',
  "We'll start finding a driver 10 minutes before.":
      "Ons begin 10 minute vooraf na 'n bestuurder soek.",
  "{0}. We'll start finding a driver 10 minutes before.":
      "{0}. Ons begin 10 minute vooraf na 'n bestuurder soek.",
  'Price offer withdrawn':
      'Prysaanbod teruggetrek',
  "We're still looking for a driver at your price.":
      "Ons soek nog 'n bestuurder teen jou prys.",
  'Your driver had to cancel':
      'Jou bestuurder moes kanselleer',
  "We're finding you another driver.":
      "Ons soek vir jou 'n ander bestuurder.",
  'No driver found':
      'Geen bestuurder gevind nie',
  'Trip cancelled':
      'Rit gekanselleer',
  'No driver was free just now. Please try again.':
      'Geen bestuurder was nou beskikbaar nie. Probeer asseblief weer.',
  'Your driver cancelled the trip.':
      'Jou bestuurder het die rit gekanselleer.',
  'ko!ngo support cancelled this trip.':
      'ko!ngo-ondersteuning het hierdie rit gekanselleer.',
  'Offer declined':
      'Aanbod van die hand gewys',
  'Pick a later time':
      "Kies 'n later tyd",
  'Book at least 20 minutes ahead, or choose Now.':
      'Bespreek ten minste 20 minute vooraf, of kies Nou.',
  'When':
      'Wanneer',
  'Now':
      'Nou',
  "We'll start finding a driver 10 minutes before. You can cancel any time before then.":
      "Ons begin 10 minute vooraf na 'n bestuurder soek. Jy kan enige tyd voor dit kanselleer.",
  'Today {0}':
      'Vandag {0}',
  'Tomorrow {0}':
      'Môre {0}',
  '{0} km':
      '{0} km',
  'Book for later':
      'Bespreek vir later',
  'Book a ride ahead — we find your driver 10 minutes before.':
      'Bespreek vooraf — ons kry jou bestuurder 10 minute vooraf.',
  'Time unknown':
      'Tyd onbekend',
  'Paid from your wallet':
      'Uit jou beursie betaal',
  'Pay the courier in cash':
      'Betaal die koerier kontant',
  'Pay the driver in cash':
      'Betaal die bestuurder kontant',
  'Parcel delivered!':
      'Pakkie afgelewer!',
  'Thanks for sending with ko!ngo.':
      'Dankie dat jy met ko!ngo gestuur het.',
  'Distance':
      'Afstand',
  'Trip ID':
      'Rit-ID',
  'Rate {0}':
      'Gradeer {0}',
  'Rate your driver':
      'Gradeer jou bestuurder',
  'Another driver has already sent a price. Try again in a moment.':
      "'n Ander bestuurder het reeds 'n prys gestuur. Probeer binnekort weer.",
  'Wallet {0} · Waiting payouts {1}':
      'Beursie {0} · Uitbetalings wat wag {1}',
  'You owe ko!ngo {0} from cash you collected. It comes off your next earnings, or pay it at a ko!ngo office.':
      "Jy skuld ko!ngo {0} van kontant wat jy ingevorder het. Dit word van jou volgende verdienste afgetrek, of betaal dit by 'n ko!ngo-kantoor.",
  'Cash you kept':
      'Kontant wat jy gehou het',
  'Bank or mobile money':
      'Bank of selfoongeld',
  'Account or phone number':
      'Rekening- of foonnommer',
  'ko!ngo will send it and let you know.':
      'ko!ngo sal dit stuur en jou laat weet.',
  'Available {0} · Waiting payouts {1}':
      'Beskikbaar {0} · Uitbetalings wat wag {1}',
  'Sales credited':
      'Verkope gekrediteer',
  'Please sign in again':
      'Meld asseblief weer aan',
  'Your session ended. Sign in again to continue.':
      'Jou sessie het verval. Meld weer aan om voort te gaan.',
  "Couldn't get your location. Allow location for ko!ngo, or type your street above.":
      'Kon nie jou ligging kry nie. Laat ligging vir ko!ngo toe, of tik jou straat hierbo.',
  'Pick an address from the list, or tap "Use my current location".':
      "Kies 'n adres uit die lys, of tik \"Gebruik my huidige ligging\".",
  "You don't have permission for this action. Try signing in again.":
      'Jy het nie toestemming hiervoor nie. Probeer weer aanmeld.',
  'code':
      'kode',
  'Upload failed':
      'Oplaai het misluk',
  "Pictures can't be saved for this account yet. Please contact ko!ngo support.":
      "Foto's kan nog nie vir hierdie rekening gestoor word nie. Kontak ko!ngo-ondersteuning.",
  "Pictures can't be saved for this store yet. Please contact ko!ngo support.":
      "Foto's kan nog nie vir hierdie winkel gestoor word nie. Kontak ko!ngo-ondersteuning.",
  'The picture could not be saved. Please try again.':
      'Die foto kon nie gestoor word nie. Probeer weer.',
  'No internet connection. Check your network and try again.':
      'Geen internetverbinding nie. Kyk jou netwerk en probeer weer.',
  'The upload took too long. Check your connection.':
      'Die oplaai het te lank geneem. Kyk jou verbinding.',
  'Could not load this item swap. Please try again.':
      'Kon nie hierdie vervanging laai nie. Probeer weer.',
  "You're offline. Check your data or Wi‑Fi and try again.":
      'Jy is vanlyn. Kyk jou data of Wi‑Fi en probeer weer.',
  'No internet. Reconnecting…':
      'Geen internet nie. Herverbind…',
  'New order':
      'Nuwe bestelling',
  'My trips':
      'My ritte',
  'Every trip you took, in order':
      'Elke rit wat jy gery het, in volgorde',
  'Booked':
      'Bespreek',
  'No trip in progress':
      'Geen rit aan die gang nie',
  'No rides booked for later':
      'Geen ritte vir later bespreek nie',
  'No finished trips yet':
      'Nog geen voltooide ritte nie',
  'No cancelled trips':
      'Geen gekanselleerde ritte nie',
  'Going to pickup':
      'Op pad om op te laai',
  'At pickup':
      'By die oplaaipunt',
  'Returning parcel':
      'Pakkie word teruggeneem',
  'Completed':
      'Voltooi',
  'Returned':
      'Teruggegee',
  'Expired':
      'Verval',
  'Delivery':
      'Aflewering',
  'Ride':
      'Rit',
  'Tap to go back to this trip':
      'Tik om terug te gaan na hierdie rit',
  'Today':
      'Vandag',
  'Tomorrow':
      'Môre',
  'Status':
      'Status',
  'Price':
      'Prys',
  'Booked for':
      'Bespreek vir',
  'Requested':
      'Aangevra',
  'Accepted':
      'Aanvaar',
  'Finished':
      'Klaar',
  'Reason':
      'Rede',
  'Your rating from the customer':
      'Jou gradering van die kliënt',
  'Trip prices {0} · ko!ngo fee {1}%':
      'Ritpryse {0} · ko!ngo-fooi {1}%',
  'Trip price':
      'Ritprys',
  'Pinned on the map':
      'Op die kaart vasgepen',
  '{0} ({1} ratings)':
      '{0} ({1} graderings)',
  'No ratings yet':
      'Nog geen graderings nie',
  'New customer · first trip':
      'Nuwe kliënt · eerste rit',
  '1 trip with ko!ngo':
      '1 rit met ko!ngo',
  '{0} trips with ko!ngo':
      '{0} ritte met ko!ngo',
  'New shopping task':
      'Nuwe inkopietaak',
  '…':
      '…',
  'ko!ngo':
      'ko!ngo',
  'Calling…':
      'Bel tans…',
  'Incoming call':
      'Inkomende oproep',
  'Connecting…':
      'Koppel tans…',
  'Decline':
      'Weier',
  'Answer':
      'Antwoord',
  'Mute':
      'Demp',
  'End':
      'Beëindig',
  'Speaker':
      'Luidspreker',
  'KO!NGO':
      'KO!NGO',
  'x{0} · {1}':
      'x{0} · {1}',
  'Share it with a friend to earn ride credit.':
      'Deel dit met ’n vriend om rit-krediet te verdien.',
  'Share your code and earn ride credit for each friend who takes their first ride.':
      'Deel jou kode en verdien rit-krediet vir elke vriend wat sy eerste rit neem.',
  "Credit is added after your friend's first completed ride.":
      'Krediet word bygevoeg nadat jou vriend sy eerste rit voltooi het.',
  'ko!ngo v1.0.0':
      'ko!ngo v1.0.0',
  'Interested? Contact ko!ngo support to join the waitlist.':
      'Belangstelling? Kontak ko!ngo-ondersteuning om by die wagsy aan te sluit.',
  'Your driver has arrived':
      'Jou bestuurder het aangekom',
  'Transport':
      'Vervoer',
  'Marketplace':
      'Markplein',
  'Book a ride in minutes · Fast & reliable':
      'Bespreek ’n rit in minute · Vinnig en betroubaar',
  'Send a package · Track delivery':
      'Stuur ’n pakkie · Volg aflewering',
  'Search shops and categories':
      'Soek winkels en kategorieë',
  'Groceries':
      'Kruideniersware',
  'Fashion':
      'Mode',
  'Electronics':
      'Elektronika',
  'Home & Living':
      'Huis en Woon',
  'Beauty':
      'Skoonheid',
  'Butchery':
      'Slaghuis',
  'Bakery':
      'Bakkery',
  'General Retail':
      'Algemene kleinhandel',
  'Other':
      'Ander',
  'No categories match your search.':
      'Geen kategorieë pas by jou soektog nie.',
  'Nearby drivers · {0} nearby':
      'Bestuurders naby · {0} naby',
  'Your new photo is saved.':
      'Jou nuwe foto is gestoor.',
  'Customers see this photo when you shop for them.':
      'Kliënte sien hierdie foto wanneer jy vir hulle inkopies doen.',
  'Change photo':
      'Verander foto',
  'All':
      'Almal',
  'Restaurant':
      'Restaurant',
  'Pharmacy':
      'Apteek',
  'Marketplace: delivery requests from shops and stores':
      'Markplein: afleweringsversoeke van winkels',
  'No shop deliveries right now. New ones appear here and ring your phone.':
      'Geen winkelaflewerings nou nie. Nuwes verskyn hier en lui jou foon.',
  'Go online to receive shop deliveries.':
      'Gaan aanlyn om winkelaflewerings te ontvang.',
  'Passed · {0}%':
      'Geslaag · {0}%',
  'Score {0}% · 80% to pass':
      'Telling {0}% · 80% om te slaag',
  'Well done. This module is now complete.':
      'Mooi so. Hierdie module is nou voltooi.',
  'Review the answers above and try again.':
      'Hersien die antwoorde hierbo en probeer weer.',
  'Answer {0} more':
      'Beantwoord nog {0}',
  'Submit quiz':
      'Dien vasvra in',
  'Call customer':
      'Bel kliënt',
  'Recommended':
      'Aanbeveel',
  "You're certified. Happy driving!":
      'Jy is gesertifiseer. Veilige ry!',
  'Complete all required modules to go online.':
      'Voltooi al die vereiste modules om aanlyn te gaan.',
  '{0} min':
      '{0} min',
  'Certificate of completion':
      'Sertifikaat van voltooiing',
  'Certificate locked':
      'Sertifikaat gesluit',
  'You have completed all required training.':
      'Jy het al die vereiste opleiding voltooi.',
  'Complete all required modules to unlock.':
      'Voltooi al die vereiste modules om oop te sluit.',
  'My shops':
      'My winkels',
  'Add another shop':
      'Voeg nog ’n winkel by',
  '{0} · Business type':
      '{0} · Soort besigheid',
  'For {0}':
      'Vir {0}',
  'Restock':
      'Hervoorraad',
  'Store profile':
      'Winkelprofiel',
  'Quick Actions':
      'Vinnige aksies',
  '1.0.0 · build 1':
      '1.0.0 · build 1',
  'Aa':
      'Aa',
  'day':
      'dag',
  'fixed price':
      'vaste prys',
  'hour':
      'uur',
  'This week':
      'Hierdie week',
  'Ongoing':
      'Deurlopend',
  'Just now':
      'Nou net',
  '{0} min ago':
      '{0} min gelede',
  '{0} h ago':
      '{0} h gelede',
  '{0} d ago':
      '{0} d gelede',
  'Live':
      'Aktief',
  'Filled':
      'Gevul',
  'Not approved':
      'Nie goedgekeur nie',
  'Shortlisted':
      'Kortlys',
  'Hired':
      'Aangestel',
  'Applied':
      'Aansoek gedoen',
  'Withdrawn':
      'Teruggetrek',
  'URGENT':
      'DRINGEND',
  'Hiring Hub':
      'Werksentrum',
  'Find Work':
      'Soek werk',
  'My Applications':
      'My aansoeke',
  'My Jobs':
      'My werke',
  'Post a Job':
      'Plaas \'n werk',
  'Search jobs, skills...':
      'Soek werke, vaardighede...',
  'Could not load jobs. Pull down to try again.':
      'Kon nie werke laai nie. Trek af om weer te probeer.',
  'No jobs here yet. Be the first to post one!':
      'Nog geen werke hier nie. Wees die eerste om een te plaas!',
  'Apply':
      'Doen aansoek',
  'You have not applied for any job yet.':
      'Jy het nog vir geen werk aansoek gedoen nie.',
  'Jobs you post will show here.':
      'Werke wat jy plaas sal hier wys.',
  'applicants':
      'aansoekers',
  'Application sent. You will be notified.':
      'Aansoek gestuur. Jy sal in kennis gestel word.',
  'Verified ID':
      'Geverifieerde ID',
  'Experience':
      'Ervaring',
  'Own tools':
      'Eie gereedskap',
  'Own transport':
      'Eie vervoer',
  'Employer':
      'Werkgewer',
  '{0} workers needed':
      '{0} werkers benodig',
  'Description':
      'Beskrywing',
  'Requirements':
      'Vereistes',
  'Your application':
      'Jou aansoek',
  'Withdraw application':
      'Trek aansoek terug',
  'Say a few words about yourself (optional)':
      'Sê \'n paar woorde oor jouself (opsioneel)',
  'Close this job?':
      'Sluit hierdie werk?',
  'Workers will no longer see it.':
      'Werkers sal dit nie meer sien nie.',
  'Close job':
      'Sluit werk',
  'We are checking your job. It will go live as soon as it is approved.':
      'Ons kontroleer jou werk. Dit sal aanlyn wees sodra dit goedgekeur is.',
  'Applicants':
      'Aansoekers',
  'No applicants yet.':
      'Nog geen aansoekers nie.',
  'Shortlist':
      'Kortlys',
  'Hire':
      'Stel aan',
  'Allow location to use this.':
      'Laat ligging toe om dit te gebruik.',
  'Could not find your location.':
      'Kon nie jou ligging vind nie.',
  'Please enter a job title.':
      'Voer asseblief \'n werktitel in.',
  'Please enter the pay amount.':
      'Voer asseblief die betaling in.',
  'Please enter where the job is.':
      'Voer asseblief in waar die werk is.',
  'This is how workers will see your job':
      'Dit is hoe werkers jou werk sal sien',
  'The photo could not be uploaded. Try again or post without it.':
      'Die foto kon nie opgelaai word nie. Probeer weer of plaas daarsonder.',
  'Job sent for approval':
      'Werk gestuur vir goedkeuring',
  'We will check it and let you know as soon as it is live.':
      'Ons sal dit nagaan en jou laat weet sodra dit aanlyn is.',
  'Post a Job - Hire in minutes':
      'Plaas \'n werk - Stel aan in minute',
  'Fill out the details and connect with trusted workers near you':
      'Vul die besonderhede in en verbind met betroubare werkers naby jou',
  'Job Title':
      'Werktitel',
  'e.g. House Cleaner Needed':
      'bv. Huisskoonmaker benodig',
  'Category':
      'Kategorie',
  'Describe the job, what you need done, and any important details...':
      'Beskryf die werk, wat gedoen moet word en belangrike besonderhede...',
  'Pay Type':
      'Betaalsoort',
  'Per Hour':
      'Per uur',
  'Per Day':
      'Per dag',
  'Fixed Price':
      'Vaste prys',
  'Amount ({0})':
      'Bedrag ({0})',
  'Location':
      'Ligging',
  'Where is the job?':
      'Waar is die werk?',
  'Use my location':
      'Gebruik my ligging',
  'Duration':
      'Duur',
  'Workers needed':
      'Werkers benodig',
  'Mark as urgent':
      'Merk as dringend',
  'Upload photo':
      'Laai foto op',
  'optional':
      'opsioneel',
  'Add a photo to help workers understand the job':
      'Voeg \'n foto by om werkers te help om die werk te verstaan',
  'Your first name will be visible to workers. Your job is checked before it goes live.':
      'Jou voornaam sal vir werkers sigbaar wees. Jou werk word nagegaan voordat dit aanlyn gaan.',
  'Preview Job':
      'Voorskou werk',
  'Post Job Now':
      'Plaas werk nou',
  'Hiring Hub - Find work, hire talent':
      'Werksentrum - Soek werk, stel talent aan',
  'Trusted workers and jobs near you':
      'Betroubare werkers en werke naby jou',
  'See All':
      'Sien alles',
  'Latest jobs':
      'Nuutste werke',
  'Hiring':
      'Werwing',
  'Rides & Delivery':
      'Ritte en aflewering',
  'Cleaning & Home':
      'Skoonmaak en huis',
  'Construction':
      'Konstruksie',
  'Retail & Hospitality':
      'Kleinhandel en gasvryheid',
  'Tutoring':
      'Afrigting',
  'Admin & Office':
      'Admin en kantoor',
  'This job is closed':
      'Hierdie werk is gesluit',
  'This job is no longer taking applications.':
      'Hierdie werk neem nie meer aansoeke aan nie.',
  'Not possible':
      'Nie moontlik nie',
  'You cannot apply to your own job.':
      'Jy kan nie vir jou eie werk aansoek doen nie.',
  'Your wallet needs {0} to post this job. Top up and try again.':
      'Jou beursie het {0} nodig om hierdie werk te plaas. Laai op en probeer weer.',
  '+{0} · shown first for {1} days':
      '+{0} · eerste gewys vir {1} dae',
  'Shown first for {0} days':
      'Eerste gewys vir {0} dae',
  'Posting fee':
      'Plasingsfooi',
  'Urgent boost':
      'Dringende hupstoot',
  'Total from your wallet':
      'Totaal uit jou beursie',
  'Your wallet':
      'Jou beursie',
  'If we do not approve your job, the fee is returned to your wallet.':
      'As ons nie jou werk goedkeur nie, word die fooi na jou beursie teruggestuur.',
  'Top up wallet':
      'Laai beursie op',
  'Fresh picks, fast':
      'Vars keuses, vinnig',
  'Our shoppers pick the best for you':
      'Ons inkopers kies die beste vir jou',
  'Verified pharmacies':
      'Geverifieerde apteke',
  'Cold-chain ready · pharmacist-verified':
      'Koueketting gereed · deur apteker geverifieer',
  'Shops near you':
      'Winkels naby jou',
  'Get around with KO!NGO':
      'Beweeg rond met KO!NGO',
  'Fast':
      'Vinnig',
  'Safe':
      'Veilig',
  'Reliable':
      'Betroubaar',
  'Book a Ride':
      'Bespreek \'n rit',
  'Shop from a wide range':
      'Koop uit \'n wye reeks',
  'Groceries, food, pharmacy, fashion and more, brought to your door':
      'Kruideniers, kos, apteek, mode en meer, aan jou deur afgelewer',
  'Promote my store':
      'Bevorder my winkel',
  'Be listed first and get more orders':
      'Word eerste gelys en kry meer bestellings',
  'Sponsored':
      'Geborg',
  'Sponsored until {0}':
      'Geborg tot {0}',
  'Your store appears first in the list with a Sponsored label.':
      'Jou winkel verskyn eerste in die lys met \'n Geborg-etiket.',
  'Your store is now sponsored':
      'Jou winkel word nou geborg',
  'Sponsored spots are not available in your country yet.':
      'Geborgde plekke is nog nie in jou land beskikbaar nie.',
  'How many weeks?':
      'Hoeveel weke?',
  'week':
      'week',
  'weeks':
      'weke',
  'Price per week':
      'Prys per week',
  'Sponsor my store · {0}':
      'Borg my winkel · {0}',
  'Not available':
      'Nie beskikbaar nie',
  'This is not available right now.':
      'Dit is tans nie beskikbaar nie.',
  'Earn more':
      'Verdien meer',
  'tasks':
      'take',
  'trips':
      'ritte',
  'task':
      'taak',
  'trip':
      'rit',
  'Done! {0} added to your wallet':
      'Klaar! {0} by jou beursie gevoeg',
  '{0} of {1} {2} this week · Bonus {3}':
      '{0} van {1} {2} hierdie week · Bonus {3}',
  '{0}: +{1} for every {2} between {3} and {4}':
      '{0}: +{1} vir elke {2} tussen {3} en {4}',
  'Verified by ko!ngo':
      'Geverifieer deur ko!ngo',
  'Verified':
      'Geverifieer',
  'Signed in on another phone':
      'Op \'n ander foon aangemeld',
  'Your account was opened on another phone, so this one was signed out.':
      'Jou rekening is op \'n ander foon oopgemaak, so hierdie een is afgeteken.',
  'Recommendations':
      'Aanbevelings',
  'Add your vehicle':
      'Voeg jou voertuig by',
  'You owe ko!ngo {0}':
      'Jy skuld ko!ngo {0}',
  'Add your profile picture':
      'Voeg jou profielfoto by',
  'Upload your papers ({0} missing)':
      'Laai jou dokumente op ({0} ontbreek)',
  'Your papers are being checked':
      'Jou dokumente word nagegaan',
  'Add your bank details to get paid':
      'Voeg jou bankbesonderhede by om betaal te word',
  'Finish driver academy':
      'Voltooi die bestuurdersakademie',
  'You are all set. Nothing to fix.':
      'Alles is in orde. Niks om reg te maak nie.',
  'Tap to see what to fix':
      'Tik om te sien wat reggemaak moet word',
  'Quick photo check':
      'Vinnige fotokontrole',
  'Take a live selfie now so we know it is you. This takes a few seconds.':
      'Neem nou \'n selfie sodat ons weet dit is jy. Dit neem \'n paar sekondes.',
  'Your face must be clearly visible. Photos from the gallery are not accepted.':
      'Jou gesig moet duidelik sigbaar wees. Foto\'s uit die galery word nie aanvaar nie.',
  'Take selfie':
      'Neem selfie',
  'Send photo':
      'Stuur foto',
  'Retake':
      'Neem weer',
  'Sending…':
      'Stuur tans…',
  'Photo check sent. Thank you.':
      'Fotokontrole gestuur. Dankie.',
  'Photo check needed before you go online':
      'Fotokontrole nodig voordat jy aanlyn gaan',
  'Take your weekly selfie check':
      'Neem jou weeklikse selfie',
  'Could not send the photo. Check your internet and try again.':
      'Kon nie die foto stuur nie. Kyk jou internet en probeer weer.',
  'Could not open the camera. Allow camera access for ko!ngo in your phone settings.':
      'Kon nie die kamera oopmaak nie. Laat ko!ngo toe om die kamera te gebruik in jou foon se instellings.',
  'Your balance is low. Top up so you can keep working without interruption.': 'Jou saldo is laag. Laai op sodat jy sonder onderbreking kan werk.',
  'Your balance is low ({0}). Top up.': 'Jou saldo is laag ({0}). Laai op.',
  'Daily goal': 'Daaglikse teiken',
  'Set a daily goal': 'Stel \'n daaglikse teiken',
  'Goal reached!': 'Teiken bereik!',
  '{0} of {1}': '{0} van {1}',
  'Amount you want to earn today': 'Bedrag wat jy vandag wil verdien',
  'Trips': 'Ritte',
  'Up {0}% on last week': '{0}% meer as verlede week',
  'Down {0}% on last week': '{0}% minder as verlede week',
  'Same as last week': 'Dieselfde as verlede week',
  'No trips yet this week': 'Nog geen ritte hierdie week nie',
  'Pop-up over other apps': 'Opspringvenster oor ander programme',
  'Lets a ride request open ko!ngo on top of other apps. Switch it on for ko!ngo on the page that opens.': 'Laat \'n ritversoek ko!ngo bo-oor ander programme oopmaak. Skakel dit aan vir ko!ngo op die bladsy wat oopmaak.',
  'Open settings': 'Maak instellings oop',
  'Not ringing? See what happened to the last request on this phone.': 'Lui nie? Kyk wat met die laaste versoek op hierdie foon gebeur het.',
  'Check last ring': 'Kyk laaste lui',
  'No ring has reached this phone yet.': 'Geen lui het nog hierdie foon bereik nie.',
  'Tip your driver':
      'Gee jou bestuurder \'n fooitjie',
  'Send tip':
      'Stuur fooitjie',
  'Tip sent. Thank you!':
      'Fooitjie gestuur. Dankie!',
  'Custom amount':
      'Ander bedrag',
  'Why this rating? (optional)':
      'Hoekom hierdie gradering? (opsioneel)',
  'Share receipt':
      'Deel kwitansie',
  'Tip amount':
      'Fooitjiebedrag',
  'My worker profile':
      'My werkerprofiel',
  'Other requests':
      'Ander versoeke',
  '{0} other requests waiting. Choose one.':
      '{0} ander versoeke wag. Kies een.',
  'Finish your current trip first':
      'Voltooi eers jou huidige rit',
  'You can accept one order at a time.':
      'Jy kan een bestelling op \'n slag aanvaar.',
  'Shops':
      'Winkels',
  'Open':
      'Oop',
  'Nothing found. Try another word.':
      'Niks gevind nie. Probeer \'n ander woord.',
  'Heavy traffic ahead. About {0} extra minutes.':
      'Swaar verkeer voor. Omtrent {0} ekstra minute.',
  'Slow traffic in {0} km.':
      'Stadige verkeer oor {0} km.',
  'In {0} metres: {1}':
      'Oor {0} meter: {1}',
  '{0} reported ahead.':
      '{0} gerapporteer voor.',
  'Accident':
      'Ongeluk',
  'Hazard on the road':
      'Gevaar op die pad',
  'Traffic jam':
      'Verkeersopstopping',
  'Report on the road':
      'Rapporteer op die pad',
  'Thanks, other drivers will be warned.':
      'Dankie, ander bestuurders sal gewaarsku word.',
  'Navigation started':
      'Navigasie begin',
  'Heavy traffic: +{0} min':
      'Swaar verkeer: +{0} min',
  'Voice directions':
      'Stemaanwysings',
  'Take a photo now':
      'Neem nou \'n foto',
  'Your worker profile is ready':
      'Jou werkersprofiel is gereed',
  'Looking for work?':
      'Soek jy werk?',
  'Tap Apply on any job below.':
      'Tik Doen aansoek op enige werk hieronder.',
  'Set up your worker profile so employers can see what you do. Then tap Apply on any job.':
      'Stel jou werkersprofiel op sodat werkgewers sien wat jy doen. Tik dan Doen aansoek op enige werk.',
  'Set up my profile':
      'Stel my profiel op',
  'No jobs here yet. Check back soon.':
      'Nog geen werk hier nie. Kom kyk gou weer.',
  'Need to hire someone? Post a job':
      'Wil jy iemand aanstel? Plaas \'n werk',
  'Write what work you do, for example "Painter".':
      'Skryf watter werk jy doen, byvoorbeeld "Skilder".',
  'Profile saved':
      'Profiel gestoor',
  'Employers see this when you apply for a job. Save it once.':
      'Werkgewers sien dit wanneer jy aansoek doen. Stoor dit net een keer.',
  'What work do you do?':
      'Watter werk doen jy?',
  'e.g. Painter, Driver, Cleaner':
      'bv. Skilder, Bestuurder, Skoonmaker',
  'Your skills':
      'Jou vaardighede',
  'e.g. painting, walls, roofs':
      'bv. verf, mure, dakke',
  'Years of experience':
      'Jare ondervinding',
  'About you':
      'Oor jou',
  'Tell employers why they should choose you':
      'Vertel werkgewers hoekom hulle jou moet kies',
  'Save profile':
      'Stoor profiel',
  'Add a short comment (optional)':
      'Voeg \'n kort opmerking by (opsioneel)',
  'Send rating':
      'Stuur gradering',
  'Rate the employer':
      'Gradeer die werkgewer',
  'Thank you for your rating':
      'Dankie vir jou gradering',
  'years experience':
      'jaar ondervinding',
  'Rate this worker':
      'Gradeer hierdie werker',
  'You rated {0} stars':
      'Jy het {0} sterre gegee',
  'Voice search is not available on this phone.':
      'Stemsoektog is nie op hierdie foon beskikbaar nie.',
  'Speak to search':
      'Praat om te soek',
  'Split the fare':
      'Verdeel die tarief',
  'Each person pays {0}':
      'Elke persoon betaal {0}',
  'Each person pays the driver their share. Nothing is taken from your wallet for others.':
      'Elke persoon betaal die bestuurder sy deel. Niks word van jou beursie vir ander afgetrek nie.',
  'Our ko!ngo ride costs {0} in total. With {1} of us, each pays {2}.':
      'Ons ko!ngo-rit kos altesaam {0}. Met {1} van ons betaal elkeen {2}.',
  'Send to friends':
      'Stuur aan vriende',
  'National ID / Passport':
      'Nasionale ID / Paspoort',
  'Clear photo of the whole document':
      'Duidelike foto van die hele dokument',
  'Selfie holding your ID':
      'Selfie met jou ID in jou hand',
  'Your face and the ID must both be readable':
      'Jou gesig en die ID moet albei leesbaar wees',
  'Driving licence':
      'Rybewys',
  'Valid, for your type of vehicle':
      'Geldig, vir jou tipe voertuig',
  'Vehicle registration & insurance':
      'Voertuigregistrasie en versekering',
  'Registration paper and valid insurance':
      'Registrasiepapier en geldige versekering',
  'Police clearance':
      'Polisie-klaring',
  'Criminal record extract, not older than 6 months':
      'Misdaadrekord-uittreksel, nie ouer as 6 maande nie',
  'Technical inspection':
      'Tegniese inspeksie',
  'Roadworthy certificate':
      'Padwaardigheidsertifikaat',
  'If your vehicle needs one':
      'As jou voertuig een nodig het',
  'Professional driving permit (PrDP)':
      'Professionele rypermit (PrDP)',
  'For paid passenger transport':
      'Vir betaalde passasiersvervoer',
  'Business registration (RCCM)':
      'Besigheidsregistrasie (RCCM)',
  'Business registration (CIPC)':
      'Besigheidsregistrasie (CIPC)',
  'Registration paper of your business':
      'Registrasiepapier van jou besigheid',
  'Photo of your shop front':
      'Foto van jou winkelfront',
  'Show the sign and the entrance':
      'Wys die bord en die ingang',
  'Tax number (NIU)':
      'Belastingnommer (NIU)',
  'Tax number (SARS)':
      'Belastingnommer (SARS)',
  'Adds trust, not required':
      'Bou vertroue, nie verpligtend nie',
  'Health certificate':
      'Gesondheidsertifikaat',
  'Food sellers: certificate from your municipality':
      'Kosverkopers: sertifikaat van jou munisipaliteit',
  'Not accepted':
      'Nie aanvaar nie',
  'Waiting for review':
      'Wag vir hersiening',
  'Not uploaded':
      'Nie opgelaai nie',
  'Optional':
      'Opsioneel',
  'Upload':
      'Laai op',
  'Verify me':
      'Verifieer my',
  'You are verified. Customers see your badge.':
      'Jy is geverifieer. Kliënte sien jou kentekens.',
  '{0} of {1} required papers accepted. When all are accepted you get the Verified badge.':
      '{0} van {1} vereiste dokumente aanvaar. Wanneer almal aanvaar is, kry jy die Geverifieerde kentekens.',
  'Your papers are private. Only ko!ngo admin can see them.':
      'Jou dokumente is privaat. Net ko!ngo-admin kan dit sien.',
  'Verify my business':
      'Verifieer my besigheid',
  'Not allowed':
      'Nie toegelaat nie',
  'Trip not found':
      'Rit nie gevind nie',
  'This is not your trip':
      'Dit is nie jou rit nie',
  'User not found':
      'Gebruiker nie gevind nie',
  'Job not found':
      'Pos nie gevind nie',
  'Enter the customer\'s PIN to start':
      'Voer die kliënt se PIN in om te begin',
  'The trip has started. Only the driver can end it now.':
      'Die rit het begin. Net die bestuurder kan dit nou beëindig.',
  'This trip has already ended':
      'Hierdie rit het reeds geëindig',
  'This job is finished and cannot be changed':
      'Hierdie pos is klaar en kan nie verander word nie',
  'You can book up to 30 days ahead':
      'Jy kan tot 30 dae vooruit bespreek',
  'Pick a time at least 15 minutes from now':
      'Kies \'n tyd minstens 15 minute van nou af',
  'This request is no longer available':
      'Hierdie versoek is nie meer beskikbaar nie',
  'Sponsored spots are not available right now':
      'Geborgde plekke is nie nou beskikbaar nie',
  'You can rate after your trip':
      'Jy kan gradeer na jou rit',
  'You can rate after the trip':
      'Jy kan gradeer na die rit',
  'You can only rate after a hire on this job':
      'Jy kan eers gradeer na \'n aanstelling op hierdie pos',
  'This ride is booked for later':
      'Hierdie rit is vir later bespreek',
  'This is not your store':
      'Dit is nie jou winkel nie',
  'Only the driver can release this trip':
      'Net die bestuurder kan hierdie rit vrystel',
  'Only the driver can do this':
      'Net die bestuurder kan dit doen',
  'The price can\'t be changed':
      'Die prys kan nie verander word nie',
  'Shop deliveries have a fixed fee':
      'Winkelaflewerings het \'n vaste fooi',
  'This job is no longer open':
      'Hierdie pos is nie meer oop nie',
  'That price offer is no longer available':
      'Daardie prysaanbod is nie meer beskikbaar nie',
  'Cancel the order instead':
      'Kanselleer eerder die bestelling',
  'Start the trip first':
      'Begin eers die rit',
  'Start the return first':
      'Begin eers die terugkeer',
  'Pick up the parcel first':
      'Haal eers die pakkie op',
  'Enter an amount':
      'Voer \'n bedrag in',
  'Enter a price':
      'Voer \'n prys in',
  'Choose 1 to 5 stars':
      'Kies 1 tot 5 sterre',
  'Pick 1 to 5 stars':
      'Kies 1 tot 5 sterre',
  'Finish or cancel your current trip first':
      'Voltooi of kanselleer eers jou huidige rit',
  'You can withdraw up to {0}':
      'Jy kan tot {0} onttrek',
  'Choose between 1 and {0} weeks':
      'Kies tussen 1 en {0} weke',
  'Sign-up problem on our side':
      'Registrasieprobleem aan ons kant',
  'Our server could not finish this. Please try again in a moment, or contact ko!ngo support.':
      'Ons bediener kon dit nie voltooi nie. Probeer weer oor \'n oomblik of kontak ko!ngo-ondersteuning.',
  'No answer. The other person must have the trip open in the app.':
      'Geen antwoord nie. Die ander persoon moet die rit in die toep oop hê.',
  'Couldn\'t connect the call. Check that both phones have internet and try again.':
      'Kon nie die oproep koppel nie. Maak seker albei fone het internet en probeer weer.',
  'Couldn\'t start the microphone. Allow microphone access for ko!ngo in your phone settings.':
      'Kon nie die mikrofoon begin nie. Laat ko!ngo toe om die mikrofoon te gebruik in jou foon se instellings.',
};
