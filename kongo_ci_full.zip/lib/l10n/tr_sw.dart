// lib/l10n/tr_sw.dart
//
// Swahili for text written directly in the screens (see tr_fr.dart).
// Machine-assisted translation: have a native speaker review before release.

const Map<String, String> trSw = {
  '% OFF':
      '% PUNGUZO',
  '6-digit code':
      'Msimbo wa tarakimu 6',
  'A minimum fare of R {0} is required.':
      'Nauli ya chini ya {0} inahitajika.',
  'A profile photo is required to continue. You can skip for now, but you won\'t be able to book or accept rides.':
      'Picha ya wasifu inahitajika ili kuendelea. Unaweza kuruka kwa sasa, lakini hutaweza kuagiza wala kukubali safari.',
  'Access denied':
      'Ufikiaji umekataliwa',
  'Account':
      'Akaunti',
  'Account blocked':
      'Akaunti imezuiwa',
  'Account holder':
      'Mwenye akaunti',
  'Account holder name':
      'Jina la mwenye akaunti',
  'Account number':
      'Namba ya akaunti',
  'Account type':
      'Aina ya akaunti',
  'Account verification':
      'Uthibitishaji wa akaunti',
  'Active sessions':
      'Vipindi vinavyoendelea',
  'Add Vehicle':
      'Ongeza gari',
  'Add an extra layer of security':
      'Ongeza ulinzi wa ziada',
  'Add at least one contact so SOS can reach someone.':
      'Ongeza angalau mtu mmoja ili SOS iweze kumfikia mtu.',
  'Add contact':
      'Ongeza mtu wa kuwasiliana',
  'Add contacts so SOS can reach someone':
      'Ongeza watu ili SOS iweze kumfikia mtu',
  'Add emergency contacts who will be notified when you trigger SOS.':
      'Ongeza watu wa dharura watakaoarifiwa unapobonyeza SOS.',
  'Add your vehicle or bike to start accepting rides and deliveries.':
      'Ongeza gari au pikipiki yako ili uanze kukubali safari na usafirishaji.',
  'Add, edit, or remove':
      'Ongeza, hariri au ondoa',
  'Allow drivers to see your pickup location during trips.':
      'Ruhusu madereva waone mahali pa kukuchukua wakati wa safari.',
  'Already added':
      'Tayari imeongezwa',
  'Already exists':
      'Tayari ipo',
  'Already have an account? ':
      'Tayari una akaunti? ',
  'Already rated':
      'Tayari umetoa tathmini',
  'Already registered':
      'Tayari umesajiliwa',
  'Ambulance':
      'Gari la wagonjwa',
  'Amount (R)':
      'Kiasi',
  'An admin hasn\'t reviewed your account yet. Try again later.':
      'Msimamizi bado hajakagua akaunti yako. Jaribu tena baadaye.',
  'Analytics':
      'Takwimu',
  'Answer every question':
      'Jibu kila swali',
  'Apply Code':
      'Tumia msimbo',
  'Approve swap':
      'Kubali kubadilisha',
  'Are you safe?':
      'Uko salama?',
  'Are you sure you want to delete "{0}"? This cannot be undone.':
      'Una uhakika unataka kufuta "{0}"? Hili haliwezi kutenduliwa.',
  'At least 8 characters':
      'Angalau herufi 8',
  'Authentication failed':
      'Uthibitishaji umeshindikana',
  'Available balance':
      'Salio linalopatikana',
  'Available to withdraw':
      'Inapatikana kutolewa',
  'Available: {0}':
      'Inapatikana: {0}',
  'Await admin approval.':
      'Subiri idhini ya msimamizi.',
  'Awaiting admin approval':
      'Inasubiri idhini ya msimamizi',
  'Back':
      'Rudi',
  'Back to home':
      'Rudi nyumbani',
  'Back to start':
      'Rudi mwanzo',
  'Bank':
      'Benki',
  'Bank details':
      'Taarifa za benki',
  'Bank details saved':
      'Taarifa za benki zimehifadhiwa',
  'Bank name':
      'Jina la benki',
  'Bank reference (optional)':
      'Kumbukumbu ya benki (si lazima)',
  'Become a driver or courier':
      'Kuwa dereva au msafirishaji',
  'Blue Toyota Corolla — see you soon':
      'Toyota Corolla ya bluu — tuonane hivi punde',
  'Book a ride, order food,\ngroceries or send parcels.':
      'Agiza safari, chakula,\nmahitaji ya nyumbani au tuma vifurushi.',
  'Branch code (optional)':
      'Msimbo wa tawi (si lazima)',
  'Brief summary of your issue':
      'Muhtasari mfupi wa tatizo lako',
  'By continuing, you agree to our ':
      'Kwa kuendelea, unakubali ',
  'By continuing, you agree to our Terms of Service and Privacy Policy.':
      'Kwa kuendelea, unakubali Masharti ya Huduma na Sera ya Faragha.',
  'CANCEL — I\'M SAFE':
      'GHAIRI — NIKO SALAMA',
  'CLOSED':
      'IMEFUNGWA',
  'Calendar':
      'Kalenda',
  'Call':
      'Piga simu',
  'Call support':
      'Piga simu huduma kwa wateja',
  'Call us at {0}':
      'Tupigie kwa {0}',
  'Call {0}':
      'Mpigie {0}',
  'Call {0} manually.':
      'Mpigie {0} wewe mwenyewe.',
  'Call {0}?':
      'Mpigie {0}?',
  'Camera':
      'Kamera',
  'Can\'t call':
      'Haiwezekani kupiga',
  'Cancel':
      'Ghairi',
  'Cancel ride':
      'Ghairi safari',
  'Cancel scheduled ride?':
      'Ghairi safari iliyopangwa?',
  'Cancel this order?':
      'Ghairi agizo hili?',
  'Card (coming soon)':
      'Kadi (inakuja hivi karibuni)',
  'Cash deposit':
      'Kuweka pesa taslimu',
  'Change email':
      'Badilisha barua pepe',
  'Change password':
      'Badilisha nenosiri',
  'Change phone number':
      'Badilisha namba ya simu',
  'Chat':
      'Gumzo',
  'Chat messages':
      'Ujumbe wa gumzo',
  'Check back soon':
      'Angalia tena hivi punde',
  'Check back soon — we\'ll notify you when there\'s an offer.':
      'Angalia tena hivi punde — tutakujulisha kukiwa na ofa.',
  'Check your connection and try again.':
      'Angalia muunganisho wako na ujaribu tena.',
  'Check your inbox':
      'Angalia kisanduku chako cha barua',
  'Choose at least Ride or Delivery.':
      'Chagua angalau Safari au Usafirishaji.',
  'Choose what notifications you receive.':
      'Chagua arifa unazopokea.',
  'Choose your role':
      'Chagua jukumu lako',
  'Close':
      'Funga',
  'Code copied':
      'Msimbo umenakiliwa',
  'Code not found.':
      'Msimbo haukupatikana.',
  'Code: ':
      'Msimbo: ',
  'Colour':
      'Rangi',
  'Coming soon':
      'Inakuja hivi karibuni',
  'Communication':
      'Mawasiliano',
  'Complete all three steps before submitting.':
      'Kamilisha hatua zote tatu kabla ya kutuma.',
  'Complete your profile':
      'Kamilisha wasifu wako',
  'Confirm':
      'Thibitisha',
  'Confirm Password':
      'Thibitisha nenosiri',
  'Confirm deletion':
      'Thibitisha kufuta',
  'Confirm new password':
      'Thibitisha nenosiri jipya',
  'Connecting you to a better journey':
      'Tunakuunganisha na safari bora',
  'Contact added':
      'Mtu ameongezwa',
  'Contact details are unavailable right now.':
      'Taarifa za mawasiliano hazipatikani kwa sasa.',
  'Contact name':
      'Jina la mtu',
  'Contact removed':
      'Mtu ameondolewa',
  'Contact support':
      'Wasiliana na huduma kwa wateja',
  'Contact support for more information.':
      'Wasiliana na huduma kwa wateja kwa maelezo zaidi.',
  'Continue':
      'Endelea',
  'Control how new ride requests interrupt you.':
      'Dhibiti jinsi maombi mapya ya safari yanavyokukatiza.',
  'Control what alerts you receive while you\'re online.':
      'Dhibiti arifa unazopokea ukiwa mtandaoni.',
  'Copy':
      'Nakili',
  'Corporate Accounts':
      'Akaunti za kampuni',
  'Corporate Travel':
      'Safari za kikazi',
  'Could not load orders':
      'Imeshindwa kupakia maagizo',
  'Could not load preview':
      'Imeshindwa kupakia onyesho',
  'Could not load restaurants':
      'Imeshindwa kupakia migahawa',
  'Could not load the menu':
      'Imeshindwa kupakia menyu',
  'Could not load {0} stores':
      'Imeshindwa kupakia maduka ya {0}',
  'Couldn\'t complete request':
      'Imeshindwa kukamilisha ombi',
  'Couldn\'t dial':
      'Imeshindwa kupiga',
  'Couldn\'t open dialer':
      'Imeshindwa kufungua simu',
  'Couldn\'t open email':
      'Imeshindwa kufungua barua pepe',
  'Couldn\'t save':
      'Imeshindwa kuhifadhi',
  'Couldn\'t send request':
      'Imeshindwa kutuma ombi',
  'Couldn\'t submit payout':
      'Imeshindwa kutuma ombi la malipo',
  'Couldn\'t validate this code. Try again.':
      'Imeshindwa kuthibitisha msimbo huu. Jaribu tena.',
  'Current password':
      'Nenosiri la sasa',
  'Current session:':
      'Kipindi cha sasa:',
  'Customer':
      'Mteja',
  'DELETE':
      'FUTA',
  'DONE':
      'IMEKAMILIKA',
  'Day':
      'Siku',
  'Delete':
      'Futa',
  'Delete account':
      'Futa akaunti',
  'Delete account?':
      'Futa akaunti?',
  'Delete forever':
      'Futa kabisa',
  'Delete vehicle?':
      'Futa gari?',
  'Deliveries':
      'Usafirishaji',
  'Describe what happened in detail':
      'Eleza kilichotokea kwa undani',
  'Details':
      'Maelezo',
  'Disc':
      'Pungu.',
  'Discounts, referral bonuses, and seasonal deals.':
      'Punguzo, bonasi za rufaa na ofa za msimu.',
  'Documents (upload pictures)':
      'Nyaraka (pakia picha)',
  'Done':
      'Imekamilika',
  'Driver':
      'Dereva',
  'Driver Academy':
      'Chuo cha madereva',
  'Driver Terms':
      'Masharti ya dereva',
  'Driver Terms of Service':
      'Masharti ya huduma ya dereva',
  'Driver assigned, arriving, and trip status.':
      'Dereva amepangwa, anafika, na hali ya safari.',
  'Driver: {0}':
      'Dereva: {0}',
  'Drivers and couriers must complete KYC documentation.':
      'Madereva na wasafirishaji lazima wakamilishe nyaraka za utambulisho.',
  'Drop-off':
      'Mahali pa kushukia',
  'Dropoff location':
      'Mahali pa kushukia',
  'EFT / Bank transfer':
      'Uhamisho wa benki',
  'Earn R50 for each referral':
      'Pata bonasi kwa kila rufaa',
  'Earn money by driving\nor delivering.':
      'Pata pesa kwa kuendesha\nau kusafirisha.',
  'Earn with ko!ngo':
      'Pata mapato na ko!ngo',
  'Earnings':
      'Mapato',
  'Earnings & payouts':
      'Mapato na malipo',
  'Edit':
      'Hariri',
  'Edit name':
      'Hariri jina',
  'Email receipts':
      'Risiti kwa barua pepe',
  'Email support':
      'Tuma barua pepe kwa huduma kwa wateja',
  'Email us at {0}':
      'Tuandikie kwa {0}',
  'Emergency SOS':
      'SOS ya dharura',
  'Emergency contacts':
      'Watu wa dharura',
  'Emergency services and {0} have been alerted.':
      'Huduma za dharura na {0} wamearifiwa.',
  'Enter a code.':
      'Weka msimbo.',
  'Enter a valid amount':
      'Weka kiasi sahihi',
  'Enter an amount greater than zero.':
      'Weka kiasi kikubwa kuliko sifuri.',
  'Enter an amount within your available balance.':
      'Weka kiasi kisichozidi salio lako.',
  'Enter both a name and phone number.':
      'Weka jina na namba ya simu.',
  'Even with sound off, the full-screen ring still appears so you won\'t miss a ride.':
      'Hata sauti ikiwa imezimwa, mlio wa skrini nzima bado utaonekana ili usikose safari.',
  'Expense your rides':
      'Rudishiwa gharama za safari',
  'Expires: ':
      'Inaisha: ',
  'Expires: {0}':
      'Inaisha: {0}',
  'Family Profile':
      'Wasifu wa familia',
  'Family Profile will be available soon.':
      'Wasifu wa familia utapatikana hivi karibuni.',
  'Favorite Places':
      'Maeneo pendwa',
  'Favorite removed':
      'Eneo pendwa limeondolewa',
  'Fill bank details':
      'Jaza taarifa za benki',
  'Fill in all your bank information.':
      'Jaza taarifa zako zote za benki.',
  'First name':
      'Jina la kwanza',
  'First name required':
      'Jina la kwanza linahitajika',
  'Food delivery':
      'Kuletewa chakula',
  'Gallery':
      'Picha',
  'Get promotions based on your trips and favourite routes.':
      'Pata ofa kulingana na safari na njia unazopenda.',
  'Get smart ride suggestions':
      'Pata mapendekezo mahiri ya safari',
  'Get smart ride suggestions based on your calendar events.':
      'Pata mapendekezo ya safari kulingana na matukio ya kalenda yako.',
  'Great, I\'ll be at the gate':
      'Sawa, nitakuwa getini',
  'Have a prescription?':
      'Una cheti cha daktari?',
  'Help us improve ko!ngo with anonymous usage data.':
      'Tusaidie kuboresha ko!ngo kwa takwimu za matumizi zisizo na majina.',
  'Hi! I\'m 5 minutes away':
      'Habari! Nimebakiza dakika 5',
  'High':
      'Juu',
  'How would you like to use KO!NGO?':
      'Ungependa kutumia KO!NGO kwa namna gani?',
  'I\'m safe':
      'Niko salama',
  'I\'m safe — end alert':
      'Niko salama — maliza tahadhari',
  'ID, licence, logbook':
      'Kitambulisho, leseni, kadi ya gari',
  'If the store has already started preparing, you may be charged a fee.':
      'Kama duka limeshaanza kuandaa, unaweza kutozwa ada.',
  'In an emergency, tap the button below.':
      'Wakati wa dharura, gusa kitufe hapa chini.',
  'Interested? Email support@efuride.com to join the waitlist.':
      'Unavutiwa? Wasiliana na huduma kwa wateja ili ujiunge na orodha ya kusubiri.',
  'Invalid amount':
      'Kiasi si sahihi',
  'Invalid email':
      'Barua pepe si sahihi',
  'Invalid number':
      'Namba si sahihi',
  'Invalid phone':
      'Simu si sahihi',
  'Invalid phone number':
      'Namba ya simu si sahihi',
  'Item unavailable':
      'Bidhaa haipatikani',
  'KYC documents':
      'Nyaraka za utambulisho',
  'Keep':
      'Baki nayo',
  'Keep active':
      'Iache iendelee',
  'Keep alert active':
      'Acha tahadhari iendelee',
  'Keep it':
      'Baki nayo',
  'Keep old cart':
      'Baki na kikapu cha zamani',
  'Keep signed in':
      'Endelea kuingia',
  'Kenyatta Avenue, Nairobi':
      'Avenue de la Paix, Brazzaville',
  'LIVE':
      'MUBASHARA',
  'Language':
      'Lugha',
  'Language updated':
      'Lugha imesasishwa',
  'Legal':
      'Kisheria',
  'Licenses':
      'Leseni',
  'Limit reached':
      'Kikomo kimefikiwa',
  'Loading cards':
      'Inapakia kadi',
  'Loading list':
      'Inapakia orodha',
  'Location is off':
      'Huduma ya mahali imezimwa',
  'Location permission needed':
      'Ruhusa ya mahali inahitajika',
  'Log in':
      'Ingia',
  'Log out':
      'Toka',
  'Log out?':
      'Toka?',
  'Low':
      'Chini',
  'Loyalty':
      'Uaminifu',
  'Loyalty points':
      'Pointi za uaminifu',
  'Make (e.g. Toyota)':
      'Aina (mf. Toyota)',
  'Make and plate number are required.':
      'Aina na namba ya usajili vinahitajika.',
  'Make sure both passwords are identical.':
      'Hakikisha manenosiri yote mawili yanafanana.',
  'Manage and pay for your family\'s rides':
      'Simamia na ulipie safari za familia yako',
  'Manage business travel for your company — team members, consolidated billing, and reporting.':
      'Simamia safari za kikazi za kampuni yako — wafanyakazi, bili moja na ripoti.',
  'Manage contacts':
      'Simamia watu',
  'Manage devices signed in to your account':
      'Simamia vifaa vilivyoingia kwenye akaunti yako',
  'Manage emergency contacts':
      'Simamia watu wa dharura',
  'Manage permission settings':
      'Simamia ruhusa',
  'Manage store':
      'Simamia duka',
  'Manage your data and permissions':
      'Simamia data na ruhusa zako',
  'Mark yourself as safe?':
      'Jiweke kuwa salama?',
  'Marked safe':
      'Umewekwa salama',
  'Medium':
      'Wastani',
  'Merchant':
      'Mfanyabiashara',
  'Merchant · Orders':
      'Mfanyabiashara · Maagizo',
  'Merchant · Payouts':
      'Mfanyabiashara · Malipo',
  'Message':
      'Ujumbe',
  'Message copied':
      'Ujumbe umenakiliwa',
  'Messages from customers during an active trip.':
      'Ujumbe kutoka kwa wateja wakati wa safari.',
  'Messages from drivers during an active trip.':
      'Ujumbe kutoka kwa madereva wakati wa safari.',
  'Min {0} XAF':
      'Chini {0} XAF',
  'Missing bank details':
      'Taarifa za benki hazipo',
  'Missing details':
      'Taarifa hazijakamilika',
  'Missing documents':
      'Nyaraka hazipo',
  'Missing information':
      'Taarifa hazijakamilika',
  'Missing vehicle photo':
      'Picha ya gari haipo',
  'Model (e.g. Corolla)':
      'Mfano (mf. Corolla)',
  'Month':
      'Mwezi',
  'My Rides':
      'Safari zangu',
  'My Vehicles':
      'Magari yangu',
  'My vehicles':
      'Magari yangu',
  'NOTIFIED':
      'AMEARIFIWA',
  'Name too short':
      'Jina ni fupi mno',
  'Name updated':
      'Jina limesasishwa',
  'Navigation app':
      'Programu ya ramani',
  'Never miss a trip':
      'Usikose safari',
  'New email':
      'Barua pepe mpya',
  'New messages':
      'Ujumbe mpya',
  'New password':
      'Nenosiri jipya',
  'New ride requests':
      'Maombi mapya ya safari',
  'New to ko!ngo':
      'Mgeni kwenye ko!ngo',
  'Next settlement: Friday, in 3 days':
      'Malipo yajayo: Ijumaa, baada ya siku 3',
  'No active conversation.':
      'Hakuna mazungumzo yanayoendelea.',
  'No active ride':
      'Hakuna safari inayoendelea',
  'No balance to withdraw.':
      'Hakuna salio la kutoa.',
  'No completed trips yet':
      'Bado hakuna safari zilizokamilika',
  'No emergency contacts yet':
      'Bado hakuna watu wa dharura',
  'No favorite places yet':
      'Bado hakuna maeneo pendwa',
  'No internet connection':
      'Hakuna mtandao',
  'No items on the menu yet':
      'Bado hakuna bidhaa kwenye menyu',
  'No items yet':
      'Bado hakuna bidhaa',
  'No matches':
      'Hakuna kinacholingana',
  'No messages yet':
      'Bado hakuna ujumbe',
  'No payout requests':
      'Hakuna maombi ya malipo',
  'No phone number':
      'Hakuna namba ya simu',
  'No promotions right now':
      'Hakuna ofa kwa sasa',
  'No quiz for this module. It will be marked complete when you finish reading.':
      'Hakuna jaribio kwa somo hili. Litawekwa kuwa limekamilika ukimaliza kusoma.',
  'No restaurants nearby yet':
      'Bado hakuna migahawa karibu',
  'No scheduled rides':
      'Hakuna safari zilizopangwa',
  'No top-up requests':
      'Hakuna maombi ya kuongeza salio',
  'No transactions yet':
      'Bado hakuna miamala',
  'No trip to rate':
      'Hakuna safari ya kutathmini',
  'No trusted contacts yet':
      'Bado hakuna watu unaowaamini',
  'No vehicles added':
      'Hakuna magari yaliyoongezwa',
  'No {0} orders':
      'Hakuna maagizo ya {0}',
  'No {0} stores nearby':
      'Hakuna maduka ya {0} karibu',
  'Not signed in':
      'Hujaingia',
  'Nothing to rate':
      'Hakuna cha kutathmini',
  'Nothing to withdraw':
      'Hakuna cha kutoa',
  'Notifications':
      'Arifa',
  'Offers & codes':
      'Ofa na misimbo',
  'Ok!':
      'Sawa!',
  'Onboarding progress':
      'Maendeleo ya usajili',
  'Once you complete rides, they\'ll show up here with your net earnings.':
      'Ukikamilisha safari, zitaonekana hapa pamoja na mapato yako halisi.',
  'One last step':
      'Hatua moja ya mwisho',
  'Only drivers can request payouts':
      'Ni madereva pekee wanaoweza kuomba malipo',
  'Open Settings':
      'Fungua mipangilio',
  'Order cancelled':
      'Agizo limeghairiwa',
  'Order not found':
      'Agizo halikupatikana',
  'Order timeline':
      'Hatua za agizo',
  'Orders':
      'Maagizo',
  'Other ways to reach us':
      'Njia nyingine za kutufikia',
  'Our team typically responds within a few hours.':
      'Timu yetu kwa kawaida hujibu ndani ya saa chache.',
  'Our team will respond within a few hours.':
      'Timu yetu itajibu ndani ya saa chache.',
  'Owner doc':
      'Hati ya mmiliki',
  'Page not found':
      'Ukurasa haukupatikana',
  'Passenger':
      'Abiria',
  'Passkeys and verification':
      'Funguo za siri na uthibitishaji',
  'Password changed':
      'Nenosiri limebadilishwa',
  'Password must be at least 8 characters.':
      'Nenosiri lazima liwe na angalau herufi 8.',
  'Password too short':
      'Nenosiri ni fupi mno',
  'Password, sessions, 2FA':
      'Nenosiri, vipindi, uthibitishaji wa hatua mbili',
  'Passwords don\'t match':
      'Manenosiri hayalingani',
  'Payment':
      'Malipo',
  'Payment method':
      'Njia ya malipo',
  'Payout account':
      'Akaunti ya kupokea malipo',
  'Payout confirmations':
      'Uthibitisho wa malipo',
  'Payout failed — verify bank details and retry.':
      'Malipo yameshindikana — hakiki taarifa za benki kisha ujaribu tena.',
  'Payout requested':
      'Malipo yameombwa',
  'Payouts':
      'Malipo',
  'Payouts, tips, and fare credits will appear here.':
      'Malipo, bakshishi na marejesho ya nauli yataonekana hapa.',
  'Peak-hour bonuses, referral rewards, and ko!ngo news.':
      'Bonasi za saa za msongamano, zawadi za rufaa na habari za ko!ngo.',
  'Pending admin review.':
      'Inasubiri ukaguzi wa msimamizi.',
  'Permanently remove your account':
      'Futa akaunti yako kabisa',
  'Personalised offers':
      'Ofa za kibinafsi',
  'Phone number':
      'Namba ya simu',
  'Phone updated':
      'Simu imesasishwa',
  'Photo from your shopper':
      'Picha kutoka kwa mnunuzi wako',
  'Photo required':
      'Picha inahitajika',
  'Photo saved':
      'Picha imehifadhiwa',
  'Photo selected':
      'Picha imechaguliwa',
  'Photo updated':
      'Picha imesasishwa',
  'Pick a future time':
      'Chagua muda ujao',
  'Pick a rating':
      'Chagua tathmini',
  'Pick a service':
      'Chagua huduma',
  'Pick a time':
      'Chagua muda',
  'Pickup':
      'Kuchukuliwa',
  'Pickup location':
      'Mahali pa kuchukuliwa',
  'Plate Number (e.g. CA123-45)':
      'Namba ya usajili (mf. BZ-1234-AB)',
  'Plate: {0}':
      'Usajili: {0}',
  'Play an audible alert when a new ride comes in.':
      'Toa sauti ya tahadhari safari mpya ikiingia.',
  'Please check the number and try again.':
      'Tafadhali hakiki namba kisha ujaribu tena.',
  'Please check your details and try again.':
      'Tafadhali hakiki taarifa zako kisha ujaribu tena.',
  'Please check your network and try again.':
      'Tafadhali hakiki mtandao wako kisha ujaribu tena.',
  'Please choose an option for each.':
      'Tafadhali chagua jibu kwa kila moja.',
  'Please enter a valid email address.':
      'Tafadhali weka barua pepe sahihi.',
  'Please enter a valid phone number.':
      'Tafadhali weka namba ya simu sahihi.',
  'Please enter at least 2 characters.':
      'Tafadhali weka angalau herufi 2.',
  'Please enter both pickup and dropoff.':
      'Tafadhali weka mahali pa kuchukuliwa na pa kushukia.',
  'Please enter your first name.':
      'Tafadhali weka jina lako la kwanza.',
  'Please fill in both the subject and message.':
      'Tafadhali jaza kichwa na ujumbe.',
  'Please select when you want the ride.':
      'Tafadhali chagua lini unataka safari.',
  'Please sign in again to continue.':
      'Tafadhali ingia tena ili kuendelea.',
  'Please sign in again.':
      'Tafadhali ingia tena.',
  'Please sign in to use chat.':
      'Tafadhali ingia ili utumie gumzo.',
  'Please sign in.':
      'Tafadhali ingia.',
  'Please try again in a moment.':
      'Tafadhali jaribu tena baada ya muda mfupi.',
  'Please turn on GPS so we can find you.':
      'Tafadhali washa GPS ili tukupate.',
  'Please upload a photo of the vehicle.':
      'Tafadhali pakia picha ya gari.',
  'Please upload all required documents first.':
      'Tafadhali pakia nyaraka zote zinazohitajika kwanza.',
  'Police':
      'Polisi',
  'Prescription on file':
      'Cheti cha daktari kimehifadhiwa',
  'Price impact':
      'Athari kwa bei',
  'Priority':
      'Kipaumbele',
  'Privacy':
      'Faragha',
  'Privacy Policy':
      'Sera ya faragha',
  'Profile':
      'Wasifu',
  'Profile not found':
      'Wasifu haukupatikana',
  'Promo applied! You save {0}.':
      'Ofa imetumika! Umeokoa {0}.',
  'Promo code  applied!':
      'Msimbo wa ofa umetumika!',
  'Promo codes, offers, and savings':
      'Misimbo ya ofa, ofa na akiba',
  'Promotions':
      'Ofa',
  'Promotions & Offers':
      'Ofa na matoleo',
  'Promotions and bonuses':
      'Ofa na bonasi',
  'Promotions and offers':
      'Ofa na matoleo',
  'QUICK QUIZ':
      'JARIBIO FUPI',
  'R50 credited after your friend\'s first completed ride.':
      'Bonasi itawekwa baada ya safari ya kwanza ya rafiki yako kukamilika.',
  'Rate trip':
      'Tathmini safari',
  'Rating':
      'Tathmini',
  'Ref: {0}':
      'Kumb.: {0}',
  'Refer & Earn':
      'Alika na upate',
  'Refer a Friend':
      'Alika rafiki',
  'Refer a friend':
      'Alika rafiki',
  'Refresh':
      'Onyesha upya',
  'Rejected — please edit and resubmit.':
      'Imekataliwa — tafadhali hariri na utume tena.',
  'Remove':
      'Ondoa',
  'Remove contact?':
      'Ondoa mtu?',
  'Remove favorite?':
      'Ondoa eneo pendwa?',
  'Replace':
      'Badilisha',
  'Request Payout':
      'Omba malipo',
  'Request a payout and we\'ll show its status here.':
      'Omba malipo na tutaonyesha hali yake hapa.',
  'Request payout':
      'Omba malipo',
  'Request timed out':
      'Muda wa ombi umeisha',
  'Required':
      'Inahitajika',
  'Resend code':
      'Tuma msimbo tena',
  'Resend code in {0}s':
      'Tuma msimbo tena baada ya sekunde {0}',
  'Retry':
      'Jaribu tena',
  'Retry payout':
      'Jaribu malipo tena',
  'Review my documents':
      'Kagua nyaraka zangu',
  'Ride  •  Deliver  •  Move':
      'Safiri  •  Safirisha  •  Songa',
  'Ride not found':
      'Safari haikupatikana',
  'Ride removed':
      'Safari imeondolewa',
  'Ride requests, chat, bonuses':
      'Maombi ya safari, gumzo, bonasi',
  'Ride scheduled':
      'Safari imepangwa',
  'Ride updates':
      'Taarifa za safari',
  'Rides':
      'Safari',
  'Rides you pay for and top-ups you make will appear here.':
      'Safari ulizolipia na salio ulioongeza vitaonekana hapa.',
  'Ring + push when a customer books nearby. Turn off and you won\'t see new rides.':
      'Mlio + arifa mteja aliye karibu anapoagiza. Ukizima, hutaona safari mpya.',
  'Ring sound':
      'Sauti ya mlio',
  'SHOPPER SUGGESTS':
      'MNUNUZI ANAPENDEKEZA',
  'SOS ACTIVE':
      'SOS INAENDELEA',
  'STEP {0}':
      'HATUA {0}',
  'Safety':
      'Usalama',
  'Safety center':
      'Kituo cha usalama',
  'Save':
      'Hifadhi',
  'Save & continue to vehicle':
      'Hifadhi na uendelee kwa gari',
  'Save draft':
      'Hifadhi rasimu',
  'Save frequently visited places for faster booking.':
      'Hifadhi maeneo unayotembelea mara kwa mara ili uagize haraka.',
  'Save on every ride':
      'Okoa kwenye kila safari',
  'Saved bank details will be used next time.':
      'Taarifa za benki zilizohifadhiwa zitatumika wakati ujao.',
  'Saved places':
      'Maeneo yaliyohifadhiwa',
  'Say hi to {0} to coordinate pickup.':
      'Msalimie {0} ili mpange kuchukuliwa.',
  'Schedule':
      'Panga',
  'Schedule a Ride':
      'Panga safari',
  'Schedule a ride':
      'Panga safari',
  'Schedule a ride for later':
      'Panga safari ya baadaye',
  'Scheduled Rides':
      'Safari zilizopangwa',
  'Seats / capacity':
      'Viti / uwezo',
  'See your ride statistics':
      'Ona takwimu za safari zako',
  'Send an EFT to the business account, then submit this form with your reference. Admin will confirm.':
      'Fanya uhamisho wa benki kwenye akaunti ya biashara, kisha tuma fomu hii na kumbukumbu yako. Msimamizi atathibitisha.',
  'Send code':
      'Tuma msimbo',
  'Send link':
      'Tuma kiungo',
  'Send trip summaries to your registered email.':
      'Tuma muhtasari wa safari kwa barua pepe yako.',
  'Services this vehicle can serve':
      'Huduma ambazo gari hili linaweza kutoa',
  'Session expired':
      'Kipindi kimeisha',
  'Settings':
      'Mipangilio',
  'Settlement history':
      'Historia ya malipo',
  'Setup is available from your Supabase dashboard. Coming to the app soon.':
      'Mipangilio inapatikana kwenye dashibodi. Inakuja kwenye programu hivi karibuni.',
  'Share Referral Link':
      'Shiriki kiungo cha rufaa',
  'Share it with a friend to earn R50.':
      'Mshirikishe rafiki upate bonasi.',
  'Share link: efuride://track/{0}':
      'Kiungo: efuride://track/{0}',
  'Share live location':
      'Shiriki mahali ulipo moja kwa moja',
  'Share more feedback (optional)':
      'Toa maoni zaidi (si lazima)',
  'Share your code and earn R50 for each friend who takes their first ride.':
      'Shiriki msimbo wako upate bonasi kwa kila rafiki anayefanya safari yake ya kwanza.',
  'Shop & pick':
      'Nunua na uchague',
  'Shopper':
      'Mnunuzi',
  'Sign Out':
      'Toka',
  'Sign in and security':
      'Kuingia na usalama',
  'Sign out':
      'Toka',
  'Sign out?':
      'Toka?',
  'Skip':
      'Ruka',
  'Skip for now':
      'Ruka kwa sasa',
  'Skip item':
      'Ruka bidhaa',
  'Some required details are missing. Please try again.':
      'Baadhi ya taarifa zinazohitajika hazipo. Tafadhali jaribu tena.',
  'Something went wrong':
      'Kuna tatizo',
  'Something went wrong on our side. Please try again.':
      'Kuna tatizo upande wetu. Tafadhali jaribu tena.',
  'Sound & alerts':
      'Sauti na tahadhari',
  'Standard SMS rates may apply. We\'ll never share your number.':
      'Gharama za kawaida za SMS zinaweza kutumika. Hatutawahi kushiriki namba yako.',
  'Start a new cart?':
      'Anzisha kikapu kipya?',
  'Start new':
      'Anza upya',
  'Stay':
      'Baki',
  'Stay where you are. Help is on the way.':
      'Baki ulipo. Msaada unakuja.',
  'Step 1 · Upload your documents':
      'Hatua ya 1 · Pakia nyaraka zako',
  'Still pending':
      'Bado inasubiri',
  'Subject':
      'Kichwa',
  'Submit a support ticket':
      'Tuma ombi la msaada',
  'Submit for admin approval':
      'Tuma kwa idhini ya msimamizi',
  'Submit for approval':
      'Tuma ili kuidhinishwa',
  'Submit payout request':
      'Tuma ombi la malipo',
  'Submit rating':
      'Tuma tathmini',
  'Substitution':
      'Bidhaa mbadala',
  'Substitution request':
      'Ombi la bidhaa mbadala',
  'Suggest rides ahead of your meetings and appointments.':
      'Pendekeza safari kabla ya mikutano na miadi yako.',
  'Support':
      'Msaada',
  'Surname':
      'Jina la ukoo',
  'Sync calendar':
      'Unganisha kalenda',
  'TAP FOR SOS':
      'GUSA KWA SOS',
  'TEAM MEMBER SIGN-IN':
      'KUINGIA KWA WAFANYAKAZI',
  'TRIGGER SOS':
      'BONYEZA SOS',
  'TRIGGERING SOS':
      'SOS INAWASHWA',
  'Take a clear selfie so drivers and passengers can recognise you during trips.':
      'Piga picha yako iliyo wazi ili madereva na abiria wakutambue wakati wa safari.',
  'Take a selfie to continue.':
      'Piga picha yako ili kuendelea.',
  'Take your photo':
      'Piga picha yako',
  'Tap a star to rate your customer.':
      'Gusa nyota ili umtathmini mteja wako.',
  'Tap a star to rate your driver.':
      'Gusa nyota ili umtathmini dereva wako.',
  'Tap a star to rate your experience.':
      'Gusa nyota ili utathmini uzoefu wako.',
  'Tap once — we handle the rest':
      'Gusa mara moja — tutashughulikia yaliyobaki',
  'Tell us more about your experience':
      'Tueleze zaidi kuhusu uzoefu wako',
  'Terms':
      'Masharti',
  'Terms of Service':
      'Masharti ya huduma',
  'Thanks for rating!':
      'Asante kwa tathmini!',
  'Thanks for riding with ko!ngo.':
      'Asante kwa kusafiri na ko!ngo.',
  'Thanks — your rating was recorded.':
      'Asante — tathmini yako imehifadhiwa.',
  'That number is already in your list.':
      'Namba hiyo tayari iko kwenye orodha yako.',
  'The place has been removed from your list.':
      'Mahali pameondolewa kwenye orodha yako.',
  'The scheduled time must be in the future.':
      'Muda uliopangwa lazima uwe ujao.',
  'The server took too long to respond. Try again.':
      'Seva imechukua muda mrefu kujibu. Jaribu tena.',
  'The store has been notified.':
      'Duka limearifiwa.',
  'There\'s no trip to chat about yet.':
      'Bado hakuna safari ya kuzungumzia.',
  'They will no longer be notified.':
      'Hawataarifiwa tena.',
  'They\'ll be notified when you trigger SOS.':
      'Wataarifiwa unapobonyeza SOS.',
  'This action cannot be undone.':
      'Hatua hii haiwezi kutenduliwa.',
  'This device':
      'Kifaa hiki',
  'This email is already in use. Try signing in.':
      'Barua pepe hii tayari inatumika. Jaribu kuingia.',
  'This permanently deletes your account, trip history, and saved data.':
      'Hii itafuta kabisa akaunti yako, historia ya safari na data iliyohifadhiwa.',
  'This place will be removed from your list.':
      'Mahali hapa pataondolewa kwenye orodha yako.',
  'This promo has expired.':
      'Ofa hii imeisha muda.',
  'This promo has reached its limit.':
      'Ofa hii imefikia kikomo.',
  'This promo hasn\'t started yet.':
      'Ofa hii bado haijaanza.',
  'This promo is not active right now.':
      'Ofa hii haitumiki kwa sasa.',
  'This record already exists. Try a different value.':
      'Kumbukumbu hii tayari ipo. Jaribu thamani nyingine.',
  'This scheduled ride will be removed and will not be booked.':
      'Safari hii iliyopangwa itaondolewa na haitaagizwa.',
  'This trip may have been removed.':
      'Huenda safari hii imeondolewa.',
  'This will alert your emergency contacts and our support team with your location. Use only in a real emergency.':
      'Hii itawatahadharisha watu wako wa dharura na timu yetu ya msaada pamoja na mahali ulipo. Tumia tu wakati wa dharura halisi.',
  'This will end the SOS alert. Your contacts will be told you\'re safe.':
      'Hii itamaliza tahadhari ya SOS. Watu wako wataambiwa uko salama.',
  'This will open your phone\'s dialer with the number pre-filled.':
      'Hii itafungua simu yako ikiwa na namba tayari.',
  'Ticket submitted':
      'Ombi limetumwa',
  'Tier benefits':
      'Faida za ngazi',
  'Top up':
      'Ongeza salio',
  'Top up now':
      'Ongeza salio sasa',
  'Top up your wallet':
      'Ongeza salio la pochi yako',
  'Top-up request sent':
      'Ombi la kuongeza salio limetumwa',
  'Top-ups':
      'Uongezaji salio',
  'Total':
      'Jumla',
  'Tracking services':
      'Huduma za ufuatiliaji',
  'Transactions':
      'Miamala',
  'Trigger SOS':
      'Bonyeza SOS',
  'Trigger SOS?':
      'Bonyeza SOS?',
  'Trip complete':
      'Safari imekamilika',
  'Trip completed':
      'Safari imekamilika',
  'Trip completed!':
      'Safari imekamilika!',
  'Try again':
      'Jaribu tena',
  'Two-factor authentication':
      'Uthibitishaji wa hatua mbili',
  'Type DELETE in capitals to confirm.':
      'Andika FUTA kwa herufi kubwa ili kuthibitisha.',
  'Type a message...':
      'Andika ujumbe…',
  'Type a message…':
      'Andika ujumbe…',
  'Typing':
      'Anaandika',
  'Unlock exclusive benefits':
      'Pata faida za kipekee',
  'Update the email on your account':
      'Badilisha barua pepe ya akaunti yako',
  'Update your account password':
      'Badilisha nenosiri la akaunti yako',
  'Uploaded':
      'Imepakiwa',
  'Usage analytics':
      'Takwimu za matumizi',
  'Use your new password next time you log in.':
      'Tumia nenosiri lako jipya utakapoingia tena.',
  'VERIFIED':
      'IMETHIBITISHWA',
  'Vehicle':
      'Gari',
  'Vehicle class':
      'Daraja la gari',
  'Vehicle deleted':
      'Gari limefutwa',
  'Vehicle photo':
      'Picha ya gari',
  'Verify & continue':
      'Thibitisha na uendelee',
  'View uploaded file':
      'Ona faili lililopakiwa',
  'View your tier and rewards':
      'Ona ngazi na zawadi zako',
  'Wallet':
      'Pochi',
  'Wallet balance':
      'Salio la pochi',
  'We can\'t dial that phone number.':
      'Hatuwezi kupiga namba hiyo.',
  'We couldn\'t find a completed ride.':
      'Hatukupata safari iliyokamilika.',
  'We couldn\'t reach our servers. Please try again.':
      'Hatukuweza kufikia seva zetu. Tafadhali jaribu tena.',
  'We never sell your personal data.':
      'Hatuuzi kamwe data yako binafsi.',
  'We sent a confirmation link to your new email address.':
      'Tumetuma kiungo cha uthibitisho kwa barua pepe yako mpya.',
  'We use your phone for trip updates and driver contact.':
      'Tunatumia simu yako kwa taarifa za safari na mawasiliano na dereva.',
  'We\'ll dispatch a driver near the time.':
      'Tutatuma dereva karibu na muda huo.',
  'We\'ll process it within 2 business days.':
      'Tutalishughulikia ndani ya siku 2 za kazi.',
  'Week':
      'Wiki',
  'Weekly settlement':
      'Malipo ya kila wiki',
  'Weekly settlement · PawaPay':
      'Malipo ya kila wiki · PawaPay',
  'Welcome aboard. Taking you to your dashboard.':
      'Karibu. Tunakupeleka kwenye dashibodi yako.',
  'Welcome to ko!ngo Academy':
      'Karibu Chuo cha ko!ngo',
  'What you\'ll be able to do':
      'Utakachoweza kufanya',
  'When a payout is processed or rejected.':
      'Malipo yanapofanyika au kukataliwa.',
  'When you submit a top-up, you\'ll be able to track its approval here.':
      'Ukituma ombi la kuongeza salio, utaweza kufuatilia idhini yake hapa.',
  'Which app should open when you tap "Start trip"?':
      'Programu ipi ifunguke unapogusa "Anza safari"?',
  'Work Profile':
      'Wasifu wa kazi',
  'Wrong email or password':
      'Barua pepe au nenosiri si sahihi',
  'YOU ORDERED':
      'ULICHOAGIZA',
  'Year':
      'Mwaka',
  'You':
      'Wewe',
  'You can save up to {0} contacts.':
      'Unaweza kuhifadhi hadi watu {0}.',
  'You can sign back in anytime to check your approval status.':
      'Unaweza kuingia tena wakati wowote kuona hali ya idhini yako.',
  'You don\'t have a balance to pay out yet.':
      'Bado huna salio la kulipwa.',
  'You have arrived!':
      'Umefika!',
  'You will stop receiving new orders until you sign in again.':
      'Hutapokea maagizo mapya hadi utakapoingia tena.',
  'You\'ll need to sign in again to book rides.':
      'Utahitaji kuingia tena ili kuagiza safari.',
  'You\'ll stop receiving ride requests until you sign in again.':
      'Hutapokea maombi ya safari hadi utakapoingia tena.',
  'You\'re all set.':
      'Kila kitu kiko tayari.',
  'You\'re approved!':
      'Umeidhinishwa!',
  'You\'re not a participant in this trip.':
      'Wewe si mshiriki wa safari hii.',
  'You\'ve already rated this trip. Thanks for the feedback!':
      'Tayari umetathmini safari hii. Asante kwa maoni yako!',
  'You\'ve already used this promo.':
      'Tayari umetumia ofa hii.',
  'Your contacts have been notified.':
      'Watu wako wamearifiwa.',
  'Your data export':
      'Nakala ya data yako',
  'Your device may not have a phone app. Please dial manually.':
      'Huenda kifaa chako hakina programu ya simu. Tafadhali piga mwenyewe.',
  'Your documents have been submitted. An administrator will review them shortly — usually within a few hours.':
      'Nyaraka zako zimetumwa. Msimamizi atazikagua hivi karibuni — kwa kawaida ndani ya saa chache.',
  'Your earnings have been added to your wallet.':
      'Mapato yako yameongezwa kwenye pochi yako.',
  'Your emergency contacts':
      'Watu wako wa dharura',
  'Your emergency contacts and our support team have been alerted with your location.':
      'Watu wako wa dharura na timu yetu ya msaada wametahadharishwa pamoja na mahali ulipo.',
  'Your emergency contacts and our support team will be notified with your location.':
      'Watu wako wa dharura na timu yetu ya msaada wataarifiwa pamoja na mahali ulipo.',
  'Your feedback helps improve ko!ngo.':
      'Maoni yako yanasaidia kuboresha ko!ngo.',
  'Your feedback helps keep ko!ngo safe.':
      'Maoni yako yanasaidia ko!ngo kuwa salama.',
  'Your name has been saved.':
      'Jina lako limehifadhiwa.',
  'Your new profile photo is live.':
      'Picha yako mpya ya wasifu iko hewani.',
  'Your number stays hidden. Only the call is connected.':
      'Namba yako inabaki siri. Ni simu tu inayounganishwa.',
  'Your personal data':
      'Data yako binafsi',
  'Your phone number has been saved.':
      'Namba yako ya simu imehifadhiwa.',
  'Your photo is visible to drivers and passengers during trips.':
      'Picha yako inaonekana kwa madereva na abiria wakati wa safari.',
  'Your scheduled ride has been cancelled.':
      'Safari yako iliyopangwa imeghairiwa.',
  'Your trips will appear here':
      'Safari zako zitaonekana hapa',
  'Your vehicle has been removed.':
      'Gari lako limeondolewa.',
  'Your vehicle will be reviewed by an admin before it becomes active.':
      'Gari lako litakaguliwa na msimamizi kabla ya kuanza kutumika.',
  'e.g. 11 2nd Street, Firgrove':
      'mf. 11 rue Mbochi, Moungali',
  'e.g. 45 Main Rd, CBD':
      'mf. 45 avenue de la Paix, Centre-ville',
  'ko!ngo Plus will be available soon.':
      'ko!ngo Plus itapatikana hivi karibuni.',
  'ko!ngo needs your location to find nearby drivers.':
      'ko!ngo inahitaji mahali ulipo ili kupata madereva walio karibu.',
  'typing…':
      'anaandika…',
  '{0} XAF pending':
      '{0} XAF zinasubiri',
  '{0} active':
      '{0} hai',
  '{0} has a suggestion':
      '{0} ana pendekezo',
  '{0} hasn\'t added a phone number to their profile.':
      '{0} hajaongeza namba ya simu kwenye wasifu wake.',
  '{0} is ready to paste.':
      '{0} iko tayari kubandikwa.',
  '{0} is typing…':
      '{0} anaandika…',
  '{0} km':
      'km {0}',
  '{0} min':
      'dk {0}',
  '{0} new':
      '{0} mpya',
  '{0} of {1} complete':
      '{0} kati ya {1} zimekamilika',
  '{0} of {1} modules complete':
      'Masomo {0} kati ya {1} yamekamilika',
  '{0} points':
      'Pointi {0}',
  '{0} points to {1}':
      'Pointi {0} hadi {1}',
  '💬 New message from {0}':
      '💬 Ujumbe mpya kutoka kwa {0}',
  '🚨 SOS activated':
      '🚨 SOS imewashwa',
  'Are you sure you want to remove "{0}"?':
      'Una uhakika unataka kumwondoa "{0}"?',
  'The price has changed':
      'Bei imebadilika',
  'Please go back and check the price again.':
      'Tafadhali rudi nyuma uangalie bei tena.',
  'The lowest price for this trip is {0}. Please go back and check the price again.':
      'Bei ya chini kwa safari hii ni {0}. Tafadhali rudi nyuma uangalie bei tena.',
  'Not enough money in your wallet':
      'Hakuna pesa za kutosha kwenye pochi yako',
  'Top up your wallet or choose another way to pay.':
      'Ongeza pesa kwenye pochi au chagua njia nyingine ya kulipa.',
  'The picture could not be uploaded':
      'Picha haikuweza kupakiwa',
  '{0}\n\nYou can save the product now and add the picture later.':
      '{0}\n\nUnaweza kuhifadhi bidhaa sasa na kuongeza picha baadaye.',
  'Save without picture':
      'Hifadhi bila picha',
  'OK':
      'Sawa',
  'Choose on map':
      'Chagua kwenye ramani',
  'Tap the map where you want to be picked up':
      'Gusa ramani mahali unapotaka kuchukuliwa',
  'Tap the map where you are going':
      'Gusa ramani mahali unapoenda',
  'Pinned location':
      'Mahali palipowekwa alama',
  'Clear':
      'Futa',
  'Use my current location':
      'Tumia mahali nilipo sasa',
  'Street, suburb or landmark':
      'Mtaa, kitongoji au alama',
  'No places found. Try a street name or landmark.':
      'Hakuna mahali palipopatikana. Jaribu jina la mtaa au alama.',
  'Current location':
      'Mahali ulipo sasa',
  'Closed':
      'Imefungwa',
  'Nearby pharmacies':
      'Maduka ya dawa karibu',
  'Stores near you':
      'Maduka karibu nawe',
  'Country':
      'Nchi',
  'Choose your country':
      'Chagua nchi yako',
  'Add a place':
      'Ongeza mahali',
  'Name this place':
      'Pa jina mahali hapa',
  'Home':
      'Nyumbani',
  'Work':
      'Kazini',
  'e.g. Mom\'s place':
      'mf. Kwa mama',
  'Place':
      'Mahali',
  'Drivers, shoppers and store owners use a separate ko!ngo account, with a different email address. Your customer account stays as it is.':
      'Madereva, wanunuzi na wamiliki wa maduka hutumia akaunti tofauti ya ko!ngo, yenye barua pepe tofauti. Akaunti yako ya mteja inabaki ilivyo.',
  'To create it, you will be signed out of this account. You can sign back in any time.':
      'Ili kuiunda, utaondolewa kwenye akaunti hii. Unaweza kuingia tena wakati wowote.',
  'Sign out and create partner account':
      'Toka na uunde akaunti ya mshirika',
  'Stay signed in':
      'Endelea kuingia',
  'Invite friends and earn ride credit':
      'Alika marafiki upate salio la safari',
  'No offers right now':
      'Hakuna ofa kwa sasa',
  'New promo codes will show here.':
      'Misimbo mipya ya ofa itaonekana hapa.',
  '{0}% off':
      'Punguzo la {0}%',
  '{0} off':
      'Punguzo la {0}',
  'Valid until {0}':
      'Inatumika hadi {0}',
  'Minimum {0}':
      'Kiwango cha chini {0}',
  'Code {0} copied. Paste it when you book or check out.':
      'Msimbo {0} umenakiliwa. Ubandike unapoagiza au kulipa.',
  'My orders':
      'Oda zangu',
  'Active':
      'Zinazoendelea',
  'Past':
      'Zilizopita',
  'No active orders':
      'Hakuna oda zinazoendelea',
  'No past orders yet':
      'Bado hakuna oda zilizopita',
  'Order food, groceries or medicine from the Home tab.':
      'Agiza chakula, mahitaji au dawa kutoka ukurasa wa Nyumbani.',
  '{0} items':
      'Bidhaa {0}',
  'Order placed':
      'Oda imewekwa',
  'Being prepared':
      'Inaandaliwa',
  'Ready for pickup':
      'Tayari kuchukuliwa',
  'On the way':
      'Iko njiani',
  'Delivered':
      'Imefikishwa',
  'Returned to office':
      'Imerudishwa ofisini',
  'Cancelled':
      'Imeghairiwa',
  'Refunded':
      'Imerejeshewa pesa',
  'Order payment':
      'Malipo ya oda',
  'Ride payment':
      'Malipo ya safari',
  'Refund':
      'Marejesho',
  'Bonus':
      'Bonasi',
  'Top-up':
      'Kuongeza pesa',
  'Amount':
      'Kiasi',
  'How did you pay?':
      'Ulilipaje?',
  'Bank transfer':
      'Uhamisho wa benki',
  'Payment reference (optional)':
      'Kumbukumbu ya malipo (si lazima)',
  'Send top-up request':
      'Tuma ombi la kuongeza pesa',
  'Pay ko!ngo by bank transfer or cash, then send this request. Your balance goes up when ko!ngo confirms the payment.':
      'Lipa ko!ngo kwa benki au taslimu, kisha tuma ombi hili. Salio lako litaongezeka ko!ngo ikithibitisha malipo.',
  'Your balance goes up when ko!ngo confirms it.':
      'Salio lako litaongezeka ko!ngo ikithibitisha.',
  'Waiting for approval':
      'Inasubiri kuidhinishwa',
  'Activity':
      'Shughuli',
  '{0} waiting for approval':
      '{0} inasubiri kuidhinishwa',
  'Add money to pay for rides and orders without cash.':
      'Ongeza pesa ili kulipia safari na oda bila taslimu.',
  'Payments, top-ups and refunds will show here.':
      'Malipo, kuongeza pesa na marejesho yataonekana hapa.',
  'Wallet & payouts':
      'Pochi na malipo',
  'Payouts on the way':
      'Malipo yanayokuja',
  'Trip earnings':
      'Mapato ya safari',
  'Past payouts':
      'Malipo yaliyopita',
  'Wallet {0} · Unpaid trips {1}':
      'Pochi {0} · Safari ambazo hazijalipwa {1}',
  'ko!ngo fee {0}% · {1} completed trips':
      'Ada ya ko!ngo {0}% · safari {1} zimekamilika',
  'Completed trips and what you earned on each will show here.':
      'Safari ulizokamilisha na mapato yako yataonekana hapa.',
  'Payout':
      'Malipo',
  'Tip':
      'Bakshishi',
  'Credit':
      'Salio',
  'Deduction':
      'Makato',
  'Rewards':
      'Zawadi',
  'App':
      'Programu',
  'More':
      'Zaidi',
  'Privacy and security':
      'Faragha na usalama',
  'Edit profile':
      'Hariri wasifu',
  '{0} ratings':
      'Tathmini {0}',
  'Your profile':
      'Wasifu wako',
  'Signing out…':
      'Inaondoka…',
  'Wallet & payment':
      'Pochi na malipo',
  'Balance, top up and activity':
      'Salio, kuongeza pesa na shughuli',
  'Home, work and favourites':
      'Nyumbani, kazini na vipendwa',
  'Emergency contacts and SOS':
      'Watu wa dharura na SOS',
  'Get help with a trip or order':
      'Pata msaada kuhusu safari au oda',
  'Notifications and email receipts':
      'Arifa na risiti za barua pepe',
  'Password, email and sessions':
      'Nenosiri, barua pepe na vipindi',
  'Terms and privacy policy':
      'Masharti na sera ya faragha',
  'Pay ko!ngo with one of the methods below, then send this request. Your balance goes up when ko!ngo confirms the payment.':
      'Lipa ko!ngo kwa mojawapo ya njia zilizo hapa chini, kisha tuma ombi hili. Salio lako litaongezeka ko!ngo ikithibitisha malipo.',
  'Pay to: {0}':
      'Lipa kwa: {0}',
  'Contact ko!ngo support for the {0} payment details.':
      'Wasiliana na msaada wa ko!ngo kupata maelezo ya malipo ya {0}.',
  'Transaction code (from the SMS)':
      'Msimbo wa muamala (kutoka kwenye SMS)',
  'Bank transfer (EFT)':
      'Uhamisho wa benki (EFT)',
  'Customers can order now':
      'Wateja wanaweza kuagiza sasa',
  'Closed: customers cannot order':
      'Imefungwa: wateja hawawezi kuagiza',
  'New and active orders':
      'Oda mpya na zinazoendelea',
  'How will you pay?':
      'Utalipa vipi?',
  'ko!ngo wallet':
      'Pochi ya ko!ngo',
  'Balance {0}':
      'Salio {0}',
  'Balance {0}: not enough for this':
      'Salio {0}: halitoshi',
  'Cash':
      'Pesa taslimu',
  'Card':
      'Kadi',
  'Visa or Mastercard':
      'Visa au Mastercard',
  'Not enough in your wallet':
      'Salio halitoshi',
  'Top up your wallet or choose cash.':
      'Ongeza pesa kwenye pochi au chagua pesa taslimu.',
  'Not enough in your wallet. Top up or choose cash.':
      'Salio halitoshi. Ongeza pesa au chagua pesa taslimu.',
  'Pay the courier':
      'Lipa msafirishaji',
  'Pay the driver at the end of the trip':
      'Lipa dereva mwisho wa safari',
  'Pay the courier at pickup':
      'Lipa msafirishaji wakati wa kuchukua',
  'Pay the driver when it arrives':
      'Lipa dereva akifika',
  'Paid from wallet':
      'Imelipwa kwa pochi',
  'Paid by card':
      'Imelipwa kwa kadi',
  'Cash: collect from customer':
      'Pesa taslimu: chukua kwa mteja',
  'Collect {0} cash from the customer':
      'Chukua {0} taslimu kutoka kwa mteja',
  'Paid from the customer\'s wallet. No cash to collect.':
      'Imelipwa kwa pochi ya mteja. Hakuna pesa ya kuchukua.',
  'Paid in the app. No cash to collect.':
      'Imelipwa kwenye programu. Hakuna pesa ya kuchukua.',
  'Card not available':
      'Kadi haipatikani',
  'Card payments are not available here yet. Please choose cash or wallet.':
      'Malipo ya kadi bado hayapatikani hapa. Chagua pesa taslimu au pochi.',
  'New message to support':
      'Ujumbe mpya kwa msaada',
  'What is it about?':
      'Inahusu nini?',
  'e.g. Payment, a trip, an order':
      'mf. Malipo, safari, oda',
  'Tell us what happened':
      'Tueleze kilichotokea',
  'Send':
      'Tuma',
  'Solved':
      'Imetatuliwa',
  'Answered':
      'Imejibiwa',
  'Waiting for support':
      'Inasubiri msaada',
  'Message support':
      'Andikia msaada',
  'Chat with the ko!ngo team. We reply here and you get a notification.':
      'Ongea na timu ya ko!ngo. Tunajibu hapa na utapata arifa.',
  'Your conversations':
      'Mazungumzo yako',
  'No conversations yet. Tap "Message support" to start one.':
      'Hakuna mazungumzo bado. Gusa "Andikia msaada" kuanza.',
  'WhatsApp':
      'WhatsApp',
  'ko!ngo support':
      'Msaada wa ko!ngo',
  'Our team will reply here. You will get a notification.':
      'Timu yetu itajibu hapa. Utapata arifa.',
  'Write a message':
      'Andika ujumbe',
  'This is a {0} account':
      'Hii ni akaunti ya {0}',
  'These details belong to a {0} account, so they can\'t be used on the {1} login. Please sign in from the {0} login.':
      'Maelezo haya ni ya akaunti ya {0}, kwa hivyo hayawezi kutumika kwenye kuingia kwa {1}. Tafadhali ingia kupitia kuingia kwa {0}.',
  'Go to {0} login':
      'Nenda kuingia kwa {0}',
  'Where to?':
      'Unaenda wapi?',
  'Later':
      'Baadaye',
  'Add home':
      'Ongeza nyumbani',
  'You are here · {0} cars nearby':
      'Uko hapa · magari {0} karibu',
  'You are here':
      'Uko hapa',
  'Tap to copy the code':
      'Gusa kunakili msimbo',
  'Offers and promo codes':
      'Ofa na misimbo ya punguzo',
  'See what is on today':
      'Tazama ofa za leo',
  'Take a photo':
      'Piga picha',
  'Choose from gallery':
      'Chagua kutoka matunzio',
  'Send a photo':
      'Tuma picha',
  'Sedan (up to 4 seats)':
      'Sedani (hadi viti 4)',
  'XL (6 seats, SUV / minivan)':
      'XL (viti 6, SUV / minivan)',
  'Van / minibus (up to 14 seats)':
      'Van / basi dogo (hadi viti 14)',
  'Large van (cargo)':
      'Van kubwa (mizigo)',
  'Truck':
      'Lori',
  'Motorbike / Scooter':
      'Pikipiki / skuta',
  'Money in your wallet':
      'Pesa kwenye pochi yako',
  'You still have {0} in your ko!ngo wallet. If you delete your account now, this money is lost. Contact support first if you want it back.':
      'Bado una {0} kwenye pochi yako ya ko!ngo. Ukifuta akaunti sasa, pesa hii itapotea. Wasiliana na msaada kwanza ukitaka kuirejesha.',
  'Keep my account':
      'Baki na akaunti yangu',
  'Delete anyway':
      'Futa hata hivyo',
  'Not yet':
      'Bado',
  'Finish or cancel your current trip first.':
      'Maliza au ghairi safari yako ya sasa kwanza.',
  'Wait until your order is delivered or cancel it first.':
      'Subiri oda yako ifike au ighairi kwanza.',
  'Your driver':
      'Dereva wako',
  'Chat opens once a driver has your order.':
      'Gumzo litafunguka dereva akichukua oda yako.',
  'Orders waiting for a driver':
      'Oda zinazosubiri dereva',
  'Tap an order to see it and accept it.':
      'Gusa oda kuiona na kuikubali.',
  'No orders waiting right now':
      'Hakuna oda zinazosubiri sasa',
  'away':
      'mbali',
  'waiting {0} min':
      'inasubiri dakika {0}',
  '{0} orders waiting':
      'Oda {0} zinasubiri',
  'NO ANSWER':
      'HAKUNA JIBU',
  'The customer didn\'t answer. Pick the original item or leave it out.':
      'Mteja hakujibu. Chukua bidhaa ya awali au iache.',
  'OK, continue shopping':
      'Sawa, endelea kununua',
  'Your trip has started. Only the driver can end it now.':
      'Safari yako imeanza. Dereva pekee ndiye anaweza kuimaliza sasa.',
  'Trip already started':
      'Safari imeshaanza',
  'This trip was cancelled.':
      'Safari hii imeghairiwa.',
  'See all':
      'Ona zote',
  'View':
      'Tazama',
  'Messages':
      'Ujumbe',
  'Yesterday':
      'Jana',
  'Trips and deliveries':
      'Safari na usafirishaji',
  'Chats from your trips show here. Chats close when a trip ends and stay readable for 7 days.':
      'Mazungumzo ya safari zako yanaonekana hapa. Yanafungwa safari ikiisha na yanasomeka kwa siku 7.',
  'ko!ngo Support':
      'Msaada wa ko!ngo',
  'Questions, problems, payments: we reply here.':
      'Maswali, matatizo, malipo: tunajibu hapa.',
  'Photo':
      'Picha',
  'Trip ended':
      'Safari imeisha',
  'This trip has ended, so the chat is closed.':
      'Safari hii imeisha, kwa hivyo gumzo limefungwa.',
  'Ride booked':
      'Safari imehifadhiwa',
  "We'll start finding a driver 10 minutes before.":
      'Tutaanza kutafuta dereva dakika 10 kabla.',
  "{0}. We'll start finding a driver 10 minutes before.":
      '{0}. Tutaanza kutafuta dereva dakika 10 kabla.',
  'Price offer withdrawn':
      'Ofa ya bei imeondolewa',
  "We're still looking for a driver at your price.":
      'Bado tunatafuta dereva kwa bei yako.',
  'Your driver had to cancel':
      'Dereva wako alilazimika kughairi',
  "We're finding you another driver.":
      'Tunakutafutia dereva mwingine.',
  'No driver found':
      'Hakuna dereva aliyepatikana',
  'Trip cancelled':
      'Safari imeghairiwa',
  'No driver was free just now. Please try again.':
      'Hakuna dereva aliyekuwa huru sasa hivi. Tafadhali jaribu tena.',
  'Your driver cancelled the trip.':
      'Dereva wako ameghairi safari.',
  'ko!ngo support cancelled this trip.':
      'Huduma ya ko!ngo imeghairi safari hii.',
  'Offer declined':
      'Ofa imekataliwa',
  'Pick a later time':
      'Chagua muda wa baadaye',
  'Book at least 20 minutes ahead, or choose Now.':
      'Hifadhi angalau dakika 20 kabla, au chagua Sasa.',
  'When':
      'Lini',
  'Now':
      'Sasa',
  "We'll start finding a driver 10 minutes before. You can cancel any time before then.":
      'Tutaanza kutafuta dereva dakika 10 kabla. Unaweza kughairi wakati wowote kabla ya hapo.',
  'Today {0}':
      'Leo {0}',
  'Tomorrow {0}':
      'Kesho {0}',
  'Book for later':
      'Hifadhi kwa baadaye',
  'Book a ride ahead — we find your driver 10 minutes before.':
      'Hifadhi safari mapema — tunakutafutia dereva dakika 10 kabla.',
  'Time unknown':
      'Muda haujulikani',
  'Paid from your wallet':
      'Imelipwa kutoka pochi yako',
  'Pay the courier in cash':
      'Mlipe msafirishaji kwa pesa taslimu',
  'Pay the driver in cash':
      'Mlipe dereva kwa pesa taslimu',
  'Parcel delivered!':
      'Kifurushi kimefikishwa!',
  'Thanks for sending with ko!ngo.':
      'Asante kwa kutuma na ko!ngo.',
  'Distance':
      'Umbali',
  'Trip ID':
      'Nambari ya safari',
  'Rate {0}':
      'Mpe {0} alama',
  'Rate your driver':
      'Mpe dereva wako alama',
  'Another driver has already sent a price. Try again in a moment.':
      'Dereva mwingine tayari ametuma bei. Jaribu tena baada ya muda.',
  'Wallet {0} · Waiting payouts {1}':
      'Pochi {0} · Malipo yanayosubiri {1}',
  'You owe ko!ngo {0} from cash you collected. It comes off your next earnings, or pay it at a ko!ngo office.':
      'Unadaiwa na ko!ngo {0} kutoka pesa taslimu ulizopokea. Itakatwa kwenye mapato yako yajayo, au ilipe kwenye ofisi ya ko!ngo.',
  'Cash you kept':
      'Pesa taslimu ulizobaki nazo',
  'Bank or mobile money':
      'Benki au pesa kwa simu',
  'Account or phone number':
      'Namba ya akaunti au simu',
  'ko!ngo will send it and let you know.':
      'ko!ngo itaituma na kukujulisha.',
  'Available {0} · Waiting payouts {1}':
      'Inapatikana {0} · Malipo yanayosubiri {1}',
  'Sales credited':
      'Mauzo yaliyowekwa',
  'Please sign in again':
      'Tafadhali ingia tena',
  'Your session ended. Sign in again to continue.':
      'Muda wako umeisha. Ingia tena kuendelea.',
  "Couldn't get your location. Allow location for ko!ngo, or type your street above.":
      'Imeshindwa kupata mahali ulipo. Ruhusu eneo kwa ko!ngo, au andika mtaa wako hapo juu.',
  'Pick an address from the list, or tap "Use my current location".':
      'Chagua anwani kwenye orodha, au gusa "Tumia mahali nilipo sasa".',
  "You don't have permission for this action. Try signing in again.":
      'Huna ruhusa kwa kitendo hiki. Jaribu kuingia tena.',
  'code':
      'msimbo',
  'Upload failed':
      'Kupakia kumeshindwa',
  "Pictures can't be saved for this account yet. Please contact ko!ngo support.":
      'Picha haziwezi kuhifadhiwa kwa akaunti hii bado. Wasiliana na huduma ya ko!ngo.',
  "Pictures can't be saved for this store yet. Please contact ko!ngo support.":
      'Picha haziwezi kuhifadhiwa kwa duka hili bado. Wasiliana na huduma ya ko!ngo.',
  'The picture could not be saved. Please try again.':
      'Picha haikuweza kuhifadhiwa. Jaribu tena.',
  'No internet connection. Check your network and try again.':
      'Hakuna intaneti. Angalia mtandao wako na ujaribu tena.',
  'The upload took too long. Check your connection.':
      'Kupakia kumechukua muda mrefu. Angalia muunganisho wako.',
  'Could not load this item swap. Please try again.':
      'Imeshindwa kupakia mbadala huu. Jaribu tena.',
  "You're offline. Check your data or Wi‑Fi and try again.":
      'Uko nje ya mtandao. Angalia data au Wi‑Fi na ujaribu tena.',
  'No internet. Reconnecting…':
      'Hakuna intaneti. Inaunganisha upya…',
  'New order':
      'Oda mpya',
  'My trips':
      'Safari zangu',
  'Every trip you took, in order':
      'Kila safari uliyofanya, kwa mpangilio',
  'Booked':
      'Imehifadhiwa',
  'No trip in progress':
      'Hakuna safari inayoendelea',
  'No rides booked for later':
      'Hakuna safari zilizohifadhiwa',
  'No finished trips yet':
      'Bado hakuna safari zilizokamilika',
  'No cancelled trips':
      'Hakuna safari zilizoghairiwa',
  'Going to pickup':
      'Unaenda kuchukua',
  'At pickup':
      'Mahali pa kuchukua',
  'Returning parcel':
      'Kurudisha kifurushi',
  'Completed':
      'Imekamilika',
  'Returned':
      'Imerudishwa',
  'Expired':
      'Imeisha muda',
  'Delivery':
      'Usafirishaji',
  'Ride':
      'Safari',
  'Tap to go back to this trip':
      'Gusa kurudi kwenye safari hii',
  'Today':
      'Leo',
  'Tomorrow':
      'Kesho',
  'Status':
      'Hali',
  'Price':
      'Bei',
  'Booked for':
      'Imehifadhiwa kwa',
  'Requested':
      'Imeombwa',
  'Accepted':
      'Imekubaliwa',
  'Finished':
      'Imemalizika',
  'Reason':
      'Sababu',
  'Your rating from the customer':
      'Ukadiriaji wako kutoka kwa mteja',
  'Trip prices {0} · ko!ngo fee {1}%':
      'Bei za safari {0} · ada ya ko!ngo {1}%',
  'Trip price':
      'Bei ya safari',
  'Pinned on the map':
      'Imewekwa kwenye ramani',
  '{0} ({1} ratings)':
      '{0} (ukadiriaji {1})',
  'No ratings yet':
      'Bado hakuna ukadiriaji',
  'New customer · first trip':
      'Mteja mpya · safari ya kwanza',
  '1 trip with ko!ngo':
      'Safari 1 na ko!ngo',
  '{0} trips with ko!ngo':
      'Safari {0} na ko!ngo',
  'New shopping task':
      'Kazi mpya ya ununuzi',
  '…':
      '…',
  'ko!ngo':
      'ko!ngo',
  'Calling…':
      'Inapiga simu…',
  'Incoming call':
      'Simu inaingia',
  'Connecting…':
      'Inaunganisha…',
  'Decline':
      'Kataa',
  'Answer':
      'Jibu',
  'Mute':
      'Nyamazisha',
  'End':
      'Maliza',
  'Speaker':
      'Spika',
  'KO!NGO':
      'KO!NGO',
  'x{0} · {1}':
      'x{0} · {1}',
  'Share it with a friend to earn ride credit.':
      'Mshirikishe rafiki upate salio la safari.',
  'Share your code and earn ride credit for each friend who takes their first ride.':
      'Shiriki msimbo wako upate salio kwa kila rafiki anayefanya safari yake ya kwanza.',
  "Credit is added after your friend's first completed ride.":
      'Salio huongezwa baada ya rafiki yako kukamilisha safari yake ya kwanza.',
  'ko!ngo v1.0.0':
      'ko!ngo v1.0.0',
  'Interested? Contact ko!ngo support to join the waitlist.':
      'Unavutiwa? Wasiliana na msaada wa ko!ngo ujiunge na orodha ya kusubiri.',
  'Your driver has arrived':
      'Dereva wako amefika',
  'Transport':
      'Usafiri',
  'Marketplace':
      'Soko',
  'Book a ride in minutes · Fast & reliable':
      'Kodi safari kwa dakika chache · Haraka na ya kuaminika',
  'Send a package · Track delivery':
      'Tuma kifurushi · Fuatilia uwasilishaji',
  'Search shops and categories':
      'Tafuta maduka na kategoria',
  'Groceries':
      'Vyakula',
  'Fashion':
      'Mitindo',
  'Electronics':
      'Vifaa vya elektroniki',
  'Home & Living':
      'Nyumba na maisha',
  'Beauty':
      'Urembo',
  'Butchery':
      'Bucha',
  'Bakery':
      'Mkate',
  'General Retail':
      'Rejareja kwa ujumla',
  'Other':
      'Nyingine',
  'No categories match your search.':
      'Hakuna kategoria inayolingana na utafutaji wako.',
  'Nearby drivers · {0} nearby':
      'Madereva walio karibu · {0} karibu',
  'Your new photo is saved.':
      'Picha yako mpya imehifadhiwa.',
  'Customers see this photo when you shop for them.':
      'Wateja huona picha hii unapowanunulia.',
  'Change photo':
      'Badilisha picha',
  'All':
      'Zote',
  'Restaurant':
      'Mkahawa',
  'Pharmacy':
      'Duka la dawa',
  'Marketplace: delivery requests from shops and stores':
      'Soko: maombi ya uwasilishaji kutoka maduka',
  'No shop deliveries right now. New ones appear here and ring your phone.':
      'Hakuna uwasilishaji wa maduka sasa. Mpya zitaonekana hapa na kupigia simu yako.',
  'Go online to receive shop deliveries.':
      'Washa hali ya mtandaoni upokee uwasilishaji wa maduka.',
  'Passed · {0}%':
      'Umefaulu · {0}%',
  'Score {0}% · 80% to pass':
      'Alama {0}% · 80% kufaulu',
  'Well done. This module is now complete.':
      'Hongera. Moduli hii sasa imekamilika.',
  'Review the answers above and try again.':
      'Pitia majibu hapo juu kisha ujaribu tena.',
  'Answer {0} more':
      'Jibu {0} zaidi',
  'Submit quiz':
      'Wasilisha jaribio',
  'Call customer':
      'Mpigie mteja',
  'Recommended':
      'Inapendekezwa',
  "You're certified. Happy driving!":
      'Umethibitishwa. Safari njema!',
  'Complete all required modules to go online.':
      'Kamilisha moduli zote zinazohitajika ili uwe mtandaoni.',
  'Certificate of completion':
      'Cheti cha kukamilisha',
  'Certificate locked':
      'Cheti kimefungwa',
  'You have completed all required training.':
      'Umekamilisha mafunzo yote yanayohitajika.',
  'Complete all required modules to unlock.':
      'Kamilisha moduli zote zinazohitajika ili kufungua.',
  'My shops':
      'Maduka yangu',
  'Add another shop':
      'Ongeza duka lingine',
  '{0} · Business type':
      '{0} · Aina ya biashara',
  'For {0}':
      'Kwa {0}',
  'Restock':
      'Jaza bidhaa',
  'Store profile':
      'Wasifu wa duka',
  'Quick Actions':
      'Vitendo vya haraka',
  '1.0.0 · build 1':
      '1.0.0 · build 1',
  'Aa':
      'Aa',
  'day':
      'siku',
  'fixed price':
      'bei maalum',
  'hour':
      'saa',
  'This week':
      'Wiki hii',
  'Ongoing':
      'Inaendelea',
  'Just now':
      'Sasa hivi',
  '{0} min ago':
      'dakika {0} zilizopita',
  '{0} h ago':
      'saa {0} zilizopita',
  '{0} d ago':
      'siku {0} zilizopita',
  'Live':
      'Hai',
  'Filled':
      'Imejazwa',
  'Not approved':
      'Haijaidhinishwa',
  'Shortlisted':
      'Umechaguliwa awali',
  'Hired':
      'Umeajiriwa',
  'Applied':
      'Umeomba',
  'Withdrawn':
      'Imeondolewa',
  'URGENT':
      'DHARURA',
  'Hiring Hub':
      'Kituo cha Ajira',
  'Find Work':
      'Tafuta kazi',
  'My Applications':
      'Maombi yangu',
  'My Jobs':
      'Kazi zangu',
  'Post a Job':
      'Weka kazi',
  'Search jobs, skills...':
      'Tafuta kazi, ujuzi...',
  'Could not load jobs. Pull down to try again.':
      'Imeshindwa kupakia kazi. Vuta chini ujaribu tena.',
  'No jobs here yet. Be the first to post one!':
      'Hakuna kazi hapa bado. Kuwa wa kwanza kuweka!',
  'Apply':
      'Omba',
  'You have not applied for any job yet.':
      'Bado hujaomba kazi yoyote.',
  'Jobs you post will show here.':
      'Kazi unazoweka zitaonekana hapa.',
  'applicants':
      'waombaji',
  'Application sent. You will be notified.':
      'Ombi limetumwa. Utaarifiwa.',
  'Verified ID':
      'Kitambulisho kilichohakikiwa',
  'Experience':
      'Uzoefu',
  'Own tools':
      'Vifaa vyake mwenyewe',
  'Own transport':
      'Usafiri wake mwenyewe',
  'Employer':
      'Mwajiri',
  '{0} workers needed':
      'Wafanyakazi {0} wanahitajika',
  'Description':
      'Maelezo',
  'Requirements':
      'Mahitaji',
  'Your application':
      'Ombi lako',
  'Withdraw application':
      'Ondoa ombi',
  'Say a few words about yourself (optional)':
      'Andika maneno machache kukuhusu (si lazima)',
  'Close this job?':
      'Funga kazi hii?',
  'Workers will no longer see it.':
      'Wafanyakazi hawataiona tena.',
  'Close job':
      'Funga kazi',
  'We are checking your job. It will go live as soon as it is approved.':
      'Tunakagua kazi yako. Itaonekana mara itakapoidhinishwa.',
  'Applicants':
      'Waombaji',
  'No applicants yet.':
      'Hakuna waombaji bado.',
  'Shortlist':
      'Chagua awali',
  'Hire':
      'Ajiri',
  'Allow location to use this.':
      'Ruhusu eneo ili kutumia hii.',
  'Could not find your location.':
      'Imeshindwa kupata eneo lako.',
  'Please enter a job title.':
      'Tafadhali andika jina la kazi.',
  'Please enter the pay amount.':
      'Tafadhali weka kiasi cha malipo.',
  'Please enter where the job is.':
      'Tafadhali andika kazi ilipo.',
  'This is how workers will see your job':
      'Hivi ndivyo wafanyakazi watakavyoona kazi yako',
  'The photo could not be uploaded. Try again or post without it.':
      'Picha haikuweza kupakiwa. Jaribu tena au weka bila hiyo.',
  'Job sent for approval':
      'Kazi imetumwa kuidhinishwa',
  'We will check it and let you know as soon as it is live.':
      'Tutaikagua na kukujulisha mara itakapoonekana.',
  'Post a Job - Hire in minutes':
      'Weka kazi - Ajiri kwa dakika',
  'Fill out the details and connect with trusted workers near you':
      'Jaza maelezo na uunganishwe na wafanyakazi wa kuaminika karibu nawe',
  'Job Title':
      'Jina la kazi',
  'e.g. House Cleaner Needed':
      'mf. Msafishaji wa nyumba anahitajika',
  'Category':
      'Kategoria',
  'Describe the job, what you need done, and any important details...':
      'Elezea kazi, kinachohitajika kufanywa na maelezo muhimu...',
  'Pay Type':
      'Aina ya malipo',
  'Per Hour':
      'Kwa saa',
  'Per Day':
      'Kwa siku',
  'Fixed Price':
      'Bei maalum',
  'Amount ({0})':
      'Kiasi ({0})',
  'Location':
      'Mahali',
  'Where is the job?':
      'Kazi iko wapi?',
  'Use my location':
      'Tumia eneo langu',
  'Duration':
      'Muda',
  'Workers needed':
      'Wafanyakazi wanaohitajika',
  'Mark as urgent':
      'Weka alama ya dharura',
  'Upload photo':
      'Pakia picha',
  'optional':
      'si lazima',
  'Add a photo to help workers understand the job':
      'Ongeza picha kusaidia wafanyakazi kuelewa kazi',
  'Your first name will be visible to workers. Your job is checked before it goes live.':
      'Jina lako la kwanza litaonekana kwa wafanyakazi. Kazi yako hukaguliwa kabla ya kuonekana.',
  'Preview Job':
      'Hakiki kazi',
  'Post Job Now':
      'Weka kazi sasa',
  'Hiring Hub - Find work, hire talent':
      'Kituo cha Ajira - Tafuta kazi, ajiri vipaji',
  'Trusted workers and jobs near you':
      'Wafanyakazi wa kuaminika na kazi karibu nawe',
  'See All':
      'Ona zote',
  'Latest jobs':
      'Kazi za hivi karibuni',
  'Hiring':
      'Ajira',
  'Rides & Delivery':
      'Usafiri na Uwasilishaji',
  'Cleaning & Home':
      'Usafi na Nyumbani',
  'Construction':
      'Ujenzi',
  'Retail & Hospitality':
      'Rejareja na Ukarimu',
  'Tutoring':
      'Masomo ya ziada',
  'Admin & Office':
      'Utawala na Ofisi',
  'This job is closed':
      'Kazi hii imefungwa',
  'This job is no longer taking applications.':
      'Kazi hii haipokei maombi tena.',
  'Not possible':
      'Haiwezekani',
  'You cannot apply to your own job.':
      'Huwezi kuomba kazi yako mwenyewe.',
  'Your wallet needs {0} to post this job. Top up and try again.':
      'Pochi lako linahitaji {0} ili kuweka kazi hii. Weka pesa kisha ujaribu tena.',
  '+{0} · shown first for {1} days':
      '+{0} · inaonekana kwanza kwa siku {1}',
  'Shown first for {0} days':
      'Inaonekana kwanza kwa siku {0}',
  'Posting fee':
      'Ada ya kuweka kazi',
  'Urgent boost':
      'Kuongeza dharura',
  'Total from your wallet':
      'Jumla kutoka pochi lako',
  'Your wallet':
      'Pochi lako',
  'If we do not approve your job, the fee is returned to your wallet.':
      'Tusipoidhinisha kazi yako, ada inarudishwa kwenye pochi lako.',
  'Top up wallet':
      'Weka pesa kwenye pochi',
  'Fresh picks, fast':
      'Bidhaa mbichi, haraka',
  'Our shoppers pick the best for you':
      'Wanunuzi wetu wanakuchagulia bora',
  'Verified pharmacies':
      'Maduka ya dawa yaliyothibitishwa',
  'Cold-chain ready · pharmacist-verified':
      'Tayari kwa baridi · imehakikiwa na mfamasia',
  'Shops near you':
      'Maduka karibu nawe',
  'Get around with KO!NGO':
      'Safiri na KO!NGO',
  'Fast':
      'Haraka',
  'Safe':
      'Salama',
  'Reliable':
      'Ya kuaminika',
  'Book a Ride':
      'Agiza safari',
  'Shop from a wide range':
      'Nunua kutoka aina nyingi',
  'Groceries, food, pharmacy, fashion and more, brought to your door':
      'Mboga, chakula, dawa, mavazi na zaidi, vinaletwa mlangoni kwako',
  'Promote my store':
      'Tangaza duka langu',
  'Be listed first and get more orders':
      'Orodheshwa kwanza na upate oda zaidi',
  'Sponsored':
      'Imedhaminiwa',
  'Sponsored until {0}':
      'Imedhaminiwa hadi {0}',
  'Your store appears first in the list with a Sponsored label.':
      'Duka lako linaonekana kwanza kwenye orodha likiwa na alama ya Imedhaminiwa.',
  'Your store is now sponsored':
      'Duka lako sasa limedhaminiwa',
  'Sponsored spots are not available in your country yet.':
      'Nafasi zilizodhaminiwa bado hazipatikani katika nchi yako.',
  'How many weeks?':
      'Wiki ngapi?',
  'week':
      'wiki',
  'weeks':
      'wiki',
  'Price per week':
      'Bei kwa wiki',
  'Sponsor my store · {0}':
      'Dhamini duka langu · {0}',
  'Not available':
      'Haipatikani',
  'This is not available right now.':
      'Hii haipatikani kwa sasa.',
  'Earn more':
      'Pata zaidi',
  'tasks':
      'kazi',
  'trips':
      'safari',
  'task':
      'kazi',
  'trip':
      'safari',
  'Done! {0} added to your wallet':
      'Umemaliza! {0} imeongezwa kwenye pochi yako',
  '{0} of {1} {2} this week · Bonus {3}':
      '{0} kati ya {1} {2} wiki hii · Bonasi {3}',
  '{0}: +{1} for every {2} between {3} and {4}':
      '{0}: +{1} kwa kila {2} kati ya {3} na {4}',
  'Verified by ko!ngo':
      'Imethibitishwa na ko!ngo',
  'Verified':
      'Imethibitishwa',
  'Signed in on another phone':
      'Umeingia kwenye simu nyingine',
  'Your account was opened on another phone, so this one was signed out.':
      'Akaunti yako imefunguliwa kwenye simu nyingine, kwa hiyo simu hii imetolewa.',
  'Recommendations':
      'Mapendekezo',
  'Add your vehicle':
      'Ongeza gari lako',
  'You owe ko!ngo {0}':
      'Unadaiwa {0} na ko!ngo',
  'Add your profile picture':
      'Ongeza picha yako ya wasifu',
  'Upload your papers ({0} missing)':
      'Pakia hati zako ({0} hazipo)',
  'Your papers are being checked':
      'Hati zako zinakaguliwa',
  'Add your bank details to get paid':
      'Ongeza maelezo ya benki ili ulipwe',
  'Finish driver academy':
      'Maliza chuo cha madereva',
  'You are all set. Nothing to fix.':
      'Kila kitu kiko sawa. Hakuna cha kurekebisha.',
  'Tap to see what to fix':
      'Gusa kuona cha kurekebisha',
  'Quick photo check':
      'Ukaguzi wa haraka wa picha',
  'Take a live selfie now so we know it is you. This takes a few seconds.':
      'Piga selfie sasa ili tujue ni wewe. Inachukua sekunde chache.',
  'Your face must be clearly visible. Photos from the gallery are not accepted.':
      'Uso wako lazima uonekane vizuri. Picha za kwenye ghala hazikubaliwi.',
  'Take selfie':
      'Piga selfie',
  'Send photo':
      'Tuma picha',
  'Retake':
      'Piga tena',
  'Sending…':
      'Inatuma…',
  'Photo check sent. Thank you.':
      'Ukaguzi wa picha umetumwa. Asante.',
  'Photo check needed before you go online':
      'Ukaguzi wa picha unahitajika kabla ya kuingia mtandaoni',
  'Take your weekly selfie check':
      'Piga selfie yako ya wiki',
  'Could not send the photo. Check your internet and try again.':
      'Imeshindwa kutuma picha. Angalia intaneti yako ujaribu tena.',
  'Could not open the camera. Allow camera access for ko!ngo in your phone settings.':
      'Imeshindwa kufungua kamera. Ruhusu ko!ngo kutumia kamera kwenye mipangilio ya simu.',
  'Your balance is low. Top up so you can keep working without interruption.': 'Salio lako ni dogo. Ongeza salio ili uendelee kufanya kazi bila kukatizwa.',
  'Your balance is low ({0}). Top up.': 'Salio lako ni dogo ({0}). Ongeza salio.',
  'Daily goal': 'Lengo la leo',
  'Set a daily goal': 'Weka lengo la leo',
  'Goal reached!': 'Lengo limefikiwa!',
  '{0} of {1}': '{0} kati ya {1}',
  'Amount you want to earn today': 'Kiasi unachotaka kupata leo',
  'Trips': 'Safari',
  'Up {0}% on last week': 'Juu kwa {0}% kuliko wiki iliyopita',
  'Down {0}% on last week': 'Chini kwa {0}% kuliko wiki iliyopita',
  'Same as last week': 'Sawa na wiki iliyopita',
  'No trips yet this week': 'Hakuna safari wiki hii bado',
  'Pop-up over other apps': 'Dirisha juu ya programu zingine',
  'Lets a ride request open ko!ngo on top of other apps. Switch it on for ko!ngo on the page that opens.': 'Huruhusu ombi la safari lifungue ko!ngo juu ya programu zingine. Washa kwa ko!ngo kwenye ukurasa utakaofunguka.',
  'Open settings': 'Fungua mipangilio',
  'Not ringing? See what happened to the last request on this phone.': 'Haipigi? Angalia kilichotokea kwa ombi la mwisho kwenye simu hii.',
  'Check last ring': 'Angalia mlio wa mwisho',
  'No ring has reached this phone yet.': 'Hakuna mlio uliofika kwenye simu hii bado.',
  'Tip your driver':
      'Mpe dereva bakshishi',
  'Send tip':
      'Tuma bakshishi',
  'Tip sent. Thank you!':
      'Bakshishi imetumwa. Asante!',
  'Custom amount':
      'Kiasi kingine',
  'Why this rating? (optional)':
      'Kwa nini alama hii? (si lazima)',
  'Share receipt':
      'Shiriki risiti',
  'Tip amount':
      'Kiasi cha bakshishi',
  'My worker profile':
      'Wasifu wangu wa mfanyakazi',
  'Other requests':
      'Maombi mengine',
  '{0} other requests waiting. Choose one.':
      'Maombi {0} mengine yanasubiri. Chagua moja.',
  'Finish your current trip first':
      'Maliza safari yako ya sasa kwanza',
  'You can accept one order at a time.':
      'Unaweza kukubali agizo moja kwa wakati.',
  'Shops':
      'Maduka',
  'Open':
      'Wazi',
  'Nothing found. Try another word.':
      'Hakuna kilichopatikana. Jaribu neno lingine.',
  'Heavy traffic ahead. About {0} extra minutes.':
      'Msongamano mbele. Takriban dakika {0} za ziada.',
  'Slow traffic in {0} km.':
      'Msongamano wa magari katika km {0}.',
  'In {0} metres: {1}':
      'Baada ya mita {0}: {1}',
  '{0} reported ahead.':
      '{0} imeripotiwa mbele.',
  'Accident':
      'Ajali',
  'Hazard on the road':
      'Hatari barabarani',
  'Traffic jam':
      'Msongamano wa magari',
  'Report on the road':
      'Ripoti barabarani',
  'Thanks, other drivers will be warned.':
      'Asante, madereva wengine wataonywa.',
  'Navigation started':
      'Uelekezaji umeanza',
  'Heavy traffic: +{0} min':
      'Msongamano: +dakika {0}',
  'Voice directions':
      'Maelekezo kwa sauti',
  'Take a photo now':
      'Piga picha sasa',
  'Your worker profile is ready':
      'Wasifu wako wa mfanyakazi uko tayari',
  'Looking for work?':
      'Unatafuta kazi?',
  'Tap Apply on any job below.':
      'Gusa Omba kwenye kazi yoyote hapa chini.',
  'Set up your worker profile so employers can see what you do. Then tap Apply on any job.':
      'Weka wasifu wako wa mfanyakazi ili waajiri waone unachofanya. Kisha gusa Omba kwenye kazi yoyote.',
  'Set up my profile':
      'Weka wasifu wangu',
  'No jobs here yet. Check back soon.':
      'Hakuna kazi hapa bado. Rudi hivi karibuni.',
  'Need to hire someone? Post a job':
      'Unahitaji kuajiri? Weka tangazo la kazi',
  'Write what work you do, for example "Painter".':
      'Andika kazi unayofanya, mfano "Mchoraji".',
  'Profile saved':
      'Wasifu umehifadhiwa',
  'Employers see this when you apply for a job. Save it once.':
      'Waajiri wanaona hii unapoomba kazi. Hifadhi mara moja tu.',
  'What work do you do?':
      'Unafanya kazi gani?',
  'e.g. Painter, Driver, Cleaner':
      'mf. Mchoraji, Dereva, Msafishaji',
  'Your skills':
      'Ujuzi wako',
  'e.g. painting, walls, roofs':
      'mf. kupaka rangi, kuta, paa',
  'Years of experience':
      'Miaka ya uzoefu',
  'About you':
      'Kukuhusu',
  'Tell employers why they should choose you':
      'Waambie waajiri kwa nini wakuchague',
  'Save profile':
      'Hifadhi wasifu',
  'Add a short comment (optional)':
      'Ongeza maoni mafupi (si lazima)',
  'Send rating':
      'Tuma alama',
  'Rate the employer':
      'Mpe mwajiri alama',
  'Thank you for your rating':
      'Asante kwa alama yako',
  'years experience':
      'miaka ya uzoefu',
  'Rate this worker':
      'Mpe mfanyakazi huyu alama',
  'You rated {0} stars':
      'Ulitoa nyota {0}',
  'Voice search is not available on this phone.':
      'Utafutaji wa sauti haupatikani kwenye simu hii.',
  'Speak to search':
      'Sema ili kutafuta',
  'Split the fare':
      'Gawanya nauli',
  'Each person pays {0}':
      'Kila mtu analipa {0}',
  'Each person pays the driver their share. Nothing is taken from your wallet for others.':
      'Kila mtu anamlipa dereva sehemu yake. Hakuna kinachokatwa kwenye pochi yako kwa wengine.',
  'Our ko!ngo ride costs {0} in total. With {1} of us, each pays {2}.':
      'Safari yetu ya ko!ngo inagharimu {0} kwa jumla. Tukiwa {1}, kila mtu analipa {2}.',
  'Send to friends':
      'Tuma kwa marafiki',
  'National ID / Passport':
      'Kitambulisho / Pasipoti',
  'Clear photo of the whole document':
      'Picha wazi ya hati nzima',
  'Selfie holding your ID':
      'Selfie ukishika kitambulisho chako',
  'Your face and the ID must both be readable':
      'Uso wako na kitambulisho vinapaswa kusomeka',
  'Driving licence':
      'Leseni ya udereva',
  'Valid, for your type of vehicle':
      'Halali, kwa aina ya gari lako',
  'Vehicle registration & insurance':
      'Usajili wa gari na bima',
  'Registration paper and valid insurance':
      'Karatasi ya usajili na bima halali',
  'Police clearance':
      'Cheti cha polisi (hana rekodi ya uhalifu)',
  'Criminal record extract, not older than 6 months':
      'Cheti cha rekodi ya uhalifu, kisichozidi miezi 6',
  'Technical inspection':
      'Ukaguzi wa kiufundi',
  'Roadworthy certificate':
      'Cheti cha ubora wa gari barabarani',
  'If your vehicle needs one':
      'Ikiwa gari lako linahitaji',
  'Professional driving permit (PrDP)':
      'Leseni ya kitaalamu ya udereva (PrDP)',
  'For paid passenger transport':
      'Kwa usafiri wa abiria wa kulipia',
  'Business registration (RCCM)':
      'Usajili wa biashara (RCCM)',
  'Business registration (CIPC)':
      'Usajili wa biashara (CIPC)',
  'Registration paper of your business':
      'Karatasi ya usajili wa biashara yako',
  'Photo of your shop front':
      'Picha ya mbele ya duka lako',
  'Show the sign and the entrance':
      'Onyesha ubao wa jina na mlango',
  'Tax number (NIU)':
      'Namba ya kodi (NIU)',
  'Tax number (SARS)':
      'Namba ya kodi (SARS)',
  'Adds trust, not required':
      'Huongeza uaminifu, si lazima',
  'Health certificate':
      'Cheti cha afya',
  'Food sellers: certificate from your municipality':
      'Wauzaji wa chakula: cheti kutoka manispaa yako',
  'Not accepted':
      'Haikukubaliwa',
  'Waiting for review':
      'Inasubiri ukaguzi',
  'Not uploaded':
      'Haijapakiwa',
  'Optional':
      'Si lazima',
  'Upload':
      'Pakia',
  'Verify me':
      'Nithibitishe',
  'You are verified. Customers see your badge.':
      'Umethibitishwa. Wateja wanaona beji yako.',
  '{0} of {1} required papers accepted. When all are accepted you get the Verified badge.':
      '{0} kati ya {1} za hati zinazohitajika zimekubaliwa. Zote zikikubaliwa unapata beji ya Imethibitishwa.',
  'Your papers are private. Only ko!ngo admin can see them.':
      'Hati zako ni za faragha. Ni msimamizi wa ko!ngo pekee anayeweza kuziona.',
  'Verify my business':
      'Thibitisha biashara yangu',
  'Not allowed':
      'Hairuhusiwi',
  'Trip not found':
      'Safari haijapatikana',
  'This is not your trip':
      'Hii si safari yako',
  'User not found':
      'Mtumiaji hajapatikana',
  'Job not found':
      'Kazi haijapatikana',
  'Enter the customer\'s PIN to start':
      'Weka PIN ya mteja ili kuanza',
  'The trip has started. Only the driver can end it now.':
      'Safari imeanza. Dereva pekee anaweza kuimaliza sasa.',
  'This trip has already ended':
      'Safari hii tayari imeisha',
  'This job is finished and cannot be changed':
      'Kazi hii imekamilika na haiwezi kubadilishwa',
  'You can book up to 30 days ahead':
      'Unaweza kuhifadhi hadi siku 30 mbele',
  'Pick a time at least 15 minutes from now':
      'Chagua muda angalau dakika 15 kutoka sasa',
  'This request is no longer available':
      'Ombi hili halipatikani tena',
  'Sponsored spots are not available right now':
      'Nafasi za udhamini hazipatikani kwa sasa',
  'You can rate after your trip':
      'Unaweza kukadiria baada ya safari yako',
  'You can rate after the trip':
      'Unaweza kukadiria baada ya safari',
  'You can only rate after a hire on this job':
      'Unaweza kukadiria tu baada ya kuajiri kwenye kazi hii',
  'This ride is booked for later':
      'Safari hii imehifadhiwa kwa baadaye',
  'This is not your store':
      'Hili si duka lako',
  'Only the driver can release this trip':
      'Dereva pekee anaweza kuachilia safari hii',
  'Only the driver can do this':
      'Dereva pekee anaweza kufanya hivi',
  'The price can\'t be changed':
      'Bei haiwezi kubadilishwa',
  'Shop deliveries have a fixed fee':
      'Uwasilishaji wa duka una ada maalum',
  'This job is no longer open':
      'Kazi hii haipo wazi tena',
  'That price offer is no longer available':
      'Ofa hiyo ya bei haipatikani tena',
  'Cancel the order instead':
      'Ghairi agizo badala yake',
  'Start the trip first':
      'Anza safari kwanza',
  'Start the return first':
      'Anza kurudi kwanza',
  'Pick up the parcel first':
      'Chukua kifurushi kwanza',
  'Enter an amount':
      'Weka kiasi',
  'Enter a price':
      'Weka bei',
  'Choose 1 to 5 stars':
      'Chagua nyota 1 hadi 5',
  'Pick 1 to 5 stars':
      'Chagua nyota 1 hadi 5',
  'Finish or cancel your current trip first':
      'Maliza au ghairi safari yako ya sasa kwanza',
  'You can withdraw up to {0}':
      'Unaweza kutoa hadi {0}',
  'Choose between 1 and {0} weeks':
      'Chagua kati ya wiki 1 na {0}',
  'Sign-up problem on our side':
      'Tatizo la usajili upande wetu',
  'Our server could not finish this. Please try again in a moment, or contact ko!ngo support.':
      'Seva yetu haikuweza kukamilisha hili. Jaribu tena baadaye kidogo au wasiliana na usaidizi wa ko!ngo.',
  'No answer. The other person must have the trip open in the app.':
      'Hakuna jibu. Mtu mwingine lazima awe amefungua safari kwenye programu.',
  'Couldn\'t connect the call. Check that both phones have internet and try again.':
      'Imeshindwa kuunganisha simu. Hakikisha simu zote mbili zina intaneti kisha jaribu tena.',
  'Couldn\'t start the microphone. Allow microphone access for ko!ngo in your phone settings.':
      'Imeshindwa kuwasha maikrofoni. Ruhusu ko!ngo kutumia maikrofoni kwenye mipangilio ya simu.',
};
