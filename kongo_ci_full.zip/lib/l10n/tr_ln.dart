// lib/l10n/tr_ln.dart
//
// Lingala for text written directly in the screens (see tr_fr.dart).
// Machine-assisted translation: have a native speaker review before release.

const Map<String, String> trLn = {
  '% OFF':
      '% REDUCTION',
  '6-digit code':
      'Code ya bilembo 6',
  'A minimum fare of R {0} is required.':
      'Motuya ya nse {0} esengeli.',
  'A profile photo is required to continue. You can skip for now, but you won\'t be able to book or accept rides.':
      'Foto ya profil esengeli mpo na kokoba. Okoki kolekisa sikoyo, kasi okoki te kosenga to kondima mibembo.',
  'Access denied':
      'Nzela epekisami',
  'Account':
      'Konti',
  'Account blocked':
      'Konti ekangami',
  'Account holder':
      'Nkolo ya konti',
  'Account holder name':
      'Kombo ya nkolo ya konti',
  'Account number':
      'Nimero ya konti',
  'Account type':
      'Lolenge ya konti',
  'Account verification':
      'Botali konti',
  'Active sessions':
      'Ba session oyo ezali',
  'Add Vehicle':
      'Bakisa motuka',
  'Add an extra layer of security':
      'Bakisa bokengi mosusu',
  'Add at least one contact so SOS can reach someone.':
      'Bakisa ata moto moko po SOS ekoka kokoma na moto.',
  'Add contact':
      'Bakisa moto',
  'Add contacts so SOS can reach someone':
      'Bakisa bato po SOS ekoka kokoma na moto',
  'Add emergency contacts who will be notified when you trigger SOS.':
      'Bakisa bato ya likama oyo bakoyeba soki obeti SOS.',
  'Add your vehicle or bike to start accepting rides and deliveries.':
      'Bakisa motuka to moto na yo mpo na kobanda kondima mibembo pe bomemi.',
  'Add, edit, or remove':
      'Bakisa, bongisa to longola',
  'Allow drivers to see your pickup location during trips.':
      'Tika batambwisi bamona esika ya kozwa yo na tango ya mobembo.',
  'Already added':
      'Ebakisami kala',
  'Already exists':
      'Ezali kala',
  'Already have an account? ':
      'Ozali na konti kala? ',
  'Already rated':
      'Opesi note kala',
  'Already registered':
      'Okomisami kala',
  'Ambulance':
      'Ambulance',
  'Amount (R)':
      'Motango',
  'An admin hasn\'t reviewed your account yet. Try again later.':
      'Admin atali naino konti na yo te. Meka lisusu na sima.',
  'Analytics':
      'Ba statistique',
  'Answer every question':
      'Yanola motuna nyonso',
  'Apply Code':
      'Salela code',
  'Approve swap':
      'Ndima kobongola',
  'Are you safe?':
      'Ozali malamu?',
  'Are you sure you want to delete "{0}"? This cannot be undone.':
      'Ozali solo na mposa ya kolongola "{0}"? Okoki kozongisa yango te.',
  'At least 8 characters':
      'Ata bilembo 8',
  'Authentication failed':
      'Bondimi ya konti elongi te',
  'Available balance':
      'Mbongo oyo ezali',
  'Available to withdraw':
      'Okoki kobimisa',
  'Available: {0}':
      'Ezali: {0}',
  'Await admin approval.':
      'Zela bondimi ya admin.',
  'Awaiting admin approval':
      'Ezali kozela bondimi ya admin',
  'Back':
      'Zonga',
  'Back to home':
      'Zonga na ebandeli',
  'Back to start':
      'Zonga na ebandeli',
  'Bank':
      'Banki',
  'Bank details':
      'Ba informasio ya banki',
  'Bank details saved':
      'Ba informasio ya banki ebombami',
  'Bank name':
      'Kombo ya banki',
  'Bank reference (optional)':
      'Reference ya banki (soki olingi)',
  'Become a driver or courier':
      'Kozala motambwisi to momemi',
  'Blue Toyota Corolla — see you soon':
      'Toyota Corolla ya bule — tokomonana noki',
  'Book a ride, order food,\ngroceries or send parcels.':
      'Senga mobembo, somba bilei,\nbiloko ya ndako to tinda poso.',
  'Branch code (optional)':
      'Code ya agence (soki olingi)',
  'Brief summary of your issue':
      'Lisolo mokuse ya likambo na yo',
  'By continuing, you agree to our ':
      'Soki okobi, ondimi ',
  'By continuing, you agree to our Terms of Service and Privacy Policy.':
      'Soki okobi, ondimi Mibeko ya bosaleli pe Politiki ya bomoko.',
  'CANCEL — I\'M SAFE':
      'TIKA — NAZALI MALAMU',
  'CLOSED':
      'EKANGAMI',
  'Calendar':
      'Calendrier',
  'Call':
      'Benga',
  'Call support':
      'Benga lisalisi',
  'Call us at {0}':
      'Benga biso na {0}',
  'Call {0}':
      'Benga {0}',
  'Call {0} manually.':
      'Benga {0} yo moko.',
  'Call {0}?':
      'Kobenga {0}?',
  'Camera':
      'Kamera',
  'Can\'t call':
      'Kobenga ekoki te',
  'Cancel':
      'Tika',
  'Cancel ride':
      'Tika mobembo',
  'Cancel scheduled ride?':
      'Tika mobembo oyo ebongisami?',
  'Cancel this order?':
      'Tika komandi oyo?',
  'Card (coming soon)':
      'Carte (ekoya)',
  'Cash deposit':
      'Kotia mbongo ya maboko',
  'Change email':
      'Bongola email',
  'Change password':
      'Bongola liloba ya sekele',
  'Change phone number':
      'Bongola nimero ya telefone',
  'Chat':
      'Lisolo',
  'Chat messages':
      'Ba message',
  'Check back soon':
      'Zonga noki',
  'Check back soon — we\'ll notify you when there\'s an offer.':
      'Zonga noki — tokoyebisa yo soki ofre ezali.',
  'Check your connection and try again.':
      'Tala connexion na yo pe meka lisusu.',
  'Check your inbox':
      'Tala boite ya ba email na yo',
  'Choose at least Ride or Delivery.':
      'Pona ata Mobembo to Bomemi.',
  'Choose what notifications you receive.':
      'Pona ba notification oyo okozwa.',
  'Choose your role':
      'Pona mosala na yo',
  'Close':
      'Kanga',
  'Code copied':
      'Code ekopiami',
  'Code not found.':
      'Code emonani te.',
  'Code: ':
      'Code: ',
  'Colour':
      'Langi',
  'Coming soon':
      'Ekoya noki',
  'Communication':
      'Bosolosoli',
  'Complete all three steps before submitting.':
      'Silisa ba etape misato liboso ya kotinda.',
  'Complete your profile':
      'Silisa profil na yo',
  'Confirm':
      'Ndima',
  'Confirm Password':
      'Ndima liloba ya sekele',
  'Confirm deletion':
      'Ndima kolongola',
  'Confirm new password':
      'Ndima liloba ya sekele ya sika',
  'Connecting you to a better journey':
      'Tokangisi yo na mobembo ya malamu',
  'Contact added':
      'Moto abakisami',
  'Contact details are unavailable right now.':
      'Ba informasio ezali te sikoyo.',
  'Contact name':
      'Kombo ya moto',
  'Contact removed':
      'Moto alongolami',
  'Contact support':
      'Solola na lisalisi',
  'Contact support for more information.':
      'Solola na lisalisi mpo na koyeba mingi.',
  'Continue':
      'Kokoba',
  'Control how new ride requests interrupt you.':
      'Pona ndenge basenga ya sika bakatisaka yo.',
  'Control what alerts you receive while you\'re online.':
      'Pona ba alerte oyo okozwa tango ozali en ligne.',
  'Copy':
      'Kopia',
  'Corporate Accounts':
      'Ba konti ya kompani',
  'Corporate Travel':
      'Mibembo ya mosala',
  'Could not load orders':
      'Ekoki kofungola ba komandi te',
  'Could not load preview':
      'Ekoki kolakisa te',
  'Could not load restaurants':
      'Ekoki kofungola ba restaurant te',
  'Could not load the menu':
      'Ekoki kofungola menu te',
  'Could not load {0} stores':
      'Ekoki kofungola ba magazini ya {0} te',
  'Couldn\'t complete request':
      'Ekoki kosilisa bosenga te',
  'Couldn\'t dial':
      'Ekoki kobenga te',
  'Couldn\'t open dialer':
      'Ekoki kofungola telefone te',
  'Couldn\'t open email':
      'Ekoki kofungola email te',
  'Couldn\'t save':
      'Ekoki kobomba te',
  'Couldn\'t send request':
      'Ekoki kotinda bosenga te',
  'Couldn\'t submit payout':
      'Ekoki kotinda lifuti te',
  'Couldn\'t validate this code. Try again.':
      'Ekoki kondima code oyo te. Meka lisusu.',
  'Current password':
      'Liloba ya sekele ya sikoyo',
  'Current session:':
      'Session ya sikoyo:',
  'Customer':
      'Mokiliya',
  'DELETE':
      'LONGOLA',
  'DONE':
      'ESILI',
  'Day':
      'Mokolo',
  'Delete':
      'Longola',
  'Delete account':
      'Longola konti',
  'Delete account?':
      'Longola konti?',
  'Delete forever':
      'Longola mpo na libela',
  'Delete vehicle?':
      'Longola motuka?',
  'Deliveries':
      'Bomemi',
  'Describe what happened in detail':
      'Limbola malamu nini esalemi',
  'Details':
      'Ba details',
  'Disc':
      'Red.',
  'Discounts, referral bonuses, and seasonal deals.':
      'Ba reduction, bonus ya kobenga baninga pe ba ofre ya tango.',
  'Documents (upload pictures)':
      'Mikanda (tinda ba foto)',
  'Done':
      'Esili',
  'Driver':
      'Motambwisi',
  'Driver Academy':
      'Eteyelo ya batambwisi',
  'Driver Terms':
      'Mibeko ya motambwisi',
  'Driver Terms of Service':
      'Mibeko ya bosaleli ya motambwisi',
  'Driver assigned, arriving, and trip status.':
      'Motambwisi apesami, kokoma pe ndenge mobembo ezali.',
  'Driver: {0}':
      'Motambwisi: {0}',
  'Drivers and couriers must complete KYC documentation.':
      'Batambwisi pe bamemi basengeli kotinda mikanda ya identite.',
  'Drop-off':
      'Esika ya kokitisa',
  'Dropoff location':
      'Esika ya kokitisa',
  'EFT / Bank transfer':
      'Kotinda na banki',
  'Earn R50 for each referral':
      'Zwa bonus mpo na moninga nyonso',
  'Earn money by driving\nor delivering.':
      'Zwa mbongo na kotambwisa\nto komema.',
  'Earn with ko!ngo':
      'Zwa mbongo na ko!ngo',
  'Earnings':
      'Lifuti',
  'Earnings & payouts':
      'Lifuti pe bafuti',
  'Edit':
      'Bongisa',
  'Edit name':
      'Bongisa kombo',
  'Email receipts':
      'Ba fakture na email',
  'Email support':
      'Tinda email na lisalisi',
  'Email us at {0}':
      'Komela biso na {0}',
  'Emergency SOS':
      'SOS ya likama',
  'Emergency contacts':
      'Bato ya likama',
  'Emergency services and {0} have been alerted.':
      'Basalisi ya likama pe {0} bayebisami.',
  'Enter a code.':
      'Kotisa code.',
  'Enter a valid amount':
      'Kotisa motango ya malamu',
  'Enter an amount greater than zero.':
      'Kotisa motango oleki zero.',
  'Enter an amount within your available balance.':
      'Kotisa motango oyo eleki te mbongo na yo.',
  'Enter both a name and phone number.':
      'Kotisa kombo pe nimero ya telefone.',
  'Even with sound off, the full-screen ring still appears so you won\'t miss a ride.':
      'Ata soki lokito ekufi, sonnerie ya ecran mobimba ekobima mpo obungisa mobembo te.',
  'Expense your rides':
      'Zongisa mbongo ya mibembo',
  'Expires: ':
      'Ekosila: ',
  'Expires: {0}':
      'Ekosila: {0}',
  'Family Profile':
      'Profil ya libota',
  'Family Profile will be available soon.':
      'Profil ya libota ekoya noki.',
  'Favorite Places':
      'Bisika olingaka',
  'Favorite removed':
      'Esika elongolami',
  'Fill bank details':
      'Tondisa ba informasio ya banki',
  'Fill in all your bank information.':
      'Tondisa ba informasio nyonso ya banki.',
  'First name':
      'Kombo',
  'First name required':
      'Kombo esengeli',
  'Food delivery':
      'Bomemi ya bilei',
  'Gallery':
      'Galerie',
  'Get promotions based on your trips and favourite routes.':
      'Zwa ba promotion na kolanda mibembo pe banzela olingaka.',
  'Get smart ride suggestions':
      'Zwa ba conseil ya mibembo',
  'Get smart ride suggestions based on your calendar events.':
      'Zwa ba conseil ya mibembo na kolanda calendrier na yo.',
  'Great, I\'ll be at the gate':
      'Malamu, nakozala na ekuke',
  'Have a prescription?':
      'Ozali na ordonnance?',
  'Help us improve ko!ngo with anonymous usage data.':
      'Salisa biso tobongisa ko!ngo na ba donnee ya kozanga kombo.',
  'Hi! I\'m 5 minutes away':
      'Mbote! Natikali minute 5',
  'High':
      'Likolo',
  'How would you like to use KO!NGO?':
      'Ndenge nini olingi kosalela KO!NGO?',
  'I\'m safe':
      'Nazali malamu',
  'I\'m safe — end alert':
      'Nazali malamu — silisa alerte',
  'ID, licence, logbook':
      'Carte d\'identite, permis, carte grise',
  'If the store has already started preparing, you may be charged a fee.':
      'Soki magazini ebandi kobongisa, okoki kofuta mbongo moke.',
  'In an emergency, tap the button below.':
      'Na tango ya likama, finga bouton oyo ezali na nse.',
  'Interested? Email support@efuride.com to join the waitlist.':
      'Olingi? Solola na lisalisi mpo na kokota na liste ya kozela.',
  'Invalid amount':
      'Motango ya mabe',
  'Invalid email':
      'Email ya mabe',
  'Invalid number':
      'Nimero ya mabe',
  'Invalid phone':
      'Telefone ya mabe',
  'Invalid phone number':
      'Nimero ya telefone ya mabe',
  'Item unavailable':
      'Eloko ezali te',
  'KYC documents':
      'Mikanda ya identite',
  'Keep':
      'Tika',
  'Keep active':
      'Tika ezala',
  'Keep alert active':
      'Tika alerte ezala',
  'Keep it':
      'Batela yango',
  'Keep old cart':
      'Batela panier ya kala',
  'Keep signed in':
      'Tikala na kati',
  'Kenyatta Avenue, Nairobi':
      'Avenue de la Paix, Brazzaville',
  'LIVE':
      'SIKOYO',
  'Language':
      'Monoko',
  'Language updated':
      'Monoko ebongisami',
  'Legal':
      'Mibeko',
  'Licenses':
      'Ba licence',
  'Limit reached':
      'Ndelo ekoki',
  'Loading cards':
      'Kofungola ba carte',
  'Loading list':
      'Kofungola liste',
  'Location is off':
      'Localisation ekufi',
  'Location permission needed':
      'Ndingisa ya esika esengeli',
  'Log in':
      'Kota',
  'Log out':
      'Bima',
  'Log out?':
      'Kobima?',
  'Low':
      'Nse',
  'Loyalty':
      'Bosembo',
  'Loyalty points':
      'Ba points ya bosembo',
  'Make (e.g. Toyota)':
      'Marque (ndakisa Toyota)',
  'Make and plate number are required.':
      'Marque pe plaque esengeli.',
  'Make sure both passwords are identical.':
      'Tala ete maloba ya sekele mibale ekokani.',
  'Manage and pay for your family\'s rides':
      'Bongisa pe futa mibembo ya libota na yo',
  'Manage business travel for your company — team members, consolidated billing, and reporting.':
      'Bongisa mibembo ya mosala ya kompani na yo — basali, fakture moko pe ba rapport.',
  'Manage contacts':
      'Bongisa bato',
  'Manage devices signed in to your account':
      'Bongisa ba appareil oyo ekoti na konti na yo',
  'Manage emergency contacts':
      'Bongisa bato ya likama',
  'Manage permission settings':
      'Bongisa ba ndingisa',
  'Manage store':
      'Bongisa magazini',
  'Manage your data and permissions':
      'Bongisa ba donnee pe ba ndingisa na yo',
  'Mark yourself as safe?':
      'Tia ete ozali malamu?',
  'Marked safe':
      'Etiami malamu',
  'Medium':
      'Ya kati',
  'Merchant':
      'Motekisi',
  'Merchant · Orders':
      'Motekisi · Ba komandi',
  'Merchant · Payouts':
      'Motekisi · Lifuti',
  'Message':
      'Message',
  'Message copied':
      'Message ekopiami',
  'Messages from customers during an active trip.':
      'Ba message ya bakiliya na tango ya mobembo.',
  'Messages from drivers during an active trip.':
      'Ba message ya batambwisi na tango ya mobembo.',
  'Min {0} XAF':
      'Min {0} XAF',
  'Missing bank details':
      'Ba informasio ya banki ezali te',
  'Missing details':
      'Ba informasio ezangi',
  'Missing documents':
      'Mikanda ezangi',
  'Missing information':
      'Ba informasio ezangi',
  'Missing vehicle photo':
      'Foto ya motuka ezali te',
  'Model (e.g. Corolla)':
      'Modele (ndakisa Corolla)',
  'Month':
      'Sanza',
  'My Rides':
      'Mibembo na ngai',
  'My Vehicles':
      'Mituka na ngai',
  'My vehicles':
      'Mituka na ngai',
  'NOTIFIED':
      'AYEBISAMI',
  'Name too short':
      'Kombo mokuse mingi',
  'Name updated':
      'Kombo ebongisami',
  'Navigation app':
      'Application ya nzela',
  'Never miss a trip':
      'Bungisa mobembo moko te',
  'New email':
      'Email ya sika',
  'New messages':
      'Ba message ya sika',
  'New password':
      'Liloba ya sekele ya sika',
  'New ride requests':
      'Basenga ya sika ya mibembo',
  'New to ko!ngo':
      'Moto ya sika na ko!ngo',
  'Next settlement: Friday, in 3 days':
      'Lifuti oyo elandi: mokolo ya mitano, na mikolo 3',
  'No active conversation.':
      'Lisolo moko te.',
  'No active ride':
      'Mobembo moko te ezali kosala',
  'No balance to withdraw.':
      'Mbongo ya kobimisa ezali te.',
  'No completed trips yet':
      'Naino mobembo moko te esili',
  'No emergency contacts yet':
      'Naino moto ya likama te',
  'No favorite places yet':
      'Naino esika olingaka te',
  'No internet connection':
      'Internet ezali te',
  'No items on the menu yet':
      'Naino eloko moko te na menu',
  'No items yet':
      'Naino eloko moko te',
  'No matches':
      'Eloko moko te ekokani',
  'No messages yet':
      'Naino message moko te',
  'No payout requests':
      'Bosenga ya lifuti ezali te',
  'No phone number':
      'Nimero ya telefone ezali te',
  'No promotions right now':
      'Promotion ezali te sikoyo',
  'No quiz for this module. It will be marked complete when you finish reading.':
      'Quiz ezali te mpo na module oyo. Ekotiama ete esili tango okosilisa kotanga.',
  'No restaurants nearby yet':
      'Naino restaurant moko te pene',
  'No scheduled rides':
      'Mobembo moko te ebongisami',
  'No top-up requests':
      'Bosenga ya kobakisa mbongo ezali te',
  'No transactions yet':
      'Naino transaction moko te',
  'No trip to rate':
      'Mobembo ya kopesa note ezali te',
  'No trusted contacts yet':
      'Naino moto ya motema te',
  'No vehicles added':
      'Motuka moko te ebakisami',
  'No {0} orders':
      'Komandi moko te ya {0}',
  'No {0} stores nearby':
      'Magazini moko te ya {0} pene',
  'Not signed in':
      'Okoti te',
  'Nothing to rate':
      'Eloko ya kopesa note ezali te',
  'Nothing to withdraw':
      'Eloko ya kobimisa ezali te',
  'Notifications':
      'Ba notification',
  'Offers & codes':
      'Ba ofre pe ba code',
  'Ok!':
      'Malamu!',
  'Onboarding progress':
      'Bokoli ya bokomisi',
  'Once you complete rides, they\'ll show up here with your net earnings.':
      'Soki osilisi mibembo, ekobima awa na lifuti na yo.',
  'One last step':
      'Etape ya suka',
  'Only drivers can request payouts':
      'Kaka batambwisi nde bakoki kosenga lifuti',
  'Open Settings':
      'Fungola bibongiseli',
  'Order cancelled':
      'Komandi etikami',
  'Order not found':
      'Komandi emonani te',
  'Order timeline':
      'Ndenge komandi ezali kokende',
  'Orders':
      'Ba komandi',
  'Other ways to reach us':
      'Banzela misusu ya kokutana na biso',
  'Our team typically responds within a few hours.':
      'Ekipe na biso eyanolaka mingi na ngonga moke.',
  'Our team will respond within a few hours.':
      'Ekipe na biso ekoyanola na ngonga moke.',
  'Owner doc':
      'Mokanda ya nkolo',
  'Page not found':
      'Lokasa emonani te',
  'Passenger':
      'Mokiliya',
  'Passkeys and verification':
      'Ba cle pe bondimi',
  'Password changed':
      'Liloba ya sekele ebongwani',
  'Password must be at least 8 characters.':
      'Liloba ya sekele esengeli kozala na ata bilembo 8.',
  'Password too short':
      'Liloba ya sekele ezali mokuse mingi',
  'Password, sessions, 2FA':
      'Liloba ya sekele, ba session, bondimi ya mibale',
  'Passwords don\'t match':
      'Maloba ya sekele ekokani te',
  'Payment':
      'Lifuti',
  'Payment method':
      'Ndenge ya kofuta',
  'Payout account':
      'Konti ya kozwa lifuti',
  'Payout confirmations':
      'Bondimi ya lifuti',
  'Payout failed — verify bank details and retry.':
      'Lifuti elongi te — tala ba informasio ya banki pe meka lisusu.',
  'Payout requested':
      'Lifuti esengami',
  'Payouts':
      'Lifuti',
  'Payouts, tips, and fare credits will appear here.':
      'Lifuti, matabisi pe bozongisi mbongo ekobima awa.',
  'Peak-hour bonuses, referral rewards, and ko!ngo news.':
      'Ba bonus ya ba ngonga ya bato ebele, matabisi ya kobenga baninga pe sango ya ko!ngo.',
  'Pending admin review.':
      'Ezali kozela botali ya admin.',
  'Permanently remove your account':
      'Longola konti na yo mpo na libela',
  'Personalised offers':
      'Ba ofre mpo na yo',
  'Phone number':
      'Nimero ya telefone',
  'Phone updated':
      'Telefone ebongisami',
  'Photo from your shopper':
      'Foto ya mosombi na yo',
  'Photo required':
      'Foto esengeli',
  'Photo saved':
      'Foto ebombami',
  'Photo selected':
      'Foto eponami',
  'Photo updated':
      'Foto ebongisami',
  'Pick a future time':
      'Pona tango oyo ekoya',
  'Pick a rating':
      'Pona note',
  'Pick a service':
      'Pona mosala',
  'Pick a time':
      'Pona tango',
  'Pickup':
      'Esika ya kozwa',
  'Pickup location':
      'Esika ya kozwa',
  'Plate Number (e.g. CA123-45)':
      'Nimero ya plaque (ndakisa BZ-1234-AB)',
  'Plate: {0}':
      'Plaque: {0}',
  'Play an audible alert when a new ride comes in.':
      'Beta lokito tango mobembo ya sika eyei.',
  'Please check the number and try again.':
      'Tala nimero pe meka lisusu.',
  'Please check your details and try again.':
      'Tala ba informasio na yo pe meka lisusu.',
  'Please check your network and try again.':
      'Tala reseau na yo pe meka lisusu.',
  'Please choose an option for each.':
      'Pona eyano mpo na moko na moko.',
  'Please enter a valid email address.':
      'Kotisa adresi ya email ya malamu.',
  'Please enter a valid phone number.':
      'Kotisa nimero ya telefone ya malamu.',
  'Please enter at least 2 characters.':
      'Kotisa ata bilembo 2.',
  'Please enter both pickup and dropoff.':
      'Kotisa esika ya kozwa pe esika ya kokitisa.',
  'Please enter your first name.':
      'Kotisa kombo na yo.',
  'Please fill in both the subject and message.':
      'Tondisa motuna pe message.',
  'Please select when you want the ride.':
      'Pona tango olingi mobembo.',
  'Please sign in again to continue.':
      'Kota lisusu mpo na kokoba.',
  'Please sign in again.':
      'Kota lisusu.',
  'Please sign in to use chat.':
      'Kota mpo na kosalela lisolo.',
  'Please sign in.':
      'Kota.',
  'Please try again in a moment.':
      'Meka lisusu sima ya mwa tango.',
  'Please turn on GPS so we can find you.':
      'Pelisa GPS po tokoka kozwa yo.',
  'Please upload a photo of the vehicle.':
      'Tinda foto ya motuka.',
  'Please upload all required documents first.':
      'Tinda mikanda nyonso esengeli liboso.',
  'Police':
      'Polisi',
  'Prescription on file':
      'Ordonnance ebombami',
  'Price impact':
      'Bobongwani ya ntalo',
  'Priority':
      'Ntina',
  'Privacy':
      'Bomoko',
  'Privacy Policy':
      'Politiki ya bomoko',
  'Profile':
      'Profil',
  'Profile not found':
      'Profil emonani te',
  'Promo applied! You save {0}.':
      'Promo esalemi! Obombi {0}.',
  'Promo code  applied!':
      'Code promo esalemi!',
  'Promo codes, offers, and savings':
      'Ba code promo, ba ofre pe mbongo obombi',
  'Promotions':
      'Ba promotion',
  'Promotions & Offers':
      'Ba promotion pe ba ofre',
  'Promotions and bonuses':
      'Ba promotion pe ba bonus',
  'Promotions and offers':
      'Ba promotion pe ba ofre',
  'QUICK QUIZ':
      'QUIZ MOKE',
  'R50 credited after your friend\'s first completed ride.':
      'Bonus ekotiama sima ya mobembo ya liboso ya moninga na yo.',
  'Rate trip':
      'Pesa note na mobembo',
  'Rating':
      'Note',
  'Ref: {0}':
      'Ref.: {0}',
  'Refer & Earn':
      'Benga baninga pe zwa',
  'Refer a Friend':
      'Benga moninga',
  'Refer a friend':
      'Benga moninga',
  'Refresh':
      'Zongisa sika',
  'Rejected — please edit and resubmit.':
      'Eboyami — bongisa pe tinda lisusu.',
  'Remove':
      'Longola',
  'Remove contact?':
      'Longola moto?',
  'Remove favorite?':
      'Longola esika olingaka?',
  'Replace':
      'Bongola',
  'Request Payout':
      'Senga lifuti',
  'Request a payout and we\'ll show its status here.':
      'Senga lifuti pe tokolakisa ndenge ezali awa.',
  'Request payout':
      'Senga lifuti',
  'Request timed out':
      'Tango ya bosenga esili',
  'Required':
      'Esengeli',
  'Resend code':
      'Tinda code lisusu',
  'Resend code in {0}s':
      'Tinda code lisusu na ba seconde {0}',
  'Retry':
      'Meka lisusu',
  'Retry payout':
      'Meka lifuti lisusu',
  'Review my documents':
      'Tala mikanda na ngai',
  'Ride  •  Deliver  •  Move':
      'Mobembo  •  Bomemi  •  Kotambola',
  'Ride not found':
      'Mobembo emonani te',
  'Ride removed':
      'Mobembo elongolami',
  'Ride requests, chat, bonuses':
      'Basenga ya mibembo, lisolo, ba bonus',
  'Ride scheduled':
      'Mobembo ebongisami',
  'Ride updates':
      'Sango ya mibembo',
  'Rides':
      'Mibembo',
  'Rides you pay for and top-ups you make will appear here.':
      'Mibembo ofutaki pe mbongo obakisaki ekobima awa.',
  'Ring + push when a customer books nearby. Turn off and you won\'t see new rides.':
      'Sonnerie + notification tango mokiliya pene asengi. Soki okufisi, okomona mibembo ya sika te.',
  'Ring sound':
      'Lokito ya sonnerie',
  'SHOPPER SUGGESTS':
      'MOSOMBI ALINGI',
  'SOS ACTIVE':
      'SOS EZALI KOSALA',
  'STEP {0}':
      'ETAPE {0}',
  'Safety':
      'Bokengi',
  'Safety center':
      'Esika ya bokengi',
  'Save':
      'Bomba',
  'Save & continue to vehicle':
      'Bomba pe kende na motuka',
  'Save draft':
      'Bomba brouillon',
  'Save frequently visited places for faster booking.':
      'Bomba bisika okendaka mingi mpo na kosenga noki.',
  'Save on every ride':
      'Bomba mbongo na mobembo nyonso',
  'Saved bank details will be used next time.':
      'Ba informasio ya banki ebombami ekosalelama mbala ekoya.',
  'Saved places':
      'Bisika ebombami',
  'Say hi to {0} to coordinate pickup.':
      'Pesa {0} mbote mpo na kobongisa bozwi.',
  'Schedule':
      'Bongisa',
  'Schedule a Ride':
      'Bongisa mobembo',
  'Schedule a ride':
      'Bongisa mobembo',
  'Schedule a ride for later':
      'Bongisa mobembo mpo na sima',
  'Scheduled Rides':
      'Mibembo ebongisami',
  'Seats / capacity':
      'Bisika ya kofanda / bonene',
  'See your ride statistics':
      'Tala ba statistique ya mibembo na yo',
  'Send an EFT to the business account, then submit this form with your reference. Admin will confirm.':
      'Tinda mbongo na banki na konti ya kompani, sima tinda formulaire oyo na reference na yo. Admin akondima.',
  'Send code':
      'Tinda code',
  'Send link':
      'Tinda lien',
  'Send trip summaries to your registered email.':
      'Tinda lisolo mokuse ya mibembo na email na yo.',
  'Services this vehicle can serve':
      'Misala motuka oyo ekoki kosala',
  'Session expired':
      'Session esili',
  'Settings':
      'Bibongiseli',
  'Settlement history':
      'Lisolo ya lifuti',
  'Setup is available from your Supabase dashboard. Coming to the app soon.':
      'Bobongisi ezali na tableau de bord. Ekoya na application noki.',
  'Share Referral Link':
      'Kabola lien ya kobenga baninga',
  'Share it with a friend to earn R50.':
      'Kabola yango na moninga mpo na kozwa bonus.',
  'Share link: efuride://track/{0}':
      'Lien: efuride://track/{0}',
  'Share live location':
      'Kabola esika ozali sikoyo',
  'Share more feedback (optional)':
      'Pesa makanisi mosusu (soki olingi)',
  'Share your code and earn R50 for each friend who takes their first ride.':
      'Kabola code na yo pe zwa bonus mpo na moninga nyonso oyo akosala mobembo na ye ya liboso.',
  'Shop & pick':
      'Somba pe pona',
  'Shopper':
      'Mosombi',
  'Sign Out':
      'Bima',
  'Sign in and security':
      'Kokota pe bokengi',
  'Sign out':
      'Bima',
  'Sign out?':
      'Kobima?',
  'Skip':
      'Leka',
  'Skip for now':
      'Leka sikoyo',
  'Skip item':
      'Leka eloko',
  'Some required details are missing. Please try again.':
      'Ba informasio mosusu esengeli ezangi. Meka lisusu.',
  'Something went wrong':
      'Likambo moko esalemi',
  'Something went wrong on our side. Please try again.':
      'Likambo moko esalemi epai na biso. Meka lisusu.',
  'Sound & alerts':
      'Lokito pe ba alerte',
  'Standard SMS rates may apply. We\'ll never share your number.':
      'Ntalo ya SMS ekoki kozala. Tokokabola nimero na yo te.',
  'Start a new cart?':
      'Kobanda panier ya sika?',
  'Start new':
      'Banda ya sika',
  'Stay':
      'Tikala',
  'Stay where you are. Help is on the way.':
      'Tikala esika ozali. Lisalisi ezali koya.',
  'Step 1 · Upload your documents':
      'Etape 1 · Tinda mikanda na yo',
  'Still pending':
      'Naino ezali kozela',
  'Subject':
      'Motuna',
  'Submit a support ticket':
      'Tinda bosenga ya lisalisi',
  'Submit for admin approval':
      'Tinda mpo na bondimi ya admin',
  'Submit for approval':
      'Tinda mpo na bondimi',
  'Submit payout request':
      'Tinda bosenga ya lifuti',
  'Submit rating':
      'Tinda note',
  'Substitution':
      'Kobongola eloko',
  'Substitution request':
      'Bosenga ya kobongola eloko',
  'Suggest rides ahead of your meetings and appointments.':
      'Pesa toli ya mibembo liboso ya ba reunion na yo.',
  'Support':
      'Lisalisi',
  'Surname':
      'Kombo ya libota',
  'Sync calendar':
      'Kangisa calendrier',
  'TAP FOR SOS':
      'FINGA MPO NA SOS',
  'TEAM MEMBER SIGN-IN':
      'KOKOTA YA EKIPE',
  'TRIGGER SOS':
      'BETA SOS',
  'TRIGGERING SOS':
      'SOS EZALI KOBANDA',
  'Take a clear selfie so drivers and passengers can recognise you during trips.':
      'Zwa selfie ya polele po batambwisi pe bakiliya bayeba yo na tango ya mobembo.',
  'Take a selfie to continue.':
      'Zwa selfie mpo na kokoba.',
  'Take your photo':
      'Zwa foto na yo',
  'Tap a star to rate your customer.':
      'Finga monzoto mpo na kopesa mokiliya na yo note.',
  'Tap a star to rate your driver.':
      'Finga monzoto mpo na kopesa motambwisi na yo note.',
  'Tap a star to rate your experience.':
      'Finga monzoto mpo na kopesa note na ndenge esalemaki.',
  'Tap once — we handle the rest':
      'Finga mbala moko — tokosala oyo etikali',
  'Tell us more about your experience':
      'Yebisa biso mingi mpo na ndenge esalemaki',
  'Terms':
      'Mibeko',
  'Terms of Service':
      'Mibeko ya bosaleli',
  'Thanks for rating!':
      'Matondi mpo na note!',
  'Thanks for riding with ko!ngo.':
      'Matondi mpo osalaki mobembo na ko!ngo.',
  'Thanks — your rating was recorded.':
      'Matondi — note na yo ebombami.',
  'That number is already in your list.':
      'Nimero wana ezali kala na liste na yo.',
  'The place has been removed from your list.':
      'Esika elongolami na liste na yo.',
  'The scheduled time must be in the future.':
      'Tango obongisi esengeli kozala na mikolo ekoya.',
  'The server took too long to respond. Try again.':
      'Serveur eumeli mingi koyanola. Meka lisusu.',
  'The store has been notified.':
      'Magazini eyebisami.',
  'There\'s no trip to chat about yet.':
      'Naino mobembo ya kosolola ezali te.',
  'They will no longer be notified.':
      'Bakoyeba lisusu te.',
  'They\'ll be notified when you trigger SOS.':
      'Bakoyeba tango okobeta SOS.',
  'This action cannot be undone.':
      'Okoki kozongisa yango te.',
  'This device':
      'Appareil oyo',
  'This email is already in use. Try signing in.':
      'Email oyo ezali kosalelama kala. Meka kokota.',
  'This permanently deletes your account, trip history, and saved data.':
      'Ekolongola mpo na libela konti na yo, lisolo ya mibembo pe ba donnee ebombami.',
  'This place will be removed from your list.':
      'Esika oyo ekolongolama na liste na yo.',
  'This promo has expired.':
      'Promo oyo esili.',
  'This promo has reached its limit.':
      'Promo oyo ekomi na ndelo.',
  'This promo hasn\'t started yet.':
      'Promo oyo naino ebandi te.',
  'This promo is not active right now.':
      'Promo oyo ezali kosala te sikoyo.',
  'This record already exists. Try a different value.':
      'Eloko oyo ezali kala. Meka eloko mosusu.',
  'This scheduled ride will be removed and will not be booked.':
      'Mobembo oyo ebongisami ekolongolama pe ekosengama te.',
  'This trip may have been removed.':
      'Mobembo oyo ekoki kozala elongolami.',
  'This will alert your emergency contacts and our support team with your location. Use only in a real emergency.':
      'Ekoyebisa bato na yo ya likama pe ekipe na biso ya lisalisi esika ozali. Salela kaka na likama ya solo.',
  'This will end the SOS alert. Your contacts will be told you\'re safe.':
      'Ekosilisa alerte ya SOS. Bato na yo bakoyeba ete ozali malamu.',
  'This will open your phone\'s dialer with the number pre-filled.':
      'Ekofungola telefone na yo na nimero esi ekomami.',
  'Ticket submitted':
      'Bosenga etindami',
  'Tier benefits':
      'Matomba ya ba niveau',
  'Top up':
      'Bakisa mbongo',
  'Top up now':
      'Bakisa mbongo sikoyo',
  'Top up your wallet':
      'Bakisa mbongo na sakosi na yo',
  'Top-up request sent':
      'Bosenga ya kobakisa mbongo etindami',
  'Top-ups':
      'Kobakisa mbongo',
  'Total':
      'Nyonso',
  'Tracking services':
      'Misala ya bolandi',
  'Transactions':
      'Ba transaction',
  'Trigger SOS':
      'Beta SOS',
  'Trigger SOS?':
      'Kobeta SOS?',
  'Trip complete':
      'Mobembo esili',
  'Trip completed':
      'Mobembo esili',
  'Trip completed!':
      'Mobembo esili!',
  'Try again':
      'Meka lisusu',
  'Two-factor authentication':
      'Bondimi ya mibale',
  'Type DELETE in capitals to confirm.':
      'Koma LONGOLA na makomi minene mpo na kondima.',
  'Type a message...':
      'Koma message…',
  'Type a message…':
      'Koma message…',
  'Typing':
      'Azali kokoma',
  'Unlock exclusive benefits':
      'Fungola matomba ya kokesena',
  'Update the email on your account':
      'Bongola email ya konti na yo',
  'Update your account password':
      'Bongola liloba ya sekele ya konti na yo',
  'Uploaded':
      'Etindami',
  'Usage analytics':
      'Ba statistique ya bosaleli',
  'Use your new password next time you log in.':
      'Salela liloba ya sekele ya sika tango okokota lisusu.',
  'VERIFIED':
      'ENDIMAMI',
  'Vehicle':
      'Motuka',
  'Vehicle class':
      'Lolenge ya motuka',
  'Vehicle deleted':
      'Motuka elongolami',
  'Vehicle photo':
      'Foto ya motuka',
  'Verify & continue':
      'Ndimisa pe kokoba',
  'View uploaded file':
      'Tala fichier etindami',
  'View your tier and rewards':
      'Tala niveau pe matabisi na yo',
  'Wallet':
      'Sakosi',
  'Wallet balance':
      'Mbongo na sakosi',
  'We can\'t dial that phone number.':
      'Tokoki kobenga nimero wana te.',
  'We couldn\'t find a completed ride.':
      'Tozwi mobembo moko te esili.',
  'We couldn\'t reach our servers. Please try again.':
      'Tokoki kokoma na ba serveur na biso te. Meka lisusu.',
  'We never sell your personal data.':
      'Tokotekaka soki moke te ba donnee na yo.',
  'We sent a confirmation link to your new email address.':
      'Totindi lien ya bondimi na email na yo ya sika.',
  'We use your phone for trip updates and driver contact.':
      'Tosalelaka telefone na yo mpo na sango ya mobembo pe kosolola na motambwisi.',
  'We\'ll dispatch a driver near the time.':
      'Tokotinda motambwisi pene ya tango.',
  'We\'ll process it within 2 business days.':
      'Tokosala yango na mikolo 2 ya mosala.',
  'Week':
      'Poso',
  'Weekly settlement':
      'Lifuti ya poso na poso',
  'Weekly settlement · PawaPay':
      'Lifuti ya poso na poso · PawaPay',
  'Welcome aboard. Taking you to your dashboard.':
      'Boyei malamu. Tozali kotambwisa yo na tableau de bord.',
  'Welcome to ko!ngo Academy':
      'Boyei malamu na Eteyelo ya ko!ngo',
  'What you\'ll be able to do':
      'Nini okokoka kosala',
  'When a payout is processed or rejected.':
      'Tango lifuti esalemi to eboyami.',
  'When you submit a top-up, you\'ll be able to track its approval here.':
      'Soki otindi bosenga ya kobakisa mbongo, okoki kolanda bondimi na yango awa.',
  'Which app should open when you tap "Start trip"?':
      'Application nini efungwama tango ofingi "Banda mobembo"?',
  'Work Profile':
      'Profil ya mosala',
  'Wrong email or password':
      'Email to liloba ya sekele ya mabe',
  'YOU ORDERED':
      'OSOMBAKI',
  'Year':
      'Mobu',
  'You':
      'Yo',
  'You can save up to {0} contacts.':
      'Okoki kobomba kino bato {0}.',
  'You can sign back in anytime to check your approval status.':
      'Okoki kokota lisusu tango nyonso mpo na kotala bondimi na yo.',
  'You don\'t have a balance to pay out yet.':
      'Naino ozali na mbongo ya kofutama te.',
  'You have arrived!':
      'Okomi!',
  'You will stop receiving new orders until you sign in again.':
      'Okozwa lisusu ba komandi ya sika te kino okokota lisusu.',
  'You\'ll need to sign in again to book rides.':
      'Osengeli kokota lisusu mpo na kosenga mibembo.',
  'You\'ll stop receiving ride requests until you sign in again.':
      'Okozwa lisusu basenga ya mibembo te kino okokota lisusu.',
  'You\'re all set.':
      'Nyonso ebongi.',
  'You\'re approved!':
      'Ondimami!',
  'You\'re not a participant in this trip.':
      'Ozali moto ya mobembo oyo te.',
  'You\'ve already rated this trip. Thanks for the feedback!':
      'Opesi kala note na mobembo oyo. Matondi mpo na makanisi na yo!',
  'You\'ve already used this promo.':
      'Osaleli kala promo oyo.',
  'Your contacts have been notified.':
      'Bato na yo bayebisami.',
  'Your data export':
      'Kobimisa ba donnee na yo',
  'Your device may not have a phone app. Please dial manually.':
      'Appareil na yo ekoki kozala na application ya telefone te. Benga yo moko.',
  'Your documents have been submitted. An administrator will review them shortly — usually within a few hours.':
      'Mikanda na yo etindami. Admin akotala yango noki — mingi na ngonga moke.',
  'Your earnings have been added to your wallet.':
      'Lifuti na yo ebakisami na sakosi na yo.',
  'Your emergency contacts':
      'Bato na yo ya likama',
  'Your emergency contacts and our support team have been alerted with your location.':
      'Bato na yo ya likama pe ekipe na biso ya lisalisi bayebisami esika ozali.',
  'Your emergency contacts and our support team will be notified with your location.':
      'Bato na yo ya likama pe ekipe na biso ya lisalisi bakoyebisama esika ozali.',
  'Your feedback helps improve ko!ngo.':
      'Makanisi na yo esalisaka kobongisa ko!ngo.',
  'Your feedback helps keep ko!ngo safe.':
      'Makanisi na yo esalisaka ko!ngo ezala na bokengi.',
  'Your name has been saved.':
      'Kombo na yo ebombami.',
  'Your new profile photo is live.':
      'Foto na yo ya sika ya profil ezali en ligne.',
  'Your number stays hidden. Only the call is connected.':
      'Nimero na yo ebombamaka. Kaka telefone nde ekangisami.',
  'Your personal data':
      'Ba donnee na yo',
  'Your phone number has been saved.':
      'Nimero na yo ya telefone ebombami.',
  'Your photo is visible to drivers and passengers during trips.':
      'Foto na yo emonanaka na batambwisi pe bakiliya na tango ya mobembo.',
  'Your scheduled ride has been cancelled.':
      'Mobembo na yo oyo ebongisamaki etikami.',
  'Your trips will appear here':
      'Mibembo na yo ekobima awa',
  'Your vehicle has been removed.':
      'Motuka na yo elongolami.',
  'Your vehicle will be reviewed by an admin before it becomes active.':
      'Motuka na yo ekotalama na admin liboso ya kobanda kosala.',
  'e.g. 11 2nd Street, Firgrove':
      'ndakisa 11 rue Mbochi, Moungali',
  'e.g. 45 Main Rd, CBD':
      'ndakisa 45 avenue de la Paix, Centre-ville',
  'ko!ngo Plus will be available soon.':
      'ko!ngo Plus ekoya noki.',
  'ko!ngo needs your location to find nearby drivers.':
      'ko!ngo esengeli esika ozali mpo na koluka batambwisi pene.',
  'typing…':
      'azali kokoma…',
  '{0} XAF pending':
      '{0} XAF ezali kozela',
  '{0} active':
      '{0} ezali kosala',
  '{0} has a suggestion':
      '{0} azali na likanisi',
  '{0} hasn\'t added a phone number to their profile.':
      '{0} abakisi naino nimero ya telefone na profil na ye te.',
  '{0} is ready to paste.':
      '{0} ebongi mpo na kotia.',
  '{0} is typing…':
      '{0} azali kokoma…',
  '{0} new':
      '{0} ya sika',
  '{0} of {1} complete':
      '{0} na {1} esili',
  '{0} of {1} modules complete':
      'Ba module {0} na {1} esili',
  '{0} points':
      'Ba points {0}',
  '{0} points to {1}':
      'Ba points {0} kino {1}',
  '💬 New message from {0}':
      '💬 Message ya sika uta na {0}',
  '🚨 SOS activated':
      '🚨 SOS ebandi',
  'Are you sure you want to remove "{0}"?':
      'Ozali solo na mposa ya kolongola "{0}"?',
  'The price has changed':
      'Ntalo ebongwani',
  'Please go back and check the price again.':
      'Zonga nsima mpe tala ntalo lisusu.',
  'The lowest price for this trip is {0}. Please go back and check the price again.':
      'Ntalo ya nse mpenza mpo na mobembo oyo ezali {0}. Zonga nsima mpe tala ntalo lisusu.',
  'Not enough money in your wallet':
      'Mbongo ekoki te na portefeuille na yo',
  'Top up your wallet or choose another way to pay.':
      'Bakisa mbongo na portefeuille to pona lolenge mosusu ya kofuta.',
  'The picture could not be uploaded':
      'Elilingi ekokaki kotinda te',
  '{0}\n\nYou can save the product now and add the picture later.':
      '{0}\n\nOkoki kobomba eloko sikoyo mpe kobakisa elilingi na nsima.',
  'Save without picture':
      'Bomba kozanga elilingi',
  'OK':
      'Malamu',
  'Choose on map':
      'Pona na karte',
  'Tap the map where you want to be picked up':
      'Simba karte esika olingi bázwa yo',
  'Tap the map where you are going':
      'Simba karte esika ozali kokende',
  'Pinned location':
      'Esika ya elembo',
  'Clear':
      'Longola',
  'Use my current location':
      'Salela esika nazali sikoyo',
  'Street, suburb or landmark':
      'Balabala, quartier to elembo',
  'No places found. Try a street name or landmark.':
      'Esika moko te emonani. Meka nkombo ya balabala to elembo.',
  'Current location':
      'Esika ozali sikoyo',
  'Closed':
      'Ekangami',
  'Nearby pharmacies':
      'Bisika ya nkisi pembeni',
  'Stores near you':
      'Bandaka pembeni na yo',
  'Country':
      'Ekolo',
  'Choose your country':
      'Pona ekolo na yo',
  'Add a place':
      'Bakisa esika',
  'Name this place':
      'Pesa esika oyo nkombo',
  'Home':
      'Ndako',
  'Work':
      'Mosala',
  'e.g. Mom\'s place':
      'ndakisa Epai ya mama',
  'Place':
      'Esika',
  'Drivers, shoppers and store owners use a separate ko!ngo account, with a different email address. Your customer account stays as it is.':
      'Bashoferi, basombi mpe bankolo ya bandaka basalelaka konti mosusu ya ko!ngo, na e-mail mosusu. Konti na yo ya mosombi etikali ndenge ezali.',
  'To create it, you will be signed out of this account. You can sign back in any time.':
      'Mpo na kosala yango, okobima na konti oyo. Okoki kozonga ntango nyonso.',
  'Sign out and create partner account':
      'Bima mpe sala konti ya moninga',
  'Stay signed in':
      'Tikala kati',
  'Invite friends and earn ride credit':
      'Benga baninga mpe zwa crédit ya mobembo',
  'No offers right now':
      'Likabo moko te sikoyo',
  'New promo codes will show here.':
      'Ba code ya sika ekomonana awa.',
  '{0}% off':
      '{0}% ekitisami',
  '{0} off':
      '{0} ekitisami',
  'Valid until {0}':
      'Ezali malamu tii {0}',
  'Minimum {0}':
      'Moke {0}',
  'Code {0} copied. Paste it when you book or check out.':
      'Code {0} ekopiami. Tia yango ntango ozali kosala commande to kofuta.',
  'My orders':
      'Ba commande na ngai',
  'Active':
      'Oyo ezali kosalema',
  'Past':
      'Oyo eleki',
  'No active orders':
      'Commande moko te ezali kosalema',
  'No past orders yet':
      'Commande ya kala ezali te',
  'Order food, groceries or medicine from the Home tab.':
      'Sombá bilei, biloko to nkisi uta na Ndako.',
  '{0} items':
      'Biloko {0}',
  'Order placed':
      'Commande etiami',
  'Being prepared':
      'Ezali kobongisama',
  'Ready for pickup':
      'Ebongi kozwama',
  'On the way':
      'Ezali na nzela',
  'Delivered':
      'Ekomi',
  'Returned to office':
      'Ezongisami na biro',
  'Cancelled':
      'Ekangami',
  'Refunded':
      'Mbongo ezongisami',
  'Order payment':
      'Kofuta commande',
  'Ride payment':
      'Kofuta mobembo',
  'Refund':
      'Kozongisa mbongo',
  'Bonus':
      'Bonus',
  'Top-up':
      'Kobakisa mbongo',
  'Amount':
      'Motuya',
  'How did you pay?':
      'Ofutaki ndenge nini?',
  'Bank transfer':
      'Kotinda na banki',
  'Payment reference (optional)':
      'Référence ya kofuta (soki olingi)',
  'Send top-up request':
      'Tinda bosenga',
  'Pay ko!ngo by bank transfer or cash, then send this request. Your balance goes up when ko!ngo confirms the payment.':
      'Futa ko!ngo na banki to na mbongo, sima tinda bosenga oyo. Mbongo na yo ekomata ntango ko!ngo ekondima.',
  'Your balance goes up when ko!ngo confirms it.':
      'Mbongo na yo ekomata ntango ko!ngo ekondima.',
  'Waiting for approval':
      'Ezali kozela bondimi',
  'Activity':
      'Misala',
  '{0} waiting for approval':
      '{0} ezali kozela bondimi',
  'Add money to pay for rides and orders without cash.':
      'Bakisa mbongo mpo na kofuta mobembo mpe commande kozanga mbongo ya maboko.',
  'Payments, top-ups and refunds will show here.':
      'Kofuta, kobakisa mpe kozongisa ekomonana awa.',
  'Wallet & payouts':
      'Portefeuille mpe bafuti',
  'Payouts on the way':
      'Bafuti ezali koya',
  'Trip earnings':
      'Matomba ya mobembo',
  'Past payouts':
      'Bafuti ya kala',
  'Wallet {0} · Unpaid trips {1}':
      'Portefeuille {0} · Mibembo ezangi kofutama {1}',
  'ko!ngo fee {0}% · {1} completed trips':
      'Frais ya ko!ngo {0}% · mibembo {1} esili',
  'Completed trips and what you earned on each will show here.':
      'Mibembo osilisi mpe matomba na yo ekomonana awa.',
  'Payout':
      'Kofutama',
  'Tip':
      'Matabisi',
  'Credit':
      'Crédit',
  'Deduction':
      'Kolongola',
  'Rewards':
      'Mbano',
  'App':
      'Application',
  'More':
      'Mosusu',
  'Privacy and security':
      'Sekele mpe libateli',
  'Edit profile':
      'Bongisa profil',
  '{0} ratings':
      'Ba avis {0}',
  'Your profile':
      'Profil na yo',
  'Signing out…':
      'Ozali kobima…',
  'Wallet & payment':
      'Portefeuille mpe kofuta',
  'Balance, top up and activity':
      'Mbongo, kobakisa mpe misala',
  'Home, work and favourites':
      'Ndako, mosala mpe oyo olingaka',
  'Emergency contacts and SOS':
      'Bato ya likama mpe SOS',
  'Get help with a trip or order':
      'Zwa lisalisi mpo na mobembo to commande',
  'Notifications and email receipts':
      'Bayebisi mpe bareçu na e-mail',
  'Password, email and sessions':
      'Mot de passe, e-mail mpe ba sessions',
  'Terms and privacy policy':
      'Mibeko mpe politique ya sekele',
  'Pay ko!ngo with one of the methods below, then send this request. Your balance goes up when ko!ngo confirms the payment.':
      'Futa ko!ngo na moko ya banzela oyo ezali awa na nse, sima tinda bosenga oyo. Mbongo na yo ekobakisama soki ko!ngo endimi kofuta.',
  'Pay to: {0}':
      'Futa epai ya: {0}',
  'Contact ko!ngo support for the {0} payment details.':
      'Benga lisalisi ya ko!ngo mpo na koyeba ndenge ya kofuta na {0}.',
  'Transaction code (from the SMS)':
      'Code ya transaction (na SMS)',
  'Bank transfer (EFT)':
      'Kotinda na banki (EFT)',
  'Customers can order now':
      'Bakiliya bakoki kosenga sikoyo',
  'Closed: customers cannot order':
      'Ekangami: bakiliya bakoki kosenga te',
  'New and active orders':
      'Ba commande ya sika mpe oyo ezali kotambola',
  'How will you pay?':
      'Okofuta ndenge nini?',
  'ko!ngo wallet':
      'Portefeuille ya ko!ngo',
  'Balance {0}':
      'Mbongo {0}',
  'Balance {0}: not enough for this':
      'Mbongo {0}: ekoki te',
  'Cash':
      'Mbongo ya maboko',
  'Card':
      'Carte',
  'Visa or Mastercard':
      'Visa to Mastercard',
  'Not enough in your wallet':
      'Mbongo ekoki te',
  'Top up your wallet or choose cash.':
      'Bakisa mbongo to pona mbongo ya maboko.',
  'Not enough in your wallet. Top up or choose cash.':
      'Mbongo ekoki te. Bakisa to pona mbongo ya maboko.',
  'Pay the courier':
      'Futa motindi',
  'Pay the driver at the end of the trip':
      'Futa shoferi na nsuka ya mobembo',
  'Pay the courier at pickup':
      'Futa motindi tango azwi colis',
  'Pay the driver when it arrives':
      'Futa shoferi tango akomi',
  'Paid from wallet':
      'Efutami na portefeuille',
  'Paid by card':
      'Efutami na carte',
  'Cash: collect from customer':
      'Mbongo ya maboko: zwa epai ya kiliya',
  'Collect {0} cash from the customer':
      'Zwa {0} mbongo ya maboko epai ya kiliya',
  'Paid from the customer\'s wallet. No cash to collect.':
      'Efutami na portefeuille ya kiliya. Mbongo ya kozwa ezali te.',
  'Paid in the app. No cash to collect.':
      'Efutami na application. Mbongo ya kozwa ezali te.',
  'Card not available':
      'Carte ezali te',
  'Card payments are not available here yet. Please choose cash or wallet.':
      'Kofuta na carte ezali naino awa te. Pona mbongo ya maboko to portefeuille.',
  'New message to support':
      'Nsango ya sika epai ya lisalisi',
  'What is it about?':
      'Ezali mpo na nini?',
  'e.g. Payment, a trip, an order':
      'ndakisa Kofuta, mobembo, commande',
  'Tell us what happened':
      'Yebisa biso nini esalemaki',
  'Send':
      'Tinda',
  'Solved':
      'Esilisami',
  'Answered':
      'Bazongisi',
  'Waiting for support':
      'Ezali kozela lisalisi',
  'Message support':
      'Komela lisalisi',
  'Chat with the ko!ngo team. We reply here and you get a notification.':
      'Solola na équipe ya ko!ngo. Tozongisaka awa mpe okozwa bayebisi.',
  'Your conversations':
      'Masolo na yo',
  'No conversations yet. Tap "Message support" to start one.':
      'Masolo ezali naino te. Finá "Komela lisalisi" mpo na kobanda.',
  'WhatsApp':
      'WhatsApp',
  'ko!ngo support':
      'Lisalisi ya ko!ngo',
  'Our team will reply here. You will get a notification.':
      'Équipe na biso ekozongisa awa. Okozwa bayebisi.',
  'Write a message':
      'Koma nsango',
  'This is a {0} account':
      'Oyo ezali compte ya {0}',
  'These details belong to a {0} account, so they can\'t be used on the {1} login. Please sign in from the {0} login.':
      'Ba informations oyo ezali ya compte ya {0}, yango ekoki kosalelama te na kokota ya {1}. Kota na nzela ya kokota ya {0}.',
  'Go to {0} login':
      'Kende na kokota ya {0}',
  'Where to?':
      'Ozali kokende wapi?',
  'Later':
      'Sima',
  'Add home':
      'Bakisa ndako',
  'You are here · {0} cars nearby':
      'Ozali awa · mituka {0} pene',
  'You are here':
      'Ozali awa',
  'Tap to copy the code':
      'Finá mpo na kozwa code',
  'Offers and promo codes':
      'Ba offres mpe ba code promo',
  'See what is on today':
      'Tala oyo ezali lelo',
  'Take a photo':
      'Kamata foto',
  'Choose from gallery':
      'Pona na galerie',
  'Send a photo':
      'Tinda foto',
  'Sedan (up to 4 seats)':
      'Sedan (bisika 4)',
  'XL (6 seats, SUV / minivan)':
      'XL (bisika 6, SUV / minivan)',
  'Van / minibus (up to 14 seats)':
      'Van / minibus (bisika 14)',
  'Large van (cargo)':
      'Van monene (biloko)',
  'Truck':
      'Kamio',
  'Motorbike / Scooter':
      'Pikipiki / scooter',
  'Money in your wallet':
      'Mbongo na portefeuille na yo',
  'You still have {0} in your ko!ngo wallet. If you delete your account now, this money is lost. Contact support first if you want it back.':
      'Ozali naino na {0} na portefeuille ya ko!ngo. Soki olongoli compte sikoyo, mbongo oyo ekobunga. Benga lisalisi liboso soki olingi kozwa yango.',
  'Keep my account':
      'Tika compte na ngai',
  'Delete anyway':
      'Longola kaka',
  'Not yet':
      'Naino te',
  'Finish or cancel your current trip first.':
      'Silisa to tika mobembo na yo ya sikoyo liboso.',
  'Wait until your order is delivered or cancel it first.':
      'Zela commande na yo ekoma to tika yango liboso.',
  'Your driver':
      'Shoferi na yo',
  'Chat opens once a driver has your order.':
      'Masolo ekofungwama soki shoferi azwi commande na yo.',
  'Orders waiting for a driver':
      'Ba commande ezali kozela shoferi',
  'Tap an order to see it and accept it.':
      'Finá commande mpo na kotala yango mpe kondima.',
  'No orders waiting right now':
      'Commande moko te ezali kozela sikoyo',
  'away':
      'mosika',
  'waiting {0} min':
      'ezali kozela miniti {0}',
  '{0} orders waiting':
      'Ba commande {0} ezali kozela',
  'NO ANSWER':
      'EYANOLI TE',
  'The customer didn\'t answer. Pick the original item or leave it out.':
      'Kiliya ayanoli te. Kamata eloko ya liboso to tika yango.',
  'OK, continue shopping':
      'Malamu, kobá kosomba',
  'Your trip has started. Only the driver can end it now.':
      'Mobembo na yo ebandi. Kaka shoferi nde akoki kosilisa yango sikoyo.',
  'Trip already started':
      'Mobembo ebandi kala',
  'This trip was cancelled.':
      'Mobembo oyo etikami.',
  'See all':
      'Tala nyonso',
  'View':
      'Tala',
  'Messages':
      'Bansango',
  'Yesterday':
      'Lobi eleki',
  'Trips and deliveries':
      'Mibembo mpe kotinda',
  'Chats from your trips show here. Chats close when a trip ends and stay readable for 7 days.':
      'Masolo ya mibembo na yo emonanaka awa. Ekangamaka soki mobembo esili mpe etangamaka mikolo 7.',
  'ko!ngo Support':
      'Lisalisi ya ko!ngo',
  'Questions, problems, payments: we reply here.':
      'Mituna, mikakatano, kofuta: tozongisaka awa.',
  'Photo':
      'Foto',
  'Trip ended':
      'Mobembo esili',
  'This trip has ended, so the chat is closed.':
      'Mobembo oyo esili, yango wana masolo ekangami.',
  'Ride booked':
      'Mobembo ebongisami',
  "We'll start finding a driver 10 minutes before.":
      'Tokoluka shofele miniti 10 liboso.',
  "{0}. We'll start finding a driver 10 minutes before.":
      '{0}. Tokoluka shofele miniti 10 liboso.',
  'Price offer withdrawn':
      'Ntalo elongolami',
  "We're still looking for a driver at your price.":
      'Tozali kaka koluka shofele na ntalo na yo.',
  'Your driver had to cancel':
      'Shofele na yo atiki',
  "We're finding you another driver.":
      'Tozali koluka shofele mosusu.',
  'No driver found':
      'Shofele azwami te',
  'Trip cancelled':
      'Mobembo etikami',
  'No driver was free just now. Please try again.':
      'Shofele moko azalaki libre te. Meka lisusu.',
  'Your driver cancelled the trip.':
      'Shofele na yo atiki mobembo.',
  'ko!ngo support cancelled this trip.':
      'Lisalisi ya ko!ngo etiki mobembo oyo.',
  'Offer declined':
      'Oboyi ntalo',
  'Pick a later time':
      'Pona ngonga ya nsima',
  'Book at least 20 minutes ahead, or choose Now.':
      'Bongisa miniti 20 liboso, to pona Sikoyo.',
  'When':
      'Ntango nini',
  'Now':
      'Sikoyo',
  "We'll start finding a driver 10 minutes before. You can cancel any time before then.":
      'Tokoluka shofele miniti 10 liboso. Okoki kotika ntango nyonso liboso.',
  'Today {0}':
      'Lelo {0}',
  'Tomorrow {0}':
      'Lobi {0}',
  '{0} km':
      '{0} km',
  'Book for later':
      'Bongisa mpo na nsima',
  'Book a ride ahead — we find your driver 10 minutes before.':
      'Bongisa mobembo liboso — tokozwela yo shofele miniti 10 liboso.',
  'Time unknown':
      'Ngonga eyebani te',
  'Paid from your wallet':
      'Efutami na portefeuille na yo',
  'Pay the courier in cash':
      'Futa motindi na mbongo ya maboko',
  'Pay the driver in cash':
      'Futa shofele na mbongo ya maboko',
  'Parcel delivered!':
      'Liboke ekomi!',
  'Thanks for sending with ko!ngo.':
      'Matondi mpo otindi na ko!ngo.',
  'Distance':
      'Molai',
  'Trip ID':
      'Nimero ya mobembo',
  'Rate {0}':
      'Pesa {0} minzoto',
  'Rate your driver':
      'Pesa shofele na yo minzoto',
  'Another driver has already sent a price. Try again in a moment.':
      'Shofele mosusu atindi ntalo. Meka lisusu sima ya mwa ntango.',
  'Wallet {0} · Waiting payouts {1}':
      'Portefeuille {0} · Mbongo ezali kozela {1}',
  'You owe ko!ngo {0} from cash you collected. It comes off your next earnings, or pay it at a ko!ngo office.':
      'Ozali na nyongo ya {0} epai ya ko!ngo na mbongo ya maboko oyo ozwaki. Ekolongolama na lifuta na yo ya nsima, to futa yango na biro ya ko!ngo.',
  'Cash you kept':
      'Mbongo ya maboko otikalaki na yango',
  'Bank or mobile money':
      'Banki to mobile money',
  'Account or phone number':
      'Nimero ya kont to ya telefone',
  'ko!ngo will send it and let you know.':
      'ko!ngo ekotinda yango mpe ekoyebisa yo.',
  'Available {0} · Waiting payouts {1}':
      'Ezali {0} · Mbongo ezali kozela {1}',
  'Sales credited':
      'Biteki ekotisami',
  'Please sign in again':
      'Kota lisusu',
  'Your session ended. Sign in again to continue.':
      'Session na yo esili. Kota lisusu mpo na kokoba.',
  "Couldn't get your location. Allow location for ko!ngo, or type your street above.":
      'Tokoki te kozwa esika ozali. Pesa ko!ngo nzela ya koyeba esika, to koma balabala na yo awa likolo.',
  'Pick an address from the list, or tap "Use my current location".':
      'Pona adresi na liste, to finá "Salela esika nazali sikoyo".',
  "You don't have permission for this action. Try signing in again.":
      'Ozali na ndingisa te mpo na likambo oyo. Meka kokota lisusu.',
  'code':
      'kode',
  'Upload failed':
      'Kotinda elongi te',
  "Pictures can't be saved for this account yet. Please contact ko!ngo support.":
      'Bafoto ekoki kobombama te mpo na kont oyo. Benga lisalisi ya ko!ngo.',
  "Pictures can't be saved for this store yet. Please contact ko!ngo support.":
      'Bafoto ekoki kobombama te mpo na magazini oyo. Benga lisalisi ya ko!ngo.',
  'The picture could not be saved. Please try again.':
      'Foto ebombami te. Meka lisusu.',
  'No internet connection. Check your network and try again.':
      'Intɛrnɛti ezali te. Tala rezo na yo mpe meka lisusu.',
  'The upload took too long. Check your connection.':
      'Kotinda eumeli mingi. Tala connexion na yo.',
  'Could not load this item swap. Please try again.':
      'Tokoki te kofungola mbongwana oyo. Meka lisusu.',
  "You're offline. Check your data or Wi‑Fi and try again.":
      'Ozali na intɛrnɛti te. Tala data to Wi‑Fi mpe meka lisusu.',
  'No internet. Reconnecting…':
      'Intɛrnɛti ezali te. Tozali kokangisa lisusu…',
  'New order':
      'Komande ya sika',
  'My trips':
      'Mibembo na ngai',
  'Every trip you took, in order':
      'Mibembo nyonso osalaki, na molongo',
  'Booked':
      'Ebombami',
  'No trip in progress':
      'Mobembo moko te ezali kosalema',
  'No rides booked for later':
      'Mibembo ebombami mpo na nsima ezali te',
  'No finished trips yet':
      'Mibembo esili naino te',
  'No cancelled trips':
      'Mibembo ekatami ezali te',
  'Going to pickup':
      'Ozali kokende kozwa',
  'At pickup':
      'Na esika ya kozwa',
  'Returning parcel':
      'Kozongisa liboke',
  'Completed':
      'Esili',
  'Returned':
      'Ezongisami',
  'Expired':
      'Ntango esili',
  'Delivery':
      'Kokumba',
  'Ride':
      'Mobembo',
  'Tap to go back to this trip':
      'Fina mpo na kozonga na mobembo oyo',
  'Today':
      'Lelo',
  'Tomorrow':
      'Lobi',
  'Status':
      'Ezalela',
  'Price':
      'Ntalo',
  'Booked for':
      'Ebombami mpo na',
  'Requested':
      'Esengami',
  'Accepted':
      'Endimami',
  'Finished':
      'Esili',
  'Reason':
      'Ntina',
  'Your rating from the customer':
      'Note na yo epai ya mokiliya',
  'Trip prices {0} · ko!ngo fee {1}%':
      'Ntalo ya mibembo {0} · lifuti ya ko!ngo {1}%',
  'Trip price':
      'Ntalo ya mobembo',
  'Pinned on the map':
      'Elakisami na karte',
  '{0} ({1} ratings)':
      '{0} (ba note {1})',
  'No ratings yet':
      'Ba note naino te',
  'New customer · first trip':
      'Mokiliya ya sika · mobembo ya liboso',
  '1 trip with ko!ngo':
      'Mobembo 1 na ko!ngo',
  '{0} trips with ko!ngo':
      'Mibembo {0} na ko!ngo',
  'New shopping task':
      'Mosala mwa sika ya kosomba',
  '…':
      '…',
  'ko!ngo':
      'ko!ngo',
  'Calling…':
      'Ezali kobenga…',
  'Incoming call':
      'Libenga ezali koya',
  'Connecting…':
      'Ezali kokangana…',
  'Decline':
      'Koboya',
  'Answer':
      'Koyanola',
  'Mute':
      'Kokanga mongongo',
  'End':
      'Kosilisa',
  'Speaker':
      'Haut-parleur',
  'KO!NGO':
      'KO!NGO',
  'x{0} · {1}':
      'x{0} · {1}',
  'Share it with a friend to earn ride credit.':
      'Pesá yango na moninga mpo ozwa crédit ya mobembo.',
  'Share your code and earn ride credit for each friend who takes their first ride.':
      'Pesá code na yo mpe zwá crédit mpo na moninga nyonso oyo akosala mobembo na ye ya liboso.',
  "Credit is added after your friend's first completed ride.":
      'Crédit ekobakisama nsima ya mobembo ya liboso ya moninga na yo esili.',
  'ko!ngo v1.0.0':
      'ko!ngo v1.0.0',
  'Interested? Contact ko!ngo support to join the waitlist.':
      'Olingi? Benga lisungi ya ko!ngo mpo oingela na liste ya kozela.',
  'Your driver has arrived':
      'Mokonzi na yo ya motuka akomi',
  'Transport':
      'Transport',
  'Marketplace':
      'Zando',
  'Book a ride in minutes · Fast & reliable':
      'Bokisa mobembo na miniti moke · Mbangu mpe ya kondima',
  'Send a package · Track delivery':
      'Tinda paket · Landa mobembo na yango',
  'Search shops and categories':
      'Luka maboutique mpe mabota',
  'Groceries':
      'Biloko ya kolia',
  'Fashion':
      'Mode',
  'Electronics':
      'Biloko ya électronique',
  'Home & Living':
      'Ndako mpe bomoi',
  'Beauty':
      'Kitoko',
  'Butchery':
      'Boucherie',
  'Bakery':
      'Boulangerie',
  'General Retail':
      'Mombongo ya bikoki',
  'Other':
      'Mosusu',
  'No categories match your search.':
      'Ezali na libota moko te oyo ekokani na boluki na yo.',
  'Nearby drivers · {0} nearby':
      'Basali ya motuka pene · {0} pene',
  'Your new photo is saved.':
      'Foto na yo ya sika ebombami.',
  'Customers see this photo when you shop for them.':
      'Bakiliya bamoni foto oyo ntango osombeli bango.',
  'Change photo':
      'Bongola foto',
  'All':
      'Nyonso',
  'Restaurant':
      'Restaurant',
  'Pharmacy':
      'Famasi',
  'Marketplace: delivery requests from shops and stores':
      'Zando: mabondeli ya kokamba uta na maboutique',
  'No shop deliveries right now. New ones appear here and ring your phone.':
      'Ezali na kokamba ya boutique te sikoyo. Ya sika ekobima awa mpe ekobetela telefone na yo.',
  'Go online to receive shop deliveries.':
      'Kota na linga mpo ozwa kokamba ya maboutique.',
  'Passed · {0}%':
      'Okoleli · {0}%',
  'Score {0}% · 80% to pass':
      'Ba point {0}% · 80% mpo ozwa',
  'Well done. This module is now complete.':
      'Malamu. Module oyo esili sikoyo.',
  'Review the answers above and try again.':
      'Tala biyano ya likolo mpe meká lisusu.',
  'Answer {0} more':
      'Yanola lisusu {0}',
  'Submit quiz':
      'Tinda quiz',
  'Call customer':
      'Benga mokiliya',
  'Recommended':
      'Elobami',
  "You're certified. Happy driving!":
      'Ozwi certificat. Tambola malamu!',
  'Complete all required modules to go online.':
      'Sala modules nyonso ya ntina mpo okota na linga.',
  '{0} min':
      '{0} min',
  'Certificate of completion':
      'Certificat ya kosilisa',
  'Certificate locked':
      'Certificat ekangami',
  'You have completed all required training.':
      'Osili formation nyonso ya ntina.',
  'Complete all required modules to unlock.':
      'Sala modules nyonso ya ntina mpo ofungola.',
  'My shops':
      'Maboutique na ngai',
  'Add another shop':
      'Bakisa boutique mosusu',
  '{0} · Business type':
      '{0} · Lolenge ya mombongo',
  'For {0}':
      'Mpo na {0}',
  'Restock':
      'Bakisa biloko',
  'Store profile':
      'Profil ya boutique',
  'Quick Actions':
      'Misala ya mbangu',
  '1.0.0 · build 1':
      '1.0.0 · build 1',
  'Aa':
      'Aa',
  'day':
      'mokolo',
  'fixed price':
      'ntalo ya kokangama',
  'hour':
      'ngonga',
  'This week':
      'Poso oyo',
  'Ongoing':
      'Ezali kokende liboso',
  'Just now':
      'Sik\'oyo',
  '{0} min ago':
      'miniti {0} eleki',
  '{0} h ago':
      'ngonga {0} eleki',
  '{0} d ago':
      'mikolo {0} eleki',
  'Live':
      'Ezali',
  'Filled':
      'Etondi',
  'Not approved':
      'Endimami te',
  'Shortlisted':
      'Palamami liboso',
  'Hired':
      'Azwi mosala',
  'Applied':
      'Asengi',
  'Withdrawn':
      'Elongwe',
  'URGENT':
      'MBANGU',
  'Hiring Hub':
      'Esika ya Misala',
  'Find Work':
      'Luka mosala',
  'My Applications':
      'Mabondeli na ngai',
  'My Jobs':
      'Misala na ngai',
  'Post a Job':
      'Pesa mosala',
  'Search jobs, skills...':
      'Luka misala, mayele...',
  'Could not load jobs. Pull down to try again.':
      'Tokoki te kolona misala. Tika na nse mpo na koluka lisusu.',
  'No jobs here yet. Be the first to post one!':
      'Misala ezali naino te awa. Zala moto ya liboso kopesa!',
  'Apply':
      'Senga',
  'You have not applied for any job yet.':
      'Osengi naino mosala moko te.',
  'Jobs you post will show here.':
      'Misala oyo okopesa ekomonana awa.',
  'applicants':
      'basengi',
  'Application sent. You will be notified.':
      'Ebondeli etindami. Bakoyebisa yo.',
  'Verified ID':
      'Kartê ya boyebisi etalelami',
  'Experience':
      'Mayele ya mosala',
  'Own tools':
      'Bisalelo na ye moko',
  'Own transport':
      'Motuka na ye moko',
  'Employer':
      'Mokonzi ya mosala',
  '{0} workers needed':
      'Basali {0} bazali na mposa',
  'Description':
      'Ndimbola',
  'Requirements':
      'Bisengeli',
  'Your application':
      'Ebondeli na yo',
  'Withdraw application':
      'Longola ebondeli',
  'Say a few words about yourself (optional)':
      'Loba maloba moke na ntina na yo (esengeli te)',
  'Close this job?':
      'Kanga mosala oyo?',
  'Workers will no longer see it.':
      'Basali bakomona yango lisusu te.',
  'Close job':
      'Kanga mosala',
  'We are checking your job. It will go live as soon as it is approved.':
      'Tozali kotala mosala na yo. Ekomonana soki endimami.',
  'Applicants':
      'Basengi',
  'No applicants yet.':
      'Basengi ezali naino te.',
  'Shortlist':
      'Palola liboso',
  'Hire':
      'Zwa na mosala',
  'Allow location to use this.':
      'Pesa ndimbola ya esika mpo na kosalela yango.',
  'Could not find your location.':
      'Tokoki te kozwa esika oyo ozali.',
  'Please enter a job title.':
      'Soki olingi, koma kombo ya mosala.',
  'Please enter the pay amount.':
      'Soki olingi, koma motango ya mbongo.',
  'Please enter where the job is.':
      'Soki olingi, koma esika mosala ezali.',
  'This is how workers will see your job':
      'Boye basali bakomona mosala na yo',
  'The photo could not be uploaded. Try again or post without it.':
      'Foto etindami te. Meka lisusu to pesa mosala na yango te.',
  'Job sent for approval':
      'Mosala etindami mpo na kondimama',
  'We will check it and let you know as soon as it is live.':
      'Tokotala yango mpe tokoyebisa yo soki ekomonani.',
  'Post a Job - Hire in minutes':
      'Pesa mosala - Zwa moto na miniti',
  'Fill out the details and connect with trusted workers near you':
      'Etangisa makambo mpe kutana na basali bandimami penepene na yo',
  'Job Title':
      'Kombo ya mosala',
  'e.g. House Cleaner Needed':
      'ndakisa: Moto ya kopetola ndako ezali na mposa',
  'Category':
      'Lolenge',
  'Describe the job, what you need done, and any important details...':
      'Limbola mosala, makambo esengeli kosalama mpe makambo ya ntina...',
  'Pay Type':
      'Lolenge ya kofuta',
  'Per Hour':
      'Na ngonga',
  'Per Day':
      'Na mokolo',
  'Fixed Price':
      'Ntalo ya kokangama',
  'Amount ({0})':
      'Motango ({0})',
  'Location':
      'Esika',
  'Where is the job?':
      'Mosala ezali wapi?',
  'Use my location':
      'Salela esika nazali',
  'Duration':
      'Ntango',
  'Workers needed':
      'Basali oyo balingami',
  'Mark as urgent':
      'Pesa elembo ya mbangu',
  'Upload photo':
      'Tinda foto',
  'optional':
      'esengeli te',
  'Add a photo to help workers understand the job':
      'Bakisa foto mpo na kosalisa basali bayeba mosala',
  'Your first name will be visible to workers. Your job is checked before it goes live.':
      'Kombo na yo ya liboso ekomonana na basali. Mosala na yo etalelami liboso ya kobima.',
  'Preview Job':
      'Tala mosala liboso',
  'Post Job Now':
      'Pesa mosala sik\'oyo',
  'Hiring Hub - Find work, hire talent':
      'Esika ya Misala - Luka mosala, zwa basali ya mayele',
  'Trusted workers and jobs near you':
      'Basali bandimami mpe misala penepene na yo',
  'See All':
      'Tala nyonso',
  'Latest jobs':
      'Misala ya sika',
  'Hiring':
      'Misala',
  'Rides & Delivery':
      'Mobembo mpe kopesa biloko',
  'Cleaning & Home':
      'Kopetola mpe ndako',
  'Construction':
      'Kotonga',
  'Retail & Hospitality':
      'Mombongo mpe kozwa bapaya',
  'Tutoring':
      'Kolakisa',
  'Admin & Office':
      'Ofisi mpe mikanda',
  'This job is closed':
      'Mosala oyo ekangami',
  'This job is no longer taking applications.':
      'Mosala oyo ezali kondima basengi lisusu te.',
  'Not possible':
      'Ekoki te',
  'You cannot apply to your own job.':
      'Okoki te kosenga mosala na yo moko.',
  'Your wallet needs {0} to post this job. Top up and try again.':
      'Libenga na yo ezali na mposa ya {0} mpo na kopesa mosala oyo. Bakisa mbongo mpe meka lisusu.',
  '+{0} · shown first for {1} days':
      '+{0} · ekomonana liboso mikolo {1}',
  'Shown first for {0} days':
      'Ekomonana liboso mikolo {0}',
  'Posting fee':
      'Lifuta ya kopesa mosala',
  'Urgent boost':
      'Kotia liboso na mbangu',
  'Total from your wallet':
      'Motango oyo ekobima na libenga na yo',
  'Your wallet':
      'Libenga na yo',
  'If we do not approve your job, the fee is returned to your wallet.':
      'Soki tondimi mosala na yo te, mbongo ekozonga na libenga na yo.',
  'Top up wallet':
      'Bakisa mbongo na libenga',
  'Fresh picks, fast':
      'Biloko ya sika, noki',
  'Our shoppers pick the best for you':
      'Basombi na biso baponeli yo oyo eleki malamu',
  'Verified pharmacies':
      'Famasi etalelami',
  'Cold-chain ready · pharmacist-verified':
      'Ekoki kobatela moto te · etalelami na mobateli ya nkisi',
  'Shops near you':
      'Bashop penepene na yo',
  'Get around with KO!NGO':
      'Tamba na KO!NGO',
  'Fast':
      'Noki',
  'Safe':
      'Libateli',
  'Reliable':
      'Ya kondimama',
  'Book a Ride':
      'Bokisa mobembo',
  'Shop from a wide range':
      'Somba biloko ebele',
  'Groceries, food, pharmacy, fashion and more, brought to your door':
      'Biloko ya bilei, nkisi, bilamba mpe misusu, ememami na ndako na yo',
  'Promote my store':
      'Bakisa magasini na ngai',
  'Be listed first and get more orders':
      'Zala na liboso na liste mpe zwa mitindo mingi',
  'Sponsored':
      'Elakisami',
  'Sponsored until {0}':
      'Elakisami tii {0}',
  'Your store appears first in the list with a Sponsored label.':
      'Magasini na yo ezali na liboso na liste elongo na elembo ya Elakisami.',
  'Your store is now sponsored':
      'Magasini na yo elakisami sikoyo',
  'Sponsored spots are not available in your country yet.':
      'Bisika bya kolakisa ezali naino te na ekolo na yo.',
  'How many weeks?':
      'Poso boni?',
  'week':
      'poso',
  'weeks':
      'baposo',
  'Price per week':
      'Ntalo na poso',
  'Sponsor my store · {0}':
      'Lakisa magasini na ngai · {0}',
  'Not available':
      'Ezali te',
  'This is not available right now.':
      'Yango ezali te sikoyo.',
  'Earn more':
      'Zwa mingi',
  'tasks':
      'misala',
  'trips':
      'mibembo',
  'task':
      'mosala',
  'trip':
      'mobembo',
  'Done! {0} added to your wallet':
      'Esili! {0} efandisami na libenga na yo',
  '{0} of {1} {2} this week · Bonus {3}':
      '{0} na {1} {2} na poso oyo · Bonisi {3}',
  '{0}: +{1} for every {2} between {3} and {4}':
      '{0}: +{1} mpo na {2} nyonso kati na {3} mpe {4}',
  'Verified by ko!ngo':
      'Ekótisami na ko!ngo',
  'Verified':
      'Ekótisami',
  'Signed in on another phone':
      'Ozali na telefone mosusu',
  'Your account was opened on another phone, so this one was signed out.':
      'Compte na yo efungami na telefone mosusu, yango wana oyo ebimisami.',
  'Recommendations':
      'Toli',
  'Add your vehicle':
      'Bakisa motuka na yo',
  'You owe ko!ngo {0}':
      'Ozali na niongo ya {0} epai ya ko!ngo',
  'Add your profile picture':
      'Bakisa foto na yo ya profil',
  'Upload your papers ({0} missing)':
      'Tinda mikanda na yo ({0} ezali te)',
  'Your papers are being checked':
      'Mikanda na yo ezali kotalelama',
  'Add your bank details to get paid':
      'Bakisa makambo ya banki mpo bakoma kofuta yo',
  'Finish driver academy':
      'Suka kelasi ya bamekanisiens',
  'You are all set. Nothing to fix.':
      'Nyonso ezali malamu. Eloko ya kobongisa ezali te.',
  'Tap to see what to fix':
      'Finá mpo ya komona oyo ya kobongisa',
  'Quick photo check':
      'Botali ya photo mbangu',
  'Take a live selfie now so we know it is you. This takes a few seconds.':
      'Zwa selfie sika po toyeba ete ezali yo. Ezwaka ndambo ya sekonde.',
  'Your face must be clearly visible. Photos from the gallery are not accepted.':
      'Elongi na yo esengeli komonana malamu. Bafoto ya galerie endimami te.',
  'Take selfie':
      'Zwa selfie',
  'Send photo':
      'Tinda foto',
  'Retake':
      'Zwa lisusu',
  'Sending…':
      'Ezali kotinda…',
  'Photo check sent. Thank you.':
      'Botali ya foto etindami. Matondi.',
  'Photo check needed before you go online':
      'Botali ya foto esengeli liboso ya kokota na linye',
  'Take your weekly selfie check':
      'Zwa selfie na yo ya poso',
  'Could not send the photo. Check your internet and try again.':
      'Tokoki kotinda foto te. Tala internet na yo mpe meka lisusu.',
  'Could not open the camera. Allow camera access for ko!ngo in your phone settings.':
      'Tokoki kofungola kamera te. Pesa ko!ngo ndingisa ya kosalela kamera na mipangilio ya telefone.',
  'Your balance is low. Top up so you can keep working without interruption.': 'Mbongo na yo ezali moke. Bakisa mbongo mpo okoba mosala kozanga kokatana.',
  'Your balance is low ({0}). Top up.': 'Mbongo na yo ezali moke ({0}). Bakisa.',
  'Daily goal': 'Mokano ya lelo',
  'Set a daily goal': 'Zwa mokano ya lelo',
  'Goal reached!': 'Mokano esili kokokisama!',
  '{0} of {1}': '{0} na {1}',
  'Amount you want to earn today': 'Mbongo olingi kozwa lelo',
  'Trips': 'Mibembo',
  'Up {0}% on last week': 'Likolo na {0}% koleka poso eleki',
  'Down {0}% on last week': 'Nse na {0}% koleka poso eleki',
  'Same as last week': 'Ndenge moko na poso eleki',
  'No trips yet this week': 'Mibembo ezali naino te na poso oyo',
  'Pop-up over other apps': 'Elongi likolo ya bapolo mosusu',
  'Lets a ride request open ko!ngo on top of other apps. Switch it on for ko!ngo on the page that opens.': 'Epesi nzela ete bosenga ya mobembo efungola ko!ngo likolo ya bapolo mosusu. Pantola yango mpo na ko!ngo na lokasa oyo ekofungwama.',
  'Open settings': 'Fungola botya',
  'Not ringing? See what happened to the last request on this phone.': 'Ezali koganga te? Tala nini esalemaki na bosenga ya suka na telefone oyo.',
  'Check last ring': 'Tala koganga ya suka',
  'No ring has reached this phone yet.': 'Koganga moko ekoki naino te na telefone oyo.',
  'Tip your driver':
      'Pesa mokonzi ya motuka libonza',
  'Send tip':
      'Tinda libonza',
  'Tip sent. Thank you!':
      'Libonza etindami. Matondi!',
  'Custom amount':
      'Motango mosusu',
  'Why this rating? (optional)':
      'Mpo na nini note oyo? (ezali na ntina te)',
  'Share receipt':
      'Kabola recu',
  'Tip amount':
      'Motango ya libonza',
  'My worker profile':
      'Profil na ngai ya mosali',
  'Other requests':
      'Mitiyo mosusu',
  '{0} other requests waiting. Choose one.':
      'Mitiyo {0} mosusu eazali kozela. Pona moko.',
  'Finish your current trip first':
      'Suka libanda ya lelo liboso',
  'You can accept one order at a time.':
      'Okoki kondima commande moko na ntango moko.',
  'Shops':
      'Maduka',
  'Open':
      'Efungwami',
  'Nothing found. Try another word.':
      'Eloko emonani te. Meka liloba mosusu.',
  'Heavy traffic ahead. About {0} extra minutes.':
      'Mobembo ya makalo ezali liboso. Pene na miniti {0} mosusu.',
  'Slow traffic in {0} km.':
      'Makalo ezali kotambola malembe na km {0}.',
  'In {0} metres: {1}':
      'Na mitɛlɛ {0}: {1}',
  '{0} reported ahead.':
      '{0} ewuti koloba liboso.',
  'Accident':
      'Likama',
  'Hazard on the road':
      'Likama na nzela',
  'Traffic jam':
      'Makalo ebakani',
  'Report on the road':
      'Koloba likambo na nzela',
  'Thanks, other drivers will be warned.':
      'Matondi, bakɛngɛli mosusu bakoyebisama.',
  'Navigation started':
      'Nzela ebandi',
  'Heavy traffic: +{0} min':
      'Makalo mingi: +miniti {0}',
  'Voice directions':
      'Mateya na mongongo',
  'Take a photo now':
      'Kamata foto sikoyo',
  'Your worker profile is ready':
      'Profil na yo ya mosali ekoki',
  'Looking for work?':
      'Ozali koluka mosala?',
  'Tap Apply on any job below.':
      'Mikia Sɛnga na mosala nyonso na nse.',
  'Set up your worker profile so employers can see what you do. Then tap Apply on any job.':
      'Kela profil na yo ya mosali po bakopesi misala bamona oyo ozali kosala. Sima mikia Sɛnga na mosala.',
  'Set up my profile':
      'Kela profil na ngai',
  'No jobs here yet. Check back soon.':
      'Mosala ezali naino te awa. Zonga noki.',
  'Need to hire someone? Post a job':
      'Olingi kobuka mosali? Tia mosala',
  'Write what work you do, for example "Painter".':
      'Koma mosala oyo ozali kosala, na ndakisa "Mopakoli".',
  'Profile saved':
      'Profil ebombami',
  'Employers see this when you apply for a job. Save it once.':
      'Bapesi mosala bamoni yango tango ozali kosenga mosala. Bomba yango mbala moko.',
  'What work do you do?':
      'Ozali kosala mosala nini?',
  'e.g. Painter, Driver, Cleaner':
      'na ndakisa Mopakoli, Mokambi, Mosukoli',
  'Your skills':
      'Makoki na yo',
  'e.g. painting, walls, roofs':
      'na ndakisa kopakola, bifelo, makuti',
  'Years of experience':
      'Mbula ya experience',
  'About you':
      'Na ntina na yo',
  'Tell employers why they should choose you':
      'Loba na bapesi mosala mpo na nini baponi yo',
  'Save profile':
      'Bomba profil',
  'Add a short comment (optional)':
      'Tia komentere moke (esengeli te)',
  'Send rating':
      'Tinda nota',
  'Rate the employer':
      'Pesa nota na mopesi mosala',
  'Thank you for your rating':
      'Matondi mpo na nota na yo',
  'years experience':
      'mbula ya experience',
  'Rate this worker':
      'Pesa nota na mosali oyo',
  'You rated {0} stars':
      'Opesaki minzoto {0}',
  'Voice search is not available on this phone.':
      'Boluki na mongongo ezali te na telefone oyo.',
  'Speak to search':
      'Loba mpo na koluka',
  'Split the fare':
      'Kabola talo ya nzela',
  'Each person pays {0}':
      'Moto na moto akofuta {0}',
  'Each person pays the driver their share. Nothing is taken from your wallet for others.':
      'Moto na moto afutaka chofer eteni na ye. Eloko moko ekobima te na portefeuille na yo mpo na basusu.',
  'Our ko!ngo ride costs {0} in total. With {1} of us, each pays {2}.':
      'Mobembo na biso ya ko!ngo etalo {0} nyonso. Tozali {1}, moto na moto akofuta {2}.',
  'Send to friends':
      'Tinda na baninga',
  'National ID / Passport':
      'Kati ya ndenge / Paspo',
  'Clear photo of the whole document':
      'Foto ya polele ya kati mobimba',
  'Selfie holding your ID':
      'Selfie na kati na yo na loboko',
  'Your face and the ID must both be readable':
      'Elongi na yo mpe kati esengeli komonana malamu',
  'Driving licence':
      'Permi ya kobeta motuka',
  'Valid, for your type of vehicle':
      'Ezali na valeur, mpo na lolenge ya motuka na yo',
  'Vehicle registration & insurance':
      'Karte grise mpe assurance',
  'Registration paper and valid insurance':
      'Karte grise mpe assurance ezali na valeur',
  'Police clearance':
      'Extrait ya casier judiciaire',
  'Criminal record extract, not older than 6 months':
      'Extrait ya casier judiciaire, eleki te sanza 6',
  'Technical inspection':
      'Contrôle technique',
  'Roadworthy certificate':
      'Satifika ya motuka ezali malamu',
  'If your vehicle needs one':
      'Soki motuka na yo esengi yango',
  'Professional driving permit (PrDP)':
      'Permi ya mosala (PrDP)',
  'For paid passenger transport':
      'Mpo na komema bato na tara',
  'Business registration (RCCM)':
      'Rejistre ya mombongo (RCCM)',
  'Business registration (CIPC)':
      'Rejistre ya mombongo (CIPC)',
  'Registration paper of your business':
      'Kati ya rejistre ya mombongo na yo',
  'Photo of your shop front':
      'Foto ya liboso ya ndako na yo ya mombongo',
  'Show the sign and the entrance':
      'Telá elembo mpe ekuke',
  'Tax number (NIU)':
      'Nimero ya impo (NIU)',
  'Tax number (SARS)':
      'Nimero ya impo (SARS)',
  'Adds trust, not required':
      'Ebakisi motema makasi, esengeli te',
  'Health certificate':
      'Satifika ya bokolongono',
  'Food sellers: certificate from your municipality':
      'Bato ya kotɛka bilei: satifika ya mairie na yo',
  'Not accepted':
      'Endimami te',
  'Waiting for review':
      'Ezali kozela botali',
  'Not uploaded':
      'Etindami naino te',
  'Optional':
      'Esengeli te',
  'Upload':
      'Tinda',
  'Verify me':
      'Tala ngai',
  'You are verified. Customers see your badge.':
      'Otalami. Bakiti bamoni elembo na yo.',
  '{0} of {1} required papers accepted. When all are accepted you get the Verified badge.':
      '{0} na {1} ya bikateli esengeli endimami. Soki nyonso endimami, ozwi elembo ya Otalami.',
  'Your papers are private. Only ko!ngo admin can see them.':
      'Bikateli na yo ezali na kati. Admin ya ko!ngo kaka akoki komona yango.',
  'Verify my business':
      'Tala mombongo na ngai',
  'Not allowed':
      'Ekoki te',
  'Trip not found':
      'Mobembo emonani te',
  'This is not your trip':
      'Oyo ezali mobembo na yo te',
  'User not found':
      'Mosaleli emonani te',
  'Job not found':
      'Mosala emonani te',
  'Enter the customer\'s PIN to start':
      'Tia PIN ya kiliyá mpo na kobanda',
  'The trip has started. Only the driver can end it now.':
      'Mobembo ebandi. Chofer kaka akoki kosilisa yango.',
  'This trip has already ended':
      'Mobembo oyo esili',
  'This job is finished and cannot be changed':
      'Mosala oyo esili mpe ekoki kobongwana te',
  'You can book up to 30 days ahead':
      'Okoki kobuka tii mikolo 30 liboso',
  'Pick a time at least 15 minutes from now':
      'Pona ngonga na nsima ya minutes 15 soki moke',
  'This request is no longer available':
      'Ebongisi oyo ezali lisusu te',
  'Sponsored spots are not available right now':
      'Bisika ya sponsor ezali te sikoyo',
  'You can rate after your trip':
      'Okoki kopesa note nsima ya mobembo na yo',
  'You can rate after the trip':
      'Okoki kopesa note nsima ya mobembo',
  'You can only rate after a hire on this job':
      'Okoki kopesa note kaka nsima ya kozwa moto na mosala oyo',
  'This ride is booked for later':
      'Mobembo oyo etiami mpo na sima',
  'This is not your store':
      'Oyo ezali ndako ya mombongo na yo te',
  'Only the driver can release this trip':
      'Chofer kaka akoki kotika mobembo oyo',
  'Only the driver can do this':
      'Chofer kaka akoki kosala yango',
  'The price can\'t be changed':
      'Talo ekoki kobongwana te',
  'Shop deliveries have a fixed fee':
      'Kopesa na ndako ya mombongo ezali na talo moko',
  'This job is no longer open':
      'Mosala oyo efungwami lisusu te',
  'That price offer is no longer available':
      'Talo wana ezali lisusu te',
  'Cancel the order instead':
      'Kanisa commande na esika na yango',
  'Start the trip first':
      'Banda mobembo liboso',
  'Start the return first':
      'Banda kozonga liboso',
  'Pick up the parcel first':
      'Kamata colis liboso',
  'Enter an amount':
      'Tia motango ya mbongo',
  'Enter a price':
      'Tia talo',
  'Choose 1 to 5 stars':
      'Pona minzoto 1 tii 5',
  'Pick 1 to 5 stars':
      'Pona minzoto 1 tii 5',
  'Finish or cancel your current trip first':
      'Silisa to kanisa mobembo na yo ya sikoyo liboso',
  'You can withdraw up to {0}':
      'Okoki kobimisa tii {0}',
  'Choose between 1 and {0} weeks':
      'Pona kati na poso 1 mpe {0}',
  'Sign-up problem on our side':
      'Libunga ya kokoma nkombo na biso',
  'Our server could not finish this. Please try again in a moment, or contact ko!ngo support.':
      'Serveur na biso ekokaki te kosilisa. Meká lisusu moke to benga lisungi ya ko!ngo.',
  'No answer. The other person must have the trip open in the app.':
      'Moto mosusu azali koyanola te. Asengeli kozala na mobembo ofungwama na application.',
  'Couldn\'t connect the call. Check that both phones have internet and try again.':
      'Ekoki kosangana te. Tala ete mitéle nyonso mibale ezali na internet mpe meka lisusu.',
  'Couldn\'t start the microphone. Allow microphone access for ko!ngo in your phone settings.':
      'Ekoki kobanda micro te. Pesa ko!ngo ndingisa ya micro na paramètres ya telefone.',
};
