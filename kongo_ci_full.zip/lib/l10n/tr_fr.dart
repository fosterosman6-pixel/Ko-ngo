// lib/l10n/tr_fr.dart
//
// French for text written directly in the screens, looked up by its
// English wording through tr('…'). {0}, {1}… are filled in by tr().
// Add a line here when you add a new tr('…') in a screen.

const Map<String, String> trFr = {
  '% OFF':
      '% DE RÉDUCTION',
  '1.0.0 · build 1':
      '1.0.0 · version 1',
  '6-digit code':
      'Code à 6 chiffres',
  'A minimum fare of R {0} is required.':
      'Un tarif minimum de {0} est requis.',
  'A profile photo is required to continue. You can skip for now, but you won\'t be able to book or accept rides.':
      'Une photo de profil est nécessaire pour continuer. Vous pouvez passer cette étape, mais vous ne pourrez ni réserver ni accepter de courses.',
  'Aa':
      'Aa',
  'Access denied':
      'Accès refusé',
  'Account':
      'Compte',
  'Account blocked':
      'Compte bloqué',
  'Account holder':
      'Titulaire du compte',
  'Account holder name':
      'Nom du titulaire du compte',
  'Account number':
      'Numéro de compte',
  'Account type':
      'Type de compte',
  'Account verification':
      'Vérification du compte',
  'Active sessions':
      'Sessions actives',
  'Add Vehicle':
      'Ajouter un véhicule',
  'Add an extra layer of security':
      'Ajoutez une sécurité supplémentaire',
  'Add at least one contact so SOS can reach someone.':
      'Ajoutez au moins un contact pour que le SOS puisse joindre quelqu\'un.',
  'Add contact':
      'Ajouter un contact',
  'Add contacts so SOS can reach someone':
      'Ajoutez des contacts pour que le SOS puisse joindre quelqu\'un',
  'Add emergency contacts who will be notified when you trigger SOS.':
      'Ajoutez des contacts d\'urgence qui seront prévenus quand vous déclenchez le SOS.',
  'Add your vehicle or bike to start accepting rides and deliveries.':
      'Ajoutez votre voiture ou moto pour commencer à accepter des courses et livraisons.',
  'Add, edit, or remove':
      'Ajouter, modifier ou retirer',
  'Allow drivers to see your pickup location during trips.':
      'Autoriser les chauffeurs à voir votre point de départ pendant les courses.',
  'Already added':
      'Déjà ajouté',
  'Already exists':
      'Existe déjà',
  'Already have an account? ':
      'Déjà un compte ? ',
  'Already rated':
      'Déjà noté',
  'Already registered':
      'Déjà inscrit',
  'Ambulance':
      'Ambulance',
  'Amount (R)':
      'Montant',
  'An admin hasn\'t reviewed your account yet. Try again later.':
      'Un administrateur n\'a pas encore vérifié votre compte. Réessayez plus tard.',
  'Analytics':
      'Statistiques',
  'Answer every question':
      'Répondez à toutes les questions',
  'Apply Code':
      'Appliquer le code',
  'Approve swap':
      'Accepter le remplacement',
  'Are you safe?':
      'Êtes-vous en sécurité ?',
  'Are you sure you want to delete "{0}"? This cannot be undone.':
      'Voulez-vous vraiment supprimer « {0} » ? Cette action est irréversible.',
  'At least 8 characters':
      'Au moins 8 caractères',
  'Authentication failed':
      'Échec de l\'authentification',
  'Available balance':
      'Solde disponible',
  'Available to withdraw':
      'Disponible au retrait',
  'Available: {0}':
      'Disponible : {0}',
  'Await admin approval.':
      'En attente de l\'approbation de l\'administrateur.',
  'Awaiting admin approval':
      'En attente d\'approbation',
  'Back':
      'Retour',
  'Back to home':
      'Retour à l\'accueil',
  'Back to start':
      'Retour au début',
  'Bank':
      'Banque',
  'Bank details':
      'Coordonnées bancaires',
  'Bank details saved':
      'Coordonnées bancaires enregistrées',
  'Bank name':
      'Nom de la banque',
  'Bank reference (optional)':
      'Référence bancaire (facultatif)',
  'Become a driver or courier':
      'Devenez chauffeur ou livreur',
  'Blue Toyota Corolla — see you soon':
      'Toyota Corolla bleue — à tout de suite',
  'Book a ride, order food,\ngroceries or send parcels.':
      'Réservez une course, commandez des repas,\ndes courses ou envoyez des colis.',
  'Branch code (optional)':
      'Code agence (facultatif)',
  'Brief summary of your issue':
      'Résumé de votre problème',
  'By continuing, you agree to our ':
      'En continuant, vous acceptez nos ',
  'By continuing, you agree to our Terms of Service and Privacy Policy.':
      'En continuant, vous acceptez nos Conditions d\'utilisation et notre Politique de confidentialité.',
  'CANCEL — I\'M SAFE':
      'ANNULER — JE SUIS EN SÉCURITÉ',
  'CLOSED':
      'FERMÉ',
  'Calendar':
      'Calendrier',
  'Call':
      'Appeler',
  'Call support':
      'Appeler l\'assistance',
  'Call us at {0}':
      'Appelez-nous au {0}',
  'Call {0}':
      'Appeler {0}',
  'Call {0} manually.':
      'Appelez {0} vous-même.',
  'Call {0}?':
      'Appeler {0} ?',
  'Camera':
      'Appareil photo',
  'Can\'t call':
      'Appel impossible',
  'Cancel':
      'Annuler',
  'Cancel ride':
      'Annuler la course',
  'Cancel scheduled ride?':
      'Annuler la course programmée ?',
  'Cancel this order?':
      'Annuler cette commande ?',
  'Card (coming soon)':
      'Carte (bientôt)',
  'Cash deposit':
      'Dépôt en espèces',
  'Change email':
      'Changer d\'e-mail',
  'Change password':
      'Changer le mot de passe',
  'Change phone number':
      'Changer de numéro',
  'Chat':
      'Discussion',
  'Chat messages':
      'Messages',
  'Check back soon':
      'Revenez bientôt',
  'Check back soon — we\'ll notify you when there\'s an offer.':
      'Revenez bientôt — nous vous préviendrons dès qu\'une offre arrive.',
  'Check your connection and try again.':
      'Vérifiez votre connexion et réessayez.',
  'Check your inbox':
      'Consultez votre boîte de réception',
  'Choose at least Ride or Delivery.':
      'Choisissez au moins Course ou Livraison.',
  'Choose what notifications you receive.':
      'Choisissez les notifications que vous recevez.',
  'Choose your role':
      'Choisissez votre rôle',
  'Close':
      'Fermer',
  'Code copied':
      'Code copié',
  'Code not found.':
      'Code introuvable.',
  'Code: ':
      'Code : ',
  'Colour':
      'Couleur',
  'Coming soon':
      'Bientôt disponible',
  'Communication':
      'Communication',
  'Complete all three steps before submitting.':
      'Terminez les trois étapes avant d\'envoyer.',
  'Complete your profile':
      'Complétez votre profil',
  'Confirm':
      'Confirmer',
  'Confirm Password':
      'Confirmer le mot de passe',
  'Confirm deletion':
      'Confirmer la suppression',
  'Confirm new password':
      'Confirmer le nouveau mot de passe',
  'Connecting you to a better journey':
      'Pour des trajets plus simples',
  'Contact added':
      'Contact ajouté',
  'Contact details are unavailable right now.':
      'Les coordonnées ne sont pas disponibles pour le moment.',
  'Contact name':
      'Nom du contact',
  'Contact removed':
      'Contact retiré',
  'Contact support':
      'Contacter l\'assistance',
  'Contact support for more information.':
      'Contactez l\'assistance pour en savoir plus.',
  'Continue':
      'Continuer',
  'Control how new ride requests interrupt you.':
      'Choisissez comment les nouvelles demandes vous interrompent.',
  'Control what alerts you receive while you\'re online.':
      'Choisissez les alertes reçues quand vous êtes en ligne.',
  'Copy':
      'Copier',
  'Corporate Accounts':
      'Comptes entreprise',
  'Corporate Travel':
      'Déplacements professionnels',
  'Could not load orders':
      'Impossible de charger les commandes',
  'Could not load preview':
      'Impossible de charger l\'aperçu',
  'Could not load restaurants':
      'Impossible de charger les restaurants',
  'Could not load the menu':
      'Impossible de charger le menu',
  'Could not load {0} stores':
      'Impossible de charger les magasins {0}',
  'Couldn\'t complete request':
      'Impossible de terminer la demande',
  'Couldn\'t dial':
      'Appel impossible',
  'Couldn\'t open dialer':
      'Impossible d\'ouvrir le téléphone',
  'Couldn\'t open email':
      'Impossible d\'ouvrir l\'e-mail',
  'Couldn\'t save':
      'Enregistrement impossible',
  'Couldn\'t send request':
      'Envoi de la demande impossible',
  'Couldn\'t submit payout':
      'Impossible d\'envoyer le versement',
  'Couldn\'t validate this code. Try again.':
      'Impossible de valider ce code. Réessayez.',
  'Current password':
      'Mot de passe actuel',
  'Current session:':
      'Session actuelle :',
  'Customer':
      'Client',
  'DELETE':
      'SUPPRIMER',
  'DONE':
      'TERMINÉ',
  'Day':
      'Jour',
  'Delete':
      'Supprimer',
  'Delete account':
      'Supprimer le compte',
  'Delete account?':
      'Supprimer le compte ?',
  'Delete forever':
      'Supprimer définitivement',
  'Delete vehicle?':
      'Supprimer le véhicule ?',
  'Deliveries':
      'Livraisons',
  'Describe what happened in detail':
      'Décrivez ce qui s\'est passé en détail',
  'Details':
      'Détails',
  'Disc':
      'Rem.',
  'Discounts, referral bonuses, and seasonal deals.':
      'Réductions, bonus de parrainage et offres saisonnières.',
  'Documents (upload pictures)':
      'Documents (envoyer des photos)',
  'Done':
      'Terminé',
  'Driver':
      'Chauffeur',
  'Driver Academy':
      'Académie des chauffeurs',
  'Driver Terms':
      'Conditions chauffeur',
  'Driver Terms of Service':
      'Conditions d\'utilisation chauffeur',
  'Driver assigned, arriving, and trip status.':
      'Chauffeur attribué, arrivée et statut de la course.',
  'Driver: {0}':
      'Chauffeur : {0}',
  'Drivers and couriers must complete KYC documentation.':
      'Les chauffeurs et livreurs doivent fournir leurs documents d\'identité.',
  'Drop-off':
      'Arrivée',
  'Dropoff location':
      'Lieu d\'arrivée',
  'EFT / Bank transfer':
      'Virement bancaire',
  'Earn R50 for each referral':
      'Gagnez un bonus pour chaque parrainage',
  'Earn money by driving\nor delivering.':
      'Gagnez de l\'argent en conduisant\nou en livrant.',
  'Earn with ko!ngo':
      'Gagnez avec ko!ngo',
  'Earnings':
      'Gains',
  'Earnings & payouts':
      'Gains et versements',
  'Edit':
      'Modifier',
  'Edit name':
      'Modifier le nom',
  'Email receipts':
      'Reçus par e-mail',
  'Email support':
      'Écrire à l\'assistance',
  'Email us at {0}':
      'Écrivez-nous à {0}',
  'Emergency SOS':
      'SOS d\'urgence',
  'Emergency contacts':
      'Contacts d\'urgence',
  'Emergency services and {0} have been alerted.':
      'Les secours et {0} ont été alertés.',
  'Enter a code.':
      'Saisissez un code.',
  'Enter a valid amount':
      'Saisissez un montant valide',
  'Enter an amount greater than zero.':
      'Saisissez un montant supérieur à zéro.',
  'Enter an amount within your available balance.':
      'Saisissez un montant inférieur ou égal à votre solde disponible.',
  'Enter both a name and phone number.':
      'Saisissez un nom et un numéro de téléphone.',
  'Even with sound off, the full-screen ring still appears so you won\'t miss a ride.':
      'Même sans son, la sonnerie plein écran s\'affiche pour ne manquer aucune course.',
  'Expense your rides':
      'Faites rembourser vos courses',
  'Expires: ':
      'Expire : ',
  'Expires: {0}':
      'Expire : {0}',
  'Family Profile':
      'Profil famille',
  'Family Profile will be available soon.':
      'Le profil famille sera bientôt disponible.',
  'Favorite Places':
      'Lieux favoris',
  'Favorite removed':
      'Favori retiré',
  'Fill bank details':
      'Remplir les coordonnées bancaires',
  'Fill in all your bank information.':
      'Renseignez toutes vos informations bancaires.',
  'First name':
      'Prénom',
  'First name required':
      'Prénom requis',
  'Food delivery':
      'Livraison de repas',
  'Gallery':
      'Galerie',
  'Get promotions based on your trips and favourite routes.':
      'Recevez des promotions selon vos courses et trajets favoris.',
  'Get smart ride suggestions':
      'Suggestions de courses intelligentes',
  'Get smart ride suggestions based on your calendar events.':
      'Recevez des suggestions de courses selon les événements de votre agenda.',
  'Great, I\'ll be at the gate':
      'Parfait, je serai au portail',
  'Have a prescription?':
      'Vous avez une ordonnance ?',
  'Help us improve ko!ngo with anonymous usage data.':
      'Aidez-nous à améliorer ko!ngo avec des données d\'utilisation anonymes.',
  'Hi! I\'m 5 minutes away':
      'Bonjour ! J\'arrive dans 5 minutes',
  'High':
      'Élevée',
  'How would you like to use KO!NGO?':
      'Comment voulez-vous utiliser KO!NGO ?',
  'I\'m safe':
      'Je suis en sécurité',
  'I\'m safe — end alert':
      'Je suis en sécurité — arrêter l\'alerte',
  'ID, licence, logbook':
      'Pièce d\'identité, permis, carte grise',
  'If the store has already started preparing, you may be charged a fee.':
      'Si le magasin a déjà commencé la préparation, des frais peuvent s\'appliquer.',
  'In an emergency, tap the button below.':
      'En cas d\'urgence, touchez le bouton ci-dessous.',
  'Interested? Email support@efuride.com to join the waitlist.':
      'Intéressé ? Écrivez à l\'assistance pour rejoindre la liste d\'attente.',
  'Invalid amount':
      'Montant invalide',
  'Invalid email':
      'E-mail invalide',
  'Invalid number':
      'Numéro invalide',
  'Invalid phone':
      'Téléphone invalide',
  'Invalid phone number':
      'Numéro de téléphone invalide',
  'Item unavailable':
      'Article indisponible',
  'KO!NGO':
      'KO!NGO',
  'KYC documents':
      'Documents d\'identité',
  'Keep':
      'Garder',
  'Keep active':
      'Garder actif',
  'Keep alert active':
      'Garder l\'alerte active',
  'Keep it':
      'Le garder',
  'Keep old cart':
      'Garder l\'ancien panier',
  'Keep signed in':
      'Rester connecté',
  'Kenyatta Avenue, Nairobi':
      'Avenue de la Paix, Brazzaville',
  'LIVE':
      'EN DIRECT',
  'Language':
      'Langue',
  'Language updated':
      'Langue mise à jour',
  'Legal':
      'Mentions légales',
  'Licenses':
      'Licences',
  'Limit reached':
      'Limite atteinte',
  'Loading cards':
      'Chargement des cartes',
  'Loading list':
      'Chargement de la liste',
  'Location is off':
      'Localisation désactivée',
  'Location permission needed':
      'Autorisation de localisation requise',
  'Log in':
      'Se connecter',
  'Log out':
      'Se déconnecter',
  'Log out?':
      'Se déconnecter ?',
  'Low':
      'Basse',
  'Loyalty':
      'Fidélité',
  'Loyalty points':
      'Points de fidélité',
  'MTN MoMo · +242 06 123 4567':
      'MTN MoMo · +242 06 123 4567',
  'Make (e.g. Toyota)':
      'Marque (ex. Toyota)',
  'Make and plate number are required.':
      'La marque et la plaque sont obligatoires.',
  'Make sure both passwords are identical.':
      'Vérifiez que les deux mots de passe sont identiques.',
  'Manage and pay for your family\'s rides':
      'Gérez et payez les courses de votre famille',
  'Manage business travel for your company — team members, consolidated billing, and reporting.':
      'Gérez les déplacements professionnels de votre entreprise — équipe, facturation groupée et rapports.',
  'Manage contacts':
      'Gérer les contacts',
  'Manage devices signed in to your account':
      'Gérez les appareils connectés à votre compte',
  'Manage emergency contacts':
      'Gérer les contacts d\'urgence',
  'Manage permission settings':
      'Gérer les autorisations',
  'Manage store':
      'Gérer la boutique',
  'Manage your data and permissions':
      'Gérez vos données et autorisations',
  'Mark yourself as safe?':
      'Indiquer que vous êtes en sécurité ?',
  'Marked safe':
      'Indiqué en sécurité',
  'Medium':
      'Moyenne',
  'Merchant':
      'Marchand',
  'Merchant · Orders':
      'Marchand · Commandes',
  'Merchant · Payouts':
      'Marchand · Versements',
  'Message':
      'Message',
  'Message copied':
      'Message copié',
  'Messages from customers during an active trip.':
      'Messages des clients pendant une course.',
  'Messages from drivers during an active trip.':
      'Messages des chauffeurs pendant une course.',
  'Min {0} XAF':
      'Min {0} XAF',
  'Missing bank details':
      'Coordonnées bancaires manquantes',
  'Missing details':
      'Informations manquantes',
  'Missing documents':
      'Documents manquants',
  'Missing information':
      'Informations manquantes',
  'Missing vehicle photo':
      'Photo du véhicule manquante',
  'Model (e.g. Corolla)':
      'Modèle (ex. Corolla)',
  'Month':
      'Mois',
  'My Rides':
      'Mes courses',
  'My Vehicles':
      'Mes véhicules',
  'My vehicles':
      'Mes véhicules',
  'NOTIFIED':
      'AVERTI',
  'Name too short':
      'Nom trop court',
  'Name updated':
      'Nom mis à jour',
  'Navigation app':
      'Application de navigation',
  'Never miss a trip':
      'Ne manquez aucune course',
  'New email':
      'Nouvel e-mail',
  'New messages':
      'Nouveaux messages',
  'New password':
      'Nouveau mot de passe',
  'New ride requests':
      'Nouvelles demandes de course',
  'New to ko!ngo':
      'Nouveau sur ko!ngo',
  'Next settlement: Friday, in 3 days':
      'Prochain règlement : vendredi, dans 3 jours',
  'No active conversation.':
      'Aucune conversation active.',
  'No active ride':
      'Aucune course active',
  'No balance to withdraw.':
      'Aucun solde à retirer.',
  'No completed trips yet':
      'Aucune course terminée',
  'No emergency contacts yet':
      'Aucun contact d\'urgence',
  'No favorite places yet':
      'Aucun lieu favori',
  'No internet connection':
      'Pas de connexion Internet',
  'No items on the menu yet':
      'Aucun article au menu',
  'No items yet':
      'Aucun article',
  'No matches':
      'Aucun résultat',
  'No messages yet':
      'Aucun message',
  'No payout requests':
      'Aucune demande de versement',
  'No phone number':
      'Aucun numéro de téléphone',
  'No promotions right now':
      'Aucune promotion pour le moment',
  'No quiz for this module. It will be marked complete when you finish reading.':
      'Pas de quiz pour ce module. Il sera validé à la fin de la lecture.',
  'No restaurants nearby yet':
      'Aucun restaurant à proximité pour le moment',
  'No scheduled rides':
      'Aucune course programmée',
  'No top-up requests':
      'Aucune demande de recharge',
  'No transactions yet':
      'Aucune transaction',
  'No trip to rate':
      'Aucune course à noter',
  'No trusted contacts yet':
      'Aucun contact de confiance',
  'No vehicles added':
      'Aucun véhicule ajouté',
  'No {0} orders':
      'Aucune commande {0}',
  'No {0} stores nearby':
      'Aucun magasin {0} à proximité',
  'Not signed in':
      'Non connecté',
  'Nothing to rate':
      'Rien à noter',
  'Nothing to withdraw':
      'Rien à retirer',
  'Notifications':
      'Notifications',
  'Offers & codes':
      'Offres et codes',
  'Ok!':
      'D\'accord !',
  'Onboarding progress':
      'Progression de l\'inscription',
  'Once you complete rides, they\'ll show up here with your net earnings.':
      'Vos courses terminées apparaîtront ici avec vos gains nets.',
  'One last step':
      'Une dernière étape',
  'Only drivers can request payouts':
      'Seuls les chauffeurs peuvent demander un versement',
  'Open Settings':
      'Ouvrir les paramètres',
  'Order cancelled':
      'Commande annulée',
  'Order not found':
      'Commande introuvable',
  'Order timeline':
      'Suivi de la commande',
  'Orders':
      'Commandes',
  'Other ways to reach us':
      'Autres moyens de nous joindre',
  'Our team typically responds within a few hours.':
      'Notre équipe répond généralement en quelques heures.',
  'Our team will respond within a few hours.':
      'Notre équipe vous répondra dans quelques heures.',
  'Owner doc':
      'Doc. propriétaire',
  'Page not found':
      'Page introuvable',
  'Passenger':
      'Passager',
  'Passkeys and verification':
      'Clés d\'accès et vérification',
  'Password changed':
      'Mot de passe modifié',
  'Password must be at least 8 characters.':
      'Le mot de passe doit contenir au moins 8 caractères.',
  'Password too short':
      'Mot de passe trop court',
  'Password, sessions, 2FA':
      'Mot de passe, sessions, double authentification',
  'Passwords don\'t match':
      'Les mots de passe ne correspondent pas',
  'Payment':
      'Paiement',
  'Payment method':
      'Moyen de paiement',
  'Payout account':
      'Compte de versement',
  'Payout confirmations':
      'Confirmations de versement',
  'Payout failed — verify bank details and retry.':
      'Échec du versement — vérifiez vos coordonnées bancaires et réessayez.',
  'Payout requested':
      'Versement demandé',
  'Payouts':
      'Versements',
  'Payouts, tips, and fare credits will appear here.':
      'Les versements, pourboires et crédits apparaîtront ici.',
  'Peak-hour bonuses, referral rewards, and ko!ngo news.':
      'Bonus aux heures de pointe, parrainage et actualités ko!ngo.',
  'Pending admin review.':
      'En attente de vérification par l\'administrateur.',
  'Permanently remove your account':
      'Supprimer définitivement votre compte',
  'Personalised offers':
      'Offres personnalisées',
  'Phone number':
      'Numéro de téléphone',
  'Phone updated':
      'Téléphone mis à jour',
  'Photo from your shopper':
      'Photo de votre acheteur',
  'Photo required':
      'Photo obligatoire',
  'Photo saved':
      'Photo enregistrée',
  'Photo selected':
      'Photo sélectionnée',
  'Photo updated':
      'Photo mise à jour',
  'Pick a future time':
      'Choisissez une heure future',
  'Pick a rating':
      'Choisissez une note',
  'Pick a service':
      'Choisissez un service',
  'Pick a time':
      'Choisissez une heure',
  'Pickup':
      'Départ',
  'Pickup location':
      'Lieu de départ',
  'Plate Number (e.g. CA123-45)':
      'Plaque (ex. BZ-1234-AB)',
  'Plate: {0}':
      'Plaque : {0}',
  'Play an audible alert when a new ride comes in.':
      'Émettre une alerte sonore à chaque nouvelle course.',
  'Please check the number and try again.':
      'Vérifiez le numéro et réessayez.',
  'Please check your details and try again.':
      'Vérifiez vos informations et réessayez.',
  'Please check your network and try again.':
      'Vérifiez votre réseau et réessayez.',
  'Please choose an option for each.':
      'Choisissez une option pour chacun.',
  'Please enter a valid email address.':
      'Saisissez une adresse e-mail valide.',
  'Please enter a valid phone number.':
      'Saisissez un numéro de téléphone valide.',
  'Please enter at least 2 characters.':
      'Saisissez au moins 2 caractères.',
  'Please enter both pickup and dropoff.':
      'Saisissez le départ et l\'arrivée.',
  'Please enter your first name.':
      'Saisissez votre prénom.',
  'Please fill in both the subject and message.':
      'Renseignez l\'objet et le message.',
  'Please select when you want the ride.':
      'Choisissez quand vous voulez la course.',
  'Please sign in again to continue.':
      'Reconnectez-vous pour continuer.',
  'Please sign in again.':
      'Reconnectez-vous.',
  'Please sign in to use chat.':
      'Connectez-vous pour utiliser la discussion.',
  'Please sign in.':
      'Connectez-vous.',
  'Please try again in a moment.':
      'Réessayez dans un instant.',
  'Please turn on GPS so we can find you.':
      'Activez le GPS pour que nous puissions vous localiser.',
  'Please upload a photo of the vehicle.':
      'Ajoutez une photo du véhicule.',
  'Please upload all required documents first.':
      'Envoyez d\'abord tous les documents requis.',
  'Police':
      'Police',
  'Prescription on file':
      'Ordonnance enregistrée',
  'Price impact':
      'Effet sur le prix',
  'Priority':
      'Priorité',
  'Privacy':
      'Confidentialité',
  'Privacy Policy':
      'Politique de confidentialité',
  'Profile':
      'Profil',
  'Profile not found':
      'Profil introuvable',
  'Promo applied! You save {0}.':
      'Code promo appliqué ! Vous économisez {0}.',
  'Promo code  applied!':
      'Code promo appliqué !',
  'Promo codes, offers, and savings':
      'Codes promo, offres et économies',
  'Promotions':
      'Promotions',
  'Promotions & Offers':
      'Promotions et offres',
  'Promotions and bonuses':
      'Promotions et bonus',
  'Promotions and offers':
      'Promotions et offres',
  'QUICK QUIZ':
      'QUIZ RAPIDE',
  'R50 credited after your friend\'s first completed ride.':
      'Bonus crédité après la première course terminée de votre ami.',
  'Rate trip':
      'Noter la course',
  'Rating':
      'Note',
  'Ref: {0}':
      'Réf. : {0}',
  'Refer & Earn':
      'Parrainez et gagnez',
  'Refer a Friend':
      'Parrainer un ami',
  'Refer a friend':
      'Parrainer un ami',
  'Refresh':
      'Actualiser',
  'Rejected — please edit and resubmit.':
      'Refusé — modifiez et renvoyez.',
  'Remove':
      'Retirer',
  'Remove contact?':
      'Retirer le contact ?',
  'Remove favorite?':
      'Retirer le favori ?',
  'Replace':
      'Remplacer',
  'Request Payout':
      'Demander un versement',
  'Request a payout and we\'ll show its status here.':
      'Demandez un versement et son statut s\'affichera ici.',
  'Request payout':
      'Demander un versement',
  'Request timed out':
      'Délai dépassé',
  'Required':
      'Obligatoire',
  'Resend code':
      'Renvoyer le code',
  'Resend code in {0}s':
      'Renvoyer le code dans {0} s',
  'Retry':
      'Réessayer',
  'Retry payout':
      'Relancer le versement',
  'Review my documents':
      'Vérifier mes documents',
  'Ride  •  Deliver  •  Move':
      'Course  •  Livraison  •  Mobilité',
  'Ride not found':
      'Course introuvable',
  'Ride removed':
      'Course supprimée',
  'Ride requests, chat, bonuses':
      'Demandes de course, discussion, bonus',
  'Ride scheduled':
      'Course programmée',
  'Ride updates':
      'Mises à jour des courses',
  'Rides':
      'Courses',
  'Rides you pay for and top-ups you make will appear here.':
      'Vos courses payées et vos recharges apparaîtront ici.',
  'Ring + push when a customer books nearby. Turn off and you won\'t see new rides.':
      'Sonnerie et notification quand un client réserve à proximité. Désactivé, vous ne verrez pas les nouvelles courses.',
  'Ring sound':
      'Sonnerie',
  'SHOPPER SUGGESTS':
      'L\'ACHETEUR PROPOSE',
  'SOS ACTIVE':
      'SOS ACTIF',
  'STEP {0}':
      'ÉTAPE {0}',
  'Safety':
      'Sécurité',
  'Safety center':
      'Centre de sécurité',
  'Save':
      'Enregistrer',
  'Save & continue to vehicle':
      'Enregistrer et passer au véhicule',
  'Save draft':
      'Enregistrer le brouillon',
  'Save frequently visited places for faster booking.':
      'Enregistrez vos lieux fréquents pour réserver plus vite.',
  'Save on every ride':
      'Économisez sur chaque course',
  'Saved bank details will be used next time.':
      'Les coordonnées bancaires enregistrées seront utilisées la prochaine fois.',
  'Saved places':
      'Lieux enregistrés',
  'Say hi to {0} to coordinate pickup.':
      'Dites bonjour à {0} pour organiser la prise en charge.',
  'Schedule':
      'Programmer',
  'Schedule a Ride':
      'Programmer une course',
  'Schedule a ride':
      'Programmer une course',
  'Schedule a ride for later':
      'Programmer une course pour plus tard',
  'Scheduled Rides':
      'Courses programmées',
  'Seats / capacity':
      'Places / capacité',
  'See your ride statistics':
      'Voir les statistiques de vos courses',
  'Send an EFT to the business account, then submit this form with your reference. Admin will confirm.':
      'Faites un virement sur le compte de l\'entreprise, puis envoyez ce formulaire avec votre référence. L\'administrateur confirmera.',
  'Send code':
      'Envoyer le code',
  'Send link':
      'Envoyer le lien',
  'Send trip summaries to your registered email.':
      'Recevez le résumé de vos courses par e-mail.',
  'Services this vehicle can serve':
      'Services que ce véhicule peut assurer',
  'Session expired':
      'Session expirée',
  'Settings':
      'Paramètres',
  'Settlement history':
      'Historique des règlements',
  'Setup is available from your Supabase dashboard. Coming to the app soon.':
      'La configuration se fait depuis le tableau de bord. Bientôt dans l\'application.',
  'Share Referral Link':
      'Partager le lien de parrainage',
  'Share it with a friend to earn R50.':
      'Partagez-le avec un ami pour gagner un bonus.',
  'Share link: efuride://track/{0}':
      'Lien de partage : efuride://track/{0}',
  'Share live location':
      'Partager ma position en direct',
  'Share more feedback (optional)':
      'Donnez plus de détails (facultatif)',
  'Share your code and earn R50 for each friend who takes their first ride.':
      'Partagez votre code et gagnez un bonus pour chaque ami qui fait sa première course.',
  'Shop & pick':
      'Achats et préparation',
  'Shopper':
      'Acheteur',
  'Sign Out':
      'Se déconnecter',
  'Sign in and security':
      'Connexion et sécurité',
  'Sign out':
      'Se déconnecter',
  'Sign out?':
      'Se déconnecter ?',
  'Skip':
      'Passer',
  'Skip for now':
      'Plus tard',
  'Skip item':
      'Ignorer l\'article',
  'Some required details are missing. Please try again.':
      'Des informations obligatoires manquent. Réessayez.',
  'Something went wrong':
      'Un problème est survenu',
  'Something went wrong on our side. Please try again.':
      'Un problème est survenu de notre côté. Réessayez.',
  'Sound & alerts':
      'Son et alertes',
  'Standard SMS rates may apply. We\'ll never share your number.':
      'Des frais de SMS peuvent s\'appliquer. Nous ne partageons jamais votre numéro.',
  'Start a new cart?':
      'Commencer un nouveau panier ?',
  'Start new':
      'Nouveau panier',
  'Stay':
      'Rester',
  'Stay where you are. Help is on the way.':
      'Restez où vous êtes. Les secours arrivent.',
  'Step 1 · Upload your documents':
      'Étape 1 · Envoyez vos documents',
  'Still pending':
      'Toujours en attente',
  'Subject':
      'Objet',
  'Submit a support ticket':
      'Envoyer une demande d\'assistance',
  'Submit for admin approval':
      'Envoyer pour approbation',
  'Submit for approval':
      'Envoyer pour approbation',
  'Submit payout request':
      'Envoyer la demande de versement',
  'Submit rating':
      'Envoyer la note',
  'Substitution':
      'Remplacement',
  'Substitution request':
      'Proposition de remplacement',
  'Suggest rides ahead of your meetings and appointments.':
      'Suggérer des courses avant vos réunions et rendez-vous.',
  'Support':
      'Assistance',
  'Surname':
      'Nom',
  'Sync calendar':
      'Synchroniser l\'agenda',
  'TAP FOR SOS':
      'TOUCHEZ POUR SOS',
  'TEAM MEMBER SIGN-IN':
      'CONNEXION ÉQUIPE',
  'TRIGGER SOS':
      'DÉCLENCHER LE SOS',
  'TRIGGERING SOS':
      'DÉCLENCHEMENT DU SOS',
  'Take a clear selfie so drivers and passengers can recognise you during trips.':
      'Prenez un selfie net pour que chauffeurs et passagers vous reconnaissent pendant les courses.',
  'Take a selfie to continue.':
      'Prenez un selfie pour continuer.',
  'Take your photo':
      'Prenez votre photo',
  'Tap a star to rate your customer.':
      'Touchez une étoile pour noter votre client.',
  'Tap a star to rate your driver.':
      'Touchez une étoile pour noter votre chauffeur.',
  'Tap a star to rate your experience.':
      'Touchez une étoile pour noter votre expérience.',
  'Tap once — we handle the rest':
      'Touchez une fois — nous nous occupons du reste',
  'Tell us more about your experience':
      'Parlez-nous de votre expérience',
  'Terms':
      'Conditions',
  'Terms of Service':
      'Conditions d\'utilisation',
  'Thanks for rating!':
      'Merci pour votre note !',
  'Thanks for riding with ko!ngo.':
      'Merci d\'avoir voyagé avec ko!ngo.',
  'Thanks — your rating was recorded.':
      'Merci — votre note a été enregistrée.',
  'That number is already in your list.':
      'Ce numéro est déjà dans votre liste.',
  'The place has been removed from your list.':
      'Le lieu a été retiré de votre liste.',
  'The scheduled time must be in the future.':
      'L\'heure programmée doit être dans le futur.',
  'The server took too long to respond. Try again.':
      'Le serveur a mis trop de temps à répondre. Réessayez.',
  'The store has been notified.':
      'Le magasin a été prévenu.',
  'There\'s no trip to chat about yet.':
      'Il n\'y a pas encore de course pour discuter.',
  'They will no longer be notified.':
      'Ce contact ne sera plus prévenu.',
  'They\'ll be notified when you trigger SOS.':
      'Ce contact sera prévenu quand vous déclenchez le SOS.',
  'This action cannot be undone.':
      'Cette action est irréversible.',
  'This device':
      'Cet appareil',
  'This email is already in use. Try signing in.':
      'Cet e-mail est déjà utilisé. Essayez de vous connecter.',
  'This permanently deletes your account, trip history, and saved data.':
      'Cela supprime définitivement votre compte, votre historique et vos données.',
  'This place will be removed from your list.':
      'Ce lieu sera retiré de votre liste.',
  'This promo has expired.':
      'Cette promotion a expiré.',
  'This promo has reached its limit.':
      'Cette promotion a atteint sa limite.',
  'This promo hasn\'t started yet.':
      'Cette promotion n\'a pas encore commencé.',
  'This promo is not active right now.':
      'Cette promotion n\'est pas active pour le moment.',
  'This record already exists. Try a different value.':
      'Cet enregistrement existe déjà. Essayez une autre valeur.',
  'This scheduled ride will be removed and will not be booked.':
      'Cette course programmée sera supprimée et ne sera pas réservée.',
  'This trip may have been removed.':
      'Cette course a peut-être été supprimée.',
  'This will alert your emergency contacts and our support team with your location. Use only in a real emergency.':
      'Vos contacts d\'urgence et notre équipe recevront votre position. À utiliser uniquement en cas d\'urgence réelle.',
  'This will end the SOS alert. Your contacts will be told you\'re safe.':
      'L\'alerte SOS sera arrêtée. Vos contacts seront informés que vous êtes en sécurité.',
  'This will open your phone\'s dialer with the number pre-filled.':
      'Le téléphone s\'ouvrira avec le numéro déjà saisi.',
  'Ticket submitted':
      'Demande envoyée',
  'Tier benefits':
      'Avantages par niveau',
  'Top up':
      'Recharger',
  'Top up now':
      'Recharger maintenant',
  'Top up your wallet':
      'Recharger votre portefeuille',
  'Top-up request sent':
      'Demande de recharge envoyée',
  'Top-ups':
      'Recharges',
  'Total':
      'Total',
  'Tracking services':
      'Services de suivi',
  'Transactions':
      'Transactions',
  'Trigger SOS':
      'Déclencher le SOS',
  'Trigger SOS?':
      'Déclencher le SOS ?',
  'Trip complete':
      'Course terminée',
  'Trip completed':
      'Course terminée',
  'Trip completed!':
      'Course terminée !',
  'Try again':
      'Réessayer',
  'Two-factor authentication':
      'Double authentification',
  'Type DELETE in capitals to confirm.':
      'Tapez SUPPRIMER en majuscules pour confirmer.',
  'Type a message...':
      'Écrivez un message…',
  'Type a message…':
      'Écrivez un message…',
  'Typing':
      'Écrit',
  'Unlock exclusive benefits':
      'Débloquez des avantages exclusifs',
  'Update the email on your account':
      'Changer l\'e-mail de votre compte',
  'Update your account password':
      'Changer le mot de passe de votre compte',
  'Uploaded':
      'Envoyé',
  'Usage analytics':
      'Statistiques d\'utilisation',
  'Use your new password next time you log in.':
      'Utilisez votre nouveau mot de passe à la prochaine connexion.',
  'VERIFIED':
      'VÉRIFIÉ',
  'Vehicle':
      'Véhicule',
  'Vehicle class':
      'Catégorie de véhicule',
  'Vehicle deleted':
      'Véhicule supprimé',
  'Vehicle photo':
      'Photo du véhicule',
  'Verify & continue':
      'Vérifier et continuer',
  'View uploaded file':
      'Voir le fichier envoyé',
  'View your tier and rewards':
      'Voir votre niveau et vos récompenses',
  'Wallet':
      'Portefeuille',
  'Wallet balance':
      'Solde du portefeuille',
  'We can\'t dial that phone number.':
      'Impossible d\'appeler ce numéro.',
  'We couldn\'t find a completed ride.':
      'Aucune course terminée trouvée.',
  'We couldn\'t reach our servers. Please try again.':
      'Impossible de joindre nos serveurs. Réessayez.',
  'We never sell your personal data.':
      'Nous ne vendons jamais vos données personnelles.',
  'We sent a confirmation link to your new email address.':
      'Nous avons envoyé un lien de confirmation à votre nouvelle adresse.',
  'We use your phone for trip updates and driver contact.':
      'Votre numéro sert aux mises à jour des courses et au contact avec le chauffeur.',
  'We\'ll dispatch a driver near the time.':
      'Nous enverrons un chauffeur peu avant l\'heure.',
  'We\'ll process it within 2 business days.':
      'Nous le traiterons sous 2 jours ouvrés.',
  'Week':
      'Semaine',
  'Weekly settlement':
      'Règlement hebdomadaire',
  'Weekly settlement · PawaPay':
      'Règlement hebdomadaire · PawaPay',
  'Welcome aboard. Taking you to your dashboard.':
      'Bienvenue à bord. Direction votre tableau de bord.',
  'Welcome to ko!ngo Academy':
      'Bienvenue à l\'Académie ko!ngo',
  'What you\'ll be able to do':
      'Ce que vous pourrez faire',
  'When a payout is processed or rejected.':
      'Quand un versement est effectué ou refusé.',
  'When you submit a top-up, you\'ll be able to track its approval here.':
      'Après une demande de recharge, vous pourrez suivre son approbation ici.',
  'Which app should open when you tap "Start trip"?':
      'Quelle application ouvrir quand vous touchez « Démarrer la course » ?',
  'Work Profile':
      'Profil professionnel',
  'Wrong email or password':
      'E-mail ou mot de passe incorrect',
  'YOU ORDERED':
      'VOUS AVEZ COMMANDÉ',
  'Year':
      'Année',
  'You':
      'Vous',
  'You can save up to {0} contacts.':
      'Vous pouvez enregistrer jusqu\'à {0} contacts.',
  'You can sign back in anytime to check your approval status.':
      'Vous pouvez vous reconnecter à tout moment pour voir l\'état de votre approbation.',
  'You don\'t have a balance to pay out yet.':
      'Vous n\'avez pas encore de solde à verser.',
  'You have arrived!':
      'Vous êtes arrivé !',
  'You will stop receiving new orders until you sign in again.':
      'Vous ne recevrez plus de commandes jusqu\'à votre prochaine connexion.',
  'You\'ll need to sign in again to book rides.':
      'Vous devrez vous reconnecter pour réserver des courses.',
  'You\'ll stop receiving ride requests until you sign in again.':
      'Vous ne recevrez plus de demandes de course jusqu\'à votre prochaine connexion.',
  'You\'re all set.':
      'Tout est prêt.',
  'You\'re approved!':
      'Vous êtes approuvé !',
  'You\'re not a participant in this trip.':
      'Vous ne participez pas à cette course.',
  'You\'ve already rated this trip. Thanks for the feedback!':
      'Vous avez déjà noté cette course. Merci pour votre avis !',
  'You\'ve already used this promo.':
      'Vous avez déjà utilisé cette promotion.',
  'Your contacts have been notified.':
      'Vos contacts ont été prévenus.',
  'Your data export':
      'Export de vos données',
  'Your device may not have a phone app. Please dial manually.':
      'Votre appareil n\'a peut-être pas d\'application téléphone. Composez le numéro vous-même.',
  'Your documents have been submitted. An administrator will review them shortly — usually within a few hours.':
      'Vos documents ont été envoyés. Un administrateur les vérifiera bientôt — généralement en quelques heures.',
  'Your earnings have been added to your wallet.':
      'Vos gains ont été ajoutés à votre portefeuille.',
  'Your emergency contacts':
      'Vos contacts d\'urgence',
  'Your emergency contacts and our support team have been alerted with your location.':
      'Vos contacts d\'urgence et notre équipe ont reçu votre position.',
  'Your emergency contacts and our support team will be notified with your location.':
      'Vos contacts d\'urgence et notre équipe recevront votre position.',
  'Your feedback helps improve ko!ngo.':
      'Votre avis aide à améliorer ko!ngo.',
  'Your feedback helps keep ko!ngo safe.':
      'Votre avis contribue à la sécurité de ko!ngo.',
  'Your name has been saved.':
      'Votre nom a été enregistré.',
  'Your new profile photo is live.':
      'Votre nouvelle photo de profil est en ligne.',
  'Your number stays hidden. Only the call is connected.':
      'Votre numéro reste masqué. Seul l\'appel est connecté.',
  'Your personal data':
      'Vos données personnelles',
  'Your phone number has been saved.':
      'Votre numéro de téléphone a été enregistré.',
  'Your photo is visible to drivers and passengers during trips.':
      'Votre photo est visible par les chauffeurs et passagers pendant les courses.',
  'Your scheduled ride has been cancelled.':
      'Votre course programmée a été annulée.',
  'Your trips will appear here':
      'Vos courses apparaîtront ici',
  'Your vehicle has been removed.':
      'Votre véhicule a été supprimé.',
  'Your vehicle will be reviewed by an admin before it becomes active.':
      'Votre véhicule sera vérifié par un administrateur avant d\'être activé.',
  'e.g. 11 2nd Street, Firgrove':
      'ex. 11 rue Mbochi, Moungali',
  'e.g. 45 Main Rd, CBD':
      'ex. 45 avenue de la Paix, Centre-ville',
  'ko!ngo':
      'ko!ngo',
  'ko!ngo Plus':
      'ko!ngo Plus',
  'ko!ngo Plus will be available soon.':
      'ko!ngo Plus sera bientôt disponible.',
  'ko!ngo needs your location to find nearby drivers.':
      'ko!ngo a besoin de votre position pour trouver des chauffeurs proches.',
  'ko!ngo v1.0.0':
      'ko!ngo v1.0.0',
  'typing…':
      'écrit…',
  'x{0} · {1}':
      'x{0} · {1}',
  '{0} XAF':
      '{0} XAF',
  '{0} XAF pending':
      '{0} XAF en attente',
  '{0} active':
      '{0} actifs',
  '{0} has a suggestion':
      '{0} a une proposition',
  '{0} hasn\'t added a phone number to their profile.':
      '{0} n\'a pas ajouté de numéro de téléphone à son profil.',
  '{0} is ready to paste.':
      '{0} est prêt à être collé.',
  '{0} is typing…':
      '{0} écrit…',
  '{0} km':
      '{0} km',
  '{0} min':
      '{0} min',
  '{0} new':
      '{0} nouveaux',
  '{0} of {1} complete':
      '{0} sur {1} terminés',
  '{0} of {1} modules complete':
      '{0} modules sur {1} terminés',
  '{0} points':
      '{0} points',
  '{0} points to {1}':
      '{0} points avant {1}',
  '💬 New message from {0}':
      '💬 Nouveau message de {0}',
  '🚨 SOS activated':
      '🚨 SOS activé',
  'Are you sure you want to remove "{0}"?':
      'Voulez-vous vraiment retirer « {0} » ?',
  'The price has changed':
      'Le prix a changé',
  'Please go back and check the price again.':
      'Revenez en arrière et vérifiez à nouveau le prix.',
  'The lowest price for this trip is {0}. Please go back and check the price again.':
      'Le prix le plus bas pour ce trajet est {0}. Revenez en arrière et vérifiez à nouveau le prix.',
  'Not enough money in your wallet':
      'Solde insuffisant dans votre portefeuille',
  'Top up your wallet or choose another way to pay.':
      'Rechargez votre portefeuille ou choisissez un autre moyen de paiement.',
  'The picture could not be uploaded':
      'L\'image n\'a pas pu être envoyée',
  '{0}\n\nYou can save the product now and add the picture later.':
      '{0}\n\nVous pouvez enregistrer le produit maintenant et ajouter l\'image plus tard.',
  'Save without picture':
      'Enregistrer sans image',
  'OK':
      'OK',
  'Choose on map':
      'Choisir sur la carte',
  'Tap the map where you want to be picked up':
      'Touchez la carte à l\'endroit où vous voulez être pris en charge',
  'Tap the map where you are going':
      'Touchez la carte à l\'endroit où vous allez',
  'Pinned location':
      'Point sur la carte',
  'Clear':
      'Effacer',
  'Use my current location':
      'Utiliser ma position actuelle',
  'Street, suburb or landmark':
      'Rue, quartier ou repère',
  'No places found. Try a street name or landmark.':
      'Aucun lieu trouvé. Essayez un nom de rue ou un repère.',
  'Current location':
      'Position actuelle',
  'Closed':
      'Fermé',
  'Nearby pharmacies':
      'Pharmacies à proximité',
  'Stores near you':
      'Magasins près de vous',
  'Country':
      'Pays',
  'Choose your country':
      'Choisissez votre pays',
  'Add a place':
      'Ajouter un lieu',
  'Name this place':
      'Nommer ce lieu',
  'Home':
      'Maison',
  'Work':
      'Travail',
  'e.g. Mom\'s place':
      'ex. Chez maman',
  'Place':
      'Lieu',
  'Drivers, shoppers and store owners use a separate ko!ngo account, with a different email address. Your customer account stays as it is.':
      'Les chauffeurs, acheteurs et commerçants utilisent un compte ko!ngo séparé, avec une autre adresse e-mail. Votre compte client reste inchangé.',
  'To create it, you will be signed out of this account. You can sign back in any time.':
      'Pour le créer, vous serez déconnecté de ce compte. Vous pourrez vous reconnecter à tout moment.',
  'Sign out and create partner account':
      'Se déconnecter et créer un compte partenaire',
  'Stay signed in':
      'Rester connecté',
  'Invite friends and earn ride credit':
      'Invitez des amis et gagnez du crédit de course',
  'No offers right now':
      'Aucune offre pour le moment',
  'New promo codes will show here.':
      'Les nouveaux codes promo apparaîtront ici.',
  '{0}% off':
      '{0} % de réduction',
  '{0} off':
      '{0} de réduction',
  'Valid until {0}':
      'Valable jusqu\'au {0}',
  'Minimum {0}':
      'Minimum {0}',
  'Code {0} copied. Paste it when you book or check out.':
      'Code {0} copié. Collez-le lors de la réservation ou du paiement.',
  'My orders':
      'Mes commandes',
  'Active':
      'En cours',
  'Past':
      'Passées',
  'No active orders':
      'Aucune commande en cours',
  'No past orders yet':
      'Aucune commande passée',
  'Order food, groceries or medicine from the Home tab.':
      'Commandez repas, courses ou médicaments depuis l\'onglet Accueil.',
  '{0} items':
      '{0} articles',
  'Order placed':
      'Commande passée',
  'Being prepared':
      'En préparation',
  'Ready for pickup':
      'Prête à récupérer',
  'On the way':
      'En route',
  'Delivered':
      'Livrée',
  'Returned to office':
      'Retournée au bureau',
  'Cancelled':
      'Annulée',
  'Refunded':
      'Remboursée',
  'Order payment':
      'Paiement de commande',
  'Ride payment':
      'Paiement de course',
  'Refund':
      'Remboursement',
  'Bonus':
      'Bonus',
  'Top-up':
      'Recharge',
  'Amount':
      'Montant',
  'How did you pay?':
      'Comment avez-vous payé ?',
  'Bank transfer':
      'Virement bancaire',
  'Payment reference (optional)':
      'Référence du paiement (facultatif)',
  'Send top-up request':
      'Envoyer la demande de recharge',
  'Pay ko!ngo by bank transfer or cash, then send this request. Your balance goes up when ko!ngo confirms the payment.':
      'Payez ko!ngo par virement ou en espèces, puis envoyez cette demande. Votre solde augmente quand ko!ngo confirme le paiement.',
  'Your balance goes up when ko!ngo confirms it.':
      'Votre solde augmente quand ko!ngo le confirme.',
  'Waiting for approval':
      'En attente de validation',
  'Activity':
      'Activité',
  '{0} waiting for approval':
      '{0} en attente de validation',
  'Add money to pay for rides and orders without cash.':
      'Ajoutez de l\'argent pour payer courses et commandes sans espèces.',
  'Payments, top-ups and refunds will show here.':
      'Paiements, recharges et remboursements apparaîtront ici.',
  'Wallet & payouts':
      'Portefeuille et paiements',
  'Payouts on the way':
      'Paiements en cours',
  'Trip earnings':
      'Gains par course',
  'Past payouts':
      'Paiements passés',
  'Wallet {0} · Unpaid trips {1}':
      'Portefeuille {0} · Courses non payées {1}',
  'ko!ngo fee {0}% · {1} completed trips':
      'Frais ko!ngo {0} % · {1} courses terminées',
  'Completed trips and what you earned on each will show here.':
      'Vos courses terminées et vos gains apparaîtront ici.',
  'Payout':
      'Paiement reçu',
  'Tip':
      'Pourboire',
  'Credit':
      'Crédit',
  'Deduction':
      'Déduction',
  'Rewards':
      'Récompenses',
  'App':
      'Application',
  'More':
      'Plus',
  'Privacy and security':
      'Confidentialité et sécurité',
  'Edit profile':
      'Modifier le profil',
  '{0} ratings':
      '{0} avis',
  'Your profile':
      'Votre profil',
  'Signing out…':
      'Déconnexion…',
  'Wallet & payment':
      'Portefeuille et paiement',
  'Balance, top up and activity':
      'Solde, recharge et activité',
  'Home, work and favourites':
      'Maison, travail et favoris',
  'Emergency contacts and SOS':
      'Contacts d’urgence et SOS',
  'Get help with a trip or order':
      'Aide pour une course ou une commande',
  'Notifications and email receipts':
      'Notifications et reçus par e-mail',
  'Password, email and sessions':
      'Mot de passe, e-mail et sessions',
  'Terms and privacy policy':
      'Conditions et politique de confidentialité',
  'Pay ko!ngo with one of the methods below, then send this request. Your balance goes up when ko!ngo confirms the payment.':
      'Payez ko!ngo avec l’un des moyens ci-dessous, puis envoyez cette demande. Votre solde augmente quand ko!ngo confirme le paiement.',
  'Pay to: {0}':
      'Payer à : {0}',
  'Contact ko!ngo support for the {0} payment details.':
      'Contactez le support ko!ngo pour les détails de paiement {0}.',
  'Transaction code (from the SMS)':
      'Code de transaction (dans le SMS)',
  'Bank transfer (EFT)':
      'Virement bancaire (EFT)',
  'Customers can order now':
      'Les clients peuvent commander',
  'Closed: customers cannot order':
      'Fermé : les clients ne peuvent pas commander',
  'New and active orders':
      'Commandes nouvelles et en cours',
  'How will you pay?':
      'Comment allez-vous payer ?',
  'ko!ngo wallet':
      'Portefeuille ko!ngo',
  'Balance {0}':
      'Solde {0}',
  'Balance {0}: not enough for this':
      'Solde {0} : insuffisant',
  'Cash':
      'Espèces',
  'Card':
      'Carte',
  'Visa or Mastercard':
      'Visa ou Mastercard',
  'Not enough in your wallet':
      'Solde insuffisant',
  'Top up your wallet or choose cash.':
      'Rechargez votre portefeuille ou choisissez les espèces.',
  'Not enough in your wallet. Top up or choose cash.':
      'Solde insuffisant. Rechargez ou choisissez les espèces.',
  'Pay the courier':
      'Payez le coursier',
  'Pay the driver at the end of the trip':
      'Payez le chauffeur à la fin de la course',
  'Pay the courier at pickup':
      'Payez le coursier au ramassage',
  'Pay the driver when it arrives':
      'Payez le livreur à l\u2019arrivée',
  'Paid from wallet':
      'Payé par portefeuille',
  'Paid by card':
      'Payé par carte',
  'Cash: collect from customer':
      'Espèces : à encaisser',
  'Collect {0} cash from the customer':
      'Encaissez {0} en espèces auprès du client',
  'Paid from the customer\'s wallet. No cash to collect.':
      'Payé par le portefeuille du client. Rien à encaisser.',
  'Paid in the app. No cash to collect.':
      'Payé dans l\u2019application. Rien à encaisser.',
  'Card not available':
      'Carte indisponible',
  'Card payments are not available here yet. Please choose cash or wallet.':
      'Le paiement par carte n\u2019est pas encore disponible ici. Choisissez espèces ou portefeuille.',
  'New message to support':
      'Nouveau message au support',
  'What is it about?':
      'De quoi s\u2019agit-il ?',
  'e.g. Payment, a trip, an order':
      'ex. Paiement, une course, une commande',
  'Tell us what happened':
      'Expliquez ce qui s\u2019est passé',
  'Send':
      'Envoyer',
  'Solved':
      'Résolu',
  'Answered':
      'Répondu',
  'Waiting for support':
      'En attente du support',
  'Message support':
      'Écrire au support',
  'Chat with the ko!ngo team. We reply here and you get a notification.':
      'Discutez avec l\u2019équipe ko!ngo. Nous répondons ici et vous recevez une notification.',
  'Your conversations':
      'Vos conversations',
  'No conversations yet. Tap "Message support" to start one.':
      'Aucune conversation. Touchez « Écrire au support » pour commencer.',
  'WhatsApp':
      'WhatsApp',
  'ko!ngo support':
      'Support ko!ngo',
  'Our team will reply here. You will get a notification.':
      'Notre équipe répondra ici. Vous recevrez une notification.',
  'Write a message':
      'Écrire un message',
  'This is a {0} account':
      'C\u2019est un compte {0}',
  'These details belong to a {0} account, so they can\'t be used on the {1} login. Please sign in from the {0} login.':
      'Ces identifiants appartiennent à un compte {0} : ils ne peuvent pas être utilisés sur la connexion {1}. Connectez-vous depuis la connexion {0}.',
  'Go to {0} login':
      'Aller à la connexion {0}',
  'Where to?':
      'Où allez-vous ?',
  'Later':
      'Plus tard',
  'Add home':
      'Ajouter domicile',
  'You are here · {0} cars nearby':
      'Vous êtes ici · {0} voitures à proximité',
  'You are here':
      'Vous êtes ici',
  'Tap to copy the code':
      'Touchez pour copier le code',
  'Offers and promo codes':
      'Offres et codes promo',
  'See what is on today':
      'Voir les offres du jour',
  'Take a photo':
      'Prendre une photo',
  'Choose from gallery':
      'Choisir dans la galerie',
  'Send a photo':
      'Envoyer une photo',
  'Sedan (up to 4 seats)':
      'Berline (jusqu\u2019à 4 places)',
  'XL (6 seats, SUV / minivan)':
      'XL (6 places, SUV / monospace)',
  'Van / minibus (up to 14 seats)':
      'Van / minibus (jusqu\u2019à 14 places)',
  'Large van (cargo)':
      'Grand fourgon (marchandises)',
  'Truck':
      'Camion',
  'Motorbike / Scooter':
      'Moto / scooter',
  'Money in your wallet':
      'Argent dans votre portefeuille',
  'You still have {0} in your ko!ngo wallet. If you delete your account now, this money is lost. Contact support first if you want it back.':
      'Il vous reste {0} dans votre portefeuille ko!ngo. Si vous supprimez votre compte maintenant, cet argent est perdu. Contactez d\u2019abord le support pour le récupérer.',
  'Keep my account':
      'Garder mon compte',
  'Delete anyway':
      'Supprimer quand même',
  'Not yet':
      'Pas encore',
  'Finish or cancel your current trip first.':
      'Terminez ou annulez d\u2019abord votre course en cours.',
  'Wait until your order is delivered or cancel it first.':
      'Attendez la livraison de votre commande ou annulez-la d\u2019abord.',
  'Your driver':
      'Votre chauffeur',
  'Chat opens once a driver has your order.':
      'La discussion s\u2019ouvre quand un chauffeur a votre commande.',
  'Orders waiting for a driver':
      'Commandes en attente d\u2019un chauffeur',
  'Tap an order to see it and accept it.':
      'Touchez une commande pour la voir et l\u2019accepter.',
  'No orders waiting right now':
      'Aucune commande en attente',
  'away':
      'de vous',
  'waiting {0} min':
      'en attente depuis {0} min',
  '{0} orders waiting':
      '{0} commandes en attente',
  'NO ANSWER':
      'PAS DE RÉPONSE',
  'The customer didn\'t answer. Pick the original item or leave it out.':
      'Le client n\u2019a pas répondu. Prenez l\u2019article d\u2019origine ou laissez-le.',
  'OK, continue shopping':
      'OK, continuer les courses',
  'Your trip has started. Only the driver can end it now.':
      'Votre course a commencé. Seul le chauffeur peut l\u2019arrêter maintenant.',
  'Trip already started':
      'Course déjà commencée',
  'This trip was cancelled.':
      'Cette course a été annulée.',
  'See all':
      'Tout voir',
  'View':
      'Voir',
  'Messages':
      'Messages',
  'Yesterday':
      'Hier',
  'Trips and deliveries':
      'Courses et livraisons',
  'Chats from your trips show here. Chats close when a trip ends and stay readable for 7 days.':
      'Les discussions de vos courses apparaissent ici. Elles se ferment à la fin de la course et restent lisibles 7 jours.',
  'ko!ngo Support':
      'Support ko!ngo',
  'Questions, problems, payments: we reply here.':
      'Questions, problèmes, paiements : nous répondons ici.',
  'Photo':
      'Photo',
  'Trip ended':
      'Course terminée',
  'This trip has ended, so the chat is closed.':
      'Cette course est terminée, la discussion est fermée.',
  'Ride booked':
      'Course réservée',
  "We'll start finding a driver 10 minutes before.":
      'Nous chercherons un chauffeur 10 minutes avant.',
  "{0}. We'll start finding a driver 10 minutes before.":
      '{0}. Nous chercherons un chauffeur 10 minutes avant.',
  'Price offer withdrawn':
      'Offre de prix retirée',
  "We're still looking for a driver at your price.":
      'Nous cherchons toujours un chauffeur à votre prix.',
  'Your driver had to cancel':
      'Votre chauffeur a dû annuler',
  "We're finding you another driver.":
      'Nous vous cherchons un autre chauffeur.',
  'No driver found':
      'Aucun chauffeur trouvé',
  'Trip cancelled':
      'Course annulée',
  'No driver was free just now. Please try again.':
      "Aucun chauffeur n'était libre. Veuillez réessayer.",
  'Your driver cancelled the trip.':
      'Votre chauffeur a annulé la course.',
  'ko!ngo support cancelled this trip.':
      'Le support ko!ngo a annulé cette course.',
  'Offer declined':
      'Offre refusée',
  'Pick a later time':
      'Choisissez une heure plus tard',
  'Book at least 20 minutes ahead, or choose Now.':
      "Réservez au moins 20 minutes à l'avance, ou choisissez Maintenant.",
  'When':
      'Quand',
  'Now':
      'Maintenant',
  "We'll start finding a driver 10 minutes before. You can cancel any time before then.":
      'Nous chercherons un chauffeur 10 minutes avant. Vous pouvez annuler à tout moment avant.',
  'Today {0}':
      "Aujourd'hui {0}",
  'Tomorrow {0}':
      'Demain {0}',
  'Book for later':
      'Réserver pour plus tard',
  'Book a ride ahead — we find your driver 10 minutes before.':
      "Réservez à l'avance — nous trouvons votre chauffeur 10 minutes avant.",
  'Time unknown':
      'Heure inconnue',
  'Paid from your wallet':
      'Payé depuis votre portefeuille',
  'Pay the courier in cash':
      'Payez le coursier en espèces',
  'Pay the driver in cash':
      'Payez le chauffeur en espèces',
  'Parcel delivered!':
      'Colis livré !',
  'Thanks for sending with ko!ngo.':
      "Merci d'avoir envoyé avec ko!ngo.",
  'Distance':
      'Distance',
  'Trip ID':
      'N° de course',
  'Rate {0}':
      'Notez {0}',
  'Rate your driver':
      'Notez votre chauffeur',
  'Another driver has already sent a price. Try again in a moment.':
      'Un autre chauffeur a déjà proposé un prix. Réessayez dans un instant.',
  'Wallet {0} · Waiting payouts {1}':
      'Portefeuille {0} · Retraits en attente {1}',
  'You owe ko!ngo {0} from cash you collected. It comes off your next earnings, or pay it at a ko!ngo office.':
      "Vous devez {0} à ko!ngo sur l'argent liquide encaissé. Ce montant sera déduit de vos prochains gains, ou payez-le dans une agence ko!ngo.",
  'Cash you kept':
      'Espèces conservées',
  'Bank or mobile money':
      'Banque ou mobile money',
  'Account or phone number':
      'Numéro de compte ou de téléphone',
  'ko!ngo will send it and let you know.':
      "ko!ngo l'enverra et vous préviendra.",
  'Available {0} · Waiting payouts {1}':
      'Disponible {0} · Retraits en attente {1}',
  'Sales credited':
      'Ventes créditées',
  'Please sign in again':
      'Veuillez vous reconnecter',
  'Your session ended. Sign in again to continue.':
      'Votre session a expiré. Reconnectez-vous pour continuer.',
  "Couldn't get your location. Allow location for ko!ngo, or type your street above.":
      "Impossible d'obtenir votre position. Autorisez la localisation pour ko!ngo, ou tapez votre rue ci-dessus.",
  'Pick an address from the list, or tap "Use my current location".':
      'Choisissez une adresse dans la liste, ou touchez « Utiliser ma position ».',
  "You don't have permission for this action. Try signing in again.":
      "Vous n'avez pas l'autorisation pour cette action. Reconnectez-vous.",
  'code':
      'code',
  'Upload failed':
      "Échec de l'envoi",
  "Pictures can't be saved for this account yet. Please contact ko!ngo support.":
      'Les photos ne peuvent pas encore être enregistrées pour ce compte. Contactez le support ko!ngo.',
  "Pictures can't be saved for this store yet. Please contact ko!ngo support.":
      'Les photos ne peuvent pas encore être enregistrées pour ce magasin. Contactez le support ko!ngo.',
  'The picture could not be saved. Please try again.':
      "La photo n'a pas pu être enregistrée. Réessayez.",
  'No internet connection. Check your network and try again.':
      'Pas de connexion Internet. Vérifiez votre réseau et réessayez.',
  'The upload took too long. Check your connection.':
      "L'envoi a pris trop de temps. Vérifiez votre connexion.",
  'Could not load this item swap. Please try again.':
      'Impossible de charger ce remplacement. Réessayez.',
  "You're offline. Check your data or Wi‑Fi and try again.":
      'Vous êtes hors ligne. Vérifiez vos données ou le Wi‑Fi et réessayez.',
  'No internet. Reconnecting…':
      "Pas d'Internet. Reconnexion…",
  'New order':
      'Nouvelle commande',
  'My trips':
      'Mes courses',
  'Every trip you took, in order':
      "Toutes vos courses, dans l'ordre",
  'Booked':
      'Réservée',
  'No trip in progress':
      'Aucune course en cours',
  'No rides booked for later':
      'Aucune course réservée',
  'No finished trips yet':
      'Aucune course terminée',
  'No cancelled trips':
      'Aucune course annulée',
  'Going to pickup':
      'En route vers le client',
  'At pickup':
      'Au point de départ',
  'Returning parcel':
      'Retour du colis',
  'Completed':
      'Terminée',
  'Returned':
      'Retourné',
  'Expired':
      'Expirée',
  'Delivery':
      'Livraison',
  'Ride':
      'Course',
  'Tap to go back to this trip':
      'Touchez pour revenir à cette course',
  'Today':
      "Aujourd'hui",
  'Tomorrow':
      'Demain',
  'Status':
      'Statut',
  'Price':
      'Prix',
  'Booked for':
      'Réservée pour',
  'Requested':
      'Demandée',
  'Accepted':
      'Acceptée',
  'Finished':
      'Terminée',
  'Reason':
      'Raison',
  'Your rating from the customer':
      'Votre note du client',
  'Trip prices {0} · ko!ngo fee {1}%':
      'Prix des courses {0} · frais ko!ngo {1}%',
  'Trip price':
      'Prix de la course',
  'Pinned on the map':
      'Épinglé sur la carte',
  '{0} ({1} ratings)':
      '{0} ({1} notes)',
  'No ratings yet':
      'Pas encore de notes',
  'New customer · first trip':
      'Nouveau client · première course',
  '1 trip with ko!ngo':
      '1 course avec ko!ngo',
  '{0} trips with ko!ngo':
      '{0} courses avec ko!ngo',
  'New shopping task':
      'Nouvelle course à faire',
  '…':
      '…',
  'Calling…':
      'Appel en cours…',
  'Incoming call':
      'Appel entrant',
  'Connecting…':
      'Connexion…',
  'Decline':
      'Refuser',
  'Answer':
      'Répondre',
  'Mute':
      'Muet',
  'End':
      'Terminer',
  'Speaker':
      'Haut-parleur',
  'Share it with a friend to earn ride credit.':
      'Partagez-le avec un ami pour gagner du crédit de course.',
  'Share your code and earn ride credit for each friend who takes their first ride.':
      'Partagez votre code et gagnez du crédit pour chaque ami qui fait sa première course.',
  "Credit is added after your friend's first completed ride.":
      'Le crédit est ajouté après la première course terminée de votre ami.',
  'Interested? Contact ko!ngo support to join the waitlist.':
      'Intéressé ? Contactez le support ko!ngo pour rejoindre la liste d’attente.',
  'Your driver has arrived':
      'Votre chauffeur est arrivé',
  'Transport':
      'Transport',
  'Marketplace':
      'Marché',
  'Book a ride in minutes · Fast & reliable':
      'Réservez une course en quelques minutes · Rapide et fiable',
  'Send a package · Track delivery':
      'Envoyez un colis · Suivez la livraison',
  'Search shops and categories':
      'Rechercher boutiques et catégories',
  'Groceries':
      'Épicerie',
  'Fashion':
      'Mode',
  'Electronics':
      'Électronique',
  'Home & Living':
      'Maison et vie',
  'Beauty':
      'Beauté',
  'Butchery':
      'Boucherie',
  'Bakery':
      'Boulangerie',
  'General Retail':
      'Commerce général',
  'Other':
      'Autre',
  'No categories match your search.':
      'Aucune catégorie ne correspond à votre recherche.',
  'Nearby drivers · {0} nearby':
      'Chauffeurs proches · {0} à proximité',
  'Your new photo is saved.':
      'Votre nouvelle photo est enregistrée.',
  'Customers see this photo when you shop for them.':
      'Les clients voient cette photo quand vous faites leurs courses.',
  'Change photo':
      'Changer la photo',
  'All':
      'Tout',
  'Restaurant':
      'Restaurant',
  'Pharmacy':
      'Pharmacie',
  'Marketplace: delivery requests from shops and stores':
      'Marché : demandes de livraison des boutiques et magasins',
  'No shop deliveries right now. New ones appear here and ring your phone.':
      'Aucune livraison de boutique pour l’instant. Les nouvelles apparaissent ici et font sonner votre téléphone.',
  'Go online to receive shop deliveries.':
      'Passez en ligne pour recevoir les livraisons de boutiques.',
  'Passed · {0}%':
      'Réussi · {0} %',
  'Score {0}% · 80% to pass':
      'Score {0} % · 80 % pour réussir',
  'Well done. This module is now complete.':
      'Bravo. Ce module est maintenant terminé.',
  'Review the answers above and try again.':
      'Relisez les réponses ci-dessus et réessayez.',
  'Answer {0} more':
      'Répondez à {0} de plus',
  'Submit quiz':
      'Envoyer le quiz',
  'Call customer':
      'Appeler le client',
  'Recommended':
      'Recommandé',
  "You're certified. Happy driving!":
      'Vous êtes certifié. Bonne route !',
  'Complete all required modules to go online.':
      'Terminez tous les modules requis pour passer en ligne.',
  'Certificate of completion':
      'Certificat de réussite',
  'Certificate locked':
      'Certificat verrouillé',
  'You have completed all required training.':
      'Vous avez terminé toute la formation requise.',
  'Complete all required modules to unlock.':
      'Terminez tous les modules requis pour déverrouiller.',
  'My shops':
      'Mes boutiques',
  'Add another shop':
      'Ajouter une autre boutique',
  '{0} · Business type':
      '{0} · Type d’activité',
  'For {0}':
      'Pour {0}',
  'Restock':
      'Réapprovisionner',
  'Store profile':
      'Profil du magasin',
  'Quick Actions':
      'Actions rapides',
  'day':
      'jour',
  'fixed price':
      'prix fixe',
  'hour':
      'heure',
  'This week':
      'Cette semaine',
  'Ongoing':
      'En continu',
  'Just now':
      'À l\'instant',
  '{0} min ago':
      'il y a {0} min',
  '{0} h ago':
      'il y a {0} h',
  '{0} d ago':
      'il y a {0} j',
  'Live':
      'En ligne',
  'Filled':
      'Pourvu',
  'Not approved':
      'Non approuvé',
  'Shortlisted':
      'Présélectionné',
  'Hired':
      'Embauché',
  'Applied':
      'Postulé',
  'Withdrawn':
      'Retiré',
  'URGENT':
      'URGENT',
  'Hiring Hub':
      'Espace Emploi',
  'Find Work':
      'Trouver du travail',
  'My Applications':
      'Mes candidatures',
  'My Jobs':
      'Mes offres',
  'Post a Job':
      'Publier une offre',
  'Search jobs, skills...':
      'Rechercher emplois, compétences...',
  'Could not load jobs. Pull down to try again.':
      'Impossible de charger les offres. Tirez vers le bas pour réessayer.',
  'No jobs here yet. Be the first to post one!':
      'Aucune offre ici pour le moment. Soyez le premier à en publier une !',
  'Apply':
      'Postuler',
  'You have not applied for any job yet.':
      'Vous n\'avez encore postulé à aucune offre.',
  'Jobs you post will show here.':
      'Les offres que vous publiez apparaîtront ici.',
  'applicants':
      'candidats',
  'Application sent. You will be notified.':
      'Candidature envoyée. Vous serez notifié.',
  'Verified ID':
      'Pièce d\'identité vérifiée',
  'Experience':
      'Expérience',
  'Own tools':
      'Outils personnels',
  'Own transport':
      'Transport personnel',
  'Employer':
      'Employeur',
  '{0} workers needed':
      '{0} travailleurs recherchés',
  'Description':
      'Description',
  'Requirements':
      'Exigences',
  'Your application':
      'Votre candidature',
  'Withdraw application':
      'Retirer la candidature',
  'Say a few words about yourself (optional)':
      'Dites quelques mots sur vous (facultatif)',
  'Close this job?':
      'Fermer cette offre ?',
  'Workers will no longer see it.':
      'Les travailleurs ne la verront plus.',
  'Close job':
      'Fermer l\'offre',
  'We are checking your job. It will go live as soon as it is approved.':
      'Nous vérifions votre offre. Elle sera en ligne dès son approbation.',
  'Applicants':
      'Candidats',
  'No applicants yet.':
      'Aucun candidat pour le moment.',
  'Shortlist':
      'Présélectionner',
  'Hire':
      'Embaucher',
  'Allow location to use this.':
      'Autorisez la localisation pour l\'utiliser.',
  'Could not find your location.':
      'Impossible de trouver votre position.',
  'Please enter a job title.':
      'Veuillez saisir un titre.',
  'Please enter the pay amount.':
      'Veuillez saisir le montant.',
  'Please enter where the job is.':
      'Veuillez indiquer où se trouve le travail.',
  'This is how workers will see your job':
      'Voici comment les travailleurs verront votre offre',
  'The photo could not be uploaded. Try again or post without it.':
      'La photo n\'a pas pu être envoyée. Réessayez ou publiez sans elle.',
  'Job sent for approval':
      'Offre envoyée pour approbation',
  'We will check it and let you know as soon as it is live.':
      'Nous allons la vérifier et vous prévenir dès qu\'elle est en ligne.',
  'Post a Job - Hire in minutes':
      'Publiez une offre - Embauchez en quelques minutes',
  'Fill out the details and connect with trusted workers near you':
      'Remplissez les détails et trouvez des travailleurs de confiance près de vous',
  'Job Title':
      'Titre du poste',
  'e.g. House Cleaner Needed':
      'ex. Femme de ménage recherchée',
  'Category':
      'Catégorie',
  'Describe the job, what you need done, and any important details...':
      'Décrivez le travail, ce qu\'il faut faire et les détails importants...',
  'Pay Type':
      'Type de paiement',
  'Per Hour':
      'Par heure',
  'Per Day':
      'Par jour',
  'Fixed Price':
      'Prix fixe',
  'Amount ({0})':
      'Montant ({0})',
  'Location':
      'Lieu',
  'Where is the job?':
      'Où se trouve le travail ?',
  'Use my location':
      'Utiliser ma position',
  'Duration':
      'Durée',
  'Workers needed':
      'Travailleurs recherchés',
  'Mark as urgent':
      'Marquer comme urgent',
  'Upload photo':
      'Ajouter une photo',
  'optional':
      'facultatif',
  'Add a photo to help workers understand the job':
      'Ajoutez une photo pour aider les travailleurs à comprendre le travail',
  'Your first name will be visible to workers. Your job is checked before it goes live.':
      'Votre prénom sera visible par les travailleurs. Votre offre est vérifiée avant publication.',
  'Preview Job':
      'Aperçu de l\'offre',
  'Post Job Now':
      'Publier maintenant',
  'Hiring Hub - Find work, hire talent':
      'Espace Emploi - Trouvez du travail, recrutez des talents',
  'Trusted workers and jobs near you':
      'Travailleurs de confiance et emplois près de vous',
  'See All':
      'Tout voir',
  'Latest jobs':
      'Dernières offres',
  'Hiring':
      'Emploi',
  'Rides & Delivery':
      'Courses et livraison',
  'Cleaning & Home':
      'Ménage et maison',
  'Construction':
      'Construction',
  'Retail & Hospitality':
      'Commerce et restauration',
  'Tutoring':
      'Cours particuliers',
  'Admin & Office':
      'Administration et bureau',
  'This job is closed':
      'Cette offre est fermée',
  'This job is no longer taking applications.':
      'Cette offre n\'accepte plus de candidatures.',
  'Not possible':
      'Impossible',
  'You cannot apply to your own job.':
      'Vous ne pouvez pas postuler à votre propre offre.',
  'Your wallet needs {0} to post this job. Top up and try again.':
      'Votre portefeuille doit contenir {0} pour publier cette offre. Rechargez et réessayez.',
  '+{0} · shown first for {1} days':
      '+{0} · affiché en premier pendant {1} jours',
  'Shown first for {0} days':
      'Affiché en premier pendant {0} jours',
  'Posting fee':
      'Frais de publication',
  'Urgent boost':
      'Mise en avant urgente',
  'Total from your wallet':
      'Total prélevé sur votre portefeuille',
  'Your wallet':
      'Votre portefeuille',
  'If we do not approve your job, the fee is returned to your wallet.':
      'Si nous n\'approuvons pas votre offre, les frais sont remboursés dans votre portefeuille.',
  'Top up wallet':
      'Recharger le portefeuille',
  'Fresh picks, fast':
      'Produits frais, livrés vite',
  'Our shoppers pick the best for you':
      'Nos acheteurs choisissent le meilleur pour vous',
  'Verified pharmacies':
      'Pharmacies vérifiées',
  'Cold-chain ready · pharmacist-verified':
      'Chaîne du froid assurée · vérifié par un pharmacien',
  'Shops near you':
      'Boutiques près de chez vous',
  'Get around with KO!NGO':
      'Déplacez-vous avec KO!NGO',
  'Fast':
      'Rapide',
  'Safe':
      'Sûr',
  'Reliable':
      'Fiable',
  'Book a Ride':
      'Réserver une course',
  'Shop from a wide range':
      'Achetez parmi un large choix',
  'Groceries, food, pharmacy, fashion and more, brought to your door':
      'Courses, repas, pharmacie, mode et plus, livrés à votre porte',
  'Promote my store':
      'Promouvoir ma boutique',
  'Be listed first and get more orders':
      'Soyez en tête de liste et recevez plus de commandes',
  'Sponsored':
      'Sponsorisé',
  'Sponsored until {0}':
      'Sponsorisé jusqu\'au {0}',
  'Your store appears first in the list with a Sponsored label.':
      'Votre boutique apparaît en premier avec l\'étiquette Sponsorisé.',
  'Your store is now sponsored':
      'Votre boutique est maintenant sponsorisée',
  'Sponsored spots are not available in your country yet.':
      'Les places sponsorisées ne sont pas encore disponibles dans votre pays.',
  'How many weeks?':
      'Combien de semaines ?',
  'week':
      'semaine',
  'weeks':
      'semaines',
  'Price per week':
      'Prix par semaine',
  'Sponsor my store · {0}':
      'Sponsoriser ma boutique · {0}',
  'Not available':
      'Indisponible',
  'This is not available right now.':
      'Ce n\'est pas disponible pour le moment.',
  'Earn more':
      'Gagnez plus',
  'tasks':
      'tâches',
  'trips':
      'courses',
  'task':
      'tâche',
  'trip':
      'course',
  'Done! {0} added to your wallet':
      'Terminé ! {0} ajouté à votre portefeuille',
  '{0} of {1} {2} this week · Bonus {3}':
      '{0} sur {1} {2} cette semaine · Bonus {3}',
  '{0}: +{1} for every {2} between {3} and {4}':
      '{0} : +{1} pour chaque {2} entre {3} et {4}',
  'Verified by ko!ngo':
      'Vérifié par ko!ngo',
  'Verified':
      'Vérifié',
  'Signed in on another phone':
      'Connecté sur un autre téléphone',
  'Your account was opened on another phone, so this one was signed out.':
      'Votre compte a été ouvert sur un autre téléphone, donc celui-ci a été déconnecté.',
  'Recommendations':
      'Recommandations',
  'Add your vehicle':
      'Ajoutez votre véhicule',
  'You owe ko!ngo {0}':
      'Vous devez {0} à ko!ngo',
  'Add your profile picture':
      'Ajoutez votre photo de profil',
  'Upload your papers ({0} missing)':
      'Envoyez vos documents ({0} manquants)',
  'Your papers are being checked':
      'Vos documents sont en cours de vérification',
  'Add your bank details to get paid':
      'Ajoutez vos coordonnées bancaires pour être payé',
  'Finish driver academy':
      'Terminez l\'académie des chauffeurs',
  'You are all set. Nothing to fix.':
      'Tout est en ordre. Rien à corriger.',
  'Tap to see what to fix':
      'Touchez pour voir quoi corriger',
  'Quick photo check':
      'Vérification photo rapide',
  'Take a live selfie now so we know it is you. This takes a few seconds.':
      'Prenez un selfie maintenant pour que nous sachions que c\'est vous. Cela prend quelques secondes.',
  'Your face must be clearly visible. Photos from the gallery are not accepted.':
      'Votre visage doit être bien visible. Les photos de la galerie ne sont pas acceptées.',
  'Take selfie':
      'Prendre un selfie',
  'Send photo':
      'Envoyer la photo',
  'Retake':
      'Reprendre',
  'Sending…':
      'Envoi…',
  'Photo check sent. Thank you.':
      'Vérification photo envoyée. Merci.',
  'Photo check needed before you go online':
      'Vérification photo nécessaire avant de passer en ligne',
  'Take your weekly selfie check':
      'Faites votre selfie de la semaine',
  'Could not send the photo. Check your internet and try again.':
      'Impossible d\'envoyer la photo. Vérifiez votre connexion et réessayez.',
  'Could not open the camera. Allow camera access for ko!ngo in your phone settings.':
      'Impossible d\'ouvrir la caméra. Autorisez l\'accès à la caméra pour ko!ngo dans les réglages du téléphone.',
  'Your balance is low. Top up so you can keep working without interruption.': 'Votre solde est bas. Rechargez pour continuer à travailler sans interruption.',
  'Your balance is low ({0}). Top up.': 'Votre solde est bas ({0}). Rechargez.',
  'Daily goal': 'Objectif du jour',
  'Set a daily goal': 'Fixer un objectif du jour',
  'Goal reached!': 'Objectif atteint !',
  '{0} of {1}': '{0} sur {1}',
  'Amount you want to earn today': 'Montant que vous voulez gagner aujourd\'hui',
  'Trips': 'Courses',
  'Up {0}% on last week': 'En hausse de {0} % sur la semaine dernière',
  'Down {0}% on last week': 'En baisse de {0} % sur la semaine dernière',
  'Same as last week': 'Comme la semaine dernière',
  'No trips yet this week': 'Aucune course cette semaine',
  'Pop-up over other apps': 'Fenêtre par-dessus les autres applis',
  'Lets a ride request open ko!ngo on top of other apps. Switch it on for ko!ngo on the page that opens.': 'Permet à une demande de course d\'ouvrir ko!ngo par-dessus les autres applis. Activez-le pour ko!ngo sur la page qui s\'ouvre.',
  'Open settings': 'Ouvrir les réglages',
  'Not ringing? See what happened to the last request on this phone.': 'Pas de sonnerie ? Voyez ce qui s\'est passé pour la dernière demande sur ce téléphone.',
  'Check last ring': 'Vérifier la dernière sonnerie',
  'No ring has reached this phone yet.': 'Aucune sonnerie n\'a encore atteint ce téléphone.',
  'Tip your driver':
      'Donnez un pourboire',
  'Send tip':
      'Envoyer le pourboire',
  'Tip sent. Thank you!':
      'Pourboire envoyé. Merci !',
  'Custom amount':
      'Autre montant',
  'Why this rating? (optional)':
      'Pourquoi cette note ? (facultatif)',
  'Share receipt':
      'Partager le reçu',
  'Tip amount':
      'Montant du pourboire',
  'My worker profile':
      'Mon profil de travailleur',
  'Other requests':
      'Autres demandes',
  '{0} other requests waiting. Choose one.':
      '{0} autres demandes en attente. Choisissez-en une.',
  'Finish your current trip first':
      'Terminez d\'abord votre course en cours',
  'You can accept one order at a time.':
      'Vous ne pouvez accepter qu\'une commande à la fois.',
  'Shops':
      'Boutiques',
  'Open':
      'Ouvert',
  'Nothing found. Try another word.':
      'Rien trouvé. Essayez un autre mot.',
  'Heavy traffic ahead. About {0} extra minutes.':
      'Fort trafic devant. Environ {0} minutes de plus.',
  'Slow traffic in {0} km.':
      'Circulation lente dans {0} km.',
  'In {0} metres: {1}':
      'Dans {0} mètres : {1}',
  '{0} reported ahead.':
      '{0} signalé plus loin.',
  'Accident':
      'Accident',
  'Hazard on the road':
      'Danger sur la route',
  'Traffic jam':
      'Embouteillage',
  'Report on the road':
      'Signaler sur la route',
  'Thanks, other drivers will be warned.':
      'Merci, les autres chauffeurs seront prévenus.',
  'Navigation started':
      'Navigation démarrée',
  'Heavy traffic: +{0} min':
      'Fort trafic : +{0} min',
  'Voice directions':
      'Guidage vocal',
  'Take a photo now':
      'Prendre une photo maintenant',
  'Your worker profile is ready':
      'Votre profil de travailleur est prêt',
  'Looking for work?':
      'Vous cherchez du travail ?',
  'Tap Apply on any job below.':
      'Appuyez sur Postuler sur n\'importe quelle offre ci-dessous.',
  'Set up your worker profile so employers can see what you do. Then tap Apply on any job.':
      'Créez votre profil de travailleur pour que les employeurs voient ce que vous faites. Ensuite, appuyez sur Postuler.',
  'Set up my profile':
      'Créer mon profil',
  'No jobs here yet. Check back soon.':
      'Pas de travail ici pour le moment. Revenez bientôt.',
  'Need to hire someone? Post a job':
      'Besoin d\'embaucher ? Publiez une offre',
  'Write what work you do, for example "Painter".':
      'Écrivez quel travail vous faites, par exemple « Peintre ».',
  'Profile saved':
      'Profil enregistré',
  'Employers see this when you apply for a job. Save it once.':
      'Les employeurs voient ceci quand vous postulez. Enregistrez-le une seule fois.',
  'What work do you do?':
      'Quel travail faites-vous ?',
  'e.g. Painter, Driver, Cleaner':
      'ex. Peintre, Chauffeur, Femme de ménage',
  'Your skills':
      'Vos compétences',
  'e.g. painting, walls, roofs':
      'ex. peinture, murs, toits',
  'Years of experience':
      'Années d\'expérience',
  'About you':
      'À propos de vous',
  'Tell employers why they should choose you':
      'Dites aux employeurs pourquoi vous choisir',
  'Save profile':
      'Enregistrer le profil',
  'Add a short comment (optional)':
      'Ajoutez un court commentaire (facultatif)',
  'Send rating':
      'Envoyer la note',
  'Rate the employer':
      'Noter l\'employeur',
  'Thank you for your rating':
      'Merci pour votre note',
  'years experience':
      'ans d\'expérience',
  'Rate this worker':
      'Noter ce travailleur',
  'You rated {0} stars':
      'Vous avez donné {0} étoiles',
  'Voice search is not available on this phone.':
      'La recherche vocale n\'est pas disponible sur ce téléphone.',
  'Speak to search':
      'Parler pour chercher',
  'Split the fare':
      'Partager le tarif',
  'Each person pays {0}':
      'Chaque personne paie {0}',
  'Each person pays the driver their share. Nothing is taken from your wallet for others.':
      'Chaque personne paie sa part au chauffeur. Rien n\'est prélevé sur votre portefeuille pour les autres.',
  'Our ko!ngo ride costs {0} in total. With {1} of us, each pays {2}.':
      'Notre course ko!ngo coûte {0} au total. À {1}, chacun paie {2}.',
  'Send to friends':
      'Envoyer aux amis',
  'National ID / Passport':
      'Carte d\'identité / Passeport',
  'Clear photo of the whole document':
      'Photo nette du document entier',
  'Selfie holding your ID':
      'Selfie avec votre pièce d\'identité',
  'Your face and the ID must both be readable':
      'Votre visage et la pièce doivent être lisibles',
  'Driving licence':
      'Permis de conduire',
  'Valid, for your type of vehicle':
      'Valide, pour votre type de véhicule',
  'Vehicle registration & insurance':
      'Carte grise et assurance',
  'Registration paper and valid insurance':
      'Carte grise et assurance valide',
  'Police clearance':
      'Casier judiciaire',
  'Criminal record extract, not older than 6 months':
      'Extrait de casier judiciaire de moins de 6 mois',
  'Technical inspection':
      'Contrôle technique',
  'Roadworthy certificate':
      'Certificat de conformité routière',
  'If your vehicle needs one':
      'Si votre véhicule en nécessite un',
  'Professional driving permit (PrDP)':
      'Permis professionnel (PrDP)',
  'For paid passenger transport':
      'Pour le transport payant de passagers',
  'Business registration (RCCM)':
      'Registre de commerce (RCCM)',
  'Business registration (CIPC)':
      'Enregistrement de l\'entreprise (CIPC)',
  'Registration paper of your business':
      'Document d\'enregistrement de votre entreprise',
  'Photo of your shop front':
      'Photo de la façade de votre boutique',
  'Show the sign and the entrance':
      'Montrez l\'enseigne et l\'entrée',
  'Tax number (NIU)':
      'Numéro d\'impôt (NIU)',
  'Tax number (SARS)':
      'Numéro fiscal (SARS)',
  'Adds trust, not required':
      'Renforce la confiance, facultatif',
  'Health certificate':
      'Certificat sanitaire',
  'Food sellers: certificate from your municipality':
      'Vendeurs de nourriture : certificat de votre commune',
  'Not accepted':
      'Refusé',
  'Waiting for review':
      'En attente de vérification',
  'Not uploaded':
      'Non envoyé',
  'Optional':
      'Facultatif',
  'Upload':
      'Envoyer',
  'Verify me':
      'Me vérifier',
  'You are verified. Customers see your badge.':
      'Vous êtes vérifié. Les clients voient votre badge.',
  '{0} of {1} required papers accepted. When all are accepted you get the Verified badge.':
      '{0} sur {1} documents requis acceptés. Quand tous sont acceptés, vous recevez le badge Vérifié.',
  'Your papers are private. Only ko!ngo admin can see them.':
      'Vos documents sont privés. Seul l\'admin ko!ngo peut les voir.',
  'Verify my business':
      'Vérifier mon commerce',
  'Not allowed':
      'Non autorisé',
  'Trip not found':
      'Course introuvable',
  'This is not your trip':
      'Ce n\'est pas votre course',
  'User not found':
      'Utilisateur introuvable',
  'Job not found':
      'Offre introuvable',
  'Enter the customer\'s PIN to start':
      'Entrez le code PIN du client pour démarrer',
  'The trip has started. Only the driver can end it now.':
      'La course a commencé. Seul le chauffeur peut la terminer.',
  'This trip has already ended':
      'Cette course est déjà terminée',
  'This job is finished and cannot be changed':
      'Cette offre est terminée et ne peut plus être modifiée',
  'You can book up to 30 days ahead':
      'Vous pouvez réserver jusqu\'à 30 jours à l\'avance',
  'Pick a time at least 15 minutes from now':
      'Choisissez une heure au moins 15 minutes plus tard',
  'This request is no longer available':
      'Cette demande n\'est plus disponible',
  'Sponsored spots are not available right now':
      'Les places sponsorisées ne sont pas disponibles pour le moment',
  'You can rate after your trip':
      'Vous pourrez noter après votre course',
  'You can rate after the trip':
      'Vous pourrez noter après la course',
  'You can only rate after a hire on this job':
      'Vous ne pouvez noter qu\'après une embauche sur cette offre',
  'This ride is booked for later':
      'Cette course est réservée pour plus tard',
  'This is not your store':
      'Ce n\'est pas votre boutique',
  'Only the driver can release this trip':
      'Seul le chauffeur peut libérer cette course',
  'Only the driver can do this':
      'Seul le chauffeur peut faire cela',
  'The price can\'t be changed':
      'Le prix ne peut pas être modifié',
  'Shop deliveries have a fixed fee':
      'Les livraisons de boutique ont un tarif fixe',
  'This job is no longer open':
      'Cette offre n\'est plus ouverte',
  'That price offer is no longer available':
      'Cette offre de prix n\'est plus disponible',
  'Cancel the order instead':
      'Annulez plutôt la commande',
  'Start the trip first':
      'Démarrez d\'abord la course',
  'Start the return first':
      'Démarrez d\'abord le retour',
  'Pick up the parcel first':
      'Récupérez d\'abord le colis',
  'Enter an amount':
      'Entrez un montant',
  'Enter a price':
      'Entrez un prix',
  'Choose 1 to 5 stars':
      'Choisissez de 1 à 5 étoiles',
  'Pick 1 to 5 stars':
      'Choisissez de 1 à 5 étoiles',
  'Finish or cancel your current trip first':
      'Terminez ou annulez d\'abord votre course en cours',
  'You can withdraw up to {0}':
      'Vous pouvez retirer jusqu\'à {0}',
  'Choose between 1 and {0} weeks':
      'Choisissez entre 1 et {0} semaines',
  'Sign-up problem on our side':
      'Problème d\'inscription de notre côté',
  'Our server could not finish this. Please try again in a moment, or contact ko!ngo support.':
      'Notre serveur n\'a pas pu terminer. Réessayez dans un instant ou contactez le support ko!ngo.',
  'No answer. The other person must have the trip open in the app.':
      'Pas de réponse. L\'autre personne doit avoir le trajet ouvert dans l\'application.',
  'Couldn\'t connect the call. Check that both phones have internet and try again.':
      'Impossible d\'établir l\'appel. Vérifiez que les deux téléphones ont Internet et réessayez.',
  'Couldn\'t start the microphone. Allow microphone access for ko!ngo in your phone settings.':
      'Impossible de démarrer le micro. Autorisez l\'accès au micro pour ko!ngo dans les réglages du téléphone.',
};
