﻿// lib/screens/auth/auth_screen.dart

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:provider/provider.dart';
import 'package:efuride_app/config/app_lang.dart';
import 'package:efuride_app/config/country_catalog.dart';
import 'package:efuride_app/config/country_config.dart';
import 'package:efuride_app/config/efuride_palette.dart';
import 'package:efuride_app/main.dart' show appLanguageNotifier;
import 'package:efuride_app/l10n/app_strings.dart'; // Added
import 'package:efuride_app/providers/auth_provider.dart';
import 'package:efuride_app/utils/app_error.dart';
import 'package:efuride_app/utils/error_ui.dart';
import 'package:efuride_app/utils/roles.dart';
import 'package:efuride_app/widgets/k_icon.dart';

class AuthScreen extends StatefulWidget {
  /// 'customer' | 'driver' | 'shopper' | 'merchant'
  final String role;

  /// 'signin' | 'signup'
  final String mode;

  const AuthScreen({
    super.key,
    this.role = 'customer',
    this.mode = 'signin',
  });

  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  final _confirmPasswordController = TextEditingController(); // Added
  final _firstNameController = TextEditingController();
  final _surnameController = TextEditingController();
  final _phoneController = TextEditingController();

  final _emailFocus = FocusNode();
  final _passwordFocus = FocusNode();
  final _confirmPasswordFocus = FocusNode(); // Added

  late bool isSignUp;
  late String _role;

  bool isLoading = false;
  bool _obscurePassword = true;
  bool _obscureConfirmPassword = true; // Added
  String selectedGender = 'Male';

  // Per-field validation errors
  String? _emailError;
  String? _passwordError;
  String? _confirmPasswordError; // Added
  String? _firstNameError;
  String? _surnameError;
  String? _phoneError;
  String? _countryError;

  /// Country picked at sign-up (sets language, currency, phone prefix).
  KongoCountry? _country;

  @override
  void initState() {
    super.initState();
    _role = widget.role.toLowerCase();
    isSignUp = widget.mode == 'signup';
    // Pre-select the country the phone is in, if we serve it.
    _country = CountryCatalog.byIso(CountryConfig.isoCode);
    if (_country != null) _phoneController.text = '${_country!.phonePrefix} ';
  }

  /// Picking a country switches the app to that country's main
  /// language (the person can still tap another one below).
  void _chooseCountry(KongoCountry c) {
    final oldPrefix = _country?.phonePrefix ?? '';
    final phone = _phoneController.text.trim();
    setState(() {
      _country = c;
      _countryError = null;
      if (phone.isEmpty || phone == oldPrefix) {
        _phoneController.text = '${c.phonePrefix} ';
      }
    });
    CountryConfig.setCountry(c.iso);
    _setLanguage(c.defaultLanguage);
  }

  void _setLanguage(AppLang lang) {
    appLanguageNotifier.value = lang;
    context.read<AuthProvider>().setLanguage(lang);
    AppLangStore.saveUserChoice(lang);
  }

  Future<void> _openCountryPicker() async {
    final picked = await showModalBottomSheet<KongoCountry>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (ctx) => SafeArea(
        child: ConstrainedBox(
          constraints: BoxConstraints(
              maxHeight: MediaQuery.of(ctx).size.height * 0.8),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const SizedBox(height: 14),
              Text(tr('Choose your country'),
                  style: const TextStyle(
                      fontSize: 20, fontWeight: FontWeight.w800)),
              const SizedBox(height: 8),
              Flexible(
                child: ListView(
                  shrinkWrap: true,
                  children: [
                    for (final c in CountryCatalog.all)
                      ListTile(
                        leading: Text(c.flag,
                            style: const TextStyle(fontSize: 28)),
                        title: Text(c.name,
                            style: const TextStyle(
                                fontSize: 17, fontWeight: FontWeight.w700)),
                        subtitle: Text(
                          c.usableLanguages.map((l) => l.label).join(' · '),
                          style: const TextStyle(fontSize: 14),
                        ),
                        trailing: c.iso == _country?.iso
                            ? Icon(Icons.check_circle, color: _accent)
                            : null,
                        onTap: () => Navigator.pop(ctx, c),
                      ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
    if (picked != null && mounted) _chooseCountry(picked);
  }

  Widget _countryField(S t) {
    final c = _country;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        InkWell(
          onTap: _openCountryPicker,
          borderRadius: BorderRadius.circular(14),
          child: InputDecorator(
            decoration: InputDecoration(
              labelText: tr('Country'),
              labelStyle: const TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w600,
                color: EfuridePalette.inkMuted,
              ),
              prefixIcon: const KIcon(Icons.public,
                  size: 20, color: EfuridePalette.inkMuted),
              suffixIcon: const Icon(Icons.expand_more),
              filled: true,
              fillColor: EfuridePalette.cream,
              errorText: _countryError,
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(14),
                borderSide: BorderSide.none,
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(14),
                borderSide: BorderSide.none,
              ),
            ),
            child: Text(
              c == null ? tr('Choose your country') : '${c.flag}  ${c.name}',
              style: TextStyle(
                fontSize: 15.5,
                fontWeight: FontWeight.w600,
                color: c == null ? EfuridePalette.inkMuted : EfuridePalette.ink,
              ),
            ),
          ),
        ),
        // That country's languages, main one first.
        if (c != null && c.usableLanguages.length > 1) ...[
          const SizedBox(height: 10),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              for (final l in c.usableLanguages)
                ChoiceChip(
                  label: Text(l.label,
                      style: const TextStyle(
                          fontSize: 15, fontWeight: FontWeight.w700)),
                  selected: appLanguageNotifier.value == l,
                  selectedColor: _accent.withValues(alpha: 0.18),
                  onSelected: (_) => setState(() => _setLanguage(l)),
                ),
            ],
          ),
        ],
      ],
    );
  }

  @override
  void dispose() {
    _emailController.dispose();
    _passwordController.dispose();
    _confirmPasswordController.dispose(); // Added
    _firstNameController.dispose();
    _surnameController.dispose();
    _phoneController.dispose();
    _emailFocus.dispose();
    _passwordFocus.dispose();
    _confirmPasswordFocus.dispose(); // Added
    super.dispose();
  }

  // ============================================================
  // ROLE METADATA
  // ============================================================
  bool get _isCustomer => _role == 'customer';
  bool get _isDriver => _role == 'driver';
  bool get _isShopper => _role == 'shopper';
  bool get _isMerchant => _role == 'merchant';

  /// Which roles need the full personal signup form (name + gender + phone).
  bool get _usesPersonalSignup =>
      isSignUp && (_isCustomer || _isDriver || _isShopper || _isMerchant);

  /// Whether to show the gender field.
  bool get _showsGender => isSignUp && !_isMerchant;

  Color get _accent {
    switch (_role) {
      case 'driver':
        return EfuridePalette.online;
      case 'shopper':
        return EfuridePalette.shopperAccent;
      case 'merchant':
        return EfuridePalette.merchantAccent;
      case 'customer':
      default:
        return EfuridePalette.accent;
    }
  }

  Color get _buttonInk {
    return _isCustomer ? EfuridePalette.accentInk : Colors.white;
  }

  IconData get _roleIcon {
    switch (_role) {
      case 'driver':
        return Icons.directions_car_filled;
      case 'shopper':
        return Icons.shopping_bag_rounded;
      case 'merchant':
        return Icons.storefront;
      case 'customer':
      default:
        return Icons.person_pin_circle;
    }
  }

  // ============================================================
  // VALIDATORS
  // ============================================================
  String? _validateEmail(String v, S t) {
    final email = v.trim();
    if (email.isEmpty) return t.t('enter_email');
    final ok = RegExp(r'^[\w\.\-\+]+@[\w\-]+\.[\w\.\-]+$').hasMatch(email);
    return ok ? null : t.t('invalid_email');
  }

  String? _validatePassword(String v, S t) {
    if (v.isEmpty) return t.t('enter_password');
    if (isSignUp && v.length < 8) return t.t('password_min_8');
    return null;
  }

  // Added Confirm Password Validator
  String? _validateConfirmPassword(String v, S t) {
    if (!isSignUp) return null;
    if (v.isEmpty) return t.t('enter_password'); // Or 'confirm_password'
    if (v != _passwordController.text) {
      return t.t('passwords_do_not_match'); // Add this to your translations
    }
    return null;
  }

  String? _validateName(String v, {required String label, required S t}) {
    if (!_usesPersonalSignup) return null;
    final name = v.trim();
    if (name.isEmpty) return t.t('enter_name').replaceAll('{name}', label);
    if (name.length < 2) return t.t('name_too_short').replaceAll('{name}', label);
    return null;
  }

  String? _validatePhone(String v, S t) {
    if (!_usesPersonalSignup) return null;
    final digits = v.replaceAll(RegExp(r'\D'), '');
    if (digits.isEmpty) return t.t('enter_phone');
    if (digits.length < 9) return t.t('phone_too_short');
    return null;
  }

  bool _validateAll(S t) {
    final email = _validateEmail(_emailController.text, t);
    final password = _validatePassword(_passwordController.text, t);
    final confirmPassword =
        _validateConfirmPassword(_confirmPasswordController.text, t); // Added
    final first = _validateName(_firstNameController.text, label: t.t('first_name'), t: t);
    final surname = _validateName(_surnameController.text, label: t.t('surname'), t: t);
    final phone = _validatePhone(_phoneController.text, t);
    final country = (_usesPersonalSignup && _country == null)
        ? tr('Choose your country')
        : null;

    setState(() {
      _countryError = country;
      _emailError = email;
      _passwordError = password;
      _confirmPasswordError = confirmPassword; // Added
      _firstNameError = first;
      _surnameError = surname;
      _phoneError = phone;
    });

    return email == null &&
        password == null &&
        confirmPassword == null && // Added
        first == null &&
        surname == null &&
        phone == null &&
        country == null;
  }

  // ============================================================
  // AUTH
  // ============================================================
  Future<void> _authenticate() async {
    FocusScope.of(context).unfocus();
    final t = S.of(context);
    if (!_validateAll(t)) return;

    setState(() => isLoading = true);
    final auth = context.read<AuthProvider>();

    try {
      if (isSignUp) {
        final result = await auth.signUp(
          email: _emailController.text.trim(),
          password: _passwordController.text,
          firstName: _firstNameController.text.trim(),
          surname: _surnameController.text.trim(),
          gender: _showsGender ? selectedGender : 'Other',
          phone: _phoneController.text.trim(),
          role: _role,
          countryCode: _country?.iso,
        );

        if (!mounted) return;

        switch (result) {
          case 'driver_pending':
            Navigator.pushReplacementNamed(context, '/pending_approval');
            return;
          case 'shopper':
            Navigator.pushNamedAndRemoveUntil(context, '/shopper', (_) => false);
            return;
          case 'merchant':
            Navigator.pushNamedAndRemoveUntil(context, '/merchant', (_) => false);
            return;
          case 'customer':
            Navigator.pushNamedAndRemoveUntil(context, '/customer', (_) => false);
            return;
          case 'error':
          default:
            final raw = auth.lastError;
            ErrorUI.showSnack(
              context,
              raw != null
                  ? AppError.from(raw)
                  : AppError(
                      title: t.t('signup_failed'),
                      message: t.t('signup_failed_msg'),
                      icon: Icons.person_off_outlined,
                    ),
            );
        }
        return;
      }

      // Sign in
      final result = await auth.signInWithPassword(
        email: _emailController.text.trim(),
        password: _passwordController.text,
      );

      if (!mounted) return;

      // Signed in at another role's door (e.g. driver details typed on
      // the customer login): don't let them in here. Sign straight back
      // out and send them to the right login.
      if (isAppRole(result) && result != normalizeRole(_role)) {
        await auth.signOut();
        if (!mounted) return;
        final roleName = t.t(roleLabelKey(result));
        final go = await showDialog<bool>(
          context: context,
          builder: (ctx) => AlertDialog(
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16)),
            title: Text(tr('This is a {0} account', [roleName])),
            content: Text(
              tr('These details belong to a {0} account, so they can\'t be used on the {1} login. Please sign in from the {0} login.',
                  [roleName, t.t(roleLabelKey(normalizeRole(_role)))]),
              style: const TextStyle(fontSize: 15.5, height: 1.4),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(ctx, false),
                child: Text(tr('Cancel')),
              ),
              ElevatedButton(
                onPressed: () => Navigator.pop(ctx, true),
                child: Text(tr('Go to {0} login', [roleName])),
              ),
            ],
          ),
        );
        if (!mounted) return;
        if (go == true) {
          Navigator.pushReplacementNamed(context, '/auth',
              arguments: {'role': result, 'mode': 'signin'});
        }
        return;
      }

      switch (result) {
        case 'customer':
          Navigator.pushNamedAndRemoveUntil(context, '/customer', (_) => false);
          break;
        case 'driver':
          Navigator.pushNamedAndRemoveUntil(context, '/driver', (_) => false);
          break;
        case 'shopper':
          Navigator.pushNamedAndRemoveUntil(context, '/shopper', (_) => false);
          break;
        case 'merchant':
          Navigator.pushNamedAndRemoveUntil(context, '/merchant', (_) => false);
          break;
        case 'inactive':
          Navigator.pushReplacementNamed(context, '/pending_approval');
          break;
        case 'blocked':
          ErrorUI.showSnack(
            context,
            AppError(
              title: t.t('account_blocked'),
              message: auth.blockedReason ?? t.t('account_blocked_msg'),
              icon: Icons.block_outlined,
            ),
          );
          break;
        case 'error':
        default:
          final raw = auth.lastError;
          ErrorUI.showSnack(
            context,
            raw != null
                ? AppError.from(raw)
                : AppError(
                    title: t.t('login_failed'),
                    message: t.t('login_failed_msg'),
                    icon: Icons.key_off_outlined,
                  ),
          );
      }
    } catch (e) {
      if (!mounted) return;
      ErrorUI.showSnack(context, AppError.from(e));
    } finally {
      if (mounted) setState(() => isLoading = false);
    }
  }

  // ============================================================
  // PASSWORD RESET
  // ============================================================
  void _showPasswordResetDialog() {
    final resetController = TextEditingController();
    String? error;
    bool sending = false;

    showDialog(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (dialogContext, setDialogState) {
          Future<void> send() async {
            final t = S.of(context);
            final email = resetController.text.trim();
            if (email.isEmpty ||
                !RegExp(r'^[\w\.\-\+]+@[\w\-]+\.[\w\.\-]+$').hasMatch(email)) {
              setDialogState(() => error = t.t('enter_valid_email'));
              return;
            }
            setDialogState(() {
              sending = true;
              error = null;
            });
            try {
              final ok = await context
                  .read<AuthProvider>()
                  .sendPasswordReset(email);
              if (!mounted) return;
              if (dialogContext.mounted) Navigator.pop(dialogContext);
              if (ok) {
                ErrorUI.showSnack(
                  context,
                  AppError(
                    title: t.t('email_sent'),
                    message: t.t('email_sent_body'),
                    icon: Icons.mark_email_read_outlined,
                  ),
                );
              } else {
                ErrorUI.showSnack(
                  context,
                  AppError(
                    title: t.t('couldnt_send_email'),
                    message: t.t('check_address_try_again'),
                    icon: Icons.error_outline,
                  ),
                );
              }
            } catch (e) {
              if (!mounted) return;
              setDialogState(() => sending = false);
              ErrorUI.showSnack(context, AppError.from(e));
            }
          }

          final t = S.of(context);
          return AlertDialog(
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16)),
            title: Text(t.t('reset_password')),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  t.t('reset_hint'),
                  style: const TextStyle(
                      fontSize: 14, color: EfuridePalette.inkMuted),
                ),
                const SizedBox(height: 14),
                TextField(
                  controller: resetController,
                  keyboardType: TextInputType.emailAddress,
                  autofillHints: const [AutofillHints.email],
                  decoration: InputDecoration(
                    labelText: t.t('email_address'),
                    border: const OutlineInputBorder(),
                    errorText: error,
                  ),
                ),
              ],
            ),
            actions: [
              TextButton(
                onPressed: sending
                    ? null
                    : () => Navigator.pop(dialogContext),
                child: Text(t.t('cancel')),
              ),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: _accent,
                  foregroundColor: _buttonInk,
                ),
                onPressed: sending ? null : send,
                child: sending
                    ? SizedBox(
                        width: 16,
                        height: 16,
                        child: CircularProgressIndicator(
                            strokeWidth: 2, color: _buttonInk),
                      )
                    : Text(t.t('send_link')),
              ),
            ],
          );
        },
      ),
    );
  }

  // ============================================================
  // BUILD
  // ============================================================
  @override
  Widget build(BuildContext context) {
    final t = S.of(context);
    final title = isSignUp
        ? _getSignUpTitle(t)
        : t.t('welcome_back');
    final subtitle = isSignUp
        ? _getSignUpSubtitle(t)
        : '${t.t('signin_role_sub')} ${_getRoleLabel(t)}';

    return Scaffold(
      backgroundColor: EfuridePalette.cream,
      body: Column(
        children: [
          _header(t, title, subtitle),
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.fromLTRB(24, 20, 24, 24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  // Signup-only name/gender/phone fields
                  if (_usesPersonalSignup) ...[
                    _countryField(t),
                    const SizedBox(height: 14),
                    _inputField(
                      controller: _firstNameController,
                      label: _isMerchant ? t.t('owner_first_name') : t.t('first_name'),
                      hint: 'Jean',
                      icon: Icons.person_outline,
                      capitalization: TextCapitalization.words,
                      autofillHints: const [AutofillHints.givenName],
                      errorText: _firstNameError,
                      inputAction: TextInputAction.next,
                    ),
                    const SizedBox(height: 14),
                    _inputField(
                      controller: _surnameController,
                      label: _isMerchant ? t.t('owner_surname') : t.t('surname'),
                      hint: 'Doe',
                      icon: Icons.person_outline,
                      capitalization: TextCapitalization.words,
                      autofillHints: const [AutofillHints.familyName],
                      errorText: _surnameError,
                      inputAction: TextInputAction.next,
                    ),
                    if (_showsGender) ...[
                      const SizedBox(height: 14),
                      _genderDropdown(t),
                    ],
                    const SizedBox(height: 14),
                    _inputField(
                      controller: _phoneController,
                      label: t.t('phone_number'),
                      hint: _country == null
                          ? '+27 82 123 4567'
                          : '${_country!.phonePrefix} …',
                      icon: Icons.phone_outlined,
                      keyboardType: TextInputType.phone,
                      autofillHints: const [AutofillHints.telephoneNumber],
                      errorText: _phoneError,
                      inputAction: TextInputAction.next,
                      formatters: [
                        FilteringTextInputFormatter.allow(
                            RegExp(r'[\d\s\+\-\(\)]')),
                      ],
                    ),
                    const SizedBox(height: 14),
                  ],

                  // Email
                  _inputField(
                    controller: _emailController,
                    focusNode: _emailFocus,
                    label: t.t('email_address'),
                    hint: 'you@example.com',
                    icon: Icons.email_outlined,
                    keyboardType: TextInputType.emailAddress,
                    autofillHints: const [AutofillHints.email],
                    errorText: _emailError,
                    inputAction: TextInputAction.next,
                    onSubmitted: (_) => _passwordFocus.requestFocus(),
                  ),
                  const SizedBox(height: 14),

                  // Password
                  _inputField(
                    controller: _passwordController,
                    focusNode: _passwordFocus,
                    label: t.t('password'),
                    hint: '••••••••',
                    icon: Icons.lock_outline,
                    obscureText: _obscurePassword,
                    autofillHints: isSignUp
                        ? const [AutofillHints.newPassword]
                        : const [AutofillHints.password],
                    errorText: _passwordError,
                    inputAction: isSignUp ? TextInputAction.next : TextInputAction.done,
                    onSubmitted: (_) {
                      if (isSignUp) {
                        _confirmPasswordFocus.requestFocus();
                      } else {
                        _authenticate();
                      }
                    },
                    trailing: IconButton(
                      icon: Icon(
                        _obscurePassword
                            ? Icons.visibility_outlined
                            : Icons.visibility_off_outlined,
                        size: 20,
                        color: EfuridePalette.inkMuted,
                      ),
                      onPressed: () => setState(
                          () => _obscurePassword = !_obscurePassword),
                    ),
                  ),
                  
                  // Confirm Password (Sign Up Only)
                  if (isSignUp) ...[
                    const SizedBox(height: 14),
                    _inputField(
                      controller: _confirmPasswordController,
                      focusNode: _confirmPasswordFocus,
                      label: tr('Confirm Password'), // Or use t.t('confirm_password') if you add it
                      hint: '••••••••',
                      icon: Icons.lock_outline,
                      obscureText: _obscureConfirmPassword,
                      autofillHints: const [AutofillHints.newPassword],
                      errorText: _confirmPasswordError,
                      inputAction: TextInputAction.done,
                      onSubmitted: (_) => _authenticate(),
                      trailing: IconButton(
                        icon: Icon(
                          _obscureConfirmPassword
                              ? Icons.visibility_outlined
                              : Icons.visibility_off_outlined,
                          size: 20,
                          color: EfuridePalette.inkMuted,
                        ),
                        onPressed: () => setState(
                            () => _obscureConfirmPassword = !_obscureConfirmPassword),
                      ),
                    ),
                  ],
                  
                  const SizedBox(height: 20),

                  // Submit
                  isLoading
                      ? const Center(
                          child: Padding(
                            padding: EdgeInsets.all(12),
                            child: SizedBox(
                              width: 24,
                              height: 24,
                              child: CircularProgressIndicator(
                                strokeWidth: 2.5,
                                color: EfuridePalette.accent,
                              ),
                            ),
                          ),
                        )
                      : ElevatedButton(
                          onPressed: _authenticate,
                          style: ElevatedButton.styleFrom(
                            backgroundColor: _accent,
                            foregroundColor: _buttonInk,
                            minimumSize: const Size(double.infinity, 54),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(14),
                            ),
                            elevation: 0,
                          ),
                          child: Text(
                            isSignUp
                                ? '${t.t('create_account')} ${_getRoleLabel(t)}'
                                : t.t('sign_in'),
                            style: const TextStyle(
                              fontSize: 15,
                              fontWeight: FontWeight.w900,
                            ),
                          ),
                        ),

                  if (!isSignUp)
                    Align(
                      alignment: Alignment.center,
                      child: TextButton(
                        onPressed: _showPasswordResetDialog,
                        child: Text(
                          t.t('forgot_password'),
                          style: TextStyle(
                            color: _accent,
                            fontSize: 14,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ),
                    ),

                  const SizedBox(height: 4),

                  // Toggle sign in / sign up
                  Center(
                    child: TextButton(
                      onPressed: () => setState(() {
                        isSignUp = !isSignUp;
                        // Clear errors when switching modes
                        _firstNameError = null;
                        _surnameError = null;
                        _phoneError = null;
                        _confirmPasswordError = null;
                        _confirmPasswordController.clear(); // Clear confirm field
                      }),
                      child: Text(
                        isSignUp
                            ? t.t('already_have_account_q')
                            : t.t('dont_have_account'),
                        style: const TextStyle(
                          color: EfuridePalette.inkMuted,
                          fontSize: 14,
                        ),
                      ),
                    ),
                  ),

                  // Role swap hint (signin only)
                  if (!isSignUp) ...[
                    const SizedBox(height: 16),
                    const Divider(color: EfuridePalette.divider),
                    const SizedBox(height: 12),
                    _roleSwapHint(t),
                  ],
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  String _getRoleLabel(S t) {
    switch (_role) {
      case 'driver': return t.t('role_driver');
      case 'shopper': return t.t('role_shopper');
      case 'merchant': return t.t('role_merchant');
      case 'customer':
      default: return t.t('role_customer');
    }
  }

  String _getSignUpTitle(S t) {
    switch (_role) {
      case 'driver': return t.t('create_driver_account');
      case 'shopper': return t.t('create_shopper_account');
      case 'merchant': return t.t('create_merchant_account');
      case 'customer':
      default: return t.t('create_your_account');
    }
  }

  String _getSignUpSubtitle(S t) {
    switch (_role) {
      case 'driver': return t.t('signup_driver_sub');
      case 'shopper': return t.t('signup_shopper_sub');
      case 'merchant': return t.t('signup_merchant_sub');
      case 'customer':
      default: return t.t('signup_customer_sub');
    }
  }

  // ============================================================
  // HEADER
  // ============================================================
  Widget _header(S t, String title, String subtitle) {
    return Container(
      decoration: const BoxDecoration(
        color: EfuridePalette.cream,
      ),
      child: SafeArea(
        bottom: false,
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(8, 8, 16, 12),
              child: Row(
                children: [
                  IconButton(
                    onPressed: () => Navigator.pop(context),
                    icon: const Icon(Icons.arrow_back,
                        color: EfuridePalette.ink),
                  ),
                  const SizedBox(width: 4),
                  Container(
                    width: 36,
                    height: 36,
                    decoration: const BoxDecoration(
                      color: Colors.white,
                      shape: BoxShape.circle,
                    ),
                    child: Center(
                      child: Icon(_roleIcon, color: _accent, size: 20),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(tr('KO!NGO'),
                          style: TextStyle(
                            color: EfuridePalette.ink,
                            fontSize: 16,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 1.2,
                            height: 1.05,
                          )),
                      SizedBox(height: 2),
                      Text(tr('Account'),
                          style: TextStyle(
                            color: EfuridePalette.inkMuted,
                            fontSize: 13,
                            fontWeight: FontWeight.w500,
                          )),
                    ],
                  ),
                  const Spacer(),
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 10, vertical: 5),
                    decoration: BoxDecoration(
                      color: _accent,
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Text(
                      _getRoleLabel(t),
                      style: TextStyle(
                        color: _buttonInk,
                        fontSize: 13,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 0.5,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.fromLTRB(24, 20, 24, 22),
              decoration: const BoxDecoration(
                color: EfuridePalette.cream,
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(24),
                  topRight: Radius.circular(24),
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: const TextStyle(
                      color: EfuridePalette.ink,
                      fontSize: 22,
                      fontWeight: FontWeight.w900,
                      letterSpacing: -0.3,
                      height: 1.15,
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    subtitle,
                    style: const TextStyle(
                      color: EfuridePalette.inkMuted,
                      fontSize: 14,
                      height: 1.4,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ============================================================
  // INPUT FIELD
  // ============================================================
  Widget _inputField({
    required TextEditingController controller,
    FocusNode? focusNode,
    required String label,
    required String hint,
    required IconData icon,
    TextInputType? keyboardType,
    TextCapitalization capitalization = TextCapitalization.none,
    List<String>? autofillHints,
    List<TextInputFormatter>? formatters,
    bool obscureText = false,
    Widget? trailing,
    String? errorText,
    TextInputAction? inputAction,
    ValueChanged<String>? onSubmitted,
  }) {
    return TextField(
      controller: controller,
      focusNode: focusNode,
      keyboardType: keyboardType,
      textCapitalization: capitalization,
      autofillHints: autofillHints,
      inputFormatters: formatters,
      obscureText: obscureText,
      textInputAction: inputAction,
      onSubmitted: onSubmitted,
      style: const TextStyle(
        fontSize: 14.5,
        fontWeight: FontWeight.w600,
        color: EfuridePalette.ink,
      ),
      decoration: InputDecoration(
        labelText: label,
        hintText: hint,
        hintStyle: const TextStyle(
          fontSize: 14.5,
          fontWeight: FontWeight.w400,
          color: EfuridePalette.inkMuted,
        ),
        labelStyle: const TextStyle(
          fontSize: 14,
          fontWeight: FontWeight.w600,
          color: EfuridePalette.inkMuted,
        ),
        prefixIcon:
            Icon(icon, size: 20, color: EfuridePalette.inkMuted),
        suffixIcon: trailing,
        filled: true,
        fillColor: EfuridePalette.cream,
        contentPadding:
            const EdgeInsets.symmetric(horizontal: 14, vertical: 16),
        errorText: errorText,
        errorStyle: const TextStyle(
            fontSize: 13, color: EfuridePalette.dropoff),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide.none,
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide.none,
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide(color: _accent, width: 1.6),
        ),
        errorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(
              color: EfuridePalette.dropoff, width: 1.4),
        ),
        focusedErrorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(
              color: EfuridePalette.dropoff, width: 1.6),
        ),
      ),
    );
  }

  // ============================================================
  // GENDER DROPDOWN
  // ============================================================
  Widget _genderDropdown(S t) {
    return DropdownButtonFormField<String>(
      value: selectedGender,
      decoration: InputDecoration(
        labelText: t.t('gender'),
        labelStyle: const TextStyle(
          fontSize: 14,
          fontWeight: FontWeight.w600,
          color: EfuridePalette.inkMuted,
        ),
        prefixIcon: const Icon(Icons.wc_outlined,
            size: 20, color: EfuridePalette.inkMuted),
        filled: true,
        fillColor: EfuridePalette.cream,
        contentPadding:
            const EdgeInsets.symmetric(horizontal: 14, vertical: 16),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide.none,
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide.none,
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide(color: _accent, width: 1.6),
        ),
      ),
      items: [t.t('gender_male'), t.t('gender_female'), t.t('gender_other')]
          .map((g) => DropdownMenuItem(value: g, child: Text(g)))
          .toList(),
      onChanged: (value) =>
          setState(() => selectedGender = value ?? 'Male'),
    );
  }

  // ============================================================
  // ROLE SWAP HINT
  // ============================================================
  Widget _roleSwapHint(S t) {
    // Determine the alternate role based on current role
    String? targetRole;
    String? targetLabel;
    Color? targetColor;
    String? promptText;

    if (_isCustomer) {
      targetRole = 'driver';
      targetLabel = t.t('role_driver');
      targetColor = EfuridePalette.online;
      promptText = t.t('want_to_drive');
    } else if (_isDriver) {
      targetRole = 'customer';
      targetLabel = t.t('role_customer');
      targetColor = EfuridePalette.accent;
      promptText = 'Want to book a ride?'; 
    } else if (_isShopper) {
      targetRole = 'customer';
      targetLabel = t.t('role_customer');
      targetColor = EfuridePalette.accent;
      promptText = 'Want to book instead?'; 
    } else if (_isMerchant) {
      targetRole = 'customer';
      targetLabel = t.t('role_customer');
      targetColor = EfuridePalette.accent;
      promptText = 'Want to book instead?';
    }

    // If we found a direct alternate role, show the swap link
    if (targetRole != null && targetLabel != null && targetColor != null) {
      return Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            promptText ?? '',
            style: const TextStyle(fontSize: 14, color: EfuridePalette.inkMuted),
          ),
          GestureDetector(
            onTap: () => Navigator.pushReplacementNamed(
              context,
              '/auth',
              arguments: {'role': targetRole, 'mode': 'signin'},
            ),
            child: Text(
              targetLabel,
              style: TextStyle(
                fontSize: 14,
                color: targetColor,
                fontWeight: FontWeight.w800,
              ),
            ),
          ),
        ],
      );
    }

    // Fallback for any other case
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Text(
          t.t('wrong_portal'),
          style: const TextStyle(fontSize: 14, color: EfuridePalette.inkMuted),
        ),
        GestureDetector(
          onTap: () => Navigator.pushReplacementNamed(context, '/role_select'),
          child: Text(
            t.t('choose_another_role'),
            style: const TextStyle(
              fontSize: 14,
              color: EfuridePalette.blueDeep,
              fontWeight: FontWeight.w800,
            ),
          ),
        ),
      ],
    );
  }
}
