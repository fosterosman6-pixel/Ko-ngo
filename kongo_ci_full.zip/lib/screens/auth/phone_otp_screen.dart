// lib/screens/auth/phone_otp_screen.dart

import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:efuride_app/config/efuride_palette.dart';

class PhoneOtpScreen extends StatefulWidget {
  final String? initialPhone;
  final String role; // 'customer' | 'driver' | 'shopper' | 'merchant'

  const PhoneOtpScreen({
    super.key,
    this.initialPhone,
    this.role = 'customer',
  });

  @override
  State<PhoneOtpScreen> createState() => _PhoneOtpScreenState();
}

class _PhoneOtpScreenState extends State<PhoneOtpScreen> {
  final _phoneCtrl = TextEditingController();
  final List<TextEditingController> _otpCtrls =
      List.generate(6, (_) => TextEditingController());
  final List<FocusNode> _otpNodes =
      List.generate(6, (_) => FocusNode());

  int _step = 0; // 0 = phone entry, 1 = OTP
  bool _sending = false;
  bool _verifying = false;
  int _resendSeconds = 0;
  Timer? _resendTimer;
  String? _error;

  @override
  void initState() {
    super.initState();
    if (widget.initialPhone != null && widget.initialPhone!.isNotEmpty) {
      _phoneCtrl.text = widget.initialPhone!;
    }
    _phoneCtrl.addListener(() => setState(() {}));
    for (var i = 0; i < _otpCtrls.length; i++) {
      _otpCtrls[i].addListener(() => setState(() {}));
    }
  }

  @override
  void dispose() {
    _phoneCtrl.dispose();
    for (final c in _otpCtrls) {
      c.dispose();
    }
    for (final n in _otpNodes) {
      n.dispose();
    }
    _resendTimer?.cancel();
    super.dispose();
  }

  String get _otpValue =>
      _otpCtrls.map((c) => c.text).join();

  // ── Send OTP ──
  Future<void> _sendOtp() async {
    final phone = _phoneCtrl.text.trim();
    if (phone.length < 9) {
      setState(() => _error = 'Enter a valid phone number');
      return;
    }

    setState(() {
      _sending = true;
      _error = null;
    });

    // In production: Supabase.instance.client.auth.signInWithOtp(phone: phone)
    await Future.delayed(const Duration(milliseconds: 800));

    if (!mounted) return;
    setState(() {
      _sending = false;
      _step = 1;
    });
    _startResendTimer();
    _focusOtp(0);
  }

  void _startResendTimer() {
    _resendSeconds = 30;
    _resendTimer?.cancel();
    _resendTimer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (!mounted) return;
      setState(() {
        _resendSeconds--;
        if (_resendSeconds <= 0) t.cancel();
      });
    });
  }

  // ── Verify ──
  Future<void> _verify() async {
    final code = _otpValue;
    if (code.length != 6) {
      setState(() => _error = 'Enter the 6-digit code');
      return;
    }

    setState(() {
      _verifying = true;
      _error = null;
    });

    // In production: Supabase.instance.client.auth.verifyOTP(...)
    await Future.delayed(const Duration(milliseconds: 900));

    if (!mounted) return;

    // Mock: any 6-digit code works except '000000'.
    if (code == '000000') {
      setState(() {
        _verifying = false;
        _error = 'Incorrect code. Please try again.';
      });
      HapticFeedback.vibrate();
      for (var i = 0; i < _otpCtrls.length; i++) {
        _otpCtrls[i].clear();
      }
      _focusOtp(0);
      return;
    }

    setState(() => _verifying = false);

    // Route based on role.
    String destination;
    switch (widget.role.toLowerCase()) {
      case 'driver':
        destination = '/driver';
        break;
      case 'shopper':
        destination = '/shopper';
        break;
      case 'merchant':
        destination = '/merchant';
        break;
      case 'customer':
      default:
        destination = '/customer';
    }
    Navigator.pushNamedAndRemoveUntil(
        context, destination, (_) => false);
  }

  void _resend() {
    if (_resendSeconds > 0) return;
    for (final c in _otpCtrls) {
      c.clear();
    }
    _startResendTimer();
    _focusOtp(0);
    _snack('Code resent');
  }

  void _focusOtp(int index) {
    if (index < 0 || index >= _otpNodes.length) return;
    _otpNodes[index].requestFocus();
  }

  void _onOtpChanged(int index, String value) {
    if (value.length == 1 && index < 5) {
      _focusOtp(index + 1);
    } else if (value.isEmpty && index > 0) {
      _focusOtp(index - 1);
    }
    setState(() => _error = null);

    // Auto-submit when all 6 filled.
    if (index == 5 && _otpValue.length == 6) {
      Future.delayed(const Duration(milliseconds: 100), () {
        if (mounted) _verify();
      });
    }
  }

  void _snack(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(msg),
        behavior: SnackBarBehavior.floating,
        backgroundColor: EfuridePalette.ink,
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10)),
      ),
    );
  }

  Color get _accent {
    switch (widget.role.toLowerCase()) {
      case 'driver':
        return EfuridePalette.blueDeep;
      case 'shopper':
        return EfuridePalette.shopperAccent;
      case 'merchant':
        return EfuridePalette.merchantAccent;
      case 'customer':
      default:
        return EfuridePalette.accent;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Column(
        children: [
          _header(),
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: _step == 0
                  ? _buildPhoneStep()
                  : _buildOtpStep(),
            ),
          ),
        ],
      ),
    );
  }

  // ── Header ──
  Widget _header() {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          colors: [EfuridePalette.blue, EfuridePalette.blueDeep],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
      ),
      child: SafeArea(
        bottom: false,
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(8, 8, 16, 12),
              child: Row(
                children: [
                  if (_step == 1)
                    IconButton(
                      onPressed: () => setState(() {
                        _step = 0;
                        _error = null;
                      }),
                      icon: const Icon(Icons.arrow_back,
                          color: Colors.white),
                    )
                  else
                    const SizedBox(width: 48),
                  const Spacer(),
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 10, vertical: 5),
                    decoration: BoxDecoration(
                      color: Colors.white.withValues(alpha: 0.20),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Text(
                      widget.role[0].toUpperCase() +
                          widget.role.substring(1),
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 11,
                        fontWeight: FontWeight.w800,
                        letterSpacing: 0.5,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.fromLTRB(24, 20, 24, 24),
              decoration: const BoxDecoration(
                color: EfuridePalette.navy,
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(24),
                  topRight: Radius.circular(24),
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    width: 44,
                    height: 44,
                    decoration: BoxDecoration(
                      color: _accent,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Icon(
                      _step == 0
                          ? Icons.phone_iphone
                          : Icons.sms_outlined,
                      color: Colors.white,
                      size: 22,
                    ),
                  ),
                  const SizedBox(height: 14),
                  Text(
                    _step == 0
                        ? 'Enter your phone'
                        : 'Verify your number',
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 22,
                      fontWeight: FontWeight.w900,
                      letterSpacing: -0.3,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    _step == 0
                        ? 'We\'ll send you a 6-digit code via SMS'
                        : 'We sent a code to ${_maskPhone(_phoneCtrl.text)}',
                    style: const TextStyle(
                        color: Colors.white70, fontSize: 13),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  String _maskPhone(String phone) {
    if (phone.length < 6) return phone;
    final last4 = phone.substring(phone.length - 4);
    return '••• $last4';
  }

  // ============================================================
  // STEP 1 — PHONE ENTRY
  // ============================================================
  Widget _buildPhoneStep() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        const Text('Phone number',
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w800,
              color: EfuridePalette.inkMuted,
              letterSpacing: 0.4,
            )),
        const SizedBox(height: 8),
        Row(
          children: [
            Container(
              padding: const EdgeInsets.symmetric(
                  horizontal: 12, vertical: 16),
              decoration: BoxDecoration(
                color: EfuridePalette.cream,
                borderRadius: BorderRadius.circular(14),
              ),
              child: const Row(
                children: [
                  Text('🇨🇬',
                      style: TextStyle(fontSize: 18)),
                  SizedBox(width: 6),
                  Text('+242',
                      style: TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w800,
                        color: EfuridePalette.ink,
                      )),
                ],
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: TextField(
                controller: _phoneCtrl,
                keyboardType: TextInputType.phone,
                inputFormatters: [
                  FilteringTextInputFormatter.allow(
                      RegExp(r'[0-9\s]')),
                  LengthLimitingTextInputFormatter(15),
                ],
                style: const TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.w800,
                  letterSpacing: 0.5,
                ),
                decoration: InputDecoration(
                  hintText: '06 123 4567',
                  hintStyle: const TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.w500,
                    color: EfuridePalette.inkMuted,
                  ),
                  filled: true,
                  fillColor: EfuridePalette.cream,
                  contentPadding: const EdgeInsets.symmetric(
                      horizontal: 14, vertical: 16),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(14),
                    borderSide: BorderSide.none,
                  ),
                ),
              ),
            ),
          ],
        ),

        if (_error != null) ...[
          const SizedBox(height: 10),
          Row(
            children: [
              const Icon(Icons.error_outline,
                  color: EfuridePalette.dropoff, size: 16),
              const SizedBox(width: 8),
              Expanded(
                child: Text(_error!,
                    style: const TextStyle(
                        fontSize: 12,
                        color: EfuridePalette.dropoff,
                        fontWeight: FontWeight.w600)),
              ),
            ],
          ),
        ],

        const SizedBox(height: 16),

        // Info box
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: EfuridePalette.blueDeep.withValues(alpha: 0.08),
            borderRadius: BorderRadius.circular(12),
          ),
          child: const Row(
            children: [
              Icon(Icons.info_outline,
                  color: EfuridePalette.blueDeep, size: 16),
              SizedBox(width: 10),
              Expanded(
                child: Text(
                  'Standard SMS rates may apply. We\'ll never share your number.',
                  style: TextStyle(
                    fontSize: 11.5,
                    color: EfuridePalette.ink,
                    height: 1.4,
                  ),
                ),
              ),
            ],
          ),
        ),

        const SizedBox(height: 24),

        ElevatedButton(
          onPressed: _sending ? null : _sendOtp,
          style: ElevatedButton.styleFrom(
            backgroundColor: _accent,
            foregroundColor:
                widget.role == 'driver' || widget.role == 'customer'
                    ? (widget.role == 'driver'
                        ? Colors.white
                        : EfuridePalette.accentInk)
                    : Colors.white,
            minimumSize: const Size(double.infinity, 54),
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(14)),
            elevation: 0,
          ),
          child: _sending
              ? const SizedBox(
                  width: 20,
                  height: 20,
                  child: CircularProgressIndicator(
                      strokeWidth: 2, color: Colors.white),
                )
              : const Text('Send code',
                  style: TextStyle(
                      fontSize: 15, fontWeight: FontWeight.w900)),
        ),

        const SizedBox(height: 20),

        // Terms
        const Text(
          'By continuing, you agree to our Terms of Service and Privacy Policy.',
          textAlign: TextAlign.center,
          style: TextStyle(
              fontSize: 11,
              color: EfuridePalette.inkMuted,
              height: 1.5),
        ),
      ],
    );
  }

  // ============================================================
  // STEP 2 — OTP ENTRY
  // ============================================================
  Widget _buildOtpStep() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        const Text('6-digit code',
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w800,
              color: EfuridePalette.inkMuted,
              letterSpacing: 0.4,
            )),
        const SizedBox(height: 12),

        // OTP boxes
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: List.generate(6, (i) => _otpBox(i)),
        ),

        if (_error != null) ...[
          const SizedBox(height: 14),
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: EfuridePalette.dropoff.withValues(alpha: 0.08),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(
                  color:
                      EfuridePalette.dropoff.withValues(alpha: 0.35)),
            ),
            child: Row(
              children: [
                const Icon(Icons.error_outline,
                    color: EfuridePalette.dropoff, size: 16),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(_error!,
                      style: const TextStyle(
                          fontSize: 12,
                          color: EfuridePalette.dropoff,
                          fontWeight: FontWeight.w600)),
                ),
              ],
            ),
          ),
        ],

        const SizedBox(height: 24),

        // Resend
        Center(
          child: _resendSeconds > 0
              ? Text(
                  'Resend code in ${_resendSeconds}s',
                  style: const TextStyle(
                    fontSize: 13,
                    color: EfuridePalette.inkMuted,
                    fontWeight: FontWeight.w600,
                  ),
                )
              : TextButton(
                  onPressed: _resend,
                  child: Text(
                    'Resend code',
                    style: TextStyle(
                      color: _accent,
                      fontSize: 13.5,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ),
        ),

        const SizedBox(height: 20),

        ElevatedButton(
          onPressed: _verifying ? null : _verify,
          style: ElevatedButton.styleFrom(
            backgroundColor: _accent,
            foregroundColor:
                widget.role == 'customer'
                    ? EfuridePalette.accentInk
                    : Colors.white,
            minimumSize: const Size(double.infinity, 54),
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(14)),
            elevation: 0,
          ),
          child: _verifying
              ? const SizedBox(
                  width: 20,
                  height: 20,
                  child: CircularProgressIndicator(
                      strokeWidth: 2, color: Colors.white),
                )
              : const Text('Verify & continue',
                  style: TextStyle(
                      fontSize: 15, fontWeight: FontWeight.w900)),
        ),

        const SizedBox(height: 20),

        // Help
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: EfuridePalette.cream,
            borderRadius: BorderRadius.circular(12),
          ),
          child: Row(
            children: [
              const Icon(Icons.help_outline,
                  size: 16, color: EfuridePalette.inkMuted),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  'Didn\'t get the code? Check that your number is correct, '
                  'or contact support@efuride.com',
                  style: TextStyle(
                    fontSize: 11.5,
                    color: EfuridePalette.inkMuted.withValues(alpha: 0.9),
                    height: 1.45,
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _otpBox(int i) {
    final filled = _otpCtrls[i].text.isNotEmpty;
    return SizedBox(
      width: 46,
      child: TextField(
        controller: _otpCtrls[i],
        focusNode: _otpNodes[i],
        autofocus: i == 0,
        keyboardType: TextInputType.number,
        textAlign: TextAlign.center,
        maxLength: 1,
        inputFormatters: [FilteringTextInputFormatter.digitsOnly],
        style: TextStyle(
          fontSize: 22,
          fontWeight: FontWeight.w900,
          color: filled ? _accent : EfuridePalette.ink,
        ),
        decoration: InputDecoration(
          counterText: '',
          filled: true,
          fillColor: filled
              ? _accent.withValues(alpha: 0.10)
              : EfuridePalette.cream,
          contentPadding: const EdgeInsets.symmetric(vertical: 14),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(
              color: filled ? _accent : Colors.transparent,
              width: 1.6,
            ),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(
              color: filled ? _accent : Colors.transparent,
              width: 1.6,
            ),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(color: _accent, width: 1.8),
          ),
        ),
        onChanged: (v) => _onOtpChanged(i, v),
      ),
    );
  }
}
