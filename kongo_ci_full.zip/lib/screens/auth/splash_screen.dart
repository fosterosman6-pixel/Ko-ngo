﻿// lib/screens/auth/splash_screen.dart
//
// Branded splash + role-aware routing.
// Uses AuthProvider.checkSession() for the routing decision.

import 'dart:async';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:efuride_app/config/app_images.dart';
import 'package:efuride_app/config/efuride_palette.dart';
import 'package:efuride_app/providers/auth_provider.dart';
import 'package:efuride_app/widgets/app_image.dart';
import 'package:efuride_app/l10n/app_strings.dart';
import 'package:efuride_app/widgets/k_icon.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with SingleTickerProviderStateMixin {
  static const _minVisible = Duration(milliseconds: 2200);

  late final AnimationController _progress;

  @override
  void initState() {
    super.initState();
    _progress = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1800),
    )..repeat();
    _bootstrap();
  }

  @override
  void dispose() {
    _progress.dispose();
    super.dispose();
  }

  // ============================================================
  // BOOTSTRAP
  // ============================================================
  Future<void> _bootstrap() async {
    final startedAt = DateTime.now();

    // Give the AuthProvider a moment to restore session state.
    await Future.delayed(const Duration(milliseconds: 400));

    String route = '/role_select';
    try {
      final auth = context.read<AuthProvider>();
      final result = await auth.checkSession();

      switch (result) {
        case 'customer':
          route = '/customer';
          break;
        case 'driver':
          route = '/driver';
          break;
        case 'shopper':
          route = '/shopper';
          break;
        case 'merchant':
          route = '/merchant';
          break;
        case 'inactive':
          route = '/pending_approval';
          break;
        case 'blocked':
        case 'none':
        default:
          route = '/role_select';
      }
    } catch (e) {
      debugPrint('splash checkSession failed: $e');
      route = '/role_select';
    }

    // Enforce minimum splash duration for branding.
    final elapsed = DateTime.now().difference(startedAt);
    if (elapsed < _minVisible) {
      await Future.delayed(_minVisible - elapsed);
    }

    if (!mounted) return;
    Navigator.pushNamedAndRemoveUntil(context, route, (_) => false);
  }

  // ============================================================
  // BUILD
  // ============================================================
  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      child: Scaffold(
        backgroundColor: EfuridePalette.cream,
        body: Stack(
          children: [
            // Warm skyline backdrop
            Positioned(
              left: 0,
              right: 0,
              bottom: 0,
              height: 280,
              child: Container(
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      Color(0xFFFAF6EE),
                      Color(0xFFF5E6BF),
                    ],
                  ),
                ),
              ),
            ),

            SafeArea(
              child: Column(
                children: [
                  const Spacer(flex: 3),

                  // Gold brand mark
                  Container(
                    width: 96,
                    height: 96,
                    decoration: const BoxDecoration(
                      color: EfuridePalette.accent,
                      shape: BoxShape.circle,
                      boxShadow: [
                        BoxShadow(
                          color: Color(0x44F2B705),
                          blurRadius: 24,
                          spreadRadius: 2,
                        ),
                      ],
                    ),
                    // ko!ngo leopard inside a gold ring.
                    padding: const EdgeInsets.all(4),
                    child: ClipOval(
                      child: Image.asset(
                        AppImages.leopardLogo,
                        fit: BoxFit.cover,
                        errorBuilder: (_, __, ___) => const Center(
                          child: KIcon(
                            Icons.location_on,
                            color: Colors.white,
                            size: 46,
                          ),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 22),

                  RichText(
                    text: const TextSpan(
                      style: TextStyle(
                        fontSize: 34,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 4,
                        color: EfuridePalette.ink,
                        height: 1.05,
                      ),
                      children: [
                        TextSpan(text: 'KO'),
                        TextSpan(
                          text: '!',
                          style: TextStyle(color: EfuridePalette.accent),
                        ),
                        TextSpan(text: 'NGO'),
                      ],
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    tr('Ride  •  Deliver  •  Move'),
                    style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w600,
                      letterSpacing: 1.4,
                      color: EfuridePalette.inkMuted,
                    ),
                  ),

                  const Spacer(flex: 2),

                  // Vehicle illustration.
                  // NOTE: AppImage takes `size`, not `height`.
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 24),
                    child: AppImage(
                      AppImages.driverSedan,
                      size: 120,
                      fit: BoxFit.contain,
                      fallbackIcon: Icons.directions_car,
                    ),
                  ),
                  const SizedBox(height: 30),

                  Text(
                    tr('Connecting you to a better journey'),
                    style: TextStyle(
                      fontSize: 14,
                      color: EfuridePalette.inkMuted,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  const SizedBox(height: 14),

                  // Animated progress
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 60),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(4),
                      child: Container(
                        height: 4,
                        color: EfuridePalette.divider,
                        child: AnimatedBuilder(
                          animation: _progress,
                          builder: (_, __) => FractionallySizedBox(
                            alignment: Alignment.centerLeft,
                            widthFactor: _progress.value,
                            child: Container(
                              color: EfuridePalette.accent,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 40),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
