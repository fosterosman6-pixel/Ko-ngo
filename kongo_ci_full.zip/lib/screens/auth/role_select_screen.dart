// lib/screens/auth/role_select_screen.dart

import 'package:flutter/material.dart';
import 'package:efuride_app/config/efuride_palette.dart';
import 'package:efuride_app/l10n/app_strings.dart';
import 'package:efuride_app/widgets/k_icon.dart';

class RoleSelectScreen extends StatelessWidget {
  const RoleSelectScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: EfuridePalette.cream,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(24, 24, 24, 16),
          child: Column(
            children: [
              const SizedBox(height: 8),

              // Gold logo
              Container(
                width: 84,
                height: 84,
                decoration: const BoxDecoration(
                  color: EfuridePalette.accent,
                  shape: BoxShape.circle,
                  boxShadow: [
                    BoxShadow(
                      color: Color(0x33F2B705),
                      blurRadius: 20,
                      spreadRadius: 1,
                    ),
                  ],
                ),
                child: const Center(
                  child: KIcon(Icons.location_on,
                      color: Colors.white, size: 40),
                ),
              ),
              const SizedBox(height: 14),

              Text(
                tr('KO!NGO'),
                style: TextStyle(
                  fontSize: 26,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 3,
                  color: EfuridePalette.ink,
                  height: 1.05,
                ),
              ),
              const SizedBox(height: 30),

              Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  tr('Choose your role'),
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.w800,
                    color: EfuridePalette.ink,
                  ),
                ),
              ),
              const SizedBox(height: 4),
              Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  tr('How would you like to use KO!NGO?'),
                  style: TextStyle(
                    fontSize: 14,
                    color: EfuridePalette.inkMuted,
                  ),
                ),
              ),
              const SizedBox(height: 20),

              // Primary two — Passenger + Driver
              _bigRoleCard(
                context,
                title: tr('Passenger'),
                subtitle: tr('Book a ride, order food,\ngroceries or send parcels.'),
                icon: Icons.person_pin_circle,
                color: EfuridePalette.accent,
                onTap: () => Navigator.pushNamed(
                  context,
                  '/auth',
                  arguments: {'role': 'customer'},
                ),
              ),
              const SizedBox(height: 14),

              _bigRoleCard(
                context,
                title: tr('Driver'),
                subtitle: tr('Earn money by driving\nor delivering.'),
                icon: Icons.directions_car_filled,
                color: EfuridePalette.online,
                onTap: () => Navigator.pushNamed(
                  context,
                  '/auth',
                  arguments: {'role': 'driver'},
                ),
              ),

              const SizedBox(height: 22),
              Row(
                children: [
                  const Expanded(
                      child: Divider(color: EfuridePalette.divider)),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 12),
                    child: Text(
                      tr('TEAM MEMBER SIGN-IN'),
                      style: TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w800,
                        letterSpacing: 1.2,
                        color: EfuridePalette.inkMuted,
                      ),
                    ),
                  ),
                  const Expanded(
                      child: Divider(color: EfuridePalette.divider)),
                ],
              ),
              const SizedBox(height: 14),

              // Compact two — Shopper + Merchant
              Row(
                children: [
                  Expanded(
                    child: _smallRoleCard(
                      context,
                      title: tr('Shopper'),
                      subtitle: tr('Shop & pick'),
                      icon: Icons.shopping_bag_rounded,
                      color: EfuridePalette.shopperAccent,
                      onTap: () => Navigator.pushNamed(
                        context,
                        '/auth',
                        arguments: {'role': 'shopper'},
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: _smallRoleCard(
                      context,
                      title: tr('Merchant'),
                      subtitle: tr('Manage store'),
                      icon: Icons.storefront,
                      color: EfuridePalette.merchantAccent,
                      onTap: () => Navigator.pushNamed(
                        context,
                        '/auth',
                        arguments: {'role': 'merchant'},
                      ),
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 24),

              // Already have an account
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    tr('Already have an account? '),
                    style: TextStyle(
                        fontSize: 14, color: EfuridePalette.inkMuted),
                  ),
                  GestureDetector(
                    onTap: () => Navigator.pushNamed(
                      context,
                      '/auth',
                      arguments: {
                        'role': 'customer',
                        'mode': 'signin',
                      },
                    ),
                    child: Text(
                      tr('Log in'),
                      style: TextStyle(
                        fontSize: 14,
                        color: EfuridePalette.accent,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 20),
              _termsText(),
              const SizedBox(height: 8),
            ],
          ),
        ),
      ),
    );
  }

  // ============================================================
  // BIG ROLE CARD — Passenger / Driver
  // ============================================================
  Widget _bigRoleCard(
    BuildContext context, {
    required String title,
    required String subtitle,
    required IconData icon,
    required Color color,
    required VoidCallback onTap,
  }) {
    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(18),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(18),
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(18),
            border: Border.all(
              color: color.withValues(alpha: 0.35),
              width: 1.4,
            ),
            boxShadow: [
              BoxShadow(
                color: color.withValues(alpha: 0.06),
                blurRadius: 10,
                offset: const Offset(0, 3),
              ),
            ],
          ),
          child: Row(
            children: [
              Container(
                width: 56,
                height: 56,
                decoration: BoxDecoration(
                  color: color.withValues(alpha: 0.15),
                  borderRadius: BorderRadius.circular(14),
                ),
                child: Icon(icon, color: color, size: 28),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title,
                        style: const TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w900,
                          color: EfuridePalette.ink,
                          letterSpacing: -0.2,
                        )),
                    const SizedBox(height: 4),
                    Text(subtitle,
                        style: const TextStyle(
                          fontSize: 14,
                          color: EfuridePalette.inkMuted,
                          height: 1.35,
                        )),
                  ],
                ),
              ),
              Icon(Icons.chevron_right, color: color, size: 22),
            ],
          ),
        ),
      ),
    );
  }

  // ============================================================
  // SMALL ROLE CARD — Shopper / Merchant
  // ============================================================
  Widget _smallRoleCard(
    BuildContext context, {
    required String title,
    required String subtitle,
    required IconData icon,
    required Color color,
    required VoidCallback onTap,
  }) {
    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(16),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(16),
        child: Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
              color: color.withValues(alpha: 0.30),
              width: 1.3,
            ),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(
                  color: color.withValues(alpha: 0.15),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(icon, color: color, size: 22),
              ),
              const SizedBox(height: 10),
              Text(title,
                  style: const TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w900,
                    color: EfuridePalette.ink,
                  )),
              const SizedBox(height: 2),
              Text(subtitle,
                  style: TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                    color: color,
                  )),
            ],
          ),
        ),
      ),
    );
  }

  // ============================================================
  // TERMS
  // ============================================================
  Widget _termsText() {
    return Wrap(
      alignment: WrapAlignment.center,
      children: [
        Text(
          tr('By continuing, you agree to our '),
          textAlign: TextAlign.center,
          style: TextStyle(fontSize: 13, color: EfuridePalette.inkMuted),
        ),
        _TappableTerms(label: tr('Terms'), route: '/terms'),
        Text(
          ' & ',
          style: TextStyle(fontSize: 13, color: EfuridePalette.inkMuted),
        ),
        _TappableTerms(label: tr('Privacy Policy'), route: '/privacy'),
      ],
    );
  }
}

class _TappableTerms extends StatelessWidget {
  final String label;
  final String route;

  const _TappableTerms({required this.label, required this.route});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => Navigator.pushNamed(context, route),
      child: Text(
        label,
        style: const TextStyle(
          fontSize: 13,
          color: EfuridePalette.accent,
          fontWeight: FontWeight.w800,
          decoration: TextDecoration.underline,
          decorationColor: EfuridePalette.accent,
        ),
      ),
    );
  }
}
