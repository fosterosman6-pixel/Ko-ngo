import 'package:efuride_app/config/efuride_palette.dart';
// lib/screens/customer/customer_account_screen.dart

import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:provider/provider.dart';
import 'package:efuride_app/providers/auth_provider.dart';
import 'package:efuride_app/config/app_images.dart';
import 'package:efuride_app/widgets/app_image.dart';
import 'package:efuride_app/utils/app_error.dart';
import 'package:efuride_app/utils/error_ui.dart';
import 'package:efuride_app/l10n/app_strings.dart';
import 'package:efuride_app/widgets/k_icon.dart';

class CustomerAccountScreen extends StatefulWidget {
  const CustomerAccountScreen({super.key});

  @override
  State<CustomerAccountScreen> createState() => _CustomerAccountScreenState();
}

class _CustomerAccountScreenState extends State<CustomerAccountScreen> {
  Map<String, dynamic>? _profile;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final userId = Supabase.instance.client.auth.currentUser?.id;
    if (userId == null) {
      if (mounted) setState(() => _loading = false);
      return;
    }
    try {
      final p = await Supabase.instance.client
          .from('profiles')
          .select(
              'first_name, surname, full_name, profile_picture_url, '
              'avatar_url, average_rating, total_ratings')
          .eq('id', userId)
          .maybeSingle();
      if (!mounted) return;
      setState(() {
        _profile = p;
        _loading = false;
      });
    } catch (_) {
      if (!mounted) return;
      setState(() => _loading = false);
    }
  }

  /// Driving / shopping / selling uses its own ko!ngo account (each
  /// account has one role). Explain that, and only sign out if the
  /// customer chooses to — before, this just dropped them on the start
  /// screen as if they had been logged out.
  Future<void> _earnWithKongo() async {
    final go = await showModalBottomSheet<bool>(
      context: context,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (ctx) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 18, 20, 16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text(tr('Earn with ko!ngo'),
                  style: const TextStyle(
                      fontSize: 21, fontWeight: FontWeight.w800)),
              const SizedBox(height: 10),
              Text(
                tr('Drivers, shoppers and store owners use a separate ko!ngo account, with a different email address. Your customer account stays as it is.'),
                style: const TextStyle(fontSize: 15.5, height: 1.4),
              ),
              const SizedBox(height: 8),
              Text(
                tr('To create it, you will be signed out of this account. You can sign back in any time.'),
                style: const TextStyle(
                    fontSize: 15, height: 1.4, color: Color(0xFF575047)),
              ),
              const SizedBox(height: 18),
              ElevatedButton(
                onPressed: () => Navigator.pop(ctx, true),
                style: ElevatedButton.styleFrom(
                  minimumSize: const Size(0, 52),
                  backgroundColor: const Color(0xFFF2B705),
                  foregroundColor: const Color(0xFF0B1220),
                ),
                child: Text(tr('Sign out and create partner account'),
                    style: const TextStyle(
                        fontSize: 16, fontWeight: FontWeight.w800)),
              ),
              const SizedBox(height: 6),
              TextButton(
                onPressed: () => Navigator.pop(ctx, false),
                child: Text(tr('Stay signed in'),
                    style: const TextStyle(fontSize: 16)),
              ),
            ],
          ),
        ),
      ),
    );
    if (go != true || !mounted) return;
    await context.read<AuthProvider>().signOut();
    if (!mounted) return;
    Navigator.pushNamedAndRemoveUntil(context, '/role_select', (_) => false);
  }

  @override
  Widget build(BuildContext context) {
    final first = (_profile?['first_name'] ?? '').toString();
    final surname = (_profile?['surname'] ?? '').toString();
    final full = (_profile?['full_name'] ?? '').toString();
    final displayName = '$first $surname'.trim().isEmpty
        ? full
        : '$first $surname'.trim();
    final rating =
        ((_profile?['average_rating'] ?? 5.0) as num).toDouble();
    final totalRatings = _profile?['total_ratings'] ?? 0;
    final avatarUrl =
        (_profile?['profile_picture_url'] ?? _profile?['avatar_url'])
            ?.toString();

    return Scaffold(
      backgroundColor: EfuridePalette.cream,
      appBar: AppBar(
        backgroundColor: EfuridePalette.cream,
        elevation: 0,
        scrolledUnderElevation: 0,
        automaticallyImplyLeading: false, // <--- No back arrow, no actions
      ),
      body: SafeArea(
        top: false,
        child: _loading
            ? const Center(child: CircularProgressIndicator())
            : ListView(
                padding: EdgeInsets.zero,
                children: [
                  // ================= Header =================
                  Padding(
                    padding: const EdgeInsets.fromLTRB(20, 8, 20, 24),
                    child: Row(
                      children: [
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                displayName.toUpperCase(),
                                style: const TextStyle(
                                  fontSize: 26,
                                  fontWeight: FontWeight.w900,
                                  letterSpacing: -0.5,
                                  color: Color(0xFF1A1A1A),
                                ),
                              ),
                              const SizedBox(height: 6),
                              Row(
                                children: [
                                  const Icon(Icons.star,
                                      color: Color(0xFF34C759), size: 18),
                                  const SizedBox(width: 4),
                                  Text(
                                    rating.toStringAsFixed(2),
                                    style: const TextStyle(
                                      fontSize: 15,
                                      fontWeight: FontWeight.w600,
                                      color: Color(0xFF1A1A1A),
                                    ),
                                  ),
                                  const SizedBox(width: 6),
                                  Icon(Icons.info_outline,
                                      size: 16,
                                      color: Colors.grey.shade500),
                                  const SizedBox(width: 6),
                                  Text(
                                    '($totalRatings)',
                                    style: TextStyle(
                                        fontSize: 14,
                                        color: Colors.grey.shade600),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                        InkWell(
                          onTap: () => Navigator.pushNamed(
                              context, '/customer_profile'),
                          borderRadius: BorderRadius.circular(30),
                          child: Container(
                            width: 56,
                            height: 56,
                            decoration: BoxDecoration(
                              color: Colors.grey.shade100,
                              shape: BoxShape.circle,
                              image: (avatarUrl != null &&
                                      avatarUrl.isNotEmpty)
                                  ? DecorationImage(
                                      image: NetworkImage(avatarUrl),
                                      fit: BoxFit.cover,
                                    )
                                  : null,
                            ),
                            child: (avatarUrl == null ||
                                    avatarUrl.isEmpty)
                                ? const KIcon(Icons.camera_alt,
                                    size: 24, color: Color(0xFF1A1A1A))
                                : null,
                          ),
                        ),
                      ],
                    ),
                  ),

                  // ================= Section 1: Account =================
                  _sectionCard([
                    _row(
                      asset: AppImages.userBlue,
                      label: tr('Profile'),
                      onTap: () => Navigator.pushNamed(
                          context, '/customer_profile'),
                    ),
                    _row(
                      asset: AppImages.card,
                      label: tr('Payment'),
                      onTap: () =>
                          Navigator.pushNamed(context, '/wallet'),
                    ),
                    _row(
                      asset: AppImages.headset,
                      label: tr('Support'),
                      onTap: () =>
                          Navigator.pushNamed(context, '/support'),
                    ),
                    _row(
                      asset: AppImages.shieldCheck,
                      label: tr('Safety'),
                      onTap: () =>
                          Navigator.pushNamed(context, '/sos_setup'),
                    ),
                    _row(
                      asset: AppImages.mapPin,
                      label: tr('Saved places'),
                      onTap: () =>
                          Navigator.pushNamed(context, '/favorites'),
                    ),
                    _row(
                      asset: AppImages.gear,
                      label: tr('Settings'),
                      onTap: () => Navigator.pushNamed(
                          context, '/customer_settings'),
                    ),
                  ]),

                  const SizedBox(height: 16),

                  // ================= Section 2: Rewards =================
                  _sectionCard([
                    _richRow(
                      asset: AppImages.gift,
                      title: tr('Loyalty points'),
                      subtitle: tr('View your tier and rewards'),
                      onTap: () =>
                          Navigator.pushNamed(context, '/loyalty'),
                    ),
                    _richRow(
                      asset: AppImages.share,
                      title: tr('Refer a friend'),
                      subtitle: tr('Invite friends and earn ride credit'),
                      onTap: () =>
                          Navigator.pushNamed(context, '/referral'),
                    ),
                    _richRow(
                      asset: AppImages.percentTag,
                      title: tr('Promotions'),
                      subtitle: tr('Promo codes, offers, and savings'),
                      onTap: () =>
                          Navigator.pushNamed(context, '/promotions'),
                    ),
                  ]),

                  const SizedBox(height: 16),

                  // ================= Section 3: Extras =================
                  _sectionCard([
                    _richRow(
                      asset: AppImages.barChart,
                      title: tr('Analytics'),
                      subtitle: tr('See your ride statistics'),
                      onTap: () =>
                          Navigator.pushNamed(context, '/analytics'),
                    ),
                    _richRow(
                      asset: AppImages.walletBlue,
                      title: tr('Earn with ko!ngo'),
                      subtitle: tr('Become a driver or courier'),
                      onTap: _earnWithKongo,
                    ),
                  ]),

                  const SizedBox(height: 24),
                  Center(
                    child: Text(
                      tr('ko!ngo v1.0.0'),
                      style: TextStyle(
                        fontSize: 13.5,
                        color: Colors.grey.shade500,
                      ),
                    ),
                  ),
                  const SizedBox(height: 40),
                ],
              ),
      ),
    );
  }

  // ============================================================
  // HELPERS
  // ============================================================
  Widget _sectionCard(List<Widget> children) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.04),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        children: [
          for (int i = 0; i < children.length; i++) ...[
            children[i],
            if (i < children.length - 1)
              Divider(
                height: 1,
                thickness: 1,
                indent: 60,
                color: Colors.grey.shade100,
              ),
          ],
        ],
      ),
    );
  }

  /// Simple row — one PNG icon on the left, label, chevron.
  /// Used for the top "Account" section.
  Widget _row({
    required String asset,
    required String label,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 18),
        child: Row(
          children: [
            AppImage(
              asset,
              size: 26,
              fallbackIcon: Icons.circle_outlined,
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Text(
                label,
                style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w500,
                  color: Color(0xFF1A1A1A),
                ),
              ),
            ),
            Icon(Icons.chevron_right,
                size: 22, color: Colors.grey.shade500),
          ],
        ),
      ),
    );
  }

  /// Richer row — PNG icon + title + subtitle. Used for the
  /// Rewards and Extras sections.
  Widget _richRow({
    required String asset,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
        child: Row(
          children: [
            AppImage(
              asset,
              size: 32,
              fallbackIcon: Icons.circle_outlined,
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w500,
                      color: Color(0xFF1A1A1A),
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    subtitle,
                    style: TextStyle(
                        fontSize: 14, color: Colors.grey.shade600),
                  ),
                ],
              ),
            ),
            Icon(Icons.chevron_right,
                size: 22, color: Colors.grey.shade500),
          ],
        ),
      ),
    );
  }
}
