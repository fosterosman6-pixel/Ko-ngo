// lib/screens/customer/customer_parcel_screen.dart
//
// Parcel booking screen. Collects pickup, dropoff, recipient details,
// package size, photo, and optional flags, then inserts a Delivery
// ride into the `rides` table and returns to the customer shell.
//
// i18n-clean · currency-clean · uses CountryConfig + S.

import 'dart:io' show File;
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:image_picker/image_picker.dart';

import 'package:efuride_app/config/country_config.dart';
import 'package:efuride_app/config/efuride_palette.dart';
import 'package:efuride_app/l10n/app_strings.dart';
import 'package:efuride_app/services/storage_service.dart';
import 'package:efuride_app/utils/app_error.dart';
import 'package:efuride_app/utils/error_ui.dart';
import 'package:efuride_app/widgets/k_icon.dart';

enum _ParcelSize { small, medium, large, xl }

extension _ParcelSizeX on _ParcelSize {
  String get key {
    switch (this) {
      case _ParcelSize.small:  return 'small';
      case _ParcelSize.medium: return 'medium';
      case _ParcelSize.large:  return 'large';
      case _ParcelSize.xl:     return 'xl';
    }
  }

  double get baseFare {
    switch (this) {
      case _ParcelSize.small:  return 800;
      case _ParcelSize.medium: return 1500;
      case _ParcelSize.large:  return 2800;
      case _ParcelSize.xl:     return 4500;
    }
  }
}

class CustomerParcelScreen extends StatefulWidget {
  const CustomerParcelScreen({super.key});

  @override
  State<CustomerParcelScreen> createState() =>
      _CustomerParcelScreenState();
}

class _CustomerParcelScreenState extends State<CustomerParcelScreen> {
  final _recipientNameCtrl  = TextEditingController();
  final _recipientPhoneCtrl = TextEditingController();
  final _pickupCtrl =
      TextEditingController(text: 'Kenyatta Avenue, Nairobi');
  final _dropoffCtrl = TextEditingController();
  final _noteCtrl    = TextEditingController();

  final _picker = ImagePicker();
  XFile? _packagePhoto;

  _ParcelSize _size = _ParcelSize.medium;
  bool _isFragile = false;
  bool _isUrgent  = false;
  bool _submitting = false;

  double get _fragileFee => _isFragile ? 500 : 0;
  double get _urgentFee  => _isUrgent ? 800 : 0;
  double get _total => _size.baseFare + _fragileFee + _urgentFee;

  @override
  void dispose() {
    _recipientNameCtrl.dispose();
    _recipientPhoneCtrl.dispose();
    _pickupCtrl.dispose();
    _dropoffCtrl.dispose();
    _noteCtrl.dispose();
    super.dispose();
  }

  // ═══════════════════════════════════════════════════════════
  // PHOTO
  // ═══════════════════════════════════════════════════════════
  Future<void> _pickPhoto({bool fromCamera = false}) async {
    try {
      final f = await StorageService.instance.pickImage(
        fromCamera: fromCamera,
        maxWidth: 1600,
        imageQuality: 70,
      );
      if (f == null) return;
      if (!mounted) return;
      setState(() => _packagePhoto = f);
    } catch (e) {
      if (!mounted) return;
      final t = S.of(context);
      _snack(t.t('camera_error'), EfuridePalette.dropoff);
    }
  }

  // ═══════════════════════════════════════════════════════════
  // SUBMIT
  // ═══════════════════════════════════════════════════════════
  Future<void> _submit() async {
    if (_submitting) return;
    final t = S.of(context);

    if (_dropoffCtrl.text.trim().isEmpty) {
      _snack(t.t('add_dropoff_address'), EfuridePalette.dropoff);
      return;
    }
    if (_recipientNameCtrl.text.trim().isEmpty) {
      _snack(t.t('add_recipient_name'), EfuridePalette.dropoff);
      return;
    }
    if (_recipientPhoneCtrl.text.trim().length < 7) {
      _snack(t.t('add_recipient_phone'), EfuridePalette.dropoff);
      return;
    }

    final userId = Supabase.instance.client.auth.currentUser?.id;
    if (userId == null) {
      _snack(t.t('not_signed_in_hint'), EfuridePalette.dropoff);
      return;
    }

    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16)),
        title: Text(t.t('confirm_parcel')),
        content: Text(
            '${t.t('total')}: ${CountryConfig.money(_total)}\n\n'
            '${t.t('recipient')}: ${_recipientNameCtrl.text.trim()}'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: Text(t.t('cancel')),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, true),
            style: ElevatedButton.styleFrom(
              backgroundColor: EfuridePalette.blueDeep,
              foregroundColor: Colors.white,
            ),
            child: Text(t.t('request_courier')),
          ),
        ],
      ),
    );

    if (ok != true || !mounted) return;

    setState(() => _submitting = true);

    try {
      final otp = _generateOtp();

      // Insert the delivery ride.
      final response = await Supabase.instance.client
          .from('rides')
          .insert({
            'customer_id': userId,
            'service_type': 'Delivery',
            'vehicle_type': 'standard',
            'pickup_address': _pickupCtrl.text.trim(),
            'dropoff_address': _dropoffCtrl.text.trim(),
            'pickup_lat': 0,          // picker would fill these in prod
            'pickup_lng': 0,
            'dropoff_lat': 0,
            'dropoff_lng': 0,
            'status': 'pending',
            'fare': _total,
            'original_fare': _total,
            'distance_km': 0.0,
            'customer_note': _noteCtrl.text.trim().isEmpty
                ? null
                : _noteCtrl.text.trim(),
            'recipient_name': _recipientNameCtrl.text.trim(),
            'recipient_phone': _recipientPhoneCtrl.text.trim(),
            'pickup_otp': otp,
            'pickup_otp_verified': false,
            'pricing_mode': 'algorithmic',
            'dispatch_mode': 'assign',
            'negotiation_state': 'none',
          })
          .select()
          .single()
          .timeout(const Duration(seconds: 20));

      final rideId = response['id'].toString();

      // Upload photo if provided.
      if (_packagePhoto != null) {
        try {
          final url = await StorageService.instance
              .uploadPackagePhoto(_packagePhoto!, rideId);
          if (url != null) {
            await Supabase.instance.client
                .from('rides')
                .update({'package_photo_url': url})
                .eq('id', rideId)
                .timeout(const Duration(seconds: 15));
          }
        } catch (e) {
          debugPrint('package photo upload failed: $e');
        }
      }

      if (!mounted) return;
      _snack(t.t('courier_requested'), EfuridePalette.online);

      await Future.delayed(const Duration(milliseconds: 600));
      if (!mounted) return;

      Navigator.pushNamedAndRemoveUntil(
          context, '/customer?tab=rides', (_) => false);
    } catch (e) {
      if (!mounted) return;
      setState(() => _submitting = false);
      ErrorUI.showSnack(context, AppError.from(e, onRetry: _submit));
    }
  }

  String _generateOtp() {
    final rnd = math.Random.secure();
    return (rnd.nextInt(900000) + 100000).toString();
  }

  void _snack(String msg, Color color) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(msg),
        backgroundColor: color,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10)),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // BUILD
  // ═══════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: EfuridePalette.cream,
      body: Column(
        children: [
          _header(),
          Expanded(
            child: ListView(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
              children: [
                _routeCard(),
                const SizedBox(height: 14),
                _recipientCard(),
                const SizedBox(height: 14),
                _packageCard(),
                const SizedBox(height: 14),
                _flagsCard(),
                const SizedBox(height: 14),
                _noteCard(),
                const SizedBox(height: 14),
                _fareCard(),
                const SizedBox(height: 20),
              ],
            ),
          ),
          _stickyBar(),
        ],
      ),
    );
  }

  // ── Header ──
  Widget _header() {
    final t = S.of(context);
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          colors: [EfuridePalette.blue, EfuridePalette.blueDeep],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
      ),
      child: SafeArea(
        bottom: false,
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(8, 8, 16, 12),
              child: Row(
                children: [
                  IconButton(
                    onPressed: () => Navigator.pop(context),
                    icon: const Icon(Icons.arrow_back, color: Colors.white),
                  ),
                  const SizedBox(width: 4),
                  Container(
                    width: 36,
                    height: 36,
                    decoration: const BoxDecoration(
                      color: Colors.white,
                      shape: BoxShape.circle,
                    ),
                    child: const Center(
                      child: KIcon(Icons.inventory_2_rounded,
                          color: EfuridePalette.blueDeep, size: 20),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('EFURIDE',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 16,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 1.2,
                            height: 1.05,
                          )),
                      const SizedBox(height: 2),
                      Text(t.t('send_parcel'),
                          style: const TextStyle(
                            color: Colors.white70,
                            fontSize: 11.5,
                            fontWeight: FontWeight.w500,
                          )),
                    ],
                  ),
                ],
              ),
            ),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 18),
              decoration: const BoxDecoration(
                color: EfuridePalette.navy,
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(24),
                  topRight: Radius.circular(24),
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(t.t('send_anything'),
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 20,
                        fontWeight: FontWeight.w900,
                        letterSpacing: -0.3,
                      )),
                  const SizedBox(height: 4),
                  Text(t.t('parcel_sub'),
                      style: const TextStyle(
                          color: Colors.white70, fontSize: 13)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ── Route card ──
  Widget _routeCard() {
    final t = S.of(context);
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: EfuridePalette.divider),
      ),
      child: Column(
        children: [
          _addrRow(
            color: EfuridePalette.pickup,
            icon: Icons.my_location,
            label: t.t('pickup_from'),
            controller: _pickupCtrl,
            hint: t.t('enter_pickup'),
          ),
          const Divider(height: 20, color: EfuridePalette.divider),
          _addrRow(
            color: EfuridePalette.dropoff,
            icon: Icons.location_on,
            label: t.t('deliver_to'),
            controller: _dropoffCtrl,
            hint: t.t('enter_dropoff'),
          ),
        ],
      ),
    );
  }

  Widget _addrRow({
    required Color color,
    required IconData icon,
    required String label,
    required TextEditingController controller,
    required String hint,
  }) {
    return Row(
      children: [
        Icon(icon, color: color, size: 20),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(label,
                  style: const TextStyle(
                      fontSize: 10.5,
                      color: EfuridePalette.inkMuted,
                      fontWeight: FontWeight.w700,
                      letterSpacing: 0.4)),
              TextField(
                controller: controller,
                decoration: InputDecoration(
                  hintText: hint,
                  hintStyle: const TextStyle(
                      fontSize: 13, color: EfuridePalette.inkMuted),
                  border: InputBorder.none,
                  isDense: true,
                  contentPadding:
                      const EdgeInsets.symmetric(vertical: 6),
                ),
                style: const TextStyle(
                  fontSize: 13.5,
                  fontWeight: FontWeight.w700,
                  color: EfuridePalette.ink,
                ),
              ),
            ],
          ),
        ),
        const Icon(Icons.chevron_right,
            size: 18, color: EfuridePalette.inkMuted),
      ],
    );
  }

  // ── Recipient card ──
  Widget _recipientCard() {
    final t = S.of(context);
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: EfuridePalette.divider),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.person_pin_outlined,
                  size: 18, color: EfuridePalette.blueDeep),
              const SizedBox(width: 8),
              Text(t.t('recipient'),
                  style: const TextStyle(
                    fontSize: 13.5,
                    fontWeight: FontWeight.w800,
                    color: EfuridePalette.ink,
                  )),
            ],
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _recipientNameCtrl,
            textCapitalization: TextCapitalization.words,
            decoration: InputDecoration(
              hintText: t.t('full_name'),
              hintStyle: const TextStyle(
                  fontSize: 13, color: EfuridePalette.inkMuted),
              filled: true,
              fillColor: EfuridePalette.cream,
              contentPadding: const EdgeInsets.symmetric(
                  horizontal: 12, vertical: 14),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(10),
                borderSide: BorderSide.none,
              ),
            ),
          ),
          const SizedBox(height: 10),
          TextField(
            controller: _recipientPhoneCtrl,
            keyboardType: TextInputType.phone,
            inputFormatters: [
              FilteringTextInputFormatter.allow(
                  RegExp(r'[0-9+\-\s()]')),
            ],
            decoration: InputDecoration(
              hintText: t.t('phone_number'),
              hintStyle: const TextStyle(
                  fontSize: 13, color: EfuridePalette.inkMuted),
              filled: true,
              fillColor: EfuridePalette.cream,
              contentPadding: const EdgeInsets.symmetric(
                  horizontal: 12, vertical: 14),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(10),
                borderSide: BorderSide.none,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ── Package card ──
  Widget _packageCard() {
    final t = S.of(context);
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: EfuridePalette.divider),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const KIcon(Icons.inventory_2_outlined,
                  size: 18, color: EfuridePalette.blueDeep),
              const SizedBox(width: 8),
              Text(t.t('package_size'),
                  style: const TextStyle(
                    fontSize: 13.5,
                    fontWeight: FontWeight.w800,
                    color: EfuridePalette.ink,
                  )),
            ],
          ),
          const SizedBox(height: 12),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: _ParcelSize.values.map((s) {
              final active = _size == s;
              return GestureDetector(
                onTap: () => setState(() => _size = s),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 180),
                  padding: const EdgeInsets.symmetric(
                      horizontal: 12, vertical: 10),
                  decoration: BoxDecoration(
                    color: active
                        ? EfuridePalette.blueDeep
                            .withValues(alpha: 0.10)
                        : Colors.transparent,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                      color: active
                          ? EfuridePalette.blueDeep
                          : EfuridePalette.divider,
                      width: active ? 1.5 : 1,
                    ),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(_sizeLabel(s, t),
                          style: TextStyle(
                            fontSize: 12.5,
                            fontWeight: FontWeight.w900,
                            color: active
                                ? EfuridePalette.blueDeep
                                : EfuridePalette.ink,
                          )),
                      const SizedBox(height: 2),
                      Text(_sizeWeight(s, t),
                          style: const TextStyle(
                              fontSize: 10.5,
                              color: EfuridePalette.inkMuted)),
                    ],
                  ),
                ),
              );
            }).toList(),
          ),
          const SizedBox(height: 14),
          Text(t.t('package_photo'),
              style: const TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w800,
                  color: EfuridePalette.inkMuted)),
          const SizedBox(height: 8),
          if (_packagePhoto == null)
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () => _pickPhoto(fromCamera: true),
                    icon: const KIcon(Icons.camera_alt_outlined, size: 16),
                    label: Text(t.t('camera'),
                        style: const TextStyle(fontSize: 12.5)),
                    style: OutlinedButton.styleFrom(
                      minimumSize: const Size(0, 44),
                      foregroundColor: EfuridePalette.blueDeep,
                      side: const BorderSide(
                          color: EfuridePalette.divider),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10)),
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () => _pickPhoto(fromCamera: false),
                    icon: const KIcon(Icons.photo_library_outlined,
                        size: 16),
                    label: Text(t.t('gallery'),
                        style: const TextStyle(fontSize: 12.5)),
                    style: OutlinedButton.styleFrom(
                      minimumSize: const Size(0, 44),
                      foregroundColor: EfuridePalette.blueDeep,
                      side: const BorderSide(
                          color: EfuridePalette.divider),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10)),
                    ),
                  ),
                ),
              ],
            )
          else
            Stack(
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(12),
                  child: Image.file(
                    File(_packagePhoto!.path),
                    height: 140,
                    width: double.infinity,
                    fit: BoxFit.cover,
                    errorBuilder: (_, __, ___) => Container(
                      height: 140,
                      color: EfuridePalette.cream,
                      child: const Center(child: Text('Photo selected')),
                    ),
                  ),
                ),
                Positioned(
                  top: 8,
                  right: 8,
                  child: CircleAvatar(
                    backgroundColor: Colors.white,
                    child: IconButton(
                      icon: const Icon(Icons.close,
                          size: 18, color: EfuridePalette.dropoff),
                      onPressed: () =>
                          setState(() => _packagePhoto = null),
                    ),
                  ),
                ),
              ],
            ),
        ],
      ),
    );
  }

  String _sizeLabel(_ParcelSize s, S t) {
    switch (s) {
      case _ParcelSize.small:  return t.t('size_small');
      case _ParcelSize.medium: return t.t('size_medium');
      case _ParcelSize.large:  return t.t('size_large');
      case _ParcelSize.xl:     return t.t('size_xl');
    }
  }

  String _sizeWeight(_ParcelSize s, S t) {
    switch (s) {
      case _ParcelSize.small:  return t.t('weight_small');
      case _ParcelSize.medium: return t.t('weight_medium');
      case _ParcelSize.large:  return t.t('weight_large');
      case _ParcelSize.xl:     return t.t('weight_xl');
    }
  }

  // ── Flags card ──
  Widget _flagsCard() {
    final t = S.of(context);
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: EfuridePalette.divider),
      ),
      child: Column(
        children: [
          _flagRow(
            icon: Icons.wine_bar_outlined,
            title: t.t('fragile'),
            subtitle:
                '${t.t('fragile_hint')} · +${CountryConfig.money(500)}',
            value: _isFragile,
            onChanged: (v) => setState(() => _isFragile = v),
          ),
          const Divider(height: 1, color: EfuridePalette.divider),
          _flagRow(
            icon: Icons.bolt,
            title: t.t('urgent'),
            subtitle:
                '${t.t('urgent_hint')} · +${CountryConfig.money(800)}',
            value: _isUrgent,
            onChanged: (v) => setState(() => _isUrgent = v),
          ),
        ],
      ),
    );
  }

  Widget _flagRow({
    required IconData icon,
    required String title,
    required String subtitle,
    required bool value,
    required ValueChanged<bool> onChanged,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: EfuridePalette.blueDeep.withValues(alpha: 0.10),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Icon(icon,
                size: 18, color: EfuridePalette.blueDeep),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title,
                    style: const TextStyle(
                        fontSize: 13.5,
                        fontWeight: FontWeight.w800,
                        color: EfuridePalette.ink)),
                const SizedBox(height: 2),
                Text(subtitle,
                    style: const TextStyle(
                        fontSize: 11.5,
                        color: EfuridePalette.inkMuted)),
              ],
            ),
          ),
          Switch.adaptive(
            value: value,
            activeColor: EfuridePalette.blueDeep,
            onChanged: onChanged,
          ),
        ],
      ),
    );
  }

  // ── Note card ──
  Widget _noteCard() {
    final t = S.of(context);
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: EfuridePalette.divider),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.sticky_note_2_outlined,
                  size: 18, color: EfuridePalette.blueDeep),
              const SizedBox(width: 8),
              Text(t.t('note_for_driver'),
                  style: const TextStyle(
                    fontSize: 13.5,
                    fontWeight: FontWeight.w800,
                    color: EfuridePalette.ink,
                  )),
            ],
          ),
          const SizedBox(height: 10),
          TextField(
            controller: _noteCtrl,
            maxLines: 2,
            decoration: InputDecoration(
              hintText: t.t('parcel_note_hint'),
              hintStyle: const TextStyle(
                  fontSize: 12.5, color: EfuridePalette.inkMuted),
              filled: true,
              fillColor: EfuridePalette.cream,
              contentPadding: const EdgeInsets.all(12),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(10),
                borderSide: BorderSide.none,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ── Fare card ──
  Widget _fareCard() {
    final t = S.of(context);
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: EfuridePalette.divider),
      ),
      child: Column(
        children: [
          _row(
            '${t.t('base_fare')} (${_sizeLabel(_size, t)})',
            CountryConfig.money(_size.baseFare),
          ),
          if (_isFragile) ...[
            const SizedBox(height: 6),
            _row(t.t('fragile_handling'),
                '+ ${CountryConfig.money(_fragileFee)}'),
          ],
          if (_isUrgent) ...[
            const SizedBox(height: 6),
            _row(t.t('urgent_surcharge'),
                '+ ${CountryConfig.money(_urgentFee)}'),
          ],
          const SizedBox(height: 10),
          const Divider(height: 1, color: EfuridePalette.divider),
          const SizedBox(height: 10),
          Row(
            children: [
              Text(t.t('total'),
                  style: const TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w900,
                    color: EfuridePalette.ink,
                  )),
              const Spacer(),
              Text(CountryConfig.money(_total),
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w900,
                    color: EfuridePalette.blueDeep,
                  )),
            ],
          ),
        ],
      ),
    );
  }

  Widget _row(String label, String value) {
    return Row(
      children: [
        Text(label,
            style: const TextStyle(
                fontSize: 12.5, color: EfuridePalette.inkMuted)),
        const Spacer(),
        Text(value,
            style: const TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.w700,
                color: EfuridePalette.ink)),
      ],
    );
  }

  // ── Sticky bar ──
  Widget _stickyBar() {
    final t = S.of(context);
    return Container(
      padding: EdgeInsets.fromLTRB(
        16,
        12,
        16,
        12 + MediaQuery.of(context).padding.bottom,
      ),
      decoration: BoxDecoration(
        color: Colors.white,
        border:
            const Border(top: BorderSide(color: EfuridePalette.divider)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.05),
            blurRadius: 10,
            offset: const Offset(0, -3),
          ),
        ],
      ),
      child: Row(
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(t.t('total'),
                  style: const TextStyle(
                      fontSize: 11,
                      color: EfuridePalette.inkMuted)),
              Text(CountryConfig.money(_total),
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w900,
                    color: EfuridePalette.ink,
                  )),
            ],
          ),
          const SizedBox(width: 16),
          Expanded(
            child: ElevatedButton.icon(
              onPressed: _submitting ? null : _submit,
              icon: _submitting
                  ? const SizedBox(
                      width: 18, height: 18,
                      child: CircularProgressIndicator(
                          strokeWidth: 2, color: Colors.white),
                    )
                  : const KIcon(Icons.local_shipping_outlined, size: 18),
              label: Text(t.t('request_courier'),
                  style: const TextStyle(
                      fontSize: 15, fontWeight: FontWeight.w900)),
              style: ElevatedButton.styleFrom(
                backgroundColor: EfuridePalette.blueDeep,
                foregroundColor: Colors.white,
                minimumSize: const Size(double.infinity, 54),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14)),
                elevation: 0,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
