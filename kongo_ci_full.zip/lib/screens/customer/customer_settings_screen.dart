// lib/screens/customer/customer_settings_screen.dart

import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:efuride_app/config/app_images.dart';
import 'package:efuride_app/config/app_lang.dart';
import 'package:efuride_app/l10n/app_strings.dart';
import 'package:efuride_app/config/readability.dart';
import 'package:efuride_app/widgets/text_size_sheet.dart';
import 'package:efuride_app/main.dart' show appLanguageNotifier;
import 'package:efuride_app/widgets/app_image.dart';
import 'package:efuride_app/services/driver_location_service.dart';
import 'package:efuride_app/services/notification_service.dart';
import 'package:efuride_app/utils/app_error.dart';
import 'package:efuride_app/utils/error_ui.dart';
import 'package:provider/provider.dart';
import 'package:efuride_app/providers/auth_provider.dart';
import 'package:efuride_app/widgets/k_icon.dart';

class _Palette {
  static const cream = Color(0xFFFAF6EE);
  static const ink = Color(0xFF1A1A1A);
  static const inkMuted = Color(0xFF575047);
  static const accent = Color(0xFFF2B705);
  static const divider = Color(0xFFE8E2D5);
  static const blue = Color(0xFF1E88E5);
  static const danger = Color(0xFFE53935);
}

class CustomerSettingsScreen extends StatefulWidget {
  /// true when shown as the bottom-bar tab (no back arrow).
  final bool asTab;
  const CustomerSettingsScreen({super.key, this.asTab = false});

  @override
  State<CustomerSettingsScreen> createState() =>
      _CustomerSettingsScreenState();
}

class _CustomerSettingsScreenState extends State<CustomerSettingsScreen> {
  bool _isLoading = true;
  bool _isLoggingOut = false;

  String _language = 'en';
  Map<String, dynamic>? _profile;
  bool _pushRides = true;
  bool _pushChats = true;
  bool _pushPromotions = false;
  bool _emailReceipts = true;
  bool _calendarSync = false;

  @override
  void initState() {
    super.initState();
    _loadPreferences();
  }

  Future<void> _loadPreferences() async {
    try {
      final userId = Supabase.instance.client.auth.currentUser?.id;
      if (userId == null) {
        if (mounted) setState(() => _isLoading = false);
        return;
      }
      final row = await Supabase.instance.client
          .from('profiles')
          .select(
            'language, push_rides, push_chats, push_promotions, '
            'email_receipts, calendar_sync, first_name, surname, '
            'full_name, profile_picture_url, avatar_url, average_rating, '
            'total_ratings',
          )
          .eq('id', userId)
          .maybeSingle();
      if (!mounted) return;
      setState(() {
        _profile = row;
        _language = (row?['language'] ?? appLanguageNotifier.value.code)
            .toString();
        _pushRides = row?['push_rides'] as bool? ?? true;
        _pushChats = row?['push_chats'] as bool? ?? true;
        _pushPromotions = row?['push_promotions'] as bool? ?? false;
        _emailReceipts = row?['email_receipts'] as bool? ?? true;
        _calendarSync = row?['calendar_sync'] as bool? ?? false;
        _isLoading = false;
      });
    } catch (e) {
      debugPrint('loadPreferences failed: $e');
      if (mounted) setState(() => _isLoading = false);
    }
  }

  Future<void> _savePreference(String key, dynamic value) async {
    final userId = Supabase.instance.client.auth.currentUser?.id;
    if (userId == null) return;
    try {
      await Supabase.instance.client
          .from('profiles')
          .update({key: value}).eq('id', userId);
    } catch (e) {
      if (!mounted) return;
      ErrorUI.showSnack(context, AppError.from(e));
    }
  }

  // ============================================================
  // COMMUNICATION
  // ============================================================
  void _openCommunication() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (_) => StatefulBuilder(
        builder: (ctx, setSheet) {
          Widget toggleRow({
            required String title,
            required String subtitle,
            required bool value,
            required ValueChanged<bool> onChanged,
          }) {
            return Padding(
              padding: const EdgeInsets.symmetric(
                  horizontal: 20, vertical: 10),
              child: Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(title,
                            style: const TextStyle(
                                fontSize: 15,
                                fontWeight: FontWeight.w600,
                                color: _Palette.ink)),
                        const SizedBox(height: 2),
                        Text(subtitle,
                            style: const TextStyle(
                                fontSize: 13.5,
                                color: _Palette.inkMuted,
                                height: 1.3)),
                      ],
                    ),
                  ),
                  Switch.adaptive(
                    value: value,
                    activeColor: _Palette.blue,
                    onChanged: onChanged,
                  ),
                ],
              ),
            );
          }

          return SafeArea(
            child: Padding(
              padding: const EdgeInsets.only(top: 16, bottom: 24),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Center(
                    child: Container(
                      width: 40,
                      height: 4,
                      decoration: BoxDecoration(
                        color: Colors.grey.shade300,
                        borderRadius: BorderRadius.circular(2),
                      ),
                    ),
                  ),
                  const SizedBox(height: 20),
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: 20),
                    child: Text(
                      tr('Communication'),
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: _Palette.ink,
                      ),
                    ),
                  ),
                  const SizedBox(height: 4),
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: 20),
                    child: Text(
                      tr('Choose what notifications you receive.'),
                      style: TextStyle(
                          fontSize: 13.5, color: _Palette.inkMuted),
                    ),
                  ),
                  const SizedBox(height: 16),
                  toggleRow(
                    title: tr('Ride updates'),
                    subtitle: tr('Driver assigned, arriving, and trip status.'),
                    value: _pushRides,
                    onChanged: (v) async {
                      setSheet(() => _pushRides = v);
                      setState(() {});
                      await _savePreference('push_rides', v);
                    },
                  ),
                  toggleRow(
                    title: tr('Chat messages'),
                    subtitle: tr('Messages from drivers during an active trip.'),
                    value: _pushChats,
                    onChanged: (v) async {
                      setSheet(() => _pushChats = v);
                      setState(() {});
                      await _savePreference('push_chats', v);
                    },
                  ),
                  toggleRow(
                    title: tr('Promotions and offers'),
                    subtitle:
                        tr('Discounts, referral bonuses, and seasonal deals.'),
                    value: _pushPromotions,
                    onChanged: (v) async {
                      setSheet(() => _pushPromotions = v);
                      setState(() {});
                      await _savePreference('push_promotions', v);
                    },
                  ),
                  toggleRow(
                    title: tr('Email receipts'),
                    subtitle:
                        tr('Send trip summaries to your registered email.'),
                    value: _emailReceipts,
                    onChanged: (v) async {
                      setSheet(() => _emailReceipts = v);
                      setState(() {});
                      await _savePreference('email_receipts', v);
                    },
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  // ============================================================
  // CALENDAR
  // ============================================================
  void _openCalendar() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (_) => StatefulBuilder(
        builder: (ctx, setSheet) => SafeArea(
          child: Padding(
            padding: const EdgeInsets.only(top: 16, bottom: 24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Center(
                  child: Container(
                    width: 40,
                    height: 4,
                    decoration: BoxDecoration(
                      color: Colors.grey.shade300,
                      borderRadius: BorderRadius.circular(2),
                    ),
                  ),
                ),
                const SizedBox(height: 20),
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 20),
                  child: Text(
                    tr('Calendar'),
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: _Palette.ink,
                    ),
                  ),
                ),
                const SizedBox(height: 4),
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 20),
                  child: Text(
                    tr('Get smart ride suggestions based on your calendar events.'),
                    style:
                        TextStyle(fontSize: 13.5, color: _Palette.inkMuted),
                  ),
                ),
                const SizedBox(height: 16),
                Padding(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 20, vertical: 10),
                  child: Row(
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(tr('Sync calendar'),
                                style: TextStyle(
                                    fontSize: 15,
                                    fontWeight: FontWeight.w600,
                                    color: _Palette.ink)),
                            SizedBox(height: 2),
                            Text(
                              tr('Suggest rides ahead of your meetings and appointments.'),
                              style: TextStyle(
                                  fontSize: 13.5,
                                  color: _Palette.inkMuted,
                                  height: 1.3),
                            ),
                          ],
                        ),
                      ),
                      Switch.adaptive(
                        value: _calendarSync,
                        activeColor: _Palette.blue,
                        onChanged: (v) async {
                          setSheet(() => _calendarSync = v);
                          setState(() {});
                          await _savePreference('calendar_sync', v);
                        },
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 12),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: _Palette.blue.withValues(alpha: 0.08),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: const Row(
                      children: [
                        Icon(Icons.info_outline,
                            size: 16, color: _Palette.blue),
                        SizedBox(width: 10),
                        Expanded(
                          child: Text(
                            'Google and Apple Calendar integration is coming soon. '
                            'Your preference is saved.',
                            style: TextStyle(
                                fontSize: 13,
                                color: _Palette.blue,
                                height: 1.4),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ============================================================
  // LANGUAGE — 7 languages, wired to appLanguageNotifier
  // ============================================================
  void _openLanguage() {
    final languages = AppLang.available
        .map((l) => {'code': l.code, 'label': l.label})
        .toList();

    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (ctx) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.only(top: 16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: Colors.grey.shade300,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
              const SizedBox(height: 20),
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 20),
                child: Text(
                  tr('Language'),
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: _Palette.ink,
                  ),
                ),
              ),
              const SizedBox(height: 12),
              Flexible(
                child: ListView.builder(
                  shrinkWrap: true,
                  itemCount: languages.length,
                  itemBuilder: (_, i) {
                    final lang = languages[i];
                    final selected = lang['code'] == _language;
                    return RadioListTile<String>(
                      value: lang['code']!,
                      groupValue: _language,
                      activeColor: _Palette.blue,
                      title: Text(lang['label']!,
                          style: const TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.w600,
                              color: _Palette.ink)),
                      onChanged: (v) {
                        if (v == null) return;
                        Navigator.pop(ctx);
                        _setLanguage(v);
                      },
                    );
                  },
                ),
              ),
              const SizedBox(height: 12),
            ],
          ),
        ),
      ),
    );
  }

  /// Change the app language right away (one tap from Settings).
  Future<void> _setLanguage(String code) async {
    if (code == _language) return;
    setState(() => _language = code);
    // Flip the running app immediately, then remember it.
    appLanguageNotifier.value = AppLang.fromCode(code);
    await AppLangStore.saveUserChoice(AppLang.fromCode(code));
    await _savePreference('language', code);
  }

  /// Driving / shopping / selling uses its own ko!ngo account (each
  /// account has one role). Explain that, and only sign out if the
  /// customer chooses to.
  Future<void> _earnWithKongo() async {
    final go = await showModalBottomSheet<bool>(
      context: context,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (ctx) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 18, 20, 16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text(tr('Earn with ko!ngo'),
                  style: const TextStyle(
                      fontSize: 21, fontWeight: FontWeight.w800)),
              const SizedBox(height: 10),
              Text(
                tr('Drivers, shoppers and store owners use a separate ko!ngo account, with a different email address. Your customer account stays as it is.'),
                style: const TextStyle(fontSize: 15.5, height: 1.4),
              ),
              const SizedBox(height: 8),
              Text(
                tr('To create it, you will be signed out of this account. You can sign back in any time.'),
                style: const TextStyle(
                    fontSize: 15, height: 1.4, color: _Palette.inkMuted),
              ),
              const SizedBox(height: 18),
              ElevatedButton(
                onPressed: () => Navigator.pop(ctx, true),
                style: ElevatedButton.styleFrom(
                  minimumSize: const Size(0, 52),
                  backgroundColor: _Palette.accent,
                  foregroundColor: const Color(0xFF0B1220),
                ),
                child: Text(tr('Sign out and create partner account'),
                    style: const TextStyle(
                        fontSize: 16, fontWeight: FontWeight.w800)),
              ),
              const SizedBox(height: 6),
              TextButton(
                onPressed: () => Navigator.pop(ctx, false),
                child: Text(tr('Stay signed in'),
                    style: const TextStyle(fontSize: 16)),
              ),
            ],
          ),
        ),
      ),
    );
    if (go != true || !mounted) return;
    await context.read<AuthProvider>().signOut();
    if (!mounted) return;
    Navigator.pushNamedAndRemoveUntil(context, '/role_select', (_) => false);
  }

  // ============================================================
  // SIGN IN AND SECURITY
  // ============================================================
  void _openSecurity() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (ctx) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.only(top: 16, bottom: 24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: Colors.grey.shade300,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
              const SizedBox(height: 20),
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 20),
                child: Text(
                  tr('Sign in and security'),
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: _Palette.ink,
                  ),
                ),
              ),
              const SizedBox(height: 12),
              _sheetTile(
                icon: Icons.password,
                title: tr('Change password'),
                subtitle: tr('Update your account password'),
                onTap: () {
                  Navigator.pop(ctx);
                  Navigator.pushNamed(context, '/customer_profile');
                },
              ),
              _sheetTile(
                icon: Icons.email_outlined,
                title: tr('Change email'),
                subtitle: tr('Update the email on your account'),
                onTap: () {
                  Navigator.pop(ctx);
                  Navigator.pushNamed(context, '/customer_profile');
                },
              ),
              _sheetTile(
                icon: Icons.devices_outlined,
                title: tr('Active sessions'),
                subtitle: tr('Manage devices signed in to your account'),
                onTap: () {
                  Navigator.pop(ctx);
                  _showActiveSessions();
                },
              ),
              _sheetTile(
                icon: Icons.verified_user_outlined,
                title: tr('Two-factor authentication'),
                subtitle: tr('Add an extra layer of security'),
                onTap: () {
                  Navigator.pop(ctx);
                  ErrorUI.showSnack(
                    context,
                    AppError(
                      title: tr('Two-factor authentication'),
                      message:
                          tr('Setup is available from your Supabase dashboard. Coming to the app soon.'),
                      icon: Icons.shield_outlined,
                    ),
                  );
                },
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showActiveSessions() {
    final createdAt =
        Supabase.instance.client.auth.currentSession?.expiresAt;
    String expires = 'Unknown';
    if (createdAt != null) {
      final dt = DateTime.fromMillisecondsSinceEpoch(createdAt * 1000);
      expires = dt.toLocal().toString().split('.').first;
    }

    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16)),
        title: Text(tr('Active sessions')),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(tr('Current session:')),
            const SizedBox(height: 8),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: _Palette.cream,
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: _Palette.divider),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Icon(Icons.phone_android,
                          size: 16, color: _Palette.blue),
                      SizedBox(width: 8),
                      Text(tr('This device'),
                          style: TextStyle(
                              fontWeight: FontWeight.bold, fontSize: 14)),
                    ],
                  ),
                  const SizedBox(height: 6),
                  Text(tr('Expires: {0}', [expires]),
                      style: const TextStyle(
                          fontSize: 13, color: _Palette.inkMuted)),
                ],
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(tr('Close')),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // LEGAL
  // ============================================================
  void _openLegal() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (ctx) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.only(top: 16, bottom: 24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: Colors.grey.shade300,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
              const SizedBox(height: 20),
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 20),
                child: Text(
                  tr('Legal'),
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: _Palette.ink,
                  ),
                ),
              ),
              const SizedBox(height: 12),
              _sheetTile(
                icon: Icons.description_outlined,
                title: tr('Terms of Service'),
                onTap: () {
                  Navigator.pop(ctx);
                  _showLegalDoc(
                    title: tr('Terms of Service'),
                    body: 'By using ko!ngo you agree to use the platform '
                        'lawfully and to follow all applicable transport '
                        'regulations in your region.\n\n'
                        'ko!ngo connects riders with independent drivers. '
                        'We are not a transport provider and do not employ '
                        'drivers directly.\n\n'
                        'Fares are estimates. Final fares may vary based on '
                        'route, traffic, and any agreed counter-offers.\n\n'
                        'Full version available from ko!ngo support.',
                  );
                },
              ),
              _sheetTile(
                icon: Icons.privacy_tip_outlined,
                title: tr('Privacy Policy'),
                onTap: () {
                  Navigator.pop(ctx);
                  Navigator.pushNamed(context, '/customer_privacy');
                },
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showLegalDoc({required String title, required String body}) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16)),
        title: Text(title),
        content: SizedBox(
          width: 400,
          child: SingleChildScrollView(
            child: Text(body,
                style: const TextStyle(height: 1.5, fontSize: 14)),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(tr('Close')),
          ),
        ],
      ),
    );
  }

  Widget _sheetTile({
    required IconData icon,
    required String title,
    String? subtitle,
    required VoidCallback onTap,
  }) {
    return ListTile(
      leading: Icon(icon, color: _Palette.ink, size: 22),
      title: Text(title,
          style: const TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.w600,
              color: _Palette.ink)),
      subtitle: subtitle != null
          ? Text(subtitle,
              style: const TextStyle(
                  fontSize: 13, color: _Palette.inkMuted))
          : null,
      trailing: const Icon(Icons.chevron_right,
          color: _Palette.inkMuted, size: 20),
      onTap: onTap,
    );
  }

  // ============================================================
  // LOGOUT
  // ============================================================
  Future<void> _confirmLogout() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Text(tr('Log out?')),
        content:
            Text(tr('You\'ll need to sign in again to book rides.')),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: Text(tr('Cancel')),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: _Palette.danger,
              foregroundColor: Colors.white,
            ),
            onPressed: () => Navigator.pop(ctx, true),
            child: Text(tr('Log out')),
          ),
        ],
      ),
    );
    if (confirmed != true) return;

    setState(() => _isLoggingOut = true);
    try {
      try {
        final userId = Supabase.instance.client.auth.currentUser?.id;
        if (userId != null) {
          await Supabase.instance.client
              .from('profiles')
              .update({'is_online': false}).eq('id', userId);
        }
      } catch (_) {}
      try {
        await DriverLocationService.instance.stop();
      } catch (_) {}
      try {
        await NotificationService.instance.unregister();
      } catch (_) {}

      await Supabase.instance.client.auth.signOut();
      if (!mounted) return;
      Navigator.pushNamedAndRemoveUntil(
          context, '/role_select', (route) => false);
    } catch (e) {
      if (!mounted) return;
      setState(() => _isLoggingOut = false);
      ErrorUI.showSnack(context, AppError.from(e));
    }
  }

  // ============================================================
  // BUILD
  // ============================================================
  @override
  Widget build(BuildContext context) {
    final s = S.of(context);
    return Scaffold(
      backgroundColor: _Palette.cream,
      appBar: AppBar(
        backgroundColor: _Palette.cream,
        elevation: 0,
        scrolledUnderElevation: 0,
        automaticallyImplyLeading: !widget.asTab,
        iconTheme: const IconThemeData(color: _Palette.ink),
        title: Text(
          s.t('settings'),
          style: const TextStyle(
            color: _Palette.ink,
            fontWeight: FontWeight.w800,
            fontSize: 22,
          ),
        ),
      ),
      body: _isLoading
          ? const Center(
              child: CircularProgressIndicator(color: _Palette.accent))
          : RefreshIndicator(
              onRefresh: _loadPreferences,
              child: ListView(
                padding: const EdgeInsets.fromLTRB(16, 4, 16, 32),
                children: [
                  _profileCard(),
                  _heading(s.t('language')),
                  _languageCard(),
                  _heading(tr('Account')),
                  _sectionCard(
                    children: [
                      _rowTile(
                        asset: AppImages.card,
                        title: tr('Wallet & payment'),
                        subtitle: tr('Balance, top up and activity'),
                        onTap: () => Navigator.pushNamed(context, '/wallet'),
                      ),
                      _divider(),
                      _rowTile(
                        asset: AppImages.mapPin,
                        title: tr('Saved places'),
                        subtitle: tr('Home, work and favourites'),
                        onTap: () =>
                            Navigator.pushNamed(context, '/favorites'),
                      ),
                      _divider(),
                      _rowTile(
                        asset: AppImages.shieldCheck,
                        title: tr('Safety'),
                        subtitle: tr('Emergency contacts and SOS'),
                        onTap: () =>
                            Navigator.pushNamed(context, '/sos_setup'),
                      ),
                      _divider(),
                      _rowTile(
                        asset: AppImages.headset,
                        title: tr('Support'),
                        subtitle: tr('Get help with a trip or order'),
                        onTap: () => Navigator.pushNamed(context, '/support'),
                      ),
                    ],
                  ),
                  _heading(tr('Rewards')),
                  _sectionCard(
                    children: [
                      _rowTile(
                        asset: AppImages.percentTag,
                        title: tr('Promotions'),
                        subtitle: tr('Promo codes, offers, and savings'),
                        onTap: () =>
                            Navigator.pushNamed(context, '/promotions'),
                      ),
                      _divider(),
                      _rowTile(
                        asset: AppImages.share,
                        title: tr('Refer a friend'),
                        subtitle: tr('Invite friends and earn ride credit'),
                        onTap: () =>
                            Navigator.pushNamed(context, '/referral'),
                      ),
                      _divider(),
                      _rowTile(
                        asset: AppImages.gift,
                        title: tr('Loyalty points'),
                        subtitle: tr('View your tier and rewards'),
                        onTap: () => Navigator.pushNamed(context, '/loyalty'),
                      ),
                    ],
                  ),
                  _heading(tr('App')),
                  _sectionCard(
                    children: [
                      _rowTile(
                        asset: AppImages.speaker,
                        title: tr('Communication'),
                        subtitle: tr('Notifications and email receipts'),
                        onTap: _openCommunication,
                      ),
                      _divider(),
                      _rowTile(
                        asset: AppImages.textSize,
                        title: s.t('text_size'),
                        subtitle: s.t(Readability.labelKeyFor(
                            Readability.textScale.value)),
                        onTap: () async {
                          await showTextSizeSheet(context);
                          if (mounted) setState(() {});
                        },
                      ),
                      _divider(),
                      _rowTile(
                        asset: AppImages.calendar,
                        title: tr('Calendar'),
                        subtitle: tr('Get smart ride suggestions'),
                        onTap: _openCalendar,
                      ),
                    ],
                  ),
                  _heading(tr('Privacy and security')),
                  _sectionCard(
                    children: [
                      _rowTile(
                        asset: AppImages.shieldInfo,
                        title: s.t('privacy'),
                        subtitle: tr('Manage your data and permissions'),
                        onTap: () => Navigator.pushNamed(
                            context, '/customer_privacy'),
                      ),
                      _divider(),
                      _rowTile(
                        asset: AppImages.lock,
                        title: tr('Sign in and security'),
                        subtitle: tr('Password, email and sessions'),
                        onTap: _openSecurity,
                      ),
                      _divider(),
                      _rowTile(
                        asset: AppImages.bank,
                        title: s.t('legal'),
                        subtitle: tr('Terms and privacy policy'),
                        onTap: _openLegal,
                      ),
                    ],
                  ),
                  _heading(tr('More')),
                  _sectionCard(
                    children: [
                      _rowTile(
                        asset: AppImages.barChart,
                        title: tr('Analytics'),
                        subtitle: tr('See your ride statistics'),
                        onTap: () =>
                            Navigator.pushNamed(context, '/analytics'),
                      ),
                      _divider(),
                      _rowTile(
                        asset: AppImages.walletBlue,
                        title: tr('Earn with ko!ngo'),
                        subtitle: tr('Become a driver or courier'),
                        onTap: _earnWithKongo,
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),
                  OutlinedButton.icon(
                    onPressed: _isLoggingOut ? null : _confirmLogout,
                    icon: _isLoggingOut
                        ? const SizedBox(
                            width: 18,
                            height: 18,
                            child: CircularProgressIndicator(
                                strokeWidth: 2, color: _Palette.danger),
                          )
                        : const KIcon(Icons.logout, color: _Palette.danger),
                    label: Text(
                      _isLoggingOut ? tr('Signing out…') : s.t('sign_out'),
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w800,
                        color: _Palette.danger,
                      ),
                    ),
                    style: OutlinedButton.styleFrom(
                      minimumSize: const Size(0, 52),
                      backgroundColor: Colors.white,
                      side: const BorderSide(color: _Palette.divider),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(14)),
                    ),
                  ),
                  const SizedBox(height: 16),
                  Center(
                    child: Text(tr('ko!ngo v1.0.0'),
                        style: const TextStyle(
                            fontSize: 13.5, color: _Palette.inkMuted)),
                  ),
                ],
              ),
            ),
    );
  }

  Widget _heading(String text) => Padding(
        padding: const EdgeInsets.fromLTRB(4, 20, 4, 8),
        child: Text(text,
            style: const TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w800,
                color: _Palette.ink)),
      );

  /// Name, rating and photo. Tap to edit the profile.
  Widget _profileCard() {
    final p = _profile;
    final first = (p?['first_name'] ?? '').toString().trim();
    final surname = (p?['surname'] ?? '').toString().trim();
    final full = (p?['full_name'] ?? '').toString().trim();
    final name = '$first $surname'.trim().isNotEmpty
        ? '$first $surname'.trim()
        : (full.isNotEmpty ? full : tr('Your profile'));
    final rating = ((p?['average_rating'] ?? 5.0) as num).toDouble();
    final count = (p?['total_ratings'] as num?)?.toInt() ?? 0;
    final avatar =
        (p?['profile_picture_url'] ?? p?['avatar_url'] ?? '').toString();
    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(16),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: () => Navigator.pushNamed(context, '/customer_profile')
            .then((_) => _loadPreferences()),
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: _Palette.divider),
          ),
          child: Row(
            children: [
              CircleAvatar(
                radius: 30,
                backgroundColor: const Color(0xFFF1EEE6),
                backgroundImage:
                    avatar.isNotEmpty ? NetworkImage(avatar) : null,
                child: avatar.isEmpty
                    ? const KIcon(Icons.person,
                        size: 32, color: _Palette.inkMuted)
                    : null,
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(name,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                            fontSize: 19,
                            fontWeight: FontWeight.w800,
                            color: _Palette.ink)),
                    const SizedBox(height: 4),
                    Row(
                      children: [
                        const Icon(Icons.star,
                            size: 17, color: Color(0xFFF2B705)),
                        const SizedBox(width: 4),
                        Text(
                          '${rating.toStringAsFixed(2)}  ·  '
                          '${tr('{0} ratings', ['$count'])}',
                          style: const TextStyle(
                              fontSize: 14.5, color: _Palette.inkMuted),
                        ),
                      ],
                    ),
                    const SizedBox(height: 4),
                    Text(tr('Edit profile'),
                        style: const TextStyle(
                            fontSize: 14.5,
                            fontWeight: FontWeight.w700,
                            color: _Palette.blue)),
                  ],
                ),
              ),
              const Icon(Icons.chevron_right, color: _Palette.inkMuted),
            ],
          ),
        ),
      ),
    );
  }

  /// Every language as a chip — one tap switches the whole app.
  Widget _languageCard() {
    final current = AppLang.fromCode(_language);
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: _Palette.divider),
      ),
      child: Wrap(
        spacing: 8,
        runSpacing: 8,
        children: [
          for (final l in AppLang.available)
            ChoiceChip(
              label: Text(l.label),
              selected: l == current,
              showCheckmark: false,
              onSelected: (_) => _setLanguage(l.code),
              labelStyle: TextStyle(
                fontSize: 15,
                fontWeight: FontWeight.w700,
                color: l == current ? const Color(0xFF0B1220) : _Palette.ink,
              ),
              selectedColor: _Palette.accent,
              backgroundColor: Colors.white,
              side: BorderSide(
                  color: l == current ? _Palette.accent : _Palette.divider),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(20)),
              padding:
                  const EdgeInsets.symmetric(horizontal: 6, vertical: 6),
            ),
        ],
      ),
    );
  }

  String _labelForLanguage(String code) {
    return AppLang.fromCode(code).label;
  }

  Widget _sectionCard({required List<Widget> children}) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: _Palette.divider),
      ),
      child: Column(children: children),
    );
  }

  Widget _divider() => const Divider(
        height: 1,
        thickness: 1,
        color: _Palette.divider,
        indent: 56,
      );

  Widget _rowTile({
    required String asset,
    required String title,
    String? subtitle,
    required VoidCallback onTap,
  }) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(16),
        child: Padding(
          padding:
              const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
          child: Row(
            children: [
              AppImage(
                asset,
                size: 24,
                fallbackIcon: Icons.circle_outlined,
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title,
                        style: const TextStyle(
                            fontSize: 15,
                            fontWeight: FontWeight.w600,
                            color: _Palette.ink)),
                    if (subtitle != null) ...[
                      const SizedBox(height: 2),
                      Text(subtitle,
                          style: const TextStyle(
                              fontSize: 13.5, color: _Palette.inkMuted)),
                    ],
                  ],
                ),
              ),
              const Icon(Icons.chevron_right,
                  color: _Palette.inkMuted, size: 22),
            ],
          ),
        ),
      ),
    );
  }
}
