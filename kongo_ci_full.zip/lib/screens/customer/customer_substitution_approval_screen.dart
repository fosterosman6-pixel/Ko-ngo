// lib/screens/customer/substitution_approval_screen.dart
//
// Closes the substitution loop. Called from NotificationRouter when the
// customer taps a substitution notification. The DB trigger already
// created a row in `notifications` — this screen reads the `substitutions`
// row, shows the comparison, and writes the customer's decision back.
//
// Backwards-compatible: also accepts the old display-field arguments so
// existing route wiring keeps working until main.dart is updated.

import 'dart:async';
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:efuride_app/config/country_config.dart';
import 'package:efuride_app/config/efuride_palette.dart';
import 'package:efuride_app/l10n/app_strings.dart';
import 'package:efuride_app/utils/app_error.dart';
import 'package:efuride_app/utils/error_ui.dart';

class SubstitutionApprovalScreen extends StatefulWidget {
  /// New path — pass this and the screen loads everything else.
  final String? substitutionId;

  // Legacy args (still accepted; ignored when substitutionId is set).
  final String orderId;
  final String originalItem;
  final String originalQty;
  final double originalPrice;
  final String proposedItem;
  final double proposedPrice;
  final String shopperName;

  const SubstitutionApprovalScreen({
    super.key,
    this.substitutionId,
    this.orderId = '',
    this.originalItem = '',
    this.originalQty = '',
    this.originalPrice = 0,
    this.proposedItem = '',
    this.proposedPrice = 0,
    this.shopperName = '',
  });

  @override
  State<SubstitutionApprovalScreen> createState() =>
      _SubstitutionApprovalScreenState();
}

class _SubstitutionApprovalScreenState
    extends State<SubstitutionApprovalScreen> {
  Timer? _ticker;
  int _secondsLeft = 120;

  bool _loading = true;
  String? _error;
  bool _deciding = false;

  // Loaded values
  String? _taskId;
  String? _orderItemId;
  String _originalName = '';
  String _originalQty = '';
  double _originalPrice = 0;
  String _proposedName = '';
  String _proposedEmoji = '';
  double _proposedPrice = 0;
  String? _photoUrl;
  String _shopperName = '';
  String _status = 'pending';
  DateTime? _expiresAt;

  double get _priceDiff => _proposedPrice - _originalPrice;
  bool get _isCheaper => _priceDiff < 0;
  bool get _isSame => _priceDiff.abs() < 0.01;

  @override
  void initState() {
    super.initState();
    if ((widget.substitutionId ?? '').isNotEmpty) {
      _loadFromDb();
    } else {
      _usePassedArgs();
    }
  }

  @override
  void dispose() {
    _ticker?.cancel();
    super.dispose();
  }

  // ═══════════════════════════════════════════════════════════
  // LOADING
  // ═══════════════════════════════════════════════════════════

  void _usePassedArgs() {
    _originalName = widget.originalItem;
    _originalQty = widget.originalQty;
    _originalPrice = widget.originalPrice;
    _proposedName = widget.proposedItem;
    _proposedPrice = widget.proposedPrice;
    _shopperName = widget.shopperName;
    _loading = false;
    _startTimer();
  }

  Future<void> _loadFromDb() async {
    final id = widget.substitutionId!;
    try {
      final sub = await Supabase.instance.client
          .from('substitutions')
          .select()
          .eq('id', id)
          .maybeSingle();

      if (sub == null) {
        _finishWithError('Substitution not found');
        return;
      }

      final status = (sub['status'] ?? 'pending').toString();
      if (status != 'pending') {
        _finishWithError('This substitution has already been resolved.');
        return;
      }

      final itemId = sub['order_item_id']?.toString() ?? '';
      String originalQty = '1';
      try {
        final item = await Supabase.instance.client
            .from('order_items')
            .select('qty')
            .eq('id', itemId)
            .maybeSingle();
        if (item != null && item['qty'] != null) {
          originalQty = (item['qty'] as num).toInt().toString();
        }
      } catch (_) {}

      String shopper = '';
      try {
        final st = await Supabase.instance.client
            .from('shopping_tasks')
            .select('shopper_id')
            .eq('id', sub['task_id'])
            .maybeSingle();
        final sid = st?['shopper_id']?.toString();
        if (sid != null && sid.isNotEmpty) {
          final p = await Supabase.instance.client
              .from('profiles')
              .select('first_name, surname, full_name')
              .eq('id', sid)
              .maybeSingle();
          final first = (p?['first_name'] ?? '').toString().trim();
          final sur = (p?['surname'] ?? '').toString().trim();
          final full = (p?['full_name'] ?? '').toString().trim();
          shopper = first.isNotEmpty ? first : full.split(' ').first;
        }
      } catch (_) {}

      final expRaw = sub['expires_at']?.toString();
      final exp = expRaw == null
          ? DateTime.now().add(const Duration(minutes: 2))
          : (DateTime.tryParse(expRaw)?.toLocal() ??
              DateTime.now().add(const Duration(minutes: 2)));

      if (!mounted) return;
      setState(() {
        _taskId = sub['task_id']?.toString();
        _orderItemId = itemId;
        _originalName = (sub['original_name'] ?? '').toString();
        _originalQty = originalQty;
        _originalPrice = (sub['original_price'] as num?)?.toDouble() ?? 0;
        _proposedName = (sub['proposed_name'] ?? '').toString();
        _proposedEmoji = (sub['proposed_emoji'] ?? '').toString();
        _proposedPrice = (sub['proposed_price'] as num?)?.toDouble() ?? 0;
        _photoUrl = sub['photo_url']?.toString();
        _shopperName = shopper;
        _status = status;
        _expiresAt = exp;
        _loading = false;
      });
      _startTimer();
    } catch (e) {
      _finishWithError(tr('Could not load this item swap. Please try again.'));
    }
  }

  void _finishWithError(String msg) {
    if (!mounted) return;
    setState(() {
      _loading = false;
      _error = msg;
    });
  }

  // ═══════════════════════════════════════════════════════════
  // TIMER
  // ═══════════════════════════════════════════════════════════

  void _startTimer() {
    _ticker?.cancel();
    _recomputeSeconds();
    _ticker = Timer.periodic(const Duration(seconds: 1), (t) {
      if (!mounted) return;
      _recomputeSeconds();
      if (_secondsLeft <= 0) {
        t.cancel();
        _decide('timeout', silent: true);
      }
    });
  }

  void _recomputeSeconds() {
    final exp = _expiresAt;
    if (exp == null) return;
    final s = exp.difference(DateTime.now()).inSeconds;
    setState(() => _secondsLeft = s.clamp(0, 999));
  }

  String _fmt(int s) {
    final m = s ~/ 60;
    final sec = s % 60;
    return '$m:${sec.toString().padLeft(2, '0')}';
  }

  // ═══════════════════════════════════════════════════════════
  // DECIDE
  // ═══════════════════════════════════════════════════════════

  Future<void> _decide(String action, {bool silent = false}) async {
    if (_deciding) return;
    if (_taskId == null || widget.substitutionId == null) {
      // Legacy path — no DB row to update. Just pop.
      if (mounted) Navigator.pop(context, action);
      return;
    }

    setState(() => _deciding = true);
    _ticker?.cancel();

    try {
      final newStatus = action == 'approve'
          ? 'approved'
          : action == 'reject'
              ? 'rejected'
              : 'timeout';

      // One server call does it all (swap, item price, shopper's task).
      var doneOnServer = false;
      try {
        await Supabase.instance.client.rpc('respond_substitution', params: {
          'p_sub': widget.substitutionId,
          'p_action': action == 'approve'
              ? 'approve'
              : action == 'reject'
                  ? 'reject'
                  : 'timeout',
        });
        doneOnServer = true;
      } catch (e) {
        debugPrint('respond_substitution failed, using the old way: $e');
      }

      if (!doneOnServer) {
      await Supabase.instance.client.from('substitutions').update({
        'status': newStatus,
        'responded_at': DateTime.now().toUtc().toIso8601String(),
      }).eq('id', widget.substitutionId!);

      if (action == 'approve' && _orderItemId != null) {
        try {
          await Supabase.instance.client
              .from('order_items')
              .update({'actual_price': _proposedPrice})
              .eq('id', _orderItemId!);

          final st = await Supabase.instance.client
              .from('shopping_tasks')
              .select('items_picked, item_count')
              .eq('id', _taskId!)
              .maybeSingle();
          final picked = (st?['items_picked'] as num?)?.toInt() ?? 0;
          await Supabase.instance.client
              .from('shopping_tasks')
              .update({
                'items_picked': picked + 1,
                'status': 'in_progress',
              })
              .eq('id', _taskId!);
        } catch (e) {
          debugPrint('post-approve update failed: $e');
        }
      } else if (_taskId != null) {
        try {
          await Supabase.instance.client
              .from('shopping_tasks')
              .update({'status': 'in_progress'})
              .eq('id', _taskId!);
        } catch (e) {
          debugPrint('post-decide task status update failed: $e');
        }
      }
      } // end old way

      if (!mounted) return;
      if (!silent) {
        final label = action == 'approve'
            ? 'Substitution approved'
            : action == 'reject'
                ? 'Substitution rejected'
                : 'Substitution timed out';
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text(label),
          backgroundColor: action == 'approve'
              ? EfuridePalette.online
              : EfuridePalette.inkMuted,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10)),
        ));
      }
      Navigator.pop(context, action);
    } catch (e) {
      if (!mounted) return;
      setState(() => _deciding = false);
      ErrorUI.showSnack(context, AppError.from(e));
    }
  }

  // ═══════════════════════════════════════════════════════════
  // BUILD
  // ═══════════════════════════════════════════════════════════

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Scaffold(
        backgroundColor: EfuridePalette.cream,
        body: Center(
          child: CircularProgressIndicator(
              color: EfuridePalette.shopperAccent),
        ),
      );
    }

    if (_error != null) {
      return Scaffold(
        backgroundColor: EfuridePalette.cream,
        appBar: AppBar(
          backgroundColor: EfuridePalette.cream,
          elevation: 0,
          foregroundColor: EfuridePalette.ink,
          title: Text(tr('Substitution')),
        ),
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(32),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.info_outline,
                    size: 56, color: EfuridePalette.inkMuted),
                const SizedBox(height: 16),
                Text(_error!,
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                        fontSize: 14, color: EfuridePalette.ink)),
                const SizedBox(height: 20),
                ElevatedButton(
                  onPressed: () => Navigator.pop(context),
                  child: Text(tr('Back')),
                ),
              ],
            ),
          ),
        ),
      );
    }

    final t = S.of(context);
    return Scaffold(
      backgroundColor: EfuridePalette.cream,
      body: Column(
        children: [
          _header(t),
          Expanded(
            child: ListView(
              padding: const EdgeInsets.all(20),
              children: [
                _alertBanner(t),
                const SizedBox(height: 20),
                _comparisonCard(t),
                const SizedBox(height: 16),
                _priceImpactCard(t),
                if (_photoUrl != null && _photoUrl!.isNotEmpty) ...[
                  const SizedBox(height: 16),
                  _photoCard(t),
                ],
                const SizedBox(height: 20),
                _instructionCard(t),
                const SizedBox(height: 24),
              ],
            ),
          ),
          _bottomBar(t),
        ],
      ),
    );
  }

  // ── Header ──
  Widget _header(S t) {
    final urgent = _secondsLeft <= 30;

    return Container(
      decoration: const BoxDecoration(
        color: EfuridePalette.cream,
      ),
      child: SafeArea(
        bottom: false,
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 14),
              child: Row(
                children: [
                  Container(
                    width: 40,
                    height: 40,
                    decoration: BoxDecoration(
                      color: EfuridePalette.ink.withValues(alpha: 0.06),
                      shape: BoxShape.circle,
                    ),
                    child: const Center(
                      child: Icon(Icons.swap_horiz,
                          color: EfuridePalette.ink, size: 22),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(tr('KO!NGO'),
                          style: TextStyle(
                            color: EfuridePalette.ink,
                            fontSize: 16,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 1.2,
                            height: 1.05,
                          )),
                      SizedBox(height: 2),
                      Text(tr('Substitution request'),
                          style: TextStyle(
                            color: EfuridePalette.inkMuted,
                            fontSize: 13,
                            fontWeight: FontWeight.w500,
                          )),
                    ],
                  ),
                  const Spacer(),
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 10, vertical: 5),
                    decoration: BoxDecoration(
                      color: urgent
                          ? EfuridePalette.dropoff
                          : EfuridePalette.ink.withValues(alpha: 0.06),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Icon(Icons.timer_outlined,
                            color: EfuridePalette.ink, size: 12),
                        const SizedBox(width: 4),
                        Text(_fmt(_secondsLeft),
                            style: const TextStyle(
                              color: EfuridePalette.ink,
                              fontSize: 13.5,
                              fontWeight: FontWeight.w900,
                              fontFeatures: [
                                FontFeature.tabularFigures(),
                              ],
                            )),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.fromLTRB(16, 14, 16, 18),
              decoration: const BoxDecoration(
                color: EfuridePalette.cream,
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(24),
                  topRight: Radius.circular(24),
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(t.t('item_unavailable'),
                      style: const TextStyle(
                        color: EfuridePalette.ink,
                        fontSize: 20,
                        fontWeight: FontWeight.w900,
                        letterSpacing: -0.3,
                      )),
                  const SizedBox(height: 4),
                  Text(
                    _shopperName.isEmpty
                        ? t.t('shopper_suggests')
                        : '$_shopperName ${t.t('has_a_suggestion')}',
                    style: const TextStyle(
                        color: EfuridePalette.inkMuted, fontSize: 14),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ── Alert banner ──
  Widget _alertBanner(S t) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: EfuridePalette.shopperAccent.withValues(alpha: 0.10),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
            color: EfuridePalette.shopperAccent.withValues(alpha: 0.40)),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: EfuridePalette.shopperAccent,
              borderRadius: BorderRadius.circular(8),
            ),
            child: const Icon(Icons.info_outline,
                color: Colors.white, size: 18),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              t.t('couldnt_find_exact'),
              style: const TextStyle(
                fontSize: 14,
                height: 1.45,
                color: EfuridePalette.ink,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ── Comparison ──
  Widget _comparisonCard(S t) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: EfuridePalette.divider),
      ),
      child: Column(
        children: [
          _compareRow(
            label: t.t('you_ordered'),
            item: _originalName,
            qty: 'x$_originalQty',
            price: _originalPrice,
            emoji: '❌',
            isOriginal: true,
          ),
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 12),
            child: Row(
              children: [
                const Expanded(child: Divider(color: EfuridePalette.divider)),
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: EfuridePalette.shopperAccent.withValues(alpha: 0.15),
                    shape: BoxShape.circle,
                  ),
                  child: const Icon(Icons.arrow_downward,
                      size: 18, color: EfuridePalette.shopperAccent),
                ),
                const Expanded(child: Divider(color: EfuridePalette.divider)),
              ],
            ),
          ),
          _compareRow(
            label: t.t('shopper_suggests_label'),
            item: _proposedName,
            qty: 'x$_originalQty',
            price: _proposedPrice,
            emoji: _proposedEmoji.isNotEmpty ? _proposedEmoji : '✅',
            isOriginal: false,
          ),
        ],
      ),
    );
  }

  Widget _compareRow({
    required String label,
    required String item,
    required String qty,
    required double price,
    required String emoji,
    required bool isOriginal,
  }) {
    return Row(
      children: [
        Container(
          width: 54,
          height: 54,
          decoration: BoxDecoration(
            color: isOriginal
                ? EfuridePalette.cream
                : EfuridePalette.shopperAccent.withValues(alpha: 0.12),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Center(
            child: Text(emoji, style: const TextStyle(fontSize: 26)),
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(label,
                  style: TextStyle(
                    fontSize: 12,
                    letterSpacing: 0.8,
                    fontWeight: FontWeight.w900,
                    color: isOriginal
                        ? EfuridePalette.inkMuted
                        : EfuridePalette.shopperAccent,
                  )),
              const SizedBox(height: 3),
              Text(item,
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w800,
                    color: isOriginal
                        ? EfuridePalette.inkMuted
                        : EfuridePalette.ink,
                    decoration: isOriginal
                        ? TextDecoration.lineThrough
                        : null,
                    decorationColor: EfuridePalette.inkMuted,
                  )),
              const SizedBox(height: 2),
              Text(qty,
                  style: const TextStyle(
                      fontSize: 13,
                      color: EfuridePalette.inkMuted)),
            ],
          ),
        ),
        Column(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Text(CountryConfig.money(price),
                style: TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.w900,
                  color: isOriginal
                      ? EfuridePalette.inkMuted
                      : EfuridePalette.shopperAccent,
                )),
          ],
        ),
      ],
    );
  }

  // ── Price impact ──
  Widget _priceImpactCard(S t) {
    final color = _isCheaper
        ? EfuridePalette.online
        : _isSame
            ? EfuridePalette.inkMuted
            : EfuridePalette.merchantAccent;

    final label = _isCheaper
        ? '${t.t('you_save')} ${CountryConfig.money(_priceDiff.abs())}'
        : _isSame
            ? t.t('same_price')
            : '${t.t('you_pay_more')} ${CountryConfig.money(_priceDiff)}';

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.08),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: color.withValues(alpha: 0.35), width: 1.4),
      ),
      child: Row(
        children: [
          Icon(
            _isCheaper
                ? Icons.trending_down
                : _isSame
                    ? Icons.horizontal_rule
                    : Icons.trending_up,
            color: color,
            size: 24,
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(t.t('price_impact'),
                    style: TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w700,
                      letterSpacing: 0.6,
                      color: color,
                    )),
                const SizedBox(height: 2),
                Text(label,
                    style: TextStyle(
                      fontSize: 14.5,
                      fontWeight: FontWeight.w900,
                      color: color,
                    )),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ── Photo ──
  Widget _photoCard(S t) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: EfuridePalette.divider),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(tr('Photo from your shopper'),
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w800,
                color: EfuridePalette.ink,
              )),
          const SizedBox(height: 10),
          ClipRRect(
            borderRadius: BorderRadius.circular(10),
            child: Image.network(
              _photoUrl!,
              height: 180,
              width: double.infinity,
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => Container(
                height: 100,
                color: EfuridePalette.cream,
                child: const Center(
                  child: Icon(Icons.broken_image_outlined,
                      color: EfuridePalette.inkMuted),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ── Instruction ──
  Widget _instructionCard(S t) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: EfuridePalette.cream,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        children: [
          const Icon(Icons.hourglass_empty,
              size: 16, color: EfuridePalette.inkMuted),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              t.t('timeout_hint'),
              style: const TextStyle(
                fontSize: 13,
                color: EfuridePalette.inkMuted,
                height: 1.45,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ── Bottom bar ──
  Widget _bottomBar(S t) {
    return Container(
      padding: EdgeInsets.fromLTRB(
        16,
        12,
        16,
        12 + MediaQuery.of(context).padding.bottom,
      ),
      decoration: BoxDecoration(
        color: Colors.white,
        border: const Border(top: BorderSide(color: EfuridePalette.divider)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.05),
            blurRadius: 10,
            offset: const Offset(0, -3),
          ),
        ],
      ),
      child: Row(
        children: [
          Expanded(
            child: OutlinedButton(
              onPressed: _deciding ? null : () => _decide('reject'),
              style: OutlinedButton.styleFrom(
                minimumSize: const Size(0, 54),
                side: const BorderSide(
                    color: EfuridePalette.dropoff, width: 1.5),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14)),
                foregroundColor: EfuridePalette.dropoff,
              ),
              child: Text(t.t('skip_item'),
                  style: const TextStyle(
                      fontSize: 15, fontWeight: FontWeight.w900)),
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            flex: 2,
            child: ElevatedButton.icon(
              onPressed: _deciding ? null : () => _decide('approve'),
              icon: _deciding
                  ? const SizedBox(
                      width: 18,
                      height: 18,
                      child: CircularProgressIndicator(
                          strokeWidth: 2, color: Colors.white),
                    )
                  : const Icon(Icons.check_circle, size: 20),
              label: Text(t.t('approve_swap'),
                  style: const TextStyle(
                      fontSize: 15, fontWeight: FontWeight.w900)),
              style: ElevatedButton.styleFrom(
                backgroundColor: EfuridePalette.shopperAccent,
                foregroundColor: Colors.white,
                minimumSize: const Size(0, 54),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14)),
                elevation: 0,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
