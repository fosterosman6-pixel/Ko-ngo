// lib/screens/customer/customer_privacy_screen.dart

import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:efuride_app/config/country_config.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:efuride_app/config/app_images.dart';
import 'package:efuride_app/widgets/app_image.dart';
import 'package:efuride_app/services/driver_location_service.dart';
import 'package:efuride_app/services/notification_service.dart';
import 'package:efuride_app/utils/app_error.dart';
import 'package:efuride_app/utils/error_ui.dart';
import 'package:efuride_app/l10n/app_strings.dart';

class _Palette {
  static const cream = Color(0xFFFAF6EE);
  static const ink = Color(0xFF1A1A1A);
  static const inkMuted = Color(0xFF575047);
  static const accent = Color(0xFFF2B705);
  static const divider = Color(0xFFE8E2D5);
  static const blue = Color(0xFF1E88E5);
  static const danger = Color(0xFFE53935);
}

class CustomerPrivacyScreen extends StatefulWidget {
  const CustomerPrivacyScreen({super.key});

  @override
  State<CustomerPrivacyScreen> createState() => _CustomerPrivacyScreenState();
}

class _CustomerPrivacyScreenState extends State<CustomerPrivacyScreen> {
  bool _isLoading = true;
  bool _isExporting = false;
  bool _isDeleting = false;

  bool _shareLocation = true;
  bool _analyticsEnabled = true;
  bool _personalisedAds = false;

  @override
  void initState() {
    super.initState();
    _loadPreferences();
  }

  Future<void> _loadPreferences() async {
    try {
      final userId = Supabase.instance.client.auth.currentUser?.id;
      if (userId == null) return;

      final row = await Supabase.instance.client
          .from('profiles')
          .select('share_location, analytics_enabled, personalised_ads')
          .eq('id', userId)
          .maybeSingle();

      if (!mounted || row == null) {
        if (mounted) setState(() => _isLoading = false);
        return;
      }
      setState(() {
        _shareLocation = row['share_location'] as bool? ?? true;
        _analyticsEnabled = row['analytics_enabled'] as bool? ?? true;
        _personalisedAds = row['personalised_ads'] as bool? ?? false;
        _isLoading = false;
      });
    } catch (e) {
      debugPrint('loadPreferences failed: $e');
      if (mounted) setState(() => _isLoading = false);
    }
  }

  Future<void> _updatePreference(String key, bool value) async {
    final userId = Supabase.instance.client.auth.currentUser?.id;
    if (userId == null) return;
    try {
      await Supabase.instance.client
          .from('profiles')
          .update({key: value}).eq('id', userId);
    } catch (e) {
      if (!mounted) return;
      ErrorUI.showSnack(context, AppError.from(e));
    }
  }

  // ============================================================
  // TRACKING SERVICES SHEET
  // ============================================================
  void _openTrackingServices() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (_) => StatefulBuilder(
        builder: (ctx, setSheet) {
          Widget toggleRow({
            required IconData icon,
            required String title,
            required String subtitle,
            required bool value,
            required ValueChanged<bool> onChanged,
          }) {
            return Padding(
              padding: const EdgeInsets.symmetric(
                  horizontal: 20, vertical: 12),
              child: Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: _Palette.blue.withValues(alpha: 0.10),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Icon(icon, color: _Palette.blue, size: 20),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(title,
                            style: const TextStyle(
                                fontSize: 14,
                                fontWeight: FontWeight.w700,
                                color: _Palette.ink)),
                        const SizedBox(height: 2),
                        Text(subtitle,
                            style: const TextStyle(
                                fontSize: 13.5,
                                color: _Palette.inkMuted,
                                height: 1.3)),
                      ],
                    ),
                  ),
                  Switch.adaptive(
                    value: value,
                    activeColor: _Palette.blue,
                    onChanged: onChanged,
                  ),
                ],
              ),
            );
          }

          return SafeArea(
            child: Padding(
              padding: const EdgeInsets.only(top: 16, bottom: 16),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Center(
                    child: Container(
                      width: 40,
                      height: 4,
                      decoration: BoxDecoration(
                        color: Colors.grey.shade300,
                        borderRadius: BorderRadius.circular(2),
                      ),
                    ),
                  ),
                  const SizedBox(height: 20),
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: 20),
                    child: Text(
                      tr('Tracking services'),
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: _Palette.ink,
                      ),
                    ),
                  ),
                  const SizedBox(height: 8),
                  toggleRow(
                    icon: Icons.location_on_outlined,
                    title: tr('Share live location'),
                    subtitle:
                        tr('Allow drivers to see your pickup location during trips.'),
                    value: _shareLocation,
                    onChanged: (v) async {
                      setSheet(() => _shareLocation = v);
                      setState(() {});
                      await _updatePreference('share_location', v);
                    },
                  ),
                  toggleRow(
                    icon: Icons.insights_outlined,
                    title: tr('Usage analytics'),
                    subtitle:
                        tr('Help us improve ko!ngo with anonymous usage data.'),
                    value: _analyticsEnabled,
                    onChanged: (v) async {
                      setSheet(() => _analyticsEnabled = v);
                      setState(() {});
                      await _updatePreference('analytics_enabled', v);
                    },
                  ),
                  toggleRow(
                    icon: Icons.campaign_outlined,
                    title: tr('Personalised offers'),
                    subtitle:
                        tr('Get promotions based on your trips and favourite routes.'),
                    value: _personalisedAds,
                    onChanged: (v) async {
                      setSheet(() => _personalisedAds = v);
                      setState(() {});
                      await _updatePreference('personalised_ads', v);
                    },
                  ),
                  const SizedBox(height: 12),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20),
                    child: Text(
                      'These settings apply across the app. '
                      'Turning off live location may affect trip accuracy.',
                      style: TextStyle(
                          fontSize: 13,
                          color: _Palette.inkMuted,
                          height: 1.4),
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  // ============================================================
  // DATA EXPORT
  // ============================================================
  Future<void> _exportPersonalData() async {
    if (_isExporting) return;
    setState(() => _isExporting = true);

    try {
      final userId = Supabase.instance.client.auth.currentUser?.id;
      if (userId == null) throw Exception('Not signed in');

      final db = Supabase.instance.client;
      // Each part on its own: one unavailable table doesn't stop the export.
      Future<dynamic> part(Future<dynamic> Function() q) async {
        try {
          return await q().timeout(const Duration(seconds: 20));
        } catch (e) {
          debugPrint('export part failed: $e');
          return null;
        }
      }

      final profile = await part(() =>
          db.from('profiles').select().eq('id', userId).maybeSingle());
      final rides = await part(() => db
          .from('rides')
          .select()
          .or('customer_id.eq.$userId,driver_id.eq.$userId')
          .order('created_at', ascending: false));
      final notifications = await part(() => db
          .from('notifications')
          .select()
          .eq('user_id', userId)
          .order('created_at', ascending: false));
      final documents = await part(
          () => db.from('documents').select().eq('user_id', userId));
      final orders = await part(() => db
          .from('orders')
          .select()
          .eq('customer_id', userId)
          .order('created_at', ascending: false));
      final wallet = await part(() => db
          .from('wallet_transactions')
          .select()
          .eq('user_id', userId)
          .order('created_at', ascending: false));
      final places = await part(
          () => db.from('favorite_places').select().eq('user_id', userId));

      final payload = {
        'exported_at': DateTime.now().toUtc().toIso8601String(),
        'user_id': userId,
        'profile': profile,
        'rides': rides,
        'notifications': notifications,
        'documents': documents,
        'orders': orders,
        'wallet_transactions': wallet,
        'favorite_places': places,
      };

      final json = const JsonEncoder.withIndent('  ').convert(payload);

      if (!mounted) return;
      _showExportSheet(json);
    } catch (e) {
      if (!mounted) return;
      ErrorUI.showSnack(context, AppError.from(e));
    } finally {
      if (mounted) setState(() => _isExporting = false);
    }
  }

  void _showExportSheet(String json) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (ctx) => DraggableScrollableSheet(
        expand: false,
        initialChildSize: 0.7,
        maxChildSize: 0.95,
        minChildSize: 0.4,
        builder: (_, scrollCtrl) => Column(
          children: [
            const SizedBox(height: 12),
            Container(
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                color: Colors.grey.shade300,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            const SizedBox(height: 16),
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 20),
              child: Row(
                children: [
                  Icon(Icons.description_outlined,
                      color: _Palette.blue, size: 22),
                  SizedBox(width: 10),
                  Text(
                    tr('Your data export'),
                    style: TextStyle(
                        fontSize: 17,
                        fontWeight: FontWeight.bold,
                        color: _Palette.ink),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 6),
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 20),
              child: Text(
                'Copy the JSON below or take a screenshot. '
                'A full download feature is coming soon.',
                style: TextStyle(fontSize: 13.5, color: _Palette.inkMuted),
              ),
            ),
            const SizedBox(height: 12),
            Expanded(
              child: Container(
                margin: const EdgeInsets.symmetric(horizontal: 16),
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: _Palette.cream,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: _Palette.divider),
                ),
                child: SingleChildScrollView(
                  controller: scrollCtrl,
                  child: SelectableText(
                    json,
                    style: const TextStyle(
                      fontFamily: 'monospace',
                      fontSize: 13,
                      height: 1.4,
                      color: _Palette.ink,
                    ),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 12),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () => Navigator.pop(ctx),
                      style: OutlinedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      child: Text(tr('Close')),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 12),
          ],
        ),
      ),
    );
  }

  // ============================================================
  // DELETE ACCOUNT
  // ============================================================
  Future<void> _confirmDeleteAccount() async {
    final confirmed = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => AlertDialog(
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Row(
          children: [
            Icon(Icons.warning_amber_rounded, color: _Palette.danger),
            SizedBox(width: 10),
            Text(tr('Delete account?')),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              tr('This permanently deletes your account, trip history, and saved data.'),
              style: TextStyle(height: 1.4),
            ),
            SizedBox(height: 12),
            Text(
              tr('This action cannot be undone.'),
              style: TextStyle(
                  color: _Palette.danger,
                  fontWeight: FontWeight.w700,
                  fontSize: 13.5),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: Text(tr('Cancel')),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: _Palette.danger,
              foregroundColor: Colors.white,
            ),
            onPressed: () => Navigator.pop(ctx, true),
            child: Text(tr('Delete forever')),
          ),
        ],
      ),
    );

    if (confirmed != true) return;

    final typedCtrl = TextEditingController();
    final doubleConfirmed = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setD) => AlertDialog(
          shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(16)),
          title: Text(tr('Confirm deletion')),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                  tr('Type DELETE in capitals to confirm.'),
                  style: TextStyle(fontSize: 14)),
              const SizedBox(height: 12),
              TextField(
                controller: typedCtrl,
                autofocus: true,
                textCapitalization: TextCapitalization.characters,
                decoration: InputDecoration(
                  hintText: tr('DELETE'),
                  border: OutlineInputBorder(),
                ),
                onChanged: (_) => setD(() {}),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: Text(tr('Cancel')),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: _Palette.danger,
                foregroundColor: Colors.white,
              ),
              onPressed: typedCtrl.text.trim() == 'DELETE'
                  ? () => Navigator.pop(ctx, true)
                  : null,
              child: Text(tr('Confirm')),
            ),
          ],
        ),
      ),
    );

    typedCtrl.dispose();

    if (doubleConfirmed != true) return;

    setState(() => _isDeleting = true);

    try {
      try {
        await DriverLocationService.instance.stop();
      } catch (_) {}
      try {
        await NotificationService.instance.unregister();
      } catch (_) {}

      // Server removes personal data and the sign-in (step14 SQL).
      try {
        await Supabase.instance.client
            .rpc('delete_my_account', params: {'p_forfeit_balance': false});
      } on PostgrestException catch (e) {
        final msg = e.message;
        if (msg.contains('kongo_wallet_not_empty')) {
          // Money still in the wallet: say so and ask again.
          final amount = double.tryParse(
                  RegExp(r'([0-9]+(?:\.[0-9]+)?)\s*$')
                          .firstMatch(msg)
                          ?.group(1) ??
                      '') ??
              0;
          if (!mounted) return;
          final forfeit = await showDialog<bool>(
            context: context,
            builder: (ctx) => AlertDialog(
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16)),
              title: Text(tr('Money in your wallet')),
              content: Text(
                tr('You still have {0} in your ko!ngo wallet. If you delete your account now, this money is lost. Contact support first if you want it back.',
                    [CountryConfig.money(amount)]),
                style: const TextStyle(height: 1.4),
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(ctx, false),
                  child: Text(tr('Keep my account')),
                ),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: _Palette.danger,
                    foregroundColor: Colors.white,
                  ),
                  onPressed: () => Navigator.pop(ctx, true),
                  child: Text(tr('Delete anyway')),
                ),
              ],
            ),
          );
          if (forfeit != true) {
            if (mounted) setState(() => _isDeleting = false);
            return;
          }
          await Supabase.instance.client
              .rpc('delete_my_account', params: {'p_forfeit_balance': true});
        } else if (msg.contains('kongo_active_trip') ||
            msg.contains('kongo_active_order')) {
          if (!mounted) return;
          setState(() => _isDeleting = false);
          ErrorUI.showSnack(
            context,
            AppError(
              title: tr('Not yet'),
              message: msg.contains('kongo_active_trip')
                  ? tr('Finish or cancel your current trip first.')
                  : tr('Wait until your order is delivered or cancel it first.'),
              icon: Icons.hourglass_top,
            ),
          );
          return;
        } else {
          rethrow;
        }
      }
      try {
        await Supabase.instance.client.auth.signOut();
      } catch (_) {}

      if (!mounted) return;
      Navigator.pushNamedAndRemoveUntil(
          context, '/role_select', (route) => false);
    } catch (e) {
      if (!mounted) return;
      setState(() => _isDeleting = false);
      ErrorUI.showSnack(
        context,
        AppError.from(e, onRetry: _confirmDeleteAccount),
      );
    }
  }

  // ============================================================
  // BUILD
  // ============================================================
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _Palette.cream,
      appBar: AppBar(
        backgroundColor: _Palette.cream,
        elevation: 0,
        iconTheme: const IconThemeData(color: _Palette.ink),
        title: Text(
          tr('Privacy'),
          style: TextStyle(
            color: _Palette.ink,
            fontWeight: FontWeight.bold,
            fontSize: 22,
          ),
        ),
      ),
      body: _isLoading
          ? const Center(
              child: CircularProgressIndicator(color: _Palette.accent))
          : SafeArea(
              child: ListView(
                padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
                children: [
                  _sectionCard(
                    children: [
                      _rowTile(
                        asset: AppImages.barChart,
                        title: tr('Tracking services'),
                        subtitle: tr('Manage permission settings'),
                        onTap: _openTrackingServices,
                      ),
                      _divider(),
                      _rowTile(
                        asset: AppImages.shieldInfo,
                        title: tr('Your personal data'),
                        subtitle: _isExporting
                            ? 'Preparing your export…'
                            : 'Download a copy of your data',
                        onTap: _isExporting ? null : _exportPersonalData,
                        trailing: _isExporting
                            ? const SizedBox(
                                width: 20,
                                height: 20,
                                child: CircularProgressIndicator(
                                    strokeWidth: 2,
                                    color: _Palette.blue),
                              )
                            : null,
                      ),
                      _divider(),
                      _rowTile(
                        asset: AppImages.lock,
                        title: tr('Delete account'),
                        subtitle: tr('Permanently remove your account'),
                        onTap: _isDeleting ? null : _confirmDeleteAccount,
                        titleColor: _Palette.danger,
                        iconTint: _Palette.danger,
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),
                  Center(
                    child: Text(
                      tr('We never sell your personal data.'),
                      style: TextStyle(
                        fontSize: 13,
                        color: _Palette.inkMuted,
                      ),
                    ),
                  ),
                ],
              ),
            ),
    );
  }

  Widget _sectionCard({required List<Widget> children}) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: _Palette.divider),
      ),
      child: Column(children: children),
    );
  }

  Widget _divider() => const Divider(
        height: 1,
        thickness: 1,
        color: _Palette.divider,
        indent: 56,
      );

  Widget _rowTile({
    required String asset,
    required String title,
    required String subtitle,
    required VoidCallback? onTap,
    Color? iconTint,
    Color? titleColor,
    Widget? trailing,
  }) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(16),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
          child: Row(
            children: [
              AppImage(
                asset,
                size: 24,
                tint: iconTint,
                fallbackIcon: Icons.circle_outlined,
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w600,
                        color: titleColor ?? _Palette.ink,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      subtitle,
                      style: const TextStyle(
                          fontSize: 13.5, color: _Palette.inkMuted),
                    ),
                  ],
                ),
              ),
              trailing ??
                  const Icon(Icons.chevron_right,
                      color: _Palette.inkMuted, size: 22),
            ],
          ),
        ),
      ),
    );
  }
}
