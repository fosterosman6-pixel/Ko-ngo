// lib/screens/customer/customer_food_screen.dart
//
// Food landing: lists real partners from the DB.

import 'dart:async';
import 'package:flutter/material.dart';
import 'package:efuride_app/utils/search_match.dart';
import 'package:efuride_app/config/country_config.dart';
import 'package:efuride_app/config/efuride_palette.dart';
import 'package:efuride_app/utils/app_error.dart';
import 'package:efuride_app/l10n/app_strings.dart';
import 'package:efuride_app/models/partner.dart';
import 'package:efuride_app/services/order_service.dart';
import 'package:efuride_app/widgets/app_image.dart';

class CustomerFoodScreen extends StatefulWidget {
  const CustomerFoodScreen({super.key});

  @override
  State<CustomerFoodScreen> createState() => _CustomerFoodScreenState();
}

class _CustomerFoodScreenState extends State<CustomerFoodScreen> {
  final _searchCtrl = TextEditingController();
  final _scrollCtrl = ScrollController();

  Timer? _debounce;
  List<Partner> _all = [];
  bool _loading = true;
  Object? _error;

  @override
  void initState() {
    super.initState();
    _load();
    _searchCtrl.addListener(_onSearchChanged);
  }

  @override
  void dispose() {
    _debounce?.cancel();
    _searchCtrl.removeListener(_onSearchChanged);
    _searchCtrl.dispose();
    _scrollCtrl.dispose();
    super.dispose();
  }

  void _onSearchChanged() {
    _debounce?.cancel();
    _debounce = Timer(const Duration(milliseconds: 250), () {
      if (mounted) {
        setState(() {});
        _loadProductHits(_searchCtrl.text.trim());
      }
    });
  }

  Future<void> _load() async {
    setState(() { _loading = true; _error = null; });
    try {
      final rows = await OrderService.instance.fetchPartners(
        category: 'restaurant',
      );
      if (!mounted) return;
      setState(() {
        _all = rows;
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() { _error = e; _loading = false; });
    }
  }

  /// Stores that sell a product matching the search (filled after typing).
  Set<String> _productHits = {};
  String _hitsFor = '';

  Future<void> _loadProductHits(String q) async {
    if (q.trim().length < 2) {
      if (_productHits.isNotEmpty) setState(() => _productHits = {});
      _hitsFor = '';
      return;
    }
    _hitsFor = q;
    final ids = await OrderService.instance.storeIdsSellingProduct(q);
    if (!mounted || _hitsFor != q) return;
    setState(() => _productHits = ids);
  }

  List<Partner> get _filtered {
    final q = _searchCtrl.text.trim();
    if (q.isEmpty) return _all;
    return _all
        .where((p) =>
            searchMatches(q, [p.name, p.address, p.description]) ||
            _productHits.contains(p.id))
        .toList();
  }

  void _openPartner(Partner p) {
    Navigator.pushNamed(
      context,
      '/customer_restaurant',
      arguments: {
        'id':      p.id,
        'name':    p.name,
        'address': p.address ?? '',
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final t = S.of(context);
    // Its own page (opened from Home), so it needs its own Scaffold:
    // without one the screen turns black and texts get yellow underlines.
    return Scaffold(
      backgroundColor: EfuridePalette.cream,
      body: Column(
        children: [
          _header(t),
          Expanded(
            child: RefreshIndicator(
              color: EfuridePalette.merchantAccent,
              onRefresh: _load,
              child: _body(t),
            ),
          ),
        ],
      ),
    );
  }

  // ── Header ────────────────────────────────────────────────────
  Widget _header(S t) {
    return Container(
      decoration: const BoxDecoration(
        color: EfuridePalette.cream,
      ),
      child: SafeArea(
        bottom: false,
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 10, 16, 14),
              child: Row(
                children: [
                  Container(
                    width: 40, height: 40,
                    decoration: const BoxDecoration(
                      color: Colors.white, shape: BoxShape.circle,
                    ),
                    child: Center(
                      child: Image.asset('assets/images/food.png',
                          width: 28, height: 28),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(tr('KO!NGO'),
                          style: TextStyle(
                            color: EfuridePalette.ink,
                            fontSize: 18,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 1.4,
                            height: 1.05,
                          )),
                      SizedBox(height: 2),
                      Text(tr('Food delivery'),
                          style: TextStyle(
                            color: EfuridePalette.inkMuted,
                            fontSize: 13.5,
                            fontWeight: FontWeight.w500,
                          )),
                    ],
                  ),
                ],
              ),
            ),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 18),
              decoration: const BoxDecoration(
                color: EfuridePalette.cream,
                borderRadius: BorderRadius.only(
                  topLeft:  Radius.circular(24),
                  topRight: Radius.circular(24),
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(t.t('hungry'),
                      style: const TextStyle(
                          color: EfuridePalette.inkMuted, fontSize: 14)),
                  const SizedBox(height: 2),
                  Text(t.t('order_in_minutes'),
                      style: const TextStyle(
                        color: EfuridePalette.ink,
                        fontSize: 22,
                        fontWeight: FontWeight.w900,
                        letterSpacing: -0.3,
                      )),
                  const SizedBox(height: 14),
                  Container(
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(14),
                    ),
                    child: TextField(
                      controller: _searchCtrl,
                      style: const TextStyle(
                        fontSize: 14,
                        color: EfuridePalette.ink,
                      ),
                      decoration: InputDecoration(
                        hintText: t.t('search_restaurants'),
                        hintStyle: const TextStyle(
                          fontSize: 14.5,
                          color: EfuridePalette.inkMuted,
                        ),
                        prefixIcon: const Icon(Icons.search,
                            color: EfuridePalette.inkMuted, size: 20),
                        border: InputBorder.none,
                        contentPadding: const EdgeInsets.symmetric(
                            horizontal: 12, vertical: 16),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ── Body ──────────────────────────────────────────────────────
  Widget _body(S t) {
    if (_loading) {
      return const Center(
        child: CircularProgressIndicator(
            color: EfuridePalette.merchantAccent),
      );
    }

    if (_error != null) {
      return ListView(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.all(24),
        children: [
          const SizedBox(height: 60),
          Icon(Icons.wifi_off_rounded,
              size: 56, color: Colors.grey.shade400),
          const SizedBox(height: 16),
          Center(
            child: Text(tr('Could not load restaurants'),
                style: TextStyle(
                    fontSize: 15, fontWeight: FontWeight.w700)),
          ),
          const SizedBox(height: 6),
          Center(
            child: Text(AppError.from(_error!).message,
                textAlign: TextAlign.center,
                style: const TextStyle(
                    fontSize: 13.5, color: EfuridePalette.inkMuted)),
          ),
          const SizedBox(height: 8),
          Center(
            child: TextButton(
              onPressed: _load,
              child: Text(tr('Retry')),
            ),
          ),
        ],
      );
    }

    final list = _filtered;

    if (_all.isEmpty) {
      return ListView(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.all(24),
        children: [
          const SizedBox(height: 60),
          Icon(Icons.restaurant_outlined,
              size: 56, color: Colors.grey.shade400),
          const SizedBox(height: 16),
          Center(
            child: Text(tr('No restaurants nearby yet'),
                style: TextStyle(
                    fontSize: 15, fontWeight: FontWeight.w700)),
          ),
          const SizedBox(height: 6),
          Center(
            child: Text(tr('Check back soon'),
                style:
                    TextStyle(fontSize: 14, color: Color(0xFF575047))),
          ),
        ],
      );
    }

    if (list.isEmpty) {
      return ListView(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.all(24),
        children: [
          const SizedBox(height: 60),
          Icon(Icons.search_off_rounded,
              size: 56, color: Colors.grey.shade400),
          const SizedBox(height: 16),
          Center(
            child: Text(t.t('no_restaurants_found'),
                style: const TextStyle(
                    fontSize: 15, fontWeight: FontWeight.w700)),
          ),
        ],
      );
    }

    return ListView.builder(
      controller: _scrollCtrl,
      physics: const AlwaysScrollableScrollPhysics(),
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
      itemCount: list.length + 1,
      itemBuilder: (_, i) {
        if (i == 0) return _sectionLabel(t.t('restaurants_near_you'));
        return _partnerCard(list[i - 1], t);
      },
    );
  }

  Widget _sectionLabel(String s) => Padding(
        padding: const EdgeInsets.only(left: 4, bottom: 10),
        child: Text(s,
            style: const TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.w800,
              color: EfuridePalette.ink,
            )),
      );

  // ── Partner card ──────────────────────────────────────────────
  Widget _partnerCard(Partner p, S t) {
    return InkWell(
      onTap: () => _openPartner(p),
      borderRadius: BorderRadius.circular(16),
      child: Container(
        margin: const EdgeInsets.only(bottom: 12),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: EfuridePalette.divider),
        ),
        child: Column(
          children: [
            // ── Cover ──
            Container(
              height: 110,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    EfuridePalette.merchantAccent.withValues(alpha: 0.20),
                    EfuridePalette.merchantAccent.withValues(alpha: 0.05),
                  ],
                ),
                borderRadius: const BorderRadius.only(
                  topLeft:  Radius.circular(15),
                  topRight: Radius.circular(15),
                ),
              ),
              child: Stack(
                children: [
                  if (p.coverUrl != null && p.coverUrl!.isNotEmpty)
                    Positioned.fill(
                      child: ClipRRect(
                        borderRadius: const BorderRadius.only(
                          topLeft:  Radius.circular(15),
                          topRight: Radius.circular(15),
                        ),
                        child: Image.network(p.coverUrl!, fit: BoxFit.cover),
                      ),
                    )
                  else
                    Center(
                      child: Image.asset('assets/images/food.png',
                          width: 84, height: 84),
                    ),
                  if (p.isVerified)
                    Positioned(
                      top: 10, left: 10,
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 8, vertical: 4),
                        decoration: BoxDecoration(
                          color: EfuridePalette.merchantAccent,
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Text(tr('VERIFIED'),
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 12,
                              fontWeight: FontWeight.w900,
                              letterSpacing: 0.4,
                            )),
                      ),
                    ),
                  if (!p.isOpen)
                    Positioned.fill(
                      child: Container(
                        decoration: BoxDecoration(
                          color: Colors.black.withValues(alpha: 0.55),
                          borderRadius: const BorderRadius.only(
                            topLeft:  Radius.circular(15),
                            topRight: Radius.circular(15),
                          ),
                        ),
                        child: Center(
                          child: Text(tr('CLOSED'),
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 16,
                                fontWeight: FontWeight.w900,
                                letterSpacing: 1.5,
                              )),
                        ),
                      ),
                    ),
                ],
              ),
            ),

            // ── Details ──
            Padding(
              padding: const EdgeInsets.all(14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Text(p.name,
                            style: const TextStyle(
                              fontSize: 15,
                              fontWeight: FontWeight.w900,
                              color: EfuridePalette.ink,
                            ),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis),
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 6, vertical: 3),
                        decoration: BoxDecoration(
                          color: EfuridePalette.accent.withValues(alpha: 0.15),
                          borderRadius: BorderRadius.circular(6),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const Icon(Icons.star,
                                size: 11, color: EfuridePalette.accent),
                            const SizedBox(width: 3),
                            Text(p.rating.toStringAsFixed(1),
                                style: const TextStyle(
                                  fontSize: 13,
                                  fontWeight: FontWeight.w900,
                                  color: EfuridePalette.ink,
                                )),
                          ],
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 4),
                  Text(
                    [p.categoryLabel, if ((p.address ?? '').isNotEmpty) p.address!]
                        .join(' · '),
                    style: const TextStyle(
                      fontSize: 13.5,
                      color: EfuridePalette.inkMuted,
                      fontWeight: FontWeight.w500,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 10),
                  Row(
                    children: [
                      _meta(Icons.access_time,
                          '${p.prepMinutes} ${t.t('min')}'),
                      const SizedBox(width: 12),
                      _meta(Icons.delivery_dining,
                          CountryConfig.money(p.deliveryFee)),
                      const Spacer(),
                      Text('${t.t('min_order')} ${CountryConfig.money(p.minOrder)}',
                          style: const TextStyle(
                            fontSize: 13,
                            color: EfuridePalette.inkMuted,
                            fontWeight: FontWeight.w700,
                          )),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _meta(IconData i, String label) => Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(i, size: 12, color: EfuridePalette.inkMuted),
          const SizedBox(width: 4),
          Text(label,
              style: const TextStyle(
                  fontSize: 13,
                  color: EfuridePalette.inkMuted,
                  fontWeight: FontWeight.w600)),
        ],
      );
}
