﻿// lib/screens/customer/customer_profile_screen.dart

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:efuride_app/utils/app_error.dart';
import 'package:efuride_app/utils/error_ui.dart';
import 'package:efuride_app/l10n/app_strings.dart';
import 'package:efuride_app/widgets/k_icon.dart';

class _Palette {
  static const cream = Color(0xFFFAF6EE);
  static const ink = Color(0xFF1A1A1A);
  static const inkMuted = Color(0xFF575047);
  static const accent = Color(0xFFF2B705);
  static const divider = Color(0xFFE8E2D5);
  static const blue = Color(0xFF1E88E5);
  static const danger = Color(0xFFE53935);
}

class CustomerProfileScreen extends StatefulWidget {
  const CustomerProfileScreen({super.key});

  @override
  State<CustomerProfileScreen> createState() => _CustomerProfileScreenState();
}

class _CustomerProfileScreenState extends State<CustomerProfileScreen> {
  final _picker = ImagePicker();

  Map<String, dynamic>? _profile;
  String? _avatarUrl;
  bool _isLoading = true;
  bool _isUploadingAvatar = false;
  AppError? _error;

  @override
  void initState() {
    super.initState();
    _loadProfile();
  }

  Future<void> _loadProfile() async {
    setState(() {
      _isLoading = true;
      _error = null;
    });

    try {
      final userId = Supabase.instance.client.auth.currentUser?.id;
      if (userId == null) {
        if (mounted) setState(() => _isLoading = false);
        return;
      }
      final res = await Supabase.instance.client
          .from('profiles')
          .select()
          .eq('id', userId)
          .maybeSingle();

      if (!mounted) return;
      setState(() {
        _profile = res;
        _avatarUrl =
            (res?['profile_picture_url'] ?? res?['avatar_url'])?.toString();
        _isLoading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _isLoading = false;
        _error = AppError.from(e, onRetry: _loadProfile);
      });
    }
  }

  String get _displayName {
    final p = _profile;
    if (p == null) return 'Loading...';
    final full = (p['full_name'] ?? '').toString().trim();
    if (full.isNotEmpty) return full;
    final first = (p['first_name'] ?? '').toString().trim();
    final surname = (p['surname'] ?? '').toString().trim();
    final combined = '$first $surname'.trim();
    if (combined.isNotEmpty) return combined;
    return (p['email'] ?? 'Customer').toString().split('@').first;
  }

  String get _displayEmail =>
      (_profile?['email'] ?? 'No email').toString();

  String get _displayPhone {
    final phone = (_profile?['phone_number'] ?? '').toString().trim();
    return phone.isEmpty ? 'No phone number' : phone;
  }

  // ============================================================
  // AVATAR
  // ============================================================
  Future<void> _pickAndUploadAvatar() async {
    try {
      final image = await _picker.pickImage(
        source: ImageSource.gallery,
        maxWidth: 800,
        maxHeight: 800,
        imageQuality: 85,
      );
      if (image == null) return;

      setState(() => _isUploadingAvatar = true);

      final userId = Supabase.instance.client.auth.currentUser?.id;
      if (userId == null) throw Exception('Not signed in');

      final bytes = await image.readAsBytes();
      final ext =
          image.name.contains('.') ? image.name.split('.').last : 'jpg';
      final path = '$userId/avatar.$ext';

      await Supabase.instance.client.storage.from('avatars').uploadBinary(
            path,
            bytes,
            fileOptions: const FileOptions(upsert: true),
          );

      final publicUrl = Supabase.instance.client.storage
          .from('avatars')
          .getPublicUrl(path);

      await Supabase.instance.client.from('profiles').update({
        'profile_picture_url': publicUrl,
        'avatar_url': publicUrl,
      }).eq('id', userId);

      if (!mounted) return;
      setState(() {
        _avatarUrl = publicUrl;
        _isUploadingAvatar = false;
      });

      ErrorUI.showSnack(
        context,
        AppError(
          title: tr('Photo updated'),
          message: tr('Your new profile photo is live.'),
          icon: Icons.check_circle_outline,
        ),
      );
    } catch (e) {
      if (!mounted) return;
      setState(() => _isUploadingAvatar = false);
      ErrorUI.showSnack(
        context,
        AppError.from(e, onRetry: _pickAndUploadAvatar),
      );
    }
  }

  // ============================================================
  // EDIT NAME
  // ============================================================
  Future<void> _editName() async {
    final firstCtrl = TextEditingController(
        text: (_profile?['first_name'] ?? '').toString());
    final surnameCtrl = TextEditingController(
        text: (_profile?['surname'] ?? '').toString());
    bool saving = false;

    final saved = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setD) => AlertDialog(
          shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(16)),
          title: Text(tr('Edit name')),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: firstCtrl,
                textCapitalization: TextCapitalization.words,
                decoration: InputDecoration(
                  labelText: tr('First name'),
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: surnameCtrl,
                textCapitalization: TextCapitalization.words,
                decoration: InputDecoration(
                  labelText: tr('Surname'),
                  border: OutlineInputBorder(),
                ),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: saving ? null : () => Navigator.pop(ctx, false),
              child: Text(tr('Cancel')),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFFF2B705),
                foregroundColor: const Color(0xFF0B1220),
              ),
              onPressed: saving
                  ? null
                  : () async {
                      if (firstCtrl.text.trim().isEmpty) {
                        ErrorUI.showSnack(
                          ctx,
                          AppError(
                            title: tr('First name required'),
                            message: tr('Please enter your first name.'),
                            icon: Icons.info_outline,
                          ),
                        );
                        return;
                      }
                      setD(() => saving = true);
                      try {
                        final userId = Supabase
                            .instance.client.auth.currentUser?.id;
                        if (userId == null) {
                          throw Exception('Not signed in');
                        }
                        final first = firstCtrl.text.trim();
                        final surname = surnameCtrl.text.trim();
                        await Supabase.instance.client
                            .from('profiles')
                            .update({
                          'first_name': first,
                          'surname': surname,
                          'full_name': '$first $surname'.trim(),
                        }).eq('id', userId);

                        if (!mounted) return;
                        Navigator.pop(ctx, true);
                      } catch (e) {
                        setD(() => saving = false);
                        if (!ctx.mounted) return;
                        ErrorUI.showSnack(ctx, AppError.from(e));
                      }
                    },
              child: saving
                  ? const SizedBox(
                      width: 16,
                      height: 16,
                      child: CircularProgressIndicator(
                          strokeWidth: 2, color: Colors.white),
                    )
                  : Text(tr('Save')),
            ),
          ],
        ),
      ),
    );

    if (saved == true) {
      await _loadProfile();
      if (mounted) {
        ErrorUI.showSnack(
          context,
          AppError(
            title: tr('Name updated'),
            message: tr('Your name has been saved.'),
            icon: Icons.check_circle_outline,
          ),
        );
      }
    }
  }

  // ============================================================
  // CHANGE EMAIL
  // ============================================================
  Future<void> _changeEmail() async {
    final emailCtrl = TextEditingController(text: _displayEmail);
    bool saving = false;

    final saved = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setD) => AlertDialog(
          shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(16)),
          title: Text(tr('Change email')),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'We\'ll send a confirmation link to your new email. '
                'The change takes effect after you click it.',
                style: TextStyle(fontSize: 13.5, color: _Palette.inkMuted),
              ),
              const SizedBox(height: 16),
              TextField(
                controller: emailCtrl,
                keyboardType: TextInputType.emailAddress,
                autocorrect: false,
                decoration: InputDecoration(
                  labelText: tr('New email'),
                  border: OutlineInputBorder(),
                ),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: saving ? null : () => Navigator.pop(ctx, false),
              child: Text(tr('Cancel')),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFFF2B705),
                foregroundColor: const Color(0xFF0B1220),
              ),
              onPressed: saving
                  ? null
                  : () async {
                      final email = emailCtrl.text.trim();
                      if (!email.contains('@') || !email.contains('.')) {
                        ErrorUI.showSnack(
                          ctx,
                          AppError(
                            title: tr('Invalid email'),
                            message: tr('Please enter a valid email address.'),
                            icon: Icons.info_outline,
                          ),
                        );
                        return;
                      }
                      setD(() => saving = true);
                      try {
                        await Supabase.instance.client.auth
                            .updateUser(UserAttributes(email: email));
                        if (!mounted) return;
                        Navigator.pop(ctx, true);
                      } catch (e) {
                        setD(() => saving = false);
                        if (!ctx.mounted) return;
                        ErrorUI.showSnack(ctx, AppError.from(e));
                      }
                    },
              child: saving
                  ? const SizedBox(
                      width: 16,
                      height: 16,
                      child: CircularProgressIndicator(
                          strokeWidth: 2, color: Colors.white),
                    )
                  : Text(tr('Send link')),
            ),
          ],
        ),
      ),
    );

    if (saved == true && mounted) {
      ErrorUI.showSnack(
        context,
        AppError(
          title: tr('Check your inbox'),
          message:
              tr('We sent a confirmation link to your new email address.'),
          icon: Icons.mark_email_read_outlined,
        ),
      );
    }
  }

  // ============================================================
  // CHANGE PHONE NUMBER
  // ============================================================
  Future<void> _changePhone() async {
    final phoneCtrl = TextEditingController(
      text: (_profile?['phone_number'] ?? '').toString(),
    );
    bool saving = false;

    final saved = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setD) => AlertDialog(
          shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(16)),
          title: Text(tr('Change phone number')),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                tr('We use your phone for trip updates and driver contact.'),
                style: TextStyle(fontSize: 13.5, color: _Palette.inkMuted),
              ),
              const SizedBox(height: 16),
              TextField(
                controller: phoneCtrl,
                keyboardType: TextInputType.phone,
                inputFormatters: [
                  FilteringTextInputFormatter.allow(
                      RegExp(r'[0-9+\-\s()]')),
                ],
                decoration: InputDecoration(
                  labelText: tr('Phone number'),
                  hintText: '+27 82 123 4567',
                  border: OutlineInputBorder(),
                ),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: saving ? null : () => Navigator.pop(ctx, false),
              child: Text(tr('Cancel')),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFFF2B705),
                foregroundColor: const Color(0xFF0B1220),
              ),
              onPressed: saving
                  ? null
                  : () async {
                      final phone = phoneCtrl.text.trim();
                      if (phone.length < 7) {
                        ErrorUI.showSnack(
                          ctx,
                          AppError(
                            title: tr('Invalid phone'),
                            message: tr('Please enter a valid phone number.'),
                            icon: Icons.info_outline,
                          ),
                        );
                        return;
                      }
                      setD(() => saving = true);
                      try {
                        final userId = Supabase
                            .instance.client.auth.currentUser?.id;
                        if (userId == null) {
                          throw Exception('Not signed in');
                        }
                        await Supabase.instance.client
                            .from('profiles')
                            .update({'phone_number': phone}).eq('id', userId);

                        if (!mounted) return;
                        Navigator.pop(ctx, true);
                      } catch (e) {
                        setD(() => saving = false);
                        if (!ctx.mounted) return;
                        ErrorUI.showSnack(ctx, AppError.from(e));
                      }
                    },
              child: saving
                  ? const SizedBox(
                      width: 16,
                      height: 16,
                      child: CircularProgressIndicator(
                          strokeWidth: 2, color: Colors.white),
                    )
                  : Text(tr('Save')),
            ),
          ],
        ),
      ),
    );

    if (saved == true) {
      await _loadProfile();
      if (mounted) {
        ErrorUI.showSnack(
          context,
          AppError(
            title: tr('Phone updated'),
            message: tr('Your phone number has been saved.'),
            icon: Icons.check_circle_outline,
          ),
        );
      }
    }
  }

  // ============================================================
  // CHANGE PASSWORD
  // ============================================================
  Future<void> _changePassword() async {
    final oldCtrl = TextEditingController();
    final newCtrl = TextEditingController();
    final confirmCtrl = TextEditingController();

    bool saving = false;
    bool obscureOld = true;
    bool obscureNew = true;
    bool obscureConfirm = true;

    final saved = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setD) => AlertDialog(
          shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(16)),
          title: Text(tr('Change password')),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: oldCtrl,
                  obscureText: obscureOld,
                  decoration: InputDecoration(
                    labelText: tr('Current password'),
                    border: const OutlineInputBorder(),
                    suffixIcon: IconButton(
                      icon: Icon(obscureOld
                          ? Icons.visibility_off
                          : Icons.visibility),
                      onPressed: () =>
                          setD(() => obscureOld = !obscureOld),
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: newCtrl,
                  obscureText: obscureNew,
                  decoration: InputDecoration(
                    labelText: tr('New password'),
                    helperText: tr('At least 8 characters'),
                    border: const OutlineInputBorder(),
                    suffixIcon: IconButton(
                      icon: Icon(obscureNew
                          ? Icons.visibility_off
                          : Icons.visibility),
                      onPressed: () =>
                          setD(() => obscureNew = !obscureNew),
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: confirmCtrl,
                  obscureText: obscureConfirm,
                  decoration: InputDecoration(
                    labelText: tr('Confirm new password'),
                    border: const OutlineInputBorder(),
                    suffixIcon: IconButton(
                      icon: Icon(obscureConfirm
                          ? Icons.visibility_off
                          : Icons.visibility),
                      onPressed: () =>
                          setD(() => obscureConfirm = !obscureConfirm),
                    ),
                  ),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: saving ? null : () => Navigator.pop(ctx, false),
              child: Text(tr('Cancel')),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFFF2B705),
                foregroundColor: const Color(0xFF0B1220),
              ),
              onPressed: saving
                  ? null
                  : () async {
                      final old = oldCtrl.text;
                      final nw = newCtrl.text;
                      final conf = confirmCtrl.text;

                      if (nw.length < 8) {
                        ErrorUI.showSnack(
                          ctx,
                          AppError(
                            title: tr('Password too short'),
                            message:
                                tr('Password must be at least 8 characters.'),
                            icon: Icons.info_outline,
                          ),
                        );
                        return;
                      }
                      if (nw != conf) {
                        ErrorUI.showSnack(
                          ctx,
                          AppError(
                            title: tr('Passwords don\'t match'),
                            message:
                                tr('Make sure both passwords are identical.'),
                            icon: Icons.info_outline,
                          ),
                        );
                        return;
                      }

                      setD(() => saving = true);
                      try {
                        // Verify old password by re-signing in.
                        final email = Supabase
                            .instance.client.auth.currentUser?.email;
                        if (email == null) {
                          throw Exception('No email on account');
                        }

                        await Supabase.instance.client.auth
                            .signInWithPassword(
                                email: email, password: old);

                        await Supabase.instance.client.auth
                            .updateUser(UserAttributes(password: nw));

                        if (!mounted) return;
                        Navigator.pop(ctx, true);
                      } catch (e) {
                        setD(() => saving = false);
                        if (!ctx.mounted) return;
                        ErrorUI.showSnack(ctx, AppError.from(e));
                      }
                    },
              child: saving
                  ? const SizedBox(
                      width: 16,
                      height: 16,
                      child: CircularProgressIndicator(
                          strokeWidth: 2, color: Colors.white),
                    )
                  : Text(tr('Save')),
            ),
          ],
        ),
      ),
    );

    if (saved == true && mounted) {
      ErrorUI.showSnack(
        context,
        AppError(
          title: tr('Password changed'),
          message: tr('Use your new password next time you log in.'),
          icon: Icons.lock_outline,
        ),
      );
    }
  }

  // ============================================================
  // BUILD
  // ============================================================
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _Palette.cream,
      appBar: AppBar(
        backgroundColor: _Palette.cream,
        elevation: 0,
        iconTheme: const IconThemeData(color: _Palette.ink),
        title: Text(
          tr('Profile'),
          style: TextStyle(
            color: _Palette.ink,
            fontWeight: FontWeight.bold,
            fontSize: 20,
          ),
        ),
      ),
      body: _isLoading
          ? const Center(
              child: CircularProgressIndicator(color: _Palette.accent))
          : _error != null
              ? ErrorUI.inline(_error!)
              : SafeArea(
                  child: SingleChildScrollView(
                    padding: const EdgeInsets.all(20),
                    child: Column(
                      children: [
                        // ------- AVATAR -------
                        Center(
                          child: GestureDetector(
                            onTap: _pickAndUploadAvatar,
                            child: Stack(
                              children: [
                                CircleAvatar(
                                  radius: 60,
                                  backgroundColor: _Palette.cream,
                                  backgroundImage:
                                      (_avatarUrl != null &&
                                              _avatarUrl!.isNotEmpty)
                                          ? NetworkImage(_avatarUrl!)
                                          : null,
                                  child: (_avatarUrl == null ||
                                          _avatarUrl!.isEmpty)
                                      ? Text(
                                          _displayName.isNotEmpty
                                              ? _displayName[0]
                                                  .toUpperCase()
                                              : '?',
                                          style: const TextStyle(
                                              fontSize: 40,
                                              color: _Palette.blue,
                                              fontWeight: FontWeight.bold),
                                        )
                                      : null,
                                ),
                                Positioned(
                                  bottom: 0,
                                  right: 0,
                                  child: Container(
                                    padding: const EdgeInsets.all(8),
                                    decoration: const BoxDecoration(
                                      color: Colors.black87,
                                      shape: BoxShape.circle,
                                    ),
                                    child: _isUploadingAvatar
                                        ? const SizedBox(
                                            width: 18,
                                            height: 18,
                                            child:
                                                CircularProgressIndicator(
                                                    strokeWidth: 2,
                                                    color: Colors.white),
                                          )
                                        : const KIcon(Icons.camera_alt,
                                            color: Colors.white, size: 18),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        const SizedBox(height: 16),
                        Text(
                          _displayName.toUpperCase(),
                          textAlign: TextAlign.center,
                          style: const TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                            color: _Palette.ink,
                          ),
                        ),
                        const SizedBox(height: 6),
                        Text(
                          _displayEmail,
                          style: const TextStyle(
                              fontSize: 14, color: _Palette.inkMuted),
                        ),
                        const SizedBox(height: 2),
                        Text(
                          _displayPhone,
                          style: const TextStyle(
                              fontSize: 14, color: _Palette.inkMuted),
                        ),

                        const SizedBox(height: 24),

                        // ------- ACTION ROWS -------
                        _sectionCard(
                          children: [
                            _rowTile(
                              icon: Icons.edit_outlined,
                              title: tr('Edit name'),
                              onTap: _editName,
                            ),
                            _divider(),
                            _rowTile(
                              icon: Icons.email_outlined,
                              title: tr('Change email'),
                              onTap: _changeEmail,
                            ),
                            _divider(),
                            _rowTile(
                              icon: Icons.phone_outlined,
                              title: tr('Change phone number'),
                              onTap: _changePhone,
                            ),
                            _divider(),
                            _rowTile(
                              icon: Icons.lock_outline,
                              title: tr('Change password'),
                              onTap: _changePassword,
                            ),
                          ],
                        ),

                        const SizedBox(height: 24),
                      ],
                    ),
                  ),
                ),
    );
  }

  Widget _sectionCard({required List<Widget> children}) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: _Palette.divider),
      ),
      child: Column(children: children),
    );
  }

  Widget _divider() => const Divider(
        height: 1,
        thickness: 1,
        color: _Palette.divider,
        indent: 56,
      );

  Widget _rowTile({
    required IconData icon,
    required String title,
    required VoidCallback onTap,
  }) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(16),
        child: Padding(
          padding:
              const EdgeInsets.symmetric(horizontal: 16, vertical: 18),
          child: Row(
            children: [
              Icon(icon, color: _Palette.ink, size: 22),
              const SizedBox(width: 16),
              Expanded(
                child: Text(
                  title,
                  style: const TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.w600,
                    color: _Palette.ink,
                  ),
                ),
              ),
              const Icon(Icons.chevron_right,
                  color: _Palette.inkMuted, size: 22),
            ],
          ),
        ),
      ),
    );
  }
}
