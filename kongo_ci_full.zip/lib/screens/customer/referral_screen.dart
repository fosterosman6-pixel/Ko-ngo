﻿// lib/screens/customer/referral_screen.dart

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:share_plus/share_plus.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:efuride_app/config/country_config.dart';
import 'package:efuride_app/config/app_images.dart';
import 'package:efuride_app/widgets/app_image.dart';
import 'package:efuride_app/utils/app_error.dart';
import 'package:efuride_app/utils/error_ui.dart';
import 'package:efuride_app/l10n/app_strings.dart';
import 'package:efuride_app/widgets/k_icon.dart';

class _Palette {
  static const cream = Color(0xFFFAF6EE);
  static const ink = Color(0xFF1A1A1A);
  static const inkMuted = Color(0xFF575047);
  static const accent = Color(0xFFF2B705);
  static const divider = Color(0xFFE8E2D5);
  static const blue = Color(0xFF1E88E5);
}

class ReferralScreen extends StatefulWidget {
  const ReferralScreen({super.key});

  @override
  State<ReferralScreen> createState() => _ReferralScreenState();
}

class _ReferralScreenState extends State<ReferralScreen> {
  String? _referralCode;
  int _referralCount = 0;
  double _referralEarnings = 0.0;
  bool _isLoading = true;
  AppError? _error;

  @override
  void initState() {
    super.initState();
    _loadReferralData();
  }

  Future<void> _loadReferralData() async {
    setState(() {
      _isLoading = true;
      _error = null;
    });

    try {
      final userId = Supabase.instance.client.auth.currentUser?.id;
      if (userId == null) throw Exception('Not signed in');

      final profile = await Supabase.instance.client
          .from('profiles')
          .select('referral_code')
          .eq('id', userId)
          .maybeSingle();

      String? code = profile?['referral_code']?.toString();
      if (code == null || code.isEmpty) {
        code = 'EFR${userId.substring(0, 6).toUpperCase()}';
      }

      int count = 0;
      double earnings = 0.0;
      try {
        final refs = await Supabase.instance.client
            .from('referrals')
            .select('status, reward_amount')
            .eq('referrer_id', userId);

        for (final r in refs) {
          final status = (r['status'] ?? '').toString().toLowerCase();
          if (status == 'completed' || status == 'credited') {
            count++;
            earnings +=
                ((r['reward_amount'] ?? 50.0) as num).toDouble();
          }
        }
      } catch (e) {
        debugPrint('referrals fetch failed: $e');
      }

      if (!mounted) return;
      setState(() {
        _referralCode = code;
        _referralCount = count;
        _referralEarnings = earnings;
        _isLoading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _isLoading = false;
        _error = AppError.from(e, onRetry: _loadReferralData);
      });
    }
  }

  Future<void> _copyCode() async {
    if (_referralCode == null) return;
    await Clipboard.setData(ClipboardData(text: _referralCode!));
    if (!mounted) return;
    ErrorUI.showSnack(
      context,
      AppError(
        title: tr('Code copied'),
        message: tr('Share it with a friend to earn ride credit.'),
        icon: Icons.check_circle_outline,
      ),
    );
  }

  Future<void> _shareCode() async {
    if (_referralCode == null) return;
    try {
      await Share.share(
        'Use my ko!ngo referral code: $_referralCode\n'
        'We both get credit off our next ride!',
        subject: 'ko!ngo referral',
      );
    } catch (e) {
      if (!mounted) return;
      ErrorUI.showSnack(context, AppError.from(e));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _Palette.cream,
      appBar: AppBar(
        backgroundColor: _Palette.cream,
        elevation: 0,
        iconTheme: const IconThemeData(color: _Palette.ink),
        title: Text(
          tr('Refer & Earn'),
          style: TextStyle(
              color: _Palette.ink,
              fontWeight: FontWeight.bold,
              fontSize: 18),
        ),
      ),
      body: _isLoading
          ? const Center(
              child: CircularProgressIndicator(color: _Palette.accent))
          : _error != null
              ? ErrorUI.inline(_error!)
              : SafeArea(
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(24),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(16),
                            border: Border.all(color: _Palette.divider),
                          ),
                          child: Column(
                            children: [
                              AppImage(
                                AppImages.share,
                                size: 72,
                                fallbackIcon: Icons.share,
                              ),
                              const SizedBox(height: 12),
                              Text(
                                tr('Refer a Friend'),
                                style: TextStyle(
                                    fontSize: 22,
                                    fontWeight: FontWeight.bold,
                                    color: _Palette.ink),
                              ),
                              const SizedBox(height: 6),
                              Text(
                                tr('Share your code and earn ride credit for each friend who takes their first ride.'),
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                    color: _Palette.inkMuted, fontSize: 14),
                              ),
                              const SizedBox(height: 18),
                              Container(
                                padding: const EdgeInsets.all(12),
                                decoration: BoxDecoration(
                                  color: _Palette.cream,
                                  borderRadius: BorderRadius.circular(10),
                                  border: Border.all(color: _Palette.divider),
                                ),
                                child: Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text(
                                      _referralCode ?? '—',
                                      style: const TextStyle(
                                          fontSize: 18,
                                          fontWeight: FontWeight.bold,
                                          letterSpacing: 1.2,
                                          color: _Palette.blue),
                                    ),
                                    IconButton(
                                      icon: const Icon(Icons.copy,
                                          color: _Palette.inkMuted),
                                      onPressed: _copyCode,
                                    ),
                                  ],
                                ),
                              ),
                              const SizedBox(height: 14),
                              ElevatedButton.icon(
                                onPressed: _shareCode,
                                icon: const KIcon(Icons.share),
                                label: Text(tr('Share Referral Link')),
                                style: ElevatedButton.styleFrom(
                                    minimumSize:
                                        const Size(double.infinity, 48),
                                    backgroundColor: const Color(0xFFF2B705),
                                    foregroundColor: const Color(0xFF0B1220)),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 20),
                        Row(
                          children: [
                            Expanded(
                              child: _statCard(
                                'Referrals',
                                '$_referralCount',
                                AppImages.family,
                              ),
                            ),
                            const SizedBox(width: 8),
                            Expanded(
                              child: _statCard(
                                'Earnings',
                                CountryConfig.money(_referralEarnings),
                                AppImages.coinsBlue,
                              ),
                            ),
                          ],
                        ),
                        const Spacer(),
                        Text(
                          tr('Credit is added after your friend\'s first completed ride.'),
                          style: TextStyle(
                              color: _Palette.inkMuted, fontSize: 13),
                          textAlign: TextAlign.center,
                        ),
                      ],
                    ),
                  ),
                ),
    );
  }

  Widget _statCard(String label, String value, String asset) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: _Palette.divider),
      ),
      child: Column(
        children: [
          AppImage(asset, size: 32, fallbackIcon: Icons.circle_outlined),
          const SizedBox(height: 8),
          Text(value,
              style: const TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: _Palette.ink)),
          const SizedBox(height: 2),
          Text(label,
              style: const TextStyle(
                  color: _Palette.inkMuted, fontSize: 13.5)),
        ],
      ),
    );
  }
}
