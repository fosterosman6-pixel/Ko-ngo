﻿// lib/screens/customer/analytics_screen.dart

import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:efuride_app/config/country_config.dart';
import 'package:efuride_app/config/app_images.dart';
import 'package:efuride_app/widgets/app_image.dart';
import 'package:efuride_app/utils/app_error.dart';
import 'package:efuride_app/utils/error_ui.dart';
import 'package:efuride_app/l10n/app_strings.dart';

class _Palette {
  static const cream = Color(0xFFFAF6EE);
  static const ink = Color(0xFF1A1A1A);
  static const inkMuted = Color(0xFF575047);
  static const accent = Color(0xFFF2B705);
  static const divider = Color(0xFFE8E2D5);
  static const blue = Color(0xFF1E88E5);
}

class AnalyticsScreen extends StatefulWidget {
  const AnalyticsScreen({super.key});

  @override
  State<AnalyticsScreen> createState() => _AnalyticsScreenState();
}

class _AnalyticsScreenState extends State<AnalyticsScreen> {
  String _period = 'Week';

  bool _isLoading = true;
  AppError? _error;

  int _rideCount = 0;
  double _distanceKm = 0.0;
  double _totalSpent = 0.0;
  double _avgRating = 0.0;
  int _ratingCount = 0;
  int _loyaltyPoints = 0;

  @override
  void initState() {
    super.initState();
    _loadAnalytics();
  }

  DateTime _periodStart() {
    final now = DateTime.now();
    switch (_period) {
      case 'Day':
        return DateTime(now.year, now.month, now.day);
      case 'Week':
        return now.subtract(const Duration(days: 7));
      case 'Month':
        return DateTime(now.year, now.month, 1);
      case 'Year':
        return DateTime(now.year, 1, 1);
      default:
        return now.subtract(const Duration(days: 7));
    }
  }

  Future<void> _loadAnalytics() async {
    setState(() {
      _isLoading = true;
      _error = null;
    });

    try {
      final userId = Supabase.instance.client.auth.currentUser?.id;
      if (userId == null) throw Exception('Not signed in');

      final start = _periodStart();

      final rides = await Supabase.instance.client
          .from('rides')
          .select(
              'fare, distance_km, customer_rating, status, created_at')
          .eq('customer_id', userId)
          .eq('status', 'completed')
          .gte('created_at', start.toUtc().toIso8601String());

      int count = 0;
      double distance = 0.0;
      double spent = 0.0;
      double ratingSum = 0.0;
      int ratings = 0;

      for (final r in rides) {
        count++;
        distance += ((r['distance_km'] ?? 0) as num).toDouble();
        spent += ((r['fare'] ?? 0) as num).toDouble();
        final rating = (r['customer_rating'] as num?)?.toDouble();
        if (rating != null) {
          ratingSum += rating;
          ratings++;
        }
      }

      final profile = await Supabase.instance.client
          .from('profiles')
          .select('loyalty_points')
          .eq('id', userId)
          .maybeSingle();

      if (!mounted) return;
      setState(() {
        _rideCount = count;
        _distanceKm = distance;
        _totalSpent = spent;
        _avgRating = ratings > 0 ? ratingSum / ratings : 0;
        _ratingCount = ratings;
        _loyaltyPoints =
            (profile?['loyalty_points'] as num?)?.toInt() ?? 0;
        _isLoading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _isLoading = false;
        _error = AppError.from(e, onRetry: _loadAnalytics);
      });
    }
  }

  String _periodLabel() {
    switch (_period) {
      case 'Day':
        return 'today';
      case 'Week':
        return 'this week';
      case 'Month':
        return 'this month';
      case 'Year':
        return 'this year';
      default:
        return '';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _Palette.cream,
      appBar: AppBar(
        backgroundColor: _Palette.cream,
        elevation: 0,
        iconTheme: const IconThemeData(color: _Palette.ink),
        title: Text(
          tr('Analytics'),
          style: TextStyle(
              color: _Palette.ink,
              fontWeight: FontWeight.bold,
              fontSize: 18),
        ),
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            children: [
              Container(
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(30),
                  border: Border.all(color: _Palette.divider),
                ),
                child: SegmentedButton<String>(
                  segments: [
                    ButtonSegment(value: 'Day', label: Text(tr('Day'))),
                    ButtonSegment(value: 'Week', label: Text(tr('Week'))),
                    ButtonSegment(value: 'Month', label: Text(tr('Month'))),
                    ButtonSegment(value: 'Year', label: Text(tr('Year'))),
                  ],
                  selected: {_period},
                  style: SegmentedButton.styleFrom(
                    backgroundColor: Colors.white,
                    selectedBackgroundColor: _Palette.accent,
                    selectedForegroundColor: const Color(0xFF0B1220),
                    foregroundColor: _Palette.inkMuted,
                  ),
                  onSelectionChanged: (s) {
                    setState(() => _period = s.first);
                    _loadAnalytics();
                  },
                ),
              ),
              const SizedBox(height: 16),
              Expanded(
                child: _isLoading
                    ? const Center(
                        child: CircularProgressIndicator(
                            color: _Palette.accent))
                    : _error != null
                        ? ErrorUI.inline(_error!)
                        : _buildContent(),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildContent() {
    final label = _periodLabel();
    return ListView(
      children: [
        _statCard(
          'Rides $label',
          '$_rideCount',
          Icons.directions_car,
          _Palette.blue,
          _rideCount == 0 ? 'No rides in this period' : 'Completed trips',
          asset: AppImages.driverSedan,
        ),
        _statCard(
          'Distance $label',
          '${_distanceKm.toStringAsFixed(1)} km',
          Icons.straighten,
          const Color(0xFF34C759),
          'Total travelled',
        ),
        _statCard(
          'Average rating',
          _ratingCount > 0
              ? '${_avgRating.toStringAsFixed(1)} ⭐'
              : '—',
          Icons.star,
          const Color(0xFFF2B705),
          _ratingCount > 0
              ? 'Based on $_ratingCount rating${_ratingCount == 1 ? '' : 's'}'
              : 'No ratings yet',
        ),
        _statCard(
          'Spent $label',
          CountryConfig.money(_totalSpent),
          Icons.attach_money,
          const Color(0xFFFF9800),
          'Across completed rides',
          asset: AppImages.coinsBlue,
        ),
        _statCard(
          'Loyalty points',
          '$_loyaltyPoints',
          Icons.card_giftcard,
          const Color(0xFF9C27B0),
          'Lifetime points balance',
          asset: AppImages.gift,
        ),
      ],
    );
  }

  Widget _statCard(
    String label,
    String value,
    IconData icon,
    Color color,
    String subtitle, {
    String? asset,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: _Palette.divider),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: color.withOpacity(0.1),
              borderRadius: BorderRadius.circular(12),
            ),
            child: asset != null
                ? AppImage(
                    asset,
                    size: 24,
                    tint: color,
                    fallbackIcon: icon,
                  )
                : Icon(icon, color: color, size: 24),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(label,
                    style: const TextStyle(
                        color: _Palette.inkMuted, fontSize: 13.5)),
                const SizedBox(height: 4),
                Text(value,
                    style: const TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: _Palette.ink)),
                const SizedBox(height: 2),
                Text(subtitle,
                    style: const TextStyle(
                        color: _Palette.inkMuted, fontSize: 13)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
