// lib/screens/customer/customer_cart_screen.dart
//
// Reads CartProvider, writes the order to the DB via OrderService,
// charges the wallet, then hands off to /order_tracking.

import 'package:efuride_app/widgets/product_thumb.dart';
import 'package:flutter/material.dart';
import 'package:efuride_app/services/favorite_places_service.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart' show LatLng;
import 'package:provider/provider.dart';
import 'package:efuride_app/config/country_config.dart';
import 'package:efuride_app/config/efuride_palette.dart';
import 'package:efuride_app/l10n/app_strings.dart';
import 'package:efuride_app/providers/auth_provider.dart';
import 'package:efuride_app/providers/cart_provider.dart';
import 'package:efuride_app/services/google_maps_service.dart';
import 'package:efuride_app/services/order_service.dart';
import 'package:efuride_app/utils/app_error.dart';
import 'package:efuride_app/utils/error_ui.dart';
import 'package:efuride_app/widgets/place_search_sheet.dart';
import 'package:efuride_app/widgets/payment_choice.dart';
import 'package:efuride_app/services/pricing_service.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:efuride_app/services/connection_service.dart';
import 'package:efuride_app/widgets/k_icon.dart';

class CustomerCartScreen extends StatefulWidget {
  const CustomerCartScreen({super.key});

  @override
  State<CustomerCartScreen> createState() => _CustomerCartScreenState();
}

class _CustomerCartScreenState extends State<CustomerCartScreen> {
  final _promoCtrl  = TextEditingController();
  final _noteCtrl   = TextEditingController();
  final _addressCtrl = TextEditingController();

  // Map position of the delivery address (from Google). The shopper and
  // driver navigate to this point, so an order can't be placed without it.
  double? _deliveryLat;
  double? _deliveryLng;
  bool _locatingAddress = false;

  bool   _substitutionsAllowed = true;
  bool   _contactless          = false;
  /// Chosen payment ('cash' | 'wallet' | 'card'); null = not picked yet,
  /// then wallet when it covers the total, otherwise cash.
  String? _pickedPay;
  String get _paymentMethod {
    final bal = context.read<AuthProvider>().walletBalance;
    final cart = context.read<CartProvider>();
    final due = _total(cart);
    final p = _pickedPay ?? PaymentChoice.suggested(due, bal);
    if (p == 'wallet' && bal < due) return 'cash';
    if (p == 'card' && !PaymentChoice.cardAvailable) return 'cash';
    return p;
  }
  String? _appliedPromo;
  bool   _placingOrder  = false;

  @override
  void initState() {
    super.initState();
    PricingService.changes.addListener(_onPricesChanged);
    _prefillAddressFromGps();
    FavoritePlacesService.listFavorites().then((l) {
      if (mounted) setState(() => _savedPlaces = l);
    });
    // Use the store's current delivery fee and minimum order.
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      context
          .read<CartProvider>()
          .refreshPartnerFees(OrderService.instance.fetchPartner);
      // Fresh wallet balance + card availability for the payment choice.
      context.read<AuthProvider>().refresh();
      PricingService.current().then((_) {
        if (mounted) setState(() {});
      });
    });
  }

  /// Start with the customer's current address; they can change it.
  Future<void> _prefillAddressFromGps() async {
    setState(() => _locatingAddress = true);
    try {
      final perm = await Geolocator.checkPermission();
      if (perm == LocationPermission.denied ||
          perm == LocationPermission.deniedForever) {
        return;
      }
      final pos = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high,
        timeLimit: const Duration(seconds: 8),
      );
      final place = await GoogleMapsService.reverseGeocode(
          LatLng(pos.latitude, pos.longitude));
      if (!mounted || _deliveryLat != null) return;
      setState(() {
        _deliveryLat = pos.latitude;
        _deliveryLng = pos.longitude;
        _addressCtrl.text = place?.displayAddress ?? '';
      });
      _quoteDelivery();
    } catch (_) {
      // No GPS — the customer picks the address manually.
    } finally {
      if (mounted) setState(() => _locatingAddress = false);
    }
  }

  List<Map<String, dynamic>> _savedPlaces = [];

  void _useSavedPlace(Map<String, dynamic> r) {
    setState(() {
      _addressCtrl.text = (r['address'] ?? r['label'] ?? '').toString();
      _deliveryLat = (r['lat'] as num).toDouble();
      _deliveryLng = (r['lng'] as num).toDouble();
    });
    _quoteDelivery();
  }

  Future<void> _pickDeliveryAddress() async {
    final place = await showPlaceSearchSheet(
      context,
      includeSaved: true,
      near: (_deliveryLat != null && _deliveryLng != null)
          ? LatLng(_deliveryLat!, _deliveryLng!)
          : null,
      title: S.of(context).t('delivery_address'),
    );
    if (place == null || !mounted) return;
    setState(() {
      _addressCtrl.text = place.displayAddress;
      _deliveryLat = place.lat;
      _deliveryLng = place.lng;
    });
    _quoteDelivery();
  }

  void _onPricesChanged() {
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    PricingService.changes.removeListener(_onPricesChanged);
    _promoCtrl.dispose();
    _noteCtrl.dispose();
    _addressCtrl.dispose();
    super.dispose();
  }

  // ── Totals ───────────────────────────────────────────────────
  double _subtotal(CartProvider c) => c.subtotal;
  // Fees are set by ko!ngo per country (admin → Pricing); the server
  // works out the delivery fee from the distance store → customer.
  double? _quotedFee;
  double? _svcPct;
  String? _quotedFor;

  Future<void> _quoteDelivery() async {
    final pid = context.read<CartProvider>().partnerId;
    final lat = _deliveryLat, lng = _deliveryLng;
    if (pid == null || lat == null || lng == null) return;
    final key = '$pid:${lat.toStringAsFixed(4)},${lng.toStringAsFixed(4)}';
    if (key == _quotedFor) return;
    _quotedFor = key;
    try {
      final q = await Supabase.instance.client.rpc('quote_delivery_fee',
          params: {'p_partner': pid, 'p_lat': lat, 'p_lng': lng});
      if (q is Map && mounted) {
        setState(() {
          _quotedFee = (q['delivery_fee'] as num?)?.toDouble();
          _svcPct = (q['service_fee_pct'] as num?)?.toDouble();
        });
      }
    } catch (_) {
      _quotedFor = null; // older database: keep the store's fee
    }
  }

  double _serviceFee(CartProvider c) => c.serviceType == 'Grocery'
      ? c.subtotal *
          (_svcPct ?? PricingService.last.groceryServiceFeePct) /
          100
      : 0;
  double _delivery(CartProvider c) => _quotedFee ?? c.deliveryFee;

  // Dynamic promo discount calculation
  double _promoDiscount(CartProvider c) {
    // KONGO15 (EFURIDE15 still works for people who saved the old code).
    if (_appliedPromo == 'KONGO15' || _appliedPromo == 'EFURIDE15') {
      return c.subtotal * 0.15;
    }
    return 0;
  }

  double _total(CartProvider c) =>
      _subtotal(c) + _serviceFee(c) + _delivery(c) - _promoDiscount(c);

  // ── Promo ────────────────────────────────────────────────────
  void _applyPromo() {
    final code = _promoCtrl.text.trim().toUpperCase();
    if (code.isEmpty) return;
    final t = S.of(context);
    final cart = context.read<CartProvider>();

    if (code == 'KONGO15' || code == 'EFURIDE15') {
      setState(() => _appliedPromo = code);
      _snack(t.t('promo_applied_short'), EfuridePalette.online);
    } else {
      _snack(t.t('invalid_promo'), EfuridePalette.dropoff);
    }
  }

  void _removePromo() {
    setState(() {
      _appliedPromo = null;
      _promoCtrl.clear();
    });
  }

  // ── Order placement ──────────────────────────────────────────
  Future<void> _placeOrder() async {
    if (_placingOrder) return;
    if (!await ConnectionService.instance.ensureOnline(context)) return;

    final cart = context.read<CartProvider>();
    final auth = context.read<AuthProvider>();
    final t = S.of(context);

    if (cart.isEmpty) return;

    if (!cart.meetsMinOrder) {
      _snack('${t.t('minimum_order')} ${CountryConfig.money(cart.minOrder)}',
          EfuridePalette.dropoff);
      return;
    }
    if (_addressCtrl.text.trim().isEmpty ||
        _deliveryLat == null ||
        _deliveryLng == null) {
      _snack(t.t('enter_address'), EfuridePalette.dropoff);
      return;
    }

    // Confirm
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16)),
        title: Text(t.t('confirm_order')),
        content: Text(
            '${cart.itemCount} ${t.t('items_suffix')} · ${CountryConfig.money(_total(cart))}\n\n'
            '${t.t('payment')}: ${_paymentLabel(t)}'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: Text(t.t('cancel')),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, true),
            style: ElevatedButton.styleFrom(
              backgroundColor: EfuridePalette.merchantAccent,
              foregroundColor: Colors.white,
            ),
            child: Text(t.t('place_order')),
          ),
        ],
      ),
    );
    if (ok != true || !mounted) return;

    final userId = auth.user?.id;
    if (userId == null) {
      _snack(t.t('sign_in_to_order'), EfuridePalette.dropoff);
      return;
    }

    // Wallet balance check
    if (_pickedPay == 'wallet' && auth.walletBalance < _total(cart)) {
      _snack(t.t('insufficient_balance'), EfuridePalette.dropoff);
      return;
    }

    setState(() => _placingOrder = true);

    try {
      // 1. Insert order + line items.
      final orderId = await OrderService.instance.createOrder(
        customerId:   userId,
        partner:      await _resolvePartnerForInsert(cart),
        serviceType:  cart.serviceType ?? 'Food',
        lines:        cart.lines,
        paymentMethod: _paymentMethod,
        serviceFee:   _serviceFee(cart),
        discountAmount: _promoDiscount(cart),
        promoCode:    _appliedPromo,
        contactless:  _contactless,
        substitutionsAllowed: _substitutionsAllowed,
        deliveryAddress: _addressCtrl.text.trim(),
        deliveryLat:  _deliveryLat,
        deliveryLng:  _deliveryLng,
        deliveryNote: _noteCtrl.text.trim().isEmpty ? null : _noteCtrl.text.trim(),
        // Driver needs a name and number to call on arrival.
        recipientName:  _recipientName(auth),
        recipientPhone: (auth.profile?['phone'] ??
                auth.profile?['phone_number'])
            ?.toString(),
      );

      // 2. Charge wallet if selected.
      // The server works out the total and takes exactly that.
      if (_paymentMethod == 'wallet') {
        await OrderService.instance.payFromWallet(orderId);
      }

      // 3. Refresh auth so wallet balance is up to date.
      await auth.refresh();

      if (!mounted) return;

      // 4. Capture data BEFORE clearing cart
      final serviceType = cart.serviceType ?? 'Food';
      final partnerName = cart.partnerName ?? '';
      final total = _total(cart);
      final dropoff = _addressCtrl.text.trim();

      // 5. Clear cart + navigate to tracking.
      cart.clear();
      
      Navigator.pushReplacementNamed(
        context,
        '/order_tracking',
        arguments: {
          'order_id':      orderId,
          'service_type':  serviceType,
          'store_name':    partnerName,
          'store_address': '',
          'dropoff':       dropoff,
          'total':         total,
        },
      );
    } catch (e) {
      if (!mounted) return;
      setState(() => _placingOrder = false);
      ErrorUI.showSnack(context, AppError.from(e));
    }
  }

  /// The DB insert needs a full Partner object, but CartProvider only
  /// keeps id + name + fee + min order. Fetch the full row by id.
  Future<dynamic> _resolvePartnerForInsert(CartProvider cart) async {
    final p = await OrderService.instance.fetchPartner(cart.partnerId ?? '');
    if (p == null) throw StateError('Partner no longer available');
    return p;
  }

  String? _recipientName(AuthProvider auth) {
    final p = auth.profile;
    if (p == null) return null;
    final first = (p['first_name'] ?? '').toString().trim();
    final last = (p['surname'] ?? '').toString().trim();
    final full = '$first $last'.trim();
    if (full.isNotEmpty) return full;
    final f = (p['full_name'] ?? '').toString().trim();
    return f.isEmpty ? null : f;
  }

  String _paymentLabel(S t) {
    switch (_paymentMethod) {
      case 'momo':   return t.t('payment_momo');
      case 'airtel': return t.t('payment_airtel');
      case 'cash':   return t.t('payment_cash');
      case 'card':   return tr('Card');
      case 'wallet':
      default:       return t.t('payment_wallet');
    }
  }

  void _snack(String msg, Color color) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg),
      backgroundColor: color,
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10)),
    ));
  }

  // ── Build ────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    final t = S.of(context);
    final cart = context.watch<CartProvider>();

    return Scaffold(
      backgroundColor: EfuridePalette.cream,
      body: Column(
        children: [
          _header(t, cart),
          Expanded(
            child: cart.isEmpty
                ? _emptyState(t)
                : ListView(
                    padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
                    children: [
                      if (cart.serviceType == 'Grocery') ...[
                        _substitutionCard(t),
                        const SizedBox(height: 14),
                      ],
                      _sectionLabel(t.t('your_items')),
                      const SizedBox(height: 10),
                      ...cart.lines.map((l) => _lineCard(l, cart)),
                      const SizedBox(height: 16),
                      _promoCard(t),
                      const SizedBox(height: 14),
                      _paymentCard(t),
                      const SizedBox(height: 14),
                      _deliveryCard(t),
                      const SizedBox(height: 14),
                      _addressCard(t),
                      const SizedBox(height: 14),
                      _noteCard(t),
                      const SizedBox(height: 14),
                      _priceBreakdown(t, cart),
                      const SizedBox(height: 20),
                    ],
                  ),
          ),
          _stickyBar(t, cart),
        ],
      ),
    );
  }

  // ── Header ───────────────────────────────────────────────────
  Widget _header(S t, CartProvider cart) {
    final accent = cart.serviceType == 'Grocery'
        ? EfuridePalette.shopperAccent
        : EfuridePalette.merchantAccent;

    return Container(
      decoration: const BoxDecoration(
        color: EfuridePalette.cream,
      ),
      child: SafeArea(
        bottom: false,
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(8, 8, 16, 12),
              child: Row(
                children: [
                  IconButton(
                    onPressed: () => Navigator.pop(context),
                    icon: const Icon(Icons.arrow_back, color: EfuridePalette.ink),
                  ),
                  const SizedBox(width: 4),
                  Container(
                    width: 36, height: 36,
                    decoration: const BoxDecoration(
                      color: Colors.white, shape: BoxShape.circle,
                    ),
                    child: Center(
                      child: Icon(
                        cart.serviceType == 'Grocery'
                            ? Icons.shopping_bag_rounded
                            : Icons.restaurant_rounded,
                        color: accent, size: 20,
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(t.t('your_cart'),
                            style: const TextStyle(
                              color: EfuridePalette.ink,
                              fontSize: 16,
                              fontWeight: FontWeight.w900,
                            )),
                        const SizedBox(height: 2),
                        Text(cart.partnerName ?? '',
                            style: const TextStyle(
                              color: EfuridePalette.inkMuted,
                              fontSize: 13,
                            ),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis),
                      ],
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 10, vertical: 6),
                    decoration: BoxDecoration(
                      color: accent,
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Text('${cart.itemCount} ${t.t('items_suffix')}',
                        style: const TextStyle(
                          color: EfuridePalette.ink,
                          fontSize: 13,
                          fontWeight: FontWeight.w900,
                        )),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _sectionLabel(String text) => Text(text,
      style: const TextStyle(
        fontSize: 14,
        fontWeight: FontWeight.w800,
        color: EfuridePalette.ink,
      ));

  // ── Line card ────────────────────────────────────────────────
  Widget _lineCard(dynamic l, CartProvider cart) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: EfuridePalette.divider),
      ),
      child: Row(
        children: [
          ProductThumb(
            imageUrl: l.imageUrl,
            size: 54,
            background: EfuridePalette.merchantAccent.withValues(alpha: 0.12),
            fallback: (l.emoji != null && l.emoji!.isNotEmpty)
                ? Text(l.emoji!, style: const TextStyle(fontSize: 26))
                : const Icon(Icons.fastfood,
                    color: EfuridePalette.merchantAccent, size: 24),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(l.name,
                    style: const TextStyle(
                      fontSize: 14.5,
                      fontWeight: FontWeight.w800,
                      color: EfuridePalette.ink,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis),
                if ((l.description ?? '').isNotEmpty) ...[
                  const SizedBox(height: 2),
                  Text(l.description!,
                      style: const TextStyle(
                        fontSize: 13,
                        color: EfuridePalette.inkMuted,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis),
                ],
                const SizedBox(height: 4),
                Text(CountryConfig.money(l.unitPrice),
                    style: const TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w900,
                      color: EfuridePalette.merchantAccent,
                    )),
              ],
            ),
          ),
          Container(
            decoration: BoxDecoration(
              color: EfuridePalette.merchantAccent,
              borderRadius: BorderRadius.circular(10),
            ),
            child: Row(
              children: [
                GestureDetector(
                  onTap: () => cart.decrement(l.productId),
                  child: const SizedBox(
                    width: 34, height: 34,
                    child: Icon(Icons.remove, color: Colors.white, size: 16),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 6),
                  child: Text('${l.qty}',
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 14,
                        fontWeight: FontWeight.w900,
                      )),
                ),
                GestureDetector(
                  onTap: () => cart.increment(l.productId),
                  child: const SizedBox(
                    width: 34, height: 34,
                    child: Icon(Icons.add, color: Colors.white, size: 16),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ── Substitution ─────────────────────────────────────────────
  Widget _substitutionCard(S t) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: EfuridePalette.shopperAccent.withValues(alpha: 0.08),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
            color: EfuridePalette.shopperAccent.withValues(alpha: 0.35)),
      ),
      child: Column(
        children: [
          Row(
            children: [
              const Icon(Icons.swap_horiz,
                  size: 20, color: EfuridePalette.shopperAccent),
              const SizedBox(width: 10),
              Expanded(
                child: Text(t.t('substitution_title'),
                    style: const TextStyle(
                      fontSize: 14.5,
                      fontWeight: FontWeight.w800,
                      color: EfuridePalette.ink,
                    )),
              ),
              Switch.adaptive(
                value: _substitutionsAllowed,
                activeColor: EfuridePalette.shopperAccent,
                onChanged: (v) => setState(() => _substitutionsAllowed = v),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            _substitutionsAllowed
                ? t.t('substitution_hint')
                : t.t('substitution_skip_hint'),
            style: const TextStyle(
              fontSize: 13,
              color: EfuridePalette.inkMuted,
              height: 1.45,
            ),
          ),
        ],
      ),
    );
  }

  // ── Promo ────────────────────────────────────────────────────
  Widget _promoCard(S t) {
    if (_appliedPromo != null) {
      return Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: EfuridePalette.online.withValues(alpha: 0.10),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
              color: EfuridePalette.online.withValues(alpha: 0.4)),
        ),
        child: Row(
          children: [
            const Icon(Icons.check_circle,
                color: EfuridePalette.online, size: 20),
            const SizedBox(width: 10),
            Expanded(
              child: Text(
                '${t.t('promo_code')} $_appliedPromo ${t.t('promo_applied')} '
                '${CountryConfig.money(_promoDiscount(context.read<CartProvider>()))}',
                style: const TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w700,
                  color: EfuridePalette.online,
                ),
              ),
            ),
            TextButton(
              onPressed: _removePromo,
              child: Text(t.t('remove'),
                  style: const TextStyle(
                      color: EfuridePalette.inkMuted, fontSize: 13.5)),
            ),
          ],
        ),
      );
    }
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: EfuridePalette.divider),
      ),
      child: Row(
        children: [
          Expanded(
            child: TextField(
              controller: _promoCtrl,
              textCapitalization: TextCapitalization.characters,
              decoration: InputDecoration(
                hintText: t.t('promo_code'),
                hintStyle: const TextStyle(
                    fontSize: 14, color: EfuridePalette.inkMuted),
                filled: true,
                fillColor: EfuridePalette.cream,
                contentPadding: const EdgeInsets.symmetric(
                    horizontal: 12, vertical: 12),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                  borderSide: BorderSide.none,
                ),
              ),
            ),
          ),
          const SizedBox(width: 8),
          ElevatedButton(
            onPressed: _applyPromo,
            style: ElevatedButton.styleFrom(
              backgroundColor: EfuridePalette.merchantAccent,
              foregroundColor: Colors.white,
              minimumSize: const Size(80, 44),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10)),
              elevation: 0,
            ),
            child: Text(t.t('apply'),
                style: const TextStyle(
                    fontWeight: FontWeight.w800, fontSize: 14)),
          ),
        ],
      ),
    );
  }

  // ── Payment ──────────────────────────────────────────────────
  Widget _paymentCard(S t) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: EfuridePalette.divider),
      ),
      child: PaymentChoice(
        value: _paymentMethod,
        onChanged: (v) => setState(() => _pickedPay = v),
        amountDue: _total(context.watch<CartProvider>()),
        walletBalance: context.watch<AuthProvider>().walletBalance,
        cashHint: tr('Pay the driver when it arrives'),
      ),
    );
  }

  // ── Delivery ─────────────────────────────────────────────────
  Widget _deliveryCard(S t) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: EfuridePalette.divider),
      ),
      child: Column(
        children: [
          Row(
            children: [
              const KIcon(Icons.delivery_dining,
                  size: 20, color: EfuridePalette.blueDeep),
              const SizedBox(width: 10),
              Expanded(
                child: Text(t.t('contactless_delivery'),
                    style: const TextStyle(
                      fontSize: 14.5,
                      fontWeight: FontWeight.w700,
                      color: EfuridePalette.ink,
                    )),
              ),
              Switch.adaptive(
                value: _contactless,
                activeColor: EfuridePalette.merchantAccent,
                onChanged: (v) => setState(() => _contactless = v),
              ),
            ],
          ),
          if (_contactless)
            Padding(
              padding: const EdgeInsets.only(left: 30),
              child: Text(
                t.t('contactless_hint'),
                style: const TextStyle(
                    fontSize: 13,
                    color: EfuridePalette.inkMuted),
              ),
            ),
        ],
      ),
    );
  }

  // ── Address ──────────────────────────────────────────────────
  Widget _addressCard(S t) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: EfuridePalette.divider),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const KIcon(Icons.location_on_outlined,
                  size: 18, color: EfuridePalette.blueDeep),
              const SizedBox(width: 8),
              Text(t.t('delivery_address'),
                  style: const TextStyle(
                    fontSize: 14.5,
                    fontWeight: FontWeight.w800,
                    color: EfuridePalette.ink,
                  )),
            ],
          ),
          const SizedBox(height: 10),
          // Picked from Google so the shopper and driver can navigate.
          TextField(
            controller: _addressCtrl,
            maxLines: 2,
            readOnly: true,
            onTap: _pickDeliveryAddress,
            decoration: InputDecoration(
              suffixIcon: _locatingAddress
                  ? const Padding(
                      padding: EdgeInsets.all(12),
                      child: SizedBox(
                          width: 16,
                          height: 16,
                          child: CircularProgressIndicator(strokeWidth: 2)),
                    )
                  : const Icon(Icons.search, color: EfuridePalette.blueDeep),
              hintText: t.t('delivery_address_hint'),
              hintStyle: const TextStyle(
                  fontSize: 14, color: EfuridePalette.inkMuted),
              filled: true,
              fillColor: EfuridePalette.cream,
              contentPadding: const EdgeInsets.all(12),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(10),
                borderSide: BorderSide.none,
              ),
            ),
          ),
          if (FavoritePlacesService.filter(_savedPlaces, '').isNotEmpty) ...[
            const SizedBox(height: 10),
            Wrap(
              spacing: 8,
              runSpacing: 6,
              children: [
                for (final r
                    in FavoritePlacesService.filter(_savedPlaces, '').take(4))
                  ActionChip(
                    avatar: Icon(
                        FavoritePlacesService.isHomeLabel(
                                (r['label'] ?? '').toString())
                            ? Icons.home_rounded
                            : Icons.star_rounded,
                        size: 18,
                        color: EfuridePalette.ink),
                    label: Text((r['label'] ?? r['name'] ?? '').toString(),
                        style: const TextStyle(fontWeight: FontWeight.w700)),
                    onPressed: () => _useSavedPlace(r),
                  ),
              ],
            ),
          ],
        ],
      ),
    );
  }

  // ── Note ─────────────────────────────────────────────────────
  Widget _noteCard(S t) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: EfuridePalette.divider),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.sticky_note_2_outlined,
                  size: 18, color: EfuridePalette.blueDeep),
              const SizedBox(width: 8),
              Text(t.t('note_for_driver'),
                  style: const TextStyle(
                    fontSize: 14.5,
                    fontWeight: FontWeight.w800,
                    color: EfuridePalette.ink,
                  )),
            ],
          ),
          const SizedBox(height: 10),
          TextField(
            controller: _noteCtrl,
            maxLines: 2,
            decoration: InputDecoration(
              hintText: t.t('note_hint'),
              hintStyle: const TextStyle(
                  fontSize: 14, color: EfuridePalette.inkMuted),
              filled: true,
              fillColor: EfuridePalette.cream,
              contentPadding: const EdgeInsets.all(12),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(10),
                borderSide: BorderSide.none,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ── Price breakdown ──────────────────────────────────────────
  Widget _priceBreakdown(S t, CartProvider cart) {
    final promoDiscount = _promoDiscount(cart);
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: EfuridePalette.divider),
      ),
      child: Column(
        children: [
          _totalRow(t.t('subtotal'), CountryConfig.money(_subtotal(cart))),
          if (_serviceFee(cart) > 0) ...[
            const SizedBox(height: 6),
            _totalRow(t.t('service_fee'), CountryConfig.money(_serviceFee(cart))),
          ],
          const SizedBox(height: 6),
          _totalRow(t.t('delivery_fee'), CountryConfig.money(_delivery(cart))),
          if (promoDiscount > 0) ...[
            const SizedBox(height: 6),
            _totalRow(
              t.t('promo_discount'),
              '− ${CountryConfig.money(promoDiscount)}',
              color: EfuridePalette.online,
            ),
          ],
          const SizedBox(height: 10),
          const Divider(height: 1, color: EfuridePalette.divider),
          const SizedBox(height: 10),
          Row(
            children: [
              Text(t.t('total'),
                  style: const TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w900,
                    color: EfuridePalette.ink,
                  )),
              const Spacer(),
              Text(CountryConfig.money(_total(cart)),
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w900,
                    color: EfuridePalette.merchantAccent,
                  )),
            ],
          ),
        ],
      ),
    );
  }

  Widget _totalRow(String label, String value, {Color? color}) {
    return Row(
      children: [
        Text(label,
            style: const TextStyle(
                fontSize: 14, color: EfuridePalette.inkMuted)),
        const Spacer(),
        Text(value,
            style: TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.w700,
              color: color ?? EfuridePalette.ink,
            )),
      ],
    );
  }

  // ── Empty state ──────────────────────────────────────────────
  Widget _emptyState(S t) => Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 90, height: 90,
                decoration: BoxDecoration(
                  color: EfuridePalette.merchantAccent.withValues(alpha: 0.12),
                  shape: BoxShape.circle,
                ),
                child: const Icon(Icons.shopping_cart_outlined,
                    size: 44, color: EfuridePalette.merchantAccent),
              ),
              const SizedBox(height: 16),
              Text(t.t('empty_cart'),
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w800,
                    color: EfuridePalette.ink,
                  )),
              const SizedBox(height: 4),
              Text(t.t('empty_cart_hint'),
                  style: const TextStyle(
                      fontSize: 13.5, color: EfuridePalette.inkMuted)),
            ],
          ),
        ),
      );

  // ── Sticky bar ───────────────────────────────────────────────
  Widget _stickyBar(S t, CartProvider cart) {
    final enabled = cart.isNotEmpty && !_placingOrder;

    return Container(
      padding: EdgeInsets.fromLTRB(
        16, 12, 16, 12 + MediaQuery.of(context).padding.bottom,
      ),
      decoration: BoxDecoration(
        color: Colors.white,
        border: const Border(top: BorderSide(color: EfuridePalette.divider)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.05),
            blurRadius: 10,
            offset: const Offset(0, -3),
          ),
        ],
      ),
      child: Row(
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(t.t('total'),
                  style: const TextStyle(
                      fontSize: 13, color: EfuridePalette.inkMuted)),
              Text(
                CountryConfig.money(_total(cart)),
                style: const TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.w900,
                  color: EfuridePalette.ink,
                ),
              ),
            ],
          ),
          const SizedBox(width: 16),
          Expanded(
            child: ElevatedButton.icon(
              onPressed: enabled ? _placeOrder : null,
              icon: _placingOrder
                  ? const SizedBox(
                      width: 18, height: 18,
                      child: CircularProgressIndicator(
                          strokeWidth: 2, color: Colors.white),
                    )
                  : const Icon(Icons.check_circle, size: 18),
              label: Text(t.t('place_order'),
                  style: const TextStyle(
                      fontSize: 15, fontWeight: FontWeight.w900)),
              style: ElevatedButton.styleFrom(
                backgroundColor: EfuridePalette.merchantAccent,
                foregroundColor: Colors.white,
                minimumSize: const Size(double.infinity, 54),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14)),
                elevation: 0,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
