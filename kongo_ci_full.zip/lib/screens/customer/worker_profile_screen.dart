// lib/screens/customer/worker_profile_screen.dart
//
// Hiring Hub: "My worker profile" (saved once, shown to employers on every
// application) and the star-rating sheet used after a hire.

import 'package:flutter/material.dart';
import 'package:efuride_app/config/efuride_palette.dart';
import 'package:efuride_app/l10n/app_strings.dart';
import 'package:efuride_app/services/hiring_service.dart';
import 'package:efuride_app/utils/app_error.dart';
import 'package:efuride_app/utils/error_ui.dart';

class WorkerProfileScreen extends StatefulWidget {
  const WorkerProfileScreen({super.key});

  @override
  State<WorkerProfileScreen> createState() => _WorkerProfileScreenState();
}

class _WorkerProfileScreenState extends State<WorkerProfileScreen> {
  final _headline = TextEditingController();
  final _skills = TextEditingController();
  final _about = TextEditingController();
  int _years = 0;
  bool _loading = true;
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    HiringService.instance.myProfile().then((p) {
      if (!mounted) return;
      setState(() {
        _headline.text = p.headline;
        _skills.text = p.skills;
        _about.text = p.about;
        _years = p.experienceYears;
        _loading = false;
      });
    });
  }

  @override
  void dispose() {
    _headline.dispose();
    _skills.dispose();
    _about.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (_headline.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(tr('Write what work you do, for example "Painter".'))));
      return;
    }
    setState(() => _saving = true);
    try {
      await HiringService.instance.saveProfile(WorkerProfile(
        headline: _headline.text,
        skills: _skills.text,
        experienceYears: _years,
        about: _about.text,
      ));
      if (!mounted) return;
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text(tr('Profile saved'))));
      Navigator.pop(context, true);
    } catch (e) {
      if (mounted) ErrorUI.showSnack(context, AppError.from(e));
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  InputDecoration _dec(String label, {String? hint}) => InputDecoration(
        labelText: label,
        hintText: hint,
        filled: true,
        fillColor: Colors.white,
        border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: BorderSide.none),
      );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: EfuridePalette.cream,
      appBar: AppBar(
        backgroundColor: EfuridePalette.cream,
        foregroundColor: EfuridePalette.ink,
        elevation: 0,
        title: Text(tr('My worker profile'),
            style: const TextStyle(fontWeight: FontWeight.w900)),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 30),
              children: [
                Text(
                    tr('Employers see this when you apply for a job. Save it once.'),
                    style: const TextStyle(color: EfuridePalette.inkMuted)),
                const SizedBox(height: 14),
                TextField(
                    controller: _headline,
                    maxLength: 60,
                    decoration: _dec(tr('What work do you do?'),
                        hint: tr('e.g. Painter, Driver, Cleaner'))),
                const SizedBox(height: 6),
                TextField(
                    controller: _skills,
                    maxLength: 160,
                    decoration: _dec(tr('Your skills'),
                        hint: tr('e.g. painting, walls, roofs'))),
                const SizedBox(height: 6),
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                  decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(14)),
                  child: Row(children: [
                    Expanded(
                        child: Text(tr('Years of experience'),
                            style: const TextStyle(
                                fontSize: 16, fontWeight: FontWeight.w700))),
                    IconButton(
                        onPressed:
                            _years > 0 ? () => setState(() => _years--) : null,
                        icon: const Icon(Icons.remove_circle_outline)),
                    Text('$_years',
                        style: const TextStyle(
                            fontSize: 18, fontWeight: FontWeight.w900)),
                    IconButton(
                        onPressed:
                            _years < 60 ? () => setState(() => _years++) : null,
                        icon: const Icon(Icons.add_circle_outline)),
                  ]),
                ),
                const SizedBox(height: 14),
                TextField(
                    controller: _about,
                    maxLines: 4,
                    maxLength: 400,
                    decoration: _dec(tr('About you'),
                        hint: tr('Tell employers why they should choose you'))),
                const SizedBox(height: 14),
                SizedBox(
                  height: 52,
                  child: ElevatedButton(
                    onPressed: _saving ? null : _save,
                    style: ElevatedButton.styleFrom(
                        backgroundColor: EfuridePalette.accent,
                        foregroundColor: EfuridePalette.ink,
                        elevation: 0,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(16))),
                    child: _saving
                        ? const SizedBox(
                            width: 22,
                            height: 22,
                            child: CircularProgressIndicator(strokeWidth: 2.5))
                        : Text(tr('Save profile'),
                            style: const TextStyle(
                                fontSize: 16, fontWeight: FontWeight.w900)),
                  ),
                ),
              ],
            ),
    );
  }
}

/// Star rating sheet. Returns true when a rating was saved.
Future<bool> showRateSheet(
  BuildContext context, {
  required String jobId,
  required String rateeId,
  required String title,
  int? initial,
}) async {
  final res = await showModalBottomSheet<bool>(
    context: context,
    isScrollControlled: true,
    backgroundColor: EfuridePalette.cream,
    shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
    builder: (_) => _RateSheet(
        jobId: jobId, rateeId: rateeId, title: title, initial: initial),
  );
  return res == true;
}

class _RateSheet extends StatefulWidget {
  final String jobId, rateeId, title;
  final int? initial;
  const _RateSheet(
      {required this.jobId,
      required this.rateeId,
      required this.title,
      this.initial});

  @override
  State<_RateSheet> createState() => _RateSheetState();
}

class _RateSheetState extends State<_RateSheet> {
  int _stars = 0;
  final _comment = TextEditingController();
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    _stars = widget.initial ?? 0;
  }

  @override
  void dispose() {
    _comment.dispose();
    super.dispose();
  }

  Future<void> _send() async {
    if (_stars < 1) return;
    setState(() => _busy = true);
    try {
      await HiringService.instance
          .rate(widget.jobId, widget.rateeId, _stars, _comment.text);
      if (!mounted) return;
      Navigator.pop(context, true);
    } catch (e) {
      if (mounted) ErrorUI.showSnack(context, AppError.from(e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.fromLTRB(
          20, 20, 20, 20 + MediaQuery.of(context).viewInsets.bottom),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(widget.title,
              style:
                  const TextStyle(fontSize: 19, fontWeight: FontWeight.w900)),
          const SizedBox(height: 12),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              for (var i = 1; i <= 5; i++)
                IconButton(
                  iconSize: 38,
                  onPressed: () => setState(() => _stars = i),
                  icon: Icon(i <= _stars ? Icons.star_rounded : Icons.star_outline_rounded,
                      color: EfuridePalette.accent),
                ),
            ],
          ),
          TextField(
            controller: _comment,
            maxLines: 3,
            maxLength: 500,
            decoration: InputDecoration(
              hintText: tr('Add a short comment (optional)'),
              filled: true,
              fillColor: Colors.white,
              border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(14),
                  borderSide: BorderSide.none),
            ),
          ),
          const SizedBox(height: 8),
          SizedBox(
            width: double.infinity,
            height: 50,
            child: ElevatedButton(
              onPressed: (_stars < 1 || _busy) ? null : _send,
              style: ElevatedButton.styleFrom(
                  backgroundColor: EfuridePalette.accent,
                  foregroundColor: EfuridePalette.ink,
                  elevation: 0),
              child: _busy
                  ? const SizedBox(
                      width: 22,
                      height: 22,
                      child: CircularProgressIndicator(strokeWidth: 2.5))
                  : Text(tr('Send rating'),
                      style: const TextStyle(
                          fontSize: 16, fontWeight: FontWeight.w900)),
            ),
          ),
        ],
      ),
    );
  }
}
