// lib/screens/customer/customer_category_screen.dart
//
// Store list for the Marketplace categories that don't have their own
// screen (Fashion, Electronics, Home & Living, Beauty, Butchery, Bakery,
// General Retail, Other). Same list as Groceries, filtered by category.

import 'package:flutter/material.dart';
import 'package:efuride_app/config/efuride_palette.dart';
import 'package:efuride_app/widgets/partner_landing_screen.dart';
import 'package:efuride_app/widgets/picture_tile.dart';

class CustomerCategoryScreen extends StatelessWidget {
  final String category;
  final String title;
  const CustomerCategoryScreen({
    super.key,
    required this.category,
    required this.title,
  });

  @override
  Widget build(BuildContext context) {
    return PartnerLandingScreen(
      category: category,
      serviceType: 'Grocery', // same checkout as groceries
      accent: EfuridePalette.shopperAccent,
      headerIcon: Icons.storefront_rounded,
      headerKicker: title,
      headerTitle: title,
      headerSubtitle: 'Shops near you',
      searchHint: 'Search stores or products',
      headerImage: marketPictureAsset(category),
    );
  }
}
