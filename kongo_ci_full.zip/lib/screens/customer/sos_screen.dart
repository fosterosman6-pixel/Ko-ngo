// lib/screens/customer/sos_screen.dart
//
// Safety center — 5-second countdown before alert fires.
// Shows trusted contacts on the pre-trigger screen.

import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:geolocator/geolocator.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:efuride_app/config/efuride_palette.dart';
import 'package:efuride_app/services/notification_service.dart';
import 'package:efuride_app/utils/app_error.dart';
import 'package:efuride_app/utils/error_ui.dart';
import 'package:efuride_app/widgets/k_icon.dart';

enum _SOSState { idle, countdown, sending, active, failed }

class SOSScreen extends StatefulWidget {
  final String role; // 'customer' | 'driver'
  final String? rideId;

  const SOSScreen({super.key, this.role = 'customer', this.rideId});

  @override
  State<SOSScreen> createState() => _SOSScreenState();
}

class _SOSScreenState extends State<SOSScreen> {
  _SOSState _state = _SOSState.idle;
  AppError? _error;
  String? _eventId;

  int _countdown = 5;
  Timer? _countdownTimer;

  List<Map<String, dynamic>> _contacts = [];
  bool _contactsLoading = true;

  @override
  void initState() {
    super.initState();
    _loadContacts();
  }

  @override
  void dispose() {
    _countdownTimer?.cancel();
    super.dispose();
  }

  // ============================================================
  // CONTACTS
  // ============================================================
  Future<void> _loadContacts() async {
    try {
      final userId = Supabase.instance.client.auth.currentUser?.id;
      if (userId == null) {
        if (mounted) setState(() => _contactsLoading = false);
        return;
      }
      final rows = await Supabase.instance.client
          .from('emergency_contacts')
          .select('name, phone')
          .eq('user_id', userId)
          .order('created_at', ascending: true);

      if (!mounted) return;
      setState(() {
        _contacts = List<Map<String, dynamic>>.from(rows);
        _contactsLoading = false;
      });
    } catch (e) {
      debugPrint('load sos contacts failed: $e');
      if (mounted) setState(() => _contactsLoading = false);
    }
  }

  // ============================================================
  // COUNTDOWN
  // ============================================================
  void _startCountdown() {
    HapticFeedback.heavyImpact();
    setState(() {
      _state = _SOSState.countdown;
      _countdown = 5;
    });

    _countdownTimer?.cancel();
    _countdownTimer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (!mounted) return;
      if (_countdown <= 1) {
        t.cancel();
        _fireAlert();
        return;
      }
      setState(() => _countdown--);
      try {
        HapticFeedback.selectionClick();
      } catch (_) {}
    });
  }

  void _cancelCountdown() {
    _countdownTimer?.cancel();
    setState(() {
      _state = _SOSState.idle;
      _countdown = 5;
    });
  }

  // ============================================================
  // FIRE ALERT
  // ============================================================
  Future<void> _fireAlert() async {
    setState(() {
      _state = _SOSState.sending;
      _error = null;
    });

    try {
      final userId = Supabase.instance.client.auth.currentUser?.id;
      if (userId == null) throw Exception('Not signed in');

      // Best-effort location.
      double? lat;
      double? lng;
      try {
        final perm = await Geolocator.checkPermission();
        if (perm == LocationPermission.always ||
            perm == LocationPermission.whileInUse) {
          final pos = await Geolocator.getCurrentPosition(
            desiredAccuracy: LocationAccuracy.high,
            timeLimit: const Duration(seconds: 6),
          );
          lat = pos.latitude;
          lng = pos.longitude;
        }
      } catch (e) {
        debugPrint('SOS location failed: $e');
      }

      final inserted = await Supabase.instance.client
          .from('sos_events')
          .insert({
            'user_id': userId,
            'role': widget.role,
            'ride_id': widget.rideId,
            'lat': lat,
            'lng': lng,
            'status': 'active',
            'triggered_at': DateTime.now().toUtc().toIso8601String(),
          })
          .select()
          .single()
          .timeout(const Duration(seconds: 12));

      _eventId = inserted['id']?.toString();

      unawaited(_notifyContacts(userId, lat, lng));

      if (!mounted) return;
      setState(() => _state = _SOSState.active);
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _state = _SOSState.failed;
        _error = AppError.from(e, onRetry: _fireAlert);
      });
    }
  }

  Future<void> _notifyContacts(
      String userId, double? lat, double? lng) async {
    try {
      if (_contacts.isEmpty) return;
      final names =
          _contacts.map((c) => c['name']?.toString() ?? '').join(', ');

      await NotificationService.send(
        toUserId: userId,
        title: '🚨 SOS activated',
        body: 'Emergency services and $names have been alerted.',
        type: 'sos_alert',
        data: {'ride_id': widget.rideId ?? ''},
      );

      try {
        await Supabase.instance.client.functions.invoke(
          'sos-notify',
          body: {
            'user_id': userId,
            'ride_id': widget.rideId,
            'lat': lat,
            'lng': lng,
            'contacts': _contacts,
          },
        );
      } catch (e) {
        debugPrint('sos-notify edge function failed: $e');
      }
    } catch (e) {
      debugPrint('sos notify failed: $e');
    }
  }

  // ============================================================
  // RESOLVE
  // ============================================================
  Future<void> _resolveSOS() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16)),
        title: const Text('Mark yourself as safe?'),
        content: const Text(
            'This will end the SOS alert. Your contacts will be told you\'re safe.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Keep active'),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: EfuridePalette.online,
              foregroundColor: Colors.white,
            ),
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('I\'m safe'),
          ),
        ],
      ),
    );
    if (confirmed != true) return;

    try {
      if (_eventId != null) {
        await Supabase.instance.client
            .from('sos_events')
            .update({
              'status': 'resolved',
              'resolved_at': DateTime.now().toUtc().toIso8601String(),
            })
            .eq('id', _eventId!);
      }

      try {
        await Supabase.instance.client.functions.invoke(
          'sos-notify',
          body: {'event_id': _eventId, 'resolved': true},
        );
      } catch (e) {
        debugPrint('sos resolve notify failed: $e');
      }

      if (!mounted) return;
      setState(() {
        _state = _SOSState.idle;
        _eventId = null;
      });
      ErrorUI.showSnack(
        context,
        const AppError(
          title: 'Marked safe',
          message: 'Your contacts have been notified.',
          icon: Icons.check_circle_outline,
        ),
      );
    } catch (e) {
      if (!mounted) return;
      ErrorUI.showSnack(
        context,
        AppError.from(e, onRetry: _resolveSOS),
      );
    }
  }

  // ============================================================
  // DIAL HELPERS
  // ============================================================
  Future<void> _dial(String number) async {
    final uri = Uri(scheme: 'tel', path: number);
    try {
      final ok = await launchUrl(uri);
      if (!ok && mounted) {
        ErrorUI.showSnack(
          context,
          AppError(
            title: 'Couldn\'t dial',
            message: 'Call $number manually.',
            icon: Icons.phone_disabled_outlined,
          ),
        );
      }
    } catch (e) {
      if (!mounted) return;
      ErrorUI.showSnack(context, AppError.from(e));
    }
  }

  // ============================================================
  // BUILD
  // ============================================================
  @override
  Widget build(BuildContext context) {
    switch (_state) {
      case _SOSState.countdown:
        return _countdownView();
      case _SOSState.active:
      case _SOSState.sending:
        return _activeView();
      case _SOSState.idle:
      case _SOSState.failed:
      default:
        return _idleView();
    }
  }

  // ── Header ──
  Widget _header() {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          colors: [EfuridePalette.dropoff, Color(0xFFB71C1C)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
      ),
      child: SafeArea(
        bottom: false,
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(8, 8, 16, 12),
              child: Row(
                children: [
                  IconButton(
                    onPressed: () => Navigator.pop(context),
                    icon: const Icon(Icons.close,
                        color: Colors.white),
                  ),
                  const SizedBox(width: 4),
                  Container(
                    width: 36,
                    height: 36,
                    decoration: BoxDecoration(
                      color: Colors.white.withValues(alpha: 0.20),
                      shape: BoxShape.circle,
                    ),
                    child: const Center(
                      child: KIcon(Icons.shield_outlined,
                          color: Colors.white, size: 20),
                    ),
                  ),
                  const SizedBox(width: 10),
                  const Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('EFURIDE',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 16,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 1.2,
                            height: 1.05,
                          )),
                      SizedBox(height: 2),
                      Text('Safety center',
                          style: TextStyle(
                            color: Colors.white70,
                            fontSize: 11.5,
                            fontWeight: FontWeight.w500,
                          )),
                    ],
                  ),
                ],
              ),
            ),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.fromLTRB(16, 14, 16, 18),
              decoration: const BoxDecoration(
                color: EfuridePalette.navy,
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(24),
                  topRight: Radius.circular(24),
                ),
              ),
              child: Row(
                children: [
                  const Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Are you safe?',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 20,
                              fontWeight: FontWeight.w900,
                              letterSpacing: -0.3,
                            )),
                        SizedBox(height: 4),
                        Text('Tap once — we handle the rest',
                            style: TextStyle(
                                color: Colors.white70, fontSize: 13)),
                      ],
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 10, vertical: 6),
                    decoration: BoxDecoration(
                      color: EfuridePalette.dropoff,
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: const Text('LIVE',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 10.5,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 0.8,
                        )),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ============================================================
  // VIEW 1 — IDLE / FAILED
  // ============================================================
  Widget _idleView() {
    return Scaffold(
      backgroundColor: EfuridePalette.cream,
      body: Column(
        children: [
          _header(),
          Expanded(
            child: ListView(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
              children: [
                _sosButton(),
                if (_error != null) ...[
                  const SizedBox(height: 12),
                  _errorBanner(),
                ],
                const SizedBox(height: 20),
                _sectionLabel('Quick dial'),
                const SizedBox(height: 10),
                _quickDialRow(),
                const SizedBox(height: 20),
                _sectionLabel('Trusted contacts'),
                const SizedBox(height: 10),
                _trustedContactsCard(),
                const SizedBox(height: 20),
                _sectionLabel('Safety tips'),
                const SizedBox(height: 10),
                _safetyTips(),
                const SizedBox(height: 20),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _sosButton() {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
            color: EfuridePalette.dropoff.withValues(alpha: 0.35),
            width: 1.5),
      ),
      child: Column(
        children: [
          GestureDetector(
            onTap: _startCountdown,
            child: Container(
              width: 160,
              height: 160,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: const LinearGradient(
                  colors: [
                    EfuridePalette.dropoff,
                    Color(0xFFB71C1C)
                  ],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                boxShadow: [
                  BoxShadow(
                    color:
                        EfuridePalette.dropoff.withValues(alpha: 0.40),
                    blurRadius: 24,
                    spreadRadius: 2,
                  ),
                ],
              ),
              child: const Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.sos, size: 56, color: Colors.white),
                  SizedBox(height: 6),
                  Text('TAP FOR SOS',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 12,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 1.2,
                      )),
                ],
              ),
            ),
          ),
          const SizedBox(height: 18),
          const Text(
            'Tap once. We alert your contacts and our safety team '
            'with your live location. You\'ll have 5 seconds to cancel.',
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 12.5,
              color: EfuridePalette.inkMuted,
              height: 1.5,
            ),
          ),
        ],
      ),
    );
  }

  Widget _errorBanner() {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: EfuridePalette.dropoff.withValues(alpha: 0.08),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
            color: EfuridePalette.dropoff.withValues(alpha: 0.35)),
      ),
      child: Row(
        children: [
          const Icon(Icons.error_outline,
              color: EfuridePalette.dropoff, size: 18),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              _error?.message ?? 'Something went wrong',
              style: const TextStyle(
                  fontSize: 12, color: EfuridePalette.dropoff),
            ),
          ),
          TextButton(
            onPressed: _fireAlert,
            child: const Text('Retry'),
          ),
        ],
      ),
    );
  }

  Widget _sectionLabel(String text) => Text(text,
      style: const TextStyle(
        fontSize: 14,
        fontWeight: FontWeight.w800,
        color: EfuridePalette.ink,
      ));

  // ── Quick dial ──
  Widget _quickDialRow() {
    return Row(
      children: [
        _quickDial(
          icon: Icons.local_police_outlined,
          label: 'Police',
          sub: '117',
          color: EfuridePalette.blueDeep,
          onTap: () => _dial('117'),
        ),
        const SizedBox(width: 10),
        _quickDial(
          icon: Icons.local_hospital_outlined,
          label: 'Ambulance',
          sub: '118',
          color: EfuridePalette.dropoff,
          onTap: () => _dial('118'),
        ),
        const SizedBox(width: 10),
        _quickDial(
          icon: Icons.support_agent,
          label: 'eFuride',
          sub: 'Support',
          color: EfuridePalette.merchantAccent,
          onTap: () => _dial('+242060000000'),
        ),
      ],
    );
  }

  Widget _quickDial({
    required IconData icon,
    required String label,
    required String sub,
    required Color color,
    required VoidCallback onTap,
  }) {
    return Expanded(
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(14),
        child: Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: color.withValues(alpha: 0.30)),
            boxShadow: [
              BoxShadow(
                color: color.withValues(alpha: 0.08),
                blurRadius: 8,
                offset: const Offset(0, 3),
              ),
            ],
          ),
          child: Column(
            children: [
              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  color: color.withValues(alpha: 0.12),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(icon, color: color, size: 20),
              ),
              const SizedBox(height: 8),
              Text(label,
                  style: const TextStyle(
                    fontSize: 12.5,
                    fontWeight: FontWeight.w900,
                    color: EfuridePalette.ink,
                  )),
              Text(sub,
                  style: TextStyle(
                    fontSize: 10.5,
                    fontWeight: FontWeight.w700,
                    color: color,
                  )),
            ],
          ),
        ),
      ),
    );
  }

  // ── Trusted contacts ──
  Widget _trustedContactsCard() {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: EfuridePalette.divider),
      ),
      child: _contactsLoading
          ? const Padding(
              padding: EdgeInsets.all(20),
              child: Center(
                child: SizedBox(
                  width: 22,
                  height: 22,
                  child: CircularProgressIndicator(
                    strokeWidth: 2,
                    // FIX: was `EfuridePalette.dropzone_or_inkMuted`
                    // (a typo) — correct field is `inkMuted`.
                    color: EfuridePalette.inkMuted,
                  ),
                ),
              ),
            )
          : _contacts.isEmpty
              ? Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    children: [
                      const Icon(Icons.contact_phone_outlined,
                          size: 32, color: EfuridePalette.inkMuted),
                      const SizedBox(height: 10),
                      const Text(
                        'No trusted contacts yet',
                        style: TextStyle(
                            fontSize: 13.5,
                            fontWeight: FontWeight.w800,
                            color: EfuridePalette.ink),
                      ),
                      const SizedBox(height: 4),
                      const Text(
                        'Add contacts so SOS can reach someone',
                        style: TextStyle(
                            fontSize: 12,
                            color: EfuridePalette.inkMuted),
                        textAlign: TextAlign.center,
                      ),
                      const SizedBox(height: 12),
                      OutlinedButton.icon(
                        onPressed: () async {
                          await Navigator.pushNamed(
                              context, '/sos_setup');
                          _loadContacts();
                        },
                        icon: const Icon(Icons.add, size: 16),
                        label: const Text('Add contact'),
                        style: OutlinedButton.styleFrom(
                          foregroundColor: EfuridePalette.blueDeep,
                          side: const BorderSide(
                              color: EfuridePalette.blueDeep),
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10)),
                        ),
                      ),
                    ],
                  ),
                )
              : Column(
                  children: [
                    for (var i = 0; i < _contacts.length; i++) ...[
                      _contactRow(_contacts[i], i),
                      if (i < _contacts.length - 1)
                        const Divider(
                          height: 1,
                          indent: 14,
                          endIndent: 14,
                          color: EfuridePalette.divider,
                        ),
                    ],
                    const Divider(
                        height: 1, color: EfuridePalette.divider),
                    InkWell(
                      onTap: () async {
                        await Navigator.pushNamed(
                            context, '/sos_setup');
                        _loadContacts();
                      },
                      child: const Padding(
                        padding: EdgeInsets.all(12),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(Icons.edit_outlined,
                                size: 14,
                                color: EfuridePalette.blueDeep),
                            SizedBox(width: 6),
                            Text('Manage contacts',
                                style: TextStyle(
                                  fontSize: 12,
                                  fontWeight: FontWeight.w800,
                                  color: EfuridePalette.blueDeep,
                                )),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
    );
  }

  Widget _contactRow(Map<String, dynamic> c, int i) {
    final name = c['name']?.toString() ?? '';
    final phone = c['phone']?.toString() ?? '';
    return InkWell(
      onTap: () => _dial(phone),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Row(
          children: [
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: EfuridePalette.blueDeep.withValues(alpha: 0.10),
                shape: BoxShape.circle,
              ),
              child: Center(
                child: Text(
                  name.isNotEmpty ? name[0].toUpperCase() : '?',
                  style: const TextStyle(
                    color: EfuridePalette.blueDeep,
                    fontSize: 15,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(name,
                      style: const TextStyle(
                        fontSize: 13.5,
                        fontWeight: FontWeight.w800,
                        color: EfuridePalette.ink,
                      )),
                  const SizedBox(height: 2),
                  Text(phone,
                      style: const TextStyle(
                          fontSize: 11.5,
                          color: EfuridePalette.inkMuted)),
                ],
              ),
            ),
            Container(
              width: 36,
              height: 36,
              decoration: BoxDecoration(
                color: EfuridePalette.online.withValues(alpha: 0.12),
                shape: BoxShape.circle,
              ),
              child: const Icon(Icons.call,
                  color: EfuridePalette.online, size: 16),
            ),
          ],
        ),
      ),
    );
  }

  // ── Safety tips ──
  Widget _safetyTips() {
    final tips = [
      'Stay in a well-lit, public place if possible.',
      'Share your live trip with a trusted contact.',
      'Your driver\'s name and plate are always in the app.',
    ];
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: EfuridePalette.dropoff.withValues(alpha: 0.06),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
            color: EfuridePalette.dropoff.withValues(alpha: 0.25)),
      ),
      child: Column(
        children: tips.map((t) {
          return Padding(
            padding: const EdgeInsets.symmetric(vertical: 6),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const KIcon(Icons.shield_outlined,
                    size: 14, color: EfuridePalette.dropoff),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(t,
                      style: const TextStyle(
                        fontSize: 12,
                        color: EfuridePalette.ink,
                        height: 1.45,
                      )),
                ),
              ],
            ),
          );
        }).toList(),
      ),
    );
  }

  // ============================================================
  // VIEW 2 — COUNTDOWN
  // ============================================================
  Widget _countdownView() {
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, _) {
        if (didPop) return;
        _cancelCountdown();
      },
      child: Scaffold(
        backgroundColor: EfuridePalette.dropoff,
        body: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              children: [
                const Spacer(),
                Stack(
                  alignment: Alignment.center,
                  children: [
                    SizedBox(
                      width: 220,
                      height: 220,
                      child: CircularProgressIndicator(
                        value: _countdown / 5,
                        strokeWidth: 10,
                        backgroundColor:
                            Colors.white.withValues(alpha: 0.20),
                        valueColor: const AlwaysStoppedAnimation(
                            Colors.white),
                      ),
                    ),
                    Text('$_countdown',
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 96,
                          fontWeight: FontWeight.w900,
                          height: 1,
                        )),
                  ],
                ),
                const SizedBox(height: 32),
                const Text('TRIGGERING SOS',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 18,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 2,
                    )),
                const SizedBox(height: 12),
                Text(
                  'Your emergency contacts will be alerted with your '
                  'live location in $_countdown second${_countdown == 1 ? '' : 's'}.',
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    color: Colors.white70,
                    fontSize: 14,
                    height: 1.5,
                  ),
                ),
                const Spacer(),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton.icon(
                    onPressed: _cancelCountdown,
                    icon: const Icon(Icons.close, size: 20),
                    label: const Text('CANCEL — I\'M SAFE',
                        style: TextStyle(
                            fontSize: 15,
                            fontWeight: FontWeight.w900)),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.white,
                      foregroundColor: EfuridePalette.dropoff,
                      minimumSize: const Size(0, 56),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(14)),
                      elevation: 0,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ============================================================
  // VIEW 3 — ACTIVE
  // ============================================================
  Widget _activeView() {
    final sending = _state == _SOSState.sending;
    return PopScope(
      canPop: false,
      child: Scaffold(
        backgroundColor: EfuridePalette.dropoff,
        body: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              children: [
                const Spacer(),
                Container(
                  padding: const EdgeInsets.all(28),
                  decoration: BoxDecoration(
                    color: Colors.white.withValues(alpha: 0.15),
                    shape: BoxShape.circle,
                  ),
                  child: Icon(
                    sending ? Icons.sync : Icons.sos,
                    size: 72,
                    color: Colors.white,
                  ),
                ),
                const SizedBox(height: 24),
                Text(
                  sending ? 'SENDING ALERT…' : 'SOS ACTIVE',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 28,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 2,
                  ),
                ),
                const SizedBox(height: 12),
                Text(
                  sending
                      ? 'Contacting your emergency contacts and safety team…'
                      : 'Your emergency contacts and our safety team have '
                          'been alerted with your location.',
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    color: Colors.white70,
                    fontSize: 14,
                    height: 1.5,
                  ),
                ),
                const SizedBox(height: 20),
                if (!sending && _contacts.isNotEmpty)
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 16, vertical: 12),
                    decoration: BoxDecoration(
                      color: Colors.white.withValues(alpha: 0.12),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Column(
                      children: [
                        const Text('NOTIFIED',
                            style: TextStyle(
                              color: Colors.white70,
                              fontSize: 10.5,
                              fontWeight: FontWeight.w900,
                              letterSpacing: 1,
                            )),
                        const SizedBox(height: 6),
                        Text(
                          _contacts
                              .map((c) => c['name']?.toString() ?? '')
                              .where((n) => n.isNotEmpty)
                              .join(' · '),
                          textAlign: TextAlign.center,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 13,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                      ],
                    ),
                  ),
                const Spacer(),
                if (!sending)
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton.icon(
                      onPressed: _resolveSOS,
                      icon: const Icon(Icons.check_circle, size: 20),
                      label: const Text('I\'m safe — end alert',
                          style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w900)),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.white,
                        foregroundColor: EfuridePalette.dropoff,
                        minimumSize: const Size(0, 56),
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(14)),
                        elevation: 0,
                      ),
                    ),
                  )
                else
                  const CircularProgressIndicator(color: Colors.white),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
