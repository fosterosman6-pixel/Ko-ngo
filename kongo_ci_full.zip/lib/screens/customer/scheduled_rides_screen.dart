﻿// lib/screens/customer/scheduled_rides_screen.dart

import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:intl/intl.dart';
import 'package:efuride_app/config/app_images.dart';
import 'package:efuride_app/widgets/app_image.dart';
import 'package:efuride_app/utils/app_error.dart';
import 'package:efuride_app/utils/error_ui.dart';
import 'package:efuride_app/l10n/app_strings.dart';
import 'package:efuride_app/config/country_config.dart';

class _Palette {
  static const cream = Color(0xFFFAF6EE);
  static const ink = Color(0xFF1A1A1A);
  static const inkMuted = Color(0xFF575047);
  static const accent = Color(0xFFF2B705);
  static const accentInk = Color(0xFF0B1220);
  static const divider = Color(0xFFE8E2D5);
  static const blue = Color(0xFF1E88E5);
}

class ScheduledRidesScreen extends StatefulWidget {
  const ScheduledRidesScreen({super.key});

  @override
  State<ScheduledRidesScreen> createState() => _ScheduledRidesScreenState();
}

class _ScheduledRidesScreenState extends State<ScheduledRidesScreen> {
  List<Map<String, dynamic>> _scheduledRides = [];
  bool _isLoading = true;
  AppError? _error;

  @override
  void initState() {
    super.initState();
    _loadScheduledRides();
  }

  Future<void> _loadScheduledRides() async {
    setState(() {
      _isLoading = true;
      _error = null;
    });

    try {
      final userId = Supabase.instance.client.auth.currentUser?.id;
      if (userId == null) throw Exception('Not signed in');

      final response = await Supabase.instance.client
          .from('rides')
          .select('id, pickup_address, dropoff_address, scheduled_at, fare, '
              'fare_after_discount, service_type, vehicle_type, payment_method')
          .eq('customer_id', userId)
          .eq('status', 'scheduled')
          .order('scheduled_at', ascending: true);

      if (!mounted) return;
      setState(() {
        _scheduledRides = List<Map<String, dynamic>>.from(response);
        _isLoading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _isLoading = false;
        _error = AppError.from(e, onRetry: _loadScheduledRides);
      });
    }
  }

  Future<void> _cancelScheduledRide(String id) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(tr('Cancel scheduled ride?')),
        content: Text(
            tr('This scheduled ride will be removed and will not be booked.')),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: Text(tr('Keep')),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            onPressed: () => Navigator.pop(ctx, true),
            child: Text(tr('Cancel ride')),
          ),
        ],
      ),
    );

    if (confirmed != true) return;

    try {
      await Supabase.instance.client.from('rides').update({
        'status': 'cancelled',
        'cancelled_by': 'customer',
        'cancellation_reason': 'Scheduled ride cancelled',
        'cancelled_at': DateTime.now().toUtc().toIso8601String(),
      }).eq('id', id).eq('status', 'scheduled');

      if (!mounted) return;
      setState(() =>
          _scheduledRides.removeWhere((r) => r['id'].toString() == id));

      ErrorUI.showSnack(
        context,
        AppError(
          title: tr('Ride removed'),
          message: tr('Your scheduled ride has been cancelled.'),
          icon: Icons.check_circle_outline,
        ),
      );
    } catch (e) {
      if (!mounted) return;
      ErrorUI.showSnack(
        context,
        AppError.from(e, onRetry: () => _cancelScheduledRide(id)),
      );
    }
  }

  /// New bookings go through the normal booking screens (map points and
  /// a real price), with "Later" picked on the review screen.
  void _bookNew() => Navigator.pop(context, 'book');

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _Palette.cream,
      appBar: AppBar(
        backgroundColor: _Palette.cream,
        elevation: 0,
        iconTheme: const IconThemeData(color: _Palette.ink),
        title: Text(
          tr('Scheduled Rides'),
          style: TextStyle(
            color: _Palette.ink,
            fontWeight: FontWeight.bold,
            fontSize: 18,
          ),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.add, color: _Palette.ink),
            onPressed: _bookNew,
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: _loadScheduledRides,
        color: _Palette.accent,
        child: _buildBody(),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _bookNew,
        backgroundColor: const Color(0xFFF2B705),
        child: const Icon(Icons.add, color: const Color(0xFF0B1220)),
      ),
    );
  }

  Widget _buildBody() {
    if (_isLoading) {
      return const Center(
          child: CircularProgressIndicator(color: _Palette.accent));
    }

    if (_error != null) {
      return ListView(
        physics: const AlwaysScrollableScrollPhysics(),
        children: [
          const SizedBox(height: 60),
          ErrorUI.inline(_error!),
        ],
      );
    }

    if (_scheduledRides.isEmpty) {
      return ListView(
        physics: const AlwaysScrollableScrollPhysics(),
        children: [
          const SizedBox(height: 60),
          Center(
            child: AppImage(
              AppImages.calendar,
              size: 72,
              tint: _Palette.inkMuted,
              fallbackIcon: Icons.schedule,
            ),
          ),
          const SizedBox(height: 16),
          Center(
            child: Text(
              tr('No scheduled rides'),
              style: TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.bold,
                  color: _Palette.ink),
            ),
          ),
          const SizedBox(height: 4),
          Center(
            child: Text(
              tr('Book a ride ahead — we find your driver 10 minutes before.'),
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 13.5, color: _Palette.inkMuted),
            ),
          ),
          const SizedBox(height: 20),
          Center(
            child: ElevatedButton.icon(
              onPressed: _bookNew,
              icon: const Icon(Icons.add),
              label: Text(tr('Schedule a ride')),
              style: ElevatedButton.styleFrom(
                backgroundColor: _Palette.accent,
                foregroundColor: _Palette.accentInk,
                padding: const EdgeInsets.symmetric(
                    horizontal: 24, vertical: 12),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12)),
              ),
            ),
          ),
        ],
      );
    }

    return ListView.separated(
      padding: const EdgeInsets.all(16),
      itemCount: _scheduledRides.length,
      separatorBuilder: (_, __) => const SizedBox(height: 8),
      itemBuilder: (_, i) {
        final ride = _scheduledRides[i];
        final pickup = (ride['pickup_address'] ?? 'Pickup').toString();
        final dropoff = (ride['dropoff_address'] ?? 'Dropoff').toString();
        final scheduledTime = DateTime.tryParse(
                ride['scheduled_at']?.toString() ?? '')
            ?.toLocal();
        final price = (ride['fare_after_discount'] as num?)?.toDouble() ??
            (ride['fare'] as num?)?.toDouble();

        return Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: _Palette.divider),
          ),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: _Palette.blue.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: AppImage(
                  AppImages.calendar,
                  size: 24,
                  fallbackIcon: Icons.schedule,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      pickup,
                      style: const TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                          color: _Palette.ink),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 2),
                    Row(
                      children: [
                        const Icon(Icons.arrow_downward,
                            size: 12, color: _Palette.inkMuted),
                        const SizedBox(width: 4),
                        Expanded(
                          child: Text(
                            dropoff,
                            style: const TextStyle(
                                fontSize: 13.5, color: _Palette.inkMuted),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 6),
                    Text(
                      scheduledTime != null
                          ? DateFormat('EEE, MMM d · h:mm a')
                              .format(scheduledTime)
                          : tr('Time unknown'),
                      style: const TextStyle(
                          fontSize: 13,
                          color: _Palette.blue,
                          fontWeight: FontWeight.w600),
                    ),
                    if (price != null) ...[
                      const SizedBox(height: 2),
                      Text(
                        '${CountryConfig.money(price)} · ${(ride['vehicle_type'] ?? '').toString()}',
                        style: const TextStyle(
                            fontSize: 12.5, color: _Palette.inkMuted),
                      ),
                    ],
                  ],
                ),
              ),
              IconButton(
                icon: const Icon(Icons.close,
                    size: 18, color: _Palette.inkMuted),
                onPressed: () =>
                    _cancelScheduledRide(ride['id'].toString()),
              ),
            ],
          ),
        );
      },
    );
  }
}
