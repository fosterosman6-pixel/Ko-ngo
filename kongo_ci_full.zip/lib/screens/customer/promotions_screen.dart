// lib/screens/customer/promotions_screen.dart
//
// Loads promotions from Supabase. Copy code, apply code.
// Returns the applied code to the caller via Navigator.pop.

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:intl/intl.dart';
import 'package:efuride_app/config/efuride_palette.dart';
import 'package:efuride_app/utils/app_error.dart';
import 'package:efuride_app/utils/error_ui.dart';
import 'package:efuride_app/widgets/k_icon.dart';

class PromotionsScreen extends StatefulWidget {
  /// When true, tapping "Apply" pops the code back to the caller.
  final bool selectMode;

  const PromotionsScreen({super.key, this.selectMode = false});

  @override
  State<PromotionsScreen> createState() => _PromotionsScreenState();
}

class _PromotionsScreenState extends State<PromotionsScreen> {
  List<Map<String, dynamic>> _active = [];
  List<Map<String, dynamic>> _expired = [];
  bool _isLoading = true;
  AppError? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _isLoading = true;
      _error = null;
    });

    try {
      final nowIso = DateTime.now().toUtc().toIso8601String();
      final rows = await Supabase.instance.client
          .from('promotions')
          .select(
              'id, title, description, code, expires_at, '
              'discount_percent, discount_amount, min_fare, '
              'is_active, created_at')
          .eq('is_active', true)
          .order('created_at', ascending: false)
          .timeout(const Duration(seconds: 15));

      final active = <Map<String, dynamic>>[];
      final expired = <Map<String, dynamic>>[];

      for (final r in rows) {
        final exp = r['expires_at']?.toString();
        if (exp == null || exp.isEmpty) {
          active.add(r);
          continue;
        }
        final dt = DateTime.tryParse(exp);
        if (dt == null) {
          active.add(r);
        } else if (dt.isAfter(DateTime.now())) {
          active.add(r);
        } else {
          expired.add(r);
        }
      }

      if (!mounted) return;
      setState(() {
        _active = active;
        _expired = expired;
        _isLoading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _isLoading = false;
        _error = AppError.from(e, onRetry: _load);
      });
    }
  }

  // ============================================================
  // ACTIONS
  // ============================================================
  Future<void> _copyCode(String code) async {
    await Clipboard.setData(ClipboardData(text: code));
    if (!mounted) return;
    ErrorUI.showSnack(
      context,
      AppError(
        title: 'Code copied',
        message: '$code is ready to paste.',
        icon: Icons.check_circle_outline,
      ),
    );
  }

  void _apply(Map<String, dynamic> promo) {
    final code = promo['code']?.toString() ?? '';
    if (code.isEmpty) return;

    if (widget.selectMode) {
      Navigator.pop(context, code);
      return;
    }

    // Non-select mode: still copy + inform.
    _copyCode(code);
  }

  // ============================================================
  // BUILD
  // ============================================================
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: EfuridePalette.cream,
      body: Column(
        children: [
          _header(),
          Expanded(child: _body()),
        ],
      ),
    );
  }

  Widget _header() {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          colors: [EfuridePalette.blue, EfuridePalette.blueDeep],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
      ),
      child: SafeArea(
        bottom: false,
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(8, 8, 16, 12),
              child: Row(
                children: [
                  IconButton(
                    onPressed: () => Navigator.pop(context),
                    icon: const Icon(Icons.arrow_back,
                        color: Colors.white),
                  ),
                  const SizedBox(width: 4),
                  Container(
                    width: 36,
                    height: 36,
                    decoration: const BoxDecoration(
                      color: Colors.white,
                      shape: BoxShape.circle,
                    ),
                    child: const Center(
                      child: Icon(Icons.local_offer_rounded,
                          color: EfuridePalette.accent, size: 20),
                    ),
                  ),
                  const SizedBox(width: 10),
                  const Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('EFURIDE',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 16,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 1.2,
                            height: 1.05,
                          )),
                      SizedBox(height: 2),
                      Text('Promotions',
                          style: TextStyle(
                            color: Colors.white70,
                            fontSize: 11.5,
                            fontWeight: FontWeight.w500,
                          )),
                    ],
                  ),
                ],
              ),
            ),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 18),
              decoration: const BoxDecoration(
                color: EfuridePalette.navy,
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(24),
                  topRight: Radius.circular(24),
                ),
              ),
              child: Row(
                children: [
                  const Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Offers & codes',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 22,
                              fontWeight: FontWeight.w900,
                              letterSpacing: -0.3,
                            )),
                        SizedBox(height: 4),
                        Text('Save on every ride',
                            style: TextStyle(
                                color: Colors.white70, fontSize: 13)),
                      ],
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 10, vertical: 5),
                    decoration: BoxDecoration(
                      color: EfuridePalette.accent,
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Text('${_active.length} active',
                        style: const TextStyle(
                          color: EfuridePalette.accentInk,
                          fontSize: 11,
                          fontWeight: FontWeight.w900,
                        )),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _body() {
    if (_isLoading) {
      return const Center(
        child: CircularProgressIndicator(color: EfuridePalette.accent),
      );
    }
    if (_error != null) return ErrorUI.inline(_error!);

    if (_active.isEmpty && _expired.isEmpty) return _emptyState();

    return RefreshIndicator(
      onRefresh: _load,
      color: EfuridePalette.accent,
      child: ListView(
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
        physics: const AlwaysScrollableScrollPhysics(),
        children: [
          if (_active.isNotEmpty) ...[
            _sectionLabel('Active offers'),
            const SizedBox(height: 10),
            ..._active.map(_promoCard),
            const SizedBox(height: 20),
          ],
          if (_expired.isNotEmpty) ...[
            _sectionLabel('Expired'),
            const SizedBox(height: 10),
            ..._expired.map((p) => _promoCard(p, expired: true)),
            const SizedBox(height: 20),
          ],
        ],
      ),
    );
  }

  Widget _sectionLabel(String text) => Text(text,
      style: const TextStyle(
        fontSize: 14,
        fontWeight: FontWeight.w800,
        color: EfuridePalette.ink,
      ));

  // ============================================================
  // PROMO CARD
  // ============================================================
  Widget _promoCard(Map<String, dynamic> p, {bool expired = false}) {
    final title = p['title']?.toString() ?? 'Special offer';
    final desc = p['description']?.toString() ?? '';
    final code = p['code']?.toString() ?? '';
    final expiresAt = p['expires_at']?.toString();
    final percent = (p['discount_percent'] as num?)?.toDouble();
    final amount = (p['discount_amount'] as num?)?.toDouble();
    final minFare = (p['min_fare'] as num?)?.toDouble();

    final accent = expired
        ? EfuridePalette.inkMuted
        : EfuridePalette.accent;

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: expired
              ? EfuridePalette.divider
              : accent.withValues(alpha: 0.35),
          width: expired ? 1 : 1.4,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Hero band
          Container(
            padding: const EdgeInsets.fromLTRB(16, 14, 16, 12),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  accent.withValues(alpha: expired ? 0.06 : 0.14),
                  accent.withValues(alpha: 0.02),
                ],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: const BorderRadius.only(
                topLeft: Radius.circular(15),
                topRight: Radius.circular(15),
              ),
            ),
            child: Row(
              children: [
                Container(
                  width: 44,
                  height: 44,
                  decoration: BoxDecoration(
                    color: accent.withValues(alpha: 0.15),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Icon(
                    expired
                        ? Icons.history
                        : Icons.local_offer_rounded,
                    color: accent,
                    size: 22,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(title,
                          style: TextStyle(
                            fontSize: 15,
                            fontWeight: FontWeight.w900,
                            color: expired
                                ? EfuridePalette.inkMuted
                                : EfuridePalette.ink,
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis),
                      if (desc.isNotEmpty) ...[
                        const SizedBox(height: 2),
                        Text(desc,
                            style: const TextStyle(
                                fontSize: 11.5,
                                color: EfuridePalette.inkMuted,
                                height: 1.3),
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis),
                      ],
                    ],
                  ),
                ),
                if (!expired && (percent != null || amount != null))
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 10, vertical: 6),
                    decoration: BoxDecoration(
                      color: accent,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Text(
                      percent != null
                          ? '${percent.toStringAsFixed(0)}% OFF'
                          : '−${amount!.toStringAsFixed(0)}',
                      style: const TextStyle(
                        color: EfuridePalette.accentInk,
                        fontSize: 11.5,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 0.3,
                      ),
                    ),
                  ),
              ],
            ),
          ),

          // Code + expiry
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 12),
            child: Column(
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 12, vertical: 10),
                        decoration: BoxDecoration(
                          color: EfuridePalette.cream,
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(
                            color: expired
                                ? EfuridePalette.divider
                                : accent.withValues(alpha: 0.35),
                            width: 1.2,
                            style: BorderStyle.solid,
                          ),
                        ),
                        child: Row(
                          children: [
                            Icon(Icons.confirmation_number_outlined,
                                size: 16, color: accent),
                            const SizedBox(width: 8),
                            Expanded(
                              child: Text(
                                code,
                                style: TextStyle(
                                  fontFamily: 'monospace',
                                  fontSize: 15,
                                  fontWeight: FontWeight.w900,
                                  letterSpacing: 1.5,
                                  color: expired
                                      ? EfuridePalette.inkMuted
                                      : EfuridePalette.ink,
                                ),
                              ),
                            ),
                            if (!expired)
                              GestureDetector(
                                onTap: () => _copyCode(code),
                                child: Icon(Icons.copy,
                                    size: 16,
                                    color: EfuridePalette.inkMuted),
                              ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                Row(
                  children: [
                    if (expiresAt != null) ...[
                      Icon(
                        expired ? Icons.cancel_outlined : Icons.schedule,
                        size: 12,
                        color: expired
                            ? EfuridePalette.dropoff
                            : EfuridePalette.inkMuted,
                      ),
                      const SizedBox(width: 4),
                      Text(
                        _expiryLabel(expiresAt, expired),
                        style: TextStyle(
                          fontSize: 11,
                          fontWeight: FontWeight.w700,
                          color: expired
                              ? EfuridePalette.dropoff
                              : EfuridePalette.inkMuted,
                        ),
                      ),
                    ],
                    if (minFare != null && minFare > 0) ...[
                      const SizedBox(width: 12),
                      const Icon(Icons.info_outline,
                          size: 12, color: EfuridePalette.inkMuted),
                      const SizedBox(width: 4),
                      Text(
                        'Min ${minFare.toStringAsFixed(0)} XAF',
                        style: const TextStyle(
                          fontSize: 11,
                          fontWeight: FontWeight.w700,
                          color: EfuridePalette.inkMuted,
                        ),
                      ),
                    ],
                  ],
                ),
              ],
            ),
          ),

          // Apply button
          if (!expired)
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 14),
              child: Row(
                children: [
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: () => _copyCode(code),
                      icon: const Icon(Icons.copy, size: 14),
                      label: const Text('Copy',
                          style: TextStyle(
                              fontSize: 13,
                              fontWeight: FontWeight.w800)),
                      style: OutlinedButton.styleFrom(
                        foregroundColor: EfuridePalette.ink,
                        side: const BorderSide(
                            color: EfuridePalette.divider),
                        minimumSize: const Size(0, 44),
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10)),
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    flex: 2,
                    child: ElevatedButton.icon(
                      onPressed: () => _apply(p),
                      icon: const Icon(Icons.check_circle_outline,
                          size: 16),
                      label: Text(
                        widget.selectMode
                            ? 'Apply code'
                            : 'Use code',
                        style: const TextStyle(
                            fontSize: 13.5,
                            fontWeight: FontWeight.w900),
                      ),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: accent,
                        foregroundColor: EfuridePalette.accentInk,
                        minimumSize: const Size(0, 44),
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10)),
                        elevation: 0,
                      ),
                    ),
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }

  String _expiryLabel(String iso, bool expired) {
    final dt = DateTime.tryParse(iso)?.toLocal();
    if (dt == null) return '';
    if (expired) {
      return 'Expired ${DateFormat('MMM d').format(dt)}';
    }
    final diff = dt.difference(DateTime.now());
    if (diff.inDays <= 0) return 'Expires today';
    if (diff.inDays == 1) return 'Expires tomorrow';
    if (diff.inDays < 7) return 'Expires in ${diff.inDays} days';
    return 'Expires ${DateFormat('MMM d').format(dt)}';
  }

  // ============================================================
  // EMPTY
  // ============================================================
  Widget _emptyState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 100,
              height: 100,
              decoration: BoxDecoration(
                color: EfuridePalette.accent.withValues(alpha: 0.12),
                shape: BoxShape.circle,
              ),
              child: const KIcon(Icons.local_offer_outlined,
                  size: 48, color: EfuridePalette.accent),
            ),
            const SizedBox(height: 20),
            const Text('No promotions right now',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w900,
                  color: EfuridePalette.ink,
                )),
            const SizedBox(height: 8),
            const Text(
              'Check back soon — we\'ll notify you when there\'s an offer.',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 13,
                color: EfuridePalette.inkMuted,
                height: 1.5,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
