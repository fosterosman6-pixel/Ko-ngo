// lib/screens/customer/trip_complete_screen.dart

import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:efuride_app/config/country_config.dart';
import 'package:efuride_app/config/app_images.dart';
import 'package:efuride_app/widgets/app_image.dart';
import 'package:efuride_app/utils/app_error.dart';
import 'package:efuride_app/utils/error_ui.dart';
import 'package:efuride_app/l10n/app_strings.dart';
import 'package:efuride_app/widgets/k_icon.dart';

class TripCompleteScreen extends StatefulWidget {
  final double finalFare;
  final String tripDistance;
  final String? rideId;
  final String? driverId;
  final String? driverName;

  const TripCompleteScreen({
    super.key,
    required this.finalFare,
    required this.tripDistance,
    this.rideId,
    this.driverId,
    this.driverName,
  });

  @override
  State<TripCompleteScreen> createState() => _TripCompleteScreenState();
}

class _TripCompleteScreenState extends State<TripCompleteScreen> {
  int _rating = 0;
  bool _submitting = false;
  bool _submitted = false;

  // From the server: what was really charged and how.
  double? _paid;
  String? _payMethod;
  String? _payStatus;
  String? _distanceText;
  bool _isParcel = false;
  final TextEditingController _noteCtrl = TextEditingController();
  double? _tipped; // set once the rider has tipped (or the server says so)

  @override
  void initState() {
    super.initState();
    _loadTrip();
  }

  @override
  void dispose() {
    _noteCtrl.dispose();
    super.dispose();
  }

  Future<void> _loadTrip() async {
    final id = widget.rideId;
    if (id == null) return;
    try {
      final r = await Supabase.instance.client
          .from('rides')
          .select('fare, fare_after_discount, paid_amount, payment_method, '
              'payment_status, distance_km, service_type, customer_rating')
          .eq('id', id)
          .maybeSingle();
      if (r == null || !mounted) return;
      final km = (r['distance_km'] as num?)?.toDouble();
      setState(() {
        _paid = (r['paid_amount'] as num?)?.toDouble() ??
            (r['fare_after_discount'] as num?)?.toDouble() ??
            (r['fare'] as num?)?.toDouble();
        _payMethod = r['payment_method']?.toString();
        _payStatus = r['payment_status']?.toString();
        if (km != null) _distanceText = '${km.toStringAsFixed(1)} km';
        _isParcel = (r['service_type'] ?? '').toString() == 'Delivery';
        if (r['customer_rating'] != null) _submitted = true;
      });
      try {
        final t = await Supabase.instance.client
            .rpc('trip_tip_amount', params: {'p_ride': id});
        if (mounted && t != null) {
          setState(() => _tipped = (t as num).toDouble());
        }
      } catch (_) {
        // tips not installed yet: the button just stays hidden
      }
    } catch (e) {
      debugPrint('trip complete load failed: $e');
    }
  }

  String get _payLine {
    if (_payMethod == 'wallet' && _payStatus == 'paid') {
      return tr('Paid from your wallet');
    }
    if (_payMethod == 'card' && _payStatus == 'paid') return tr('Paid by card');
    return _isParcel ? tr('Pay the courier in cash') : tr('Pay the driver in cash');
  }

  static const _cream = Color(0xFFFAF6EE);
  static const _ink = Color(0xFF1A1A1A);
  static const _inkMuted = Color(0xFF575047);
  static const _accent = Color(0xFFF2B705);
  static const _accentInk = Color(0xFF0B1220);
  static const _divider = Color(0xFFE8E2D5);
  static const _blue = Color(0xFF1E88E5);

  Future<void> _submitRating() async {
    if (_rating == 0) {
      ErrorUI.showSnack(
        context,
        AppError(
          title: tr('Pick a rating'),
          message: tr('Tap a star to rate your driver.'),
          icon: Icons.star_border,
        ),
      );
      return;
    }

    setState(() => _submitting = true);
    try {
      final userId = Supabase.instance.client.auth.currentUser?.id;
      if (userId == null) throw Exception('Not signed in');

      if (widget.rideId != null) {
        await Supabase.instance.client.from('rides').update({
          'customer_rating': _rating,
          'customer_rated_at': DateTime.now().toUtc().toIso8601String(),
          if (_noteCtrl.text.trim().isNotEmpty)
            'customer_rating_note': _noteCtrl.text.trim(),
        }).eq('id', widget.rideId!);
      }

      // The driver's average is worked out on the server.

      if (!mounted) return;
      setState(() {
        _submitting = false;
        _submitted = true;
      });

      ErrorUI.showSnack(
        context,
        AppError(
          title: tr('Thanks for rating!'),
          message: tr('Your feedback helps improve ko!ngo.'),
          icon: Icons.check_circle_outline,
        ),
      );
    } catch (e) {
      if (!mounted) return;
      setState(() => _submitting = false);
      ErrorUI.showSnack(
        context,
        AppError.from(e, onRetry: _submitRating),
      );
    }
  }

  // ── Tip the driver from the wallet ───────────────────────────────
  Future<void> _openTipSheet() async {
    final id = widget.rideId;
    if (id == null) return;
    final total = _paid ?? widget.finalFare;
    final amountCtrl = TextEditingController();
    bool sending = false;
    String? error;

    final done = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setSheet) {
          Future<void> send() async {
            final v = double.tryParse(amountCtrl.text.trim().replaceAll(',', '.'));
            if (v == null || v <= 0) {
              setSheet(() => error = tr('Tip amount'));
              return;
            }
            setSheet(() {
              sending = true;
              error = null;
            });
            try {
              final res = await Supabase.instance.client
                  .rpc('give_tip', params: {'p_ride': id, 'p_amount': v});
              final m = Map<String, dynamic>.from(res as Map);
              if (m['ok'] == true) {
                if (ctx.mounted) Navigator.pop(ctx, true);
                if (mounted) setState(() => _tipped = v);
              } else {
                setSheet(() {
                  sending = false;
                  error = (m['message'] ?? '').toString();
                });
              }
            } catch (e) {
              setSheet(() {
                sending = false;
                error = AppError.from(e).message;
              });
            }
          }

          final presets = <double>[
            (total * 0.05),
            (total * 0.10),
            (total * 0.15),
          ].map((v) => v.roundToDouble()).where((v) => v >= 1).toSet().toList();

          return Padding(
            padding: EdgeInsets.fromLTRB(
                20, 20, 20, 20 + MediaQuery.of(ctx).viewInsets.bottom),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Text(tr('Tip your driver'),
                    style: const TextStyle(
                        fontSize: 18, fontWeight: FontWeight.bold, color: _ink)),
                const SizedBox(height: 14),
                if (presets.isNotEmpty)
                  Wrap(
                    spacing: 8,
                    children: presets
                        .map((v) => ActionChip(
                              label: Text(CountryConfig.money(v)),
                              onPressed: sending
                                  ? null
                                  : () => amountCtrl.text = v.toStringAsFixed(0),
                            ))
                        .toList(),
                  ),
                const SizedBox(height: 12),
                TextField(
                  controller: amountCtrl,
                  enabled: !sending,
                  keyboardType:
                      const TextInputType.numberWithOptions(decimal: true),
                  decoration: InputDecoration(
                    labelText: tr('Custom amount'),
                    border: const OutlineInputBorder(),
                  ),
                ),
                if (error != null) ...[
                  const SizedBox(height: 8),
                  Text(error!, style: const TextStyle(color: Colors.red)),
                ],
                const SizedBox(height: 14),
                ElevatedButton(
                  onPressed: sending ? null : send,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: _accent,
                    foregroundColor: _accentInk,
                    padding: const EdgeInsets.symmetric(vertical: 14),
                  ),
                  child: sending
                      ? const SizedBox(
                          width: 18,
                          height: 18,
                          child: CircularProgressIndicator(strokeWidth: 2))
                      : Text(tr('Send tip'),
                          style: const TextStyle(fontWeight: FontWeight.bold)),
                ),
              ],
            ),
          );
        },
      ),
    );
    amountCtrl.dispose();
    if (done == true && mounted) {
      ErrorUI.showSnack(
        context,
        AppError(
          title: tr('Tip sent. Thank you!'),
          message: '',
          icon: Icons.check_circle_outline,
        ),
      );
    }
  }

  // ── Share a plain-text receipt ────────────────────────────────────
  void _shareReceipt() {
    final b = StringBuffer()
      ..writeln('ko!ngo')
      ..writeln('${tr('Total')}: ${CountryConfig.money(_paid ?? widget.finalFare)}')
      ..writeln('${tr('Payment')}: $_payLine')
      ..writeln('${tr('Distance')}: ${_distanceText ?? widget.tripDistance}');
    if (widget.rideId != null && widget.rideId!.length >= 8) {
      b.writeln('${tr('Trip ID')}: #${widget.rideId!.substring(0, 8)}');
    }
    if (_tipped != null) {
      b.writeln('${tr('Tip')}: ${CountryConfig.money(_tipped!)}');
    }
    Share.share(b.toString().trim());
  }

  void _goHome() {
    Navigator.pushNamedAndRemoveUntil(
      context,
      '/customer',
      (r) => false,
    );
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      child: Scaffold(
        backgroundColor: _cream,
        appBar: AppBar(
          backgroundColor: _cream,
          elevation: 0,
          automaticallyImplyLeading: false,
          title: Text(
            tr('Trip complete'),
            style: TextStyle(
              color: _ink,
              fontWeight: FontWeight.bold,
              fontSize: 18,
            ),
          ),
        ),
        body: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const SizedBox(height: 12),
                Center(
                  child: AppImage(
                    AppImages.shieldCheck,
                    size: 80,
                    fallbackIcon: Icons.flag_circle,
                  ),
                ),
                const SizedBox(height: 16),
                Text(
                  _isParcel ? tr('Parcel delivered!') : tr('You have arrived!'),
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                    color: _ink,
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  _isParcel
                      ? tr('Thanks for sending with ko!ngo.')
                      : tr('Thanks for riding with ko!ngo.'),
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 14, color: _inkMuted),
                ),
                const SizedBox(height: 32),

                Container(
                  padding: const EdgeInsets.all(18),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: _divider),
                  ),
                  child: Column(
                    children: [
                      _summaryRow(
                        tr('Total'),
                        CountryConfig.money(_paid ?? widget.finalFare),
                        bold: true,
                      ),
                      const SizedBox(height: 10),
                      _summaryRow(tr('Payment'), _payLine),
                      const SizedBox(height: 10),
                      _summaryRow(
                          tr('Distance'), _distanceText ?? widget.tripDistance),
                      if (widget.rideId != null) ...[
                        const SizedBox(height: 10),
                        _summaryRow(tr('Trip ID'),
                            '#${widget.rideId!.substring(0, 8)}'),
                      ],
                    ],
                  ),
                ),

                const SizedBox(height: 28),

                if (!_submitted) ...[
                  Text(
                    widget.driverName != null &&
                            widget.driverName!.isNotEmpty
                        ? tr('Rate {0}', [widget.driverName!])
                        : tr('Rate your driver'),
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.bold,
                      color: _ink,
                    ),
                  ),
                  const SizedBox(height: 12),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: List.generate(5, (i) {
                      final filled = i < _rating;
                      return IconButton(
                        iconSize: 40,
                        onPressed: _submitting
                            ? null
                            : () => setState(() => _rating = i + 1),
                        icon: Icon(
                          filled ? Icons.star : Icons.star_border,
                          color: _accent,
                        ),
                      );
                    }),
                  ),
                  if (_rating > 0) ...[
                    const SizedBox(height: 8),
                    TextField(
                      controller: _noteCtrl,
                      enabled: !_submitting,
                      maxLength: 140,
                      decoration: InputDecoration(
                        hintText: tr('Why this rating? (optional)'),
                        border: const OutlineInputBorder(),
                        isDense: true,
                      ),
                    ),
                  ],
                  const SizedBox(height: 12),
                  ElevatedButton(
                    onPressed: _submitting ? null : _submitRating,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: _accent,
                      foregroundColor: _accentInk,
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    child: _submitting
                        ? const SizedBox(
                            width: 18,
                            height: 18,
                            child: CircularProgressIndicator(
                              strokeWidth: 2,
                              color: _accentInk,
                            ),
                          )
                        : Text(
                            tr('Submit rating'),
                            style: TextStyle(
                              fontSize: 15,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                  ),
                  const SizedBox(height: 8),
                  TextButton(
                    onPressed: _submitting
                        ? null
                        : () => setState(() => _submitted = true),
                    child: Text(
                      tr('Skip'),
                      style: TextStyle(color: _inkMuted),
                    ),
                  ),
                ] else ...[
                  Text(
                    tr('Thanks — your rating was recorded.'),
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 14, color: _inkMuted),
                  ),
                ],

                const Spacer(),

                if (widget.rideId != null && widget.driverId != null) ...[
                  if (_tipped == null)
                    OutlinedButton.icon(
                      onPressed: _openTipSheet,
                      icon: const KIcon(Icons.card_giftcard, size: 22),
                      label: Text(tr('Tip your driver')),
                    ),
                ],
                TextButton.icon(
                  onPressed: _shareReceipt,
                  icon: const KIcon(Icons.share, size: 20),
                  label: Text(tr('Share receipt')),
                ),
                const SizedBox(height: 4),

                ElevatedButton(
                  onPressed: _goHome,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFFF2B705),
                    foregroundColor: const Color(0xFF0B1220),
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  child: Text(
                    tr('Back to home'),
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _summaryRow(String label, String value, {bool bold = false}) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          label,
          style: const TextStyle(fontSize: 14, color: _inkMuted),
        ),
        Text(
          value,
          style: TextStyle(
            fontSize: bold ? 18 : 13,
            fontWeight: bold ? FontWeight.bold : FontWeight.w500,
            color: _ink,
          ),
        ),
      ],
    );
  }
}
