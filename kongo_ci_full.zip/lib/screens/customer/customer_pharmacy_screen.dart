// lib/screens/customer/customer_pharmacy_screen.dart

import 'package:flutter/material.dart';
import 'package:efuride_app/config/efuride_palette.dart';
import 'package:efuride_app/l10n/app_strings.dart';
import 'package:efuride_app/services/storage_service.dart';
import 'package:efuride_app/providers/auth_provider.dart';
import 'package:efuride_app/utils/app_error.dart';
import 'package:efuride_app/utils/error_ui.dart';
import 'package:efuride_app/widgets/partner_landing_screen.dart';
import 'package:provider/provider.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:efuride_app/widgets/k_icon.dart';

class CustomerPharmacyScreen extends StatelessWidget {
  const CustomerPharmacyScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return PartnerLandingScreen(
      category:       'pharmacy',
      serviceType:    'Pharmacy',
      accent:         EfuridePalette.dropoff,
      headerIcon:     Icons.medical_services_rounded,
      headerKicker:   'Medicine delivered safely',
      headerTitle:    'Verified pharmacies',
      headerSubtitle: 'Cold-chain ready · pharmacist-verified',
      searchHint:     'Search pharmacies or medicine',
      topCard:        const _RxUploadCard(),
      headerImage:    'assets/images/pharmacy.png',
    );
  }
}

class _RxUploadCard extends StatefulWidget {
  const _RxUploadCard();

  @override
  State<_RxUploadCard> createState() => _RxUploadCardState();
}

class _RxUploadCardState extends State<_RxUploadCard> {
  String? _localPath;
  String? _uploadedUrl;
  bool _busy = false;

  Future<void> _pick({required bool camera}) async {
    if (_busy) return;
    final auth = context.read<AuthProvider>();
    final userId = auth.user?.id;
    if (userId == null) {
      _snack('Please sign in first', EfuridePalette.dropoff);
      return;
    }

    final file = await StorageService.instance.pickImage(fromCamera: camera);
    if (file == null) return;

    setState(() {
      _busy = true;
      _localPath = file.path;
    });

    try {
      final url = await StorageService.instance.uploadPrescription(
        userId: userId,
        file:   file,
      );
      if (!mounted) return;
      if (url == null) throw StateError('Upload failed');

      // Mirror to the customer's row so the admin/shopper can find it.
      await Supabase.instance.client
          .from('profiles')
          .update({'active_prescription_url': url})
          .eq('id', userId);

      setState(() => _uploadedUrl = url);
      _snack('Prescription uploaded', EfuridePalette.online);
    } catch (e) {
      if (!mounted) return;
      ErrorUI.showSnack(context, AppError.from(e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  void _snack(String msg, Color color) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg),
      backgroundColor: color,
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10)),
    ));
  }

  @override
  Widget build(BuildContext context) {
    final t = S.of(context);
    final uploaded = _uploadedUrl != null;

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            EfuridePalette.dropoff.withValues(alpha: 0.12),
            EfuridePalette.dropoff.withValues(alpha: 0.03),
          ],
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
            color: EfuridePalette.dropoff.withValues(alpha: 0.40),
            width: 1.5),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: EfuridePalette.dropoff,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: const Icon(Icons.description_outlined,
                    color: Colors.white, size: 20),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(tr('Have a prescription?'),
                        style: TextStyle(
                          fontSize: 15,
                          fontWeight: FontWeight.w900,
                          color: EfuridePalette.ink,
                        )),
                    const SizedBox(height: 2),
                    Text(
                      uploaded
                          ? 'Prescription attached — the pharmacist will verify it'
                          : 'Upload a photo — a pharmacist will verify it',
                      style: const TextStyle(
                        fontSize: 13,
                        color: EfuridePalette.inkMuted,
                        fontWeight: FontWeight.w600,
                        height: 1.35,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          if (uploaded)
            Row(
              children: [
                const Icon(Icons.check_circle,
                    color: EfuridePalette.online, size: 18),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(tr('Prescription on file'),
                      style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w700,
                        color: EfuridePalette.online,
                      )),
                ),
                TextButton(
                  onPressed: _busy
                      ? null
                      : () => setState(() {
                            _uploadedUrl = null;
                            _localPath = null;
                          }),
                  child: Text(tr('Replace')),
                ),
              ],
            )
          else
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: _busy ? null : () => _pick(camera: true),
                    icon: const KIcon(Icons.camera_alt_outlined, size: 16),
                    label: Text(tr('Camera'),
                        style: TextStyle(
                            fontSize: 14, fontWeight: FontWeight.w800)),
                    style: OutlinedButton.styleFrom(
                      minimumSize: const Size(0, 44),
                      foregroundColor: EfuridePalette.dropoff,
                      side: const BorderSide(color: EfuridePalette.dropoff),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10)),
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: _busy ? null : () => _pick(camera: false),
                    icon: const KIcon(Icons.photo_library_outlined, size: 16),
                    label: Text(tr('Gallery'),
                        style: TextStyle(
                            fontSize: 14, fontWeight: FontWeight.w800)),
                    style: OutlinedButton.styleFrom(
                      minimumSize: const Size(0, 44),
                      foregroundColor: EfuridePalette.dropoff,
                      side: const BorderSide(color: EfuridePalette.dropoff),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10)),
                    ),
                  ),
                ),
              ],
            ),
          if (_busy) ...[
            const SizedBox(height: 10),
            const LinearProgressIndicator(
                color: EfuridePalette.dropoff),
          ],
        ],
      ),
    );
  }
}
