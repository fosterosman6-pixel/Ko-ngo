// lib/screens/customer/hiring_hub_screen.dart
//
// Hiring Hub: find work, apply, and post jobs.
//   Find Work · My Applications · My Jobs   (+ "Post a Job" button)
// New jobs wait for admin approval before workers see them.

import 'dart:async';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:efuride_app/screens/customer/worker_profile_screen.dart';
import 'package:efuride_app/widgets/verified_badge.dart';
import 'package:geolocator/geolocator.dart';
import 'package:image_picker/image_picker.dart';
import 'package:url_launcher/url_launcher.dart';

import 'package:efuride_app/config/country_config.dart';
import 'package:efuride_app/config/efuride_palette.dart';
import 'package:efuride_app/l10n/app_strings.dart';
import 'package:efuride_app/services/hiring_service.dart';
import 'package:efuride_app/services/storage_service.dart';
import 'package:efuride_app/utils/address_formatter.dart';
import 'package:efuride_app/utils/app_error.dart';
import 'package:efuride_app/utils/error_ui.dart';
import 'package:efuride_app/utils/geo_search.dart';
import 'package:efuride_app/utils/money.dart';
import 'package:efuride_app/widgets/kongo_brand.dart';
import 'package:efuride_app/widgets/picture_tile.dart';
import 'package:efuride_app/widgets/k_icon.dart';

// ═════════════════════════════════════════════════════════════════
// Small helpers shared by the screens below
// ═════════════════════════════════════════════════════════════════
String _asset(String key) =>
    kJobCategoryAssets[key] ?? 'assets/images/job_hiring.png';
Color _tint(String key) => Color(kJobCategoryTint[key] ?? 0xFFEDEDED);

String _catName(List<JobCategory> cats, String key) {
  for (final c in cats) {
    if (c.key == key) return tr(c.name);
  }
  return tr('Other');
}

String _payText(Job j) {
  final amt = fmtMoney(j.amount);
  switch (j.payType) {
    case 'day':
      return '$amt/${tr('day')}';
    case 'fixed':
      return '$amt · ${tr('fixed price')}';
    default:
      return '$amt/${tr('hour')}';
  }
}

String _durationText(String d) {
  switch (d) {
    case 'week':
      return tr('This week');
    case 'ongoing':
      return tr('Ongoing');
    default:
      return tr('Today');
  }
}

String _ago(DateTime t) {
  final d = DateTime.now().difference(t);
  if (d.inMinutes < 2) return tr('Just now');
  if (d.inMinutes < 60) return tr('{0} min ago', [d.inMinutes]);
  if (d.inHours < 24) return tr('{0} h ago', [d.inHours]);
  return tr('{0} d ago', [d.inDays]);
}

void _snack(BuildContext c, String msg, {bool ok = true}) {
  ScaffoldMessenger.of(c).hideCurrentSnackBar();
  ScaffoldMessenger.of(c).showSnackBar(SnackBar(
    behavior: SnackBarBehavior.floating,
    backgroundColor: ok ? EfuridePalette.ink : EfuridePalette.danger,
    content: Text(msg),
  ));
}

void _fail(BuildContext c, Object e) {
  if (!c.mounted) return;
  ErrorUI.showSnack(c, AppError.from(e));
}

Widget _chip(String text, Color bg, Color fg) => Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration:
          BoxDecoration(color: bg, borderRadius: BorderRadius.circular(20)),
      child: Text(text,
          style: TextStyle(
              fontSize: 12, fontWeight: FontWeight.w800, color: fg)),
    );

Widget _statusChip(String status) {
  switch (status) {
    case 'open':
      return _chip(tr('Live'), const Color(0xFFDDF6E7), const Color(0xFF16803C));
    case 'pending':
      return _chip(tr('Waiting for approval'), const Color(0xFFFFF1CC),
          const Color(0xFF8A5A00));
    case 'filled':
      return _chip(tr('Filled'), const Color(0xFFE3F0FF), const Color(0xFF1565C0));
    case 'rejected':
      return _chip(tr('Not approved'), const Color(0xFFFFE0E0),
          const Color(0xFFB3261E));
    case 'shortlisted':
      return _chip(tr('Shortlisted'), const Color(0xFFEBE0FF),
          const Color(0xFF5B3CC4));
    case 'hired':
      return _chip(tr('Hired'), const Color(0xFFDDF6E7), const Color(0xFF16803C));
    case 'applied':
      return _chip(tr('Applied'), const Color(0xFFFFF1CC), const Color(0xFF8A5A00));
    case 'withdrawn':
      return _chip(tr('Withdrawn'), const Color(0xFFEDEDED), EfuridePalette.inkMuted);
    default:
      return _chip(tr('Closed'), const Color(0xFFEDEDED), EfuridePalette.inkMuted);
  }
}

// ═════════════════════════════════════════════════════════════════
// Job picture + card
// ═════════════════════════════════════════════════════════════════
class _JobPicture extends StatelessWidget {
  final Job job;
  final List<JobCategory> cats;
  final double size;
  const _JobPicture(this.job, this.cats, {this.size = 74});

  @override
  Widget build(BuildContext context) {
    String? catUrl;
    for (final c in cats) {
      if (c.key == job.categoryKey) catUrl = c.imageUrl;
    }
    final photo = job.photoUrl;
    return ClipRRect(
      borderRadius: BorderRadius.circular(16),
      child: Container(
        width: size,
        height: size,
        color: _tint(job.categoryKey),
        child: photo != null
            ? Image.network(photo,
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => Center(
                    child: PictureImage(
                        asset: _asset(job.categoryKey),
                        networkUrl: catUrl,
                        size: size * 0.72)))
            : Center(
                child: PictureImage(
                    asset: _asset(job.categoryKey),
                    networkUrl: catUrl,
                    size: size * 0.72)),
      ),
    );
  }
}

class _JobCard extends StatelessWidget {
  final Job job;
  final List<JobCategory> cats;
  final VoidCallback onTap;
  final Widget? trailing;
  final bool showStatus;
  const _JobCard({
    required this.job,
    required this.cats,
    required this.onTap,
    this.trailing,
    this.showStatus = false,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Material(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        elevation: 1.5,
        shadowColor: Colors.black.withValues(alpha: 0.10),
        child: InkWell(
          borderRadius: BorderRadius.circular(20),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _JobPicture(job, cats),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      if (job.isBoosted || showStatus)
                        Padding(
                          padding: const EdgeInsets.only(bottom: 4),
                          child: Wrap(spacing: 6, runSpacing: 4, children: [
                            if (job.isBoosted)
                              _chip(tr('URGENT'), EfuridePalette.accent,
                                  EfuridePalette.ink),
                            if (showStatus) _statusChip(job.status),
                          ]),
                        ),
                      Text(job.title,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                              fontSize: 17,
                              fontWeight: FontWeight.w900,
                              color: EfuridePalette.ink)),
                      const SizedBox(height: 3),
                      Text(_payText(job),
                          style: const TextStyle(
                              fontSize: 15,
                              fontWeight: FontWeight.w800,
                              color: Color(0xFF8A5A00))),
                      const SizedBox(height: 4),
                      Row(children: [
                        const KIcon(Icons.location_on_outlined,
                            size: 15, color: EfuridePalette.inkMuted),
                        const SizedBox(width: 3),
                        Expanded(
                          child: Text(
                              job.location.isEmpty
                                  ? _catName(cats, job.categoryKey)
                                  : job.location,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                  fontSize: 13,
                                  color: EfuridePalette.inkMuted)),
                        ),
                      ]),
                      const SizedBox(height: 2),
                      Text('${_durationText(job.duration)} · ${_ago(job.createdAt)}',
                          style: const TextStyle(
                              fontSize: 12.5, color: EfuridePalette.inkMuted)),
                    ],
                  ),
                ),
                if (trailing != null) ...[
                  const SizedBox(width: 8),
                  trailing!,
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }
}

Widget _applyButton(String label, VoidCallback? onTap) => SizedBox(
      height: 40,
      child: ElevatedButton(
        onPressed: onTap,
        style: ElevatedButton.styleFrom(
          backgroundColor: EfuridePalette.accent,
          foregroundColor: EfuridePalette.ink,
          elevation: 0,
          padding: const EdgeInsets.symmetric(horizontal: 16),
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        ),
        child: Text(label,
            style:
                const TextStyle(fontSize: 14, fontWeight: FontWeight.w900)),
      ),
    );

// ═════════════════════════════════════════════════════════════════
// HIRING HUB SCREEN
// ═════════════════════════════════════════════════════════════════
class HiringHubScreen extends StatefulWidget {
  final String? initialCategory;
  final String initialTab; // find | applied | mine
  const HiringHubScreen({super.key, this.initialCategory, this.initialTab = 'find'});

  @override
  State<HiringHubScreen> createState() => _HiringHubScreenState();
}

class _HiringHubScreenState extends State<HiringHubScreen>
    with SingleTickerProviderStateMixin {
  final _svc = HiringService.instance;
  late final TabController _tabs;
  final _searchCtl = TextEditingController();
  Timer? _debounce;

  List<JobCategory> _cats = [];
  String? _category;
  List<Job> _jobs = [];
  List<Map<String, dynamic>> _apps = [];
  List<Job> _mine = [];
  bool _loadingJobs = true, _loadingApps = true, _loadingMine = true;
  bool _errJobs = false;
  bool _hasProfile = false;

  Future<void> _loadProfile() async {
    final p = await _svc.myProfile();
    if (mounted) setState(() => _hasProfile = p.headline.trim().isNotEmpty);
  }

  Future<void> _openProfile() async {
    await Navigator.push(context,
        MaterialPageRoute(builder: (_) => const WorkerProfileScreen()));
    _loadProfile();
  }

  @override
  void initState() {
    super.initState();
    _category = widget.initialCategory;
    _loadProfile();
    final idx = widget.initialTab == 'applied'
        ? 1
        : widget.initialTab == 'mine'
            ? 2
            : 0;
    _tabs = TabController(length: 3, vsync: this, initialIndex: idx);
    _tabs.addListener(() {
      if (mounted) setState(() {});
    });
    _loadCats();
    _loadJobs();
    _loadApps();
    _loadMine();
  }

  @override
  void dispose() {
    _debounce?.cancel();
    _searchCtl.dispose();
    _tabs.dispose();
    super.dispose();
  }

  Future<void> _loadCats() async {
    final c = await _svc.categories();
    if (mounted) setState(() => _cats = c);
  }

  Future<void> _loadJobs() async {
    setState(() {
      _loadingJobs = true;
      _errJobs = false;
    });
    try {
      final j = await _svc.openJobs(
          category: _category, query: _searchCtl.text);
      if (mounted) setState(() => _jobs = j);
    } catch (_) {
      if (mounted) setState(() => _errJobs = true);
    } finally {
      if (mounted) setState(() => _loadingJobs = false);
    }
  }

  Future<void> _loadApps() async {
    try {
      final a = await _svc.myApplications();
      if (mounted) setState(() => _apps = a);
    } catch (_) {
    } finally {
      if (mounted) setState(() => _loadingApps = false);
    }
  }

  Future<void> _loadMine() async {
    try {
      final m = await _svc.myJobs();
      if (mounted) setState(() => _mine = m);
    } catch (_) {
    } finally {
      if (mounted) setState(() => _loadingMine = false);
    }
  }

  void _onSearch(String _) {
    _debounce?.cancel();
    _debounce = Timer(const Duration(milliseconds: 400), _loadJobs);
  }

  Future<void> _postJob() async {
    final posted = await Navigator.push<bool>(
        context, MaterialPageRoute(builder: (_) => PostJobScreen(cats: _cats)));
    if (posted == true) {
      await _loadMine();
      if (mounted) _tabs.animateTo(2);
    }
  }

  void _openJob(Job j) async {
    await showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => _JobDetailSheet(job: j, cats: _cats),
    );
    _loadJobs();
    _loadApps();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: EfuridePalette.cream,
      body: SafeArea(
        bottom: false,
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(4, 6, 12, 0),
              child: Row(children: [
                IconButton(
                    icon: const Icon(Icons.arrow_back_ios_new_rounded),
                    onPressed: () => Navigator.maybePop(context)),
                Expanded(
                  child: Text(tr('Hiring Hub'),
                      style: const TextStyle(
                          fontSize: 22, fontWeight: FontWeight.w900)),
                ),
                IconButton(
                  tooltip: tr('My worker profile'),
                  icon: const Icon(Icons.badge_outlined,
                      color: EfuridePalette.ink),
                  onPressed: _openProfile,
                ),
                const KongoBrand(size: 34),
              ]),
            ),
            TabBar(
              controller: _tabs,
              labelColor: EfuridePalette.ink,
              unselectedLabelColor: EfuridePalette.inkMuted,
              indicatorColor: EfuridePalette.ink,
              indicatorWeight: 3,
              labelStyle:
                  const TextStyle(fontWeight: FontWeight.w900, fontSize: 14.5),
              tabs: [
                Tab(text: tr('Find Work')),
                Tab(text: tr('My Applications')),
                Tab(text: tr('My Jobs')),
              ],
            ),
            Expanded(
              child: TabBarView(
                controller: _tabs,
                children: [_findTab(), _appsTab(), _mineTab()],
              ),
            ),
          ],
        ),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
      // The big "Post a Job" button belongs to employers, so it only shows
      // on the My Jobs tab. Job seekers get their own card on Find Work.
      floatingActionButton: _tabs.index != 2
          ? null
          : SizedBox(
              width: MediaQuery.of(context).size.width - 32,
              height: 56,
              child: FloatingActionButton.extended(
                onPressed: _postJob,
                backgroundColor: EfuridePalette.accent,
                foregroundColor: EfuridePalette.ink,
                elevation: 4,
                icon: const Icon(Icons.add_rounded, size: 28),
                label: Text(tr('Post a Job'),
                    style: const TextStyle(
                        fontSize: 18, fontWeight: FontWeight.w900)),
              ),
            ),
    );
  }

  // ── Find work ──────────────────────────────────────────────────
  Widget _findTab() {
    return RefreshIndicator(
      onRefresh: _loadJobs,
      child: ListView(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 100),
        children: [
          // Job seeker card
          Container(
            padding: const EdgeInsets.all(14),
            margin: const EdgeInsets.only(bottom: 12),
            decoration: BoxDecoration(
              color: const Color(0xFFFFF1CC),
              borderRadius: BorderRadius.circular(18),
            ),
            child: Row(children: [
              const Icon(Icons.badge_outlined,
                  size: 34, color: EfuridePalette.ink),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                        _hasProfile
                            ? tr('Your worker profile is ready')
                            : tr('Looking for work?'),
                        style: const TextStyle(
                            fontSize: 16.5, fontWeight: FontWeight.w900)),
                    const SizedBox(height: 2),
                    Text(
                        _hasProfile
                            ? tr('Tap Apply on any job below.')
                            : tr('Set up your worker profile so employers can see what you do. Then tap Apply on any job.'),
                        style: const TextStyle(
                            fontSize: 13.5, color: EfuridePalette.inkMuted)),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              _applyButton(
                  _hasProfile ? tr('Edit') : tr('Set up my profile'),
                  _openProfile),
            ]),
          ),
          Align(
            alignment: Alignment.centerLeft,
            child: TextButton.icon(
              onPressed: _postJob,
              icon: const Icon(Icons.add_circle_outline,
                  color: EfuridePalette.ink),
              label: Text(tr('Need to hire someone? Post a job'),
                  style: const TextStyle(
                      fontWeight: FontWeight.w800,
                      color: EfuridePalette.ink)),
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 14),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: EfuridePalette.divider),
            ),
            child: Row(children: [
              const Icon(Icons.search, color: EfuridePalette.ink),
              const SizedBox(width: 10),
              Expanded(
                child: TextField(
                  controller: _searchCtl,
                  onChanged: _onSearch,
                  decoration: InputDecoration(
                    hintText: tr('Search jobs, skills...'),
                    border: InputBorder.none,
                    hintStyle: const TextStyle(color: EfuridePalette.inkMuted),
                  ),
                  style: const TextStyle(fontSize: 16),
                ),
              ),
            ]),
          ),
          const SizedBox(height: 14),
          SizedBox(
            height: 112,
            child: ListView(
              scrollDirection: Axis.horizontal,
              children: [
                SizedBox(
                  width: 92,
                  child: Padding(
                    padding: const EdgeInsets.only(right: 10),
                    child: PictureTile(
                      label: tr('All'),
                      asset: 'assets/images/briefcase.png',
                      tint: const Color(0xFFFFF1CC),
                      imageSize: 46,
                      selected: _category == null,
                      onTap: () {
                        setState(() => _category = null);
                        _loadJobs();
                      },
                    ),
                  ),
                ),
                for (final c in _cats)
                  SizedBox(
                    width: 100,
                    child: Padding(
                      padding: const EdgeInsets.only(right: 10),
                      child: PictureTile(
                        label: tr(c.name),
                        asset: _asset(c.key),
                        networkUrl: c.imageUrl,
                        tint: _tint(c.key),
                        imageSize: 46,
                        selected: _category == c.key,
                        onTap: () {
                          setState(() => _category = c.key);
                          _loadJobs();
                        },
                      ),
                    ),
                  ),
              ],
            ),
          ),
          const SizedBox(height: 14),
          if (_loadingJobs)
            const Padding(
              padding: EdgeInsets.all(40),
              child: Center(child: CircularProgressIndicator()),
            )
          else if (_errJobs)
            _empty(Icons.wifi_off_rounded, tr('Could not load jobs. Pull down to try again.'))
          else if (_jobs.isEmpty)
            _empty('assets/images/job_hiring.png',
                tr('No jobs here yet. Check back soon.'))
          else
            for (final j in _jobs)
              _JobCard(
                job: j,
                cats: _cats,
                onTap: () => _openJob(j),
                trailing: j.myApplication != null &&
                        j.myApplication != 'withdrawn'
                    ? _statusChip(j.myApplication!)
                    : _applyButton(tr('Apply'), () => _openJob(j)),
              ),
        ],
      ),
    );
  }

  Widget _empty(Object pic, String text) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 36, horizontal: 20),
        child: Column(children: [
          if (pic is String)
            Image.asset(pic, width: 110, height: 110)
          else
            Icon(pic as IconData, size: 56, color: EfuridePalette.inkMuted),
          const SizedBox(height: 12),
          Text(text,
              textAlign: TextAlign.center,
              style: const TextStyle(
                  fontSize: 15.5, color: EfuridePalette.inkMuted)),
        ]),
      );

  // ── My applications ────────────────────────────────────────────
  Widget _appsTab() {
    if (_loadingApps) return const Center(child: CircularProgressIndicator());
    return RefreshIndicator(
      onRefresh: _loadApps,
      child: ListView(
        padding: const EdgeInsets.fromLTRB(16, 14, 16, 100),
        children: [
          if (_apps.isEmpty)
            _empty('assets/images/job_office.png',
                tr('You have not applied for any job yet.')),
          for (final a in _apps)
            Builder(builder: (_) {
              final job =
                  Job.fromMap(Map<String, dynamic>.from(a['jobs'] as Map));
              final st = a['status'].toString();
              final card = _JobCard(
                job: job,
                cats: _cats,
                onTap: () => _openJob(Job.fromMap(
                    Map<String, dynamic>.from(a['jobs'] as Map),
                    mine: st)),
                trailing: _statusChip(st),
              );
              if (st != 'hired') return card;
              return Column(children: [
                card,
                Align(
                  alignment: Alignment.centerRight,
                  child: TextButton.icon(
                    onPressed: () async {
                      final done = await showRateSheet(context,
                          jobId: job.id,
                          rateeId: job.employerId,
                          title: tr('Rate the employer'));
                      if (done && mounted) {
                        ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(content: Text(tr('Thank you for your rating'))));
                      }
                    },
                    icon: const Icon(Icons.star_rounded,
                        color: EfuridePalette.accent),
                    label: Text(tr('Rate the employer'),
                        style: const TextStyle(
                            fontWeight: FontWeight.w800,
                            color: EfuridePalette.ink)),
                  ),
                ),
              ]);
            }),
        ],
      ),
    );
  }

  // ── My jobs ────────────────────────────────────────────────────
  Widget _mineTab() {
    if (_loadingMine) return const Center(child: CircularProgressIndicator());
    return RefreshIndicator(
      onRefresh: _loadMine,
      child: ListView(
        padding: const EdgeInsets.fromLTRB(16, 14, 16, 100),
        children: [
          if (_mine.isEmpty)
            _empty('assets/images/job_hiring.png',
                tr('Jobs you post will show here.')),
          for (final j in _mine)
            _JobCard(
              job: j,
              cats: _cats,
              showStatus: true,
              onTap: () async {
                await Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (_) => _ApplicantsScreen(job: j, cats: _cats)));
                _loadMine();
              },
              trailing: j.status == 'open' || j.status == 'filled'
                  ? Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text('${j.applicantCount}',
                            style: const TextStyle(
                                fontSize: 22, fontWeight: FontWeight.w900)),
                        Text(tr('applicants'),
                            style: const TextStyle(
                                fontSize: 11, color: EfuridePalette.inkMuted)),
                      ],
                    )
                  : null,
            ),
        ],
      ),
    );
  }
}

// ═════════════════════════════════════════════════════════════════
// JOB DETAIL + APPLY
// ═════════════════════════════════════════════════════════════════
class _JobDetailSheet extends StatefulWidget {
  final Job job;
  final List<JobCategory> cats;
  const _JobDetailSheet({required this.job, required this.cats});

  @override
  State<_JobDetailSheet> createState() => _JobDetailSheetState();
}

class _JobDetailSheetState extends State<_JobDetailSheet> {
  final _msg = TextEditingController();
  String _employer = '';
  bool _employerVerified = false;
  double _employerAvg = 0;
  int _employerCount = 0;
  String? _myStatus;
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    _myStatus = widget.job.myApplication;
    HiringService.instance.employerName(widget.job.id).then((n) {
      if (mounted) setState(() => _employer = n);
    });
    HiringService.instance.employerVerified(widget.job.id).then((v) {
      if (mounted) setState(() => _employerVerified = v);
    });
    HiringService.instance.employerRating(widget.job.id).then((r) {
      if (mounted) {
        setState(() {
          _employerAvg = r.$1;
          _employerCount = r.$2;
        });
      }
    });
  }

  @override
  void dispose() {
    _msg.dispose();
    super.dispose();
  }

  Future<void> _apply() async {
    setState(() => _busy = true);
    try {
      await HiringService.instance.apply(widget.job.id, _msg.text);
      if (!mounted) return;
      setState(() => _myStatus = 'applied');
      _snack(context, tr('Application sent. You will be notified.'));
    } catch (e) {
      _fail(context, e);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _withdraw() async {
    setState(() => _busy = true);
    try {
      await HiringService.instance.withdraw(widget.job.id);
      if (!mounted) return;
      setState(() => _myStatus = 'withdrawn');
    } catch (e) {
      _fail(context, e);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final j = widget.job;
    final reqs = <String>[
      if (j.reqVerifiedId) tr('Verified ID'),
      if (j.reqExperience) tr('Experience'),
      if (j.reqOwnTools) tr('Own tools'),
      if (j.reqOwnTransport) tr('Own transport'),
    ];
    final applied = _myStatus != null && _myStatus != 'withdrawn';
    return Padding(
      padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
      child: Container(
        constraints:
            BoxConstraints(maxHeight: MediaQuery.of(context).size.height * 0.9),
        decoration: const BoxDecoration(
          color: EfuridePalette.cream,
          borderRadius: BorderRadius.vertical(top: Radius.circular(26)),
        ),
        child: SafeArea(
          top: false,
          child: ListView(
            shrinkWrap: true,
            padding: const EdgeInsets.fromLTRB(18, 10, 18, 20),
            children: [
              Center(
                child: Container(
                    width: 44,
                    height: 5,
                    margin: const EdgeInsets.only(bottom: 14),
                    decoration: BoxDecoration(
                        color: EfuridePalette.divider,
                        borderRadius: BorderRadius.circular(3))),
              ),
              ClipRRect(
                borderRadius: BorderRadius.circular(20),
                child: Container(
                  height: 170,
                  color: _tint(j.categoryKey),
                  child: j.photoUrl != null
                      ? Image.network(j.photoUrl!,
                          width: double.infinity,
                          fit: BoxFit.cover,
                          errorBuilder: (_, __, ___) => Center(
                              child: Image.asset(_asset(j.categoryKey),
                                  height: 120)))
                      : Center(
                          child: Image.asset(_asset(j.categoryKey), height: 120)),
                ),
              ),
              const SizedBox(height: 14),
              Wrap(spacing: 6, children: [
                if (j.isBoosted)
                  _chip(tr('URGENT'), EfuridePalette.accent, EfuridePalette.ink),
                _chip(_catName(widget.cats, j.categoryKey),
                    _tint(j.categoryKey), EfuridePalette.ink),
              ]),
              const SizedBox(height: 8),
              Text(j.title,
                  style: const TextStyle(
                      fontSize: 24, fontWeight: FontWeight.w900, height: 1.15)),
              const SizedBox(height: 6),
              Text(_payText(j),
                  style: const TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.w900,
                      color: Color(0xFF8A5A00))),
              const SizedBox(height: 10),
              _line(Icons.person_outline,
                  '${tr('Employer')}: ${_employer.isEmpty ? '…' : _employer}'),
              if (_employerCount > 0)
                Padding(
                  padding: const EdgeInsets.only(left: 26, bottom: 4),
                  child: Row(children: [
                    const Icon(Icons.star_rounded,
                        size: 17, color: EfuridePalette.accent),
                    const SizedBox(width: 3),
                    Text('${_employerAvg.toStringAsFixed(1)} ($_employerCount)',
                        style: const TextStyle(
                            fontSize: 13.5, fontWeight: FontWeight.w800)),
                  ]),
                ),
              if (_employerVerified)
                const Padding(
                  padding: EdgeInsets.only(left: 26, bottom: 4),
                  child: Align(
                      alignment: Alignment.centerLeft,
                      child: VerifiedBadge(label: true)),
                ),
              if (j.location.isNotEmpty)
                _line(Icons.location_on_outlined, j.location),
              _line(Icons.schedule,
                  '${_durationText(j.duration)} · ${_ago(j.createdAt)}'),
              if (j.workersNeeded > 1)
                _line(Icons.groups_outlined,
                    tr('{0} workers needed', [j.workersNeeded])),
              if (j.description.isNotEmpty) ...[
                const SizedBox(height: 12),
                Text(tr('Description'),
                    style: const TextStyle(
                        fontSize: 16, fontWeight: FontWeight.w900)),
                const SizedBox(height: 4),
                Text(j.description,
                    style: const TextStyle(fontSize: 15.5, height: 1.4)),
              ],
              if (reqs.isNotEmpty) ...[
                const SizedBox(height: 12),
                Text(tr('Requirements'),
                    style: const TextStyle(
                        fontSize: 16, fontWeight: FontWeight.w900)),
                const SizedBox(height: 6),
                Wrap(spacing: 8, runSpacing: 6, children: [
                  for (final r in reqs)
                    _chip('✓ $r', const Color(0xFFDDF6E7), const Color(0xFF16803C)),
                ]),
              ],
              const SizedBox(height: 16),
              if (applied) ...[
                Row(children: [
                  Text('${tr('Your application')}: ',
                      style: const TextStyle(fontSize: 15)),
                  _statusChip(_myStatus!),
                ]),
                if (_myStatus == 'applied') ...[
                  const SizedBox(height: 8),
                  TextButton(
                      onPressed: _busy ? null : _withdraw,
                      child: Text(tr('Withdraw application'))),
                ],
              ] else ...[
                TextField(
                  controller: _msg,
                  maxLines: 3,
                  maxLength: 300,
                  decoration: InputDecoration(
                    hintText: tr('Say a few words about yourself (optional)'),
                    filled: true,
                    fillColor: Colors.white,
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(14),
                        borderSide: BorderSide.none),
                  ),
                ),
                const SizedBox(height: 8),
                SizedBox(
                  height: 54,
                  child: ElevatedButton(
                    onPressed: _busy ? null : _apply,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: EfuridePalette.accent,
                      foregroundColor: EfuridePalette.ink,
                      elevation: 0,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(16)),
                    ),
                    child: _busy
                        ? const SizedBox(
                            width: 22,
                            height: 22,
                            child: CircularProgressIndicator(strokeWidth: 2.5))
                        : Text(tr('Apply'),
                            style: const TextStyle(
                                fontSize: 18, fontWeight: FontWeight.w900)),
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }

  Widget _line(IconData icon, String text) => Padding(
        padding: const EdgeInsets.only(top: 4),
        child: Row(children: [
          Icon(icon, size: 18, color: EfuridePalette.inkMuted),
          const SizedBox(width: 8),
          Expanded(
              child: Text(text,
                  style: const TextStyle(
                      fontSize: 15, color: EfuridePalette.inkMuted))),
        ]),
      );
}

// ═════════════════════════════════════════════════════════════════
// APPLICANTS (employer)
// ═════════════════════════════════════════════════════════════════
class _ApplicantsScreen extends StatefulWidget {
  final Job job;
  final List<JobCategory> cats;
  const _ApplicantsScreen({required this.job, required this.cats});

  @override
  State<_ApplicantsScreen> createState() => _ApplicantsScreenState();
}

class _ApplicantsScreenState extends State<_ApplicantsScreen> {
  final _svc = HiringService.instance;
  List<JobApplicant> _list = [];
  bool _loading = true;
  late String _status;

  @override
  void initState() {
    super.initState();
    _status = widget.job.status;
    _load();
  }

  Future<void> _load() async {
    try {
      final l = await _svc.applicants(widget.job.id);
      if (mounted) setState(() => _list = l);
    } catch (e) {
      _fail(context, e);
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _set(JobApplicant a, String status) async {
    try {
      await _svc.setApplicantStatus(a.id, status);
      await _load();
    } catch (e) {
      _fail(context, e);
    }
  }

  Future<void> _close() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: Text(tr('Close this job?')),
        content: Text(tr('Workers will no longer see it.')),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: Text(tr('Cancel'))),
          TextButton(
              onPressed: () => Navigator.pop(context, true),
              child: Text(tr('Close job'))),
        ],
      ),
    );
    if (ok != true) return;
    try {
      await _svc.closeJob(widget.job.id);
      if (mounted) setState(() => _status = 'closed');
    } catch (e) {
      _fail(context, e);
    }
  }

  Future<void> _call(String phone) async {
    if (phone.isEmpty) return;
    await launchUrl(Uri(scheme: 'tel', path: phone));
  }

  @override
  Widget build(BuildContext context) {
    final j = widget.job;
    return Scaffold(
      backgroundColor: EfuridePalette.cream,
      appBar: AppBar(
        backgroundColor: EfuridePalette.cream,
        foregroundColor: EfuridePalette.ink,
        elevation: 0,
        title: Text(j.title,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(fontWeight: FontWeight.w900)),
        actions: [
          if (_status == 'open')
            TextButton(onPressed: _close, child: Text(tr('Close job'))),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 4, 16, 30),
        children: [
          Row(children: [
            _statusChip(_status),
            const SizedBox(width: 8),
            Text(_payText(j),
                style: const TextStyle(fontWeight: FontWeight.w800)),
          ]),
          if (_status == 'rejected' && (j.rejectReason ?? '').isNotEmpty)
            Padding(
              padding: const EdgeInsets.only(top: 8),
              child: Text(j.rejectReason!,
                  style: const TextStyle(color: Color(0xFFB3261E))),
            ),
          if (_status == 'pending')
            Padding(
              padding: const EdgeInsets.only(top: 8),
              child: Text(
                  tr('We are checking your job. It will go live as soon as it is approved.'),
                  style: const TextStyle(color: EfuridePalette.inkMuted)),
            ),
          const SizedBox(height: 14),
          Text(tr('Applicants'),
              style:
                  const TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
          const SizedBox(height: 8),
          if (_loading)
            const Padding(
                padding: EdgeInsets.all(30),
                child: Center(child: CircularProgressIndicator()))
          else if (_list.isEmpty)
            Padding(
              padding: const EdgeInsets.all(24),
              child: Text(tr('No applicants yet.'),
                  textAlign: TextAlign.center,
                  style: const TextStyle(color: EfuridePalette.inkMuted)),
            ),
          for (final a in _list)
            Container(
              margin: const EdgeInsets.only(bottom: 10),
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                  color: Colors.white, borderRadius: BorderRadius.circular(18)),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(children: [
                    CircleAvatar(
                      radius: 24,
                      backgroundColor: const Color(0xFFFFF1CC),
                      backgroundImage:
                          a.avatarUrl != null ? NetworkImage(a.avatarUrl!) : null,
                      child: a.avatarUrl == null
                          ? const KIcon(Icons.person, color: EfuridePalette.ink)
                          : null,
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(children: [
                            Flexible(
                              child: Text(a.name,
                                  style: const TextStyle(
                                      fontSize: 16.5,
                                      fontWeight: FontWeight.w900)),
                            ),
                            if (a.verified) ...[
                              const SizedBox(width: 5),
                              const VerifiedBadge(),
                            ],
                          ]),
                          Text(_ago(a.createdAt),
                              style: const TextStyle(
                                  fontSize: 12.5,
                                  color: EfuridePalette.inkMuted)),
                        ],
                      ),
                    ),
                    _statusChip(a.status),
                    if (a.phone.isNotEmpty)
                      IconButton(
                        icon: const Icon(Icons.call_rounded,
                            color: Color(0xFF16803C)),
                        onPressed: () => _call(a.phone),
                      ),
                  ]),
                  if (a.headline.isNotEmpty) ...[
                    const SizedBox(height: 8),
                    Text(
                        [
                          a.headline,
                          if (a.experienceYears > 0)
                            '${a.experienceYears} ${tr('years experience')}',
                        ].join(' · '),
                        style: const TextStyle(
                            fontSize: 15, fontWeight: FontWeight.w800)),
                    if (a.skills.isNotEmpty)
                      Text(a.skills,
                          style: const TextStyle(
                              fontSize: 14, color: EfuridePalette.inkMuted)),
                    if (a.about.isNotEmpty)
                      Padding(
                        padding: const EdgeInsets.only(top: 4),
                        child:
                            Text(a.about, style: const TextStyle(fontSize: 14)),
                      ),
                  ],
                  if (a.ratingCount > 0)
                    Padding(
                      padding: const EdgeInsets.only(top: 6),
                      child: Row(children: [
                        const Icon(Icons.star_rounded,
                            size: 18, color: EfuridePalette.accent),
                        const SizedBox(width: 3),
                        Text('${a.ratingAvg.toStringAsFixed(1)} (${a.ratingCount})',
                            style: const TextStyle(
                                fontSize: 14, fontWeight: FontWeight.w800)),
                      ]),
                    ),
                  if (a.message.isNotEmpty) ...[
                    const SizedBox(height: 8),
                    Text(a.message, style: const TextStyle(fontSize: 15)),
                  ],
                  if (a.status == 'hired')
                    Align(
                      alignment: Alignment.centerLeft,
                      child: TextButton.icon(
                        onPressed: () async {
                          final done = await showRateSheet(context,
                              jobId: widget.job.id,
                              rateeId: a.workerId,
                              title: tr('Rate {0}', [a.name]),
                              initial: a.myStars);
                          if (done) _load();
                        },
                        icon: const Icon(Icons.star_rounded,
                            color: EfuridePalette.accent),
                        label: Text(
                            a.myStars == null
                                ? tr('Rate this worker')
                                : tr('You rated {0} stars', ['${a.myStars}']),
                            style: const TextStyle(
                                fontWeight: FontWeight.w800,
                                color: EfuridePalette.ink)),
                      ),
                    ),
                  const SizedBox(height: 10),
                  Row(children: [
                    if (a.status != 'shortlisted' && a.status != 'hired')
                      Expanded(
                          child: OutlinedButton(
                              onPressed: () => _set(a, 'shortlisted'),
                              child: Text(tr('Shortlist')))),
                    if (a.status != 'shortlisted' && a.status != 'hired')
                      const SizedBox(width: 8),
                    if (a.status != 'hired')
                      Expanded(
                          child: ElevatedButton(
                              onPressed: () => _set(a, 'hired'),
                              style: ElevatedButton.styleFrom(
                                  backgroundColor: EfuridePalette.accent,
                                  foregroundColor: EfuridePalette.ink,
                                  elevation: 0),
                              child: Text(tr('Hire')))),
                    if (a.status != 'rejected' && a.status != 'hired') ...[
                      const SizedBox(width: 8),
                      Expanded(
                          child: TextButton(
                              onPressed: () => _set(a, 'rejected'),
                              child: Text(tr('Decline'),
                                  style: const TextStyle(
                                      color: Color(0xFFB3261E))))),
                    ],
                  ]),
                ],
              ),
            ),
        ],
      ),
    );
  }
}

// ═════════════════════════════════════════════════════════════════
// POST A JOB
// ═════════════════════════════════════════════════════════════════
class PostJobScreen extends StatefulWidget {
  final List<JobCategory> cats;
  const PostJobScreen({super.key, required this.cats});

  @override
  State<PostJobScreen> createState() => _PostJobScreenState();
}

class _PostJobScreenState extends State<PostJobScreen> {
  final _title = TextEditingController();
  final _desc = TextEditingController();
  final _amount = TextEditingController();
  final _loc = TextEditingController();
  List<JobCategory> _cats = [];
  String _cat = 'cleaning';
  String _pay = 'hour';
  String _duration = 'today';
  int _workers = 1;
  bool _verified = false, _exp = false, _tools = false, _transport = false;
  bool _urgent = false;
  XFile? _photo;
  double? _lat, _lng;
  bool _busy = false, _locating = false;
  JobFees _fees = const JobFees();

  @override
  void initState() {
    super.initState();
    _cats = widget.cats;
    if (_cats.isEmpty) {
      HiringService.instance.categories().then((c) {
        if (mounted) setState(() => _cats = c);
      });
    }
    if (_cats.isNotEmpty && !_cats.any((c) => c.key == _cat)) {
      _cat = _cats.first.key;
    }
    HiringService.instance.fees().then((f) {
      if (mounted) setState(() => _fees = f);
    });
  }

  @override
  void dispose() {
    _title.dispose();
    _desc.dispose();
    _amount.dispose();
    _loc.dispose();
    super.dispose();
  }

  Future<void> _useMyLocation() async {
    setState(() => _locating = true);
    try {
      var perm = await Geolocator.checkPermission();
      if (perm == LocationPermission.denied) {
        perm = await Geolocator.requestPermission();
      }
      if (perm == LocationPermission.denied ||
          perm == LocationPermission.deniedForever) {
        if (mounted) {
          _snack(context, tr('Allow location to use this.'), ok: false);
        }
        return;
      }
      final p = await Geolocator.getCurrentPosition(
          desiredAccuracy: LocationAccuracy.medium);
      _lat = p.latitude;
      _lng = p.longitude;
      final r = await GeoSearch.reverse(p.latitude, p.longitude);
      if (r != null && mounted) {
        _loc.text = AddressFormatter.short(r);
      }
    } catch (_) {
      if (mounted) {
        _snack(context, tr('Could not find your location.'), ok: false);
      }
    } finally {
      if (mounted) setState(() => _locating = false);
    }
  }

  Future<void> _pickPhoto() async {
    final f = await StorageService.instance.pickImage();
    if (f != null && mounted) setState(() => _photo = f);
  }

  String? _check() {
    if (_title.text.trim().length < 3) return tr('Please enter a job title.');
    final a = double.tryParse(_amount.text.trim().replaceAll(',', '.'));
    if (a == null || a <= 0) return tr('Please enter the pay amount.');
    if (_loc.text.trim().isEmpty) return tr('Please enter where the job is.');
    final need = _fees.total(_urgent);
    if (need > _fees.balance) {
      return tr('Your wallet needs {0} to post this job. Top up and try again.',
          [fmtMoney(need)]);
    }
    return null;
  }

  Future<void> _preview() async {
    final err = _check();
    if (err != null) {
      _snack(context, err, ok: false);
      return;
    }
    final j = _draft();
    await showModalBottomSheet(
      context: context,
      backgroundColor: EfuridePalette.cream,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(26))),
      builder: (_) => Padding(
        padding: const EdgeInsets.all(18),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Text(tr('This is how workers will see your job'),
              style:
                  const TextStyle(fontSize: 16, fontWeight: FontWeight.w900)),
          const SizedBox(height: 12),
          _JobCard(job: j, cats: _cats, onTap: () {}),
        ]),
      ),
    );
  }

  Job _draft() => Job(
        id: 'draft',
        employerId: '',
        title: _title.text.trim(),
        categoryKey: _cat,
        description: _desc.text.trim(),
        payType: _pay,
        amount: double.tryParse(_amount.text.trim().replaceAll(',', '.')) ?? 0,
        duration: _duration,
        location: _loc.text.trim(),
        lat: _lat,
        lng: _lng,
        workersNeeded: _workers,
        reqVerifiedId: _verified,
        reqExperience: _exp,
        reqOwnTools: _tools,
        reqOwnTransport: _transport,
        photoUrl: null,
        urgent: _urgent,
        status: 'pending',
        rejectReason: null,
        createdAt: DateTime.now(),
      );

  Future<void> _submit() async {
    final err = _check();
    if (err != null) {
      _snack(context, err, ok: false);
      return;
    }
    setState(() => _busy = true);
    try {
      String? photoUrl;
      final p = _photo;
      if (p != null) {
        photoUrl = await StorageService.instance.uploadJobPhoto(p);
        if (photoUrl == null) {
          if (mounted) {
            _snack(context, tr('The photo could not be uploaded. Try again or post without it.'),
                ok: false);
          }
          return;
        }
      }
      await HiringService.instance.postJob({
        'title': _title.text.trim(),
        'category_key': _cat,
        'description': _desc.text.trim(),
        'pay_type': _pay,
        'amount': double.parse(_amount.text.trim().replaceAll(',', '.')),
        'duration': _duration,
        'location_text': _loc.text.trim(),
        'lat': _lat,
        'lng': _lng,
        'workers_needed': _workers,
        'req_verified_id': _verified,
        'req_experience': _exp,
        'req_own_tools': _tools,
        'req_own_transport': _transport,
        'urgent': _urgent,
        'photo_url': photoUrl,
      });
      if (!mounted) return;
      await showDialog(
        context: context,
        builder: (_) => AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)),
          content: Column(mainAxisSize: MainAxisSize.min, children: [
            Image.asset('assets/images/job_office.png', height: 90),
            const SizedBox(height: 10),
            Text(tr('Job sent for approval'),
                style:
                    const TextStyle(fontSize: 19, fontWeight: FontWeight.w900)),
            const SizedBox(height: 6),
            Text(
                tr('We will check it and let you know as soon as it is live.'),
                textAlign: TextAlign.center),
          ]),
          actions: [
            TextButton(
                onPressed: () => Navigator.pop(context),
                child: Text(tr('OK'))),
          ],
        ),
      );
      if (mounted) Navigator.pop(context, true);
    } catch (e) {
      _fail(context, e);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  // ── UI ─────────────────────────────────────────────────────────
  Widget _label(String t) => Padding(
        padding: const EdgeInsets.only(top: 18, bottom: 8),
        child: Text(t,
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
      );

  InputDecoration _dec(String hint, {Widget? suffix, Widget? prefix}) =>
      InputDecoration(
        hintText: hint,
        suffixIcon: suffix,
        prefixIcon: prefix,
        filled: true,
        fillColor: const Color(0xFFEFEAE0),
        contentPadding:
            const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
        border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
      );

  Widget _seg(List<MapEntry<String, String>> items, String value,
      ValueChanged<String> on) {
    return Row(children: [
      for (var i = 0; i < items.length; i++) ...[
        if (i > 0) const SizedBox(width: 8),
        Expanded(
          child: GestureDetector(
            onTap: () => on(items[i].key),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 150),
              padding: const EdgeInsets.symmetric(vertical: 13),
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: value == items[i].key
                    ? EfuridePalette.accent
                    : const Color(0xFFEFEAE0),
                borderRadius: BorderRadius.circular(14),
              ),
              child: Text(items[i].value,
                  style: TextStyle(
                      fontSize: 15,
                      fontWeight: value == items[i].key
                          ? FontWeight.w900
                          : FontWeight.w600)),
            ),
          ),
        ),
      ],
    ]);
  }

  Widget _req(String text, IconData icon, bool v, ValueChanged<bool> on) =>
      CheckboxListTile(
        value: v,
        onChanged: (x) => on(x ?? false),
        contentPadding: EdgeInsets.zero,
        dense: true,
        activeColor: EfuridePalette.accent,
        checkColor: EfuridePalette.ink,
        controlAffinity: ListTileControlAffinity.leading,
        title: Row(children: [
          Text(text, style: const TextStyle(fontSize: 16)),
          const SizedBox(width: 8),
          Icon(icon, size: 19, color: EfuridePalette.inkMuted),
        ]),
      );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: EfuridePalette.cream,
      body: Column(
        children: [
          // Yellow brand header (as in the design)
          Container(
            color: EfuridePalette.accent,
            child: SafeArea(
              bottom: false,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(16, 8, 8, 12),
                child: Row(children: [
                  const KongoBrand(size: 40),
                  const Spacer(),
                  IconButton(
                      icon: const Icon(Icons.close_rounded, size: 30),
                      onPressed: () => Navigator.pop(context)),
                ]),
              ),
            ),
          ),
          Expanded(
            child: ListView(
              padding: const EdgeInsets.fromLTRB(18, 14, 18, 24),
              children: [
                Text(tr('Post a Job - Hire in minutes'),
                    style: const TextStyle(
                        fontSize: 26, fontWeight: FontWeight.w900, height: 1.1)),
                const SizedBox(height: 6),
                Text(
                    tr('Fill out the details and connect with trusted workers near you'),
                    style: const TextStyle(
                        fontSize: 15, color: EfuridePalette.inkMuted)),
                _label(tr('Job Title')),
                TextField(
                  controller: _title,
                  textCapitalization: TextCapitalization.sentences,
                  maxLength: 120,
                  decoration: _dec(tr('e.g. House Cleaner Needed'),
                      suffix: const Icon(Icons.edit_outlined)),
                ),
                _label(tr('Category')),
                SizedBox(
                  height: 112,
                  child: ListView(
                    scrollDirection: Axis.horizontal,
                    children: [
                      for (final c in _cats)
                        SizedBox(
                          width: 100,
                          child: Padding(
                            padding: const EdgeInsets.only(right: 10),
                            child: PictureTile(
                              label: tr(c.name),
                              asset: _asset(c.key),
                              networkUrl: c.imageUrl,
                              tint: _tint(c.key),
                              imageSize: 46,
                              selected: _cat == c.key,
                              onTap: () => setState(() => _cat = c.key),
                            ),
                          ),
                        ),
                    ],
                  ),
                ),
                _label(tr('Description')),
                TextField(
                  controller: _desc,
                  maxLines: 4,
                  maxLength: 800,
                  textCapitalization: TextCapitalization.sentences,
                  decoration: _dec(tr(
                      'Describe the job, what you need done, and any important details...')),
                ),
                _label(tr('Pay Type')),
                _seg([
                  MapEntry('hour', tr('Per Hour')),
                  MapEntry('day', tr('Per Day')),
                  MapEntry('fixed', tr('Fixed Price')),
                ], _pay, (v) => setState(() => _pay = v)),
                const SizedBox(height: 10),
                Text(tr('Amount ({0})', [CountryConfig.currencyCode]),
                    style: const TextStyle(
                        fontSize: 13, color: EfuridePalette.inkMuted)),
                const SizedBox(height: 4),
                TextField(
                  controller: _amount,
                  keyboardType:
                      const TextInputType.numberWithOptions(decimal: true),
                  decoration: _dec('0',
                      prefix: Padding(
                        padding: const EdgeInsets.only(left: 16, right: 6),
                        child: Center(
                          widthFactor: 1,
                          child: Text(CountryConfig.symbol,
                              style: const TextStyle(
                                  fontSize: 16, fontWeight: FontWeight.w800)),
                        ),
                      )),
                ),
                _label(tr('Location')),
                TextField(
                  controller: _loc,
                  decoration: _dec(tr('Where is the job?'),
                      prefix: const KIcon(Icons.location_on_outlined,
                          color: EfuridePalette.gold),
                      suffix: _locating
                          ? const Padding(
                              padding: EdgeInsets.all(14),
                              child: SizedBox(
                                  width: 18,
                                  height: 18,
                                  child: CircularProgressIndicator(
                                      strokeWidth: 2)))
                          : IconButton(
                              icon: const Icon(Icons.my_location),
                              tooltip: tr('Use my location'),
                              onPressed: _useMyLocation)),
                ),
                _label(tr('Duration')),
                _seg([
                  MapEntry('today', tr('Today')),
                  MapEntry('week', tr('This week')),
                  MapEntry('ongoing', tr('Ongoing')),
                ], _duration, (v) => setState(() => _duration = v)),
                _label(tr('Workers needed')),
                Row(children: [
                  IconButton.filledTonal(
                      onPressed: _workers > 1
                          ? () => setState(() => _workers--)
                          : null,
                      icon: const Icon(Icons.remove)),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 18),
                    child: Text('$_workers',
                        style: const TextStyle(
                            fontSize: 22, fontWeight: FontWeight.w900)),
                  ),
                  IconButton.filledTonal(
                      onPressed: _workers < 20
                          ? () => setState(() => _workers++)
                          : null,
                      icon: const Icon(Icons.add)),
                ]),
                _label(tr('Requirements')),
                _req(tr('Verified ID'), Icons.verified_user_outlined,
                    _verified, (v) => setState(() => _verified = v)),
                _req(tr('Experience'), Icons.work_outline, _exp,
                    (v) => setState(() => _exp = v)),
                _req(tr('Own tools'), Icons.handyman_outlined, _tools,
                    (v) => setState(() => _tools = v)),
                _req(tr('Own transport'), Icons.directions_car_outlined,
                    _transport, (v) => setState(() => _transport = v)),
                const SizedBox(height: 8),
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  value: _urgent,
                  activeColor: EfuridePalette.gold,
                  onChanged: (v) => setState(() => _urgent = v),
                  title: Text(tr('Mark as urgent'),
                      style: const TextStyle(
                          fontSize: 16, fontWeight: FontWeight.w700)),
                  subtitle: Text(
                      _fees.enabled && _fees.boostFee > 0
                          ? tr('+{0} · shown first for {1} days',
                              [fmtMoney(_fees.boostFee), _fees.boostDays])
                          : tr('Shown first for {0} days', [_fees.boostDays]),
                      style: const TextStyle(fontSize: 13)),
                ),
                const SizedBox(height: 6),
                GestureDetector(
                  onTap: _pickPhoto,
                  child: Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(
                          color: EfuridePalette.inkMuted.withValues(alpha: 0.6),
                          width: 1.4),
                    ),
                    child: Row(children: [
                      ClipRRect(
                        borderRadius: BorderRadius.circular(12),
                        child: Container(
                          width: 64,
                          height: 64,
                          color: const Color(0xFFEFEAE0),
                          child: _photo == null
                              ? const Icon(Icons.add_photo_alternate_outlined,
                                  size: 30)
                              : FutureBuilder<Uint8List>(
                                  future: _photo!.readAsBytes(),
                                  builder: (_, s) {
                                    final data = s.data;
                                    return data == null
                                        ? const SizedBox()
                                        : Image.memory(data, fit: BoxFit.cover);
                                  }),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('${tr('Upload photo')} — ${tr('optional')}',
                                style: const TextStyle(
                                    fontSize: 16, fontWeight: FontWeight.w900)),
                            Text(
                                tr('Add a photo to help workers understand the job'),
                                style: const TextStyle(
                                    fontSize: 13.5,
                                    color: EfuridePalette.inkMuted)),
                          ],
                        ),
                      ),
                      if (_photo != null)
                        IconButton(
                            icon: const Icon(Icons.close),
                            onPressed: () => setState(() => _photo = null)),
                    ]),
                  ),
                ),
                if (_fees.enabled && _fees.total(_urgent) > 0) ...[
                  const SizedBox(height: 14),
                  Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(color: EfuridePalette.accent, width: 1.6)),
                    child: Column(children: [
                      Row(children: [
                        Expanded(child: Text(tr('Posting fee'))),
                        Text(fmtMoney(_fees.postFee),
                            style: const TextStyle(fontWeight: FontWeight.w800)),
                      ]),
                      if (_urgent && _fees.boostFee > 0) ...[
                        const SizedBox(height: 6),
                        Row(children: [
                          Expanded(child: Text(tr('Urgent boost'))),
                          Text(fmtMoney(_fees.boostFee),
                              style:
                                  const TextStyle(fontWeight: FontWeight.w800)),
                        ]),
                      ],
                      const Divider(height: 18),
                      Row(children: [
                        Expanded(
                            child: Text(tr('Total from your wallet'),
                                style: const TextStyle(
                                    fontWeight: FontWeight.w900))),
                        Text(fmtMoney(_fees.total(_urgent)),
                            style: const TextStyle(
                                fontSize: 17, fontWeight: FontWeight.w900)),
                      ]),
                      const SizedBox(height: 6),
                      Row(children: [
                        Expanded(
                            child: Text(tr('Your wallet'),
                                style: const TextStyle(
                                    color: EfuridePalette.inkMuted))),
                        Text(fmtMoney(_fees.balance),
                            style: TextStyle(
                                fontWeight: FontWeight.w800,
                                color: _fees.balance >= _fees.total(_urgent)
                                    ? const Color(0xFF16803C)
                                    : EfuridePalette.danger)),
                      ]),
                      const SizedBox(height: 6),
                      Text(tr('If we do not approve your job, the fee is returned to your wallet.'),
                          style: const TextStyle(
                              fontSize: 12.5, color: EfuridePalette.inkMuted)),
                      if (_fees.balance < _fees.total(_urgent))
                        Align(
                          alignment: Alignment.centerRight,
                          child: TextButton(
                              onPressed: () =>
                                  Navigator.pushNamed(context, '/wallet'),
                              child: Text(tr('Top up wallet'))),
                        ),
                    ]),
                  ),
                ],
                const SizedBox(height: 14),
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                      color: const Color(0xFFFFF1CC),
                      borderRadius: BorderRadius.circular(12)),
                  child: Row(children: [
                    const Icon(Icons.info_outline, color: EfuridePalette.gold),
                    const SizedBox(width: 10),
                    Expanded(
                        child: Text(
                            tr('Your first name will be visible to workers. Your job is checked before it goes live.'),
                            style: const TextStyle(fontSize: 14))),
                  ]),
                ),
                const SizedBox(height: 14),
                SizedBox(
                  height: 52,
                  child: OutlinedButton(
                    onPressed: _busy ? null : _preview,
                    style: OutlinedButton.styleFrom(
                      side: const BorderSide(color: EfuridePalette.accent, width: 2),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(16)),
                    ),
                    child: Text(tr('Preview Job'),
                        style: const TextStyle(
                            fontSize: 17,
                            fontWeight: FontWeight.w900,
                            color: Color(0xFF8A5A00))),
                  ),
                ),
                const SizedBox(height: 10),
                SizedBox(
                  height: 58,
                  child: ElevatedButton(
                    onPressed: _busy ? null : _submit,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: EfuridePalette.accent,
                      foregroundColor: EfuridePalette.ink,
                      elevation: 0,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(18)),
                    ),
                    child: _busy
                        ? const SizedBox(
                            width: 24,
                            height: 24,
                            child: CircularProgressIndicator(strokeWidth: 2.8))
                        : Text(
                            _fees.enabled && _fees.total(_urgent) > 0
                                ? '${tr('Post Job Now')} · ${fmtMoney(_fees.total(_urgent))}'
                                : tr('Post Job Now'),
                            style: const TextStyle(
                                fontSize: 20, fontWeight: FontWeight.w900)),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ═════════════════════════════════════════════════════════════════
// HOME SECTION (the "Hiring" tab on the customer home screen)
// ═════════════════════════════════════════════════════════════════
class HiringHomeSection extends StatefulWidget {
  const HiringHomeSection({super.key});

  @override
  State<HiringHomeSection> createState() => _HiringHomeSectionState();
}

class _HiringHomeSectionState extends State<HiringHomeSection> {
  final _svc = HiringService.instance;
  List<JobCategory> _cats = [];
  List<Job> _latest = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final c = await _svc.categories();
    List<Job> j = [];
    try {
      j = await _svc.openJobs();
    } catch (_) {}
    if (!mounted) return;
    setState(() {
      _cats = c;
      _latest = j.take(3).toList();
      _loading = false;
    });
  }

  Future<void> _open({String? category, String tab = 'find'}) async {
    await Navigator.push(
        context,
        MaterialPageRoute(
            builder: (_) =>
                HiringHubScreen(initialCategory: category, initialTab: tab)));
    if (mounted) _load();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        // Banner
        ClipRRect(
          borderRadius: BorderRadius.circular(22),
          child: SizedBox(
            height: 160,
            child: Stack(
              fit: StackFit.expand,
              children: [
                Image.asset('assets/images/banner_hiring.jpg',
                    fit: BoxFit.cover,
                    alignment: Alignment.centerRight,
                    errorBuilder: (_, __, ___) =>
                        Container(color: const Color(0xFFFFE27A))),
                Container(
                  decoration: const BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.centerLeft,
                      end: Alignment.centerRight,
                      stops: [0.0, 0.55, 0.75],
                      colors: [
                        Color(0xCCFFF0BE),
                        Color(0x80FFF0BE),
                        Color(0x00FFF0BE),
                      ],
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 14, 110, 14),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(tr('Hiring Hub - Find work, hire talent'),
                          style: const TextStyle(
                              fontSize: 19,
                              fontWeight: FontWeight.w900,
                              height: 1.15)),
                      const SizedBox(height: 4),
                      Text(tr('Trusted workers and jobs near you'),
                          style: const TextStyle(fontSize: 13.5)),
                      const SizedBox(height: 10),
                      Row(children: [
                        _applyButton(tr('Find Work'), () => _open()),
                        const SizedBox(width: 8),
                        SizedBox(
                          height: 40,
                          child: OutlinedButton(
                            onPressed: () async {
                              final posted = await Navigator.push<bool>(
                                  context,
                                  MaterialPageRoute(
                                      builder: (_) => PostJobScreen(cats: _cats)));
                              if (posted == true && mounted) _open(tab: 'mine');
                            },
                            style: OutlinedButton.styleFrom(
                              backgroundColor: Colors.white,
                              side: BorderSide.none,
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 14),
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(14)),
                            ),
                            child: Text(tr('Post a Job'),
                                style: const TextStyle(
                                    fontSize: 14,
                                    fontWeight: FontWeight.w900,
                                    color: EfuridePalette.ink)),
                          ),
                        ),
                      ]),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 16),
        Row(children: [
          Expanded(
            child: Text(tr('Hiring Hub'),
                style:
                    const TextStyle(fontSize: 19, fontWeight: FontWeight.w900)),
          ),
          TextButton(onPressed: () => _open(), child: Text('${tr('See All')} ›')),
        ]),
        const SizedBox(height: 4),
        GridView.count(
          crossAxisCount: 3,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          mainAxisSpacing: 10,
          crossAxisSpacing: 10,
          childAspectRatio: 0.95,
          children: [
            for (final c in _cats)
              PictureTile(
                label: tr(c.name),
                asset: _asset(c.key),
                networkUrl: c.imageUrl,
                tint: _tint(c.key),
                onTap: () => _open(category: c.key),
              ),
          ],
        ),
        const SizedBox(height: 16),
        Text(tr('Latest jobs'),
            style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w900)),
        const SizedBox(height: 10),
        if (_loading)
          const Padding(
              padding: EdgeInsets.all(24),
              child: Center(child: CircularProgressIndicator()))
        else if (_latest.isEmpty)
          Padding(
            padding: const EdgeInsets.all(16),
            child: Text(tr('No jobs here yet. Be the first to post one!'),
                textAlign: TextAlign.center,
                style: const TextStyle(color: EfuridePalette.inkMuted)),
          )
        else
          for (final j in _latest)
            _JobCard(
              job: j,
              cats: _cats,
              onTap: () => _open(),
              trailing: _applyButton(tr('Apply'), () => _open()),
            ),
      ],
    );
  }
}
