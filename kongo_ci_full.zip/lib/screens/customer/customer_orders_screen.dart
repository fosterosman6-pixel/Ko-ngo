// lib/screens/customer/customer_orders_screen.dart
//
// "Orders" tab: the customer's shop orders (food, grocery, pharmacy).
// Active orders first; tap one to follow it live.

import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'package:efuride_app/config/country_config.dart';
import 'package:efuride_app/config/efuride_palette.dart';
import 'package:efuride_app/l10n/app_strings.dart';
import 'package:efuride_app/models/order.dart';
import 'package:efuride_app/services/order_service.dart';
import 'package:efuride_app/utils/app_error.dart';
import 'package:efuride_app/utils/error_ui.dart';
import 'package:efuride_app/utils/money.dart' show fmtDate;
import 'package:efuride_app/widgets/k_icon.dart';

class CustomerOrdersScreen extends StatefulWidget {
  const CustomerOrdersScreen({super.key});

  @override
  State<CustomerOrdersScreen> createState() => _CustomerOrdersScreenState();
}

class _CustomerOrdersScreenState extends State<CustomerOrdersScreen> {
  bool _showPast = false;
  List<Order> _active = [];
  List<Order> _past = [];
  final Map<String, String> _storeNames = {};
  bool _loading = true;
  AppError? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final uid = Supabase.instance.client.auth.currentUser?.id;
    if (uid == null) return;
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final res = await Future.wait([
        OrderService.instance.fetchActiveOrders(uid),
        OrderService.instance.fetchOrderHistory(uid),
      ]);
      final all = [...res[0], ...res[1]];
      final ids = {
        for (final o in all)
          if (o.partnerId != null && !_storeNames.containsKey(o.partnerId))
            o.partnerId!
      };
      if (ids.isNotEmpty) {
        final rows = await Supabase.instance.client
            .from('partners')
            .select('id, name')
            .inFilter('id', ids.toList());
        for (final r in rows) {
          _storeNames[r['id'].toString()] = (r['name'] ?? '').toString();
        }
      }
      if (!mounted) return;
      setState(() {
        _active = res[0];
        _past = res[1];
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _error = AppError.from(e, onRetry: _load);
      });
    }
  }

  String _storeName(Order o) =>
      o.partnerName ??
      _storeNames[o.partnerId] ??
      tr(o.serviceType);

  IconData _icon(Order o) {
    switch (o.serviceType.toLowerCase()) {
      case 'grocery':
        return Icons.shopping_basket;
      case 'pharmacy':
        return Icons.local_pharmacy;
      default:
        return Icons.restaurant;
    }
  }

  (String, Color) _status(Order o) {
    switch (o.status) {
      case OrderStatus.pending:
      case OrderStatus.confirmed:
        return (tr('Order placed'), const Color(0xFFB45309));
      case OrderStatus.shopping:
      case OrderStatus.preparing:
        return (tr('Being prepared'), const Color(0xFF1565C0));
      case OrderStatus.ready:
        return (tr('Ready for pickup'), const Color(0xFF1565C0));
      case OrderStatus.pickedUp:
      case OrderStatus.inTransit:
        return (tr('On the way'), const Color(0xFF15803D));
      case OrderStatus.delivered:
        return (tr('Delivered'), const Color(0xFF15803D));
      case OrderStatus.returning:
      case OrderStatus.returned:
        return (tr('Returned to office'), const Color(0xFFB45309));
      case OrderStatus.cancelled:
        return (tr('Cancelled'), EfuridePalette.dropoff);
      case OrderStatus.refunded:
        return (tr('Refunded'), EfuridePalette.inkMuted);
    }
  }

  void _open(Order o) {
    Navigator.pushNamed(context, '/order_tracking', arguments: {
      'order_id': o.id,
      'service_type': o.serviceType,
      'store_name': _storeName(o),
      'store_address': '',
      'dropoff': o.deliveryAddress ?? '',
      'total': o.total,
    }).then((_) => _load());
  }

  @override
  Widget build(BuildContext context) {
    final list = _showPast ? _past : _active;
    return Container(
      color: EfuridePalette.cream,
      child: SafeArea(
        bottom: false,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 14, 20, 10),
              child: Text(tr('My orders'),
                  style: const TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.w800,
                      color: EfuridePalette.ink)),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: SegmentedButton<bool>(
                showSelectedIcon: false,
                segments: [
                  ButtonSegment(
                      value: false,
                      label: Text('${tr('Active')} (${_active.length})',
                          style: const TextStyle(
                              fontSize: 15, fontWeight: FontWeight.w700))),
                  ButtonSegment(
                      value: true,
                      label: Text(tr('Past'),
                          style: const TextStyle(
                              fontSize: 15, fontWeight: FontWeight.w700))),
                ],
                selected: {_showPast},
                onSelectionChanged: (s) =>
                    setState(() => _showPast = s.first),
                style: SegmentedButton.styleFrom(
                  selectedBackgroundColor: EfuridePalette.accent,
                  selectedForegroundColor: EfuridePalette.accentInk,
                  backgroundColor: Colors.white,
                ),
              ),
            ),
            const SizedBox(height: 10),
            Expanded(
              child: _loading
                  ? const Center(child: CircularProgressIndicator())
                  : _error != null
                      ? ErrorUI.inline(_error!)
                      : RefreshIndicator(
                          onRefresh: _load,
                          child: list.isEmpty
                              ? _empty()
                              : ListView.separated(
                                  physics:
                                      const AlwaysScrollableScrollPhysics(),
                                  padding: const EdgeInsets.fromLTRB(
                                      16, 4, 16, 24),
                                  itemCount: list.length,
                                  separatorBuilder: (_, __) =>
                                      const SizedBox(height: 10),
                                  itemBuilder: (_, i) => _card(list[i]),
                                ),
                        ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _empty() => ListView(
        physics: const AlwaysScrollableScrollPhysics(),
        children: [
          const SizedBox(height: 100),
          const KIcon(Icons.receipt_long_outlined,
              size: 56, color: EfuridePalette.inkMuted),
          const SizedBox(height: 12),
          Center(
            child: Text(
              _showPast ? tr('No past orders yet') : tr('No active orders'),
              style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800),
            ),
          ),
          const SizedBox(height: 6),
          Center(
            child: Text(
              tr('Order food, groceries or medicine from the Home tab.'),
              textAlign: TextAlign.center,
              style: const TextStyle(
                  fontSize: 15, color: EfuridePalette.inkMuted),
            ),
          ),
        ],
      );

  Widget _card(Order o) {
    final (label, color) = _status(o);
    final items = o.lines.fold<int>(0, (s, l) => s + l.qty);
    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(14),
      child: InkWell(
        onTap: () => _open(o),
        borderRadius: BorderRadius.circular(14),
        child: Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: EfuridePalette.divider),
          ),
          child: Row(
            children: [
              Container(
                width: 48,
                height: 48,
                decoration: BoxDecoration(
                  color: EfuridePalette.greyBg,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(_icon(o), color: EfuridePalette.ink),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(_storeName(o),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                            fontSize: 16.5, fontWeight: FontWeight.w800)),
                    const SizedBox(height: 2),
                    Text(
                      [
                        fmtDate(o.createdAt.toIso8601String()),
                        if (items > 0) tr('{0} items', ['$items']),
                      ].join('  ·  '),
                      style: const TextStyle(
                          fontSize: 14, color: EfuridePalette.inkMuted),
                    ),
                    const SizedBox(height: 6),
                    Text(label,
                        style: TextStyle(
                            fontSize: 14.5,
                            fontWeight: FontWeight.w800,
                            color: color)),
                  ],
                ),
              ),
              Text(CountryConfig.money(o.total),
                  style: const TextStyle(
                      fontSize: 16, fontWeight: FontWeight.w800)),
              const SizedBox(width: 4),
              const Icon(Icons.chevron_right, color: EfuridePalette.inkMuted),
            ],
          ),
        ),
      ),
    );
  }
}
