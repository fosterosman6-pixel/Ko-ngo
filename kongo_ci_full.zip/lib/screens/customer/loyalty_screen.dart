﻿import 'package:efuride_app/config/efuride_palette.dart';
// lib/screens/customer/loyalty_screen.dart

import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:efuride_app/config/app_images.dart';
import 'package:efuride_app/widgets/app_image.dart';
import 'package:efuride_app/l10n/app_strings.dart';

class LoyaltyScreen extends StatefulWidget {
  const LoyaltyScreen({super.key});

  @override
  State<LoyaltyScreen> createState() => _LoyaltyScreenState();
}

class _LoyaltyScreenState extends State<LoyaltyScreen> {
  int _points = 0;
  String _tier = 'Bronze';
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final userId = Supabase.instance.client.auth.currentUser?.id;
      if (userId == null) {
        setState(() => _isLoading = false);
        return;
      }
      final profile = await Supabase.instance.client
          .from('profiles')
          .select('loyalty_points')
          .eq('id', userId)
          .single();
      final points = (profile['loyalty_points'] ?? 0) as int;
      if (!mounted) return;
      setState(() {
        _points = points;
        if (points >= 500) {
          _tier = 'Platinum';
        } else if (points >= 300) {
          _tier = 'Gold';
        } else if (points >= 150) {
          _tier = 'Silver';
        } else {
          _tier = 'Bronze';
        }
        _isLoading = false;
      });
    } catch (_) {
      if (!mounted) return;
      setState(() => _isLoading = false);
    }
  }

  int get _nextTierAt {
    switch (_tier) {
      case 'Bronze':
        return 150;
      case 'Silver':
        return 300;
      case 'Gold':
        return 500;
      default:
        return 0;
    }
  }

  String get _nextTier => _tier == 'Bronze'
      ? 'Silver'
      : _tier == 'Silver'
          ? 'Gold'
          : _tier == 'Gold'
              ? 'Platinum'
              : '';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: EfuridePalette.cream,
      appBar: AppBar(
        backgroundColor: EfuridePalette.cream,
        elevation: 0,
        scrolledUnderElevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Color(0xFF1A1A1A)),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          tr('Loyalty'),
          style: TextStyle(
            color: Color(0xFF1A1A1A),
            fontSize: 18,
            fontWeight: FontWeight.w700,
          ),
        ),
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : SafeArea(
              top: false,
              child: ListView(
                padding: const EdgeInsets.fromLTRB(20, 8, 20, 24),
                children: [
                  Container(
                    padding: const EdgeInsets.all(28),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(16),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.05),
                          blurRadius: 12,
                          offset: const Offset(0, 3),
                        ),
                      ],
                    ),
                    child: Column(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(16),
                          decoration: BoxDecoration(
                            color: _tierColor.withOpacity(0.15),
                            shape: BoxShape.circle,
                          ),
                          child: AppImage(
                            AppImages.gift,
                            size: 44,
                            fallbackIcon: Icons.workspace_premium,
                          ),
                        ),
                        const SizedBox(height: 16),
                        Text(
                          _tier.toUpperCase(),
                          style: TextStyle(
                            fontSize: 26,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 1,
                            color: _tierColor,
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          tr('{0} points', [_points]),
                          style: const TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.w700,
                            color: Color(0xFF1A1A1A),
                          ),
                        ),
                        if (_nextTierAt > 0) ...[
                          const SizedBox(height: 12),
                          ClipRRect(
                            borderRadius: BorderRadius.circular(6),
                            child: LinearProgressIndicator(
                              value: _points / _nextTierAt,
                              minHeight: 6,
                              backgroundColor: Colors.grey.shade200,
                              valueColor:
                                  AlwaysStoppedAnimation(_tierColor),
                            ),
                          ),
                          const SizedBox(height: 8),
                          Text(
                            tr('{0} points to {1}', [_nextTierAt - _points, _nextTier]),
                            style: TextStyle(
                              fontSize: 13.5,
                              color: Colors.grey.shade600,
                            ),
                          ),
                        ],
                      ],
                    ),
                  ),
                  const SizedBox(height: 28),
                  Text(
                    tr('Tier benefits'),
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w700,
                      color: Color(0xFF1A1A1A),
                    ),
                  ),
                  const SizedBox(height: 12),
                  _benefitRow(
                    'Bronze',
                    '10 points per ride',
                    const Color(0xFFCD7F32),
                    _tier == 'Bronze',
                  ),
                  _benefitRow(
                    'Silver',
                    '15 points per ride · 5% discount',
                    const Color(0xFF9E9E9E),
                    _tier == 'Silver',
                  ),
                  _benefitRow(
                    'Gold',
                    '20 points per ride · 10% discount',
                    const Color(0xFFFFB300),
                    _tier == 'Gold',
                  ),
                  _benefitRow(
                    'Platinum',
                    '25 points per ride · 15% discount + VIP support',
                    const Color(0xFF546E7A),
                    _tier == 'Platinum',
                  ),
                ],
              ),
            ),
    );
  }

  Color get _tierColor {
    switch (_tier) {
      case 'Platinum':
        return const Color(0xFF546E7A);
      case 'Gold':
        return const Color(0xFFFFB300);
      case 'Silver':
        return const Color(0xFF9E9E9E);
      default:
        return const Color(0xFFCD7F32);
    }
  }

  Widget _benefitRow(
      String name, String benefit, Color color, bool active) {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: active ? color.withOpacity(0.08) : Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
          color: active ? color : Colors.grey.shade200,
          width: active ? 1.5 : 1,
        ),
      ),
      child: Row(
        children: [
          Container(
            width: 40,
            height: 40,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: color.withOpacity(0.15),
              shape: BoxShape.circle,
            ),
            child: AppImage(
              AppImages.coinsBlue,
              size: 22,
              tint: color,
              fallbackIcon: Icons.star,
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  name,
                  style: const TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.w700,
                    color: Color(0xFF1A1A1A),
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  benefit,
                  style: TextStyle(
                      fontSize: 13.5, color: Colors.grey.shade600),
                ),
              ],
            ),
          ),
          if (active)
            Icon(Icons.check_circle, size: 22, color: color),
        ],
      ),
    );
  }
}
