// lib/screens/customer/rating_screen.dart
//
// Single source of truth for all ratings.
// Writes to `ratings` table only. A DB trigger recomputes
// profiles.average_rating / total_ratings.

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:efuride_app/config/efuride_palette.dart';
import 'package:efuride_app/utils/app_error.dart';
import 'package:efuride_app/utils/error_ui.dart';

class RatingScreen extends StatefulWidget {
  /// Optional prefill — passed from trip_complete / trip_ended.
  final String? rideId;
  final String? rateeId;
  final String? rateeName;
  final String? rateeAvatarUrl;
  final String? raterRole; // 'customer' | 'driver'

  const RatingScreen({
    super.key,
    this.rideId,
    this.rateeId,
    this.rateeName,
    this.rateeAvatarUrl,
    this.raterRole,
  });

  @override
  State<RatingScreen> createState() => _RatingScreenState();
}

class _RatingScreenState extends State<RatingScreen> {
  int _stars = 0;
  final TextEditingController _feedbackCtrl = TextEditingController();
  final Set<String> _selectedTags = {};

  bool _isLoading = true;
  bool _isSubmitting = false;
  bool _alreadyRated = false;
  AppError? _error;

  String _raterRole = 'customer';
  Map<String, dynamic>? _rateeProfile;
  Map<String, dynamic>? _ride;

  static const _customerTags = [
    'Excellent service',
    'Polite driver',
    'Arrived on time',
    'Safe driving',
    'Clean vehicle',
    'Good communication',
  ];

  static const _driverTags = [
    'Great passenger',
    'Polite & friendly',
    'Ready on time',
    'Clean & tidy',
    'Good communication',
  ];

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _feedbackCtrl.dispose();
    super.dispose();
  }

  // ============================================================
  // LOAD — resolve ride + ratee
  // ============================================================
  Future<void> _load() async {
    setState(() {
      _isLoading = true;
      _error = null;
    });

    try {
      final user = Supabase.instance.client.auth.currentUser;
      if (user == null) throw Exception('Not signed in');

      // Case 1: explicit args from trip_complete / trip_ended.
      if (widget.rideId != null && widget.rateeId != null) {
        _raterRole = widget.raterRole ?? 'customer';
        _ride = {'id': widget.rideId};
        _rateeProfile = {
          'id': widget.rateeId,
          'first_name': widget.rateeName,
          'profile_picture_url': widget.rateeAvatarUrl,
        };

        final existing = await Supabase.instance.client
            .from('ratings')
            .select('id')
            .eq('ride_id', widget.rideId!)
            .eq('rater_id', user.id)
            .maybeSingle();

        if (!mounted) return;
        setState(() {
          _alreadyRated = existing != null;
          _isLoading = false;
        });
        return;
      }

      // Case 2: auto-detect — most recent completed ride within 24h.
      final uid = user.id;
      final window = DateTime.now()
          .subtract(const Duration(hours: 24))
          .toUtc()
          .toIso8601String();

      // Try as customer first.
      final asCustomer = await Supabase.instance.client
          .from('rides')
          .select()
          .eq('customer_id', uid)
          .eq('status', 'completed')
          .gte('completed_at', window)
          .order('completed_at', ascending: false)
          .limit(1)
          .maybeSingle();

      if (asCustomer != null &&
          asCustomer['driver_id'] != null &&
          asCustomer['driver_id'].toString() != uid) {
        _raterRole = 'customer';
        _ride = asCustomer;
        _rateeProfile = await Supabase.instance.client
            .from('profiles')
            .select(
              'id, first_name, surname, full_name, profile_picture_url, '
              'average_rating, total_ratings',
            )
            .eq('id', asCustomer['driver_id'])
            .maybeSingle();
      } else {
        // Try as driver.
        final asDriver = await Supabase.instance.client
            .from('rides')
            .select()
            .eq('driver_id', uid)
            .eq('status', 'completed')
            .gte('completed_at', window)
            .order('completed_at', ascending: false)
            .limit(1)
            .maybeSingle();

        if (asDriver != null && asDriver['customer_id'] != null) {
          _raterRole = 'driver';
          _ride = asDriver;
          _rateeProfile = await Supabase.instance.client
              .from('profiles')
              .select(
                'id, first_name, surname, full_name, profile_picture_url, '
                'average_rating, total_ratings',
              )
              .eq('id', asDriver['customer_id'])
              .maybeSingle();
        }
      }

      if (_ride != null) {
        final existing = await Supabase.instance.client
            .from('ratings')
            .select('id')
            .eq('ride_id', _ride!['id'])
            .eq('rater_id', uid)
            .maybeSingle();
        _alreadyRated = existing != null;
      }

      if (!mounted) return;
      setState(() => _isLoading = false);
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _isLoading = false;
        _error = AppError.from(e, onRetry: _load);
      });
    }
  }

  List<String> get _quickTags =>
      _raterRole == 'customer' ? _customerTags : _driverTags;

  String _rateeName() {
    if (_rateeProfile == null) {
      return _raterRole == 'customer' ? 'your driver' : 'your passenger';
    }
    final f = _rateeProfile!['first_name'] ?? '';
    final s = _rateeProfile!['surname'] ?? '';
    final full = _rateeProfile!['full_name'] ?? '';
    final composed = '$f $s'.trim();
    if (composed.isNotEmpty) return composed;
    if (full.toString().trim().isNotEmpty) return full.toString().trim();
    return _raterRole == 'customer' ? 'your driver' : 'your passenger';
  }

  double? _rateeRating() {
    final r = _rateeProfile?['average_rating'];
    if (r == null) return null;
    if (r is num) return r.toDouble();
    final parsed = double.tryParse(r.toString());
    if (parsed == null || parsed == 0) return null;
    return parsed;
  }

  int _rateeTotal() {
    final r = _rateeProfile?['total_ratings'];
    if (r is num) return r.toInt();
    if (r != null) return int.tryParse(r.toString()) ?? 0;
    return 0;
  }

  // ============================================================
  // SUBMIT
  // ============================================================
  Future<void> _submitRating() async {
    if (_ride == null || _rateeProfile == null) {
      ErrorUI.showSnack(
        context,
        const AppError(
          title: 'No trip to rate',
          message: 'We couldn\'t find a completed ride.',
          icon: Icons.info_outline,
        ),
      );
      return;
    }
    if (_stars == 0) {
      ErrorUI.showSnack(
        context,
        const AppError(
          title: 'Pick a rating',
          message: 'Tap a star to rate your experience.',
          icon: Icons.star_border,
        ),
      );
      return;
    }

    setState(() => _isSubmitting = true);

    try {
      final user = Supabase.instance.client.auth.currentUser;
      if (user == null) throw Exception('Not signed in');

      final rideId = _ride!['id'];
      final rateeId = _rateeProfile!['id'];

      await Supabase.instance.client.from('ratings').insert({
        'ride_id': rideId,
        'rater_id': user.id,
        'ratee_id': rateeId,
        'rater_role': _raterRole,
        'stars': _stars,
        'tags': _selectedTags.toList(),
        'feedback': _feedbackCtrl.text.trim().isEmpty
            ? null
            : _feedbackCtrl.text.trim(),
        'created_at': DateTime.now().toUtc().toIso8601String(),
      });
      // DB trigger recomputes profiles.average_rating + total_ratings.

      if (!mounted) return;
      try {
        HapticFeedback.lightImpact();
      } catch (_) {}

      ErrorUI.showSnack(
        context,
        const AppError(
          title: 'Thanks for rating!',
          message: 'Your feedback helps keep eFuride safe.',
          icon: Icons.check_circle_outline,
        ),
      );
      Navigator.pop(context, true);
    } catch (e) {
      if (!mounted) return;
      ErrorUI.showSnack(
        context,
        AppError.from(e, onRetry: _submitRating),
      );
    } finally {
      if (mounted) setState(() => _isSubmitting = false);
    }
  }

  // ============================================================
  // BUILD
  // ============================================================
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: EfuridePalette.cream,
      body: Column(
        children: [
          _header(),
          Expanded(child: _body()),
        ],
      ),
    );
  }

  Widget _header() {
    final isDriver = _raterRole == 'driver';
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          colors: [EfuridePalette.blue, EfuridePalette.blueDeep],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
      ),
      child: SafeArea(
        bottom: false,
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(8, 8, 16, 12),
              child: Row(
                children: [
                  IconButton(
                    onPressed: () => Navigator.pop(context),
                    icon: const Icon(Icons.arrow_back,
                        color: Colors.white),
                  ),
                  const SizedBox(width: 4),
                  Container(
                    width: 36,
                    height: 36,
                    decoration: const BoxDecoration(
                      color: Colors.white,
                      shape: BoxShape.circle,
                    ),
                    child: const Center(
                      child: Icon(Icons.star,
                          color: EfuridePalette.accent, size: 20),
                    ),
                  ),
                  const SizedBox(width: 10),
                  const Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('EFURIDE',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 16,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 1.2,
                            height: 1.05,
                          )),
                      SizedBox(height: 2),
                      Text('Rating',
                          style: TextStyle(
                            color: Colors.white70,
                            fontSize: 11.5,
                            fontWeight: FontWeight.w500,
                          )),
                    ],
                  ),
                ],
              ),
            ),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 18),
              decoration: const BoxDecoration(
                color: EfuridePalette.navy,
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(24),
                  topRight: Radius.circular(24),
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    isDriver ? 'Rate your passenger' : 'Rate your driver',
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 22,
                      fontWeight: FontWeight.w900,
                      letterSpacing: -0.3,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    isDriver
                        ? 'Your feedback keeps the community safe'
                        : 'Help other riders find great drivers',
                    style: const TextStyle(
                        color: Colors.white70, fontSize: 13),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _body() {
    if (_isLoading) {
      return const Center(
        child: CircularProgressIndicator(
            color: EfuridePalette.accent),
      );
    }
    if (_error != null) return ErrorUI.inline(_error!);
    if (_alreadyRated) return _alreadyRatedView();

    if (_ride == null || _rateeProfile == null) {
      return _noTripView();
    }

    return SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          _rateeCard(),
          const SizedBox(height: 24),
          _starsRow(),
          const SizedBox(height: 8),
          _ratingLabel(),
          const SizedBox(height: 20),
          _tagsWrap(),
          const SizedBox(height: 20),
          _feedbackField(),
          const SizedBox(height: 20),
          _submitButton(),
          const SizedBox(height: 12),
          TextButton(
            onPressed: _isSubmitting
                ? null
                : () => Navigator.pop(context, false),
            child: const Text('Skip for now',
                style: TextStyle(
                    fontSize: 13,
                    color: EfuridePalette.inkMuted,
                    fontWeight: FontWeight.w600)),
          ),
        ],
      ),
    );
  }

  // ── Ratee card ──
  Widget _rateeCard() {
    final rating = _rateeRating();
    final total = _rateeTotal();
    final pic = _rateeProfile?['profile_picture_url']?.toString() ?? '';
    final initial = _rateeName().isNotEmpty
        ? _rateeName()[0].toUpperCase()
        : '?';

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: EfuridePalette.divider),
      ),
      child: Row(
        children: [
          CircleAvatar(
            radius: 30,
            backgroundColor:
                EfuridePalette.blueDeep.withValues(alpha: 0.12),
            backgroundImage:
                pic.isNotEmpty ? NetworkImage(pic) : null,
            child: pic.isEmpty
                ? Text(initial,
                    style: const TextStyle(
                      color: EfuridePalette.blueDeep,
                      fontSize: 22,
                      fontWeight: FontWeight.w900,
                    ))
                : null,
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(_rateeName(),
                    style: const TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w800,
                        color: EfuridePalette.ink),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis),
                const SizedBox(height: 4),
                if (rating != null)
                  Row(
                    children: [
                      const Icon(Icons.star,
                          color: EfuridePalette.accent, size: 14),
                      const SizedBox(width: 4),
                      Text(rating.toStringAsFixed(1),
                          style: const TextStyle(
                              fontSize: 12.5,
                              fontWeight: FontWeight.w800,
                              color: EfuridePalette.ink)),
                      const SizedBox(width: 6),
                      Text('($total)',
                          style: const TextStyle(
                              fontSize: 11.5,
                              color: EfuridePalette.inkMuted)),
                    ],
                  )
                else
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 8, vertical: 3),
                    decoration: BoxDecoration(
                      color: EfuridePalette.accent
                          .withValues(alpha: 0.15),
                      borderRadius: BorderRadius.circular(6),
                    ),
                    child: const Text('New to eFuride',
                        style: TextStyle(
                          fontSize: 10.5,
                          fontWeight: FontWeight.w800,
                          color: EfuridePalette.accent,
                        )),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ── Stars ──
  Widget _starsRow() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: List.generate(5, (i) {
        final filled = i < _stars;
        final isNext = i == _stars;
        return Padding(
          padding: const EdgeInsets.symmetric(horizontal: 4),
          child: GestureDetector(
            onTap: _isSubmitting
                ? null
                : () {
                    setState(() => _stars = i + 1);
                    try {
                      HapticFeedback.selectionClick();
                    } catch (_) {}
                  },
            child: AnimatedScale(
              scale: filled || isNext ? 1.0 : 0.92,
              duration: const Duration(milliseconds: 180),
              child: Icon(
                filled ? Icons.star : Icons.star_border,
                color: filled
                    ? EfuridePalette.accent
                    : EfuridePalette.divider,
                size: 48,
              ),
            ),
          ),
        );
      }),
    );
  }

  // ── Rating label (single source of truth) ──
  //
  // NOTE: There used to be a duplicate `String _ratingLabel()` here that
  // shadowed this widget and caused a `duplicate_definition` error.
  // That string version has been removed — its logic lives in
  // `_ratingLabelText()` below, and this widget wraps it.
  Widget _ratingLabel() {
    final isEmpty = _stars == 0;
    return Center(
      child: AnimatedSwitcher(
        duration: const Duration(milliseconds: 180),
        child: Text(
          _ratingLabelText(),
          key: ValueKey(_stars),
          style: TextStyle(
            fontSize: 15,
            fontWeight: FontWeight.w800,
            color: isEmpty
                ? EfuridePalette.inkMuted
                : EfuridePalette.ink,
          ),
        ),
      ),
    );
  }

  String _ratingLabelText() {
    switch (_stars) {
      case 0:
        return 'Tap to rate';
      case 1:
        return 'Terrible';
      case 2:
        return 'Bad';
      case 3:
        return 'Okay';
      case 4:
        return 'Good';
      case 5:
        return 'Excellent!';
      default:
        return '';
    }
  }

  // ── Tags ──
  Widget _tagsWrap() {
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      alignment: WrapAlignment.center,
      children: _quickTags.map((t) {
        final selected = _selectedTags.contains(t);
        return GestureDetector(
          onTap: _isSubmitting
              ? null
              : () {
                  setState(() {
                    if (selected) {
                      _selectedTags.remove(t);
                    } else {
                      _selectedTags.add(t);
                    }
                  });
                },
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 180),
            padding: const EdgeInsets.symmetric(
                horizontal: 14, vertical: 9),
            decoration: BoxDecoration(
              color: selected
                  ? EfuridePalette.accent.withValues(alpha: 0.15)
                  : Colors.white,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(
                color: selected
                    ? EfuridePalette.accent
                    : EfuridePalette.divider,
                width: selected ? 1.6 : 1,
              ),
            ),
            child: Text(t,
                style: TextStyle(
                  fontSize: 12.5,
                  fontWeight: FontWeight.w700,
                  color: selected
                      ? EfuridePalette.ink
                      : EfuridePalette.inkMuted,
                )),
          ),
        );
      }).toList(),
    );
  }

  // ── Feedback ──
  Widget _feedbackField() {
    return TextField(
      controller: _feedbackCtrl,
      maxLines: 3,
      maxLength: 300,
      enabled: !_isSubmitting,
      textCapitalization: TextCapitalization.sentences,
      decoration: InputDecoration(
        hintText: 'Share more feedback (optional)',
        hintStyle: const TextStyle(
            fontSize: 13, color: EfuridePalette.inkMuted),
        filled: true,
        fillColor: Colors.white,
        contentPadding: const EdgeInsets.all(14),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide:
              const BorderSide(color: EfuridePalette.divider),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide:
              const BorderSide(color: EfuridePalette.divider),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(
              color: EfuridePalette.blueDeep, width: 1.5),
        ),
      ),
    );
  }

  // ── Submit ──
  Widget _submitButton() {
    final disabled = _isSubmitting || _stars == 0;
    return ElevatedButton(
      onPressed: disabled ? null : _submitRating,
      style: ElevatedButton.styleFrom(
        backgroundColor: EfuridePalette.accent,
        foregroundColor: EfuridePalette.accentInk,
        disabledBackgroundColor:
            EfuridePalette.divider,
        minimumSize: const Size(double.infinity, 54),
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(14)),
        elevation: 0,
      ),
      child: _isSubmitting
          ? const SizedBox(
              width: 20,
              height: 20,
              child: CircularProgressIndicator(
                  strokeWidth: 2, color: EfuridePalette.accentInk),
            )
          : const Text('Submit rating',
              style: TextStyle(
                  fontSize: 15, fontWeight: FontWeight.w900)),
    );
  }

  // ── Already rated ──
  Widget _alreadyRatedView() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 80,
              height: 80,
              decoration: BoxDecoration(
                color: EfuridePalette.online.withValues(alpha: 0.12),
                shape: BoxShape.circle,
              ),
              child: const Center(
                child: Icon(Icons.check_circle_outline,
                    size: 42, color: EfuridePalette.online),
              ),
            ),
            const SizedBox(height: 20),
            const Text('Already rated',
                style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w900,
                    color: EfuridePalette.ink)),
            const SizedBox(height: 8),
            const Text(
              'You\'ve already rated this trip. Thanks for the feedback!',
              textAlign: TextAlign.center,
              style: TextStyle(
                  fontSize: 13,
                  color: EfuridePalette.inkMuted,
                  height: 1.5),
            ),
            const SizedBox(height: 24),
            ElevatedButton(
              onPressed: () => Navigator.pop(context, false),
              style: ElevatedButton.styleFrom(
                backgroundColor: EfuridePalette.accent,
                foregroundColor: EfuridePalette.accentInk,
                minimumSize: const Size(160, 48),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12)),
                elevation: 0,
              ),
              child: const Text('Back'),
            ),
          ],
        ),
      ),
    );
  }

  // ── No trip ──
  Widget _noTripView() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 80,
              height: 80,
              decoration: BoxDecoration(
                color: EfuridePalette.inkMuted.withValues(alpha: 0.12),
                shape: BoxShape.circle,
              ),
              child: const Center(
                child: Icon(Icons.info_outline,
                    size: 38, color: EfuridePalette.inkMuted),
              ),
            ),
            const SizedBox(height: 20),
            const Text('Nothing to rate',
                style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w900,
                    color: EfuridePalette.ink)),
            const SizedBox(height: 8),
            const Text(
              'We couldn\'t find a recent completed trip. Ratings are '
              'available for 24 hours after a trip ends.',
              textAlign: TextAlign.center,
              style: TextStyle(
                  fontSize: 13,
                  color: EfuridePalette.inkMuted,
                  height: 1.5),
            ),
            const SizedBox(height: 24),
            ElevatedButton(
              onPressed: () => Navigator.pop(context, false),
              style: ElevatedButton.styleFrom(
                backgroundColor: EfuridePalette.accent,
                foregroundColor: EfuridePalette.accentInk,
                minimumSize: const Size(160, 48),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12)),
                elevation: 0,
              ),
              child: const Text('Back'),
            ),
          ],
        ),
      ),
    );
  }
}
