import 'package:efuride_app/config/efuride_palette.dart';
// lib/screens/customer/customer_shell.dart

import 'package:flutter/material.dart';
import 'package:efuride_app/config/tab_routes.dart';
import 'package:efuride_app/widgets/efuride_bottom_nav.dart';
import 'package:efuride_app/screens/customer/customer_home_screen.dart';
import 'package:efuride_app/screens/customer/ride_history_screen.dart';
import 'package:efuride_app/screens/customer/customer_orders_screen.dart';
import 'package:efuride_app/screens/customer/customer_settings_screen.dart';

class CustomerShell extends StatefulWidget {
  final int  initialIndex;
  final bool orderPlaced;
  final Map<String, dynamic> orderArgs;

  const CustomerShell({
    super.key,
    this.initialIndex = 0,
    this.orderPlaced = false,
    this.orderArgs = const {},
  });

  @override
  State<CustomerShell> createState() => _CustomerShellState();
}

class _CustomerShellState extends State<CustomerShell> {
  late int _index;
  bool _handoffScheduled = false;

  @override
  void initState() {
    super.initState();
    _index = widget.initialIndex.clamp(0, kCustomerTabs.length - 1);

    if (widget.orderPlaced && !_handoffScheduled) {
      _handoffScheduled = true;
      WidgetsBinding.instance.addPostFrameCallback((_) => _pushTracking());
    }
  }

  void _pushTracking() {
    if (!mounted) return;
    final orderId = (widget.orderArgs['order_id'] ?? '').toString();
    if (orderId.isEmpty) return;

    Navigator.of(context).pushNamed(
      '/order_tracking',
      arguments: {
        'order_id':      orderId,
        'service_type':  (widget.orderArgs['service_type']  ?? 'Food').toString(),
        'store_name':    (widget.orderArgs['store_name']    ?? '').toString(),
        'store_address': (widget.orderArgs['store_address'] ?? '').toString(),
        'dropoff':       (widget.orderArgs['dropoff']       ?? '').toString(),
        'total':         ((widget.orderArgs['total'] ?? 0) as num).toDouble(),
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    // Phone Back button: from another tab go to the first tab; on the
    // first tab leave the app as usual (never back to sign-in).
    return PopScope(
      canPop: _index == 0,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop && _index != 0) setState(() => _index = 0);
      },
      child: Scaffold(
      backgroundColor: EfuridePalette.cream,
      body: IndexedStack(
        index: _index,
        children: const [
          CustomerHomeScreen(),
          RideHistoryScreen(),
          CustomerOrdersScreen(),
          CustomerSettingsScreen(asTab: true),
        ],
      ),
      bottomNavigationBar: EfurideBottomNav(
        role: EfurideRole.customer,
        currentIndex: _index,
        onTap: (i) => setState(() => _index = i),
        items: kCustomerTabs,
      ),
    ),
    );
  }
}

// ── Factory used by main.dart's onGenerateRoute ──────────────────
CustomerShell buildCustomerShell(Uri uri, Object? args) {
  final m = args is Map ? args : const <String, dynamic>{};

  final tabIndex = TabRoute.indexFor('customer', uri.queryParameters['tab']);

  return CustomerShell(
    initialIndex: tabIndex,
    orderPlaced:  m['order_placed'] == true,
    orderArgs:    m['order_placed'] == true
        ? Map<String, dynamic>.from(m)
        : const {},
  );
}
