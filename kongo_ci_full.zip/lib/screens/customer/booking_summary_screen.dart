// lib/screens/customer/booking_summary_screen.dart
//
// Booking review screen. Collects delivery details (for Parcel),
// promo code, driver note, and optional bid, then inserts a `rides`
// row and pops the result back to CustomerHomeScreen.
//
// i18n-clean · currency-clean · uses CountryConfig + S.

import 'dart:async';
import 'dart:io' show File;
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:image_picker/image_picker.dart';

import 'package:efuride_app/config/country_config.dart';
import 'package:efuride_app/config/efuride_palette.dart';
import 'package:efuride_app/l10n/app_strings.dart';
import 'package:efuride_app/services/storage_service.dart';
import 'package:efuride_app/services/promo_service.dart';
import 'package:efuride_app/utils/app_error.dart';
import 'package:efuride_app/utils/error_ui.dart';
import 'package:provider/provider.dart';
import 'package:efuride_app/providers/auth_provider.dart';
import 'package:efuride_app/services/pricing_service.dart';
import 'package:efuride_app/widgets/payment_choice.dart';
import 'package:efuride_app/widgets/split_fare_card.dart';
import 'package:efuride_app/services/connection_service.dart';
import 'package:efuride_app/widgets/k_icon.dart';

enum _AddOn { none, promo, note, bidding }

class BookingSummaryScreen extends StatefulWidget {
  final String vehicle;
  final String pickup;
  final String dropoff;
  final String serviceType;
  final double fare;
  final double distance;
  final int? etaMinutes;
  final LatLng pickupLatLng;
  final LatLng dropoffLatLng;

  const BookingSummaryScreen({
    super.key,
    required this.vehicle,
    required this.pickup,
    required this.dropoff,
    required this.fare,
    required this.distance,
    required this.pickupLatLng,
    required this.dropoffLatLng,
    required this.serviceType,
    this.etaMinutes,
    this.startScheduled = false,
  });

  /// Opened from "Scheduled rides": start on "Later" with the time picker.
  final bool startScheduled;

  @override
  State<BookingSummaryScreen> createState() => _BookingSummaryScreenState();
}

class _BookingSummaryScreenState extends State<BookingSummaryScreen> {
  bool _isBidding = false;
  double _customerBid = 0;
  bool _isSubmitting = false;

  /// null = now. Otherwise the ride is booked for this time.
  DateTime? _scheduledAt;

  final TextEditingController _recipientNameController =
      TextEditingController();
  final TextEditingController _recipientPhoneController =
      TextEditingController();
  final TextEditingController _noteController = TextEditingController();
  final TextEditingController _promoCtrl = TextEditingController();
  XFile? _packagePhoto;

  bool _isCheckingPromo = false;
  PromoResult? _promoResult;
  String? _promoError;

  _AddOn _openSection = _AddOn.none;

  @override
  void initState() {
    super.initState();
    PricingService.changes.addListener(_onPricesChanged);
    _customerBid = widget.fare;
    if (widget.startScheduled) {
      WidgetsBinding.instance.addPostFrameCallback((_) => _pickScheduleTime());
    }
    // Fresh wallet balance + whether cards work in this country.
    Future.wait([
      context.read<AuthProvider>().refresh(),
      PricingService.current(),
    ]).then((_) {
      if (mounted) setState(() {});
    }).catchError((_) {});
  }

  /// Chosen payment. Until the customer picks, wallet when it covers the
  /// fare, otherwise cash.
  String? _pickedPay;
  String get _payMethod {
    final bal = context.read<AuthProvider>().walletBalance;
    final p = _pickedPay ?? PaymentChoice.suggested(_finalFare, bal);
    if (p == 'wallet' && bal < _finalFare) return 'cash';
    if (p == 'card' && !PaymentChoice.cardAvailable) return 'cash';
    return p;
  }

  void _onPricesChanged() {
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    PricingService.changes.removeListener(_onPricesChanged);
    _recipientNameController.dispose();
    _recipientPhoneController.dispose();
    _noteController.dispose();
    _promoCtrl.dispose();
    super.dispose();
  }

  // ═══════════════════════════════════════════════════════════
  // FARE
  // ═══════════════════════════════════════════════════════════
  double get _effectiveBaseFare => _isBidding ? _customerBid : widget.fare;

  double get _finalFare {
    if (_promoResult?.valid == true) {
      final v = _promoResult!.fareAfterDiscount;
      return v < 0 ? 0 : v;
    }
    return _effectiveBaseFare;
  }

  double get _sliderMin => (widget.fare * 0.5).clamp(1.0, double.infinity);
  double get _sliderMax =>
      (widget.fare * 1.5).clamp(_sliderMin + 1, double.infinity);

  // ═══════════════════════════════════════════════════════════
  // SECTIONS
  // ═══════════════════════════════════════════════════════════
  void _toggleSection(_AddOn section) {
    setState(() {
      final wasOpen = _openSection == section;
      _openSection = wasOpen ? _AddOn.none : section;
      _isBidding = _openSection == _AddOn.bidding;

      if (_openSection == _AddOn.bidding) {
        _customerBid = _customerBid.clamp(_sliderMin, _sliderMax);
        if (_promoResult != null) {
          _promoResult = null;
          _promoCtrl.clear();
          _promoError = null;
        }
      }
    });
  }

  // ═══════════════════════════════════════════════════════════
  // PHOTO
  // ═══════════════════════════════════════════════════════════
  Future<void> _pickPackagePhoto({bool fromCamera = false}) async {
    try {
      final file = await StorageService.instance.pickImage(
        fromCamera: fromCamera,
      );
      if (file != null && mounted) {
        setState(() => _packagePhoto = file);
      }
    } catch (_) {
      if (!mounted) return;
      final t = S.of(context);
      ErrorUI.showSnack(
        context,
        AppError(
          title: t.t('camera_error'),
          message: t.t('camera_error_hint'),
          icon: Icons.image_not_supported_outlined,
        ),
      );
    }
  }

  // ═══════════════════════════════════════════════════════════
  // PROMO
  // ═══════════════════════════════════════════════════════════
  Future<void> _applyPromo() async {
    final code = _promoCtrl.text.trim();
    if (code.isEmpty) return;

    setState(() {
      _isCheckingPromo = true;
      _promoError = null;
      _promoResult = null;
    });

    try {
      final result = await PromoService.validate(
        code: code,
        fare: widget.fare,
      ).timeout(const Duration(seconds: 12));

      if (!mounted) return;
      setState(() {
        _isCheckingPromo = false;
        if (result.valid) {
          _promoResult = result;
          _promoError = null;
        } else {
          _promoError = _friendlyPromoError(result.message);
        }
      });
    } on TimeoutException {
      if (!mounted) return;
      setState(() {
        _isCheckingPromo = false;
        _promoError = S.of(context).t('promo_timeout');
      });
    } catch (e) {
      debugPrint('promo validate failed: $e');
      if (!mounted) return;
      setState(() {
        _isCheckingPromo = false;
        _promoError = S.of(context).t('promo_check_failed');
      });
    }
  }

  String _friendlyPromoError(String? raw) {
    final t = S.of(context);
    if (raw == null || raw.isEmpty) {
      return t.t('promo_invalid');
    }
    final m = raw.toLowerCase();
    if (m.contains('expired')) return t.t('promo_expired');
    if (m.contains('not found') || m.contains('invalid')) {
      return t.t('promo_not_found');
    }
    if (m.contains('minimum') || m.contains('min')) {
      return t.t('promo_min_fare');
    }
    if (m.contains('used') || m.contains('redeemed')) {
      return t.t('promo_already_used');
    }
    return t.t('promo_invalid');
  }

  void _clearPromo() {
    setState(() {
      _promoResult = null;
      _promoError = null;
      _promoCtrl.clear();
    });
  }

  // ═══════════════════════════════════════════════════════════
  // SUBMIT
  // ═══════════════════════════════════════════════════════════
  String _generateOtp() {
    final rnd = Random.secure();
    final n = rnd.nextInt(900000) + 100000;
    return n.toString();
  }

  // ── When: now or later ───────────────────────────────────
  Future<void> _pickScheduleTime() async {
    final now = DateTime.now();
    final first = now.add(const Duration(minutes: 20));
    final date = await showDatePicker(
      context: context,
      initialDate: _scheduledAt ?? first,
      firstDate: DateTime(first.year, first.month, first.day),
      lastDate: now.add(const Duration(days: 30)),
    );
    if (date == null || !mounted) return;
    final time = await showTimePicker(
      context: context,
      initialTime: TimeOfDay.fromDateTime(_scheduledAt ?? first),
    );
    if (time == null || !mounted) return;
    final picked =
        DateTime(date.year, date.month, date.day, time.hour, time.minute);
    if (picked.isBefore(now.add(const Duration(minutes: 15)))) {
      ErrorUI.showSnack(
        context,
        AppError(
          title: tr('Pick a later time'),
          message: tr('Book at least 20 minutes ahead, or choose Now.'),
          icon: Icons.schedule,
        ),
      );
      return;
    }
    setState(() => _scheduledAt = picked);
  }

  Widget _whenSection() {
    final later = _scheduledAt != null;
    Widget chip(String label, IconData icon, bool on, VoidCallback onTap) {
      return Expanded(
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(12),
          child: Container(
            padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 12),
            decoration: BoxDecoration(
              color: on ? EfuridePalette.accent.withOpacity(0.14) : Colors.white,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: on ? EfuridePalette.accent : const Color(0xFFE8E2D5),
                width: on ? 1.6 : 1,
              ),
            ),
            child: Row(
              children: [
                Icon(icon, size: 18, color: EfuridePalette.ink),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    label,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      fontSize: 13.5,
                      fontWeight: on ? FontWeight.w700 : FontWeight.w500,
                      color: EfuridePalette.ink,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(tr('When'),
            style: const TextStyle(
                fontSize: 15,
                fontWeight: FontWeight.w700,
                color: EfuridePalette.ink)),
        const SizedBox(height: 10),
        Row(
          children: [
            chip(tr('Now'), Icons.bolt, !later,
                () => setState(() => _scheduledAt = null)),
            const SizedBox(width: 10),
            chip(
              later ? _fmtWhen(_scheduledAt!) : tr('Later'),
              Icons.event,
              later,
              _pickScheduleTime,
            ),
          ],
        ),
        if (later) ...[
          const SizedBox(height: 8),
          Text(
            tr('We\'ll start finding a driver 10 minutes before. You can cancel any time before then.'),
            style: const TextStyle(fontSize: 12.5, color: EfuridePalette.inkMuted),
          ),
        ],
      ],
    );
  }

  String _fmtWhen(DateTime d) {
    final now = DateTime.now();
    final tomorrow = DateTime(now.year, now.month, now.day + 1);
    final hm = '${d.hour.toString().padLeft(2, '0')}:${d.minute.toString().padLeft(2, '0')}';
    if (d.year == now.year && d.month == now.month && d.day == now.day) {
      return tr('Today {0}', [hm]);
    }
    if (d.year == tomorrow.year && d.month == tomorrow.month && d.day == tomorrow.day) {
      return tr('Tomorrow {0}', [hm]);
    }
    return '${d.day}/${d.month} $hm';
  }

  Future<void> _submitBooking() async {
    if (_isSubmitting) return;
    if (!await ConnectionService.instance.ensureOnline(context)) return;
    final t = S.of(context);
    final scheduledAt = _scheduledAt;
    if (scheduledAt != null &&
        scheduledAt.isBefore(DateTime.now().add(const Duration(minutes: 15)))) {
      ErrorUI.showSnack(
        context,
        AppError(
          title: tr('Pick a later time'),
          message: tr('Book at least 20 minutes ahead, or choose Now.'),
          icon: Icons.schedule,
        ),
      );
      return;
    }

    if (widget.serviceType == 'Delivery') {
      if (_recipientNameController.text.trim().isEmpty ||
          _recipientPhoneController.text.trim().isEmpty) {
        setState(() => _openSection = _AddOn.note);
        ErrorUI.showSnack(
          context,
          AppError(
            title: t.t('recipient_missing'),
            message: t.t('recipient_missing_hint'),
            icon: Icons.person_off_outlined,
          ),
        );
        return;
      }
    }

    if (_pickedPay == 'wallet' && _payMethod != 'wallet') {
      ErrorUI.showSnack(
        context,
        AppError(
          title: tr('Not enough in your wallet'),
          message: tr('Top up your wallet or choose cash.'),
          icon: Icons.account_balance_wallet_outlined,
        ),
      );
      return;
    }

    setState(() => _isSubmitting = true);

    try {
      final userId = Supabase.instance.client.auth.currentUser?.id;
      if (userId == null) {
        setState(() => _isSubmitting = false);
        return;
      }

      final note = _noteController.text.trim();
      final otp = _generateOtp();
      final baseFare = _effectiveBaseFare;
      final discount =
          _promoResult?.valid == true ? _promoResult!.discountAmount : 0.0;
      final finalFare = _finalFare;

      final pricingMode = _isBidding ? 'negotiated' : 'algorithmic';
      final dispatchMode = _isBidding ? 'inform' : 'assign';
      final negotiationState = _isBidding ? 'open' : 'none';

      final payload = <String, dynamic>{
        'customer_id': userId,
        'service_type': widget.serviceType,
        'vehicle_type': widget.vehicle,
        'pickup_address': widget.pickup,
        'dropoff_address': widget.dropoff,
        'pickup_lat': widget.pickupLatLng.latitude,
        'pickup_lng': widget.pickupLatLng.longitude,
        'dropoff_lat': widget.dropoffLatLng.latitude,
        'dropoff_lng': widget.dropoffLatLng.longitude,
        'status': scheduledAt != null ? 'scheduled' : 'pending',
        if (scheduledAt != null)
          'scheduled_at': scheduledAt.toUtc().toIso8601String(),
        'fare': finalFare,
        'original_fare': widget.fare,
        'customer_bid': _isBidding ? _customerBid : null,
        'is_bidding': _isBidding,
        'bid_status': _isBidding ? 'pending' : 'none',
        'pricing_mode': pricingMode,
        'dispatch_mode': dispatchMode,
        'negotiation_state': negotiationState,
        'surge_multiplier': 1.0,
        'distance_km': widget.distance,
        'eta_minutes': widget.etaMinutes,
        'customer_note': note.isEmpty ? null : note,
        'payment_method': _payMethod,
        'payment_status': 'pending',
        'pickup_otp': otp,
        'pickup_otp_verified': false,
        if (_promoResult?.valid == true) ...{
          'promo_code': _promoResult!.promo?['code'],
          'promo_id': _promoResult!.promo?['id'],
          'discount_amount': discount,
          'fare_after_discount': finalFare,
        },
        if (widget.serviceType == 'Delivery') ...{
          'recipient_name': _recipientNameController.text.trim(),
          'recipient_phone': _recipientPhoneController.text.trim(),
        },
      };

      final response = await Supabase.instance.client
          .from('rides')
          .insert(payload)
          .select()
          .single()
          .timeout(const Duration(seconds: 20));

      if (response['pickup_otp'] == null) {
        try {
          await Supabase.instance.client
              .from('rides')
              .update({'pickup_otp': otp, 'pickup_otp_verified': false})
              .eq('id', response['id'])
              .timeout(const Duration(seconds: 10));
        } catch (e) {
          debugPrint('follow-up OTP write failed: $e');
        }
      }

      if (widget.serviceType == 'Delivery' && _packagePhoto != null) {
        try {
          final photoUrl = await StorageService.instance.uploadPackagePhoto(
           _packagePhoto!,
            response['id'].toString(),
          );
          if (photoUrl != null) {
            await Supabase.instance.client
                .from('rides')
                .update({'package_photo_url': photoUrl})
                .eq('id', response['id'])
                .timeout(const Duration(seconds: 10));
          }
        } catch (e) {
          debugPrint('package photo upload failed: $e');
        }
      }

      if (_promoResult?.valid == true && _promoResult!.promo != null) {
        final promoId = _promoResult!.promo!['id'];
        if (promoId is int) {
          try {
            await PromoService.recordRedemption(
              promoId: promoId,
              rideId: response['id'].toString(),
              discountApplied: discount,
            ).timeout(const Duration(seconds: 10));
          } catch (e) {
            debugPrint('promo redemption failed: $e');
            try {
              await Supabase.instance.client
                  .from('rides')
                  .update({
                    'status': 'cancelled',
                    'cancellation_reason': 'promo_redemption_failed',
                    'cancelled_by': 'system',
                    'cancelled_at':
                        DateTime.now().toUtc().toIso8601String(),
                  })
                  .eq('id', response['id'])
                  .timeout(const Duration(seconds: 10));
            } catch (rollbackErr) {
              debugPrint('rollback failed: $rollbackErr');
            }
            if (!mounted) return;
            setState(() => _isSubmitting = false);
            await ErrorUI.showErrorDialog(
              context,
              AppError(
                title: t.t('promo_apply_failed'),
                message: t.t('promo_apply_failed_hint'),
                icon: Icons.local_offer_outlined,
                onRetry: _submitBooking,
              ),
            );
            return;
          }
        }
      }

      if (!mounted) return;
      if (scheduledAt != null) {
        Navigator.pop(context, {
          'scheduled': true,
          'ride_id': response['id'],
          'scheduled_at': scheduledAt.toUtc().toIso8601String(),
        });
        return;
      }
      Navigator.pop(context, {
        'ride_id': response['id'],
        'fare': finalFare,
        'is_bidding': _isBidding,
        'distance_km': widget.distance,
        'eta_minutes': widget.etaMinutes,
        'pickup_otp': otp,
        'discount_amount': discount,
        'pricing_mode': pricingMode,
        'dispatch_mode': dispatchMode,
      });
    } on TimeoutException {
      if (!mounted) return;
      setState(() => _isSubmitting = false);
      await ErrorUI.showErrorDialog(
        context,
        AppError(
          title: t.t('request_timeout'),
          message: t.t('request_timeout_hint'),
          icon: Icons.access_time,
          onRetry: _submitBooking,
        ),
      );
    } catch (e) {
      if (!mounted) return;
      setState(() => _isSubmitting = false);
      await ErrorUI.showErrorDialog(
        context,
        AppError.from(e, onRetry: _submitBooking),
      );
    }
  }

  // ═══════════════════════════════════════════════════════════
  // BUILD
  // ═══════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    final t = S.of(context);
    final isDelivery = widget.serviceType == 'Delivery';

    return Scaffold(
      backgroundColor: EfuridePalette.cream,
      appBar: AppBar(
        backgroundColor: EfuridePalette.cream,
        elevation: 0,
        scrolledUnderElevation: 0,
        foregroundColor: EfuridePalette.ink,
        title: Text(
          isDelivery ? t.t('review_delivery') : t.t('review_ride'),
          style: const TextStyle(
              color: EfuridePalette.ink,
              fontWeight: FontWeight.w700,
              fontSize: 17),
        ),
      ),
      body: Column(
        children: [
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.fromLTRB(20, 8, 20, 24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  _tripSummaryCard(isDelivery),
                  const SizedBox(height: 20),
                  if (isDelivery) ...[
                    _deliveryDetailsCard(),
                    const SizedBox(height: 16),
                  ],
                  _addOnsSection(),
                  const SizedBox(height: 20),
                  _whenSection(),
                  const SizedBox(height: 20),
                  PaymentChoice(
                    value: _payMethod,
                    onChanged: (v) => setState(() => _pickedPay = v),
                    amountDue: _finalFare,
                    walletBalance:
                        context.watch<AuthProvider>().walletBalance,
                    cashHint: isDelivery
                        ? tr('Pay the courier')
                        : tr('Pay the driver at the end of the trip'),
                  ),
                  if (!isDelivery) ...[
                    const SizedBox(height: 16),
                    SplitFareCard(total: _finalFare),
                  ],
                  const SizedBox(height: 24),
                  _totalsBlock(),
                ],
              ),
            ),
          ),
          _stickyCheckoutBar(isDelivery),
        ],
      ),
    );
  }

  // ── Trip summary ─────────────────────────────────────────
  Widget _tripSummaryCard(bool isDelivery) {
    final t = S.of(context);
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: EfuridePalette.divider),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  color: EfuridePalette.accent.withValues(alpha: 0.14),
                  borderRadius: BorderRadius.circular(12),
                ),
                padding: const EdgeInsets.all(4),
                child: Image.asset(
                  isDelivery
                      ? 'assets/images/parcel.png'
                      : 'assets/images/ride.png',
                  fit: BoxFit.contain,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  widget.vehicle,
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w700,
                    color: EfuridePalette.ink,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 18),
          _routeLine(Icons.trip_origin, EfuridePalette.pickup, t.t('pickup'),
              widget.pickup),
          Padding(
            padding: const EdgeInsets.only(left: 7, top: 4, bottom: 4),
            child: Container(width: 2, height: 16, color: EfuridePalette.divider),
          ),
          _routeLine(Icons.place, EfuridePalette.dropoff, t.t('dropoff'),
              widget.dropoff),
          const SizedBox(height: 16),
          const Divider(height: 1, color: EfuridePalette.divider),
          const SizedBox(height: 12),
          Row(
            children: [
              const Icon(Icons.straighten,
                  size: 14, color: EfuridePalette.inkMuted),
              const SizedBox(width: 4),
              Text(tr('{0} km', [widget.distance.toStringAsFixed(1)]),
                  style: const TextStyle(
                      fontSize: 13.5, color: EfuridePalette.inkMuted)),
              if (widget.etaMinutes != null) ...[
                const SizedBox(width: 14),
                const KIcon(Icons.schedule,
                    size: 14, color: EfuridePalette.inkMuted),
                const SizedBox(width: 4),
                Text('~${widget.etaMinutes} ${t.t('min')}',
                    style: const TextStyle(
                        fontSize: 13.5, color: EfuridePalette.inkMuted)),
              ],
            ],
          ),
        ],
      ),
    );
  }

  Widget _routeLine(IconData icon, Color color, String label, String value) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(top: 2),
          child: Icon(icon, color: color, size: 16),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(label,
                  style: const TextStyle(
                      fontSize: 13,
                      color: EfuridePalette.inkMuted,
                      fontWeight: FontWeight.w500)),
              const SizedBox(height: 2),
              Text(value,
                  style: const TextStyle(
                      fontSize: 14.5,
                      fontWeight: FontWeight.w600,
                      color: EfuridePalette.ink),
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis),
            ],
          ),
        ),
      ],
    );
  }

  // ── Delivery details ─────────────────────────────────────
  Widget _deliveryDetailsCard() {
    final t = S.of(context);
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: EfuridePalette.divider),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              const Icon(Icons.person_pin_outlined,
                  color: EfuridePalette.ink, size: 20),
              const SizedBox(width: 10),
              Text(t.t('recipient_details'),
                  style: const TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w700,
                      color: EfuridePalette.ink)),
            ],
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _recipientNameController,
            decoration: InputDecoration(
              labelText: t.t('full_name'),
              filled: true,
              fillColor: EfuridePalette.greyBg,
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide.none,
              ),
            ),
          ),
          const SizedBox(height: 10),
          TextField(
            controller: _recipientPhoneController,
            keyboardType: TextInputType.phone,
            decoration: InputDecoration(
              labelText: t.t('phone_number'),
              filled: true,
              fillColor: EfuridePalette.greyBg,
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide.none,
              ),
            ),
          ),
          const SizedBox(height: 16),
          Text(t.t('package_photo'),
              style: const TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                  color: EfuridePalette.ink)),
          const SizedBox(height: 8),
          if (_packagePhoto == null)
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () => _pickPackagePhoto(fromCamera: true),
                    icon: const KIcon(Icons.camera_alt_outlined, size: 18),
                    label: Text(t.t('camera')),
                    style: OutlinedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(vertical: 12),
                      side: const BorderSide(color: EfuridePalette.divider),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12)),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () => _pickPackagePhoto(fromCamera: false),
                    icon: const KIcon(Icons.photo_library_outlined, size: 18),
                    label: Text(t.t('gallery')),
                    style: OutlinedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(vertical: 12),
                      side: const BorderSide(color: EfuridePalette.divider),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12)),
                    ),
                  ),
                ),
              ],
            )
          else
            Stack(
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(12),
                  child: Image.file(
                    File(_packagePhoto!.path),
                    height: 150,
                    width: double.infinity,
                    fit: BoxFit.cover,
                    errorBuilder: (_, __, ___) => Container(
                      height: 150,
                      color: EfuridePalette.greyBg,
                      child: Center(child: Text(tr('Photo selected'))),
                    ),
                  ),
                ),
                Positioned(
                  top: 8,
                  right: 8,
                  child: CircleAvatar(
                    backgroundColor: Colors.white,
                    child: IconButton(
                      icon: const Icon(Icons.close,
                          color: EfuridePalette.dropoff, size: 18),
                      onPressed: () =>
                          setState(() => _packagePhoto = null),
                    ),
                  ),
                ),
              ],
            ),
        ],
      ),
    );
  }

  // ── Add-ons ──────────────────────────────────────────────
  Widget _addOnsSection() {
    final t = S.of(context);
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: EfuridePalette.divider),
      ),
      child: Column(
        children: [
          _addOnRow(
            section: _AddOn.promo,
            icon: Icons.local_offer_outlined,
            title: t.t('promo_code'),
            value: _promoResult?.valid == true
                ? '− ${CountryConfig.money(_promoResult!.discountAmount)}'
                : null,
            valueColor: EfuridePalette.online,
            expandedChild: _promoBody(),
          ),
          _divider(),
          _addOnRow(
            section: _AddOn.note,
            icon: Icons.sticky_note_2_outlined,
            title: t.t('note_for_driver'),
            value: _noteController.text.trim().isEmpty
                ? null
                : t.t('added'),
            expandedChild: _noteBody(),
          ),
          _divider(),
          _addOnRow(
            section: _AddOn.bidding,
            icon: Icons.gavel_rounded,
            title: t.t('offer_your_price'),
            value: _isBidding
                ? CountryConfig.money(_customerBid)
                : null,
            valueColor: EfuridePalette.accent,
            expandedChild: _biddingBody(),
          ),
        ],
      ),
    );
  }

  Widget _divider() =>
      const Divider(height: 1, indent: 50, color: EfuridePalette.divider);

  Widget _addOnRow({
    required _AddOn section,
    required IconData icon,
    required String title,
    required Widget expandedChild,
    String? value,
    Color? valueColor,
  }) {
    final isOpen = _openSection == section;
    return Column(
      children: [
        InkWell(
          onTap: () => _toggleSection(section),
          child: Padding(
            padding:
                const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
            child: Row(
              children: [
                Icon(icon, size: 20, color: EfuridePalette.inkMuted),
                const SizedBox(width: 14),
                Expanded(
                  child: Text(title,
                      style: const TextStyle(
                          fontSize: 14.5,
                          fontWeight: FontWeight.w600,
                          color: EfuridePalette.ink)),
                ),
                if (value != null)
                  Padding(
                    padding: const EdgeInsets.only(right: 8),
                    child: Text(value,
                        style: TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w700,
                            color: valueColor ?? EfuridePalette.ink)),
                  ),
                AnimatedRotation(
                  turns: isOpen ? 0.5 : 0,
                  duration: const Duration(milliseconds: 180),
                  child: const Icon(Icons.keyboard_arrow_down,
                      size: 20, color: EfuridePalette.inkMuted),
                ),
              ],
            ),
          ),
        ),
        AnimatedSize(
          duration: const Duration(milliseconds: 220),
          curve: Curves.easeOutCubic,
          alignment: Alignment.topCenter,
          child: isOpen
              ? Padding(
                  padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                  child: expandedChild,
                )
              : const SizedBox(width: double.infinity),
        ),
      ],
    );
  }

  Widget _promoBody() {
    final t = S.of(context);
    if (_promoResult?.valid == true) {
      return Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: EfuridePalette.online.withValues(alpha: 0.10),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Row(
          children: [
            const Icon(Icons.check_circle,
                color: EfuridePalette.online, size: 20),
            const SizedBox(width: 10),
            Expanded(
              child: Text(
                '${_promoResult!.promo?['code']} ${t.t('promo_applied')} ${CountryConfig.money(_promoResult!.discountAmount)}',
                style: const TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                    color: EfuridePalette.online),
              ),
            ),
            TextButton(
              onPressed: _clearPromo,
              style: TextButton.styleFrom(
                minimumSize: const Size(0, 32),
                padding: const EdgeInsets.symmetric(horizontal: 8),
              ),
              child: Text(t.t('remove'),
                  style: const TextStyle(color: EfuridePalette.inkMuted)),
            ),
          ],
        ),
      );
    }
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Row(
          children: [
            Expanded(
              child: TextField(
                controller: _promoCtrl,
                textCapitalization: TextCapitalization.characters,
                decoration: InputDecoration(
                  hintText: t.t('enter_code'),
                  filled: true,
                  fillColor: EfuridePalette.greyBg,
                  contentPadding: const EdgeInsets.symmetric(
                      horizontal: 14, vertical: 12),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: BorderSide.none,
                  ),
                ),
              ),
            ),
            const SizedBox(width: 8),
            ElevatedButton(
              onPressed: _isCheckingPromo ? null : _applyPromo,
              style: ElevatedButton.styleFrom(
                backgroundColor: EfuridePalette.accent,
                foregroundColor: EfuridePalette.accentInk,
                padding: const EdgeInsets.symmetric(
                    horizontal: 18, vertical: 14),
                elevation: 0,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12)),
              ),
              child: _isCheckingPromo
                  ? const SizedBox(
                      width: 16,
                      height: 16,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                  : Text(t.t('apply'),
                      style: const TextStyle(fontWeight: FontWeight.w700)),
            ),
          ],
        ),
        if (_promoError != null) ...[
          const SizedBox(height: 8),
          Row(
            children: [
              const Icon(Icons.error_outline,
                  color: EfuridePalette.dropoff, size: 14),
              const SizedBox(width: 6),
              Expanded(
                child: Text(_promoError!,
                    style: const TextStyle(
                        color: EfuridePalette.dropoff, fontSize: 13.5)),
              ),
            ],
          ),
        ],
      ],
    );
  }

  Widget _noteBody() {
    final t = S.of(context);
    return TextField(
      controller: _noteController,
      maxLines: 3,
      maxLength: 200,
      onChanged: (_) => setState(() {}),
      decoration: InputDecoration(
        hintText: t.t('note_hint'),
        filled: true,
        fillColor: EfuridePalette.greyBg,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide.none,
        ),
      ),
    );
  }

  Widget _biddingBody() {
    final t = S.of(context);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Text(
          '${t.t('bidding_range_a')} ${CountryConfig.money(_sliderMin)} ${t.t('and')} ${CountryConfig.money(_sliderMax)} ${t.t('bidding_range_b')}',
          style: const TextStyle(fontSize: 13.5, color: EfuridePalette.inkMuted),
        ),
        const SizedBox(height: 12),
        SliderTheme(
          data: SliderTheme.of(context).copyWith(
            trackHeight: 6,
            activeTrackColor: EfuridePalette.accent,
            inactiveTrackColor: EfuridePalette.divider,
            thumbColor: EfuridePalette.accent,
            overlayColor: EfuridePalette.accent.withValues(alpha: 0.15),
            thumbShape: const RoundSliderThumbShape(
                enabledThumbRadius: 12),
          ),
          child: Slider(
            value: _customerBid.clamp(_sliderMin, _sliderMax),
            min: _sliderMin,
            max: _sliderMax,
            onChanged: (v) => setState(() => _customerBid = v),
          ),
        ),
        Center(
          child: Text(
            CountryConfig.money(_customerBid),
            style: const TextStyle(
                fontSize: 26,
                fontWeight: FontWeight.w800,
                color: EfuridePalette.ink),
          ),
        ),
      ],
    );
  }

  // ── Totals ───────────────────────────────────────────────
  Widget _totalsBlock() {
    final t = S.of(context);
    final baseFare = _effectiveBaseFare;
    return Column(
      children: [
        _totalRow(t.t('fare'), CountryConfig.money(baseFare)),
        if (_promoResult?.valid == true) ...[
          const SizedBox(height: 6),
          _totalRow(
            '${t.t('discount')} · ${_promoResult!.promo?['code']}',
            '− ${CountryConfig.money(_promoResult!.discountAmount)}',
            color: EfuridePalette.online,
          ),
        ],
      ],
    );
  }

  Widget _totalRow(String label, String value, {Color? color}) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(label,
            style: const TextStyle(
                fontSize: 14, color: EfuridePalette.inkMuted)),
        Text(value,
            style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w600,
                color: color ?? EfuridePalette.ink)),
      ],
    );
  }

  // ── Sticky bar ───────────────────────────────────────────
  Widget _stickyCheckoutBar(bool isDelivery) {
    final t = S.of(context);
    return Container(
      padding: EdgeInsets.fromLTRB(
        20, 12, 20, 12 + MediaQuery.of(context).padding.bottom,
      ),
      decoration: BoxDecoration(
        color: Colors.white,
        border: const Border(top: BorderSide(color: EfuridePalette.divider)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.04),
            blurRadius: 12,
            offset: const Offset(0, -4),
          ),
        ],
      ),
      child: Row(
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(t.t('you_pay'),
                  style: const TextStyle(
                      fontSize: 13.5, color: EfuridePalette.inkMuted)),
              AnimatedSwitcher(
                duration: const Duration(milliseconds: 180),
                child: Text(
                  CountryConfig.money(_finalFare),
                  key: ValueKey(_finalFare.toStringAsFixed(2)),
                  style: const TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.w800,
                    color: EfuridePalette.ink,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(width: 16),
          Expanded(
            child: ElevatedButton.icon(
              onPressed: _isSubmitting ? null : _submitBooking,
              style: ElevatedButton.styleFrom(
                backgroundColor: EfuridePalette.accent,
                foregroundColor: EfuridePalette.accentInk,
                padding: const EdgeInsets.symmetric(vertical: 16),
                minimumSize: const Size(double.infinity, 54),
                elevation: 0,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14)),
              ),
              icon: _isSubmitting
                  ? const SizedBox(
                      width: 18,
                      height: 18,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                  : Icon(_isBidding
                      ? Icons.gavel_rounded
                      : Icons.arrow_forward,
                      size: 18),
              label: Text(
                _scheduledAt != null
                    ? tr('Book for later')
                    : _isBidding
                    ? t.t('send_bid')
                    : (isDelivery ? t.t('request_delivery') : t.t('request_ride')),
                style: const TextStyle(
                    fontSize: 15, fontWeight: FontWeight.w700),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
