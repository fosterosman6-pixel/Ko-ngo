// lib/screens/customer/substitution_approval_screen.dart

import 'dart:async';
import 'package:flutter/material.dart';
import 'package:efuride_app/config/efuride_palette.dart';

class SubstitutionApprovalScreen extends StatefulWidget {
  final String orderId;
  final String originalItem;
  final String originalQty;
  final double originalPrice;
  final String proposedItem;
  final double proposedPrice;
  final String shopperName;

  const SubstitutionApprovalScreen({
    super.key,
    required this.orderId,
    required this.originalItem,
    required this.originalQty,
    required this.originalPrice,
    required this.proposedItem,
    required this.proposedPrice,
    required this.shopperName,
  });

  @override
  State<SubstitutionApprovalScreen> createState() =>
      _SubstitutionApprovalScreenState();
}

class _SubstitutionApprovalScreenState
    extends State<SubstitutionApprovalScreen> {
  Timer? _timer;
  int _secondsLeft = 120;

  @override
  void initState() {
    super.initState();
    _timer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (!mounted) return;
      if (_secondsLeft <= 1) {
        t.cancel();
        _onTimeout();
        return;
      }
      setState(() => _secondsLeft--);
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  double get _priceDiff => widget.proposedPrice - widget.originalPrice;
  bool get _isCheaper => _priceDiff < 0;

  String _fmt(int s) {
    final m = s ~/ 60;
    final sec = s % 60;
    return '$m:${sec.toString().padLeft(2, '0')}';
  }

  void _approve() {
    _timer?.cancel();
    Navigator.pop(context, {
      'action': 'approve',
      'order_id': widget.orderId,
      'proposed_price': widget.proposedPrice,
    });
  }

  void _reject() {
    _timer?.cancel();
    Navigator.pop(context, {
      'action': 'reject',
      'order_id': widget.orderId,
    });
  }

  void _onTimeout() {
    if (!mounted) return;
    Navigator.pop(context, {
      'action': 'timeout',
      'order_id': widget.orderId,
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: EfuridePalette.cream,
      body: Column(
        children: [
          _header(),
          Expanded(
            child: ListView(
              padding: const EdgeInsets.all(20),
              children: [
                _alertBanner(),
                const SizedBox(height: 20),
                _comparisonCard(),
                const SizedBox(height: 16),
                _priceImpactCard(),
                const SizedBox(height: 20),
                _instructionCard(),
                const SizedBox(height: 24),
              ],
            ),
          ),
          _bottomBar(),
        ],
      ),
    );
  }

  // ── Header ──
  Widget _header() {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          colors: [EfuridePalette.blue, EfuridePalette.blueDeep],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
      ),
      child: SafeArea(
        bottom: false,
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 14),
              child: Row(
                children: [
                  Container(
                    width: 40,
                    height: 40,
                    decoration: BoxDecoration(
                      color: Colors.white.withValues(alpha: 0.15),
                      shape: BoxShape.circle,
                    ),
                    child: const Center(
                      child: Icon(Icons.swap_horiz,
                          color: Colors.white, size: 22),
                    ),
                  ),
                  const SizedBox(width: 12),
                  const Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('EFURIDE',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 16,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 1.2,
                            height: 1.05,
                          )),
                      SizedBox(height: 2),
                      Text('Substitution request',
                          style: TextStyle(
                            color: Colors.white70,
                            fontSize: 11.5,
                            fontWeight: FontWeight.w500,
                          )),
                    ],
                  ),
                  const Spacer(),
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 10, vertical: 5),
                    decoration: BoxDecoration(
                      color: _secondsLeft <= 30
                          ? EfuridePalette.dropoff
                          : Colors.white.withValues(alpha: 0.20),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Icon(Icons.timer_outlined,
                            color: Colors.white, size: 12),
                        const SizedBox(width: 4),
                        Text(_fmt(_secondsLeft),
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 12,
                              fontWeight: FontWeight.w900,
                              fontFeatures: [
                                FontFeature.tabularFigures(),
                              ],
                            )),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.fromLTRB(16, 14, 16, 18),
              decoration: const BoxDecoration(
                color: EfuridePalette.navy,
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(24),
                  topRight: Radius.circular(24),
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Item unavailable',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 20,
                        fontWeight: FontWeight.w900,
                        letterSpacing: -0.3,
                      )),
                  const SizedBox(height: 4),
                  Text('${widget.shopperName} has a suggestion',
                      style: const TextStyle(
                          color: Colors.white70, fontSize: 13)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ── Alert banner ──
  Widget _alertBanner() {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: EfuridePalette.shopperAccent.withValues(alpha: 0.10),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
            color:
                EfuridePalette.shopperAccent.withValues(alpha: 0.40)),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: EfuridePalette.shopperAccent,
              borderRadius: BorderRadius.circular(8),
            ),
            child: const Icon(Icons.info_outline,
                color: Colors.white, size: 18),
          ),
          const SizedBox(width: 12),
          const Expanded(
            child: Text(
              'We couldn\'t find exactly what you ordered. '
              'Your shopper found a close match.',
              style: TextStyle(
                fontSize: 12.5,
                height: 1.45,
                color: EfuridePalette.ink,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ── Comparison card ──
  Widget _comparisonCard() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: EfuridePalette.divider),
      ),
      child: Column(
        children: [
          _compareRow(
            label: 'YOU ORDERED',
            item: widget.originalItem,
            qty: widget.originalQty,
            price: widget.originalPrice,
            emoji: '❌',
            isOriginal: true,
          ),
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 12),
            child: Row(
              children: [
                const Expanded(
                    child:
                        Divider(color: EfuridePalette.divider)),
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: EfuridePalette.shopperAccent
                        .withValues(alpha: 0.15),
                    shape: BoxShape.circle,
                  ),
                  child: const Icon(Icons.arrow_downward,
                      size: 18,
                      color: EfuridePalette.shopperAccent),
                ),
                const Expanded(
                    child:
                        Divider(color: EfuridePalette.divider)),
              ],
            ),
          ),
          _compareRow(
            label: 'SHOPPER SUGGESTS',
            item: widget.proposedItem,
            qty: widget.originalQty,
            price: widget.proposedPrice,
            emoji: '✅',
            isOriginal: false,
          ),
        ],
      ),
    );
  }

  Widget _compareRow({
    required String label,
    required String item,
    required String qty,
    required double price,
    required String emoji,
    required bool isOriginal,
  }) {
    return Row(
      children: [
        Container(
          width: 54,
          height: 54,
          decoration: BoxDecoration(
            color: isOriginal
                ? EfuridePalette.cream
                : EfuridePalette.shopperAccent.withValues(alpha: 0.12),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Center(
            child: Text(emoji, style: const TextStyle(fontSize: 26)),
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(label,
                  style: TextStyle(
                    fontSize: 10,
                    letterSpacing: 0.8,
                    fontWeight: FontWeight.w900,
                    color: isOriginal
                        ? EfuridePalette.inkMuted
                        : EfuridePalette.shopperAccent,
                  )),
              const SizedBox(height: 3),
              Text(item,
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w800,
                    color: isOriginal
                        ? EfuridePalette.inkMuted
                        : EfuridePalette.ink,
                    decoration: isOriginal
                        ? TextDecoration.lineThrough
                        : null,
                    decorationColor: EfuridePalette.inkMuted,
                  )),
              const SizedBox(height: 2),
              Text(qty,
                  style: const TextStyle(
                      fontSize: 11.5,
                      color: EfuridePalette.inkMuted)),
            ],
          ),
        ),
        Column(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Text('${price.toStringAsFixed(0)}',
                style: TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.w900,
                  color: isOriginal
                      ? EfuridePalette.inkMuted
                      : EfuridePalette.shopperAccent,
                )),
            const Text('XAF',
                style: TextStyle(
                    fontSize: 10, color: EfuridePalette.inkMuted)),
          ],
        ),
      ],
    );
  }

  // ── Price impact ──
  Widget _priceImpactCard() {
    final color = _isCheaper
        ? EfuridePalette.online
        : _priceDiff == 0
            ? EfuridePalette.inkMuted
            : EfuridePalette.merchantAccent;

    final label = _isCheaper
        ? 'You save ${_priceDiff.abs().toStringAsFixed(0)} XAF'
        : _priceDiff == 0
            ? 'Same price as original'
            : 'You pay ${_priceDiff.toStringAsFixed(0)} XAF more';

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.08),
        borderRadius: BorderRadius.circular(14),
        border:
            Border.all(color: color.withValues(alpha: 0.35), width: 1.4),
      ),
      child: Row(
        children: [
          Icon(
            _isCheaper
                ? Icons.trending_down
                : _priceDiff == 0
                    ? Icons.horizontal_rule
                    : Icons.trending_up,
            color: color,
            size: 24,
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Price impact',
                    style: TextStyle(
                      fontSize: 11,
                      fontWeight: FontWeight.w700,
                      letterSpacing: 0.6,
                      color: color,
                    )),
                const SizedBox(height: 2),
                Text(label,
                    style: TextStyle(
                      fontSize: 14.5,
                      fontWeight: FontWeight.w900,
                      color: color,
                    )),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ── Instruction ──
  Widget _instructionCard() {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: EfuridePalette.cream,
        borderRadius: BorderRadius.circular(12),
      ),
      child: const Row(
        children: [
          Icon(Icons.hourglass_empty,
              size: 16, color: EfuridePalette.inkMuted),
          SizedBox(width: 10),
          Expanded(
            child: Text(
              'If you don\'t respond within 2 minutes, this item '
              'will be skipped and you won\'t be charged for it.',
              style: TextStyle(
                fontSize: 11.5,
                color: EfuridePalette.inkMuted,
                height: 1.45,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ── Bottom bar ──
  Widget _bottomBar() {
    return Container(
      padding: EdgeInsets.fromLTRB(
        16,
        12,
        16,
        12 + MediaQuery.of(context).padding.bottom,
      ),
      decoration: BoxDecoration(
        color: Colors.white,
        border:
            const Border(top: BorderSide(color: EfuridePalette.divider)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.05),
            blurRadius: 10,
            offset: const Offset(0, -3),
          ),
        ],
      ),
      child: Row(
        children: [
          Expanded(
            child: OutlinedButton(
              onPressed: _reject,
              style: OutlinedButton.styleFrom(
                minimumSize: const Size(0, 54),
                side: const BorderSide(
                    color: EfuridePalette.dropoff, width: 1.5),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14)),
                foregroundColor: EfuridePalette.dropoff,
              ),
              child: const Text('Skip item',
                  style: TextStyle(
                      fontSize: 15, fontWeight: FontWeight.w900)),
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            flex: 2,
            child: ElevatedButton.icon(
              onPressed: _approve,
              icon: const Icon(Icons.check_circle, size: 20),
              label: const Text('Approve swap',
                  style: TextStyle(
                      fontSize: 15, fontWeight: FontWeight.w900)),
              style: ElevatedButton.styleFrom(
                backgroundColor: EfuridePalette.shopperAccent,
                foregroundColor: Colors.white,
                minimumSize: const Size(0, 54),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14)),
                elevation: 0,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
