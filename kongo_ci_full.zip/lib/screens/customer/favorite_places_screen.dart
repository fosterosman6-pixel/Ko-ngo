﻿// lib/screens/customer/favorite_places_screen.dart

import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:efuride_app/config/app_images.dart';
import 'package:efuride_app/widgets/app_image.dart';
import 'package:efuride_app/utils/app_error.dart';
import 'package:efuride_app/utils/error_ui.dart';
import 'package:efuride_app/l10n/app_strings.dart';
import 'package:efuride_app/services/favorite_places_service.dart';
import 'package:efuride_app/widgets/place_picker_sheet.dart';

class _Palette {
  static const cream = Color(0xFFFAF6EE);
  static const ink = Color(0xFF1A1A1A);
  static const inkMuted = Color(0xFF575047);
  static const accent = Color(0xFFF2B705);
  static const divider = Color(0xFFE8E2D5);
  static const blue = Color(0xFF1E88E5);
}

class FavoritePlacesScreen extends StatefulWidget {
  const FavoritePlacesScreen({super.key});

  @override
  State<FavoritePlacesScreen> createState() => _FavoritePlacesScreenState();
}

class _FavoritePlacesScreenState extends State<FavoritePlacesScreen> {
  List<Map<String, dynamic>> _favorites = [];
  bool _isLoading = true;
  AppError? _error;

  @override
  void initState() {
    super.initState();
    _loadFavorites();
  }

  Future<void> _loadFavorites() async {
    setState(() {
      _isLoading = true;
      _error = null;
    });

    try {
      final userId = Supabase.instance.client.auth.currentUser?.id;
      if (userId == null) throw Exception('Not signed in');

      final response = await Supabase.instance.client
          .from('favorite_places')
          .select()
          .eq('user_id', userId)
          .order('created_at', ascending: false);

      if (!mounted) return;
      setState(() {
        _favorites = List<Map<String, dynamic>>.from(response);
        _isLoading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _isLoading = false;
        _error = AppError.from(e, onRetry: _loadFavorites);
      });
    }
  }

  Future<void> _deleteFavorite(String id) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Text(tr('Remove favorite?')),
        content: Text(tr('This place will be removed from your list.')),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: Text(tr('Keep')),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            onPressed: () => Navigator.pop(ctx, true),
            child: Text(tr('Remove')),
          ),
        ],
      ),
    );

    if (confirmed != true) return;

    try {
      await Supabase.instance.client
          .from('favorite_places')
          .delete()
          .eq('id', id);

      if (!mounted) return;
      setState(() =>
          _favorites.removeWhere((fav) => fav['id'].toString() == id));

      ErrorUI.showSnack(
        context,
        AppError(
          title: tr('Favorite removed'),
          message: tr('The place has been removed from your list.'),
          icon: Icons.check_circle_outline,
        ),
      );
    } catch (e) {
      if (!mounted) return;
      ErrorUI.showSnack(
        context,
        AppError.from(e, onRetry: () => _deleteFavorite(id)),
      );
    }
  }

  /// Add a place: pick it, then name it (Home, Work, or anything).
  Future<void> _addFavorite() async {
    final place = await showPlacePicker(context, title: tr('Add a place'));
    if (place == null || !mounted) return;
    final labelCtrl = TextEditingController();
    final label = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(tr('Name this place')),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(place.address, style: const TextStyle(fontSize: 14)),
            const SizedBox(height: 12),
            Wrap(spacing: 8, children: [
              for (final q in [tr('Home'), tr('Work')])
                ActionChip(
                  label: Text(q),
                  onPressed: () => Navigator.pop(ctx, q),
                ),
            ]),
            const SizedBox(height: 8),
            TextField(
              controller: labelCtrl,
              autofocus: true,
              decoration: InputDecoration(hintText: tr('e.g. Mom\'s place')),
            ),
          ],
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: Text(tr('Cancel'))),
          ElevatedButton(
              onPressed: () => Navigator.pop(ctx, labelCtrl.text.trim()),
              child: Text(tr('Save'))),
        ],
      ),
    );
    labelCtrl.dispose();
    if (label == null || label.isEmpty || !mounted) return;
    try {
      await FavoritePlacesService.saveFavorite(
        label: label,
        address: place.address,
        lat: place.latLng.latitude,
        lng: place.latLng.longitude,
      );
      _loadFavorites();
    } catch (e) {
      if (!mounted) return;
      ErrorUI.showSnack(context, AppError.from(e, onRetry: _addFavorite));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      floatingActionButton: _error == null
          ? FloatingActionButton.extended(
              onPressed: _addFavorite,
              backgroundColor: _Palette.accent,
              foregroundColor: _Palette.ink,
              icon: const Icon(Icons.add_location_alt),
              label: Text(tr('Add a place'),
                  style: const TextStyle(fontWeight: FontWeight.w800)),
            )
          : null,
      backgroundColor: _Palette.cream,
      appBar: AppBar(
        backgroundColor: _Palette.cream,
        elevation: 0,
        iconTheme: const IconThemeData(color: _Palette.ink),
        title: Text(
          tr('Favorite Places'),
          style: TextStyle(
              color: _Palette.ink,
              fontWeight: FontWeight.bold,
              fontSize: 18),
        ),
      ),
      body: _isLoading
          ? const Center(
              child: CircularProgressIndicator(color: _Palette.accent))
          : _error != null
              ? ErrorUI.inline(_error!)
              : _favorites.isEmpty
                  ? _emptyState()
                  : ListView.separated(
                      padding: const EdgeInsets.all(16),
                      itemCount: _favorites.length,
                      separatorBuilder: (_, __) => const SizedBox(height: 8),
                      itemBuilder: (_, i) => _favoriteTile(_favorites[i]),
                    ),
    );
  }

  Widget _emptyState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            AppImage(
              AppImages.mapPin,
              size: 64,
              tint: _Palette.inkMuted,
              fallbackIcon: Icons.favorite_border,
            ),
            const SizedBox(height: 16),
            Text(
              tr('No favorite places yet'),
              style: TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.bold,
                  color: _Palette.ink),
            ),
            const SizedBox(height: 4),
            Text(
              tr('Save frequently visited places for faster booking.'),
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 13.5, color: _Palette.inkMuted),
            ),
          ],
        ),
      ),
    );
  }

  Widget _favoriteTile(Map<String, dynamic> fav) {
    final name = (fav['name'] ?? fav['label'] ?? tr('Place')).toString();
    final address = (fav['address'] ?? '').toString();

    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: _Palette.divider),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: Colors.red.withOpacity(0.1),
              borderRadius: BorderRadius.circular(10),
            ),
            child: AppImage(
              AppImages.mapPin,
              size: 22,
              tint: Colors.red,
              fallbackIcon: Icons.favorite,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  name,
                  style: const TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.bold,
                      color: _Palette.ink),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                if (address.isNotEmpty) ...[
                  const SizedBox(height: 2),
                  Text(
                    address,
                    style: const TextStyle(
                        fontSize: 13.5, color: _Palette.inkMuted),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
              ],
            ),
          ),
          IconButton(
            icon: const Icon(Icons.delete_outline,
                color: Colors.red, size: 20),
            onPressed: () => _deleteFavorite(fav['id'].toString()),
          ),
        ],
      ),
    );
  }
}
