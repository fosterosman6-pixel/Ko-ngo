﻿// lib/screens/customer/corporate_screen.dart

import 'package:flutter/material.dart';
import 'package:efuride_app/config/app_images.dart';
import 'package:efuride_app/widgets/app_image.dart';
import 'package:efuride_app/l10n/app_strings.dart';

class _Palette {
  static const cream = Color(0xFFFAF6EE);
  static const ink = Color(0xFF1A1A1A);
  static const inkMuted = Color(0xFF575047);
  static const divider = Color(0xFFE8E2D5);
  static const blue = Color(0xFF1E88E5);
}

class CorporateScreen extends StatelessWidget {
  const CorporateScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _Palette.cream,
      appBar: AppBar(
        backgroundColor: _Palette.cream,
        elevation: 0,
        iconTheme: const IconThemeData(color: _Palette.ink),
        title: Text(
          tr('Corporate Accounts'),
          style: TextStyle(
              color: _Palette.ink,
              fontWeight: FontWeight.bold,
              fontSize: 18),
        ),
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Container(
                padding: const EdgeInsets.all(28),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: _Palette.divider),
                ),
                child: Column(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(18),
                      decoration: BoxDecoration(
                        color: _Palette.blue.withOpacity(0.1),
                        shape: BoxShape.circle,
                      ),
                      child: AppImage(
                        AppImages.briefcase,
                        size: 44,
                        fallbackIcon: Icons.business,
                      ),
                    ),
                    const SizedBox(height: 18),
                    Text(
                      tr('Corporate Travel'),
                      style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          color: _Palette.ink),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      tr('Manage business travel for your company — team members, consolidated billing, and reporting.'),
                      textAlign: TextAlign.center,
                      style: TextStyle(
                          color: _Palette.inkMuted,
                          fontSize: 14,
                          height: 1.4),
                    ),
                    const SizedBox(height: 20),
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 14, vertical: 8),
                      decoration: BoxDecoration(
                        color: _Palette.blue.withOpacity(0.08),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.construction,
                              size: 16, color: _Palette.blue),
                          SizedBox(width: 6),
                          Text(
                            tr('Coming soon'),
                            style: TextStyle(
                                fontSize: 13.5,
                                fontWeight: FontWeight.bold,
                                color: _Palette.blue),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),
              Text(
                tr('What you\'ll be able to do'),
                style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                    color: _Palette.ink),
              ),
              const SizedBox(height: 10),
              _featureRow(AppImages.family, 'Add and manage team members'),
              _featureRow(AppImages.coinsBlue,
                  'Consolidated monthly billing'),
              _featureRow(AppImages.gear, 'Central account settings'),
              _featureRow(AppImages.barChart,
                  'Spend analytics and reports'),
              const Spacer(),
              Text(
                tr('Interested? Contact ko!ngo support to join the waitlist.'),
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 13.5, color: _Palette.inkMuted),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _featureRow(String asset, String text) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: _Palette.cream,
              borderRadius: BorderRadius.circular(8),
            ),
            child: AppImage(
              asset,
              size: 20,
              fallbackIcon: Icons.check,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              text,
              style: const TextStyle(fontSize: 14, color: _Palette.ink),
            ),
          ),
        ],
      ),
    );
  }
}
