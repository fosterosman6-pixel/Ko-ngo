// lib/screens/customer/order_tracking_screen.dart
//
// Live tracker for Food / Grocery / Pharmacy orders.
//
// Streams:
//   • `orders` filtered by order_id            → status, timestamps
//   • `order_items` (re-fetched on each tick)  → line items
//   • `profiles` where id = order.driver_id    → live driver pin
//
// Two subscriptions: one for the order, one for the driver's location.
// The driver subscription is torn down and rebuilt whenever the
// assigned driver changes.

import 'dart:async';
import 'package:efuride_app/services/call_service.dart';
import 'package:efuride_app/screens/shared/in_app_call_screen.dart';
import 'package:flutter/material.dart';
import 'package:efuride_app/widgets/verified_badge.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:efuride_app/config/country_config.dart';
import 'package:efuride_app/config/efuride_palette.dart';
import 'package:efuride_app/l10n/app_strings.dart';
import 'package:efuride_app/models/order.dart';
import 'package:efuride_app/services/order_service.dart';
import 'package:efuride_app/utils/app_error.dart';
import 'package:efuride_app/utils/error_ui.dart';

class OrderTrackingScreen extends StatefulWidget {
  final String orderId;
  final String serviceType;      // 'Food' | 'Grocery' | 'Pharmacy'
  final String storeName;
  final String storeAddress;
  final String dropoffAddress;
  final double total;

  const OrderTrackingScreen({
    super.key,
    required this.orderId,
    required this.serviceType,
    required this.storeName,
    required this.storeAddress,
    required this.dropoffAddress,
    required this.total,
  });

  @override
  State<OrderTrackingScreen> createState() => _OrderTrackingScreenState();
}

class _OrderTrackingScreenState extends State<OrderTrackingScreen> {
  StreamSubscription<Order?>? _orderSub;
  RealtimeChannel? _driverChannel;

  Order? _order;
  bool _loading = true;
  Object? _error;
  bool _cancelling = false;

  // Driver live location
  String? _driverIdSubscribed;
  LatLng? _driverLatLng;
  String? _driverName;
  bool _driverVerified = false;
  String? _driverPhone;
  String? _driverPlate;
  bool _driverLoaded = false;

  // From get_trip_driver (step16 SQL): photo, rating, car, delivery job id.
  String? _driverPhoto;
  double? _driverRating;
  String? _driverCar;      // "White Nissan Micra"
  String? _deliveryRideId; // for the trip chat
  Timer? _driverPoll;

  GoogleMapController? _mapController;
  bool _mapCenteredOnce = false;

  @override
  void initState() {
    super.initState();
    _subscribeToOrder();
  }

  @override
  void dispose() {
    _orderSub?.cancel();
    _driverChannel?.unsubscribe();
    _driverPoll?.cancel();
    _mapController?.dispose();
    super.dispose();
  }

  // ══════════════════════════════════════════════════════════════
  // STREAMS
  // ══════════════════════════════════════════════════════════════

  void _subscribeToOrder() {
    _orderSub?.cancel();
    _orderSub = OrderService.instance
        .streamOrder(widget.orderId)
        .listen(
      (order) {
        if (!mounted) return;
        setState(() {
          _order = order;
          _loading = false;
          _error = null;
        });
        if (order == null) return;

        // When the driver appears or changes, re-subscribe to their pin.
        final did = order.driverId;
        if (did != null && did.isNotEmpty && did != _driverIdSubscribed) {
          _subscribeToDriver(did);
        }

        // Load driver profile details once.
        if (did != null && did.isNotEmpty && !_driverLoaded) {
          _driverLoaded = true;
          _loadDriverProfile(did);
        }
      },
      onError: (e) {
        if (!mounted) return;
        setState(() { _loading = false; _error = e; });
      },
    );
  }

  /// Live driver pin. The driver's position is mirrored onto the
  /// delivery job (rides row linked to this order), which the customer
  /// can read — driver profiles are private.
  void _subscribeToDriver(String driverId) {
    _driverIdSubscribed = driverId;
    _driverChannel?.unsubscribe();
    _driverChannel = Supabase.instance.client
        .channel('track_delivery_${widget.orderId}')
        .onPostgresChanges(
          event: PostgresChangeEvent.update,
          schema: 'public',
          table: 'rides',
          filter: PostgresChangeFilter(
            type: PostgresChangeFilterType.eq,
            column: 'order_id',
            value: widget.orderId,
          ),
          callback: (payload) => _applyDeliveryRow(payload.newRecord),
        )
        .subscribe();

    // Also pull the initial position immediately.
    _fetchInitialDriverLocation(driverId);
  }

  void _applyDeliveryRow(Map<String, dynamic> row) {
    final lat = (row['driver_lat'] as num?)?.toDouble();
    final lng = (row['driver_lng'] as num?)?.toDouble();
    if (lat == null || lng == null || !mounted) return;
    setState(() => _driverLatLng = LatLng(lat, lng));
    _maybeAutoCenter();
  }

  Future<void> _fetchInitialDriverLocation(String driverId) async {
    try {
      final row = await Supabase.instance.client
          .from('rides')
          .select('driver_lat, driver_lng')
          .eq('order_id', widget.orderId)
          .order('created_at', ascending: false)
          .limit(1)
          .maybeSingle();
      if (row != null) _applyDeliveryRow(Map<String, dynamic>.from(row));
    } catch (e) {
      debugPrint('fetchInitialDriverLocation failed: $e');
    }
  }

  /// Driver details + position through the server (driver profiles are
  /// private). Re-checked every 10 s while the order is on its way, so
  /// the pin keeps moving even if live updates drop.
  Future<bool> _loadDriverFromServer() async {
    try {
      final res = await Supabase.instance.client.rpc('get_trip_driver',
          params: {'p_order': widget.orderId}).timeout(
          const Duration(seconds: 10));
      if (res is! Map || !mounted) return false;
      final m = Map<String, dynamic>.from(res);
      String s(String k) => (m[k] ?? '').toString().trim();
      final name = s('name').isNotEmpty ? s('name') : s('full_name');
      final car = [s('color'), s('make'), s('model')]
          .where((e) => e.isNotEmpty)
          .join(' ');
      final lat = (m['lat'] as num?)?.toDouble();
      final lng = (m['lng'] as num?)?.toDouble();
      setState(() {
        if (name.isNotEmpty) _driverName = name;
        _driverVerified = m['verified'] == true;
        if (s('phone').isNotEmpty) _driverPhone = s('phone');
        if (s('plate').isNotEmpty) _driverPlate = s('plate');
        if (s('photo').isNotEmpty) _driverPhoto = s('photo');
        _driverRating = double.tryParse(s('rating'));
        if (car.isNotEmpty) _driverCar = car;
        if (s('ride_id').isNotEmpty) _deliveryRideId = s('ride_id');
        if (lat != null && lng != null) _driverLatLng = LatLng(lat, lng);
      });
      _maybeAutoCenter();
      return true;
    } catch (e) {
      debugPrint('get_trip_driver failed: $e');
      return false;
    }
  }

  Future<void> _loadDriverProfile(String driverId) async {
    if (await _loadDriverFromServer()) {
      _driverPoll?.cancel();
      _driverPoll = Timer.periodic(const Duration(seconds: 10), (_) {
        final st = _order?.status;
        if (st == OrderStatus.delivered ||
            st == OrderStatus.cancelled ||
            st == OrderStatus.refunded) {
          _driverPoll?.cancel();
          return;
        }
        _loadDriverFromServer();
      });
      return;
    }
    try {
      final p = await Supabase.instance.client
          .from('profiles')
          .select('first_name, surname, full_name, phone_number, phone')
          .eq('id', driverId)
          .maybeSingle();

      String? plate;
      try {
        final v = await Supabase.instance.client
            .from('vehicles')
            .select('plate_number')
            .eq('driver_id', driverId)
            .eq('status', 'active')
            .limit(1)
            .maybeSingle();
        plate = v?['plate_number']?.toString();
      } catch (_) {}

      if (!mounted) return;
      final first = (p?['first_name'] ?? '').toString().trim();
      final sur   = (p?['surname']    ?? '').toString().trim();
      final full  = (p?['full_name']  ?? '').toString().trim();
      final name = first.isNotEmpty ? '$first $sur'.trim() : full;

      setState(() {
        if (name.isNotEmpty)  _driverName  = name;
        _driverPhone = (p?['phone'] ?? p?['phone_number'])?.toString();
        _driverPlate = plate;
      });
    } catch (e) {
      debugPrint('loadDriverProfile failed: $e');
    }
  }

  /// First time: show both the driver and the delivery address.
  void _maybeAutoCenter() {
    if (_mapCenteredOnce || _driverLatLng == null || _mapController == null) {
      return;
    }
    _mapCenteredOnce = true;
    final o = _order;
    final d = _driverLatLng!;
    if (o?.deliveryLat != null && o?.deliveryLng != null) {
      final h = LatLng(o!.deliveryLat!, o.deliveryLng!);
      final sw = LatLng(d.latitude < h.latitude ? d.latitude : h.latitude,
          d.longitude < h.longitude ? d.longitude : h.longitude);
      final ne = LatLng(d.latitude > h.latitude ? d.latitude : h.latitude,
          d.longitude > h.longitude ? d.longitude : h.longitude);
      if ((ne.latitude - sw.latitude).abs() > 0.0005 ||
          (ne.longitude - sw.longitude).abs() > 0.0005) {
        _mapController!.animateCamera(CameraUpdate.newLatLngBounds(
            LatLngBounds(southwest: sw, northeast: ne), 60));
        return;
      }
    }
    _mapController!.animateCamera(CameraUpdate.newLatLngZoom(d, 15.0));
  }

  // ══════════════════════════════════════════════════════════════
  // CANCEL
  // ══════════════════════════════════════════════════════════════

  Future<void> _confirmCancel() async {
    if (_cancelling) return;
    final o = _order;
    if (o == null || !o.isActive) return;

    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16)),
        title: Text(tr('Cancel this order?')),
        content: Text(
          tr('If the store has already started preparing, you may be charged a fee.'),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: Text(tr('Keep it')),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: EfuridePalette.dropoff,
              foregroundColor: Colors.white,
            ),
            onPressed: () => Navigator.pop(context, true),
            child: Text(tr('Cancel')),
          ),
        ],
      ),
    );
    if (ok != true || !mounted) return;

    setState(() => _cancelling = true);
    try {
      await OrderService.instance.cancelOrder(
        orderId: o.id,
        reason: 'Cancelled by customer',
        cancelledBy: 'customer',
      );
      if (!mounted) return;
      ErrorUI.showSnack(
        context,
        AppError(
          title: tr('Order cancelled'),
          message: tr('The store has been notified.'),
          icon: Icons.check_circle_outline,
        ),
      );
    } catch (e) {
      if (!mounted) return;
      ErrorUI.showSnack(context, AppError.from(e));
    } finally {
      if (mounted) setState(() => _cancelling = false);
    }
  }

  // ══════════════════════════════════════════════════════════════
  // HELPERS
  // ══════════════════════════════════════════════════════════════

  Color get _accent {
    switch (widget.serviceType) {
      case 'Grocery':  return EfuridePalette.shopperAccent;
      case 'Pharmacy': return EfuridePalette.dropoff;
      case 'Food':
      default:         return EfuridePalette.merchantAccent;
    }
  }

  IconData get _serviceIcon {
    switch (widget.serviceType) {
      case 'Grocery':  return Icons.shopping_bag_rounded;
      case 'Pharmacy': return Icons.medical_services_rounded;
      case 'Food':
      default:         return Icons.restaurant_rounded;
    }
  }

  /// Which stages does the timeline show for this vertical?
  /// Every order: placed → shopper buying → packed → on the way → delivered.
  List<_StageItem> _stagesFor(S t) {
    return [
      _StageItem(OrderStatus.pending,
          t.t('stage_placed'), t.t('stage_placed_sub'),
          Icons.receipt_long),
      _StageItem(OrderStatus.shopping,
          t.t('stage_shopping'), t.t('stage_shopping_sub'),
          Icons.shopping_cart),
      _StageItem(OrderStatus.ready,
          t.t('stage_packed'), t.t('stage_packed_sub'),
          Icons.inventory_2_outlined),
      _StageItem(OrderStatus.pickedUp,
          t.t('stage_picked_up'), t.t('stage_picked_up_sub'),
          Icons.delivery_dining),
      _StageItem(OrderStatus.delivered,
          t.t('stage_delivered'), t.t('stage_delivered_sub'),
          Icons.check_circle),
    ];
  }

  int _stageIndex(List<_StageItem> stages, OrderStatus current) {
    // Map statuses that share a timeline position.
    final OrderStatus normalized;
    switch (current) {
      case OrderStatus.confirmed:
        normalized = OrderStatus.pending;
        break;
      case OrderStatus.preparing:
        normalized = OrderStatus.shopping;
        break;
      case OrderStatus.inTransit:
      case OrderStatus.returning:
      case OrderStatus.returned:
        normalized = OrderStatus.pickedUp;
        break;
      default:
        normalized = current;
    }
    for (var i = 0; i < stages.length; i++) {
      if (stages[i].status == normalized) return i;
    }
    // Cancelled or refunded → keep the last known stage visible.
    return 0;
  }

  // ══════════════════════════════════════════════════════════════
  // BUILD
  // ══════════════════════════════════════════════════════════════

  @override
  Widget build(BuildContext context) {
    final t = S.of(context);

    return Scaffold(
      backgroundColor: EfuridePalette.cream,
      body: Column(
        children: [
          _header(t),
          Expanded(child: _body(t)),
        ],
      ),
    );
  }

  Widget _body(S t) {
    if (_loading) {
      return const Center(
        child: CircularProgressIndicator(color: EfuridePalette.accent),
      );
    }

    if (_error != null || _order == null) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.error_outline,
                  size: 56, color: Colors.grey.shade400),
              const SizedBox(height: 12),
              Text(tr('Order not found'),
                  style: TextStyle(
                      fontSize: 15, fontWeight: FontWeight.w700)),
              const SizedBox(height: 8),
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: Text(tr('Back')),
              ),
            ],
          ),
        ),
      );
    }

    final o = _order!;

    return RefreshIndicator(
      color: _accent,
      onRefresh: () async => _subscribeToOrder(),
      child: ListView(
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
        children: [
          _mapCard(o),
          const SizedBox(height: 14),
          _statusCard(o, t),
          const SizedBox(height: 14),
          if (o.driverId != null &&
              o.status != OrderStatus.cancelled &&
              o.status != OrderStatus.refunded) ...[
            _driverCard(t),
            const SizedBox(height: 14),
          ],
          _timelineCard(o, t),
          const SizedBox(height: 14),
          _detailsCard(o, t),
          if (o.lines.isNotEmpty) ...[
            const SizedBox(height: 14),
            _itemsCard(o, t),
          ],
          const SizedBox(height: 14),
          _supportCard(o, t),
          const SizedBox(height: 20),
        ],
      ),
    );
  }

  // ── Header ───────────────────────────────────────────────────
  Widget _header(S t) {
    final o = _order;
    final statusLabel = o == null
        ? widget.serviceType
        : _statusTitle(o.status, t);

    return Container(
      decoration: const BoxDecoration(
        color: EfuridePalette.cream,
      ),
      child: SafeArea(
        bottom: false,
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(8, 8, 16, 12),
              child: Row(
                children: [
                  IconButton(
                    onPressed: () => Navigator.pop(context),
                    icon: const Icon(Icons.arrow_back, color: EfuridePalette.ink),
                  ),
                  const SizedBox(width: 4),
                  Container(
                    width: 36, height: 36,
                    decoration: const BoxDecoration(
                      color: Colors.white, shape: BoxShape.circle,
                    ),
                    child: Center(
                      child: Icon(_serviceIcon, color: _accent, size: 20),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(tr('KO!NGO'),
                          style: TextStyle(
                            color: EfuridePalette.ink,
                            fontSize: 16,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 1.2,
                            height: 1.05,
                          )),
                      const SizedBox(height: 2),
                      Text('${t.t('tracking')} · ${widget.serviceType}',
                          style: const TextStyle(
                            color: EfuridePalette.inkMuted,
                            fontSize: 13,
                            fontWeight: FontWeight.w500,
                          )),
                    ],
                  ),
                ],
              ),
            ),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.fromLTRB(16, 14, 16, 18),
              decoration: const BoxDecoration(
                color: EfuridePalette.cream,
                borderRadius: BorderRadius.only(
                  topLeft:  Radius.circular(24),
                  topRight: Radius.circular(24),
                ),
              ),
              child: Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('#${widget.orderId}',
                            style: const TextStyle(
                              color: EfuridePalette.inkMuted,
                              fontSize: 13,
                              fontWeight: FontWeight.w600,
                              letterSpacing: 0.4,
                            )),
                        const SizedBox(height: 2),
                        Text(statusLabel,
                            style: const TextStyle(
                              color: EfuridePalette.ink,
                              fontSize: 20,
                              fontWeight: FontWeight.w900,
                              letterSpacing: -0.3,
                            )),
                      ],
                    ),
                  ),
                  if (_order?.isActive == true)
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 10, vertical: 6),
                      decoration: BoxDecoration(
                        color: _accent,
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          SizedBox(
                            width: 8, height: 8,
                            child: CircularProgressIndicator(
                              strokeWidth: 2,
                              valueColor: AlwaysStoppedAnimation(
                                  Colors.white),
                            ),
                          ),
                          SizedBox(width: 8),
                          Text(tr('LIVE'),
                              style: TextStyle(
                                color: EfuridePalette.ink,
                                fontSize: 12.5,
                                fontWeight: FontWeight.w900,
                                letterSpacing: 0.8,
                              )),
                        ],
                      ),
                    ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  String _statusTitle(OrderStatus s, S t) {
    switch (s) {
      case OrderStatus.pending:    return t.t('stage_placed');
      case OrderStatus.confirmed:  return t.t('stage_confirmed');
      case OrderStatus.shopping:   return t.t('stage_shopping');
      case OrderStatus.preparing:  return t.t('stage_preparing');
      case OrderStatus.ready:      return t.t('stage_ready');
      case OrderStatus.pickedUp:   return t.t('stage_picked_up');
      case OrderStatus.inTransit:  return t.t('stage_in_transit');
      case OrderStatus.delivered:  return t.t('stage_delivered');
      case OrderStatus.returning:  return t.t('ot_returning');
      case OrderStatus.returned:   return t.t('ot_returned');
      case OrderStatus.cancelled:  return t.t('ot_cancelled');
      case OrderStatus.refunded:   return t.t('ot_refunded');
    }
  }

  // ── Map ──────────────────────────────────────────────────────
  Widget _mapCard(Order o) {
    final live = o.driverId != null &&
        o.status != OrderStatus.delivered &&
        o.status != OrderStatus.cancelled;
    return Container(
      height: live ? 280 : 200,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: EfuridePalette.divider),
      ),
      clipBehavior: Clip.antiAlias,
      child: Stack(
        children: [
          Positioned.fill(
            child: GoogleMap(
              initialCameraPosition: CameraPosition(
                target: _driverLatLng ??
                    (o.deliveryLat != null && o.deliveryLng != null
                        ? LatLng(o.deliveryLat!, o.deliveryLng!)
                        : const LatLng(-4.2634, 15.2429)),
                zoom: 14.5,
              ),
              onMapCreated: (c) {
                _mapController = c;
                _maybeAutoCenter();
              },
              markers: {
                if (_driverLatLng != null)
                  Marker(
                    markerId: const MarkerId('driver'),
                    position: _driverLatLng!,
                    infoWindow: InfoWindow(
                        title: _driverName ?? tr('Your driver'),
                        snippet: _driverPlate),
                    icon: BitmapDescriptor.defaultMarkerWithHue(
                        BitmapDescriptor.hueAzure),
                  ),
                if (o.deliveryLat != null && o.deliveryLng != null)
                  Marker(
                    markerId: const MarkerId('me'),
                    position: LatLng(o.deliveryLat!, o.deliveryLng!),
                    icon: BitmapDescriptor.defaultMarkerWithHue(
                        BitmapDescriptor.hueGreen),
                  ),
              },
              myLocationEnabled: false,
              myLocationButtonEnabled: false,
              zoomControlsEnabled: false,
              compassEnabled: false,
              tiltGesturesEnabled: false,
              rotateGesturesEnabled: false,
              mapToolbarEnabled: false,
            ),
          ),
          Positioned(
            bottom: 12, right: 12,
            child: Material(
              color: Colors.white,
              shape: const CircleBorder(),
              elevation: 3,
              child: InkWell(
                customBorder: const CircleBorder(),
                onTap: () {
                  final target = _driverLatLng;
                  if (target != null && _mapController != null) {
                    _mapController!.animateCamera(
                      CameraUpdate.newLatLngZoom(target, 15.0),
                    );
                  }
                },
                child: const Padding(
                  padding: EdgeInsets.all(10),
                  child: Icon(Icons.my_location,
                      size: 20, color: EfuridePalette.ink),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ── Status summary ───────────────────────────────────────────
  Widget _statusCard(Order o, S t) {
    final done = o.status == OrderStatus.delivered;
    final cancelled = o.status == OrderStatus.cancelled ||
        o.status == OrderStatus.refunded ||
        o.status == OrderStatus.returned;

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            _accent.withValues(alpha: 0.12),
            _accent.withValues(alpha: 0.03),
          ],
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: _accent.withValues(alpha: 0.35), width: 1.4),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: _accent,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(
              done
                  ? Icons.check_circle
                  : cancelled
                      ? Icons.cancel_outlined
                      : Icons.access_time,
              color: Colors.white,
              size: 22,
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  done
                      ? t.t('stage_delivered')
                      : cancelled
                          ? 'Cancelled'
                          : t.t('estimated_arrival'),
                  style: const TextStyle(
                    fontSize: 13,
                    color: EfuridePalette.inkMuted,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 0.3,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  done
                      ? '✓'
                      : cancelled
                          ? '—'
                          : _etaLabel(o, t),
                  style: TextStyle(
                    fontSize: done || cancelled ? 24 : 18,
                    fontWeight: FontWeight.w900,
                    color: done
                        ? EfuridePalette.online
                        : cancelled
                            ? EfuridePalette.dropoff
                            : _accent,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  /// Crude ETA: based on status only. A real ETA comes from a routing
  /// service; for now this gives the customer a sense of where they are.
  String _etaLabel(Order o, S t) {
    switch (o.status) {
      case OrderStatus.pending:   return t.t('ot_finding_shopper');
      case OrderStatus.confirmed: return '~${15 + 10} ${t.t('min')}';
      case OrderStatus.preparing:
      case OrderStatus.shopping:  return '~${10 + 10} ${t.t('min')}';
      case OrderStatus.ready:     return t.t('ot_finding_driver');
      case OrderStatus.pickedUp:
      case OrderStatus.inTransit: return '~10 ${t.t('min')}';
      case OrderStatus.delivered: return '✓';
      case OrderStatus.returning: return t.t('ot_returning_eta');
      case OrderStatus.returned:  return t.t('ot_returned_eta');
      case OrderStatus.cancelled:
      case OrderStatus.refunded:  return '—';
    }
  }

  // ── Driver card ──────────────────────────────────────────────
  /// Who is bringing the order: photo, name, rating, car + plate,
  /// call and chat.
  Widget _driverCard(S t) {
    final name = _driverName ?? tr('Your driver');
    final initial = name.substring(0, 1).toUpperCase();
    final details = [
      if (_driverCar != null) _driverCar!,
      if (_driverPlate != null) _driverPlate!,
    ].join(' · ');
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: EfuridePalette.divider),
      ),
      child: Row(
        children: [
          CircleAvatar(
            radius: 28,
            backgroundColor: _accent.withValues(alpha: 0.12),
            backgroundImage:
                _driverPhoto != null ? NetworkImage(_driverPhoto!) : null,
            child: _driverPhoto == null
                ? Text(initial,
                    style: TextStyle(
                        fontSize: 22,
                        fontWeight: FontWeight.w900,
                        color: _accent))
                : null,
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(children: [
                  Flexible(
                    child: Text(name,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          fontSize: 16.5,
                          fontWeight: FontWeight.w800,
                          color: EfuridePalette.ink,
                        )),
                  ),
                  if (_driverVerified) ...[
                    const SizedBox(width: 5),
                    const VerifiedBadge(),
                  ],
                ]),
                const SizedBox(height: 2),
                Row(
                  children: [
                    if (_driverRating != null) ...[
                      const Icon(Icons.star,
                          size: 15, color: EfuridePalette.accent),
                      const SizedBox(width: 3),
                      Text(_driverRating!.toStringAsFixed(1),
                          style: const TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.w700,
                              color: EfuridePalette.ink)),
                      const SizedBox(width: 8),
                    ],
                    Text(t.t('role_driver'),
                        style: const TextStyle(
                            fontSize: 14, color: EfuridePalette.inkMuted)),
                  ],
                ),
                if (details.isNotEmpty) ...[
                  const SizedBox(height: 2),
                  Text(details,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w700,
                          color: EfuridePalette.ink)),
                ],
              ],
            ),
          ),
          if (_driverPhone != null && _driverPhone!.isNotEmpty) ...[
            _circleBtn(
              icon: Icons.call,
              color: const Color(0xFF15803D),
              onTap: _deliveryRideId == null
                  ? () => launchUrl(Uri(
                      scheme: 'tel',
                      path: _driverPhone!.replaceAll(' ', '')))
                  : () async {
                      final svc = CallService.instance;
                      svc.onOutgoing = () {
                        if (mounted) InAppCallScreen.show(context);
                      };
                      svc.onIncoming = () {
                        if (mounted) InAppCallScreen.show(context);
                      };
                      await svc.attach(_deliveryRideId!,
                          myName: tr('Customer'));
                      svc.call(toName: tr('Driver'));
                    },
            ),
            const SizedBox(width: 8),
          ],
          _circleBtn(
            icon: Icons.chat_bubble_outline,
            color: EfuridePalette.blueDeep,
            onTap: _deliveryRideId == null
                ? () => ErrorUI.showSnack(
                      context,
                      AppError(
                        title: tr('Chat'),
                        message: tr('Chat opens once a driver has your order.'),
                        icon: Icons.chat_bubble_outline,
                      ),
                    )
                : () => Navigator.pushNamed(
                      context,
                      '/chat',
                      arguments: {
                        // The trip chat belongs to the delivery job.
                        'chatId': _deliveryRideId,
                        'rideId': _deliveryRideId,
                        'otherName': name,
                      },
                    ),
          ),
        ],
      ),
    );
  }

  Widget _circleBtn({
    required IconData icon,
    required Color color,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(24),
      child: Container(
        width: 42, height: 42,
        decoration: BoxDecoration(
          color: color.withValues(alpha: 0.12),
          shape: BoxShape.circle,
        ),
        child: Icon(icon, color: color, size: 20),
      ),
    );
  }

  // ── Timeline ─────────────────────────────────────────────────
  Widget _timelineCard(Order o, S t) {
    final stages = _stagesFor(t);
    final current = _stageIndex(stages, o.status);
    final cancelled = o.status == OrderStatus.cancelled ||
        o.status == OrderStatus.refunded ||
        o.status == OrderStatus.returned;

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: EfuridePalette.divider),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(tr('Order timeline'),
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w800,
                color: EfuridePalette.ink,
              )),
          const SizedBox(height: 16),
          ...List.generate(stages.length, (i) {
            final item = stages[i];
            final isDone = !cancelled && i < current;
            final isActive = !cancelled && i == current;
            final isLast = i == stages.length - 1;

            final dotColor = isDone
                ? EfuridePalette.online
                : isActive
                    ? _accent
                    : EfuridePalette.divider;

            return IntrinsicHeight(
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(
                    width: 28,
                    child: Column(
                      children: [
                        Container(
                          width: 24, height: 24,
                          decoration: BoxDecoration(
                            color: isDone
                                ? dotColor
                                : isActive
                                    ? dotColor.withValues(alpha: 0.20)
                                    : Colors.transparent,
                            shape: BoxShape.circle,
                            border: Border.all(color: dotColor, width: 2),
                          ),
                          child: isDone
                              ? const Icon(Icons.check,
                                  size: 14, color: Colors.white)
                              : isActive
                                  ? Center(
                                      child: Container(
                                        width: 8, height: 8,
                                        decoration: BoxDecoration(
                                          color: dotColor,
                                          shape: BoxShape.circle,
                                        ),
                                      ),
                                    )
                                  : null,
                        ),
                        if (!isLast)
                          Expanded(
                            child: Container(
                              width: 2,
                              color: isDone
                                  ? EfuridePalette.online
                                  : EfuridePalette.divider,
                            ),
                          ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Padding(
                      padding: EdgeInsets.only(
                          bottom: isLast ? 0 : 20, top: 1),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(item.title,
                              style: TextStyle(
                                fontSize: 14.5,
                                fontWeight: isActive
                                    ? FontWeight.w900
                                    : FontWeight.w700,
                                color: isActive || isDone
                                    ? EfuridePalette.ink
                                    : EfuridePalette.inkMuted,
                              )),
                          const SizedBox(height: 2),
                          Text(item.subtitle,
                              style: const TextStyle(
                                fontSize: 13,
                                color: EfuridePalette.inkMuted,
                                height: 1.35,
                              )),
                        ],
                      ),
                    ),
                  ),
                  if (isActive)
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 8, vertical: 3),
                      decoration: BoxDecoration(
                        color: _accent.withValues(alpha: 0.15),
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child: Text('NOW',
                          style: TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.w900,
                            color: _accent,
                            letterSpacing: 0.5,
                          )),
                    ),
                ],
              ),
            );
          }),
        ],
      ),
    );
  }

  // ── Details ──────────────────────────────────────────────────
  Widget _detailsCard(Order o, S t) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: EfuridePalette.divider),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(tr('Details'),
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w800,
                color: EfuridePalette.ink,
              )),
          const SizedBox(height: 12),
          _detailRow(Icons.storefront, t.t('from'),
              widget.storeName, widget.storeAddress),
          const SizedBox(height: 10),
          _detailRow(Icons.location_on, t.t('to'), t.t('you'),
              o.deliveryAddress ?? widget.dropoffAddress),
          const SizedBox(height: 10),
          _detailRow(
            Icons.payments_outlined,
            t.t('total'),
            CountryConfig.money(o.total),
            o.paymentStatus == 'paid' ? 'Paid' : 'Pending',
          ),
        ],
      ),
    );
  }

  Widget _detailRow(
      IconData icon, String label, String title, String sub) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          width: 36, height: 36,
          decoration: BoxDecoration(
            color: _accent.withValues(alpha: 0.10),
            borderRadius: BorderRadius.circular(10),
          ),
          child: Icon(icon, size: 18, color: _accent),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(label,
                  style: const TextStyle(
                    fontSize: 12.5,
                    color: EfuridePalette.inkMuted,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 0.4,
                  )),
              const SizedBox(height: 2),
              Text(title,
                  style: const TextStyle(
                    fontSize: 14.5,
                    fontWeight: FontWeight.w800,
                    color: EfuridePalette.ink,
                  )),
              Text(sub,
                  style: const TextStyle(
                    fontSize: 13,
                    color: EfuridePalette.inkMuted,
                    height: 1.35,
                  )),
            ],
          ),
        ),
      ],
    );
  }

  // ── Items ────────────────────────────────────────────────────
  Widget _itemsCard(Order o, S t) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: EfuridePalette.divider),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(t.t('your_items'),
              style: const TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w800,
                color: EfuridePalette.ink,
              )),
          const SizedBox(height: 12),
          for (final l in o.lines)
            Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: Row(
                children: [
                  Container(
                    width: 34, height: 34,
                    decoration: BoxDecoration(
                      color: _accent.withValues(alpha: 0.10),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Center(
                      child: (l.emoji != null && l.emoji!.isNotEmpty)
                          ? Text(l.emoji!,
                              style: const TextStyle(fontSize: 18))
                          : Icon(Icons.fastfood, size: 16, color: _accent),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(l.name,
                            style: const TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.w700,
                              color: EfuridePalette.ink,
                            ),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis),
                        Text(tr('x{0} · {1}', [l.qty, CountryConfig.money(l.unitPrice)]),
                            style: const TextStyle(
                              fontSize: 13,
                              color: EfuridePalette.inkMuted,
                            )),
                      ],
                    ),
                  ),
                  Text(CountryConfig.money(l.lineTotal),
                      style: const TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w800,
                        color: EfuridePalette.ink,
                      )),
                ],
              ),
            ),
          const Divider(height: 20, color: EfuridePalette.divider),
          Row(
            children: [
              Text(t.t('subtotal'),
                  style: const TextStyle(
                      fontSize: 14, color: EfuridePalette.inkMuted)),
              const Spacer(),
              Text(CountryConfig.money(o.subtotal),
                  style: const TextStyle(
                      fontSize: 14, fontWeight: FontWeight.w700)),
            ],
          ),
          if (o.serviceFee > 0) ...[
            const SizedBox(height: 4),
            Row(
              children: [
                Text(t.t('service_fee'),
                    style: const TextStyle(
                        fontSize: 14, color: EfuridePalette.inkMuted)),
                const Spacer(),
                Text(CountryConfig.money(o.serviceFee),
                    style: const TextStyle(
                        fontSize: 14, fontWeight: FontWeight.w700)),
              ],
            ),
          ],
          const SizedBox(height: 4),
          Row(
            children: [
              Text(t.t('delivery_fee'),
                  style: const TextStyle(
                      fontSize: 14, color: EfuridePalette.inkMuted)),
              const Spacer(),
              Text(CountryConfig.money(o.deliveryFee),
                  style: const TextStyle(
                      fontSize: 14, fontWeight: FontWeight.w700)),
            ],
          ),
          if (o.discountAmount > 0) ...[
            const SizedBox(height: 4),
            Row(
              children: [
                Text(t.t('promo_discount'),
                    style: const TextStyle(
                        fontSize: 14, color: EfuridePalette.online)),
                const Spacer(),
                Text('− ${CountryConfig.money(o.discountAmount)}',
                    style: const TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w700,
                        color: EfuridePalette.online)),
              ],
            ),
          ],
          const SizedBox(height: 8),
          Row(
            children: [
              Text(t.t('total'),
                  style: const TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w900,
                    color: EfuridePalette.ink,
                  )),
              const Spacer(),
              Text(CountryConfig.money(o.total),
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w900,
                    color: _accent,
                  )),
            ],
          ),
        ],
      ),
    );
  }

  // ── Support ──────────────────────────────────────────────────
  Widget _supportCard(Order o, S t) {
    final canCancel = o.canCustomerCancel;

    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: EfuridePalette.divider),
      ),
      child: Column(
        children: [
          _supportRow(
            icon: Icons.help_outline,
            title: t.t('need_help'),
            subtitle: t.t('need_help_hint'),
            onTap: () => Navigator.pushNamed(context, '/support'),
          ),
          const Divider(height: 1, color: EfuridePalette.divider),
          _supportRow(
            icon: Icons.ios_share,
            title: t.t('share_tracking'),
            subtitle: t.t('share_tracking_hint'),
            onTap: () {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text(
                    tr('Share link: efuride://track/{0}', [widget.orderId]))),
              );
            },
          ),
          if (canCancel) ...[
            const Divider(height: 1, color: EfuridePalette.divider),
            _supportRow(
              icon: Icons.cancel_outlined,
              title: t.t('cancel_order'),
              subtitle: t.t('cancel_may_fee'),
              color: EfuridePalette.dropoff,
              onTap: _cancelling ? () {} : _confirmCancel,
            ),
          ],
        ],
      ),
    );
  }

  Widget _supportRow({
    required IconData icon,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
    Color? color,
  }) {
    final c = color ?? EfuridePalette.blueDeep;
    return InkWell(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 12),
        child: Row(
          children: [
            Container(
              width: 36, height: 36,
              decoration: BoxDecoration(
                color: c.withValues(alpha: 0.10),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Icon(icon, size: 18, color: c),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title,
                      style: TextStyle(
                        fontSize: 14.5,
                        fontWeight: FontWeight.w800,
                        color: color ?? EfuridePalette.ink,
                      )),
                  const SizedBox(height: 1),
                  Text(subtitle,
                      style: const TextStyle(
                        fontSize: 13,
                        color: EfuridePalette.inkMuted,
                      )),
                ],
              ),
            ),
            const Icon(Icons.chevron_right,
                size: 20, color: EfuridePalette.inkMuted),
          ],
        ),
      ),
    );
  }
}

class _StageItem {
  final OrderStatus status;
  final String title;
  final String subtitle;
  final IconData icon;
  const _StageItem(this.status, this.title, this.subtitle, this.icon);
}
