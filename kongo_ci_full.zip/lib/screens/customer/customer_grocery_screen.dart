// lib/screens/customer/customer_grocery_screen.dart

import 'package:flutter/material.dart';
import 'package:efuride_app/config/efuride_palette.dart';
import 'package:efuride_app/widgets/partner_landing_screen.dart';

class CustomerGroceryScreen extends StatelessWidget {
  const CustomerGroceryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const PartnerLandingScreen(
      category:       'grocery',
      serviceType:    'Grocery',
      accent:         EfuridePalette.shopperAccent,
      headerIcon:     Icons.shopping_bag_rounded,
      headerKicker:   'Groceries at your door',
      headerTitle:    'Fresh picks, fast',
      headerSubtitle: 'Our shoppers pick the best for you',
      searchHint:     'Search stores or products',
      headerImage:    'assets/images/grocery.png',
    );
  }
}
