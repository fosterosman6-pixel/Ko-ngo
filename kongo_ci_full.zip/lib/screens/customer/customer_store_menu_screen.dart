// lib/screens/customer/customer_store_menu_screen.dart
//
// Generic menu for Grocery + Pharmacy partners.

import 'package:efuride_app/widgets/product_thumb.dart';
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:efuride_app/utils/search_match.dart';
import 'package:provider/provider.dart';
import 'package:efuride_app/config/country_config.dart';
import 'package:efuride_app/config/efuride_palette.dart';
import 'package:efuride_app/l10n/app_strings.dart';
import 'package:efuride_app/models/partner.dart';
import 'package:efuride_app/models/product.dart';
import 'package:efuride_app/providers/cart_provider.dart';
import 'package:efuride_app/services/order_service.dart';
import 'package:efuride_app/widgets/k_icon.dart';

class CustomerStoreMenuScreen extends StatefulWidget {
  final String storeId;
  final String storeName;
  final String storeAddress;
  final String serviceType;   // 'Grocery' | 'Pharmacy'

  const CustomerStoreMenuScreen({
    super.key,
    required this.storeId,
    required this.storeName,
    required this.storeAddress,
    required this.serviceType,
  });

  @override
  State<CustomerStoreMenuScreen> createState() =>
      _CustomerStoreMenuScreenState();
}

class _CustomerStoreMenuScreenState
    extends State<CustomerStoreMenuScreen> {
  final _searchCtrl = TextEditingController();
  Timer? _debounce;

  Partner? _partner;
  List<Product> _all = [];
  bool _loading = true;
  Object? _error;

  Color get _accent => widget.serviceType == 'Pharmacy'
      ? EfuridePalette.dropoff
      : EfuridePalette.shopperAccent;

  @override
  void initState() {
    super.initState();
    _load();
    _searchCtrl.addListener(_onSearch);
  }

  @override
  void dispose() {
    _debounce?.cancel();
    _searchCtrl.removeListener(_onSearch);
    _searchCtrl.dispose();
    super.dispose();
  }

  void _onSearch() {
    _debounce?.cancel();
    _debounce = Timer(const Duration(milliseconds: 200), () {
      if (mounted) setState(() {});
    });
  }

  Future<void> _load() async {
    setState(() { _loading = true; _error = null; });
    try {
      final results = await Future.wait([
        OrderService.instance.fetchPartner(widget.storeId),
        OrderService.instance.fetchProducts(widget.storeId),
      ]);
      if (!mounted) return;
      setState(() {
        _partner = results[0] as Partner?;
        _all = results[1] as List<Product>;
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() { _error = e; _loading = false; });
    }
  }

  List<Product> get _visible {
    final q = _searchCtrl.text.trim().toLowerCase();
    if (q.isEmpty) return _all;
    return _all
        .where((p) => searchMatches(q, [p.name, p.description, p.category]))
        .toList();
  }

  Map<String, List<Product>> get _grouped {
    final out = <String, List<Product>>{};
    for (final p in _visible) {
      final key = (p.category ?? '').trim().isEmpty
          ? 'Other'
          : p.category!;
      out.putIfAbsent(key, () => []).add(p);
    }
    return out;
  }

  Future<void> _ensureCartBound() async {
    final cart = context.read<CartProvider>();
    if (cart.partnerId == widget.storeId) {
      // Same store: keep the items but take its current fees.
      final partner = _partner;
      if (partner != null) cart.bindTo(partner, widget.serviceType);
      return;
    }

    if (cart.isNotEmpty) {
      final ok = await showDialog<bool>(
        context: context,
        builder: (_) => AlertDialog(
          shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(16)),
          title: Text(tr('Start a new cart?')),
          content: Text(
              'Your cart from ${cart.partnerName ?? 'another store'} will be cleared.'),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: Text(tr('Keep old cart')),
            ),
            ElevatedButton(
              onPressed: () => Navigator.pop(context, true),
              child: Text(tr('Start new')),
            ),
          ],
        ),
      );
      if (ok != true) return;
      cart.clear();
    }

    final partner = _partner;
    if (partner != null) cart.resetTo(partner, widget.serviceType);
  }

  Future<void> _addToCart(Product p) async {
    await _ensureCartBound();
    if (!mounted) return;
    context.read<CartProvider>().add(p);
  }

  void _openCart() => Navigator.pushNamed(context, '/customer_cart');

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: EfuridePalette.cream,
      body: Column(
        children: [
          _header(),
          Expanded(child: _body()),
        ],
      ),
      bottomNavigationBar: _cartBar(),
    );
  }

  Widget _header() {
    final t = S.of(context);
    return Container(
      decoration: const BoxDecoration(
        color: EfuridePalette.cream,
      ),
      child: SafeArea(
        bottom: false,
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(8, 8, 16, 12),
              child: Row(
                children: [
                  IconButton(
                    onPressed: () => Navigator.pop(context),
                    icon: const Icon(Icons.arrow_back, color: EfuridePalette.ink),
                  ),
                  Expanded(
                    child: Text(widget.storeName,
                        style: const TextStyle(
                          color: EfuridePalette.ink,
                          fontSize: 17,
                          fontWeight: FontWeight.w900,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis),
                  ),
                ],
              ),
            ),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.fromLTRB(16, 14, 16, 16),
              decoration: const BoxDecoration(
                color: EfuridePalette.cream,
                borderRadius: BorderRadius.only(
                  topLeft:  Radius.circular(24),
                  topRight: Radius.circular(24),
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      if (_partner != null)
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 8, vertical: 4),
                          decoration: BoxDecoration(
                            color: EfuridePalette.accent
                                .withValues(alpha: 0.20),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              const Icon(Icons.star,
                                  size: 12, color: EfuridePalette.accent),
                              const SizedBox(width: 4),
                              Text(_partner!.rating.toStringAsFixed(1),
                                  style: const TextStyle(
                                    color: EfuridePalette.accent,
                                    fontSize: 13.5,
                                    fontWeight: FontWeight.w900,
                                  )),
                            ],
                          ),
                        ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Text(widget.storeAddress,
                            style: const TextStyle(
                              color: EfuridePalette.inkMuted,
                              fontSize: 14,
                              fontWeight: FontWeight.w600,
                            ),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Container(
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: TextField(
                      controller: _searchCtrl,
                      style: const TextStyle(
                        fontSize: 14.5, color: EfuridePalette.ink),
                      decoration: InputDecoration(
                        hintText: t.t('search_products'),
                        hintStyle: const TextStyle(
                          fontSize: 14, color: EfuridePalette.inkMuted),
                        prefixIcon: const Icon(Icons.search,
                            color: EfuridePalette.inkMuted, size: 18),
                        border: InputBorder.none,
                        contentPadding: const EdgeInsets.symmetric(
                            horizontal: 12, vertical: 14),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _body() {
    if (_loading) {
      return Center(child: CircularProgressIndicator(color: _accent));
    }

    if (_error != null) {
      return Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.wifi_off_rounded,
                size: 56, color: Colors.grey.shade400),
            const SizedBox(height: 12),
            Text(tr('Could not load the menu'),
                style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700)),
            const SizedBox(height: 8),
            TextButton(onPressed: _load, child: Text(tr('Retry'))),
          ],
        ),
      );
    }

    if (_all.isEmpty) {
      return Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            KIcon(Icons.inventory_2_outlined,
                size: 56, color: Colors.grey.shade400),
            const SizedBox(height: 12),
            Text(tr('No items yet'),
                style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700)),
          ],
        ),
      );
    }

    final groups = _grouped;
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 100),
      children: [
        for (final entry in groups.entries) ...[
          Padding(
            padding: const EdgeInsets.only(left: 4, bottom: 10),
            child: Text(entry.key,
                style: const TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w800,
                  color: EfuridePalette.ink,
                )),
          ),
          ...entry.value.map(_itemCard),
          const SizedBox(height: 20),
        ],
      ],
    );
  }

  Widget _itemCard(Product p) {
    final qty = context.watch<CartProvider>().qtyFor(p.id);

    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
          color: qty > 0 ? _accent.withValues(alpha: 0.5) : EfuridePalette.divider,
          width: qty > 0 ? 1.5 : 1,
        ),
      ),
      child: Row(
        children: [
          ProductThumb(
            imageUrl: p.imageUrl,
            background: _accent.withValues(alpha: 0.12),
            fallback: p.emoji != null && p.emoji!.isNotEmpty
                ? Text(p.emoji!, style: const TextStyle(fontSize: 30))
                : Icon(
                    widget.serviceType == 'Pharmacy'
                        ? Icons.medication
                        : Icons.shopping_basket,
                    color: _accent,
                    size: 26,
                  ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(p.name,
                    style: const TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w800,
                      color: EfuridePalette.ink,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis),
                if ((p.description ?? '').isNotEmpty) ...[
                  const SizedBox(height: 2),
                  Text(p.description!,
                      style: const TextStyle(
                        fontSize: 13,
                        color: EfuridePalette.inkMuted,
                        height: 1.3,
                      ),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis),
                ],
                const SizedBox(height: 6),
                Text(CountryConfig.money(p.price),
                    style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w900,
                      color: _accent,
                    )),
              ],
            ),
          ),
          const SizedBox(width: 8),
          qty == 0
              ? GestureDetector(
                  onTap: () => _addToCart(p),
                  child: Container(
                    width: 36, height: 36,
                    decoration: BoxDecoration(
                      color: _accent,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: const Icon(Icons.add, color: Colors.white, size: 20),
                  ),
                )
              : Container(
                  decoration: BoxDecoration(
                    color: _accent,
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Row(
                    children: [
                      GestureDetector(
                        onTap: () => context.read<CartProvider>().decrement(p.id),
                        child: const SizedBox(
                          width: 34, height: 36,
                          child: Icon(Icons.remove, color: Colors.white, size: 18),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 4),
                        child: Text('$qty',
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 14,
                              fontWeight: FontWeight.w900,
                            )),
                      ),
                      GestureDetector(
                        onTap: () => context.read<CartProvider>().increment(p.id),
                        child: const SizedBox(
                          width: 34, height: 36,
                          child: Icon(Icons.add, color: Colors.white, size: 18),
                        ),
                      ),
                    ],
                  ),
                ),
        ],
      ),
    );
  }

  Widget? _cartBar() {
    final t = S.of(context);
    final cart = context.watch<CartProvider>();
    if (cart.isEmpty) return null;

    return Container(
      padding: EdgeInsets.fromLTRB(
        16, 12, 16, 12 + MediaQuery.of(context).padding.bottom,
      ),
      decoration: BoxDecoration(
        color: Colors.white,
        border: const Border(top: BorderSide(color: EfuridePalette.divider)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.05),
            blurRadius: 10,
            offset: const Offset(0, -3),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 40, height: 40,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: _accent,
              borderRadius: BorderRadius.circular(10),
            ),
            child: Text('${cart.itemCount}',
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 15,
                  fontWeight: FontWeight.w900,
                )),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(t.t('subtotal'),
                    style: const TextStyle(
                        fontSize: 13, color: EfuridePalette.inkMuted)),
                Text(CountryConfig.money(cart.subtotal),
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w900,
                      color: EfuridePalette.ink,
                    )),
              ],
            ),
          ),
          ElevatedButton(
            onPressed: _openCart,
            style: ElevatedButton.styleFrom(
              backgroundColor: _accent,
              foregroundColor: Colors.white,
              minimumSize: const Size(140, 50),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12)),
              elevation: 0,
            ),
            child: Text(t.t('view_cart'),
                style: const TextStyle(
                    fontSize: 14, fontWeight: FontWeight.w900)),
          ),
        ],
      ),
    );
  }
}
