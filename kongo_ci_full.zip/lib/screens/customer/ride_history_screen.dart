﻿// lib/screens/customer/ride_history_screen.dart

import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:intl/intl.dart';
import 'package:efuride_app/config/country_config.dart';
import 'package:efuride_app/config/app_images.dart';
import 'package:efuride_app/widgets/app_image.dart';
import 'package:efuride_app/utils/app_error.dart';
import 'package:efuride_app/utils/error_ui.dart';
import 'package:efuride_app/l10n/app_strings.dart';
import 'package:efuride_app/widgets/k_icon.dart';

class _Palette {
  static const cream = Color(0xFFFAF6EE);
  static const ink = Color(0xFF1A1A1A);
  static const inkMuted = Color(0xFF575047);
  static const accent = Color(0xFFF2B705);
  static const accentInk = Color(0xFF0B1220);
  static const divider = Color(0xFFE8E2D5);
  static const completed = Color(0xFF34C759);
  static const cancelled = Color(0xFFE53935);
}

class RideHistoryScreen extends StatefulWidget {
  const RideHistoryScreen({super.key});

  @override
  State<RideHistoryScreen> createState() => _RideHistoryScreenState();
}

class _RideHistoryScreenState extends State<RideHistoryScreen> {
  String _tab = 'Ride';
  bool _isLoading = true;
  AppError? _error;

  List<Map<String, dynamic>> _rideHistory = [];
  List<Map<String, dynamic>> _deliveryHistory = [];

  @override
  void initState() {
    super.initState();
    _fetchAll();
  }

  Future<void> _fetchAll() async {
    setState(() {
      _isLoading = true;
      _error = null;
    });

    try {
      final userId = Supabase.instance.client.auth.currentUser?.id;
      if (userId == null) throw Exception('Not signed in');

      final response = await Supabase.instance.client
          .from('rides')
          .select(
              'id, service_type, pickup_address, dropoff_address, status, fare, created_at, vehicle_type')
          .eq('customer_id', userId)
          .inFilter('status', ['completed', 'cancelled'])
          .order('created_at', ascending: false);

      final all = List<Map<String, dynamic>>.from(response);

      final rides = <Map<String, dynamic>>[];
      final deliveries = <Map<String, dynamic>>[];

      for (final r in all) {
        final type = (r['service_type'] ?? 'Ride').toString().toLowerCase();
        if (type == 'delivery') {
          deliveries.add(r);
        } else {
          rides.add(r);
        }
      }

      if (!mounted) return;
      setState(() {
        _rideHistory = rides;
        _deliveryHistory = deliveries;
        _isLoading = false;
        _error = null;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _isLoading = false;
        _error = AppError.from(e, onRetry: _fetchAll);
      });
    }
  }

  List<Map<String, dynamic>> get _currentList =>
      _tab == 'Ride' ? _rideHistory : _deliveryHistory;

  double get _totalSpend => _currentList
      .where((r) => (r['status'] ?? '').toString().toLowerCase() == 'completed')
      .fold(0.0, (sum, r) => sum + ((r['fare'] ?? 0) as num).toDouble());

  int get _completedCount => _currentList
      .where((r) => (r['status'] ?? '').toString().toLowerCase() == 'completed')
      .length;

  double get _thisMonthSpend {
    final now = DateTime.now();
    final start = DateTime(now.year, now.month, 1);
    return _currentList
        .where((r) =>
            (r['status'] ?? '').toString().toLowerCase() == 'completed' &&
            (DateTime.tryParse(r['created_at']?.toString() ?? '')
                    ?.isAfter(start) ??
                false))
        .fold(0.0, (sum, r) => sum + ((r['fare'] ?? 0) as num).toDouble());
  }

  String _formatDate(String? dateStr) {
    if (dateStr == null) return 'Unknown date';
    try {
      final date = DateTime.parse(dateStr).toLocal();
      final now = DateTime.now();
      final today = DateTime(now.year, now.month, now.day);
      final day = DateTime(date.year, date.month, date.day);

      if (day == today) {
        return 'Today · ${DateFormat('h:mm a').format(date)}';
      }
      final yesterday = today.subtract(const Duration(days: 1));
      if (day == yesterday) {
        return 'Yesterday · ${DateFormat('h:mm a').format(date)}';
      }
      return DateFormat('MMM d, yyyy · h:mm a').format(date);
    } catch (_) {
      return dateStr;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _Palette.cream,
      appBar: AppBar(
        backgroundColor: _Palette.cream,
        elevation: 0,
        automaticallyImplyLeading: false, // <--- REMOVES THE BACK ARROW
        iconTheme: const IconThemeData(color: _Palette.ink),
        title: Text(
          tr('My Rides'),
          style: TextStyle(
            color: _Palette.ink,
            fontWeight: FontWeight.bold,
            fontSize: 18,
          ),
        ),
        actions: [
          // Optional: Add a sign-out button here if you want users to log out from this screen
          IconButton(
            icon: const KIcon(Icons.logout, color: _Palette.ink),
            tooltip: tr('Sign Out'),
            onPressed: () async {
              await Supabase.instance.client.auth.signOut();
              // The AuthProvider or main.dart listener will handle routing to login
            },
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 4, 16, 12),
            child: Container(
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(30),
                border: Border.all(color: _Palette.divider),
              ),
              child: SegmentedButton<String>(
                segments: [
                  ButtonSegment(
                    value: 'Ride',
                    label: Text(tr('Rides')),
                    icon: AppImage(
                      AppImages.driverSedan,
                      size: 18,
                      fallbackIcon: Icons.local_taxi,
                    ),
                  ),
                  ButtonSegment(
                    value: 'Delivery',
                    label: Text(tr('Deliveries')),
                    icon: AppImage(
                      AppImages.deliveryTruck,
                      size: 18,
                      fallbackIcon: Icons.local_shipping,
                    ),
                  ),
                ],
                selected: {_tab},
                style: SegmentedButton.styleFrom(
                  backgroundColor: Colors.white,
                  selectedBackgroundColor: _Palette.accent,
                  selectedForegroundColor: _Palette.accentInk,
                  foregroundColor: _Palette.inkMuted,
                ),
                onSelectionChanged: (s) => setState(() => _tab = s.first),
              ),
            ),
          ),

          if (!_isLoading && _error == null && _currentList.isNotEmpty)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: _summaryCard(),
            ),

          const SizedBox(height: 12),

          Expanded(
            child: RefreshIndicator(
              onRefresh: _fetchAll,
              color: _Palette.accent,
              child: _buildBody(),
            ),
          ),
        ],
      ),
    );
  }

  Widget _summaryCard() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: _Palette.divider),
      ),
      child: Row(
        children: [
          Expanded(
            child: _summaryStat(
              'Total ${_tab == 'Ride' ? 'rides' : 'deliveries'}',
              '$_completedCount',
            ),
          ),
          Container(width: 1, height: 36, color: _Palette.divider),
          Expanded(
            child: _summaryStat(
              'This month',
              CountryConfig.money(_thisMonthSpend),
            ),
          ),
          Container(width: 1, height: 36, color: _Palette.divider),
          Expanded(
            child: _summaryStat(
              'Total spent',
              CountryConfig.money(_totalSpend),
            ),
          ),
        ],
      ),
    );
  }

  Widget _summaryStat(String label, String value) {
    return Column(
      children: [
        Text(
          label,
          style: const TextStyle(
              fontSize: 13,
              color: _Palette.inkMuted,
              fontWeight: FontWeight.w600),
          textAlign: TextAlign.center,
        ),
        const SizedBox(height: 4),
        Text(
          value,
          style: const TextStyle(
              fontSize: 15,
              fontWeight: FontWeight.bold,
              color: _Palette.ink),
          textAlign: TextAlign.center,
        ),
      ],
    );
  }

  Widget _buildBody() {
    if (_isLoading) {
      return const Center(
          child: CircularProgressIndicator(color: _Palette.accent));
    }

    if (_error != null) {
      return ListView(
        physics: const AlwaysScrollableScrollPhysics(),
        children: [
          const SizedBox(height: 60),
          ErrorUI.inline(_error!),
        ],
      );
    }

    if (_currentList.isEmpty) {
      return ListView(
        physics: const AlwaysScrollableScrollPhysics(),
        children: [
          const SizedBox(height: 60),
          Center(
            child: AppImage(
              _tab == 'Ride'
                  ? AppImages.driverSedan
                  : AppImages.deliveryTruck,
              size: 80,
              tint: _Palette.inkMuted,
              fallbackIcon: _tab == 'Ride'
                  ? Icons.directions_car_outlined
                  : Icons.local_shipping_outlined,
            ),
          ),
          const SizedBox(height: 12),
          Center(
            child: Text(
              _tab == 'Ride' ? 'No rides yet' : 'No deliveries yet',
              style: const TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.bold,
                  color: _Palette.ink),
            ),
          ),
          const SizedBox(height: 4),
          Center(
            child: Text(
              tr('Your trips will appear here'),
              style: TextStyle(fontSize: 13.5, color: _Palette.inkMuted),
            ),
          ),
        ],
      );
    }

    return ListView.separated(
      padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
      itemCount: _currentList.length,
      separatorBuilder: (_, __) => const SizedBox(height: 8),
      itemBuilder: (_, i) => _historyTile(_currentList[i]),
    );
  }

  Widget _historyTile(Map<String, dynamic> ride) {
    final status = (ride['status'] ?? '').toString().toLowerCase();
    final isCancelled = status == 'cancelled';
    final isCompleted = status == 'completed';
    final fare = (ride['fare'] ?? 0).toDouble();
    final pickup = (ride['pickup_address'] ?? '').toString();
    final dropoff = (ride['dropoff_address'] ?? '').toString();
    final vehicleType = (ride['vehicle_type'] ?? '').toString();
    final date = _formatDate(ride['created_at']?.toString());
    // Parcels and shop orders (food, grocery, pharmacy) are deliveries.
    final isDelivery =
        (ride['service_type'] ?? 'Ride').toString().toLowerCase() != 'ride';

    // First part of an address; never raw coordinates or a bare number.
    String short(String s) {
      final parts = s
          .split(RegExp(r'[,·]'))
          .map((p) => p.trim())
          .where((p) => p.isNotEmpty)
          .where((p) => !RegExp(r'^-?\d+(\.\d+)?$').hasMatch(p))
          .toList();
      if (parts.isEmpty) return s.trim().isEmpty ? '—' : tr('Pinned location');
      return parts.first;
    }

    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: _Palette.divider),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.only(top: 2),
                child: Icon(
                  isCancelled ? Icons.cancel_outlined : Icons.check_circle,
                  color:
                      isCancelled ? _Palette.cancelled : _Palette.completed,
                  size: 20,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        AppImage(
                          isDelivery
                              ? AppImages.deliveryTruck
                              : AppImages.driverSedan,
                          size: 20,
                          fallbackIcon: isDelivery
                              ? Icons.local_shipping
                              : Icons.local_taxi,
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                short(pickup),
                                style: const TextStyle(
                                  fontSize: 15,
                                  fontWeight: FontWeight.bold,
                                  color: _Palette.ink,
                                ),
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                              ),
                              Text(
                                '→ ${short(dropoff)}',
                                style: const TextStyle(
                                  fontSize: 14.5,
                                  fontWeight: FontWeight.w600,
                                  color: _Palette.ink,
                                ),
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                              ),
                            ],
                          ),
                        ),
                        Text(
                          isCompleted
                              ? CountryConfig.money(fare)
                              : '—', // cancelled: nothing was paid
                          style: TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.bold,
                            color: isCompleted
                                ? _Palette.ink
                                : _Palette.inkMuted,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 4),
                    Text(
                      date,
                      style: const TextStyle(
                          fontSize: 13, color: _Palette.inkMuted),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              _badge(
                isCancelled ? 'Cancelled' : 'Completed',
                isCancelled ? _Palette.cancelled : _Palette.completed,
              ),
              if (vehicleType.isNotEmpty) ...[
                const SizedBox(width: 6),
                _badge(vehicleType, _Palette.inkMuted),
              ],
            ],
          ),
        ],
      ),
    );
  }

  Widget _badge(String text, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: color.withOpacity(0.12),
        borderRadius: BorderRadius.circular(6),
      ),
      child: Text(
        text,
        style: TextStyle(
          fontSize: 12,
          fontWeight: FontWeight.w600,
          color: color,
        ),
      ),
    );
  }
}
