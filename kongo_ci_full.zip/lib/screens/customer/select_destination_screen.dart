// lib/screens/customer/select_destination_screen.dart
//
// Destination picker for rides and parcels.
//   • Search      → Google Places (biased to the pickup, kept in-country)
//   • Map tap     → Google reverse geocode (real address, not coordinates)
//   • Route + ETA → Google Routes (traffic-aware)
// All Google calls go through GoogleMapsService (Supabase proxy).

import 'dart:async';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:efuride_app/services/favorite_places_service.dart';
import 'package:efuride_app/widgets/photo_source_sheet.dart';
import 'package:efuride_app/config/efuride_palette.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'package:image_picker/image_picker.dart' show XFile;
import 'package:efuride_app/services/pricing_service.dart';
import 'package:efuride_app/services/storage_service.dart';
import 'package:efuride_app/config/app_images.dart';
import 'package:efuride_app/config/country_config.dart';
import 'package:efuride_app/l10n/app_strings.dart';
import 'package:efuride_app/services/google_maps_service.dart';
import 'package:efuride_app/widgets/app_image.dart';
import 'package:efuride_app/widgets/debouncer.dart';
import 'package:efuride_app/widgets/map_markers.dart';
import 'package:efuride_app/utils/app_error.dart';
import 'package:efuride_app/utils/error_ui.dart';
import 'package:provider/provider.dart';
import 'package:efuride_app/providers/auth_provider.dart';
import 'package:efuride_app/widgets/payment_choice.dart';
import 'package:efuride_app/widgets/k_icon.dart';

class _Palette {
  static const ink = Color(0xFF1A1A1A);
  static const inkMuted = Color(0xFF575047);
  static const accent = Color(0xFFE88A1A);
  static const accentInk = Color(0xFF0B1220);
  static const pickup = Color(0xFF1E5A96);
  static const dropoff = Color(0xFFE53935);
  static const divider = Color(0xFFE8E2D5);
  static const greyBg = Color(0xFFF3F3F3);
  static const blue = Color(0xFF1E5A96);
  static const pickupGreen = Color(0xFF34C759);
}

/// True if the vehicle row is bookable in [mode] ('Ride' | 'Delivery').
/// Prefers `service_types` (array) and falls back to `service_type` (string).
bool _vehicleServesMode(Map<String, dynamic> v, String mode) {
  final target = mode.trim().toLowerCase();

  final raw = v['service_types'];
  if (raw is List && raw.isNotEmpty) {
    return raw
        .map((e) => e.toString().trim().toLowerCase())
        .contains(target);
  }
  final single =
      (v['service_type'] ?? 'Ride').toString().trim().toLowerCase();
  return single == target;
}

class SelectDestinationScreen extends StatefulWidget {
  final String initialServiceMode;
  final LatLng pickupLatLng;

  /// Pickup address shown in the route card (optional).
  final String? pickupAddress;

  const SelectDestinationScreen({
    super.key,
    this.initialServiceMode = 'Ride',
    required this.pickupLatLng,
    this.pickupAddress,
  });

  @override
  State<SelectDestinationScreen> createState() =>
      _SelectDestinationScreenState();
}

class _SelectDestinationScreenState extends State<SelectDestinationScreen> {
  GoogleMapController? _mapController;
  final Debouncer _debouncer = Debouncer(milliseconds: 350);
  final TextEditingController _searchCtrl = TextEditingController();
  final FocusNode _searchFocus = FocusNode();

  late String serviceMode;
  List<Map<String, dynamic>> _vehicles = [];
  String selectedVehicle = '';
  bool _loading = true;

  List<PlacePrediction> _suggestions = [];
  bool _searching = false;
  bool _isTyping = false;
  int _searchRequestId = 0;
  bool _resolvingPlace = false;

  final Map<String, List<PlacePrediction>> _searchCache = {};
  static const int _searchCacheMax = 40;

  LatLng? _destination;
  String _destinationAddress = '';

  // Pickup can be changed here (starts at the customer's location).
  late LatLng _pickup;
  String _pickupAddress = '';
  final TextEditingController _pickupCtrl = TextEditingController();
  final FocusNode _pickupFocus = FocusNode();

  /// Which box the search results fill: 'pickup' or 'dropoff'.
  String _activeField = 'dropoff';

  /// "Choose on map": the next map tap sets this field.
  bool _pickingOnMap = false;

  // ── Parcel mode ──
  String _parcelSize = 'medium'; // small | medium | large | xl
  bool _fragile = false;

  /// Parcel payment ('cash' | 'wallet' | 'card'); null = not picked yet.
  String? _parcelPay;
  String get _parcelPayMethod {
    final bal = context.read<AuthProvider>().walletBalance;
    final p = _parcelPay ?? PaymentChoice.suggested(_parcelFare, bal);
    if (p == 'wallet' && bal < _parcelFare) return 'cash';
    if (p == 'card' && !PaymentChoice.cardAvailable) return 'cash';
    return p;
  }
  bool _urgent = false;
  final TextEditingController _recipientNameCtrl = TextEditingController();
  final TextEditingController _recipientPhoneCtrl = TextEditingController();
  final TextEditingController _parcelNoteCtrl = TextEditingController();
  XFile? _packagePhoto;
  bool _sendingParcel = false;

  bool get _isParcel => serviceMode == 'Delivery';

  double _routeDistanceKm = 0.0;
  double _fare = 0.0;
  int? _etaMinutes;
  List<LatLng> _routePoints = [];
  bool _routeIsApproximate = false;
  int _routeRequestId = 0;

  double _adminBaseFare = 25.0;
  double _adminPerKmRate = 12.0;
  double _adminMinFare = 25.0;
  double _adminSurge = 1.0;

  List<Map<String, dynamic>> _recentDestinations = [];

  BitmapDescriptor? _pickupIcon;
  BitmapDescriptor? _destinationIcon;

  S get _t => S.of(context);

  @override
  void initState() {
    super.initState();
    PricingService.changes.addListener(_onPricesChanged);
    FavoritePlacesService.listFavorites().then((l) {
      if (mounted) setState(() => _saved = l);
    });
    serviceMode = widget.initialServiceMode;
    // Fresh wallet balance for the payment choice.
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) context.read<AuthProvider>().refresh();
    });
    _pickup = widget.pickupLatLng;
    final given = (widget.pickupAddress ?? '').trim();
    if (_looksLikeRealAddress(given)) {
      _pickupAddress = given;
      _pickupCtrl.text = given.split(',').first.trim();
    } else {
      _pickupCtrl.text = '';
      _lookUpPickupAddress();
    }
    _pickupFocus.addListener(() {
      if (_pickupFocus.hasFocus) setState(() => _activeField = 'pickup');
    });
    _searchFocus.addListener(() {
      if (_searchFocus.hasFocus) setState(() => _activeField = 'dropoff');
    });
    // Open ready to type the destination.
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) _searchFocus.requestFocus();
    });
    _pickupIcon = MapMarkers.pickup();
    _destinationIcon = MapMarkers.dropoff();
    _searchCtrl.addListener(_onSearchTextChanged);
    _pickupCtrl.addListener(_onSearchTextChanged);
    _loadAll();
    _loadRecentDestinations();
  }

  void _onPricesChanged() {
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    PricingService.changes.removeListener(_onPricesChanged);
    _debouncer.dispose();
    _searchCtrl.removeListener(_onSearchTextChanged);
    _pickupCtrl.removeListener(_onSearchTextChanged);
    _searchCtrl.dispose();
    _searchFocus.dispose();
    _pickupCtrl.dispose();
    _pickupFocus.dispose();
    _recipientNameCtrl.dispose();
    _recipientPhoneCtrl.dispose();
    _parcelNoteCtrl.dispose();
    super.dispose();
  }

  /// "22", "-34.07, 18.84", "Detecting location…" are not addresses.
  static bool _looksLikeRealAddress(String a) {
    final t = a.trim();
    if (t.length < 4) return false;
    if (!RegExp(r'[A-Za-zÀ-ÿ]{3,}').hasMatch(t)) return false;
    if (RegExp(r'^-?\d+\.\d+\s*,\s*-?\d+\.\d+$').hasMatch(t)) return false;
    final low = t.toLowerCase();
    if (low.contains('detecting') || low.contains('locating')) return false;
    return true;
  }

  /// Real street address for the pickup point (from Google).
  Future<void> _lookUpPickupAddress() async {
    final at = _pickup;
    final place = await GoogleMapsService.reverseGeocode(at);
    if (!mounted || place == null || _pickup != at) return;
    setState(() {
      _pickupAddress = place.displayAddress;
      if (!_pickupFocus.hasFocus) _pickupCtrl.text = place.shortLabel;
    });
  }

  void _onSearchTextChanged() {
    final isTyping = _activeCtrl.text.trim().isNotEmpty &&
        (_searchFocus.hasFocus || _pickupFocus.hasFocus);
    if (isTyping != _isTyping) {
      setState(() => _isTyping = isTyping);
    }
  }

  // ============================================================
  // VEHICLE PNG MAPPING — mode-aware (bikes in both Ride & Delivery)
  // ============================================================
  bool _isBike(Map<String, dynamic> v) {
    final icon = (v['icon'] ?? '').toString().toLowerCase();
    final name = (v['name'] ?? '').toString().toLowerCase();
    return icon == 'bike' ||
        icon == 'motorbike' ||
        icon == 'motorcycle' ||
        icon == 'scooter' ||
        name.contains('bike') ||
        name.contains('scooter') ||
        name.contains('moto');
  }

  String _vehicleAsset(Map<String, dynamic> v) {
    final icon = (v['icon'] ?? 'car').toString().toLowerCase();
    final name = (v['name'] ?? '').toString().toLowerCase();

    if (_isBike(v)) return AppImages.driverBike;

    // Each class its own picture (XL no longer shows the van picture).
    if (name.contains('truck') || icon == 'truck') {
      return AppImages.deliveryTruck;
    }
    if (name.contains('large van') || name.contains('large_van')) {
      return 'assets/images/vehicle_large_van.png';
    }
    if (name.contains('xl') || name.contains('suv') || name.contains('minivan')) {
      return 'assets/images/vehicle_xl.png';
    }
    if (name.contains('van') || name.contains('bus') ||
        icon == 'bus' || icon == 'van') {
      return AppImages.driverVan;
    }
    return AppImages.driverSedan;
  }

  // ============================================================
  // LOADERS
  // ============================================================
  Future<void> _loadAll() async {
    await Future.wait([_loadVehicles(), _loadPricingSettings()]);
    if (mounted) {
      setState(() => _loading = false);
      _recompute();
    }
  }

  List<Map<String, dynamic>> _filterByMode(List<Map<String, dynamic>> list) {
    return list.where((v) => _vehicleServesMode(v, serviceMode)).toList();
  }

  Future<void> _loadVehicles() async {
    try {
      final res = await Supabase.instance.client
          .from('vehicle_types')
          .select()
          .eq('is_active', true)
          .order('display_order')
          .timeout(const Duration(seconds: 30));
      final list = List<Map<String, dynamic>>.from(res);
      if (!mounted) return;
      setState(() {
        _vehicles = list;
        final filtered = _filterByMode(list);
        if (filtered.isNotEmpty) {
          selectedVehicle = filtered.first['name'] as String;
        }
      });
    } catch (e) {
      debugPrint('loadVehicles failed: $e');
      if (!mounted) return;
      ErrorUI.showSnack(
        context,
        AppError(
          title: _t.t('sd_options_failed'),
          message: _t.t('sd_tap_retry'),
          icon: Icons.directions_car_outlined,
          actionLabel: _t.t('retry'),
          onRetry: _loadVehicles,
        ),
      );
    }
  }

  Future<void> _loadPricingSettings() async {
    // Prices for the user's country, in its own currency.
    try {
      final p = await PricingService.current();
      _adminBaseFare = p.baseFare;
      _adminPerKmRate = p.perKmRate;
      _adminMinFare = p.minimumFare;
      _adminSurge = p.surge;
    } catch (e) {
      debugPrint('Could not load pricing (using defaults): $e');
    }
  }

  Future<void> _loadRecentDestinations() async {
    try {
      final userId = Supabase.instance.client.auth.currentUser?.id;
      if (userId == null) return;
      final rows = await Supabase.instance.client
          .from('rides')
          .select('dropoff_address, dropoff_lat, dropoff_lng')
          .eq('customer_id', userId)
          .eq('status', 'completed')
          .order('created_at', ascending: false)
          .limit(20)
          .timeout(const Duration(seconds: 30));

      final seen = <String>{};
      final list = <Map<String, dynamic>>[];
      for (final r in rows) {
        final addr = (r['dropoff_address'] ?? '').toString().trim();
        if (!_looksLikeRealAddress(addr) || seen.contains(addr)) continue;
        if (r['dropoff_lat'] == null || r['dropoff_lng'] == null) continue;
        seen.add(addr);
        list.add({
          'address': addr,
          'lat': r['dropoff_lat'],
          'lng': r['dropoff_lng'],
        });
        if (list.length >= 5) break;
      }
      if (mounted) setState(() => _recentDestinations = list);
    } catch (e) {
      debugPrint('recent destinations failed: $e');
    }
  }

  List<Map<String, dynamic>> get _filteredVehicles => _filterByMode(_vehicles);

  double _distanceBetween(LatLng a, LatLng b) {
    const R = 6371.0;
    final dLat = (b.latitude - a.latitude) * math.pi / 180;
    final dLng = (b.longitude - a.longitude) * math.pi / 180;
    final h = math.sin(dLat / 2) * math.sin(dLat / 2) +
        math.cos(a.latitude * math.pi / 180) *
            math.cos(b.latitude * math.pi / 180) *
            math.sin(dLng / 2) *
            math.sin(dLng / 2);
    return 2 * R * math.asin(math.sqrt(h));
  }

  TextEditingController get _activeCtrl =>
      _activeField == 'pickup' ? _pickupCtrl : _searchCtrl;

  // ============================================================
  // SEARCH (Google Places)
  // ============================================================
  void _onSearch(String query) {
    final trimmed = query.trim();
    final requestId = ++_searchRequestId;
    if (trimmed.isEmpty) {
      setState(() {
        _suggestions = [];
        _searching = false;
      });
      return;
    }
    setState(() => _searching = true);

    _debouncer.debounce(() async {
      final cacheKey = trimmed.toLowerCase();
      final cached = _searchCache[cacheKey];
      if (cached != null) {
        if (requestId != _searchRequestId || !mounted) return;
        setState(() {
          _suggestions = cached;
          _searching = false;
        });
        return;
      }

      try {
        final preds = await GoogleMapsService.autocomplete(
          query: trimmed,
          origin: _pickup,
          radiusMeters: 50000,
        );
        if (requestId != _searchRequestId || !mounted) return;
        if (_searchCache.length >= _searchCacheMax) {
          _searchCache.remove(_searchCache.keys.first);
        }
        _searchCache[cacheKey] = preds;
        setState(() {
          _suggestions = preds;
          _searching = false;
        });
      } catch (e) {
        if (requestId != _searchRequestId || !mounted) return;
        setState(() => _searching = false);
        ErrorUI.showSnack(
          context,
          AppError(
            title: _t.t('sd_search_failed'),
            message: _t.t('sd_search_failed_hint'),
            icon: Icons.search_off_rounded,
            actionLabel: _t.t('retry'),
            onRetry: () => _onSearch(_activeCtrl.text),
          ),
        );
      }
    });
  }

  Future<void> _onSuggestionTap(PlacePrediction p) async {
    if (_resolvingPlace) return;
    setState(() => _resolvingPlace = true);
    PlaceDetails? details;
    try {
      details = await GoogleMapsService.details(p.placeId);
    } catch (_) {
      details = null;
    }
    if (!mounted) return;
    setState(() => _resolvingPlace = false);

    if (details == null) {
      ErrorUI.showSnack(
        context,
        AppError(
          title: _t.t('sd_search_failed'),
          message: _t.t('sd_search_failed_hint'),
          icon: Icons.location_off,
        ),
      );
      return;
    }

    var address = details.displayAddress;
    var label = details.shortLabel;

    // A bare street with no number: ask for the house number so the
    // driver lands at the right gate. The pin stays on the street.
    if (p.isStreetOnly &&
        (details.houseNumber == null || details.houseNumber!.isEmpty)) {
      final house = await _askHouseNumber(label, details.contextLabel);
      if (!mounted) return;
      if (house != null && house.isNotEmpty) {
        label = '$house $label';
        address = '$house, $address';
      }
    }

    if (_activeField == 'pickup') {
      await _setPickup(point: details.latLng, label: label, address: address);
    } else {
      await _selectDestination(
        point: details.latLng,
        label: label,
        address: address,
      );
    }
  }

  /// New pickup point (from search or the map).
  Future<void> _setPickup({
    required LatLng point,
    required String label,
    required String address,
  }) async {
    setState(() {
      _pickup = point;
      _pickupAddress = address.isNotEmpty ? address : label;
      _pickupCtrl.text = label;
      _suggestions = [];
      _isTyping = false;
      _searching = false;
    });
    _pickupFocus.unfocus();
    if (_destination != null) {
      _applyFallbackDistance();
      _fitRoute();
      await _fetchRouteAndFare();
    } else {
      _mapController?.animateCamera(CameraUpdate.newLatLngZoom(point, 16));
      _searchFocus.requestFocus();
    }
  }

  Future<String?> _askHouseNumber(String street, String context_) async {
    final ctrl = TextEditingController();
    try {
      return await showDialog<String>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: Text(_t.t('sd_add_house')),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(street,
                  style: const TextStyle(fontWeight: FontWeight.w600)),
              if (context_.isNotEmpty)
                Padding(
                  padding: const EdgeInsets.only(top: 2),
                  child: Text(context_,
                      style:
                          const TextStyle(fontSize: 13.5, color: Color(0xFF575047))),
                ),
              const SizedBox(height: 8),
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: Colors.amber.shade50,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: Colors.amber.shade300),
                ),
                child: Text(
                  _t.t('sd_pin_on_street'),
                  style: const TextStyle(fontSize: 13, color: Colors.black87),
                ),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: ctrl,
                autofocus: true,
                decoration: InputDecoration(
                  labelText: _t.t('sd_house_number'),
                  hintText: _t.t('sd_house_number_hint'),
                  border: const OutlineInputBorder(),
                ),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx, null),
              child: Text(_t.t('skip')),
            ),
            ElevatedButton(
              onPressed: () => Navigator.pop(ctx, ctrl.text.trim()),
              child: Text(_t.t('ok')),
            ),
          ],
        ),
      );
    } finally {
      ctrl.dispose();
    }
  }

  Future<void> _selectDestination({
    required LatLng point,
    required String label,
    required String address,
  }) async {
    setState(() {
      _destination = point;
      _destinationAddress = address.isNotEmpty ? address : label;
      _suggestions = [];
      _searching = false;
      _searchCtrl.text = label;
      _isTyping = false;
      _routePoints = [];
      _routeDistanceKm = 0;
      _etaMinutes = null;
      _routeIsApproximate = false;
    });
    _searchFocus.unfocus();
    _applyFallbackDistance();
    _fitRoute();
    await _fetchRouteAndFare();
  }

  // Saved places (Home, Work...) offered in the search.
  List<Map<String, dynamic>> _saved = [];

  Future<void> _useSaved(Map<String, dynamic> r) async {
    final lat = r['lat'];
    final lng = r['lng'];
    if (lat == null || lng == null) return;
    final label = (r['label'] ?? r['name'] ?? '').toString();
    final address = (r['address'] ?? '').toString();
    final point = LatLng((lat as num).toDouble(), (lng as num).toDouble());
    if (_activeField == 'pickup') {
      await _setPickup(
          point: point, label: label, address: address.isEmpty ? label : address);
    } else {
      await _selectDestination(
          point: point,
          label: label,
          address: address.isEmpty ? label : address);
    }
  }

  Widget _savedRow(Map<String, dynamic> r) {
    final label = (r['label'] ?? r['name'] ?? '').toString();
    final home = FavoritePlacesService.isHomeLabel(label);
    return _optionRow(
      icon: home ? Icons.home_rounded : Icons.star_rounded,
      color: _Palette.accent,
      title: label,
      subtitle: (r['address'] ?? '').toString(),
      onTap: () => _useSaved(r),
    );
  }

  Future<void> _useRecentDestination(Map<String, dynamic> r) async {
    final lat = r['lat'];
    final lng = r['lng'];
    if (lat == null || lng == null) return;
    final address = (r['address'] ?? '').toString();
    await _selectDestination(
      point: LatLng((lat as num).toDouble(), (lng as num).toDouble()),
      label: address.split(',').first.trim(),
      address: address,
    );
  }

  /// Pickup back to where the customer is now.
  Future<void> _useCurrentLocation() async {
    await _setPickup(
      point: widget.pickupLatLng,
      label: _t.t('sd_current_location'),
      address: _t.t('sd_current_location'),
    );
    _lookUpPickupAddress();
  }

  void _startPickOnMap() {
    _pickupFocus.unfocus();
    _searchFocus.unfocus();
    setState(() {
      _pickingOnMap = true;
      _suggestions = [];
      _isTyping = false;
      _searching = false;
    });
  }

  /// Tap on the map → drop the pin and look up the real address.
  Future<void> _onMapTap(LatLng point) async {
    final pinnedLabel = _t.t('sd_pinned_location');
    if (_activeField == 'pickup' && (_pickingOnMap || _pickupFocus.hasFocus)) {
      setState(() => _pickingOnMap = false);
      await _setPickup(point: point, label: pinnedLabel, address: pinnedLabel);
      _lookUpPickupAddress();
      return;
    }
    setState(() => _pickingOnMap = false);
    setState(() {
      _destination = point;
      _destinationAddress = pinnedLabel;
      _routePoints = [];
      _suggestions = [];
      _isTyping = false;
      _searchCtrl.text = pinnedLabel;
      _routeDistanceKm = 0;
      _etaMinutes = null;
      _routeIsApproximate = false;
    });
    _searchFocus.unfocus();
    _applyFallbackDistance();
    unawaited(_fetchRouteAndFare());

    final place = await GoogleMapsService.reverseGeocode(point);
    if (!mounted || place == null) return;
    // Ignore if the user has picked somewhere else meanwhile.
    if (_destination != point) return;
    setState(() {
      _destinationAddress = place.displayAddress;
      _searchCtrl.text = place.shortLabel;
    });
  }

  void _applyFallbackDistance() {
    if (_destination == null) return;
    final straightKm = _distanceBetween(_pickup, _destination!);
    final approxKm = straightKm * 1.3;
    final approxMin = (approxKm / 30 * 60).round();
    if (!mounted) return;
    setState(() {
      _routeDistanceKm = approxKm;
      _etaMinutes = approxMin;
      _routePoints = [];
      _routeIsApproximate = true;
      _recompute();
    });
  }

  /// Google road route + ETA. Keeps the straight-line estimate if
  /// Google can't route (the fare is then marked "est.").
  Future<void> _fetchRouteAndFare() async {
    final dest = _destination;
    if (dest == null) return;
    final requestId = ++_routeRequestId;

    final selected = _filteredVehicles.firstWhere(
      (v) => v['name'] == selectedVehicle,
      orElse: () => <String, dynamic>{},
    );
    final route = await GoogleMapsService.route(
      _pickup,
      dest,
      twoWheeler: selected.isNotEmpty && _isBike(selected),
    );
    if (!mounted || requestId != _routeRequestId) return;
    if (route == null || route.points.isEmpty) return;

    setState(() {
      _routePoints = route.points;
      _routeDistanceKm = route.distanceKm;
      _etaMinutes = route.durationMin;
      _routeIsApproximate = false;
      _recompute();
    });
    _fitRoute();
  }

  void _fitRoute() {
    if (_destination == null || _mapController == null) return;
    final pts = <LatLng>[
      _pickup,
      _destination!,
      ..._routePoints,
    ];
    var minLat = pts.first.latitude, maxLat = pts.first.latitude;
    var minLng = pts.first.longitude, maxLng = pts.first.longitude;
    for (final p in pts) {
      minLat = math.min(minLat, p.latitude);
      maxLat = math.max(maxLat, p.latitude);
      minLng = math.min(minLng, p.longitude);
      maxLng = math.max(maxLng, p.longitude);
    }
    if (minLat == maxLat && minLng == maxLng) {
      _mapController!.animateCamera(
          CameraUpdate.newLatLngZoom(_destination!, 16));
      return;
    }
    _mapController!.animateCamera(
      CameraUpdate.newLatLngBounds(
        LatLngBounds(
          southwest: LatLng(minLat, minLng),
          northeast: LatLng(maxLat, maxLng),
        ),
        60,
      ),
    );
  }

  double _fareForVehicle(Map<String, dynamic> v) {
    final multiplier = (v['multiplier'] as num?)?.toDouble() ?? 1.0;
    final effectiveKm = _routeDistanceKm <= 0 ? 0.0 : _routeDistanceKm;
    double fare =
        (_adminBaseFare + (effectiveKm * _adminPerKmRate)) * _adminSurge *
            multiplier;
    if (fare < _adminMinFare) fare = _adminMinFare;
    return fare;
  }

  // ============================================================
  // PARCEL
  // ============================================================
  double _sizePrice(String size) {
    final p = PricingService.last;
    switch (size) {
      case 'small':
        return p.parcelSmall;
      case 'large':
        return p.parcelLarge;
      case 'xl':
        return p.parcelXl;
      default:
        return p.parcelMedium;
    }
  }

  /// Size price + distance, plus fragile / urgent extras.
  double get _parcelFare {
    final p = PricingService.last;
    final km = _routeDistanceKm <= 0 ? 0.0 : _routeDistanceKm;
    // Bigger vehicles (large van, truck) cost more, like on the server.
    double mult = 1.0;
    for (final v in _vehicles) {
      if (v['name'] == selectedVehicle) {
        mult = (v['multiplier'] as num?)?.toDouble() ?? 1.0;
        break;
      }
    }
    if (mult <= 0) mult = 1.0;
    var fare =
        (_sizePrice(_parcelSize) + km * _adminPerKmRate) * _adminSurge * mult;
    if (fare < _adminMinFare) fare = _adminMinFare;
    if (_fragile) fare += p.fragileFee;
    if (_urgent) fare += p.urgentFee;
    return double.parse(fare.toStringAsFixed(2));
  }

  Future<void> _pickPackagePhoto() async {
    final f = await pickPhotoLiveOrGallery(context,
        maxWidth: 1600, imageQuality: 70);
    if (f != null && mounted) setState(() => _packagePhoto = f);
  }

  void _say(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg, style: const TextStyle(fontSize: 15)),
      behavior: SnackBarBehavior.floating,
      backgroundColor: _Palette.dropoff,
    ));
  }

  /// Book the parcel straight from this screen; the home screen then
  /// tracks it like a ride.
  Future<void> _requestCourier() async {
    if (_sendingParcel || _destination == null) return;
    final name = _recipientNameCtrl.text.trim();
    final phone = _recipientPhoneCtrl.text.trim();
    if (name.isEmpty) { _say(_t.t('add_recipient_name')); return; }
    if (phone.replaceAll(RegExp(r'[^0-9]'), '').length < 7) {
      { _say(_t.t('add_recipient_phone')); return; }
    }
    final userId = Supabase.instance.client.auth.currentUser?.id;
    if (userId == null) { _say(_t.t('not_signed_in_hint')); return; }
    if (_parcelPay == 'wallet' && _parcelPayMethod != 'wallet') {
      _say(tr('Not enough in your wallet. Top up or choose cash.'));
      return;
    }

    setState(() => _sendingParcel = true);
    try {
      final otp = (math.Random.secure().nextInt(900000) + 100000).toString();
      final fare = _parcelFare;
      final note = _parcelNoteCtrl.text.trim();
      final extras = [
        _t.t('size_$_parcelSize'),
        if (_fragile) _t.t('fragile'),
        if (_urgent) _t.t('urgent'),
      ].join(' · ');

      final row = await Supabase.instance.client
          .from('rides')
          .insert({
            'customer_id': userId,
            'service_type': 'Delivery',
            'vehicle_type': selectedVehicle.isNotEmpty
                ? selectedVehicle
                : 'standard',
            'pickup_address': _pickupAddress.isNotEmpty
                ? _pickupAddress
                : _pickupCtrl.text.trim(),
            'dropoff_address': _destinationAddress,
            'pickup_lat': _pickup.latitude,
            'pickup_lng': _pickup.longitude,
            'dropoff_lat': _destination!.latitude,
            'dropoff_lng': _destination!.longitude,
            'status': 'pending',
            'fare': fare,
            'original_fare': fare,
            'distance_km':
                double.parse(_routeDistanceKm.toStringAsFixed(2)),
            'eta_minutes': _etaMinutes,
            'customer_note': note.isEmpty ? extras : '$extras — $note',
            'recipient_name': name,
            'recipient_phone': phone,
            'payment_method': _parcelPayMethod,
            'payment_status': 'pending',
            'pickup_otp': otp,
            'pickup_otp_verified': false,
            'is_bidding': false,
            'bid_status': 'none',
            'pricing_mode': 'algorithmic',
            'dispatch_mode': 'assign',
            'negotiation_state': 'none',
            'surge_multiplier': 1.0,
          })
          .select()
          .single()
          .timeout(const Duration(seconds: 20));
      final rideId = row['id'].toString();

      if (_packagePhoto != null) {
        try {
          final url = await StorageService.instance
              .uploadPackagePhoto(_packagePhoto!, rideId);
          if (url != null) {
            await Supabase.instance.client
                .from('rides')
                .update({'package_photo_url': url}).eq('id', rideId);
          }
        } catch (e) {
          debugPrint('package photo upload failed: $e');
        }
      }

      if (!mounted) return;
      Navigator.pop(context, {
        'serviceType': 'Delivery',
        'dropoff': _destinationAddress,
        'lat': _destination!.latitude,
        'lng': _destination!.longitude,
        'pickup': _pickupAddress,
        'pickup_lat': _pickup.latitude,
        'pickup_lng': _pickup.longitude,
        'distance': _routeDistanceKm,
        'fare': fare,
        'vehicle': selectedVehicle,
        'parcel_booking': {
          'ride_id': rideId,
          'fare': fare,
          'pickup_otp': otp,
          'is_bidding': false,
          'distance_km': _routeDistanceKm,
          'eta_minutes': _etaMinutes,
        },
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => _sendingParcel = false);
      ErrorUI.showSnack(context, AppError.from(e, onRetry: _requestCourier));
    }
  }

  void _recompute() {
    final filtered = _filteredVehicles;
    if (filtered.isEmpty) {
      _fare = 0.0;
      return;
    }
    if (!filtered.any((v) => v['name'] == selectedVehicle)) {
      selectedVehicle = filtered.first['name'] as String;
    }
    final v = filtered.firstWhere(
      (x) => x['name'] == selectedVehicle,
      orElse: () => <String, dynamic>{},
    );
    if (v.isEmpty) {
      _fare = 0.0;
      return;
    }
    _fare = _fareForVehicle(v);
  }

  // ============================================================
  // MAP
  // ============================================================
  Widget _buildMap() {
    final markers = <Marker>{
      Marker(
        markerId: const MarkerId('pickup'),
        position: _pickup,
        icon: _pickupIcon ?? BitmapDescriptor.defaultMarker,
        anchor: const Offset(0.5, 1.0),
      ),
      if (_destination != null)
        Marker(
          markerId: const MarkerId('destination'),
          position: _destination!,
          icon: _destinationIcon ?? BitmapDescriptor.defaultMarker,
          anchor: const Offset(0.5, 1.0),
        ),
    };

    final polylines = <Polyline>{
      if (_routePoints.isNotEmpty)
        Polyline(
          polylineId: const PolylineId('route'),
          points: _routePoints,
          width: 4,
          color: _routeIsApproximate
              ? _Palette.blue.withValues(alpha: 0.4)
              : _Palette.blue,
          startCap: Cap.roundCap,
          endCap: Cap.roundCap,
        ),
    };

    return GoogleMap(
      initialCameraPosition: CameraPosition(
        target: widget.pickupLatLng,
        zoom: 14,
      ),
      onMapCreated: (c) {
        _mapController = c;
        _fitRoute();
      },
      onTap: _onMapTap,
      myLocationEnabled: false,
      myLocationButtonEnabled: false,
      zoomControlsEnabled: false,
      compassEnabled: false,
      tiltGesturesEnabled: false,
      rotateGesturesEnabled: false,
      markers: markers,
      polylines: polylines,
    );
  }

  void _recenterOnRoute() => _fitRoute();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: EfuridePalette.cream,
      appBar: AppBar(
        backgroundColor: EfuridePalette.cream,
        foregroundColor: _Palette.ink,
        elevation: 0,
        scrolledUnderElevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: _Palette.ink),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          _isParcel ? _t.t('sd_send_parcel') : _t.t('sd_where_to'),
          style: const TextStyle(
            color: _Palette.ink,
            fontWeight: FontWeight.w800,
            fontSize: 19,
          ),
        ),
        centerTitle: true,
        actions: [
          IconButton(
            icon: const Icon(Icons.close, color: _Palette.ink),
            onPressed: () => Navigator.pop(context),
          ),
        ],
      ),
      body: Column(
        children: [
          // ── SERVICE TOGGLE ──
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 4, 16, 10),
            child: Container(
              decoration: BoxDecoration(
                color: _Palette.greyBg,
                borderRadius: BorderRadius.circular(30),
              ),
              child: SegmentedButton<String>(
                segments: [
                  ButtonSegment(
                    value: 'Ride',
                    label: Text(_t.t('svc_ride'),
                        style: const TextStyle(
                            fontSize: 16, fontWeight: FontWeight.w800)),
                    icon: const KIcon(Icons.local_taxi),
                  ),
                  ButtonSegment(
                    value: 'Delivery',
                    label: Text(_t.t('svc_parcel'),
                        style: const TextStyle(
                            fontSize: 16, fontWeight: FontWeight.w800)),
                    icon: const KIcon(Icons.inventory_2),
                  ),
                ],
                selected: {serviceMode},
                style: SegmentedButton.styleFrom(
                  backgroundColor: _Palette.greyBg,
                  selectedBackgroundColor: _Palette.accent,
                  selectedForegroundColor: _Palette.accentInk,
                  foregroundColor: _Palette.inkMuted,
                  side: BorderSide.none,
                ),
                onSelectionChanged: (s) {
                  setState(() {
                    serviceMode = s.first;
                    final filtered = _filterByMode(_vehicles);
                    if (filtered.isNotEmpty) {
                      selectedVehicle = filtered.first['name'];
                    }
                  });
                  _recompute();
                  _fetchRouteAndFare();
                },
              ),
            ),
          ),

          // ── FROM / TO: both editable, like a route ──
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Container(
              padding: const EdgeInsets.fromLTRB(12, 6, 4, 6),
              decoration: BoxDecoration(
                color: _Palette.greyBg,
                borderRadius: BorderRadius.circular(16),
              ),
              child: Row(
                children: [
                  // Dot — line — square
                  Column(
                    children: [
                      Container(
                        width: 12,
                        height: 12,
                        decoration: const BoxDecoration(
                          color: _Palette.pickupGreen,
                          shape: BoxShape.circle,
                        ),
                      ),
                      Container(
                        width: 2,
                        height: 30,
                        margin: const EdgeInsets.symmetric(vertical: 3),
                        color: _Palette.divider,
                      ),
                      Container(
                        width: 12,
                        height: 12,
                        decoration: BoxDecoration(
                          color: _Palette.dropoff,
                          borderRadius: BorderRadius.circular(3),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      children: [
                        _placeField(
                          controller: _pickupCtrl,
                          focusNode: _pickupFocus,
                          hint: _t.t('sd_your_pickup'),
                          active: _activeField == 'pickup',
                        ),
                        const Divider(height: 1, color: _Palette.divider),
                        _placeField(
                          controller: _searchCtrl,
                          focusNode: _searchFocus,
                          hint: serviceMode == 'Delivery'
                              ? _t.t('sd_where_deliver')
                              : _t.t('sd_where_going'),
                          active: _activeField == 'dropoff',
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 10),

          // ── MAP — now takes only 40% ──
          Expanded(
            flex: 4,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Stack(
                children: [
                  ClipRRect(
                    borderRadius: BorderRadius.circular(20),
                    child: _buildMap(),
                  ),
                  if (_pickingOnMap)
                    Positioned(
                      left: 10,
                      right: 10,
                      top: 10,
                      child: Material(
                        color: _Palette.ink,
                        borderRadius: BorderRadius.circular(12),
                        child: Padding(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 14, vertical: 10),
                          child: Row(
                            children: [
                              const Icon(Icons.touch_app,
                                  color: Colors.white, size: 20),
                              const SizedBox(width: 8),
                              Expanded(
                                child: Text(
                                  _activeField == 'pickup'
                                      ? tr('Tap the map where you want to be picked up')
                                      : tr('Tap the map where you are going'),
                                  style: const TextStyle(
                                      color: Colors.white,
                                      fontSize: 14.5,
                                      fontWeight: FontWeight.w600),
                                ),
                              ),
                              GestureDetector(
                                onTap: () =>
                                    setState(() => _pickingOnMap = false),
                                child: const Icon(Icons.close,
                                    color: Colors.white70, size: 20),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  if (_destination != null)
                    Positioned(
                      right: 10,
                      bottom: 10,
                      child: Material(
                        color: Colors.white,
                        shape: const CircleBorder(),
                        elevation: 3,
                        child: InkWell(
                          customBorder: const CircleBorder(),
                          onTap: _recenterOnRoute,
                          child: const Padding(
                            padding: EdgeInsets.all(10),
                            child: Icon(Icons.center_focus_strong,
                                size: 20, color: _Palette.ink),
                          ),
                        ),
                      ),
                    ),
                ],
              ),
            ),
          ),

          const SizedBox(height: 12),

          // ── BOTTOM SHEET — takes 60% so all cards fit ──
          Expanded(
            flex: 6,
            child: ConstrainedBox(
              constraints: const BoxConstraints(minHeight: 340),
              child: Container(
                decoration: const BoxDecoration(
                  color: Colors.white,
                  borderRadius:
                      BorderRadius.vertical(top: Radius.circular(24)),
                ),
                child: _loading
                    ? const Center(
                        child: CircularProgressIndicator(
                            color: _Palette.accent))
                    : (_isTyping || _searching || _suggestions.isNotEmpty)
                        ? Padding(
                            padding:
                                const EdgeInsets.fromLTRB(16, 16, 16, 20),
                            child: _buildSuggestionsList(),
                          )
                        : _buildBookingSheet(),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSuggestionsList() {
    final saved = FavoritePlacesService.filter(_saved, _activeCtrl.text);
    if (_resolvingPlace ||
        (_searching && _suggestions.isEmpty && saved.isEmpty)) {
      return const Center(
        child: Padding(
          padding: EdgeInsets.all(20),
          child: SizedBox(
            width: 26,
            height: 26,
            child: CircularProgressIndicator(
                color: _Palette.accent, strokeWidth: 2.5),
          ),
        ),
      );
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        if (saved.isNotEmpty) ...[
          Text(
            tr('Saved places'),
            style: const TextStyle(
              fontSize: 13.5,
              fontWeight: FontWeight.w700,
              color: _Palette.inkMuted,
            ),
          ),
          const SizedBox(height: 4),
          for (final r in saved.take(4)) _savedRow(r),
          const SizedBox(height: 10),
        ],
        Text(
          _t.t('sd_search_results'),
          style: const TextStyle(
            fontSize: 13.5,
            fontWeight: FontWeight.w700,
            color: _Palette.inkMuted,
          ),
        ),
        const SizedBox(height: 8),
        Expanded(
          child: _suggestions.isEmpty && saved.isNotEmpty
              ? const SizedBox.shrink()
              : _suggestions.isEmpty
              ? Center(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(Icons.location_off,
                          size: 40, color: _Palette.inkMuted),
                      const SizedBox(height: 8),
                      Text(
                        _t.t('sd_no_results'),
                        style: const TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w600,
                            color: _Palette.ink),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        _t.t('sd_no_results_hint'),
                        style: const TextStyle(
                            fontSize: 13.5, color: _Palette.inkMuted),
                      ),
                      const SizedBox(height: 12),
                      OutlinedButton.icon(
                        onPressed: () {
                          FocusScope.of(context).unfocus();
                          _startPickOnMap();
                        },
                        icon: const Icon(Icons.map_outlined),
                        label: Text(tr('Choose on map')),
                      ),
                    ],
                  ),
                )
              : ListView.separated(
                  itemCount: _suggestions.length,
                  separatorBuilder: (_, __) =>
                      Divider(height: 1, color: Colors.grey.shade100),
                  itemBuilder: (_, i) {
                    final item = _suggestions[i];
                    final name = item.primaryText.isNotEmpty
                        ? item.primaryText
                        : item.fullDescription;
                    final ctxText = item.secondaryText;
                    final dist = item.distanceKm;
                    return ListTile(
                      contentPadding: EdgeInsets.zero,
                      leading: Container(
                        width: 36,
                        height: 36,
                        decoration: const BoxDecoration(
                          color: _Palette.greyBg,
                          shape: BoxShape.circle,
                        ),
                        child: const KIcon(Icons.location_on,
                            color: _Palette.ink, size: 20),
                      ),
                      title: Text(
                        name,
                        style: const TextStyle(
                            color: _Palette.ink,
                            fontSize: 14,
                            fontWeight: FontWeight.w600),
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                      ),
                      subtitle: ctxText.isEmpty
                          ? null
                          : Text(
                              ctxText,
                              style: const TextStyle(
                                  color: _Palette.inkMuted, fontSize: 13.5),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                      trailing: dist == null
                          ? null
                          : Text(
                              dist < 1
                                  ? '${(dist * 1000).toStringAsFixed(0)} m'
                                  : '${dist.toStringAsFixed(1)} km',
                              style: const TextStyle(
                                  color: _Palette.inkMuted,
                                  fontSize: 13.5,
                                  fontWeight: FontWeight.w600),
                            ),
                      onTap: () => _onSuggestionTap(item),
                    );
                  },
                ),
        ),
      ],
    );
  }

  Widget _buildBookingSheet() {
    final vehicles = _filteredVehicles;

    if (vehicles.isEmpty && !_loading && !_isParcel) {
      return Padding(
        padding: const EdgeInsets.all(16),
        child: ErrorUI.inline(
          AppError(
            title: _t.t('sd_options_failed'),
            message: _t.t('sd_servers_trouble'),
            icon: Icons.directions_car_outlined,
            actionLabel: _t.t('retry'),
            onRetry: _loadAll,
          ),
        ),
      );
    }

    return Column(
      children: [
        Expanded(
          child: SingleChildScrollView(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                if (_routeDistanceKm > 0) ...[
                  Row(
                    children: [
                      const Icon(Icons.straighten,
                          size: 14, color: _Palette.inkMuted),
                      const SizedBox(width: 4),
                      Text(
                        tr('{0} km', [_routeDistanceKm.toStringAsFixed(1)]),
                        style: const TextStyle(
                            color: _Palette.ink,
                            fontSize: 13.5,
                            fontWeight: FontWeight.w600),
                      ),
                      const SizedBox(width: 16),
                      const KIcon(Icons.access_time,
                          size: 14, color: _Palette.inkMuted),
                      const SizedBox(width: 4),
                      Text(
                        '~${_etaMinutes ?? '—'} ${_t.t('min')}',
                        style: const TextStyle(
                            color: _Palette.ink,
                            fontSize: 13.5,
                            fontWeight: FontWeight.w600),
                      ),
                      if (_routeIsApproximate) ...[
                        const SizedBox(width: 10),
                        Text(
                          _t.t('sd_estimate'),
                          style: const TextStyle(
                              fontSize: 12,
                              fontStyle: FontStyle.italic,
                              color: _Palette.inkMuted),
                        ),
                      ],
                    ],
                  ),
                  const SizedBox(height: 12),
                ],

                if (_destination == null) ...[
                  if (_activeField == 'pickup')
                    _optionRow(
                      icon: Icons.my_location,
                      color: _Palette.blue,
                      title: _t.t('sd_use_current'),
                      onTap: _useCurrentLocation,
                    ),
                  _optionRow(
                    icon: Icons.map_outlined,
                    color: _Palette.accent,
                    title: tr('Choose on map'),
                    onTap: _startPickOnMap,
                  ),
                  if (_saved.isNotEmpty) ...[
                    const SizedBox(height: 10),
                    Text(
                      tr('Saved places'),
                      style: const TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w700,
                        color: _Palette.inkMuted,
                      ),
                    ),
                    const SizedBox(height: 4),
                    for (final r in FavoritePlacesService.filter(_saved, '')
                        .take(4))
                      _savedRow(r),
                  ],
                  if (_activeField == 'dropoff' &&
                      _recentDestinations.isNotEmpty) ...[
                    const SizedBox(height: 10),
                    Text(
                      _t.t('sd_recent'),
                      style: const TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w700,
                        color: _Palette.inkMuted,
                      ),
                    ),
                    const SizedBox(height: 4),
                    for (final r in _recentDestinations)
                      _optionRow(
                        icon: Icons.history,
                        color: _Palette.inkMuted,
                        title: (r['address'] ?? '')
                            .toString()
                            .split(',')
                            .first
                            .trim(),
                        subtitle: (r['address'] ?? '').toString(),
                        onTap: () => _useRecentDestination(r),
                      ),
                  ],
                  const SizedBox(height: 14),
                ],

                if (_destination != null && _isParcel) _parcelSection(),

                if (_destination != null && !_isParcel) ...[
                  Text(
                    serviceMode == 'Delivery'
                        ? _t.t('sd_choose_vehicle')
                        : _t.t('sd_choose_ride'),
                    style: const TextStyle(
                      fontSize: 13.5,
                      fontWeight: FontWeight.w700,
                      color: _Palette.inkMuted,
                    ),
                  ),
                  const SizedBox(height: 8),

                  if (vehicles.isEmpty)
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 20),
                      child: Center(
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const KIcon(Icons.directions_car_outlined,
                                size: 40, color: _Palette.inkMuted),
                            const SizedBox(height: 8),
                            Text(
                              _t.t('sd_no_vehicles'),
                              style: const TextStyle(
                                  fontSize: 14,
                                  fontWeight: FontWeight.w600,
                                  color: _Palette.ink),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              _t.t('sd_try_later'),
                              style: const TextStyle(
                                  fontSize: 13.5, color: _Palette.inkMuted),
                            ),
                          ],
                        ),
                      ),
                    )
                  else
                    ListView.separated(
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      itemCount: vehicles.length,
                      separatorBuilder: (_, __) =>
                          const SizedBox(height: 8),
                      itemBuilder: (_, i) {
                        final v = vehicles[i];
                        final isSel = selectedVehicle == v['name'];
                        final fare = _fareForVehicle(v);
                        return _vehicleRow(v, isSel, fare);
                      },
                    ),
                ],
              ],
            ),
          ),
        ),

        // ── Confirm bar ──
        if (_destination != null)
          Container(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 16),
            decoration: BoxDecoration(
              color: Colors.white,
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withValues(alpha: 0.06),
                  blurRadius: 10,
                  offset: const Offset(0, -4),
                ),
              ],
            ),
            child: Row(
              children: [
                Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(_t.t('total'),
                        style: const TextStyle(
                            fontSize: 13.5, color: _Palette.inkMuted)),
                    Text(
                      CountryConfig.money(_isParcel ? _parcelFare : _fare),
                      style: const TextStyle(
                          fontSize: 21,
                          fontWeight: FontWeight.w900,
                          color: _Palette.ink),
                    ),
                  ],
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: ElevatedButton(
              onPressed: (_destination == null)
                  ? null
                  : (selectedVehicle.isEmpty && !_isParcel)
                  ? null
                  : _isParcel
                  ? (_sendingParcel ? null : _requestCourier)
                  : () => Navigator.pop(context, {
                        'vehicle': selectedVehicle,
                        'serviceType': serviceMode,
                        'pickup': _pickupAddress.isNotEmpty
                            ? _pickupAddress
                            : _pickupCtrl.text,
                        'pickup_lat': _pickup.latitude,
                        'pickup_lng': _pickup.longitude,
                        'dropoff': _destinationAddress,
                        'lat': _destination!.latitude,
                        'lng': _destination!.longitude,
                        'distance': _routeDistanceKm,
                        'eta': _etaMinutes,
                        'fare': _fare,
                        'approximate': _routeIsApproximate,
                      }),
              style: ElevatedButton.styleFrom(
                backgroundColor: _Palette.accent,
                foregroundColor: _Palette.accentInk,
                disabledBackgroundColor: Colors.grey.shade300,
                padding: const EdgeInsets.symmetric(vertical: 16),
                minimumSize: const Size(0, 56),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14)),
              ),
              child: _sendingParcel
                  ? const SizedBox(
                      width: 22,
                      height: 22,
                      child: CircularProgressIndicator(
                          strokeWidth: 2.5, color: _Palette.accentInk),
                    )
                  : Text(
                      _isParcel
                          ? _t.t('request_courier')
                          : _t.t('sd_confirm_continue'),
                      style: const TextStyle(
                          fontSize: 17, fontWeight: FontWeight.w900),
                    ),
            ),
                ),
              ],
            ),
          ),
      ],
    );
  }

  // ── Parcel details: size, extras, recipient, note, photo ──
  Widget _parcelSection() {
    final p = PricingService.last;
    Widget sizeTile(String key, String weightKey) {
      final on = _parcelSize == key;
      return Expanded(
        child: GestureDetector(
          onTap: () => setState(() => _parcelSize = key),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 160),
            padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 4),
            decoration: BoxDecoration(
              color: on ? const Color(0xFFEBF5FF) : Colors.white,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(
                color: on ? const Color(0xFF1565C0) : Colors.grey.shade300,
                width: on ? 1.6 : 1,
              ),
            ),
            child: Column(
              children: [
                Text(_t.t('size_$key'),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w800,
                        color: on ? const Color(0xFF1565C0) : _Palette.ink)),
                const SizedBox(height: 2),
                Text(_t.t(weightKey),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                        fontSize: 12.5, color: _Palette.inkMuted)),
              ],
            ),
          ),
        ),
      );
    }

    Widget extra(String label, double price, bool on, VoidCallback tap) {
      return Expanded(
        child: GestureDetector(
          onTap: tap,
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 160),
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
            decoration: BoxDecoration(
              color: on ? _Palette.accent.withValues(alpha: 0.08) : Colors.white,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                  color: on ? _Palette.accent : Colors.grey.shade300,
                  width: on ? 1.6 : 1),
            ),
            child: Row(
              children: [
                Icon(on ? Icons.check_box : Icons.check_box_outline_blank,
                    size: 20, color: on ? _Palette.accent : _Palette.inkMuted),
                const SizedBox(width: 6),
                Expanded(
                  child: Text(label,
                      style: const TextStyle(
                          fontSize: 14.5, fontWeight: FontWeight.w700)),
                ),
                Text('+${CountryConfig.money(price)}',
                    style: const TextStyle(
                        fontSize: 13.5, fontWeight: FontWeight.w700)),
              ],
            ),
          ),
        ),
      );
    }

    InputDecoration box(String hint, IconData icon) => InputDecoration(
          hintText: hint,
          prefixIcon: Icon(icon, color: _Palette.inkMuted),
          filled: true,
          fillColor: _Palette.greyBg,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide.none,
          ),
          contentPadding: const EdgeInsets.symmetric(vertical: 14),
        );

    TextStyle label() => const TextStyle(
        fontSize: 14, fontWeight: FontWeight.w700, color: _Palette.inkMuted);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Text(_t.t('package_size'), style: label()),
        const SizedBox(height: 8),
        Row(children: [
          sizeTile('small', 'weight_small'),
          const SizedBox(width: 6),
          sizeTile('medium', 'weight_medium'),
          const SizedBox(width: 6),
          sizeTile('large', 'weight_large'),
          const SizedBox(width: 6),
          sizeTile('xl', 'weight_xl'),
        ]),
        const SizedBox(height: 10),
        Row(children: [
          extra(_t.t('fragile'), p.fragileFee, _fragile,
              () => setState(() => _fragile = !_fragile)),
          const SizedBox(width: 8),
          extra(_t.t('urgent'), p.urgentFee, _urgent,
              () => setState(() => _urgent = !_urgent)),
        ]),
        const SizedBox(height: 16),
        Text(_t.t('recipient'), style: label()),
        const SizedBox(height: 8),
        TextField(
          controller: _recipientNameCtrl,
          textCapitalization: TextCapitalization.words,
          style: const TextStyle(fontSize: 16),
          decoration: box(_t.t('full_name'), Icons.person_outline),
        ),
        const SizedBox(height: 8),
        TextField(
          controller: _recipientPhoneCtrl,
          keyboardType: TextInputType.phone,
          style: const TextStyle(fontSize: 16),
          decoration: box(_t.t('phone_number'), Icons.phone_outlined),
        ),
        const SizedBox(height: 8),
        TextField(
          controller: _parcelNoteCtrl,
          maxLines: 2,
          minLines: 1,
          style: const TextStyle(fontSize: 16),
          decoration: box(_t.t('note_for_driver'), Icons.sticky_note_2_outlined),
        ),
        const SizedBox(height: 10),
        // Package photo (optional)
        InkWell(
          onTap: _pickPackagePhoto,
          borderRadius: BorderRadius.circular(12),
          child: Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: Colors.grey.shade300),
            ),
            child: Row(
              children: [
                Icon(
                    _packagePhoto == null
                        ? Icons.add_a_photo_outlined
                        : Icons.check_circle,
                    color: _packagePhoto == null
                        ? _Palette.inkMuted
                        : _Palette.pickupGreen),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    _packagePhoto == null
                        ? _t.t('package_photo')
                        : _packagePhoto!.name,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                        fontSize: 15, fontWeight: FontWeight.w600),
                  ),
                ),
                if (_packagePhoto != null)
                  GestureDetector(
                    onTap: () => setState(() => _packagePhoto = null),
                    child: const Icon(Icons.close, color: _Palette.inkMuted),
                  ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 16),
        PaymentChoice(
          value: _parcelPayMethod,
          onChanged: (v) => setState(() => _parcelPay = v),
          amountDue: _parcelFare,
          walletBalance: context.watch<AuthProvider>().walletBalance,
          cashHint: tr('Pay the courier at pickup'),
        ),
        const SizedBox(height: 8),
      ],
    );
  }

  Widget _placeField({
    required TextEditingController controller,
    required FocusNode focusNode,
    required String hint,
    required bool active,
  }) {
    return Row(
      children: [
        Expanded(
          child: TextField(
            controller: controller,
            focusNode: focusNode,
            onChanged: _onSearch,
            textInputAction: TextInputAction.search,
            style: TextStyle(
              color: _Palette.ink,
              fontSize: 16,
              fontWeight: active ? FontWeight.w700 : FontWeight.w500,
            ),
            decoration: InputDecoration(
              hintText: hint,
              hintStyle: const TextStyle(color: _Palette.inkMuted),
              border: InputBorder.none,
              isDense: true,
              contentPadding: const EdgeInsets.symmetric(vertical: 12),
            ),
          ),
        ),
        if (active && controller.text.isNotEmpty)
          IconButton(
            tooltip: tr('Clear'),
            icon: const Icon(Icons.close, color: _Palette.inkMuted, size: 20),
            onPressed: () {
              _searchRequestId++;
              controller.clear();
              setState(() {
                _suggestions = [];
                _searching = false;
                _isTyping = false;
                if (controller == _searchCtrl) {
                  _routeRequestId++;
                  _destination = null;
                  _destinationAddress = '';
                  _routePoints = [];
                  _routeDistanceKm = 0;
                  _etaMinutes = null;
                  _routeIsApproximate = false;
                  _fare = 0;
                }
              });
              focusNode.requestFocus();
            },
          ),
      ],
    );
  }

  Widget _optionRow({
    required IconData icon,
    required Color color,
    required String title,
    String? subtitle,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 4),
        child: Row(
          children: [
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: color.withValues(alpha: 0.12),
                shape: BoxShape.circle,
              ),
              child: Icon(icon, color: color, size: 22),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w700,
                      color: _Palette.ink,
                    ),
                  ),
                  if (subtitle != null && subtitle != title)
                    Text(
                      subtitle,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        fontSize: 14,
                        color: _Palette.inkMuted,
                      ),
                    ),
                ],
              ),
            ),
            const Icon(Icons.chevron_right, color: _Palette.inkMuted),
          ],
        ),
      ),
    );
  }

  // ── VEHICLE ROW — smaller icon box, more inner padding ──
  Widget _vehicleRow(Map<String, dynamic> v, bool selected, double fare) {
    final etaOffset = (v['eta_offset'] ?? 0) as int;
    final etaLabel = _etaMinutes != null
        ? '~${_etaMinutes! + etaOffset} ${_t.t('min')}'
        : null;
    final subtitle = _vehicleSubtitle(v);

    return InkWell(
      onTap: () {
        final wasBike = _filteredVehicles.any(
            (x) => x['name'] == selectedVehicle && _isBike(x));
        setState(() => selectedVehicle = v['name'] as String);
        _recompute();
        // Bikes take different roads — re-route when switching type.
        if (_destination != null && wasBike != _isBike(v)) {
          _fetchRouteAndFare();
        }
      },
      borderRadius: BorderRadius.circular(16),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        curve: Curves.easeOut,
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
        decoration: BoxDecoration(
          color: selected
              ? _Palette.accent.withValues(alpha: 0.08)
              : Colors.white,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: selected ? _Palette.accent : Colors.grey.shade200,
            width: selected ? 1.6 : 1,
          ),
          boxShadow: selected
              ? [
                  BoxShadow(
                    color: _Palette.accent.withValues(alpha: 0.18),
                    blurRadius: 14,
                    offset: const Offset(0, 5),
                  ),
                ]
              : null,
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            // Icon box: 52×52 with 10px inner pad → 32px PNG, full bleed
            Container(
              width: 52,
              height: 52,
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: selected
                    ? _Palette.accent.withValues(alpha: 0.18)
                    : _Palette.greyBg,
                borderRadius: BorderRadius.circular(12),
              ),
              child: AppImage(
                _vehicleAsset(v),
                size: 32,
                fit: BoxFit.contain,
                fallbackIcon: _vehicleAsset(v).contains('large_van')
                    ? Icons.local_shipping_outlined
                    : Icons.directions_car_filled,
              ),
            ),
            const SizedBox(width: 12),

            // Middle — name, subtitle, ETA
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    v['name'] as String,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      fontSize: 14.5,
                      fontWeight: FontWeight.bold,
                      color: _Palette.ink,
                      height: 1.15,
                    ),
                  ),
                  const SizedBox(height: 3),
                  Text(
                    subtitle,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      fontSize: 13,
                      color: _Palette.inkMuted,
                      height: 1.2,
                    ),
                  ),
                  if (etaLabel != null) ...[
                    const SizedBox(height: 4),
                    Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const KIcon(Icons.access_time,
                            size: 12, color: _Palette.blue),
                        const SizedBox(width: 4),
                        Flexible(
                          child: Text(
                            etaLabel,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              fontSize: 13,
                              fontWeight: FontWeight.w600,
                              color: _Palette.blue,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ],
              ),
            ),
            const SizedBox(width: 8),

            // Right — fare + Selected badge, stable height
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  CountryConfig.money(fare),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.bold,
                    color: _Palette.ink,
                    height: 1.1,
                  ),
                ),
                const SizedBox(height: 4),
                if (selected)
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 8, vertical: 3),
                    decoration: BoxDecoration(
                      color: _Palette.accent,
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Text(
                      _t.t('sd_selected'),
                      style: const TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.bold,
                        color: _Palette.accentInk,
                        letterSpacing: 0.3,
                      ),
                    ),
                  )
                else
                  const SizedBox(height: 14),
              ],
            ),
          ],
        ),
      ),
    );
  }

  // ── Mode-aware subtitle: bikes read differently per mode ──
  // Parses seats from the name when the DB has no seats column.
  String _vehicleSubtitle(Map<String, dynamic> v) {
    final name = (v['name'] ?? '').toString();
    final nameLower = name.toLowerCase();
    final seats = v['seats'] ?? v['capacity'];

    if (_isBike(v)) {
      return serviceMode.trim().toLowerCase() == 'delivery'
          ? _t.t('sd_bike_parcel')
          : _t.t('sd_bike_ride');
    }

    final seatsWord = _t.t('sd_seats');

    // 1) explicit seats column, if the DB ever gets one
    if (seats != null) return '$seats $seatsWord';

    // 2) parse "6-Seater", "4 seater", "XL (6 seats)"
    final match = RegExp(
      r'(\d+)\s*[-\s]?(?:seat|seater|seats)',
      caseSensitive: false,
    ).firstMatch(name);
    if (match != null) return '${match.group(1)} $seatsWord';

    // 3) fallbacks by convention
    if (nameLower.contains('xl')) return '6 $seatsWord';
    if (nameLower.contains('van')) return '14 $seatsWord';
    if (nameLower.contains('sedan')) return '4 $seatsWord';

    return _t.t('sd_standard');
  }
}
