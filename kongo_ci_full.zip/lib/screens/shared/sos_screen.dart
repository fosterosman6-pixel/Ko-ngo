﻿import 'dart:async';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:efuride_app/services/notification_service.dart';
import 'package:efuride_app/utils/app_error.dart';
import 'package:efuride_app/utils/error_ui.dart';
import 'package:efuride_app/l10n/app_strings.dart';

class _Palette {
  static const cream = Color(0xFFFAF6EE);
  static const ink = Color(0xFF1A1A1A);
  static const inkMuted = Color(0xFF575047);
  static const divider = Color(0xFFE8E2D5);
  static const dropoff = Color(0xFFE53935);
  static const pickup = Color(0xFF34C759);
}

enum _SOSState { idle, sending, active, failed }

class SOSScreen extends StatefulWidget {
  final String role;
  final String? rideId;
  const SOSScreen({super.key, this.role = 'customer', this.rideId});

  @override
  State<SOSScreen> createState() => _SOSScreenState();
}

class _SOSScreenState extends State<SOSScreen> {
  _SOSState _state = _SOSState.idle;
  AppError? _error;
  String? _eventId;

  Future<void> _triggerSOS() async {
    final confirmed = await _confirmDialog();
    if (confirmed != true) return;

    setState(() {
      _state = _SOSState.sending;
      _error = null;
    });

    try {
      final userId = Supabase.instance.client.auth.currentUser?.id;
      if (userId == null) throw Exception('Not signed in');

      // Best-effort location.
      double? lat;
      double? lng;
      try {
        final perm = await Geolocator.checkPermission();
        if (perm == LocationPermission.always ||
            perm == LocationPermission.whileInUse) {
          final pos = await Geolocator.getCurrentPosition(
            desiredAccuracy: LocationAccuracy.high,
            timeLimit: const Duration(seconds: 6),
          );
          lat = pos.latitude;
          lng = pos.longitude;
        }
      } catch (e) {
        debugPrint('SOS location failed: $e');
      }

      // Insert SOS event — must succeed.
      final inserted = await Supabase.instance.client
          .from('sos_events')
          .insert({
            'user_id': userId,
            'role': widget.role,
            'ride_id': widget.rideId,
            'lat': lat,
            'lng': lng,
            'status': 'active',
            'triggered_at': DateTime.now().toUtc().toIso8601String(),
          })
          .select()
          .single()
          .timeout(const Duration(seconds: 12));

      _eventId = inserted['id']?.toString();

      unawaited(_notifyContacts(userId, lat, lng));

      if (!mounted) return;
      setState(() => _state = _SOSState.active);
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _state = _SOSState.failed;
        _error = AppError.from(e, onRetry: _triggerSOS);
      });
    }
  }

  Future<void> _notifyContacts(
      String userId, double? lat, double? lng) async {
    try {
      final contacts = await Supabase.instance.client
          .from('emergency_contacts')
          .select('name, phone')
          .eq('user_id', userId);

      if (contacts.isEmpty) return;

      final contactNames =
          contacts.map((c) => c['name']?.toString() ?? '').join(', ');

      await NotificationService.send(
        toUserId: userId,
        title: tr('🚨 SOS activated'),
        body: tr('Emergency services and {0} have been alerted.', [contactNames]),
        type: 'sos_alert',
        data: {'ride_id': widget.rideId ?? ''},
      );

      try {
        await Supabase.instance.client.functions.invoke(
          'sos-notify',
          body: {
            'user_id': userId,
            'ride_id': widget.rideId,
            'lat': lat,
            'lng': lng,
            'contacts': contacts,
          },
        );
      } catch (e) {
        debugPrint('sos-notify edge function failed: $e');
      }
    } catch (e) {
      debugPrint('sos notify failed: $e');
    }
  }

  Future<void> _resolveSOS() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16)),
        title: Text(tr('Mark yourself as safe?')),
        content: Text(
            tr('This will end the SOS alert. Your contacts will be told you\'re safe.')),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: Text(tr('Keep alert active')),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
                backgroundColor: _Palette.pickup),
            onPressed: () => Navigator.pop(ctx, true),
            child: Text(tr('I\'m safe')),
          ),
        ],
      ),
    );
    if (confirmed != true) return;

    try {
      if (_eventId != null) {
        await Supabase.instance.client
            .from('sos_events')
            .update({
              'status': 'resolved',
              'resolved_at': DateTime.now().toUtc().toIso8601String(),
            })
            .eq('id', _eventId!);
      }

      try {
        await Supabase.instance.client.functions.invoke(
          'sos-notify',
          body: {'event_id': _eventId, 'resolved': true},
        );
      } catch (e) {
        debugPrint('sos resolve notify failed: $e');
      }

      if (!mounted) return;
      setState(() => _state = _SOSState.idle);
      ErrorUI.showSnack(
        context,
        AppError(
          title: tr('Marked safe'),
          message: tr('Your contacts have been notified.'),
          icon: Icons.check_circle_outline,
        ),
      );
    } catch (e) {
      if (!mounted) return;
      ErrorUI.showSnack(
        context,
        AppError.from(e, onRetry: _resolveSOS),
      );
    }
  }

  Future<bool?> _confirmDialog() {
    return showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Row(
          children: [
            Icon(Icons.warning_amber_rounded, color: _Palette.dropoff),
            SizedBox(width: 8),
            Text(tr('Trigger SOS?')),
          ],
        ),
        content: Text(
          tr('This will alert your emergency contacts and our support team with your location. Use only in a real emergency.'),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: Text(tr('Cancel')),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: _Palette.dropoff,
              foregroundColor: Colors.white,
            ),
            onPressed: () => Navigator.pop(ctx, true),
            child: Text(tr('Trigger SOS'),
                style: TextStyle(fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (_state == _SOSState.active) return _activeView();

    return Scaffold(
      backgroundColor: _Palette.cream,
      appBar: AppBar(
        backgroundColor: _Palette.dropoff,
        foregroundColor: Colors.white,
        elevation: 0,
        title: Text(tr('Emergency SOS'),
            style: TextStyle(fontWeight: FontWeight.bold)),
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                padding: const EdgeInsets.all(24),
                decoration: BoxDecoration(
                  color: _Palette.dropoff.withOpacity(0.1),
                  shape: BoxShape.circle,
                ),
                child: const Icon(Icons.sos,
                    size: 72, color: _Palette.dropoff),
              ),
              const SizedBox(height: 24),
              Text(
                tr('In an emergency, tap the button below.'),
                textAlign: TextAlign.center,
                style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w500,
                    color: _Palette.ink),
              ),
              const SizedBox(height: 12),
              Text(
                tr('Your emergency contacts and our support team will be notified with your location.'),
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 14, color: _Palette.inkMuted),
              ),
              const SizedBox(height: 40),
              SizedBox(
                width: double.infinity,
                height: 70,
                child: ElevatedButton(
                  onPressed:
                      _state == _SOSState.sending ? null : _triggerSOS,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: _Palette.dropoff,
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16),
                    ),
                  ),
                  child: _state == _SOSState.sending
                      ? const SizedBox(
                          width: 24,
                          height: 24,
                          child: CircularProgressIndicator(
                              color: Colors.white, strokeWidth: 2.5),
                        )
                      : Text(
                          tr('TRIGGER SOS'),
                          style: TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.bold),
                        ),
                ),
              ),
              if (_error != null) ...[
                const SizedBox(height: 16),
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: _Palette.dropoff.withOpacity(0.08),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Row(
                    children: [
                      const Icon(Icons.error_outline,
                          color: _Palette.dropoff, size: 18),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          _error!.message,
                          style: const TextStyle(
                              fontSize: 13.5, color: _Palette.dropoff),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
              const SizedBox(height: 20),
              OutlinedButton.icon(
                onPressed: () => Navigator.pushNamed(context, '/sos_setup'),
                icon: const Icon(Icons.contacts),
                label: Text(tr('Manage emergency contacts')),
                style: OutlinedButton.styleFrom(
                  foregroundColor: _Palette.ink,
                  side: const BorderSide(color: _Palette.divider),
                  padding:
                      const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _activeView() {
    return PopScope(
      canPop: false,
      child: Scaffold(
        backgroundColor: _Palette.dropoff,
        body: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(Icons.sos, size: 96, color: Colors.white),
                const SizedBox(height: 24),
                Text(
                  tr('SOS ACTIVE'),
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 28,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 2,
                  ),
                ),
                const SizedBox(height: 12),
                Text(
                  tr('Your emergency contacts and our support team have been alerted with your location.'),
                  textAlign: TextAlign.center,
                  style: TextStyle(
                      color: Colors.white70, fontSize: 14, height: 1.4),
                ),
                const SizedBox(height: 32),
                Text(
                  tr('Stay where you are. Help is on the way.'),
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 15,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const Spacer(),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: _resolveSOS,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.white,
                      foregroundColor: _Palette.dropoff,
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(14)),
                    ),
                    child: Text(
                      tr('I\'m safe — end alert'),
                      style: TextStyle(
                          fontSize: 16, fontWeight: FontWeight.bold),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
