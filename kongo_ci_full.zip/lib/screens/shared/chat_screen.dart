// lib/screens/shared/chat_screen.dart

import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:efuride_app/config/efuride_palette.dart';

class ChatScreen extends StatefulWidget {
  final String chatId;
  final String otherName;
  final String? otherAvatarUrl;
  final String? otherRole; // 'Driver', 'Customer', 'Shopper', 'Merchant'

  const ChatScreen({
    super.key,
    required this.chatId,
    required this.otherName,
    this.otherAvatarUrl,
    this.otherRole,
  });

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final _msgCtrl = TextEditingController();
  final _scrollCtrl = ScrollController();
  final _picker = ImagePicker();

  bool _otherTyping = false;
  Timer? _typingDebounce;

  // Mock message list — swap for Supabase stream.
  final List<_Msg> _messages = [
    _Msg(
      id: '1',
      text: 'Hi! I\'m 5 minutes away',
      isMine: false,
      time: DateTime.now().subtract(const Duration(minutes: 4)),
      read: true,
    ),
    _Msg(
      id: '2',
      text: 'Great, I\'ll be at the gate',
      isMine: true,
      time: DateTime.now().subtract(const Duration(minutes: 3, seconds: 30)),
      read: true,
    ),
    _Msg(
      id: '3',
      text: 'Blue Toyota Corolla — see you soon',
      isMine: false,
      time: DateTime.now().subtract(const Duration(minutes: 3)),
      read: true,
    ),
  ];

  final List<String> _quickReplies = [
    'On my way',
    'I\'m at the gate',
    'Please wait 2 min',
    'Where are you?',
    'Thank you!',
  ];

  @override
  void dispose() {
    _msgCtrl.dispose();
    _scrollCtrl.dispose();
    _typingDebounce?.cancel();
    super.dispose();
  }

  void _sendMessage(String text) {
    if (text.trim().isEmpty) return;
    setState(() {
      _messages.add(_Msg(
        id: DateTime.now().millisecondsSinceEpoch.toString(),
        text: text.trim(),
        isMine: true,
        time: DateTime.now(),
        read: false,
      ));
      _msgCtrl.clear();
    });
    _scrollToBottom();

    // Fake "other is typing" then reply.
    _typingDebounce?.cancel();
    _typingDebounce = Timer(const Duration(seconds: 2), () {
      if (!mounted) return;
      setState(() {
        _otherTyping = true;
      });
      Timer(const Duration(seconds: 2), () {
        if (!mounted) return;
        setState(() {
          _otherTyping = false;
          _messages.add(_Msg(
            id: DateTime.now().millisecondsSinceEpoch.toString(),
            text: 'Ok!',
            isMine: false,
            time: DateTime.now(),
            read: false,
          ));
        });
        _scrollToBottom();
      });
    });
  }

  Future<void> _sendImage() async {
    try {
      final f = await _picker.pickImage(
        source: ImageSource.gallery,
        imageQuality: 70,
        maxWidth: 1200,
      );
      if (f == null) return;
      setState(() {
        _messages.add(_Msg(
          id: DateTime.now().millisecondsSinceEpoch.toString(),
          text: '',
          imagePath: f.path,
          isMine: true,
          time: DateTime.now(),
          read: false,
        ));
      });
      _scrollToBottom();
    } catch (_) {}
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollCtrl.hasClients) {
        _scrollCtrl.animateTo(
          _scrollCtrl.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  String _timeLabel(DateTime t) {
    final h = t.hour.toString().padLeft(2, '0');
    final m = t.minute.toString().padLeft(2, '0');
    return '$h:$m';
  }

  String _dayLabel(DateTime t) {
    final now = DateTime.now();
    final diff = now.difference(t);
    if (diff.inMinutes < 1) return 'Just now';
    if (diff.inHours < 1) return '${diff.inMinutes}m ago';
    if (diff.inHours < 24) return '${diff.inHours}h ago';
    return '${t.day}/${t.month}';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: EfuridePalette.cream,
      body: Column(
        children: [
          _header(),
          Expanded(
            child: ListView.builder(
              controller: _scrollCtrl,
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 16),
              itemCount: _messages.length + (_otherTyping ? 1 : 0),
              itemBuilder: (_, i) {
                if (i == _messages.length) return _typingBubble();
                final m = _messages[i];
                final prev = i > 0 ? _messages[i - 1] : null;
                final showDateSep = prev == null ||
                    _dayLabel(prev.time) != _dayLabel(m.time);

                return Column(
                  children: [
                    if (showDateSep) _dateSeparator(m.time),
                    _bubble(m),
                  ],
                );
              },
            ),
          ),
          _quickRepliesRow(),
          _composer(),
        ],
      ),
    );
  }

  // ── Header ──
  Widget _header() {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          colors: [EfuridePalette.blue, EfuridePalette.blueDeep],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
      ),
      child: SafeArea(
        bottom: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(8, 8, 16, 12),
          child: Row(
            children: [
              IconButton(
                onPressed: () => Navigator.pop(context),
                icon: const Icon(Icons.arrow_back,
                    color: Colors.white),
              ),
              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  color: Colors.white.withValues(alpha: 0.15),
                  shape: BoxShape.circle,
                ),
                child: Center(
                  child: Text(
                    widget.otherName.substring(0, 1).toUpperCase(),
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 16,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(widget.otherName,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 16,
                          fontWeight: FontWeight.w900,
                          height: 1.1,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis),
                    const SizedBox(height: 2),
                    Row(
                      children: [
                        if (_otherTyping) ...[
                          const Text('typing…',
                              style: TextStyle(
                                color: Colors.white70,
                                fontSize: 11.5,
                                fontWeight: FontWeight.w500,
                                fontStyle: FontStyle.italic,
                              )),
                        ] else ...[
                          Container(
                            width: 6,
                            height: 6,
                            decoration: const BoxDecoration(
                              color: EfuridePalette.online,
                              shape: BoxShape.circle,
                            ),
                          ),
                          const SizedBox(width: 6),
                          Text(
                            widget.otherRole ?? 'Online',
                            style: const TextStyle(
                              color: Colors.white70,
                              fontSize: 11.5,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ],
                      ],
                    ),
                  ],
                ),
              ),
              IconButton(
                onPressed: () {},
                icon: const Icon(Icons.call,
                    color: Colors.white, size: 22),
              ),
              IconButton(
                onPressed: () {},
                icon: const Icon(Icons.more_vert,
                    color: Colors.white, size: 22),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ── Date separator ──
  Widget _dateSeparator(DateTime t) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 12),
      child: Center(
        child: Container(
          padding:
              const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: EfuridePalette.divider),
          ),
          child: Text(_dayLabel(t),
              style: const TextStyle(
                fontSize: 11,
                fontWeight: FontWeight.w700,
                color: EfuridePalette.inkMuted,
              )),
        ),
      ),
    );
  }

  // ── Bubble ──
  Widget _bubble(_Msg m) {
    final align =
        m.isMine ? CrossAxisAlignment.end : CrossAxisAlignment.start;
    final bg = m.isMine
        ? EfuridePalette.blueDeep
        : Colors.white;
    final fg =
        m.isMine ? Colors.white : EfuridePalette.ink;

    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Column(
        crossAxisAlignment: align,
        children: [
          ConstrainedBox(
            constraints: BoxConstraints(
                maxWidth: MediaQuery.of(context).size.width * 0.72),
            child: Container(
              padding: m.imagePath != null
                  ? const EdgeInsets.all(4)
                  : const EdgeInsets.symmetric(
                      horizontal: 14, vertical: 10),
              decoration: BoxDecoration(
                color: bg,
                borderRadius: BorderRadius.only(
                  topLeft: const Radius.circular(16),
                  topRight: const Radius.circular(16),
                  bottomLeft: Radius.circular(m.isMine ? 16 : 4),
                  bottomRight: Radius.circular(m.isMine ? 4 : 16),
                ),
                boxShadow: m.isMine
                    ? null
                    : [
                        BoxShadow(
                          color: Colors.black.withValues(alpha: 0.04),
                          blurRadius: 6,
                          offset: const Offset(0, 2),
                        ),
                      ],
              ),
              child: m.imagePath != null
                  ? ClipRRect(
                      borderRadius: BorderRadius.circular(12),
                      child: Image.file(
                        File(m.imagePath!),
                        width: 200,
                        fit: BoxFit.cover,
                      ),
                    )
                  : Text(
                      m.text,
                      style: TextStyle(
                        fontSize: 14,
                        height: 1.35,
                        color: fg,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
            ),
          ),
          const SizedBox(height: 3),
          Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(_timeLabel(m.time),
                  style: const TextStyle(
                      fontSize: 10,
                      color: EfuridePalette.inkMuted)),
              if (m.isMine) ...[
                const SizedBox(width: 4),
                Icon(
                  m.read ? Icons.done_all : Icons.done,
                  size: 12,
                  color: m.read
                      ? EfuridePalette.online
                      : EfuridePalette.inkMuted,
                ),
              ],
            ],
          ),
        ],
      ),
    );
  }

  // ── Typing bubble ──
  Widget _typingBubble() {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Align(
        alignment: Alignment.centerLeft,
        child: Container(
          padding:
              const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: const BorderRadius.only(
              topLeft: Radius.circular(16),
              topRight: Radius.circular(16),
              bottomLeft: Radius.circular(4),
              bottomRight: Radius.circular(16),
            ),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withValues(alpha: 0.04),
                blurRadius: 6,
                offset: const Offset(0, 2),
              ),
            ],
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: List.generate(3, (i) {
              return Container(
                margin: const EdgeInsets.symmetric(horizontal: 2),
                width: 6,
                height: 6,
                decoration: const BoxDecoration(
                  color: EfuridePalette.inkMuted,
                  shape: BoxShape.circle,
                ),
              );
            }),
          ),
        ),
      ),
    );
  }

  // ── Quick replies ──
  Widget _quickRepliesRow() {
    return Container(
      height: 44,
      decoration: const BoxDecoration(
        color: Colors.white,
        border: Border(top: BorderSide(color: EfuridePalette.divider)),
      ),
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        itemCount: _quickReplies.length,
        separatorBuilder: (_, __) => const SizedBox(width: 8),
        itemBuilder: (_, i) {
          final r = _quickReplies[i];
          return GestureDetector(
            onTap: () => _sendMessage(r),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: EfuridePalette.cream,
                borderRadius: BorderRadius.circular(18),
                border: Border.all(color: EfuridePalette.divider),
              ),
              child: Text(r,
                  style: const TextStyle(
                    fontSize: 12.5,
                    fontWeight: FontWeight.w700,
                    color: EfuridePalette.ink,
                  )),
            ),
          );
        },
      ),
    );
  }

  // ── Composer ──
  Widget _composer() {
    return Container(
      padding: EdgeInsets.fromLTRB(
        8,
        8,
        8,
        8 + MediaQuery.of(context).padding.bottom,
      ),
      decoration: BoxDecoration(
        color: Colors.white,
        border: const Border(top: BorderSide(color: EfuridePalette.divider)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.03),
            blurRadius: 8,
            offset: const Offset(0, -2),
          ),
        ],
      ),
      child: Row(
        children: [
          IconButton(
            onPressed: _sendImage,
            icon: const Icon(Icons.add_photo_alternate_outlined,
                color: EfuridePalette.inkMuted, size: 22),
          ),
          Expanded(
            child: Container(
              decoration: BoxDecoration(
                color: EfuridePalette.cream,
                borderRadius: BorderRadius.circular(22),
                border: Border.all(color: EfuridePalette.divider),
              ),
              child: TextField(
                controller: _msgCtrl,
                maxLines: 4,
                minLines: 1,
                onSubmitted: _sendMessage,
                textCapitalization: TextCapitalization.sentences,
                decoration: const InputDecoration(
                  hintText: 'Type a message…',
                  hintStyle: TextStyle(
                      fontSize: 13.5,
                      color: EfuridePalette.inkMuted),
                  contentPadding: EdgeInsets.symmetric(
                      horizontal: 14, vertical: 12),
                  border: InputBorder.none,
                ),
              ),
            ),
          ),
          const SizedBox(width: 6),
          GestureDetector(
            onTap: () => _sendMessage(_msgCtrl.text),
            child: Container(
              width: 42,
              height: 42,
              decoration: const BoxDecoration(
                color: EfuridePalette.blueDeep,
                shape: BoxShape.circle,
              ),
              child: const Icon(Icons.send_rounded,
                  color: Colors.white, size: 20),
            ),
          ),
        ],
      ),
    );
  }
}

class _Msg {
  final String id;
  final String text;
  final String? imagePath;
  final bool isMine;
  final DateTime time;
  final bool read;
  _Msg({
    required this.id,
    required this.text,
    required this.isMine,
    required this.time,
    this.imagePath,
    this.read = false,
  });
}
