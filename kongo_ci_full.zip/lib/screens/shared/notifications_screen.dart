﻿// lib/screens/shared/notifications_screen.dart

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:efuride_app/config/efuride_palette.dart';
import 'package:efuride_app/l10n/app_strings.dart';
import 'package:efuride_app/providers/notification_provider.dart';

class NotificationsScreen extends StatefulWidget {
  const NotificationsScreen({super.key});

  @override
  State<NotificationsScreen> createState() => _NotificationsScreenState();
}

class _NotificationsScreenState extends State<NotificationsScreen> {
  String _filter = 'All';

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      NotificationProvider.instance.refresh();
    });
  }

  // 🎯 Dynamic filters based on current role
  List<String> get _filters {
    switch (NotificationProvider.instance.currentRole) {
      case 'driver':
        return ['All', 'Rides', 'Earnings', 'Account'];
      case 'merchant':
        return ['All', 'Orders', 'Payouts', 'Account'];
      case 'shopper':
        return ['All', 'Tasks', 'Payouts', 'Account'];
      case 'customer':
      default:
        return ['All', 'Rides', 'Food', 'Account'];
    }
  }

  List<AppNotification> _filtered(List<AppNotification> all) {
    if (_filter == 'All') return all;
    return all.where((n) {
      final type = n.type;
      switch (_filter) {
        case 'Rides':
          return type.startsWith('ride');
        case 'Food':
        case 'Grocery':
        case 'Pharmacy':
          return type == 'order_status';
        case 'Account':
          return type.startsWith('account') ||
                 type.startsWith('payout') ||
                 type == 'substitution';
        case 'Earnings':
          return type.startsWith('payout') || type == 'ride_completed';
        case 'Orders':
          return type.startsWith('order');
        case 'Payouts':
          return type.startsWith('payout');
        case 'Tasks':
          return type.startsWith('task');
        default:
          return true;
      }
    }).toList();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: EfuridePalette.cream,
      appBar: AppBar(
        backgroundColor: EfuridePalette.cream,
        elevation: 0,
        scrolledUnderElevation: 0,
        foregroundColor: EfuridePalette.ink,
        title: Text(
          S.of(context).t('notif_inbox'),
          style: const TextStyle(
            color: EfuridePalette.ink,
            fontWeight: FontWeight.w900,
            fontSize: 18,
          ),
        ),
        actions: [
          Consumer<NotificationProvider>(
            builder: (_, prov, __) => prov.unread > 0
                ? TextButton(
                    onPressed: prov.markAllRead,
                    child: Text(
                      S.of(context).t('mark_all_read'),
                      style: const TextStyle(
                        color: EfuridePalette.blueDeep,
                        fontSize: 14,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  )
                : const SizedBox.shrink(),
          ),
        ],
      ),
      body: Consumer<NotificationProvider>(
        builder: (_, prov, __) {
          if (!prov.loaded) {
            return const Center(
              child: CircularProgressIndicator(
                  color: EfuridePalette.accent),
            );
          }

          final list = _filtered(prov.items);

          return Column(
            children: [
              _filterRow(prov),
              Expanded(
                child: list.isEmpty
                    ? _emptyState()
                    : RefreshIndicator(
                        color: EfuridePalette.accent,
                        onRefresh: prov.refresh,
                        child: ListView.separated(
                          padding: const EdgeInsets.fromLTRB(
                              16, 8, 16, 24),
                          itemCount: list.length,
                          separatorBuilder: (_, __) => const SizedBox(
                              height: 8),
                          itemBuilder: (_, i) =>
                              _card(list[i], prov),
                        ),
                      ),
              ),
            ],
          );
        },
      ),
    );
  }

  Widget _filterRow(NotificationProvider prov) {
    final filters = _filters; // <--- Dynamic
    final unread = prov.unread;

    return Container(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (unread > 0)
            Padding(
              padding: const EdgeInsets.only(left: 4, bottom: 8),
              child: Text(
                '$unread ${S.of(context).t('new_suffix')}',
                style: const TextStyle(
                  fontSize: 13.5,
                  fontWeight: FontWeight.w800,
                  color: EfuridePalette.blueDeep,
                ),
              ),
            ),
          SizedBox(
            height: 36,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              itemCount: filters.length,
              separatorBuilder: (_, __) => const SizedBox(width: 8),
              itemBuilder: (_, i) {
                final f = filters[i];
                final active = _filter == f;
                return GestureDetector(
                  onTap: () => setState(() => _filter = f),
                  child: Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 14),
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      color: active
                          ? EfuridePalette.blueDeep
                          : Colors.white,
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(
                        color: active
                            ? EfuridePalette.blueDeep
                            : EfuridePalette.divider,
                      ),
                    ),
                    child: Text(
                      _filterLabel(f),
                      style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w800,
                        color: active
                            ? Colors.white
                            : EfuridePalette.ink,
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  String _filterLabel(String key) {
    final t = S.of(context);
    switch (key) {
      case 'All':     return t.t('notif_all');
      case 'Rides':   return t.t('notif_rides');
      case 'Food':    return t.t('notif_food');
      case 'Account': return t.t('notif_account');
      case 'Earnings': return 'Earnings';
      case 'Orders':   return 'Orders';
      case 'Payouts':  return 'Payouts';
      case 'Tasks':    return 'Tasks';
      default:        return key;
    }
  }

  Widget _card(AppNotification n, NotificationProvider prov) {
    final color = _accentFor(n.type);
    final title = n.localizedTitle(context);
    final body  = n.localizedBody(context);
    final isRead = n.read;

    return Material(
      color: isRead ? Colors.white : color.withValues(alpha: 0.06),
      borderRadius: BorderRadius.circular(14),
      child: InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: () async {
          await prov.markRead(n.id);
          if (!mounted) return;
          final route  = n.route;
          final tab    = n.tab;
          final params = n.params;
          if (route != null && route.isNotEmpty) {
            Navigator.pushNamed(
              context,
              route,
              arguments: {
                if (tab != null && tab.isNotEmpty) 'tab': tab,
                ...params,
              },
            );
          } else if (n.type == 'support') {
            // Reply from ko!ngo support: open the conversations.
            Navigator.pushNamed(context, '/support');
          }
        },
        child: Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(14),
            border: Border.all(
              color: isRead
                  ? EfuridePalette.divider
                  : color.withValues(alpha: 0.30),
              width: isRead ? 1 : 1.4,
            ),
          ),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 42, height: 42,
                decoration: BoxDecoration(
                  color: color.withValues(alpha: 0.12),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Icon(_iconFor(n.type), color: color, size: 20),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            title,
                            style: TextStyle(
                              fontSize: 14,
                              fontWeight: isRead
                                  ? FontWeight.w700
                                  : FontWeight.w900,
                              color: EfuridePalette.ink,
                            ),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                        if (!isRead)
                          Container(
                            width: 8, height: 8,
                            decoration: BoxDecoration(
                              color: color,
                              shape: BoxShape.circle,
                            ),
                          ),
                      ],
                    ),
                    if (body.isNotEmpty) ...[
                      const SizedBox(height: 3),
                      Text(
                        body,
                        style: const TextStyle(
                          fontSize: 14,
                          color: EfuridePalette.inkMuted,
                          height: 1.35,
                        ),
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ],
                    const SizedBox(height: 6),
                    Text(
                      _relative(n.createdAt),
                      style: const TextStyle(
                        fontSize: 13,
                        color: EfuridePalette.inkMuted,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _emptyState() {
    final t = S.of(context);
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 90, height: 90,
              decoration: BoxDecoration(
                color: EfuridePalette.blueDeep.withValues(alpha: 0.08),
                shape: BoxShape.circle,
              ),
              child: const Icon(Icons.notifications_none,
                  size: 44, color: EfuridePalette.blueDeep),
            ),
            const SizedBox(height: 16),
            Text(t.t('all_caught_up'),
                style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w800,
                  color: EfuridePalette.ink,
                )),
            const SizedBox(height: 4),
            Text(t.t('no_new_notifications'),
                style: const TextStyle(
                  fontSize: 14,
                  color: EfuridePalette.inkMuted,
                )),
          ],
        ),
      ),
    );
  }

  IconData _iconFor(String type) {
    switch (type) {
      case 'ride_request':   return Icons.local_taxi_outlined;
      case 'ride_accepted':  return Icons.check_circle_outline;
      case 'ride_cancelled': return Icons.cancel_outlined;
      case 'substitution':   return Icons.swap_horiz;
      case 'order_status':   return Icons.receipt_long_outlined;
      case 'chat_message':   return Icons.chat_bubble_outline;
      case 'payout':         return Icons.payments_outlined;
      default:               return Icons.notifications_none;
    }
  }

  Color _accentFor(String type) {
    switch (type) {
      case 'ride_request':   return EfuridePalette.accent;
      case 'ride_accepted':  return EfuridePalette.online;
      case 'ride_cancelled': return EfuridePalette.dropoff;
      case 'substitution':   return EfuridePalette.shopperAccent;
      case 'order_status':   return EfuridePalette.merchantAccent;
      case 'payout':         return EfuridePalette.blueDeep;
      default:               return EfuridePalette.blueDeep;
    }
  }

  String _relative(DateTime? t) {
    if (t == null) return 'just now';
    final d = DateTime.now().difference(t);
    if (d.inSeconds < 60) return 'just now';
    if (d.inMinutes < 60) return '${d.inMinutes}m ago';
    if (d.inHours < 24)   return '${d.inHours}h ago';
    if (d.inDays < 7)     return '${d.inDays}d ago';
    return '${t.day}/${t.month}/${t.year}';
  }
}
