import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:efuride_app/utils/app_error.dart';
import 'package:efuride_app/utils/error_ui.dart';
import 'package:efuride_app/l10n/app_strings.dart';

class _Palette {
  static const cream = Color(0xFFFAF6EE);
  static const ink = Color(0xFF1A1A1A);
  static const inkMuted = Color(0xFF575047);
  static const accent = Color(0xFFF2B705);
  static const divider = Color(0xFFE8E2D5);
  static const blue = Color(0xFF1E88E5);
  static const pickup = Color(0xFF34C759);
}

class ProfilePhotoRequiredScreen extends StatefulWidget {
  const ProfilePhotoRequiredScreen({super.key});

  @override
  State<ProfilePhotoRequiredScreen> createState() =>
      _ProfilePhotoRequiredScreenState();
}

class _ProfilePhotoRequiredScreenState
    extends State<ProfilePhotoRequiredScreen> {
  final _picker = ImagePicker();

  Uint8List? _preview;
  bool _uploading = false;
  AppError? _error;

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, _) async {
        if (didPop) return;
        await _confirmExit();
      },
      child: Scaffold(
        backgroundColor: _Palette.cream,
        appBar: AppBar(
          backgroundColor: _Palette.cream,
          elevation: 0,
          automaticallyImplyLeading: false,
          iconTheme: const IconThemeData(color: _Palette.ink),
          title: Text(
            tr('Take your photo'),
            style: TextStyle(
                color: _Palette.ink,
                fontWeight: FontWeight.bold,
                fontSize: 18),
          ),
        ),
        body: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(24.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const SizedBox(height: 8),
                Text(
                  tr('One last step'),
                  style: TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                      color: _Palette.ink),
                ),
                const SizedBox(height: 6),
                Text(
                  tr('Take a clear selfie so drivers and passengers can recognise you during trips.'),
                  style:
                      TextStyle(color: _Palette.inkMuted, fontSize: 14),
                ),
                const SizedBox(height: 32),

                // Preview
                Center(
                  child: Stack(
                    children: [
                      Container(
                        width: 180,
                        height: 180,
                        decoration: BoxDecoration(
                          color: _Palette.cream,
                          shape: BoxShape.circle,
                          border: Border.all(
                            color: _Palette.blue,
                            width: 3,
                          ),
                          image: _preview != null
                              ? DecorationImage(
                                  image: MemoryImage(_preview!),
                                  fit: BoxFit.cover,
                                )
                              : null,
                        ),
                        child: _preview == null
                            ? const Icon(
                                Icons.face_retouching_natural,
                                size: 80,
                                color: _Palette.inkMuted,
                              )
                            : null,
                      ),
                      if (_uploading)
                        Positioned.fill(
                          child: Container(
                            decoration: const BoxDecoration(
                              color: Colors.black45,
                              shape: BoxShape.circle,
                            ),
                            child: const Center(
                              child: CircularProgressIndicator(
                                color: Colors.white,
                                strokeWidth: 3,
                              ),
                            ),
                          ),
                        ),
                    ],
                  ),
                ),

                const SizedBox(height: 24),

                if (_error != null) ...[
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: Colors.red.shade50,
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: Colors.red.shade200),
                    ),
                    child: Row(
                      children: [
                        const Icon(Icons.error_outline,
                            color: Colors.red, size: 18),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            _error!.message,
                            style: const TextStyle(
                                color: Colors.red, fontSize: 13.5),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 16),
                ],

                ElevatedButton.icon(
                  onPressed: _uploading ? null : _captureAndUpload,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFFF2B705),
                    foregroundColor: const Color(0xFF0B1220),
                    padding: const EdgeInsets.symmetric(vertical: 18),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(14),
                    ),
                  ),
                  icon: Icon(
                    _preview == null
                        ? Icons.camera_alt
                        : Icons.camera_alt_outlined,
                    size: 22,
                  ),
                  label: Text(
                    _preview == null ? 'Open camera' : 'Retake photo',
                    style: const TextStyle(
                        fontWeight: FontWeight.bold, fontSize: 16),
                  ),
                ),

                const Spacer(),

                Text(
                  tr('Your photo is visible to drivers and passengers during trips.'),
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 13, color: _Palette.inkMuted),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Future<void> _confirmExit() async {
    final leave = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Text(tr('Photo required')),
        content: Text(
          tr('A profile photo is required to continue. You can skip for now, but you won\'t be able to book or accept rides.'),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: Text(tr('Stay')),
          ),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: Text(tr('Skip for now'),
                style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );

    if (leave == true && mounted) {
      Navigator.of(context).pop(false);
    }
  }

  Future<void> _captureAndUpload() async {
    if (_uploading) return;
    setState(() => _error = null);

    try {
      final shot = await _picker.pickImage(
        source: ImageSource.camera,
        preferredCameraDevice: CameraDevice.front,
        maxWidth: 800,
        maxHeight: 800,
        imageQuality: 85,
      );

      if (shot == null) {
        if (!mounted) return;
        setState(() {
          _error = AppError(
            title: tr('Photo required'),
            message: tr('Take a selfie to continue.'),
            icon: Icons.camera_alt,
          );
        });
        return;
      }

      final bytes = await shot.readAsBytes();
      if (!mounted) return;
      setState(() {
        _preview = bytes;
        _uploading = true;
      });

      final userId = Supabase.instance.client.auth.currentUser?.id;
      if (userId == null) throw Exception('Not signed in');

      final ext =
          shot.name.contains('.') ? shot.name.split('.').last : 'jpg';
      final path = '$userId/avatar.$ext';

      await Supabase.instance.client.storage.from('avatars').uploadBinary(
            path,
            bytes,
            fileOptions: const FileOptions(upsert: true),
          );

      final publicUrl = Supabase.instance.client.storage
          .from('avatars')
          .getPublicUrl(path);

      await Supabase.instance.client.from('profiles').update({
        'profile_picture_url': publicUrl,
        'avatar_url': publicUrl,
      }).eq('id', userId);

      if (!mounted) return;
      setState(() => _uploading = false);

      ErrorUI.showSnack(
        context,
        AppError(
          title: tr('Photo saved'),
          message: tr('You\'re all set.'),
          icon: Icons.check_circle_outline,
        ),
      );

      await Future.delayed(const Duration(milliseconds: 600));
      if (!mounted) return;
      Navigator.of(context).pop(true);
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _uploading = false;
        _error = AppError.from(e, onRetry: _captureAndUpload);
      });
    }
  }
}
