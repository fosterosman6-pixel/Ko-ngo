﻿// lib/screens/customer/sos_setup_screen.dart

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:efuride_app/config/app_images.dart';
import 'package:efuride_app/widgets/app_image.dart';
import 'package:efuride_app/utils/app_error.dart';
import 'package:efuride_app/utils/error_ui.dart';
import 'package:efuride_app/utils/phone_utils.dart';
import 'package:efuride_app/l10n/app_strings.dart';
import 'package:efuride_app/widgets/k_icon.dart';

class _Palette {
  static const cream = Color(0xFFFAF6EE);
  static const ink = Color(0xFF1A1A1A);
  static const inkMuted = Color(0xFF575047);
  static const accent = Color(0xFFF2B705);
  static const divider = Color(0xFFE8E2D5);
  static const blue = Color(0xFF1E88E5);
  static const pickup = Color(0xFF34C759);
}

class SOSSetupScreen extends StatefulWidget {
  const SOSSetupScreen({super.key});

  @override
  State<SOSSetupScreen> createState() => _SOSSetupScreenState();
}

class _SOSSetupScreenState extends State<SOSSetupScreen> {
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _phoneController = TextEditingController();

  List<Map<String, dynamic>> _contacts = [];
  bool _isLoading = true;
  bool _isSaving = false;
  AppError? _error;

  static const int _maxContacts = 5;

  @override
  void initState() {
    super.initState();
    _loadContacts();
  }

  @override
  void dispose() {
    _nameController.dispose();
    _phoneController.dispose();
    super.dispose();
  }

  Future<void> _loadContacts() async {
    setState(() {
      _isLoading = true;
      _error = null;
    });

    try {
      final userId = Supabase.instance.client.auth.currentUser?.id;
      if (userId == null) throw Exception('Not signed in');

      final rows = await Supabase.instance.client
          .from('emergency_contacts')
          .select()
          .eq('user_id', userId)
          .order('created_at', ascending: true);

      if (!mounted) return;
      setState(() {
        _contacts = List<Map<String, dynamic>>.from(rows);
        _isLoading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _isLoading = false;
        _error = AppError.from(e, onRetry: _loadContacts);
      });
    }
  }

  Future<void> _addContact() async {
    final name = _nameController.text.trim();
    final phoneRaw = _phoneController.text.trim();

    if (name.isEmpty || phoneRaw.isEmpty) {
      ErrorUI.showSnack(
        context,
        AppError(
          title: tr('Missing details'),
          message: tr('Enter both a name and phone number.'),
          icon: Icons.info_outline,
        ),
      );
      return;
    }
    if (name.length < 2) {
      ErrorUI.showSnack(
        context,
        AppError(
          title: tr('Name too short'),
          message: tr('Please enter at least 2 characters.'),
          icon: Icons.info_outline,
        ),
      );
      return;
    }

    final phone = PhoneUtils.normalise(phoneRaw);
    if (phone == null || !PhoneUtils.isValid(phone)) {
      ErrorUI.showSnack(
        context,
        AppError(
          title: tr('Invalid phone number'),
          message: tr('Please check the number and try again.'),
          icon: Icons.phone_disabled_outlined,
        ),
      );
      return;
    }

    if (_contacts.length >= _maxContacts) {
      ErrorUI.showSnack(
        context,
        AppError(
          title: tr('Limit reached'),
          message: tr('You can save up to {0} contacts.', [_maxContacts]),
          icon: Icons.info_outline,
        ),
      );
      return;
    }
    if (_contacts.any((c) => c['phone'] == phone)) {
      ErrorUI.showSnack(
        context,
        AppError(
          title: tr('Already added'),
          message: tr('That number is already in your list.'),
          icon: Icons.info_outline,
        ),
      );
      return;
    }

    final userId = Supabase.instance.client.auth.currentUser?.id;
    if (userId == null) return;

    setState(() => _isSaving = true);
    try {
      final inserted = await Supabase.instance.client
          .from('emergency_contacts')
          .insert({
            'user_id': userId,
            'name': name,
            'phone': phone,
            'created_at': DateTime.now().toUtc().toIso8601String(),
          })
          .select()
          .single();

      if (!mounted) return;
      setState(() {
        _contacts.add(Map<String, dynamic>.from(inserted));
        _nameController.clear();
        _phoneController.clear();
        _isSaving = false;
      });
      ErrorUI.showSnack(
        context,
        AppError(
          title: tr('Contact added'),
          message: tr('They\'ll be notified when you trigger SOS.'),
          icon: Icons.check_circle_outline,
        ),
      );
    } catch (e) {
      if (!mounted) return;
      setState(() => _isSaving = false);
      ErrorUI.showSnack(context, AppError.from(e, onRetry: _addContact));
    }
  }

  Future<void> _removeContact(int index) async {
    final contact = _contacts[index];
    final id = contact['id']?.toString();
    if (id == null) return;

    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Text(tr('Remove contact?')),
        content:
            Text(tr('Are you sure you want to remove "{0}"?', [contact['name']])),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: Text(tr('Cancel')),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFFE53935)),
            onPressed: () => Navigator.pop(ctx, true),
            child: Text(tr('Remove')),
          ),
        ],
      ),
    );

    if (confirmed != true) return;

    try {
      await Supabase.instance.client
          .from('emergency_contacts')
          .delete()
          .eq('id', id);
      if (!mounted) return;
      setState(() => _contacts.removeAt(index));
      ErrorUI.showSnack(
        context,
        AppError(
          title: tr('Contact removed'),
          message: tr('They will no longer be notified.'),
          icon: Icons.check_circle_outline,
        ),
      );
    } catch (e) {
      if (!mounted) return;
      ErrorUI.showSnack(
        context,
        AppError.from(e, onRetry: () => _removeContact(index)),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _Palette.cream,
      appBar: AppBar(
        backgroundColor: _Palette.cream,
        elevation: 0,
        iconTheme: const IconThemeData(color: _Palette.ink),
        title: Text(
          tr('Emergency contacts'),
          style: TextStyle(
              color: _Palette.ink,
              fontWeight: FontWeight.bold,
              fontSize: 18),
        ),
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  AppImage(
                    AppImages.shieldCheck,
                    size: 22,
                    fallbackIcon: Icons.contact_phone_outlined,
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      tr('Add emergency contacts who will be notified when you trigger SOS.'),
                      style:
                          TextStyle(color: _Palette.inkMuted, fontSize: 14),
                      textAlign: TextAlign.center,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: _Palette.divider),
                ),
                child: Column(
                  children: [
                    TextField(
                      controller: _nameController,
                      textCapitalization: TextCapitalization.words,
                      decoration: InputDecoration(
                        labelText: tr('Contact name'),
                        border: OutlineInputBorder(),
                        prefixIcon: KIcon(Icons.person),
                      ),
                    ),
                    const SizedBox(height: 8),
                    TextField(
                      controller: _phoneController,
                      keyboardType: TextInputType.phone,
                      inputFormatters: [
                        FilteringTextInputFormatter.allow(
                            RegExp(r'[0-9+\s\-()]')),
                      ],
                      decoration: InputDecoration(
                        labelText: tr('Phone number'),
                        hintText: '+27 82 123 4567',
                        border: OutlineInputBorder(),
                        prefixIcon: Icon(Icons.phone),
                      ),
                    ),
                    const SizedBox(height: 12),
                    ElevatedButton.icon(
                      onPressed: _isSaving ? null : _addContact,
                      icon: _isSaving
                          ? const SizedBox(
                              width: 18,
                              height: 18,
                              child: CircularProgressIndicator(
                                  strokeWidth: 2, color: Colors.white),
                            )
                          : const Icon(Icons.add),
                      label: Text(_isSaving ? 'Saving…' : 'Add contact'),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFFF2B705),
                        foregroundColor: const Color(0xFF0B1220),
                        minimumSize: const Size(double.infinity, 48),
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10)),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 16),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    tr('Your emergency contacts'),
                    style: TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.bold,
                        color: _Palette.ink),
                  ),
                  Text(
                    '${_contacts.length}/$_maxContacts',
                    style: const TextStyle(
                        fontSize: 13.5, color: _Palette.inkMuted),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              Expanded(child: _buildList()),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildList() {
    if (_isLoading) {
      return const Center(
          child: CircularProgressIndicator(color: _Palette.accent));
    }
    if (_error != null) {
      return ErrorUI.inline(_error!);
    }
    if (_contacts.isEmpty) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              AppImage(
                AppImages.shieldInfo,
                size: 64,
                tint: _Palette.inkMuted,
                fallbackIcon: Icons.contact_phone_outlined,
              ),
              const SizedBox(height: 12),
              Text(tr('No emergency contacts yet'),
                  style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.bold,
                      color: _Palette.ink)),
              const SizedBox(height: 6),
              Text(tr('Add at least one contact so SOS can reach someone.'),
                  style:
                      TextStyle(fontSize: 13.5, color: _Palette.inkMuted),
                  textAlign: TextAlign.center),
            ],
          ),
        ),
      );
    }

    return ListView.separated(
      itemCount: _contacts.length,
      separatorBuilder: (_, __) => const SizedBox(height: 6),
      itemBuilder: (_, i) {
        final contact = _contacts[i];
        return Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: _Palette.divider),
          ),
          child: Row(
            children: [
              Container(
                width: 40,
                height: 40,
                decoration: const BoxDecoration(
                  color: _Palette.blue,
                  shape: BoxShape.circle,
                ),
                child: const Center(
                  child: KIcon(Icons.person, color: Colors.white, size: 22),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(contact['name']?.toString() ?? '',
                        style: const TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w600,
                            color: _Palette.ink)),
                    const SizedBox(height: 2),
                    Text(PhoneUtils.mask(contact['phone']?.toString() ?? ''),
                        style: const TextStyle(
                            fontSize: 13.5, color: _Palette.inkMuted)),
                  ],
                ),
              ),
              IconButton(
                icon: const Icon(Icons.delete_outline,
                    color: Color(0xFFE53935)),
                onPressed: () => _removeContact(i),
              ),
            ],
          ),
        );
      },
    );
  }
}
