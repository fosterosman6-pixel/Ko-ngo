// lib/screens/shared/verify_screen.dart
//
// "Verify me": drivers, shoppers and merchants upload their papers
// (ID, selfie, licence, business registration...). ko!ngo admin checks
// them; when every REQUIRED paper is accepted the Verified badge appears.
// Papers live in the private driver_documents folder. Needs step44.

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:efuride_app/config/efuride_palette.dart';
import 'package:efuride_app/l10n/app_strings.dart';
import 'package:efuride_app/providers/auth_provider.dart';
import 'package:efuride_app/utils/app_error.dart';
import 'package:efuride_app/utils/error_ui.dart';
import 'package:efuride_app/widgets/private_image.dart';
import 'package:efuride_app/widgets/verified_badge.dart';
import 'package:efuride_app/widgets/k_icon.dart';

class _DocType {
  final String key, label, hint;
  final bool required;
  const _DocType(this.key, this.label, this.hint, {this.required = true});
}

List<_DocType> _typesFor(String role, String country) {
  final cg = country.toUpperCase() == 'CG';
  final common = [
    _DocType('id_card', tr('National ID / Passport'),
        tr('Clear photo of the whole document')),
    _DocType('selfie', tr('Selfie holding your ID'),
        tr('Your face and the ID must both be readable')),
  ];
  switch (role.toLowerCase()) {
    case 'driver':
      return [
        ...common,
        _DocType('license', tr('Driving licence'),
            tr('Valid, for your type of vehicle')),
        _DocType('logbook', tr('Vehicle registration & insurance'),
            tr('Registration paper and valid insurance')),
        _DocType('police_clearance', tr('Police clearance'),
            tr('Criminal record extract, not older than 6 months')),
        _DocType('roadworthy',
            cg ? tr('Technical inspection') : tr('Roadworthy certificate'),
            tr('If your vehicle needs one'), required: false),
        if (!cg)
          _DocType('prdp', tr('Professional driving permit (PrDP)'),
              tr('For paid passenger transport'), required: false),
      ];
    case 'shopper':
      return [
        ...common,
        _DocType('police_clearance', tr('Police clearance'),
            tr('Criminal record extract, not older than 6 months')),
      ];
    case 'merchant':
      return [
        ...common,
        _DocType('business_reg',
            cg ? tr('Business registration (RCCM)') : tr('Business registration (CIPC)'),
            tr('Registration paper of your business')),
        _DocType('shop_photo', tr('Photo of your shop front'),
            tr('Show the sign and the entrance')),
        _DocType('tax_number',
            cg ? tr('Tax number (NIU)') : tr('Tax number (SARS)'),
            tr('Adds trust, not required'), required: false),
        _DocType('health_cert', tr('Health certificate'),
            tr('Food sellers: certificate from your municipality'),
            required: false),
      ];
    default:
      return common;
  }
}

class VerifyScreen extends StatefulWidget {
  const VerifyScreen({super.key});
  @override
  State<VerifyScreen> createState() => _VerifyScreenState();
}

class _VerifyScreenState extends State<VerifyScreen> {
  final _picker = ImagePicker();
  final Map<String, Map<String, dynamic>> _rows = {};
  final Set<String> _busy = {};
  bool _loading = true;
  bool _verified = false;
  AppError? _error;

  SupabaseClient get _sb => Supabase.instance.client;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final uid = _sb.auth.currentUser?.id;
      if (uid == null) throw Exception('Not signed in');
      final rows = await _sb
          .from('documents')
          .select('type, status, file_url, reject_reason')
          .eq('user_id', uid)
          .timeout(const Duration(seconds: 15));
      _rows.clear();
      for (final r in rows) {
        _rows[(r['type'] ?? '').toString()] = Map<String, dynamic>.from(r);
      }
      try {
        final me = await _sb.from('profiles').select('is_verified').eq('id', uid).maybeSingle();
        _verified = me?['is_verified'] == true;
      } catch (_) {}
      if (mounted) setState(() => _loading = false);
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _error = AppError.from(e, onRetry: _load);
      });
    }
  }

  Future<void> _upload(String type, String label, ImageSource src) async {
    if (_busy.contains(type)) return;
    setState(() => _busy.add(type));
    try {
      final img = await _picker.pickImage(
          source: src, maxWidth: 1600, maxHeight: 1600, imageQuality: 80);
      if (img == null) return;
      final uid = _sb.auth.currentUser?.id;
      if (uid == null) throw Exception('Not signed in');
      final bytes = await img.readAsBytes();
      final ext = img.name.contains('.') ? img.name.split('.').last : 'jpg';
      final path = '$uid/$type-${DateTime.now().millisecondsSinceEpoch}.$ext';
      await _sb.storage.from('driver_documents').uploadBinary(path, bytes,
          fileOptions: const FileOptions(upsert: true));
      final url = _sb.storage.from('driver_documents').getPublicUrl(path);
      final existing = await _sb
          .from('documents')
          .select('id')
          .eq('user_id', uid)
          .eq('type', type)
          .maybeSingle();
      final now = DateTime.now().toUtc().toIso8601String();
      if (existing == null) {
        await _sb.from('documents').insert({
          'user_id': uid, 'type': type, 'name': label,
          'file_url': url, 'status': 'Pending', 'created_at': now,
        });
      } else {
        await _sb.from('documents').update({
          'file_url': url, 'status': 'Pending', 'updated_at': now,
        }).eq('id', existing['id']);
      }
      _rows[type] = {'type': type, 'status': 'Pending', 'file_url': url};
    } catch (e) {
      if (mounted) {
        ErrorUI.showSnack(context, AppError.from(e));
      }
    } finally {
      if (mounted) setState(() => _busy.remove(type));
    }
  }

  void _pickSource(String type, String label) {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: EfuridePalette.cream,
      builder: (ctx) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          ListTile(
            leading: const Icon(Icons.photo_camera_outlined),
            title: Text(tr('Take a photo')),
            onTap: () {
              Navigator.pop(ctx);
              _upload(type, label, ImageSource.camera);
            },
          ),
          ListTile(
            leading: const KIcon(Icons.photo_library_outlined),
            title: Text(tr('Choose from gallery')),
            onTap: () {
              Navigator.pop(ctx);
              _upload(type, label, ImageSource.gallery);
            },
          ),
        ]),
      ),
    );
  }

  void _preview(String url, String label) {
    showDialog<void>(
      context: context,
      builder: (_) => Dialog(
        backgroundColor: Colors.black87,
        insetPadding: const EdgeInsets.all(12),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Padding(
            padding: const EdgeInsets.all(12),
            child: Text(label,
                style: const TextStyle(
                    color: Colors.white, fontWeight: FontWeight.bold)),
          ),
          Flexible(
              child: InteractiveViewer(
                  child: PrivateImage(url: url, fit: BoxFit.contain))),
          TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text(tr('Close'),
                  style: const TextStyle(color: Colors.white))),
        ]),
      ),
    );
  }

  Color _statusColor(String s) {
    switch (s) {
      case 'Verified':
        return EfuridePalette.pickup;
      case 'Rejected':
        return EfuridePalette.dropoff;
      default:
        return EfuridePalette.accent;
    }
  }

  String _statusLabel(String s) {
    switch (s) {
      case 'Verified':
        return tr('Accepted');
      case 'Rejected':
        return tr('Not accepted');
      case 'Pending':
        return tr('Waiting for review');
      default:
        return tr('Not uploaded');
    }
  }

  Widget _tile(_DocType d) {
    final r = _rows[d.key];
    final status = (r?['status'] ?? '').toString();
    final url = (r?['file_url'] ?? '').toString();
    final busy = _busy.contains(d.key);
    final shown = r == null ? '' : status;
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: EfuridePalette.divider),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Expanded(
            child: Text(d.label,
                style: const TextStyle(
                    fontSize: 15.5, fontWeight: FontWeight.w800)),
          ),
          if (!d.required)
            Text(tr('Optional'),
                style: const TextStyle(
                    fontSize: 12.5, color: EfuridePalette.inkMuted)),
        ]),
        const SizedBox(height: 2),
        Text(d.hint,
            style: const TextStyle(
                fontSize: 13, color: EfuridePalette.inkMuted)),
        const SizedBox(height: 8),
        Row(children: [
          if (url.isNotEmpty)
            GestureDetector(
              onTap: () => _preview(url, d.label),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: SizedBox(
                    width: 52,
                    height: 52,
                    child: PrivateImage(url: url, fit: BoxFit.cover)),
              ),
            ),
          if (url.isNotEmpty) const SizedBox(width: 10),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
            decoration: BoxDecoration(
              color: _statusColor(shown).withOpacity(0.16),
              borderRadius: BorderRadius.circular(20),
            ),
            child: Text(_statusLabel(shown),
                style: TextStyle(
                    fontSize: 12.5,
                    fontWeight: FontWeight.w800,
                    color: shown == 'Pending'
                        ? EfuridePalette.ink
                        : _statusColor(shown))),
          ),
          const Spacer(),
          if (shown != 'Verified')
            OutlinedButton(
              onPressed: busy ? null : () => _pickSource(d.key, d.label),
              child: busy
                  ? const SizedBox(
                      width: 16,
                      height: 16,
                      child: CircularProgressIndicator(strokeWidth: 2))
                  : Text(url.isEmpty ? tr('Upload') : tr('Replace')),
            ),
        ]),
        if (shown == 'Rejected' &&
            (r?['reject_reason'] ?? '').toString().isNotEmpty) ...[
          const SizedBox(height: 6),
          Text(r!['reject_reason'].toString(),
              style: const TextStyle(
                  fontSize: 13, color: EfuridePalette.dropoff)),
        ],
      ]),
    );
  }

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    final types = _typesFor(auth.role, auth.country.isoCode);
    final req = types.where((t) => t.required).toList();
    final done = req.where((t) => _rows[t.key]?['status'] == 'Verified').length;
    return Scaffold(
      backgroundColor: EfuridePalette.cream,
      appBar: AppBar(
        backgroundColor: EfuridePalette.cream,
        elevation: 0,
        foregroundColor: EfuridePalette.ink,
        title: Text(tr('Verify me'),
            style: const TextStyle(fontWeight: FontWeight.w900)),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _error != null
              ? Center(
                  child: Padding(
                  padding: const EdgeInsets.all(24),
                  child: Column(mainAxisSize: MainAxisSize.min, children: [
                    Text(_error!.message, textAlign: TextAlign.center),
                    const SizedBox(height: 12),
                    ElevatedButton(onPressed: _load, child: Text(tr('Try again'))),
                  ]),
                ))
              : RefreshIndicator(
                  onRefresh: _load,
                  child: ListView(
                    padding: const EdgeInsets.fromLTRB(16, 8, 16, 32),
                    children: [
                      Container(
                        padding: const EdgeInsets.all(14),
                        decoration: BoxDecoration(
                          color: EfuridePalette.accent.withOpacity(0.18),
                          borderRadius: BorderRadius.circular(14),
                        ),
                        child: Row(children: [
                          const VerifiedBadge(size: 30),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Text(
                              _verified
                                  ? tr('You are verified. Customers see your badge.')
                                  : tr('{0} of {1} required papers accepted. When all are accepted you get the Verified badge.',
                                      ['$done', '${req.length}']),
                              style: const TextStyle(
                                  fontSize: 14.5, fontWeight: FontWeight.w700),
                            ),
                          ),
                        ]),
                      ),
                      const SizedBox(height: 12),
                      Text(
                          tr('Your papers are private. Only ko!ngo admin can see them.'),
                          style: const TextStyle(
                              fontSize: 13, color: EfuridePalette.inkMuted)),
                      const SizedBox(height: 12),
                      for (final t in types) _tile(t),
                    ],
                  ),
                ),
    );
  }
}
