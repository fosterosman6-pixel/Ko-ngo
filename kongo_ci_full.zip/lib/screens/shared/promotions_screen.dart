﻿// lib/screens/shared/promotions_screen.dart
//
// Live offers: the active promo codes ko!ngo admins create (admin app →
// Promotions). Customers copy a code and use it at booking or checkout,
// where the server checks it.

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'package:efuride_app/config/country_config.dart';
import 'package:efuride_app/config/efuride_palette.dart';
import 'package:efuride_app/l10n/app_strings.dart';
import 'package:efuride_app/utils/app_error.dart';
import 'package:efuride_app/utils/error_ui.dart';
import 'package:efuride_app/widgets/k_icon.dart';

class PromotionsScreen extends StatefulWidget {
  const PromotionsScreen({super.key});

  @override
  State<PromotionsScreen> createState() => _PromotionsScreenState();
}

class _PromotionsScreenState extends State<PromotionsScreen> {
  List<Map<String, dynamic>> _promos = [];
  bool _loading = true;
  AppError? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final rows = List<Map<String, dynamic>>.from(await Supabase
          .instance.client
          .from('promotions')
          .select()
          .order('created_at', ascending: false)
          .timeout(const Duration(seconds: 15)));
      final now = DateTime.now().toUtc();
      bool live(Map<String, dynamic> p) {
        if (p['is_active'] == false) return false;
        final st = (p['status'] ?? 'active').toString().toLowerCase();
        if (st == 'inactive' || st == 'expired' || st == 'disabled') {
          return false;
        }
        final start = DateTime.tryParse('${p['start_date'] ?? ''}');
        final end = DateTime.tryParse(
            '${p['expiry_date'] ?? p['expires_at'] ?? ''}');
        if (start != null && now.isBefore(start.toUtc())) return false;
        if (end != null && now.isAfter(end.toUtc())) return false;
        final max = (p['max_uses'] as num?)?.toInt() ?? 0;
        final used = (p['used_count'] as num?)?.toInt() ?? 0;
        if (max > 0 && used >= max) return false;
        return (p['code'] ?? '').toString().trim().isNotEmpty;
      }

      if (!mounted) return;
      setState(() {
        _promos = rows.where(live).toList();
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _error = AppError.from(e, onRetry: _load);
      });
    }
  }

  String _value(Map<String, dynamic> p) {
    final v = (p['discount_value'] as num?)?.toDouble() ?? 0;
    final percent =
        (p['discount_type'] ?? 'percent').toString().toLowerCase() == 'percent';
    return percent
        ? tr('{0}% off', [v.toStringAsFixed(v % 1 == 0 ? 0 : 1)])
        : tr('{0} off', [CountryConfig.money(v)]);
  }

  String? _expiry(Map<String, dynamic> p) {
    final end =
        DateTime.tryParse('${p['expiry_date'] ?? p['expires_at'] ?? ''}');
    if (end == null) return null;
    final d = end.toLocal();
    return tr('Valid until {0}',
        ['${d.day.toString().padLeft(2, '0')}/${d.month.toString().padLeft(2, '0')}/${d.year}']);
  }

  Future<void> _copy(String code) async {
    await Clipboard.setData(ClipboardData(text: code));
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      behavior: SnackBarBehavior.floating,
      content: Text(
        tr('Code {0} copied. Paste it when you book or check out.', [code]),
        style: const TextStyle(fontSize: 15),
      ),
    ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: EfuridePalette.cream,
      appBar: AppBar(
        backgroundColor: EfuridePalette.cream,
        foregroundColor: EfuridePalette.ink,
        elevation: 0,
        scrolledUnderElevation: 0,
        title: Text(tr('Promotions'),
            style: const TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.w800,
                color: EfuridePalette.ink)),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _error != null
              ? ErrorUI.inline(_error!)
              : RefreshIndicator(
                  onRefresh: _load,
                  child: _promos.isEmpty
                      ? ListView(
                          physics: const AlwaysScrollableScrollPhysics(),
                          children: [
                            const SizedBox(height: 120),
                            const KIcon(Icons.local_offer_outlined,
                                size: 56, color: EfuridePalette.inkMuted),
                            const SizedBox(height: 14),
                            Center(
                              child: Text(tr('No offers right now'),
                                  style: const TextStyle(
                                      fontSize: 17,
                                      fontWeight: FontWeight.w800)),
                            ),
                            const SizedBox(height: 6),
                            Center(
                              child: Text(tr('New promo codes will show here.'),
                                  style: const TextStyle(
                                      fontSize: 15,
                                      color: EfuridePalette.inkMuted)),
                            ),
                          ],
                        )
                      : ListView.separated(
                          padding: const EdgeInsets.all(16),
                          physics: const AlwaysScrollableScrollPhysics(),
                          itemCount: _promos.length,
                          separatorBuilder: (_, __) =>
                              const SizedBox(height: 10),
                          itemBuilder: (_, i) => _card(_promos[i]),
                        ),
                ),
    );
  }

  Widget _card(Map<String, dynamic> p) {
    final code = (p['code'] ?? '').toString().trim().toUpperCase();
    final desc = (p['description'] ?? '').toString().trim();
    final min = (p['min_fare'] as num?)?.toDouble() ?? 0;
    final expiry = _expiry(p);
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: EfuridePalette.divider),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(_value(p),
              style: const TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.w900,
                  color: EfuridePalette.ink)),
          if (desc.isNotEmpty) ...[
            const SizedBox(height: 4),
            Text(desc,
                style: const TextStyle(
                    fontSize: 15.5, color: EfuridePalette.ink, height: 1.35)),
          ],
          const SizedBox(height: 8),
          Text(
            [
              if (min > 0) tr('Minimum {0}', [CountryConfig.money(min)]),
              if (expiry != null) expiry,
            ].join('  ·  '),
            style: const TextStyle(
                fontSize: 14, color: EfuridePalette.inkMuted),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
                  decoration: BoxDecoration(
                    color: EfuridePalette.greyBg,
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(
                        color: EfuridePalette.divider,
                        style: BorderStyle.solid),
                  ),
                  child: Text(code,
                      style: const TextStyle(
                          fontSize: 17,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 1.5)),
                ),
              ),
              const SizedBox(width: 10),
              ElevatedButton.icon(
                onPressed: () => _copy(code),
                icon: const Icon(Icons.copy, size: 18),
                label: Text(tr('Copy'),
                    style: const TextStyle(
                        fontSize: 15, fontWeight: FontWeight.w800)),
                style: ElevatedButton.styleFrom(
                  backgroundColor: EfuridePalette.accent,
                  foregroundColor: EfuridePalette.accentInk,
                  minimumSize: const Size(0, 48),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10)),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
