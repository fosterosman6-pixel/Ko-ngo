// lib/screens/shared/messages_screen.dart
//
// Messages inbox (every role): ko!ngo Support on top, then one row per
// trip / delivery chat — active trips and trips that ended in the last
// 7 days (those are read-only). Data from my_conversations() (step18).

import 'dart:async';

import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'package:efuride_app/config/efuride_palette.dart';
import 'package:efuride_app/l10n/app_strings.dart';
import 'package:efuride_app/utils/app_error.dart';
import 'package:efuride_app/utils/error_ui.dart';
import 'package:efuride_app/widgets/k_icon.dart';

class MessagesScreen extends StatefulWidget {
  const MessagesScreen({super.key});

  @override
  State<MessagesScreen> createState() => _MessagesScreenState();
}

class _MessagesScreenState extends State<MessagesScreen> {
  final _db = Supabase.instance.client;
  List<Map<String, dynamic>> _chats = [];
  int _supportUnread = 0;
  String? _supportLast;
  bool _loading = true;
  AppError? _error;
  RealtimeChannel? _channel;

  @override
  void initState() {
    super.initState();
    _load();
    // Any new chat message → refresh the list (RLS only delivers ours).
    _channel = _db
        .channel('inbox_${DateTime.now().millisecondsSinceEpoch}')
        .onPostgresChanges(
          event: PostgresChangeEvent.insert,
          schema: 'public',
          table: 'ride_messages',
          callback: (_) => _load(quiet: true),
        )
        .subscribe();
  }

  @override
  void dispose() {
    if (_channel != null) _db.removeChannel(_channel!);
    super.dispose();
  }

  Future<void> _load({bool quiet = false}) async {
    if (!quiet) {
      setState(() {
        _loading = true;
        _error = null;
      });
    }
    try {
      final res = await _db.rpc('my_conversations').timeout(
          const Duration(seconds: 15));
      final list = res is List
          ? res.map((e) => Map<String, dynamic>.from(e as Map)).toList()
          : <Map<String, dynamic>>[];

      int sUnread = 0;
      String? sLast;
      final uid = _db.auth.currentUser?.id;
      if (uid != null) {
        try {
          final t = await _db
              .from('support_tickets')
              .select('unread_for_user, last_message, last_message_at, created_at')
              .eq('user_id', uid)
              .order('created_at', ascending: false)
              .limit(20);
          for (final r in t) {
            sUnread += ((r['unread_for_user'] as num?) ?? 0).toInt();
          }
          if (t.isNotEmpty) sLast = (t.first['last_message'] ?? '').toString();
        } catch (_) {}
      }
      if (!mounted) return;
      setState(() {
        _chats = list;
        _supportUnread = sUnread;
        _supportLast = sLast;
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _error = AppError.from(e, onRetry: _load);
      });
    }
  }

  String _when(dynamic v) {
    final d = DateTime.tryParse('${v ?? ''}')?.toLocal();
    if (d == null) return '';
    final now = DateTime.now();
    final hm =
        '${d.hour.toString().padLeft(2, '0')}:${d.minute.toString().padLeft(2, '0')}';
    if (d.year == now.year && d.month == now.month && d.day == now.day) {
      return hm;
    }
    final y = now.subtract(const Duration(days: 1));
    if (d.year == y.year && d.month == y.month && d.day == y.day) {
      return tr('Yesterday');
    }
    return '${d.day.toString().padLeft(2, '0')}/${d.month.toString().padLeft(2, '0')}';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: EfuridePalette.cream,
      appBar: AppBar(
        backgroundColor: EfuridePalette.cream,
        foregroundColor: EfuridePalette.ink,
        elevation: 0,
        scrolledUnderElevation: 0,
        title: Text(tr('Messages'),
            style: const TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.w800,
                color: EfuridePalette.ink)),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _error != null
              ? ErrorUI.inline(_error!)
              : RefreshIndicator(
                  onRefresh: _load,
                  child: ListView(
                    padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
                    children: [
                      _supportRow(),
                      const SizedBox(height: 16),
                      Text(tr('Trips and deliveries'),
                          style: const TextStyle(
                              fontSize: 16, fontWeight: FontWeight.w800)),
                      const SizedBox(height: 8),
                      if (_chats.isEmpty)
                        Container(
                          padding: const EdgeInsets.all(20),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(14),
                            border: Border.all(color: EfuridePalette.divider),
                          ),
                          child: Text(
                            tr('Chats from your trips show here. Chats close when a trip ends and stay readable for 7 days.'),
                            textAlign: TextAlign.center,
                            style: const TextStyle(
                                fontSize: 15,
                                height: 1.35,
                                color: EfuridePalette.inkMuted),
                          ),
                        )
                      else
                        for (final c in _chats) ...[
                          _chatRow(c),
                          const SizedBox(height: 8),
                        ],
                    ],
                  ),
                ),
    );
  }

  Widget _supportRow() {
    return _row(
      avatar: const CircleAvatar(
        radius: 26,
        backgroundColor: EfuridePalette.accent,
        child: KIcon(Icons.support_agent, color: EfuridePalette.accentInk),
      ),
      title: tr('ko!ngo Support'),
      subtitle: (_supportLast ?? '').isNotEmpty
          ? _supportLast!
          : tr('Questions, problems, payments: we reply here.'),
      trailing: '',
      unread: _supportUnread,
      onTap: () async {
        await Navigator.pushNamed(context, '/support');
        _load(quiet: true);
      },
    );
  }

  Widget _chatRow(Map<String, dynamic> c) {
    final name = (c['other_name'] ?? '').toString().trim();
    final role = (c['other_role'] ?? '').toString();
    final photo = (c['other_photo'] ?? '').toString();
    final closed = c['closed'] == true;
    final unread = ((c['unread'] as num?) ?? 0).toInt();
    final mine = c['last_is_mine'] == true;
    var last = (c['last_message'] ?? '').toString();
    if (last.isEmpty && c['last_is_photo'] == true) last = '📷 ${tr('Photo')}';
    final who = name.isNotEmpty
        ? name
        : (role == 'driver' ? tr('Your driver') : tr('Customer'));
    final where = (c['dropoff'] ?? '').toString().split(',').first.trim();

    return _row(
      avatar: CircleAvatar(
        radius: 26,
        backgroundColor: EfuridePalette.greyBg,
        backgroundImage: photo.isNotEmpty ? NetworkImage(photo) : null,
        child: photo.isEmpty
            ? Text(who.substring(0, 1).toUpperCase(),
                style: const TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.w800,
                    color: EfuridePalette.ink))
            : null,
      ),
      title: who,
      subtitle: '${mine ? '${tr('You')}: ' : ''}$last',
      caption: [
        if (where.isNotEmpty) '→ $where',
        if (closed) tr('Trip ended'),
      ].join('  ·  '),
      trailing: _when(c['last_at']),
      unread: unread,
      onTap: () async {
        await Navigator.pushNamed(context, '/chat', arguments: {
          'rideId': c['ride_id'],
          'chatId': c['ride_id'],
          'otherName': who,
        });
        _load(quiet: true);
      },
    );
  }

  Widget _row({
    required Widget avatar,
    required String title,
    required String subtitle,
    String? caption,
    required String trailing,
    required int unread,
    required VoidCallback onTap,
  }) {
    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(14),
      child: InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(14),
            border: Border.all(
              color: unread > 0 ? EfuridePalette.accent : EfuridePalette.divider,
              width: unread > 0 ? 1.6 : 1,
            ),
          ),
          child: Row(
            children: [
              avatar,
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                            fontSize: 16, fontWeight: FontWeight.w800)),
                    const SizedBox(height: 2),
                    Text(subtitle,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                            fontSize: 14.5,
                            fontWeight:
                                unread > 0 ? FontWeight.w700 : FontWeight.w400,
                            color: unread > 0
                                ? EfuridePalette.ink
                                : EfuridePalette.inkMuted)),
                    if (caption != null && caption.isNotEmpty) ...[
                      const SizedBox(height: 2),
                      Text(caption,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                              fontSize: 13, color: EfuridePalette.inkMuted)),
                    ],
                  ],
                ),
              ),
              const SizedBox(width: 8),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text(trailing,
                      style: const TextStyle(
                          fontSize: 13, color: EfuridePalette.inkMuted)),
                  const SizedBox(height: 6),
                  if (unread > 0)
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 8, vertical: 3),
                      decoration: BoxDecoration(
                        color: EfuridePalette.dropoff,
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Text(unread > 9 ? '9+' : '$unread',
                          style: const TextStyle(
                              color: Colors.white,
                              fontSize: 12.5,
                              fontWeight: FontWeight.w800)),
                    ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// 💬 icon with the unread count, for home-screen headers.
class MessagesIconButton extends StatefulWidget {
  final Color color;
  const MessagesIconButton({super.key, this.color = EfuridePalette.ink});

  @override
  State<MessagesIconButton> createState() => _MessagesIconButtonState();
}

class _MessagesIconButtonState extends State<MessagesIconButton> {
  int _unread = 0;
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _refresh();
    _timer = Timer.periodic(const Duration(seconds: 30), (_) => _refresh());
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  Future<void> _refresh() async {
    try {
      final n = await Supabase.instance.client.rpc('my_unread_messages');
      if (mounted) setState(() => _unread = (n as num?)?.toInt() ?? 0);
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    return IconButton(
      tooltip: tr('Messages'),
      onPressed: () async {
        await Navigator.pushNamed(context, '/messages');
        _refresh();
      },
      icon: Badge(
        isLabelVisible: _unread > 0,
        label: Text(_unread > 9 ? '9+' : '$_unread'),
        child: KIcon(Icons.chat_bubble_outline, color: widget.color, size: 26),
      ),
    );
  }
}
