﻿import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:provider/provider.dart';
import 'package:efuride_app/config/efuride_palette.dart'; // Using global palette
import 'package:efuride_app/providers/auth_provider.dart';
import 'package:efuride_app/utils/app_error.dart';
import 'package:efuride_app/utils/error_ui.dart';
import 'package:efuride_app/l10n/app_strings.dart';
import 'package:efuride_app/widgets/k_icon.dart';

class PendingApprovalScreen extends StatefulWidget {
  const PendingApprovalScreen({super.key});

  @override
  State<PendingApprovalScreen> createState() =>
      _PendingApprovalScreenState();
}

class _PendingApprovalScreenState extends State<PendingApprovalScreen> {
  bool _checking = false;
  bool _approved = false;

  Future<void> _checkStatus() async {
    setState(() => _checking = true);

    try {
      final userId = Supabase.instance.client.auth.currentUser?.id;
      if (userId == null) throw Exception('Not signed in');

      final profile = await Supabase.instance.client
          .from('profiles')
          .select('is_active, is_blocked, role')
          .eq('id', userId)
          .maybeSingle();

      if (!mounted) return;
      setState(() => _checking = false);

      if (profile == null) {
        ErrorUI.showSnack(
          context,
          AppError(
            title: tr('Profile not found'),
            message: tr('Please sign in again.'),
            icon: Icons.person_off_outlined,
          ),
        );
        return;
      }

      if (profile['is_blocked'] == true) {
        ErrorUI.showSnack(
          context,
          AppError(
            title: tr('Account blocked'),
            message: tr('Contact support for more information.'),
            icon: Icons.block_outlined,
          ),
        );
        return;
      }

      if (profile['is_active'] == true) {
        setState(() => _approved = true);
        ErrorUI.showSnack(
          context,
          AppError(
            title: tr('You\'re approved!'),
            message: tr('Welcome aboard. Taking you to your dashboard.'),
            icon: Icons.check_circle_outline,
          ),
        );
        await Future.delayed(const Duration(milliseconds: 900));
        if (!mounted) return;

        // Route based on user role
        final role = profile['role']?.toString().toLowerCase() ?? 'customer';
        String route;
        switch (role) {
          case 'driver':
            route = '/driver';
            break;
          case 'shopper':
            route = '/shopper';
            break;
          case 'merchant':
            route = '/merchant';
            break;
          case 'customer':
          default:
            route = '/customer';
        }
        Navigator.pushNamedAndRemoveUntil(context, route, (_) => false);
        return;
      }

      ErrorUI.showSnack(
        context,
        AppError(
          title: tr('Still pending'),
          message:
              tr('An admin hasn\'t reviewed your account yet. Try again later.'),
          icon: Icons.hourglass_top,
        ),
      );
    } catch (e) {
      if (!mounted) return;
      setState(() => _checking = false);
      ErrorUI.showSnack(
        context,
        AppError.from(e, onRetry: _checkStatus),
      );
    }
  }

  Future<void> _logout() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16)),
        title: Text(tr('Log out?')),
        content: Text(
            tr('You can sign back in anytime to check your approval status.')),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: Text(tr('Cancel')),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            onPressed: () => Navigator.pop(ctx, true),
            child: Text(tr('Log out')),
          ),
        ],
      ),
    );
    if (confirmed != true) return;

    try {
      final auth = context.read<AuthProvider>();
      await auth.signOut();
      if (!mounted) return;
      Navigator.pushNamedAndRemoveUntil(
          context, '/role_select', (route) => false);
    } catch (e) {
      if (!mounted) return;
      ErrorUI.showSnack(context, AppError.from(e));
    }
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      child: Scaffold(
        backgroundColor: EfuridePalette.cream,
        appBar: AppBar(
          backgroundColor: EfuridePalette.cream,
          elevation: 0,
          automaticallyImplyLeading: false,
          iconTheme: const IconThemeData(color: EfuridePalette.ink),
          title: Text(
            tr('Account verification'),
            style: TextStyle(
                color: EfuridePalette.ink,
                fontWeight: FontWeight.bold,
                fontSize: 18),
          ),
          actions: [
            TextButton(
              onPressed: _logout,
              child: Text(tr('Log out'),
                  style: TextStyle(color: EfuridePalette.inkMuted)),
            ),
          ],
        ),
        body: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(24.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Container(
                  padding: const EdgeInsets.all(24),
                  decoration: BoxDecoration(
                    color: Colors.orange.withOpacity(0.1),
                    shape: BoxShape.circle,
                  ),
                  child: const Icon(
                    Icons.hourglass_top_rounded,
                    size: 56,
                    color: Colors.orange,
                  ),
                ),
                const SizedBox(height: 24),
                Text(
                  tr('Awaiting admin approval'),
                  textAlign: TextAlign.center,
                  style: TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                      color: EfuridePalette.ink),
                ),
                const SizedBox(height: 12),
                Text(
                  tr('Your documents have been submitted. An administrator will review them shortly — usually within a few hours.'),
                  textAlign: TextAlign.center,
                  style:
                      TextStyle(color: EfuridePalette.inkMuted, fontSize: 14),
                ),
                const SizedBox(height: 32),
                ElevatedButton.icon(
                  onPressed: _checking ? null : _checkStatus,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFFF2B705),
                    foregroundColor: const Color(0xFF0B1220),
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12)),
                  ),
                  icon: _checking
                      ? const SizedBox(
                          width: 18,
                          height: 18,
                          child: CircularProgressIndicator(
                              strokeWidth: 2, color: const Color(0xFF0B1220)),
                        )
                      : const Icon(Icons.refresh),
                  label: Text(_checking ? 'Checking…' : 'Check status'),
                ),
                const SizedBox(height: 12),
                OutlinedButton.icon(
                  onPressed: () =>
                      Navigator.pushNamed(context, '/driver_documents'),
                  icon: const KIcon(Icons.verified_user_outlined),
                  label: Text(tr('Review my documents')),
                  style: OutlinedButton.styleFrom(
                    foregroundColor: EfuridePalette.ink,
                    side: const BorderSide(color: EfuridePalette.divider),
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12)),
                  ),
                ),
                const SizedBox(height: 12),
                OutlinedButton.icon(
                  onPressed: () =>
                      Navigator.pushNamed(context, '/support'),
                  icon: const KIcon(Icons.support_agent),
                  label: Text(tr('Contact support')),
                  style: OutlinedButton.styleFrom(
                    foregroundColor: EfuridePalette.ink,
                    side: const BorderSide(color: EfuridePalette.divider),
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12)),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
