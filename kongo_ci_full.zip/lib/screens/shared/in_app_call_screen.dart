// lib/screens/shared/in_app_call_screen.dart
//
// The call screen: "Calling…", "Incoming call", and the live call.

import 'dart:async';

import 'package:flutter/material.dart';
import 'package:efuride_app/config/efuride_palette.dart';
import 'package:efuride_app/l10n/app_strings.dart';
import 'package:efuride_app/services/call_service.dart';

class InAppCallScreen extends StatefulWidget {
  const InAppCallScreen({super.key});

  /// Opens the call screen once (no stacking).
  static bool _open = false;
  static Future<void> show(BuildContext context) async {
    if (_open) return;
    _open = true;
    try {
      await Navigator.of(context, rootNavigator: true).push(
        MaterialPageRoute(
          fullscreenDialog: true,
          builder: (_) => const InAppCallScreen(),
        ),
      );
    } finally {
      _open = false;
    }
  }

  @override
  State<InAppCallScreen> createState() => _InAppCallScreenState();
}

class _InAppCallScreenState extends State<InAppCallScreen> {
  final _svc = CallService.instance;
  Timer? _tick;
  int _seconds = 0;

  @override
  void initState() {
    super.initState();
    _svc.phase.addListener(_onPhase);
    _tick = Timer.periodic(const Duration(seconds: 1), (_) {
      if (_svc.phase.value == CallPhase.connected && mounted) {
        setState(() => _seconds++);
      }
    });
  }

  void _onPhase() {
    if (!mounted) return;
    if (_svc.phase.value == CallPhase.idle) {
      final msg = _svc.note.value;
      if (msg.isNotEmpty) {
        _svc.note.value = '';
        ScaffoldMessenger.maybeOf(context)?.showSnackBar(
          SnackBar(
            content: Text(tr(msg)),
            duration: const Duration(seconds: 6),
          ),
        );
      }
      _close();
    } else {
      setState(() {});
    }
  }

  bool _closed = false;

  // pop() ignores PopScope(canPop: false); maybePop() did not, so the
  // screen stayed up after End was tapped.
  void _close() {
    if (_closed || !mounted) return;
    _closed = true;
    Navigator.of(context).pop();
  }

  Future<void> _end() async {
    _close();
    await _svc.hangUp();
  }

  @override
  void dispose() {
    _svc.phase.removeListener(_onPhase);
    _tick?.cancel();
    super.dispose();
  }

  String get _clock {
    final m = (_seconds ~/ 60).toString().padLeft(2, '0');
    final s = (_seconds % 60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  @override
  Widget build(BuildContext context) {
    final phase = _svc.phase.value;
    final name = _svc.otherName.value.isEmpty
        ? tr('Call')
        : _svc.otherName.value;
    final status = switch (phase) {
      CallPhase.ringingOut => tr('Calling…'),
      CallPhase.ringingIn => tr('Incoming call'),
      CallPhase.connecting => tr('Connecting…'),
      CallPhase.connected => _clock,
      CallPhase.idle => '',
    };
    return PopScope(
      canPop: false,
      child: Scaffold(
        backgroundColor: const Color(0xFF14110B),
        body: SafeArea(
          child: Column(
            children: [
              const Spacer(flex: 2),
              CircleAvatar(
                radius: 56,
                backgroundColor: EfuridePalette.accent,
                child: Text(
                  name.isEmpty ? '?' : name.characters.first.toUpperCase(),
                  style: const TextStyle(
                      fontSize: 44,
                      fontWeight: FontWeight.w900,
                      color: EfuridePalette.accentInk),
                ),
              ),
              const SizedBox(height: 22),
              Text(name,
                  style: const TextStyle(
                      color: Colors.white,
                      fontSize: 28,
                      fontWeight: FontWeight.w800)),
              const SizedBox(height: 8),
              Text(status,
                  style: const TextStyle(color: Colors.white70, fontSize: 18)),
              ValueListenableBuilder<String>(
                valueListenable: _svc.step,
                builder: (_, t, __) => t.isEmpty
                    ? const SizedBox.shrink()
                    : Padding(
                        padding: const EdgeInsets.fromLTRB(24, 14, 24, 0),
                        child: Text(t,
                            textAlign: TextAlign.center,
                            style: const TextStyle(
                                color: Colors.white38, fontSize: 12)),
                      ),
              ),
              const Spacer(flex: 3),
              if (phase == CallPhase.ringingIn)
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    _round(Icons.call_end, const Color(0xFFDC2626),
                        tr('Decline'), _svc.decline),
                    _round(Icons.call, const Color(0xFF16A34A), tr('Answer'),
                        _svc.answer),
                  ],
                )
              else
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    ValueListenableBuilder<bool>(
                      valueListenable: _svc.muted,
                      builder: (_, m, __) => _round(
                          m ? Icons.mic_off : Icons.mic,
                          m ? Colors.white : Colors.white24,
                          tr('Mute'),
                          () => _svc.setMuted(!m),
                          dark: m),
                    ),
                    _round(Icons.call_end, const Color(0xFFDC2626),
                        tr('End'), _end),
                    ValueListenableBuilder<bool>(
                      valueListenable: _svc.speaker,
                      builder: (_, on, __) => _round(
                          Icons.volume_up,
                          on ? Colors.white : Colors.white24,
                          tr('Speaker'),
                          () => _svc.setSpeaker(!on),
                          dark: on),
                    ),
                  ],
                ),
              const SizedBox(height: 40),
            ],
          ),
        ),
      ),
    );
  }

  Widget _round(IconData icon, Color bg, String label, VoidCallback onTap,
      {bool dark = false}) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Material(
          color: bg,
          shape: const CircleBorder(),
          child: InkWell(
            customBorder: const CircleBorder(),
            onTap: onTap,
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Icon(icon,
                  size: 32, color: dark ? Colors.black : Colors.white),
            ),
          ),
        ),
        const SizedBox(height: 8),
        Text(label, style: const TextStyle(color: Colors.white70)),
      ],
    );
  }
}
