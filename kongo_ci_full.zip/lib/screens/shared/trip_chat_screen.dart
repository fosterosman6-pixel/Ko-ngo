﻿import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:efuride_app/services/call_service.dart';
import 'package:efuride_app/screens/shared/in_app_call_screen.dart';
import 'package:flutter/services.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:intl/intl.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:efuride_app/services/notification_service.dart';
import 'package:efuride_app/utils/app_error.dart';
import 'package:efuride_app/utils/error_ui.dart';
import 'package:efuride_app/utils/phone_utils.dart';
import 'package:efuride_app/widgets/k_icon.dart';

class _Palette {
  static const cream = Color(0xFFFAF6EE);
  static const ink = Color(0xFF1A1A1A);
  static const inkMuted = Color(0xFF8C8378);
  static const accent = Color(0xFFF2B705);
  static const accentInk = Color(0xFF0B1220);
  static const pickup = Color(0xFF34C759);
  static const dropoff = Color(0xFFE53935);
  static const divider = Color(0xFFE8E2D5);
  static const blue = Color(0xFF1E88E5);
}

class ChatScreen extends StatefulWidget {
  final String rideId;
  const ChatScreen({super.key, required this.rideId});

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final TextEditingController _messageCtrl = TextEditingController();
  final ScrollController _scrollCtrl = ScrollController();
  final FocusNode _focusNode = FocusNode();

  List<Map<String, dynamic>> _messages = [];
  Map<String, dynamic>? _rideInfo;
  Map<String, dynamic>? _otherUser;

  String? _myUserId;
  String? _myRole;

  bool _isLoading = true;
  bool _isSending = false;
  bool _isCalling = false;
  AppError? _error;
  RealtimeChannel? _messagesChannel;

  // Typing indicator
  RealtimeChannel? _typingChannel;
  bool _otherIsTyping = false;
  Timer? _myTypingTimer;
  Timer? _otherTypingTimeoutTimer;

  @override
  void initState() {
    super.initState();
    _myUserId = Supabase.instance.client.auth.currentUser?.id;
    _messageCtrl.addListener(_onLocalTyping);
    _initChat();
  }

  @override
  void dispose() {
    _messagesChannel?.unsubscribe();
    _typingChannel?.unsubscribe();
    _myTypingTimer?.cancel();
    _otherTypingTimeoutTimer?.cancel();
    _messageCtrl.dispose();
    _scrollCtrl.dispose();
    _focusNode.dispose();
    super.dispose();
  }

  // ============================================================
  // INIT
  // ============================================================
  Future<void> _initChat() async {
    setState(() {
      _isLoading = true;
      _error = null;
    });

    if (_myUserId == null) {
      setState(() {
        _isLoading = false;
        _error = const AppError(
          title: 'Not signed in',
          message: 'Please sign in to use chat.',
          icon: Icons.lock_outline,
        );
      });
      return;
    }

    if (widget.rideId.trim().isEmpty) {
      setState(() {
        _isLoading = false;
        _error = const AppError(
          title: 'No active ride',
          message: 'There\'s no trip to chat about yet.',
          icon: Icons.chat_bubble_outline,
        );
      });
      return;
    }

    try {
      final ride = await Supabase.instance.client
          .from('rides')
          .select()
          .eq('id', widget.rideId)
          .maybeSingle();

      if (ride == null) {
        if (!mounted) return;
        setState(() {
          _isLoading = false;
          _error = const AppError(
            title: 'Ride not found',
            message: 'This trip may have been removed.',
            icon: Icons.error_outline,
          );
        });
        return;
      }

      final customerId = ride['customer_id']?.toString();
      final driverId = ride['driver_id']?.toString();

      final myId = (_myUserId ?? '').toString().trim();
      final custId = (customerId ?? '').toString().trim();
      final drivId = (driverId ?? '').toString().trim();

      if (myId.isNotEmpty && myId == custId) {
        _myRole = 'customer';
      } else if (myId.isNotEmpty && drivId.isNotEmpty && myId == drivId) {
        _myRole = 'driver';
      } else {
        if (!mounted) return;
        setState(() {
          _isLoading = false;
          _error = const AppError(
            title: 'Access denied',
            message: 'You\'re not a participant in this trip.',
            icon: Icons.lock_outline,
          );
        });
        return;
      }

      final otherUserId = (_myRole == 'customer') ? driverId : customerId;

      Map<String, dynamic>? otherProfile;
      if (otherUserId != null && otherUserId.isNotEmpty) {
        try {
          otherProfile = await Supabase.instance.client
              .from('profiles')
              .select(
                  'id, first_name, surname, full_name, profile_picture_url, average_rating')
              .eq('id', otherUserId)
              .maybeSingle();

          if (otherProfile != null) {
            final r = otherProfile['average_rating'];
            if (r is num) {
              otherProfile['average_rating'] = r.toDouble();
            } else if (r != null) {
              otherProfile['average_rating'] =
                  double.tryParse(r.toString()) ?? 5.0;
            }
          }
        } catch (e) {
          debugPrint('profile fetch failed: $e');
        }
      }

      List<Map<String, dynamic>> msgs = [];
      try {
        final res = await Supabase.instance.client
            .from('ride_messages')
            .select()
            .eq('ride_id', widget.rideId)
            .order('created_at', ascending: true);
        msgs = List<Map<String, dynamic>>.from(res);
      } catch (e) {
        debugPrint('message fetch failed: $e');
      }

      if (!mounted) return;

      setState(() {
        _rideInfo = ride;
        _otherUser = otherProfile;
        _messages = msgs;
        _isLoading = false;
        _error = null;
      });

      _subscribeToMessages();
      _subscribeToTyping();
      _scrollToBottom();
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _isLoading = false;
        _error = AppError.from(e, onRetry: _initChat);
      });
    }
  }

  // ============================================================
  // REALTIME — MESSAGES
  // ============================================================
  void _subscribeToMessages() {
    _messagesChannel?.unsubscribe();
    final uniqueName =
        'ride_chat_${widget.rideId}_${DateTime.now().millisecondsSinceEpoch}';

    _messagesChannel = Supabase.instance.client
        .channel(uniqueName)
        .onPostgresChanges(
          event: PostgresChangeEvent.insert,
          schema: 'public',
          table: 'ride_messages',
          filter: PostgresChangeFilter(
            type: PostgresChangeFilterType.eq,
            column: 'ride_id',
            value: widget.rideId,
          ),
          callback: (payload) {
            Map<String, dynamic> msg;
            try {
              final dynamic raw = payload.newRecord;
              if (raw is Map<String, dynamic>) {
                msg = Map<String, dynamic>.from(raw);
              } else if (raw is Map) {
                msg = Map<String, dynamic>.from(
                  raw.map((k, v) => MapEntry(k.toString(), v)),
                );
              } else if (raw is String) {
                final dynamic decoded = jsonDecode(raw);
                if (decoded is Map<String, dynamic>) {
                  msg = decoded;
                } else if (decoded is Map) {
                  msg = Map<String, dynamic>.from(
                    decoded.map((k, v) => MapEntry(k.toString(), v)),
                  );
                } else {
                  return;
                }
              } else {
                return;
              }
            } catch (e) {
              debugPrint('realtime decode failed: $e');
              return;
            }

            if (msg.isEmpty) return;
            if (_messages.any((m) => m['id'] == msg['id'])) return;

            // Remove the optimistic copy, matching by sender + body only.
            _messages.removeWhere((m) {
              final id = (m['id'] ?? '').toString();
              return id.startsWith('temp_') &&
                  m['sender_id'] == msg['sender_id'] &&
                  m['message'] == msg['message'];
            });

            if (mounted) {
              setState(() => _messages.add(msg));
              _scrollToBottom();
            }
          },
        )
        .subscribe();
  }

  // ============================================================
  // REALTIME — TYPING
  // ============================================================
  void _subscribeToTyping() {
    _typingChannel?.unsubscribe();
    // Same name for both people, or they never hear each other.
    final channelName = 'typing_ride_${widget.rideId}';

    _typingChannel = Supabase.instance.client
        .channel(channelName, opts: const RealtimeChannelConfig(self: true))
        .onBroadcast(
          event: 'typing',
          callback: (payload) {
            final fromUserId = payload['user_id']?.toString();
            final isTyping = payload['typing'] == true;
            if (fromUserId == null || fromUserId == _myUserId) return;

            if (isTyping) {
              _otherTypingTimeoutTimer?.cancel();
              _otherTypingTimeoutTimer =
                  Timer(const Duration(seconds: 2), () {
                if (mounted) setState(() => _otherIsTyping = false);
              });
              if (mounted && !_otherIsTyping) {
                setState(() => _otherIsTyping = true);
              }
            } else {
              _otherTypingTimeoutTimer?.cancel();
              if (mounted && _otherIsTyping) {
                setState(() => _otherIsTyping = false);
              }
            }
          },
        )
        .subscribe();
  }

  void _onLocalTyping() {
    final text = _messageCtrl.text;
    if (text.isNotEmpty) {
      _sendTyping(true);
      _myTypingTimer?.cancel();
      _myTypingTimer = Timer(const Duration(seconds: 2), () {
        _sendTyping(false);
      });
    } else {
      _sendTyping(false);
      _myTypingTimer?.cancel();
    }
  }

  void _sendTyping(bool typing) {
    try {
      _typingChannel?.sendBroadcastMessage(
        event: 'typing',
        payload: {
          'user_id': _myUserId,
          'role': _myRole,
          'typing': typing,
        },
      );
    } catch (_) {}
  }

  // ============================================================
  // SEND MESSAGE
  // ============================================================
  Future<void> _sendMessage() async {
    final text = _messageCtrl.text.trim();
    if (text.isEmpty || _myUserId == null) return;

    setState(() => _isSending = true);
    _sendTyping(false);

    final nowIso = DateTime.now().toUtc().toIso8601String();
    final tempId = 'temp_${DateTime.now().millisecondsSinceEpoch}';
    final optimistic = {
      'id': tempId,
      'ride_id': widget.rideId,
      'sender_id': _myUserId,
      'sender_role': _myRole,
      'message': text,
      'created_at': nowIso,
    };
    setState(() {
      _messages.add(optimistic);
      _messageCtrl.clear();
    });
    _scrollToBottom();

    try {
      final inserted = await Supabase.instance.client
          .from('ride_messages')
          .insert({
            'ride_id': widget.rideId,
            'sender_id': _myUserId,
            'sender_role': _myRole,
            'message': text,
            'created_at': nowIso,
          })
          .select()
          .single();

      if (!mounted) return;

      setState(() {
        _messages.removeWhere((m) => m['id'] == tempId);
        if (!_messages.any((m) => m['id'] == inserted['id'])) {
          _messages.add(Map<String, dynamic>.from(inserted));
        }
      });
      _scrollToBottom();

      // Notify the other party (fire and forget)
      dynamic otherUserId;
      if (_rideInfo != null) {
        otherUserId = _myRole == 'customer'
            ? _rideInfo!['driver_id']
            : _rideInfo!['customer_id'];
      }

      if (otherUserId != null && otherUserId.toString().isNotEmpty) {
        final senderName = (_myRole == 'customer') ? 'Passenger' : 'Driver';
        NotificationService.send(
          toUserId: otherUserId.toString(),
          title: '💬 New message from $senderName',
          body: text,
          type: 'chat_message',
          data: {
            'ride_id': widget.rideId,
            'sender_id': _myUserId,
            'sender_role': _myRole,
          },
        );
      }
    } catch (e) {
      debugPrint('send failed: $e');
      if (!mounted) return;
      setState(() {
        _messages.removeWhere((m) => m['id'] == tempId);
        _messageCtrl.text = text;
      });
      ErrorUI.showSnack(
        context,
        AppError.from(e, onRetry: _sendMessage),
      );
    } finally {
      if (mounted) setState(() => _isSending = false);
    }
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!_scrollCtrl.hasClients) return;
      _scrollCtrl.animateTo(
        _scrollCtrl.position.maxScrollExtent + 120,
        duration: const Duration(milliseconds: 250),
        curve: Curves.easeOut,
      );
    });
  }

  // ============================================================
  // CALL FLOW
  // ============================================================
  bool get _canCall {
    final status = _rideInfo?['status']?.toString() ?? '';
    return status == 'accepted' || status == 'in_progress';
  }

  Future<void> _openCallSheet() async {
    if (_isCalling) return;
    // In-app voice call (no phone number is shared or dialled).
    final svc = CallService.instance;
    svc.onOutgoing = () {
      if (mounted) InAppCallScreen.show(context);
    };
    svc.onIncoming = () {
      if (mounted) InAppCallScreen.show(context);
    };
    await svc.attach(widget.rideId,
        myName: _myRole == 'customer' ? 'Customer' : 'Driver');
    svc.call(toName: _otherName());
    return;
  }

  // ignore: unused_element
  Future<void> _openCallSheetViaDialer() async {
    if (_isCalling) return;

    String? otherId;
    if (_myRole == 'customer') {
      otherId = _rideInfo?['driver_id']?.toString();
    } else {
      otherId = _rideInfo?['customer_id']?.toString();
    }

    if (otherId == null || otherId.isEmpty) {
      ErrorUI.showSnack(
        context,
        const AppError(
          title: 'Can\'t call',
          message: 'Contact details are unavailable right now.',
          icon: Icons.phone_disabled_outlined,
        ),
      );
      return;
    }

    setState(() => _isCalling = true);

    try {
      final profile = await Supabase.instance.client
          .from('profiles')
          .select('first_name, surname, phone_number, role')
          .eq('id', otherId)
          .maybeSingle()
          .timeout(const Duration(seconds: 8));

      if (!mounted) return;
      setState(() => _isCalling = false);

      final phoneRaw = profile?['phone_number']?.toString().trim();
      if (phoneRaw == null || phoneRaw.isEmpty) {
        ErrorUI.showSnack(
          context,
          AppError(
            title: 'No phone number',
            message:
                '${_otherName()} hasn\'t added a phone number to their profile.',
            icon: Icons.phone_disabled_outlined,
          ),
        );
        return;
      }

      final phone = PhoneUtils.normalise(phoneRaw);
      if (phone == null || !PhoneUtils.isValid(phone)) {
        ErrorUI.showSnack(
          context,
          const AppError(
            title: 'Invalid number',
            message: 'We can\'t dial that phone number.',
            icon: Icons.phone_disabled_outlined,
          ),
        );
        return;
      }

      final confirmed = await _showCallConfirmDialog(phone);
      if (confirmed != true) return;

      // Best-effort audit log. Never blocks the call.
      unawaited(_logCall(otherId));

      final uri = Uri(scheme: 'tel', path: phone);
      final ok = await launchUrl(uri, mode: LaunchMode.externalApplication);

      if (!ok && mounted) {
        ErrorUI.showSnack(
          context,
          const AppError(
            title: 'Couldn\'t open dialer',
            message:
                'Your device may not have a phone app. Please dial manually.',
            icon: Icons.phone_disabled_outlined,
          ),
        );
      }
    } catch (e) {
      if (!mounted) return;
      setState(() => _isCalling = false);
      ErrorUI.showSnack(
        context,
        AppError.from(e, onRetry: _openCallSheet),
      );
    }
  }

  Future<bool?> _showCallConfirmDialog(String normalisedPhone) {
    return showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(6),
              decoration: BoxDecoration(
                color: _Palette.pickup.withOpacity(0.15),
                borderRadius: BorderRadius.circular(8),
              ),
              child: const Icon(Icons.call,
                  color: _Palette.pickup, size: 18),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Text(
                'Call ${_otherName()}?',
                style: const TextStyle(fontSize: 16),
              ),
            ),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              PhoneUtils.mask(normalisedPhone),
              style: const TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: _Palette.ink,
                letterSpacing: 1.2,
              ),
            ),
            const SizedBox(height: 10),
            const Text(
              'This will open your phone\'s dialer with the number pre-filled.',
              style: TextStyle(fontSize: 12, color: _Palette.inkMuted),
            ),
            const SizedBox(height: 6),
            const Text(
              'Your number stays hidden. Only the call is connected.',
              style: TextStyle(
                fontSize: 11,
                color: _Palette.inkMuted,
                fontStyle: FontStyle.italic,
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Cancel'),
          ),
          ElevatedButton.icon(
            style: ElevatedButton.styleFrom(
              backgroundColor: _Palette.pickup,
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10)),
            ),
            onPressed: () => Navigator.pop(ctx, true),
            icon: const Icon(Icons.call, size: 16),
            label: const Text('Call',
                style: TextStyle(fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }

  Future<void> _logCall(String calleeId) async {
    try {
      await Supabase.instance.client.from('call_logs').insert({
        'ride_id': widget.rideId,
        'caller_id': _myUserId,
        'callee_id': calleeId,
        'caller_role': _myRole,
      });
    } catch (e) {
      // Silent. The call still goes through even if logging fails.
      debugPrint('call log insert failed: $e');
    }
  }

  // ============================================================
  // QUICK REPLIES
  // ============================================================
  List<String> get _quickReplies {
    final status = _rideInfo?['status']?.toString() ?? '';

    if (_myRole == 'driver') {
      if (status == 'accepted') {
        return const [
          "I'm on my way",
          "I'll be there in 2 min",
          "I'm at the pickup",
          "Can't find you",
          "Please come to the main gate",
        ];
      }
      if (status == 'in_progress') {
        return const [
          "We've arrived",
          "Please rate me 5 stars",
          "Thank you!",
        ];
      }
      return const ["I'm on my way", "Ok", "See you soon"];
    }

    if (_myRole == 'customer') {
      if (status == 'accepted') {
        return const [
          "I'm at the pickup",
          "I'll be there in 2 min",
          "Please wait, coming now",
          "Where are you?",
          "I'm wearing a blue shirt",
        ];
      }
      if (status == 'in_progress') {
        return const [
          "Thank you!",
          "Please drop me here",
          "Next turn please",
        ];
      }
      return const ["Ok", "Thanks"];
    }

    return const [];
  }

  Widget _buildQuickReplies() {
    final replies = _quickReplies;
    if (replies.isEmpty) return const SizedBox.shrink();

    return Container(
      height: 46,
      color: Colors.white,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        itemCount: replies.length,
        separatorBuilder: (_, __) => const SizedBox(width: 8),
        itemBuilder: (_, i) {
          final text = replies[i];
          return ActionChip(
            label: Text(
              text,
              style: const TextStyle(fontSize: 12.5),
            ),
            labelPadding:
                const EdgeInsets.symmetric(horizontal: 6, vertical: 0),
            padding: EdgeInsets.zero,
            backgroundColor: Colors.grey[100],
            side: BorderSide(color: Colors.grey.shade300),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(20),
            ),
            onPressed: _isSending
                ? null
                : () {
                    _messageCtrl.text = text;
                    _messageCtrl.selection = TextSelection.fromPosition(
                      TextPosition(offset: _messageCtrl.text.length),
                    );
                    _sendMessage();
                  },
          );
        },
      ),
    );
  }

  // ============================================================
  // HELPERS
  // ============================================================
  bool _isMyMessage(Map<String, dynamic> m) => m['sender_id'] == _myUserId;

  String _timeLabel(dynamic iso) {
    if (iso == null) return '';
    try {
      if (iso is int) {
        final dt = iso > 100000000000
            ? DateTime.fromMillisecondsSinceEpoch(iso, isUtc: true)
            : DateTime.fromMillisecondsSinceEpoch(iso * 1000, isUtc: true);
        return DateFormat('h:mm a').format(dt.toLocal());
      }
      if (iso is double) {
        return _timeLabel(iso.toInt());
      }
      final dt = DateTime.parse(iso.toString()).toLocal();
      return DateFormat('h:mm a').format(dt);
    } catch (_) {
      return '';
    }
  }

  String _otherName() {
    if (_otherUser == null) return 'User';
    final f = _otherUser!['first_name'] ?? '';
    final s = _otherUser!['surname'] ?? '';
    final full = _otherUser!['full_name'] ?? '';
    final composed = '$f $s'.trim();
    if (composed.isNotEmpty) return composed;
    if (full.toString().isNotEmpty) return full.toString();
    return 'User';
  }

  // ============================================================
  // BUILD
  // ============================================================
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _Palette.cream,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 1,
        iconTheme: const IconThemeData(color: _Palette.ink),
        titleSpacing: 0,
        title: Row(
          children: [
            CircleAvatar(
              radius: 20,
              backgroundColor: Colors.indigo.shade100,
              backgroundImage: (_otherUser?['profile_picture_url'] != null &&
                      _otherUser!['profile_picture_url']
                          .toString()
                          .isNotEmpty)
                  ? NetworkImage(
                      _otherUser!['profile_picture_url'].toString())
                  : null,
              child: (_otherUser?['profile_picture_url'] == null ||
                      _otherUser!['profile_picture_url']
                          .toString()
                          .isEmpty)
                  ? Text(
                      _otherName().isNotEmpty
                          ? _otherName()[0].toUpperCase()
                          : '?',
                      style: const TextStyle(
                          fontWeight: FontWeight.bold, color: Colors.white),
                    )
                  : null,
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    _otherName(),
                    style: const TextStyle(
                        color: _Palette.ink,
                        fontSize: 15,
                        fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    _otherIsTyping
                        ? 'typing…'
                        : (_myRole == 'customer'
                            ? 'Your driver'
                            : 'Your passenger'),
                    style: TextStyle(
                        color: _otherIsTyping
                            ? _Palette.blue
                            : _Palette.inkMuted,
                        fontSize: 11,
                        fontStyle: _otherIsTyping
                            ? FontStyle.italic
                            : FontStyle.normal),
                  ),
                ],
              ),
            ),
          ],
        ),
        actions: [
          // ---- CALL BUTTON (only during an active trip) ----
          if (_canCall)
            IconButton(
              tooltip: 'Call ${_otherName()}',
              onPressed: _isCalling ? null : _openCallSheet,
              icon: _isCalling
                  ? const SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        color: _Palette.pickup,
                      ),
                    )
                  : const Icon(Icons.call, color: _Palette.pickup),
            ),
        ],
      ),
      body: Column(
        children: [
          if (_rideInfo != null) _buildRideBanner(),
          Expanded(child: _buildBody()),
          if (_otherIsTyping) _buildTypingIndicator(),
          if (_error == null &&
              _rideInfo != null &&
              _rideInfo!['status'] != 'completed' &&
              _rideInfo!['status'] != 'cancelled')
            _buildQuickReplies(),
          if (_error == null) _buildInputBar(),
        ],
      ),
    );
  }

  Widget _buildBody() {
    if (_isLoading) {
      return const Center(
          child: CircularProgressIndicator(color: _Palette.accent));
    }
    if (_error != null) {
      return Center(child: ErrorUI.inline(_error!));
    }
    if (_messages.isEmpty) return _buildEmptyState();
    return ListView.builder(
      controller: _scrollCtrl,
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 16),
      itemCount: _messages.length,
      itemBuilder: (context, index) {
        final msg = _messages[index];
        final mine = _isMyMessage(msg);
        return _buildBubble(msg, mine);
      },
    );
  }

  Widget _buildTypingIndicator() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      alignment: Alignment.centerLeft,
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          const _TypingDots(),
          const SizedBox(width: 8),
          Text(
            '${_otherName()} is typing…',
            style: const TextStyle(
                fontSize: 12,
                color: _Palette.inkMuted,
                fontStyle: FontStyle.italic),
          ),
        ],
      ),
    );
  }

  Widget _buildRideBanner() {
    final status = (_rideInfo!['status'] ?? 'pending').toString();
    final pickup = _rideInfo!['pickup_address'] ?? '—';
    final dropoff = _rideInfo!['dropoff_address'] ?? '—';
    final serviceType = _rideInfo!['service_type'] ?? 'Ride';
    final isDelivery = serviceType == 'Delivery';

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      color: Colors.white,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(
                isDelivery ? Icons.local_shipping : Icons.local_taxi,
                size: 16,
                color: _Palette.blue,
              ),
              const SizedBox(width: 6),
              Text(
                '$serviceType • ${status.toUpperCase()}',
                style: const TextStyle(
                    fontSize: 11,
                    fontWeight: FontWeight.bold,
                    color: _Palette.blue),
              ),
            ],
          ),
          const SizedBox(height: 6),
          Row(
            children: [
              const Icon(Icons.my_location,
                  size: 12, color: _Palette.pickup),
              const SizedBox(width: 6),
              Expanded(
                child: Text(
                  pickup.toString(),
                  style: const TextStyle(
                      fontSize: 11, color: _Palette.ink),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ],
          ),
          const SizedBox(height: 2),
          Row(
            children: [
              const KIcon(Icons.location_on,
                  size: 12, color: _Palette.dropoff),
              const SizedBox(width: 6),
              Expanded(
                child: Text(
                  dropoff.toString(),
                  style: const TextStyle(
                      fontSize: 11, color: _Palette.ink),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            KIcon(Icons.chat_bubble_outline,
                size: 56, color: _Palette.inkMuted),
            const SizedBox(height: 12),
            const Text(
              'No messages yet',
              style: TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.bold,
                  color: _Palette.ink),
            ),
            const SizedBox(height: 6),
            Text(
              'Say hi to ${_otherName()} to coordinate pickup.',
              textAlign: TextAlign.center,
              style:
                  const TextStyle(fontSize: 12, color: _Palette.inkMuted),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildBubble(Map<String, dynamic> msg, bool mine) {
    final text = (msg['message'] ?? '').toString();
    final time = _timeLabel(msg['created_at']);
    final rawId = msg['id']?.toString() ?? '';
    final isSending = rawId.startsWith('temp_');

    final avatarUrl =
        mine ? null : _otherUser?['profile_picture_url']?.toString();
    final otherInitial =
        _otherName().isNotEmpty ? _otherName()[0].toUpperCase() : '?';

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        mainAxisAlignment:
            mine ? MainAxisAlignment.end : MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          if (!mine) ...[
            CircleAvatar(
              radius: 16,
              backgroundColor: Colors.indigo.shade100,
              backgroundImage: (avatarUrl != null && avatarUrl.isNotEmpty)
                  ? NetworkImage(avatarUrl)
                  : null,
              child: (avatarUrl == null || avatarUrl.isEmpty)
                  ? Text(otherInitial,
                      style: const TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.bold,
                          color: Colors.white))
                  : null,
            ),
            const SizedBox(width: 6),
          ],
          Flexible(
            child: Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              constraints: BoxConstraints(
                maxWidth: MediaQuery.of(context).size.width * 0.72,
              ),
              decoration: BoxDecoration(
                color: mine ? _Palette.blue : Colors.white,
                borderRadius: BorderRadius.only(
                  topLeft: const Radius.circular(14),
                  topRight: const Radius.circular(14),
                  bottomLeft: Radius.circular(mine ? 14 : 2),
                  bottomRight: Radius.circular(mine ? 2 : 14),
                ),
                border: mine
                    ? null
                    : Border.all(color: _Palette.divider),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.05),
                    blurRadius: 4,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              child: Column(
                crossAxisAlignment: mine
                    ? CrossAxisAlignment.end
                    : CrossAxisAlignment.start,
                children: [
                  Text(
                    text,
                    style: TextStyle(
                      color: mine ? Colors.white : _Palette.ink,
                      fontSize: 14,
                      height: 1.3,
                    ),
                  ),
                  const SizedBox(height: 3),
                  Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        isSending ? 'Sending…' : time,
                        style: TextStyle(
                          color: mine
                              ? Colors.white70
                              : _Palette.inkMuted,
                          fontSize: 10,
                          fontStyle: isSending
                              ? FontStyle.italic
                              : FontStyle.normal,
                        ),
                      ),
                      if (isSending) ...[
                        const SizedBox(width: 4),
                        const SizedBox(
                          width: 8,
                          height: 8,
                          child: CircularProgressIndicator(
                              strokeWidth: 1.5, color: Colors.white70),
                        ),
                      ],
                    ],
                  ),
                ],
              ),
            ),
          ),
          if (mine) const SizedBox(width: 6),
        ],
      ),
    );
  }

  Widget _buildInputBar() {
    return SafeArea(
      top: false,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
        decoration: BoxDecoration(
          color: Colors.white,
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.05),
              blurRadius: 6,
              offset: const Offset(0, -2),
            ),
          ],
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Expanded(
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 14),
                decoration: BoxDecoration(
                  color: _Palette.cream,
                  borderRadius: BorderRadius.circular(24),
                  border: Border.all(color: _Palette.divider),
                ),
                child: TextField(
                  controller: _messageCtrl,
                  focusNode: _focusNode,
                  textInputAction: TextInputAction.send,
                  keyboardType: TextInputType.text,
                  maxLines: 4,
                  minLines: 1,
                  onSubmitted: (_) => _sendMessage(),
                  decoration: const InputDecoration(
                    hintText: 'Type a message...',
                    hintStyle: TextStyle(color: _Palette.inkMuted),
                    border: InputBorder.none,
                    contentPadding: EdgeInsets.symmetric(vertical: 12),
                  ),
                ),
              ),
            ),
            const SizedBox(width: 8),
            GestureDetector(
              onTap: _isSending ? null : _sendMessage,
              child: Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(
                  color: _Palette.blue,
                  shape: BoxShape.circle,
                  boxShadow: [
                    BoxShadow(
                      color: _Palette.blue.withOpacity(0.35),
                      blurRadius: 8,
                      offset: const Offset(0, 3),
                    ),
                  ],
                ),
                child: _isSending
                    ? const Padding(
                        padding: EdgeInsets.all(12),
                        child: CircularProgressIndicator(
                            color: Colors.white, strokeWidth: 2),
                      )
                    : const Icon(Icons.send,
                        color: Colors.white, size: 20),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ============================================================
// Typing dots animation
// ============================================================
class _TypingDots extends StatefulWidget {
  const _TypingDots();

  @override
  State<_TypingDots> createState() => _TypingDotsState();
}

class _TypingDotsState extends State<_TypingDots>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 900))
      ..repeat();
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _ctrl,
      builder: (_, __) {
        final v = _ctrl.value;
        return Row(
          mainAxisSize: MainAxisSize.min,
          children: List.generate(3, (i) {
            final phase = (v + i * 0.2) % 1.0;
            final scale = 0.6 + 0.6 * (1 - (phase - 0.5).abs() * 2);
            return Padding(
              padding: const EdgeInsets.symmetric(horizontal: 1.5),
              child: Transform.scale(
                scale: scale,
                child: Container(
                  width: 6,
                  height: 6,
                  decoration: const BoxDecoration(
                    color: _Palette.inkMuted,
                    shape: BoxShape.circle,
                  ),
                ),
              ),
            );
          }),
        );
      },
    );
  }
}
