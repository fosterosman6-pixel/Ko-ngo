﻿import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:efuride_app/utils/app_error.dart';
import 'package:efuride_app/utils/error_ui.dart';
import 'package:efuride_app/l10n/app_strings.dart';
import 'package:efuride_app/widgets/k_icon.dart';

class _Palette {
  static const cream = Color(0xFFFAF6EE);
  static const ink = Color(0xFF1A1A1A);
  static const inkMuted = Color(0xFF575047);
  static const accent = Color(0xFFF2B705);
  static const accentInk = Color(0xFF0B1220);
  static const divider = Color(0xFFE8E2D5);
  static const blue = Color(0xFF1E88E5);
  static const pickup = Color(0xFF34C759);
}

class RatingScreen extends StatefulWidget {
  /// Optional prefill when launched from trip_complete / trip_ended.
  final String? rideId;
  final String? rateeId;
  final String? rateeName;
  final String? rateeAvatarUrl;
  final String? raterRole; // 'customer' | 'driver'

  const RatingScreen({
    super.key,
    this.rideId,
    this.rateeId,
    this.rateeName,
    this.rateeAvatarUrl,
    this.raterRole,
  });

  @override
  State<RatingScreen> createState() => _RatingScreenState();
}

class _RatingScreenState extends State<RatingScreen> {
  int _stars = 5;
  final TextEditingController _feedbackCtrl = TextEditingController();
  final Set<String> _selectedTags = {};
  bool _isSubmitting = false;
  bool _isLoading = true;
  bool _alreadyRated = false;
  AppError? _error;

  String _raterRole = 'customer';
  Map<String, dynamic>? _rateeProfile;
  Map<String, dynamic>? _ride;

  static const _customerTags = [
    'Excellent service',
    'Polite driver',
    'Arrived on time',
    'Safe driving',
    'Clean vehicle',
    'Good communication',
  ];

  static const _driverTags = [
    'Great passenger',
    'Polite & friendly',
    'Ready on time',
    'Clean & tidy',
    'Good communication',
  ];

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _feedbackCtrl.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    setState(() {
      _isLoading = true;
      _error = null;
    });

    try {
      final user = Supabase.instance.client.auth.currentUser;
      if (user == null) throw Exception('Not signed in');

      // Prefer explicit args (from trip_complete / trip_ended)
      if (widget.rideId != null && widget.rateeId != null) {
        _raterRole = widget.raterRole ?? 'customer';
        _ride = {'id': widget.rideId};
        _rateeProfile = {
          'id': widget.rateeId,
          'first_name': widget.rateeName,
          'profile_picture_url': widget.rateeAvatarUrl,
        };
        // Check for existing rating on this ride
        final existing = await Supabase.instance.client
            .from('ratings')
            .select('id')
            .eq('ride_id', widget.rideId!)
            .eq('rater_id', user.id)
            .maybeSingle();

        if (!mounted) return;
        setState(() {
          _alreadyRated = existing != null;
          _isLoading = false;
        });
        return;
      }

      // Auto-detect: most recent completed ride where I'm a participant
      final uid = user.id;

      final asCustomer = await Supabase.instance.client
          .from('rides')
          .select()
          .eq('customer_id', uid)
          .eq('status', 'completed')
          .order('completed_at', ascending: false)
          .limit(1)
          .maybeSingle();

      if (asCustomer != null &&
          asCustomer['driver_id'] != null &&
          asCustomer['driver_id'].toString() != uid) {
        _raterRole = 'customer';
        _ride = asCustomer;
        _rateeProfile = await Supabase.instance.client
            .from('profiles')
            .select(
                'id, first_name, surname, full_name, profile_picture_url, average_rating, total_ratings')
            .eq('id', asCustomer['driver_id'])
            .maybeSingle();
      } else {
        final asDriver = await Supabase.instance.client
            .from('rides')
            .select()
            .eq('driver_id', uid)
            .eq('status', 'completed')
            .order('completed_at', ascending: false)
            .limit(1)
            .maybeSingle();

        if (asDriver != null && asDriver['customer_id'] != null) {
          _raterRole = 'driver';
          _ride = asDriver;
          _rateeProfile = await Supabase.instance.client
              .from('profiles')
              .select(
                  'id, first_name, surname, full_name, profile_picture_url, average_rating, total_ratings')
              .eq('id', asDriver['customer_id'])
              .maybeSingle();
        }
      }

      // Check for existing rating
      if (_ride != null) {
        final existing = await Supabase.instance.client
            .from('ratings')
            .select('id')
            .eq('ride_id', _ride!['id'])
            .eq('rater_id', uid)
            .maybeSingle();
        _alreadyRated = existing != null;
      }

      if (!mounted) return;
      setState(() => _isLoading = false);
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _isLoading = false;
        _error = AppError.from(e, onRetry: _load);
      });
    }
  }

  List<String> get _quickComments =>
      _raterRole == 'customer' ? _customerTags : _driverTags;

  String _rateeName() {
    if (_rateeProfile == null) {
      return _raterRole == 'customer' ? 'your driver' : 'your passenger';
    }
    final f = _rateeProfile!['first_name'] ?? '';
    final s = _rateeProfile!['surname'] ?? '';
    final full = _rateeProfile!['full_name'] ?? '';
    final composed = '$f $s'.trim();
    if (composed.isNotEmpty) return composed;
    if (full.toString().isNotEmpty) return full.toString();
    return _raterRole == 'customer' ? 'your driver' : 'your passenger';
  }

  double _rateeRating() {
    final r = _rateeProfile?['average_rating'];
    if (r is num) return r.toDouble();
    if (r != null) return double.tryParse(r.toString()) ?? 5.0;
    return 5.0;
  }

  int _rateeTotal() {
    final r = _rateeProfile?['total_ratings'];
    if (r is num) return r.toInt();
    if (r != null) return int.tryParse(r.toString()) ?? 0;
    return 0;
  }

  Future<void> _submitRating() async {
    if (_ride == null || _rateeProfile == null) {
      ErrorUI.showSnack(
        context,
        AppError(
          title: tr('No trip to rate'),
          message: tr('We couldn\'t find a completed ride.'),
          icon: Icons.info_outline,
        ),
      );
      return;
    }

    setState(() => _isSubmitting = true);

    try {
      final user = Supabase.instance.client.auth.currentUser;
      if (user == null) throw Exception('Not signed in');

      final rideId = _ride!['id'];
      final rateeId = _rateeProfile!['id'];

      await Supabase.instance.client.from('ratings').insert({
        'ride_id': rideId,
        'rater_id': user.id,
        'ratee_id': rateeId,
        'rater_role': _raterRole,
        'stars': _stars,
        'tags': _selectedTags.toList(),
        'feedback': _feedbackCtrl.text.trim().isEmpty
            ? null
            : _feedbackCtrl.text.trim(),
        'created_at': DateTime.now().toUtc().toIso8601String(),
      });

      // The DB trigger recomputes average_rating on profiles.

      if (!mounted) return;
      ErrorUI.showSnack(
        context,
        AppError(
          title: tr('Thanks for rating!'),
          message: tr('Your feedback helps keep ko!ngo safe.'),
          icon: Icons.check_circle_outline,
        ),
      );
      Navigator.pop(context, true);
    } catch (e) {
      if (!mounted) return;
      ErrorUI.showSnack(
        context,
        AppError.from(e, onRetry: _submitRating),
      );
    } finally {
      if (mounted) setState(() => _isSubmitting = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) {
      return Scaffold(
        backgroundColor: _Palette.cream,
        appBar: AppBar(
          backgroundColor: _Palette.cream,
          elevation: 0,
          iconTheme: const IconThemeData(color: _Palette.ink),
          title: Text(tr('Rate trip'),
              style: TextStyle(
                  color: _Palette.ink,
                  fontWeight: FontWeight.bold,
                  fontSize: 18)),
        ),
        body: const Center(
            child: CircularProgressIndicator(color: _Palette.accent)),
      );
    }

    if (_error != null) {
      return Scaffold(
        backgroundColor: _Palette.cream,
        appBar: AppBar(
          backgroundColor: _Palette.cream,
          elevation: 0,
          iconTheme: const IconThemeData(color: _Palette.ink),
          title: Text(tr('Rate trip'),
              style: TextStyle(
                  color: _Palette.ink,
                  fontWeight: FontWeight.bold,
                  fontSize: 18)),
        ),
        body: ErrorUI.inline(_error!),
      );
    }

    if (_alreadyRated) {
      return Scaffold(
        backgroundColor: _Palette.cream,
        appBar: AppBar(
          backgroundColor: _Palette.cream,
          elevation: 0,
          iconTheme: const IconThemeData(color: _Palette.ink),
          title: Text(tr('Rate trip'),
              style: TextStyle(
                  color: _Palette.ink,
                  fontWeight: FontWeight.bold,
                  fontSize: 18)),
        ),
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(32),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.check_circle_outline,
                    size: 56, color: _Palette.pickup),
                const SizedBox(height: 16),
                Text(
                  tr('Already rated'),
                  style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: _Palette.ink),
                ),
                const SizedBox(height: 8),
                Text(
                  tr('You\'ve already rated this trip. Thanks for the feedback!'),
                  textAlign: TextAlign.center,
                  style:
                      TextStyle(fontSize: 14, color: _Palette.inkMuted),
                ),
                const SizedBox(height: 20),
                ElevatedButton(
                  onPressed: () => Navigator.pop(context),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: _Palette.accent,
                    foregroundColor: _Palette.accentInk,
                  ),
                  child: Text(tr('Back')),
                ),
              ],
            ),
          ),
        ),
      );
    }

    final isDriver = _raterRole == 'driver';
    final title = isDriver ? 'Rate your passenger' : 'Rate your driver';
    final question =
        isDriver ? 'How was your passenger?' : 'How was your ride?';
    final subtitle = isDriver
        ? 'Your feedback helps keep the community safe.'
        : 'Your feedback helps your driver improve.';

    return Scaffold(
      backgroundColor: _Palette.cream,
      appBar: AppBar(
        backgroundColor: _Palette.cream,
        elevation: 0,
        iconTheme: const IconThemeData(color: _Palette.ink),
        title: Text(
          title,
          style: const TextStyle(
              color: _Palette.ink,
              fontWeight: FontWeight.bold,
              fontSize: 18),
        ),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              if (_rateeProfile != null)
                Container(
                  padding: const EdgeInsets.all(14),
                  margin: const EdgeInsets.only(bottom: 20),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: _Palette.divider),
                  ),
                  child: Row(
                    children: [
                      CircleAvatar(
                        radius: 28,
                        backgroundColor: Colors.indigo,
                        backgroundImage: (_rateeProfile![
                                        'profile_picture_url'] !=
                                    null &&
                                _rateeProfile!['profile_picture_url']
                                    .toString()
                                    .isNotEmpty)
                            ? NetworkImage(_rateeProfile![
                                    'profile_picture_url']
                                .toString())
                            : null,
                        child: (_rateeProfile!['profile_picture_url'] ==
                                    null ||
                                _rateeProfile!['profile_picture_url']
                                    .toString()
                                    .isEmpty)
                            ? const KIcon(Icons.person,
                                color: Colors.white, size: 28)
                            : null,
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              _rateeName(),
                              style: const TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontSize: 15,
                                  color: _Palette.ink),
                            ),
                            const SizedBox(height: 4),
                            Row(
                              children: [
                                const Icon(Icons.star,
                                    color: Colors.amber, size: 14),
                                const SizedBox(width: 4),
                                Text(
                                  _rateeRating().toStringAsFixed(1),
                                  style: const TextStyle(
                                      fontWeight: FontWeight.w600,
                                      fontSize: 13.5,
                                      color: _Palette.ink),
                                ),
                                const SizedBox(width: 4),
                                Text(
                                  '(${_rateeTotal()})',
                                  style: const TextStyle(
                                      fontSize: 13,
                                      color: _Palette.inkMuted),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),

              Text(
                question,
                style: const TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: _Palette.ink),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 6),
              Text(
                subtitle,
                style: const TextStyle(
                    fontSize: 13.5, color: _Palette.inkMuted),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 24),

              // Stars
              Center(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: List.generate(5, (index) {
                    return IconButton(
                      icon: Icon(
                        index < _stars
                            ? Icons.star
                            : Icons.star_border,
                        color: _Palette.accent,
                        size: 44,
                      ),
                      onPressed: () =>
                          setState(() => _stars = index + 1),
                    );
                  }),
                ),
              ),
              const SizedBox(height: 16),

              // Tags
              Wrap(
                spacing: 8,
                runSpacing: 8,
                alignment: WrapAlignment.center,
                children: _quickComments.map((comment) {
                  final selected = _selectedTags.contains(comment);
                  return FilterChip(
                    label: Text(comment),
                    selected: selected,
                    selectedColor: _Palette.accent.withOpacity(0.25),
                    checkmarkColor: _Palette.accentInk,
                    onSelected: (v) => setState(() {
                      if (v) {
                        _selectedTags.add(comment);
                      } else {
                        _selectedTags.remove(comment);
                      }
                    }),
                  );
                }).toList(),
              ),
              const SizedBox(height: 16),

              TextField(
                controller: _feedbackCtrl,
                maxLines: 3,
                maxLength: 300,
                decoration: InputDecoration(
                  border: const OutlineInputBorder(),
                  labelText: tr('Share more feedback (optional)'),
                  hintText: tr('Tell us more about your experience'),
                  hintStyle:
                      const TextStyle(color: _Palette.inkMuted),
                  filled: true,
                  fillColor: Colors.white,
                ),
              ),
              const SizedBox(height: 16),

              _isSubmitting
                  ? const Center(
                      child: CircularProgressIndicator(
                          color: _Palette.accent))
                  : ElevatedButton(
                      onPressed: _submitRating,
                      style: ElevatedButton.styleFrom(
                        padding:
                            const EdgeInsets.symmetric(vertical: 16),
                        backgroundColor: _Palette.accent,
                        foregroundColor: _Palette.accentInk,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12)),
                      ),
                      child: Text(
                        tr('Submit rating'),
                        style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold),
                      ),
                    ),
            ],
          ),
        ),
      ),
    );
  }
}
