import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:efuride_app/services/wallet_service.dart';
import 'package:efuride_app/widgets/k_icon.dart';

class WalletScreen extends StatefulWidget {
  const WalletScreen({super.key});

  @override
  State<WalletScreen> createState() => _WalletScreenState();
}

class _WalletScreenState extends State<WalletScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabs;

  double _balance = 0;
  bool _loading = true;
  String _role = 'Customer';

  List<Map<String, dynamic>> _tx = [];
  List<Map<String, dynamic>> _topups = [];
  List<Map<String, dynamic>> _payouts = [];

  @override
  void initState() {
    super.initState();
    _tabs = TabController(length: 3, vsync: this);
    _loadAll();
  }

  @override
  void dispose() {
    _tabs.dispose();
    super.dispose();
  }

  Future<void> _loadAll() async {
    setState(() => _loading = true);
    final user = Supabase.instance.client.auth.currentUser;

    if (user != null) {
      try {
        final p = await Supabase.instance.client
            .from('profiles')
            .select('role, wallet_balance')
            .eq('id', user.id)
            .maybeSingle();
        _role = (p?['role'] ?? 'Customer').toString();
        _balance = (p?['wallet_balance'] as num?)?.toDouble() ?? 0;
      } catch (_) {}
    }

    final tx = await WalletService.listTransactions();
    final topups = await WalletService.listMyTopups();
    final payouts = _role.toLowerCase() == 'driver'
        ? await WalletService.listMyPayouts()
        : <Map<String, dynamic>>[];

    if (!mounted) return;
    setState(() {
      _tx = tx;
      _topups = topups;
      _payouts = payouts;
      _loading = false;
    });
  }

  String _fmtMoney(num v) => 'R ${v.toStringAsFixed(2)}';
  String _fmtDate(dynamic v) {
    if (v == null) return '';
    try {
      return DateFormat('d MMM, HH:mm')
          .format(DateTime.parse(v.toString()).toLocal());
    } catch (_) {
      return '';
    }
  }

  // ============================================================
  // Compute driver's pending earnings from completed, unpaid rides
  // ============================================================
  Future<double> _pendingFromRides() async {
    final user = Supabase.instance.client.auth.currentUser;
    if (user == null) return 0;
    try {
      final rides = await Supabase.instance.client
          .from('rides')
          .select('fare, payout_status')
          .eq('driver_id', user.id)
          .eq('status', 'completed')
          .neq('payout_status', 'paid');

      double total = 0;
      for (final r in rides) {
        final fare = (r['fare'] as num?)?.toDouble() ?? 0;
        total += fare * 0.85; // 15% platform commission
      }
      return total;
    } catch (_) {
      return 0;
    }
  }

  // ============================================================
  // TOPUP FLOW (customer)
  // ============================================================
  Future<void> _openTopupSheet() async {
    final amountCtrl = TextEditingController();
    String method = 'eft';
    final refCtrl = TextEditingController();

    final ok = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (ctx) => Padding(
        padding: EdgeInsets.only(
            left: 16,
            right: 16,
            top: 20,
            bottom: MediaQuery.of(ctx).viewInsets.bottom + 20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Text('Top up your wallet',
                style:
                    TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 6),
            const Text(
              'Send an EFT to the business account, then submit this form with your reference. Admin will confirm.',
              style: TextStyle(fontSize: 12, color: Colors.grey),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: amountCtrl,
              keyboardType:
                  const TextInputType.numberWithOptions(decimal: true),
              decoration: const InputDecoration(
                  labelText: 'Amount (R)',
                  border: OutlineInputBorder(),
                  prefixText: 'R '),
            ),
            const SizedBox(height: 12),
            DropdownButtonFormField<String>(
              value: method,
              decoration: const InputDecoration(
                  labelText: 'Payment method',
                  border: OutlineInputBorder()),
              items: const [
                DropdownMenuItem(value: 'eft', child: Text('EFT / Bank transfer')),
                DropdownMenuItem(value: 'cash', child: Text('Cash deposit')),
                DropdownMenuItem(value: 'card', child: Text('Card (coming soon)')),
              ],
              onChanged: (v) => method = v ?? 'eft',
            ),
            const SizedBox(height: 12),
            TextField(
              controller: refCtrl,
              decoration: const InputDecoration(
                  labelText: 'Bank reference (optional)',
                  border: OutlineInputBorder()),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF1E88E5),
                  padding: const EdgeInsets.symmetric(vertical: 14)),
              onPressed: () {
                final amt = double.tryParse(amountCtrl.text.trim()) ?? 0;
                if (amt <= 0) {
                  ScaffoldMessenger.of(ctx).showSnackBar(const SnackBar(
                      content: Text('Enter a valid amount'),
                      backgroundColor: Colors.red));
                  return;
                }
                Navigator.pop(ctx, true);
              },
              child: const Text('Submit for approval',
                  style: TextStyle(
                      color: Colors.white, fontWeight: FontWeight.bold)),
            ),
          ],
        ),
      ),
    );

    if (ok != true) return;

    final amount = double.tryParse(amountCtrl.text.trim()) ?? 0;
    if (amount <= 0) return;

    final result = await WalletService.requestTopup(
      amount: amount,
      method: method,
      reference: refCtrl.text.trim().isEmpty ? null : refCtrl.text.trim(),
    );
    final success = result.success;

    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(success
          ? '✅ Top-up request sent. Await admin approval.'
          : 'Failed to send top-up request.'),
      backgroundColor: success ? Colors.green : Colors.red,
    ));

    if (success) _loadAll();
  }

  // ============================================================
  // PAYOUT FLOW (driver)
  // ============================================================
  Future<void> _openPayoutSheet() async {
    // Pull pending earnings from rides — matches driver Earnings screen
    final pendingFromRides = await _pendingFromRides();
    final available = pendingFromRides > 0 ? pendingFromRides : _balance;

    if (available <= 0) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('No balance to withdraw.'),
          backgroundColor: Colors.orange));
      return;
    }

    final amountCtrl =
        TextEditingController(text: available.toStringAsFixed(2));
    final bankCtrl = TextEditingController();
    final acctCtrl = TextEditingController();
    final nameCtrl = TextEditingController();

    final ok = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (ctx) => Padding(
        padding: EdgeInsets.only(
            left: 16,
            right: 16,
            top: 20,
            bottom: MediaQuery.of(ctx).viewInsets.bottom + 20),
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const Text('Request Payout',
                  style:
                      TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              const SizedBox(height: 6),
              Text('Available: ${_fmtMoney(available)}',
                  style: const TextStyle(color: Colors.grey)),
              const SizedBox(height: 16),
              TextField(
                controller: amountCtrl,
                keyboardType:
                    const TextInputType.numberWithOptions(decimal: true),
                decoration: const InputDecoration(
                    labelText: 'Amount (R)',
                    border: OutlineInputBorder(),
                    prefixText: 'R '),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: bankCtrl,
                decoration: const InputDecoration(
                    labelText: 'Bank name',
                    border: OutlineInputBorder()),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: acctCtrl,
                decoration: const InputDecoration(
                    labelText: 'Account number',
                    border: OutlineInputBorder()),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: nameCtrl,
                decoration: const InputDecoration(
                    labelText: 'Account holder name',
                    border: OutlineInputBorder()),
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.green,
                    padding: const EdgeInsets.symmetric(vertical: 14)),
                onPressed: () {
                  final amt = double.tryParse(amountCtrl.text.trim()) ?? 0;
                  if (amt <= 0 || amt > available) {
                    ScaffoldMessenger.of(ctx).showSnackBar(const SnackBar(
                        content: Text('Invalid amount'),
                        backgroundColor: Colors.red));
                    return;
                  }
                  if (bankCtrl.text.trim().isEmpty ||
                      acctCtrl.text.trim().isEmpty ||
                      nameCtrl.text.trim().isEmpty) {
                    ScaffoldMessenger.of(ctx).showSnackBar(const SnackBar(
                        content: Text('Fill bank details'),
                        backgroundColor: Colors.red));
                    return;
                  }
                  Navigator.pop(ctx, true);
                },
                child: const Text('Submit payout request',
                    style: TextStyle(
                        color: Colors.white, fontWeight: FontWeight.bold)),
              ),
            ],
          ),
        ),
      ),
    );

    if (ok != true) return;

    final amount = double.tryParse(amountCtrl.text.trim()) ?? 0;
    final result = await WalletService.requestPayout(
      amount: amount,
      bankName: bankCtrl.text.trim(),
      accountNumber: acctCtrl.text.trim(),
      accountHolder: nameCtrl.text.trim(),
    );
    final success = result.success;

    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(success
          ? '✅ Payout request submitted.'
          : 'Failed to submit payout.'),
      backgroundColor: success ? Colors.green : Colors.red,
    ));
    if (success) _loadAll();
  }

  // ============================================================
  // BUILD
  // ============================================================
  @override
  Widget build(BuildContext context) {
    final isDriver = _role.toLowerCase() == 'driver';

    return Scaffold(
      backgroundColor: const Color(0xFFF5F5F5),
      appBar: AppBar(
        title: const Text('Wallet'),
        bottom: TabBar(
          controller: _tabs,
          tabs: const [
            Tab(text: 'Transactions'),
            Tab(text: 'Top-ups'),
            Tab(text: 'Payouts'),
          ],
        ),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : Column(
              children: [
                // Balance card
                Container(
                  width: double.infinity,
                  margin: const EdgeInsets.all(16),
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(colors: [
                      Color(0xFF1E88E5),
                      Color(0xFF1565C0),
                    ]),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('Available balance',
                          style: TextStyle(
                              color: Colors.white70, fontSize: 13)),
                      const SizedBox(height: 6),
                      Text(_fmtMoney(_balance),
                          style: const TextStyle(
                              color: Colors.white,
                              fontSize: 32,
                              fontWeight: FontWeight.bold)),
                      const SizedBox(height: 16),
                      Row(
                        children: [
                          if (!isDriver)
                            Expanded(
                              child: ElevatedButton.icon(
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: Colors.white,
                                  foregroundColor: const Color(0xFF1E88E5),
                                ),
                                icon: const Icon(Icons.add),
                                label: const Text('Top up'),
                                onPressed: _openTopupSheet,
                              ),
                            ),
                          if (isDriver)
                            Expanded(
                              child: ElevatedButton.icon(
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: Colors.white,
                                  foregroundColor: const Color(0xFF1E88E5),
                                ),
                                icon: const KIcon(Icons.account_balance),
                                label: const Text('Request payout'),
                                onPressed: _openPayoutSheet,
                              ),
                            ),
                        ],
                      ),
                    ],
                  ),
                ),

                // Tabs
                Expanded(
                  child: TabBarView(
                    controller: _tabs,
                    children: [
                      _buildTransactions(),
                      _buildTopups(),
                      isDriver
                          ? _buildPayouts()
                          : const Center(
                              child: Text('Only drivers can request payouts',
                                  style: TextStyle(color: Colors.grey))),
                    ],
                  ),
                ),
              ],
            ),
    );
  }

  Widget _buildTransactions() {
    if (_tx.isEmpty) {
      return const Center(
        child: Text('No transactions yet',
            style: TextStyle(color: Colors.grey)),
      );
    }
    return ListView.separated(
      padding: const EdgeInsets.all(16),
      itemCount: _tx.length,
      separatorBuilder: (_, __) => const SizedBox(height: 6),
      itemBuilder: (_, i) {
        final t = _tx[i];
        final amt = (t['amount'] as num?)?.toDouble() ?? 0;
        final isCredit = amt >= 0;
        final type = (t['type'] ?? '').toString();
        final label = type
            .replaceAll('_', ' ')
            .split(' ')
            .map((w) => w.isEmpty
                ? w
                : (w[0].toUpperCase() + w.substring(1)))
            .join(' ');

        return Card(
          elevation: 0,
          shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
              side: BorderSide(color: Colors.grey.shade200)),
          child: ListTile(
            leading: CircleAvatar(
              backgroundColor:
                  (isCredit ? Colors.green : Colors.red).withOpacity(0.15),
              child: Icon(
                isCredit ? Icons.add : Icons.remove,
                color: isCredit ? Colors.green : Colors.red,
              ),
            ),
            title: Text(label,
                style:
                    const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
            subtitle: Text(_fmtDate(t['created_at']),
                style: const TextStyle(fontSize: 11, color: Colors.grey)),
            trailing: Text(
              '${isCredit ? '+' : ''}${_fmtMoney(amt)}',
              style: TextStyle(
                  fontWeight: FontWeight.bold,
                  color: isCredit ? Colors.green : Colors.red),
            ),
          ),
        );
      },
    );
  }

  Widget _buildTopups() {
    if (_topups.isEmpty) {
      return const Center(
          child: Text('No top-up requests',
              style: TextStyle(color: Colors.grey)));
    }
    return ListView.separated(
      padding: const EdgeInsets.all(16),
      itemCount: _topups.length,
      separatorBuilder: (_, __) => const SizedBox(height: 6),
      itemBuilder: (_, i) {
        final t = _topups[i];
        final status = (t['status'] ?? 'pending').toString();
        final color = status == 'approved'
            ? Colors.green
            : (status == 'rejected' ? Colors.red : Colors.orange);

        return Card(
          elevation: 0,
          shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
              side: BorderSide(color: Colors.grey.shade200)),
          child: ListTile(
            leading: const CircleAvatar(
                backgroundColor: Color(0x1A1E88E5),
                child: Icon(Icons.arrow_downward, color: Color(0xFF1E88E5))),
            title: Text(_fmtMoney((t['amount'] as num?)?.toDouble() ?? 0),
                style:
                    const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
            subtitle: Text(
              '${t['method']} • ${_fmtDate(t['created_at'])}',
              style: const TextStyle(fontSize: 11, color: Colors.grey),
            ),
            trailing: Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              decoration: BoxDecoration(
                  color: color.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(6)),
              child: Text(status.toUpperCase(),
                  style: TextStyle(
                      color: color,
                      fontSize: 10,
                      fontWeight: FontWeight.bold)),
            ),
          ),
        );
      },
    );
  }

  Widget _buildPayouts() {
    if (_payouts.isEmpty) {
      return const Center(
          child: Text('No payout requests',
              style: TextStyle(color: Colors.grey)));
    }
    return ListView.separated(
      padding: const EdgeInsets.all(16),
      itemCount: _payouts.length,
      separatorBuilder: (_, __) => const SizedBox(height: 6),
      itemBuilder: (_, i) {
        final t = _payouts[i];
        final status = (t['status'] ?? 'pending').toString();
        final color = status == 'paid'
            ? Colors.green
            : (status == 'rejected' ? Colors.red : Colors.orange);

        return Card(
          elevation: 0,
          shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
              side: BorderSide(color: Colors.grey.shade200)),
          child: ListTile(
            leading: const CircleAvatar(
                backgroundColor: Color(0x1A34C759),
                child: Icon(Icons.arrow_upward, color: Color(0xFF34C759))),
            title: Text(_fmtMoney((t['amount'] as num?)?.toDouble() ?? 0),
                style:
                    const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
            subtitle: Text(
              '${t['bank_name'] ?? ''} • ${_fmtDate(t['created_at'])}',
              style: const TextStyle(fontSize: 11, color: Colors.grey),
            ),
            trailing: Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              decoration: BoxDecoration(
                  color: color.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(6)),
              child: Text(status.toUpperCase(),
                  style: TextStyle(
                      color: color,
                      fontSize: 10,
                      fontWeight: FontWeight.bold)),
            ),
          ),
        );
      },
    );
  }
}
