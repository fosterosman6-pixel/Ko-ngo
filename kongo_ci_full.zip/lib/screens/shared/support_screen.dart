// lib/screens/shared/support_screen.dart
//
// Support for every role (customer, driver, shopper, merchant).
// Each request is a conversation with ko!ngo support: the person writes,
// an admin answers from the admin app, and both sides see new messages
// live (tables support_tickets + support_messages, step10 SQL).

import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:url_launcher/url_launcher.dart';

import 'package:efuride_app/config/efuride_palette.dart';
import 'package:efuride_app/l10n/app_strings.dart';
import 'package:efuride_app/screens/shared/support_chat_screen.dart';
import 'package:efuride_app/services/app_control.dart';
import 'package:efuride_app/utils/app_error.dart';
import 'package:efuride_app/utils/error_ui.dart';
import 'package:efuride_app/utils/money.dart' show fmtDate;
import 'package:efuride_app/widgets/k_icon.dart';

class SupportScreen extends StatefulWidget {
  const SupportScreen({super.key});

  @override
  State<SupportScreen> createState() => _SupportScreenState();
}

class _SupportScreenState extends State<SupportScreen> {
  final _uid = Supabase.instance.client.auth.currentUser?.id;
  late final Stream<List<Map<String, dynamic>>> _tickets = _uid == null
      ? const Stream.empty()
      : Supabase.instance.client
          .from('support_tickets')
          .stream(primaryKey: ['id'])
          .eq('user_id', _uid!)
          .order('created_at', ascending: false);

  /// Ask for a subject and the first message, create the ticket, open it.
  Future<void> _newConversation() async {
    final subjectCtrl = TextEditingController();
    final msgCtrl = TextEditingController();
    final go = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (ctx) => Padding(
        padding: EdgeInsets.fromLTRB(
            20, 20, 20, MediaQuery.of(ctx).viewInsets.bottom + 20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(tr('New message to support'),
                style: const TextStyle(
                    fontSize: 21, fontWeight: FontWeight.w800)),
            const SizedBox(height: 14),
            TextField(
              controller: subjectCtrl,
              autofocus: true,
              textCapitalization: TextCapitalization.sentences,
              style: const TextStyle(fontSize: 16),
              decoration: _box(tr('What is it about?'),
                  tr('e.g. Payment, a trip, an order')),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: msgCtrl,
              minLines: 3,
              maxLines: 6,
              textCapitalization: TextCapitalization.sentences,
              style: const TextStyle(fontSize: 16),
              decoration: _box(tr('Message'), tr('Tell us what happened')),
            ),
            const SizedBox(height: 16),
            ElevatedButton.icon(
              onPressed: () {
                if (subjectCtrl.text.trim().isEmpty ||
                    msgCtrl.text.trim().isEmpty) {
                  return;
                }
                Navigator.pop(ctx, true);
              },
              icon: const Icon(Icons.send),
              label: Text(tr('Send'),
                  style: const TextStyle(
                      fontSize: 17, fontWeight: FontWeight.w800)),
              style: ElevatedButton.styleFrom(
                backgroundColor: EfuridePalette.accent,
                foregroundColor: EfuridePalette.accentInk,
                minimumSize: const Size(0, 54),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14)),
              ),
            ),
          ],
        ),
      ),
    );
    final subject = subjectCtrl.text.trim();
    final message = msgCtrl.text.trim();
    subjectCtrl.dispose();
    msgCtrl.dispose();
    if (go != true || _uid == null) return;

    try {
      final row = await Supabase.instance.client
          .from('support_tickets')
          .insert({
            'user_id': _uid,
            'subject': subject,
            'message': message,
            'status': 'open',
            'priority': 'Medium',
          })
          .select('id, subject')
          .single()
          .timeout(const Duration(seconds: 20));
      if (!mounted) return;
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => SupportChatScreen(
            ticketId: row['id'].toString(),
            subject: (row['subject'] ?? subject).toString(),
          ),
        ),
      );
    } catch (e) {
      if (!mounted) return;
      ErrorUI.showSnack(context, AppError.from(e, onRetry: _newConversation));
    }
  }

  InputDecoration _box(String label, String hint) => InputDecoration(
        labelText: label,
        hintText: hint,
        filled: true,
        fillColor: EfuridePalette.greyBg,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide.none,
        ),
      );

  // Support contacts are set by ko!ngo admins (App Control).
  Future<void> _openEmail() async {
    final email = AppControl.current.supportEmail;
    if (email == null) return;
    final uri = Uri(
      scheme: 'mailto',
      path: email,
      query: 'subject=ko!ngo Support Request',
    );
    try {
      final ok = await launchUrl(uri);
      if (!ok && mounted) {
        ErrorUI.showSnack(
          context,
          AppError(
            title: tr('Couldn\'t open email'),
            message: tr('Email us at {0}', [email]),
            icon: Icons.email_outlined,
          ),
        );
      }
    } catch (e) {
      if (!mounted) return;
      ErrorUI.showSnack(context, AppError.from(e));
    }
  }

  Future<void> _openPhone() async {
    final phone = AppControl.current.supportPhone;
    if (phone == null) return;
    final uri = Uri(scheme: 'tel', path: phone.replaceAll(' ', ''));
    try {
      final ok = await launchUrl(uri);
      if (!ok && mounted) {
        ErrorUI.showSnack(
          context,
          AppError(
            title: tr('Couldn\'t open dialer'),
            message: tr('Call us at {0}', [phone]),
            icon: Icons.phone_disabled_outlined,
          ),
        );
      }
    } catch (e) {
      if (!mounted) return;
      ErrorUI.showSnack(context, AppError.from(e));
    }
  }

  Future<void> _openWhatsapp() async {
    final w = AppControl.current.supportWhatsapp;
    if (w == null) return;
    final digits = w.replaceAll(RegExp(r'[^0-9]'), '');
    try {
      await launchUrl(Uri.parse('https://wa.me/$digits'),
          mode: LaunchMode.externalApplication);
    } catch (e) {
      if (!mounted) return;
      ErrorUI.showSnack(context, AppError.from(e));
    }
  }

  (String, Color) _status(String s) {
    switch (s.toLowerCase()) {
      case 'resolved':
      case 'closed':
        return (tr('Solved'), const Color(0xFF15803D));
      case 'in_progress':
      case 'pending':
        return (tr('Answered'), const Color(0xFF1565C0));
      default:
        return (tr('Waiting for support'), const Color(0xFFB45309));
    }
  }

  @override
  Widget build(BuildContext context) {
    final c = AppControl.current;
    return Scaffold(
      backgroundColor: EfuridePalette.cream,
      appBar: AppBar(
        backgroundColor: EfuridePalette.cream,
        foregroundColor: EfuridePalette.ink,
        elevation: 0,
        scrolledUnderElevation: 0,
        title: Text(tr('Support'),
            style: const TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.w800,
                color: EfuridePalette.ink)),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _newConversation,
        backgroundColor: EfuridePalette.accent,
        foregroundColor: EfuridePalette.accentInk,
        icon: const KIcon(Icons.chat_bubble_outline),
        label: Text(tr('Message support'),
            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
      ),
      body: StreamBuilder<List<Map<String, dynamic>>>(
        stream: _tickets,
        builder: (context, snap) {
          final rows = [...(snap.data ?? const <Map<String, dynamic>>[])]
            ..sort((a, b) => '${b['last_message_at'] ?? b['created_at']}'
                .compareTo('${a['last_message_at'] ?? a['created_at']}'));
          return ListView(
            padding: const EdgeInsets.fromLTRB(16, 4, 16, 100),
            children: [
              Text(
                tr('Chat with the ko!ngo team. We reply here and you get a notification.'),
                style: const TextStyle(
                    fontSize: 15, height: 1.35, color: EfuridePalette.inkMuted),
              ),
              const SizedBox(height: 16),
              Text(tr('Your conversations'),
                  style: const TextStyle(
                      fontSize: 16, fontWeight: FontWeight.w800)),
              const SizedBox(height: 8),
              if (snap.connectionState == ConnectionState.waiting &&
                  !snap.hasData)
                const Padding(
                  padding: EdgeInsets.all(24),
                  child: Center(child: CircularProgressIndicator()),
                )
              else if (rows.isEmpty)
                Container(
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: EfuridePalette.divider),
                  ),
                  child: Text(
                    tr('No conversations yet. Tap "Message support" to start one.'),
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                        fontSize: 15, color: EfuridePalette.inkMuted),
                  ),
                )
              else
                for (final t in rows) ...[
                  _ticketRow(t),
                  const SizedBox(height: 8),
                ],
              if (c.supportPhone != null ||
                  c.supportEmail != null ||
                  c.supportWhatsapp != null) ...[
                const SizedBox(height: 16),
                Text(tr('Other ways to reach us'),
                    style: const TextStyle(
                        fontSize: 16, fontWeight: FontWeight.w800)),
                const SizedBox(height: 8),
                if (c.supportWhatsapp != null)
                  _contactRow(Icons.chat, tr('WhatsApp'), c.supportWhatsapp!,
                      _openWhatsapp),
                if (c.supportPhone != null)
                  _contactRow(Icons.phone_outlined, tr('Call support'),
                      c.supportPhone!, _openPhone),
                if (c.supportEmail != null)
                  _contactRow(Icons.email_outlined, tr('Email support'),
                      c.supportEmail!, _openEmail),
              ],
            ],
          );
        },
      ),
    );
  }

  Widget _ticketRow(Map<String, dynamic> t) {
    final (label, color) = _status((t['status'] ?? 'open').toString());
    final unread = (t['unread_for_user'] as num?)?.toInt() ?? 0;
    final last = (t['last_message'] ?? t['message'] ?? '').toString();
    final fromSupport = t['last_sender'] == 'admin';
    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(14),
      child: InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: () => Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => SupportChatScreen(
              ticketId: t['id'].toString(),
              subject: (t['subject'] ?? '').toString(),
            ),
          ),
        ),
        child: Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(14),
            border: Border.all(
                color: unread > 0 ? EfuridePalette.accent : EfuridePalette.divider,
                width: unread > 0 ? 1.6 : 1),
          ),
          child: Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text((t['subject'] ?? tr('Support')).toString(),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                            fontSize: 16, fontWeight: FontWeight.w800)),
                    const SizedBox(height: 3),
                    Text(
                      fromSupport ? '${tr('Support')}: $last' : last,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                          fontSize: 14.5, color: EfuridePalette.inkMuted),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      '$label  ·  ${fmtDate(t['last_message_at'] ?? t['created_at'])}',
                      style: TextStyle(
                          fontSize: 13.5,
                          fontWeight: FontWeight.w700,
                          color: color),
                    ),
                  ],
                ),
              ),
              if (unread > 0)
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
                  decoration: BoxDecoration(
                    color: EfuridePalette.dropoff,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text('$unread',
                      style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w800,
                          fontSize: 13)),
                )
              else
                const Icon(Icons.chevron_right,
                    color: EfuridePalette.inkMuted),
            ],
          ),
        ),
      ),
    );
  }

  Widget _contactRow(
      IconData icon, String title, String value, VoidCallback onTap) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Material(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        child: ListTile(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(14),
            side: const BorderSide(color: EfuridePalette.divider),
          ),
          leading: Icon(icon, color: EfuridePalette.ink),
          title: Text(title,
              style: const TextStyle(
                  fontSize: 16, fontWeight: FontWeight.w700)),
          subtitle: Text(value, style: const TextStyle(fontSize: 14)),
          trailing: const Icon(Icons.chevron_right),
          onTap: onTap,
        ),
      ),
    );
  }
}
