// lib/screens/shared/support_chat_screen.dart
//
// One support conversation, live in both directions: the user's messages
// on the right, ko!ngo support on the left. Admins answer from the admin
// app (Support tab); the user gets a notification and sees it here.

import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'package:efuride_app/config/efuride_palette.dart';
import 'package:efuride_app/l10n/app_strings.dart';
import 'package:efuride_app/utils/app_error.dart';
import 'package:efuride_app/utils/error_ui.dart';

class SupportChatScreen extends StatefulWidget {
  final String ticketId;
  final String subject;
  const SupportChatScreen(
      {super.key, required this.ticketId, required this.subject});

  @override
  State<SupportChatScreen> createState() => _SupportChatScreenState();
}

class _SupportChatScreenState extends State<SupportChatScreen> {
  final _db = Supabase.instance.client;
  final _ctrl = TextEditingController();
  final _scroll = ScrollController();
  bool _sending = false;
  int _lastCount = 0;

  late final Stream<List<Map<String, dynamic>>> _messages = _db
      .from('support_messages')
      .stream(primaryKey: ['id'])
      .eq('ticket_id', widget.ticketId)
      .order('created_at');

  @override
  void initState() {
    super.initState();
    _markRead();
  }

  @override
  void dispose() {
    _ctrl.dispose();
    _scroll.dispose();
    super.dispose();
  }

  Future<void> _markRead() async {
    try {
      await _db.rpc('support_mark_read', params: {'p_ticket': widget.ticketId});
    } catch (_) {}
  }

  Future<void> _send() async {
    final text = _ctrl.text.trim();
    final uid = _db.auth.currentUser?.id;
    if (text.isEmpty || uid == null || _sending) return;
    setState(() => _sending = true);
    try {
      await _db.from('support_messages').insert({
        'ticket_id': widget.ticketId,
        'sender_id': uid,
        'sender_role': 'user',
        'body': text,
      }).timeout(const Duration(seconds: 20));
      _ctrl.clear();
    } catch (e) {
      if (mounted) {
        ErrorUI.showSnack(context, AppError.from(e, onRetry: _send));
      }
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  void _toBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scroll.hasClients) {
        _scroll.animateTo(_scroll.position.maxScrollExtent,
            duration: const Duration(milliseconds: 250),
            curve: Curves.easeOut);
      }
    });
  }

  String _time(dynamic v) {
    final d = DateTime.tryParse('${v ?? ''}')?.toLocal();
    if (d == null) return '';
    final now = DateTime.now();
    final hm =
        '${d.hour.toString().padLeft(2, '0')}:${d.minute.toString().padLeft(2, '0')}';
    if (d.year == now.year && d.month == now.month && d.day == now.day) {
      return hm;
    }
    return '${d.day.toString().padLeft(2, '0')}/${d.month.toString().padLeft(2, '0')} $hm';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: EfuridePalette.cream,
      appBar: AppBar(
        backgroundColor: EfuridePalette.cream,
        foregroundColor: EfuridePalette.ink,
        elevation: 0,
        scrolledUnderElevation: 0,
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(widget.subject.isEmpty ? tr('Support') : widget.subject,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                    fontSize: 18, fontWeight: FontWeight.w800)),
            Text(tr('ko!ngo support'),
                style: const TextStyle(
                    fontSize: 13.5, color: EfuridePalette.inkMuted)),
          ],
        ),
      ),
      body: Column(
        children: [
          Expanded(
            child: StreamBuilder<List<Map<String, dynamic>>>(
              stream: _messages,
              builder: (context, snap) {
                if (snap.hasError) {
                  return ErrorUI.inline(AppError.from(snap.error!));
                }
                if (!snap.hasData) {
                  return const Center(child: CircularProgressIndicator());
                }
                final msgs = snap.data!;
                if (msgs.length != _lastCount) {
                  _lastCount = msgs.length;
                  _toBottom();
                  _markRead();
                }
                return ListView.builder(
                  controller: _scroll,
                  padding: const EdgeInsets.fromLTRB(12, 8, 12, 12),
                  itemCount: msgs.length + 1,
                  itemBuilder: (_, i) {
                    if (i == msgs.length) {
                      final waiting = msgs.isEmpty ||
                          msgs.last['sender_role'] != 'admin';
                      return waiting
                          ? Padding(
                              padding: const EdgeInsets.only(top: 8),
                              child: Text(
                                tr('Our team will reply here. You will get a notification.'),
                                textAlign: TextAlign.center,
                                style: const TextStyle(
                                    fontSize: 13.5,
                                    color: EfuridePalette.inkMuted),
                              ),
                            )
                          : const SizedBox.shrink();
                    }
                    return _bubble(msgs[i]);
                  },
                );
              },
            ),
          ),
          SafeArea(
            top: false,
            child: Container(
              padding: const EdgeInsets.fromLTRB(12, 8, 8, 8),
              decoration: const BoxDecoration(
                color: Colors.white,
                border:
                    Border(top: BorderSide(color: EfuridePalette.divider)),
              ),
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _ctrl,
                      minLines: 1,
                      maxLines: 4,
                      textCapitalization: TextCapitalization.sentences,
                      style: const TextStyle(fontSize: 16),
                      decoration: InputDecoration(
                        hintText: tr('Write a message'),
                        filled: true,
                        fillColor: EfuridePalette.greyBg,
                        contentPadding: const EdgeInsets.symmetric(
                            horizontal: 14, vertical: 12),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(22),
                          borderSide: BorderSide.none,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 6),
                  IconButton.filled(
                    onPressed: _sending ? null : _send,
                    style: IconButton.styleFrom(
                      backgroundColor: EfuridePalette.accent,
                      foregroundColor: EfuridePalette.accentInk,
                      minimumSize: const Size(48, 48),
                    ),
                    icon: _sending
                        ? const SizedBox(
                            width: 18,
                            height: 18,
                            child: CircularProgressIndicator(strokeWidth: 2))
                        : const Icon(Icons.send),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _bubble(Map<String, dynamic> m) {
    final mine = m['sender_role'] != 'admin';
    return Align(
      alignment: mine ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        constraints: BoxConstraints(
            maxWidth: MediaQuery.of(context).size.width * 0.78),
        margin: const EdgeInsets.symmetric(vertical: 4),
        padding: const EdgeInsets.fromLTRB(14, 10, 14, 8),
        decoration: BoxDecoration(
          color: mine ? const Color(0xFFFEF3C7) : Colors.white,
          borderRadius: BorderRadius.only(
            topLeft: const Radius.circular(16),
            topRight: const Radius.circular(16),
            bottomLeft: Radius.circular(mine ? 16 : 4),
            bottomRight: Radius.circular(mine ? 4 : 16),
          ),
          border: Border.all(color: EfuridePalette.divider),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (!mine)
              Padding(
                padding: const EdgeInsets.only(bottom: 2),
                child: Text(tr('ko!ngo support'),
                    style: const TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w800,
                        color: Color(0xFF1565C0))),
              ),
            Text((m['body'] ?? '').toString(),
                style: const TextStyle(fontSize: 16, height: 1.3)),
            const SizedBox(height: 4),
            Align(
              alignment: Alignment.bottomRight,
              child: Text(_time(m['created_at']),
                  style: const TextStyle(
                      fontSize: 12, color: EfuridePalette.inkMuted)),
            ),
          ],
        ),
      ),
    );
  }
}
