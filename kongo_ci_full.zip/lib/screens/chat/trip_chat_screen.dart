// lib/screens/shared/trip_chat_screen.dart

import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:url_launcher/url_launcher.dart';

import 'package:efuride_app/services/notification_service.dart';
import 'package:efuride_app/services/ring_service.dart' show activeChatRideId;
import 'package:efuride_app/utils/app_error.dart';
import 'package:efuride_app/utils/error_ui.dart';
import 'package:efuride_app/utils/phone_utils.dart';
import 'package:efuride_app/l10n/app_strings.dart';
import 'package:efuride_app/widgets/k_icon.dart';

class _Palette {
  static const cream = Color(0xFFFAF6EE);
  static const ink = Color(0xFF1A1A1A);
  static const inkMuted = Color(0xFF575047);
  static const accent = Color(0xFFF2B705);
  static const accentInk = Color(0xFF0B1220);
  static const pickup = Color(0xFF34C759);
  static const dropoff = Color(0xFFE53935);
  static const divider = Color(0xFFE8E2D5);
  static const blue = Color(0xFF1E88E5);
  static const danger = Color(0xFFE53935);
}

class ChatScreen extends StatefulWidget {
  final String rideId;
  const ChatScreen({super.key, required this.rideId});

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  // ── Tunables ────────────────────────────────────────────────
  static const _imageBucket = 'ride-chat'; // Supabase Storage bucket
  static const _groupWindow = Duration(minutes: 2);
  static const _nearBottomThreshold = 120.0;

  // ── Controllers ─────────────────────────────────────────────
  final _messageCtrl = TextEditingController();
  final _scrollCtrl = ScrollController();
  final _focusNode = FocusNode();
  final _picker = ImagePicker();

  // ── State ───────────────────────────────────────────────────
  List<Map<String, dynamic>> _messages = [];
  Map<String, dynamic>? _rideInfo;
  Map<String, dynamic>? _otherUser;

  String? _myUserId;
  String? _myRole;

  bool _isLoading = true;
  bool _isSending = false;
  bool _isUploading = false;
  bool _isCalling = false;
  AppError? _error;

  RealtimeChannel? _messagesChannel;
  RealtimeChannel? _typingChannel;

  bool _otherIsTyping = false;
  Timer? _myTypingTimer;
  Timer? _otherTypingTimeout;

  bool _userNearBottom = true;
  bool _showJumpPill = false;

  // ============================================================
  // LIFECYCLE
  // ============================================================
  @override
  void initState() {
    super.initState();
    _myUserId = Supabase.instance.client.auth.currentUser?.id;
    _messageCtrl.addListener(_onLocalTyping);
    _scrollCtrl.addListener(_onScroll);
    activeChatRideId.value = widget.rideId;
    _initChat();
  }

  @override
  void dispose() {
    _messagesChannel?.unsubscribe();
    _typingChannel?.unsubscribe();
    _myTypingTimer?.cancel();
    _otherTypingTimeout?.cancel();
    _messageCtrl.dispose();
    _scrollCtrl.dispose();
    _focusNode.dispose();
    if (activeChatRideId.value == widget.rideId) {
      activeChatRideId.value = null;
    }
    super.dispose();
  }

  // ============================================================
  // INIT
  // ============================================================
  Future<void> _initChat() async {
    setState(() {
      _isLoading = true;
      _error = null;
    });

    if (_myUserId == null) {
      setState(() {
        _isLoading = false;
        _error = AppError(
          title: tr('Not signed in'),
          message: tr('Please sign in to use chat.'),
          icon: Icons.lock_outline,
        );
      });
      return;
    }

    if (widget.rideId.trim().isEmpty) {
      setState(() {
        _isLoading = false;
        _error = AppError(
          title: tr('No active ride'),
          message: tr('There\'s no trip to chat about yet.'),
          icon: Icons.chat_bubble_outline,
        );
      });
      return;
    }

    try {
      final client = Supabase.instance.client;

      final ride = await client
          .from('rides')
          .select()
          .eq('id', widget.rideId)
          .maybeSingle();

      if (ride == null) {
        if (!mounted) return;
        setState(() {
          _isLoading = false;
          _error = AppError(
            title: tr('Ride not found'),
            message: tr('This trip may have been removed.'),
            icon: Icons.error_outline,
          );
        });
        return;
      }

      final myId = (_myUserId ?? '').trim();
      final custId = (ride['customer_id'] ?? '').toString().trim();
      final drivId = (ride['driver_id'] ?? '').toString().trim();

      if (myId.isNotEmpty && myId == custId) {
        _myRole = 'customer';
      } else if (myId.isNotEmpty && drivId.isNotEmpty && myId == drivId) {
        _myRole = 'driver';
      } else {
        if (!mounted) return;
        setState(() {
          _isLoading = false;
          _error = AppError(
            title: tr('Access denied'),
            message: tr('You\'re not a participant in this trip.'),
            icon: Icons.lock_outline,
          );
        });
        return;
      }

      final otherUserId = (_myRole == 'customer') ? drivId : custId;

      Map<String, dynamic>? otherProfile;
      if (otherUserId.isNotEmpty) {
        try {
          otherProfile = await client
              .from('profiles')
              .select(
                  'id, first_name, surname, full_name, profile_picture_url, avatar_url, average_rating')
              .eq('id', otherUserId)
              .maybeSingle();

          // Some accounts keep their photo in avatar_url instead.
          if (otherProfile != null &&
              (otherProfile['profile_picture_url'] ?? '').toString().isEmpty) {
            otherProfile['profile_picture_url'] = otherProfile['avatar_url'];
          }

          if (otherProfile != null) {
            final r = otherProfile['average_rating'];
            if (r is num) {
              otherProfile['average_rating'] = r.toDouble();
            } else if (r != null) {
              otherProfile['average_rating'] =
                  double.tryParse(r.toString()) ?? 5.0;
            }
          }
        } catch (e) {
          debugPrint('profile fetch failed: $e');
        }
      }

      List<Map<String, dynamic>> msgs = [];
      try {
        final res = await client
            .from('ride_messages')
            .select()
            .eq('ride_id', widget.rideId)
            .order('created_at', ascending: true);
        msgs = List<Map<String, dynamic>>.from(res);
      } catch (e) {
        debugPrint('message fetch failed: $e');
      }

      if (!mounted) return;

      setState(() {
        _rideInfo = ride;
        _otherUser = otherProfile;
        _messages = msgs;
        _isLoading = false;
        _error = null;
      });

      _subscribeToMessages();
      _markRead();
      _subscribeToTyping();
      _maybeScrollToBottom(force: true);
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _isLoading = false;
        _error = AppError.from(e, onRetry: _initChat);
      });
    }
  }

  // ============================================================
  // REALTIME — MESSAGES
  // ============================================================
  void _subscribeToMessages() {
    _messagesChannel?.unsubscribe();

    // Unique channel name is fine here because Postgres changes are
    // filtered server-side by ride_id.
    final name =
        'ride_msgs_${widget.rideId}_${DateTime.now().microsecondsSinceEpoch}';

    _messagesChannel = Supabase.instance.client
        .channel(name)
        .onPostgresChanges(
          event: PostgresChangeEvent.all,
          schema: 'public',
          table: 'ride_messages',
          filter: PostgresChangeFilter(
            type: PostgresChangeFilterType.eq,
            column: 'ride_id',
            value: widget.rideId,
          ),
          callback: (payload) {
            switch (payload.eventType) {
              case PostgresChangeEvent.insert:
                _handleRemoteInsert(payload.newRecord);
                break;
              case PostgresChangeEvent.update:
                _handleRemoteUpdate(payload.newRecord);
                break;
              case PostgresChangeEvent.delete:
                _handleRemoteDelete(payload.oldRecord);
                break;
              default:
                break;
            }
          },
        )
        .subscribe();
  }

  Map<String, dynamic>? _decodeRecord(dynamic raw) {
    try {
      if (raw is Map<String, dynamic>) return Map.from(raw);
      if (raw is Map) {
        return raw.map((k, v) => MapEntry(k.toString(), v));
      }
      if (raw is String) {
        final decoded = jsonDecode(raw);
        if (decoded is Map<String, dynamic>) return decoded;
        if (decoded is Map) {
          return decoded.map((k, v) => MapEntry(k.toString(), v));
        }
      }
    } catch (e) {
      debugPrint('decode failed: $e');
    }
    return null;
  }

  void _handleRemoteInsert(dynamic raw) {
    final msg = _decodeRecord(raw);
    if (msg == null || msg.isEmpty) return;
    _markRead(); // the chat is open, so this message is read
    if (_messages.any((m) => m['id'] == msg['id'])) return;

    // Drop the optimistic copy (matched by sender + body/image).
    _messages.removeWhere((m) {
      final id = (m['id'] ?? '').toString();
      if (!id.startsWith('temp_')) return false;
      if (m['sender_id'] != msg['sender_id']) return false;
      final sameText = (m['message'] ?? '').toString().isNotEmpty &&
          m['message'] == msg['message'];
      final sameImage = m['image_url'] != null &&
          m['image_url'] != '' &&
          m['image_url'] == msg['image_url'];
      return sameText || sameImage;
    });

    if (!mounted) return;
    final mine = msg['sender_id'] == _myUserId;
    setState(() => _messages.add(msg));
    _maybeScrollToBottom(force: mine);
  }

  void _handleRemoteUpdate(dynamic raw) {
    final msg = _decodeRecord(raw);
    if (msg == null) return;
    final idx = _messages.indexWhere((m) => m['id'] == msg['id']);
    if (idx == -1) return;
    if (!mounted) return;
    setState(() => _messages[idx] = {..._messages[idx], ...msg});
  }

  void _handleRemoteDelete(dynamic raw) {
    final msg = _decodeRecord(raw);
    if (msg == null) return;
    final id = msg['id'];
    if (id == null) return;
    if (!mounted) return;
    setState(() => _messages.removeWhere((m) => m['id'] == id));
  }

  // ============================================================
  // REALTIME — TYPING
  // ============================================================
  void _subscribeToTyping() {
    _typingChannel?.unsubscribe();

    // ⚠️ MUST be identical on both devices — no timestamp, no user id.
    final channelName = 'typing_ride_${widget.rideId}';

    _typingChannel = Supabase.instance.client
        .channel(channelName)
        .onBroadcast(
          event: 'typing',
          callback: (payload) {
            final from = payload['user_id']?.toString();
            final typing = payload['typing'] == true;
            if (from == null || from == _myUserId) return;

            if (typing) {
              _otherTypingTimeout?.cancel();
              _otherTypingTimeout = Timer(const Duration(seconds: 3), () {
                if (mounted) setState(() => _otherIsTyping = false);
              });
              if (mounted && !_otherIsTyping) {
                setState(() => _otherIsTyping = true);
              }
            } else {
              _otherTypingTimeout?.cancel();
              if (mounted && _otherIsTyping) {
                setState(() => _otherIsTyping = false);
              }
            }
          },
        )
        .subscribe();
  }

  void _onLocalTyping() {
    final hasText = _messageCtrl.text.trim().isNotEmpty;
    _sendTyping(hasText);
    _myTypingTimer?.cancel();
    if (hasText) {
      _myTypingTimer = Timer(const Duration(seconds: 2), () {
        _sendTyping(false);
      });
    }
  }

  void _sendTyping(bool typing) {
    try {
      _typingChannel?.sendBroadcastMessage(
        event: 'typing',
        payload: {'user_id': _myUserId, 'role': _myRole, 'typing': typing},
      );
    } catch (_) {}
  }

  // ============================================================
  // SEND — TEXT
  // ============================================================
  Future<void> _sendMessage() async {
    if (_isSending) return;
    final text = _messageCtrl.text.trim();
    if (text.isEmpty || _myUserId == null) return;

    setState(() => _isSending = true);
    _sendTyping(false);

    final nowIso = DateTime.now().toUtc().toIso8601String();
    final tempId = 'temp_${DateTime.now().microsecondsSinceEpoch}';

    final optimistic = <String, dynamic>{
      'id': tempId,
      'ride_id': widget.rideId,
      'sender_id': _myUserId,
      'sender_role': _myRole,
      'message': text,
      'created_at': nowIso,
      '_status': 'sending',
    };

    setState(() {
      _messages.add(optimistic);
      _messageCtrl.clear();
    });
    _maybeScrollToBottom(force: true);

    await _commitMessage(optimistic: optimistic, payload: {
      'ride_id': widget.rideId,
      'sender_id': _myUserId,
      'sender_role': _myRole,
      'message': text,
      'created_at': nowIso,
    });

    if (mounted) setState(() => _isSending = false);
  }

  // ============================================================
  // SEND — IMAGE
  // ============================================================
  Future<void> _sendImage() async {
    if (_isUploading || _myUserId == null) return;

    // Camera or gallery.
    final source = await showModalBottomSheet<ImageSource>(
      context: context,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (ctx) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 8),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              ListTile(
                leading: const Icon(Icons.photo_camera_outlined,
                    color: _Palette.ink),
                title: Text(tr('Take a photo'),
                    style: const TextStyle(
                        fontSize: 16, fontWeight: FontWeight.w700)),
                onTap: () => Navigator.pop(ctx, ImageSource.camera),
              ),
              ListTile(
                leading: const KIcon(Icons.photo_library_outlined,
                    color: _Palette.ink),
                title: Text(tr('Choose from gallery'),
                    style: const TextStyle(
                        fontSize: 16, fontWeight: FontWeight.w700)),
                onTap: () => Navigator.pop(ctx, ImageSource.gallery),
              ),
            ],
          ),
        ),
      ),
    );
    if (source == null || !mounted) return;

    XFile? picked;
    try {
      picked = await _picker.pickImage(
        source: source,
        imageQuality: 70,
        maxWidth: 1600,
      );
    } catch (e) {
      debugPrint('pick failed: $e');
      return;
    }
    if (picked == null) return;

    setState(() => _isUploading = true);

    final nowIso = DateTime.now().toUtc().toIso8601String();
    final tempId = 'temp_${DateTime.now().microsecondsSinceEpoch}';
    final localFile = File(picked.path);

    final optimistic = <String, dynamic>{
      'id': tempId,
      'ride_id': widget.rideId,
      'sender_id': _myUserId,
      'sender_role': _myRole,
      'message': '',
      'image_url': '', // placeholder until upload
      'created_at': nowIso,
      '_local_path': picked.path,
      '_status': 'sending',
    };

    setState(() => _messages.add(optimistic));
    _maybeScrollToBottom(force: true);

    try {
      final ext = picked.path.split('.').last.toLowerCase();
      final path =
          '${widget.rideId}/${DateTime.now().millisecondsSinceEpoch}_${_myUserId}.$ext';
      final bytes = await localFile.readAsBytes();

      await Supabase.instance.client.storage
          .from(_imageBucket)
          .uploadBinary(
            path,
            bytes,
            fileOptions: FileOptions(
              contentType: _mimeFor(ext),
              upsert: false,
            ),
          );

      final url =
          Supabase.instance.client.storage.from(_imageBucket).getPublicUrl(path);

      await _commitMessage(optimistic: optimistic, payload: {
        'ride_id': widget.rideId,
        'sender_id': _myUserId,
        'sender_role': _myRole,
        'message': '',
        'image_url': url,
        'created_at': nowIso,
      });
    } catch (e) {
      debugPrint('image upload failed: $e');
      if (!mounted) return;
      setState(() {
        final idx = _messages.indexWhere((m) => m['id'] == tempId);
        if (idx != -1) _messages[idx]['_status'] = 'failed';
      });
      ErrorUI.showSnack(context, AppError.from(e));
    } finally {
      if (mounted) setState(() => _isUploading = false);
    }
  }

  String _mimeFor(String ext) {
    switch (ext) {
      case 'png':
        return 'image/png';
      case 'gif':
        return 'image/gif';
      case 'webp':
        return 'image/webp';
      default:
        return 'image/jpeg';
    }
  }

  // ============================================================
  // SEND — COMMIT (shared by text & image)
  // ============================================================
  Future<void> _commitMessage({
    required Map<String, dynamic> optimistic,
    required Map<String, dynamic> payload,
  }) async {
    final tempId = optimistic['id'] as String;

    try {
      final inserted = await Supabase.instance.client
          .from('ride_messages')
          .insert(payload)
          .select()
          .single();

      if (!mounted) return;
      setState(() {
        _messages.removeWhere((m) => m['id'] == tempId);
        if (!_messages.any((m) => m['id'] == inserted['id'])) {
          _messages.add({...Map<String, dynamic>.from(inserted), '_status': 'sent'});
        }
      });
      _maybeScrollToBottom(force: true);

      _notifyOtherParty(payload['message']?.toString() ?? '📷 Photo');
    } catch (e) {
      debugPrint('send failed: $e');
      if (!mounted) return;
      setState(() {
        final idx = _messages.indexWhere((m) => m['id'] == tempId);
        if (idx != -1) _messages[idx]['_status'] = 'failed';
      });
    }
  }

  Future<void> _retryMessage(Map<String, dynamic> msg) async {
    final id = (msg['id'] ?? '').toString();
    if (!id.startsWith('temp_')) return;
    if (msg['_status'] == 'sending') return;

    setState(() {
      final idx = _messages.indexWhere((m) => m['id'] == id);
      if (idx != -1) _messages[idx]['_status'] = 'sending';
    });

    final isImage = (msg['image_url'] != null && msg['image_url'] != '') ||
        msg['_local_path'] != null;

    if (isImage && msg['_local_path'] != null) {
      // Re-run the upload path
      final path = msg['_local_path'] as String;
      try {
        final ext = path.split('.').last.toLowerCase();
        final remotePath =
            '${widget.rideId}/${DateTime.now().millisecondsSinceEpoch}_${_myUserId}.$ext';
        final bytes = await File(path).readAsBytes();
        await Supabase.instance.client.storage
            .from(_imageBucket)
            .uploadBinary(
              remotePath,
              bytes,
              fileOptions: FileOptions(contentType: _mimeFor(ext)),
            );
        final url = Supabase.instance.client.storage
            .from(_imageBucket)
            .getPublicUrl(remotePath);

        await _commitMessage(optimistic: msg, payload: {
          'ride_id': widget.rideId,
          'sender_id': _myUserId,
          'sender_role': _myRole,
          'message': '',
          'image_url': url,
          'created_at': msg['created_at'],
        });
      } catch (e) {
        if (!mounted) return;
        setState(() {
          final idx = _messages.indexWhere((m) => m['id'] == id);
          if (idx != -1) _messages[idx]['_status'] = 'failed';
        });
      }
      return;
    }

    await _commitMessage(optimistic: msg, payload: {
      'ride_id': widget.rideId,
      'sender_id': _myUserId,
      'sender_role': _myRole,
      'message': msg['message'],
      'created_at': msg['created_at'],
    });
  }

  void _notifyOtherParty(String preview) {
    final ride = _rideInfo;
    if (ride == null) return;

    final otherId = _myRole == 'customer'
        ? ride['driver_id']?.toString()
        : ride['customer_id']?.toString();
    if (otherId == null || otherId.isEmpty) return;

    final senderLabel = _myRole == 'customer' ? 'Passenger' : 'Driver';
    NotificationService.send(
      toUserId: otherId,
      title: tr('💬 New message from {0}', [senderLabel]),
      body: preview,
      type: 'chat_message',
      data: {
        'ride_id': widget.rideId,
        'sender_id': _myUserId,
        'sender_role': _myRole,
      },
    );
  }

  // ============================================================
  // SCROLL
  // ============================================================
  void _onScroll() {
    if (!_scrollCtrl.hasClients) return;
    final pos = _scrollCtrl.position;
    final near = (pos.maxScrollExtent - pos.pixels) < _nearBottomThreshold;
    if (near != _userNearBottom) {
      _userNearBottom = near;
      final shouldShow = !near && _messages.isNotEmpty;
      if (shouldShow != _showJumpPill && mounted) {
        setState(() => _showJumpPill = shouldShow);
      }
    }
  }

  void _maybeScrollToBottom({bool force = false}) {
    if (!force && !_userNearBottom) return;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!_scrollCtrl.hasClients) return;
      _scrollCtrl.animateTo(
        _scrollCtrl.position.maxScrollExtent,
        duration: const Duration(milliseconds: 250),
        curve: Curves.easeOut,
      );
      if (mounted && _showJumpPill) {
        setState(() => _showJumpPill = false);
      }
    });
  }

  // ============================================================
  // CALL FLOW
  // ============================================================
  bool get _canCall {
    final status = _rideInfo?['status']?.toString() ?? '';
    return status == 'accepted' || status == 'in_progress';
  }

  Future<void> _openCallSheet() async {
    if (_isCalling) return;

    final ride = _rideInfo;
    String? otherId;
    if (ride != null) {
      otherId = _myRole == 'customer'
          ? ride['driver_id']?.toString()
          : ride['customer_id']?.toString();
    }

    if (otherId == null || otherId.isEmpty) {
      ErrorUI.showSnack(
        context,
        AppError(
          title: tr('Can\'t call'),
          message: tr('Contact details are unavailable right now.'),
          icon: Icons.phone_disabled_outlined,
        ),
      );
      return;
    }

    setState(() => _isCalling = true);
    try {
      final profile = await Supabase.instance.client
          .from('profiles')
          .select('first_name, surname, phone_number, role')
          .eq('id', otherId)
          .maybeSingle()
          .timeout(const Duration(seconds: 8));

      if (!mounted) return;
      setState(() => _isCalling = false);

      final phoneRaw = profile?['phone_number']?.toString().trim();
      if (phoneRaw == null || phoneRaw.isEmpty) {
        ErrorUI.showSnack(
          context,
          AppError(
            title: tr('No phone number'),
            message:
                tr('{0} hasn\'t added a phone number to their profile.', [_otherName()]),
            icon: Icons.phone_disabled_outlined,
          ),
        );
        return;
      }

      final phone = PhoneUtils.normalise(phoneRaw);
      if (phone == null || !PhoneUtils.isValid(phone)) {
        ErrorUI.showSnack(
          context,
          AppError(
            title: tr('Invalid number'),
            message: tr('We can\'t dial that phone number.'),
            icon: Icons.phone_disabled_outlined,
          ),
        );
        return;
      }

      final confirmed = await _showCallConfirmDialog(phone);
      if (confirmed != true) return;

      unawaited(_logCall(otherId));

      final uri = Uri(scheme: 'tel', path: phone);
      final ok = await launchUrl(uri, mode: LaunchMode.externalApplication);

      if (!ok && mounted) {
        ErrorUI.showSnack(
          context,
          AppError(
            title: tr('Couldn\'t open dialer'),
            message:
                tr('Your device may not have a phone app. Please dial manually.'),
            icon: Icons.phone_disabled_outlined,
          ),
        );
      }
    } catch (e) {
      if (!mounted) return;
      setState(() => _isCalling = false);
      ErrorUI.showSnack(context, AppError.from(e, onRetry: _openCallSheet));
    }
  }

  Future<bool?> _showCallConfirmDialog(String normalisedPhone) {
    return showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(6),
              decoration: BoxDecoration(
                color: _Palette.pickup.withValues(alpha: 0.15),
                borderRadius: BorderRadius.circular(8),
              ),
              child: const Icon(Icons.call,
                  color: _Palette.pickup, size: 18),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Text(tr('Call {0}?', [_otherName()]),
                  style: const TextStyle(fontSize: 16)),
            ),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              PhoneUtils.mask(normalisedPhone),
              style: const TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: _Palette.ink,
                letterSpacing: 1.2,
              ),
            ),
            const SizedBox(height: 10),
            Text(
              tr('This will open your phone\'s dialer with the number pre-filled.'),
              style: TextStyle(fontSize: 13.5, color: _Palette.inkMuted),
            ),
            const SizedBox(height: 6),
            Text(
              tr('Your number stays hidden. Only the call is connected.'),
              style: TextStyle(
                fontSize: 13,
                color: _Palette.inkMuted,
                fontStyle: FontStyle.italic,
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: Text(tr('Cancel')),
          ),
          ElevatedButton.icon(
            style: ElevatedButton.styleFrom(
              backgroundColor: _Palette.pickup,
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10)),
            ),
            onPressed: () => Navigator.pop(ctx, true),
            icon: const Icon(Icons.call, size: 16),
            label: Text(tr('Call'),
                style: TextStyle(fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }

  Future<void> _logCall(String calleeId) async {
    try {
      await Supabase.instance.client.from('call_logs').insert({
        'ride_id': widget.rideId,
        'caller_id': _myUserId,
        'callee_id': calleeId,
        'caller_role': _myRole,
      });
    } catch (e) {
      debugPrint('call log insert failed: $e');
    }
  }

  // ============================================================
  // QUICK REPLIES
  // ============================================================
  List<String> get _quickReplies {
    final status = _rideInfo?['status']?.toString() ?? '';

    if (_myRole == 'driver') {
      if (status == 'accepted') {
        return const [
          "I'm on my way",
          "I'll be there in 2 min",
          "I'm at the pickup",
          "Can't find you",
          "Please come to the main gate",
        ];
      }
      if (status == 'in_progress') {
        return const [
          "We've arrived",
          "Please rate me 5 stars",
          "Thank you!",
        ];
      }
      return const ["I'm on my way", "Ok", "See you soon"];
    }

    if (_myRole == 'customer') {
      if (status == 'accepted') {
        return const [
          "I'm at the pickup",
          "I'll be there in 2 min",
          "Please wait, coming now",
          "Where are you?",
          "I'm wearing a blue shirt",
        ];
      }
      if (status == 'in_progress') {
        return const [
          "Thank you!",
          "Please drop me here",
          "Next turn please",
        ];
      }
      return const ["Ok", "Thanks"];
    }

    return const [];
  }

  Widget _buildQuickReplies() {
    final replies = _quickReplies;
    if (replies.isEmpty) return const SizedBox.shrink();

    return Container(
      height: 46,
      color: Colors.white,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        itemCount: replies.length,
        separatorBuilder: (_, __) => const SizedBox(width: 8),
        itemBuilder: (_, i) {
          final text = replies[i];
          return ActionChip(
            label: Text(text, style: const TextStyle(fontSize: 14)),
            labelPadding:
                const EdgeInsets.symmetric(horizontal: 6, vertical: 0),
            padding: EdgeInsets.zero,
            backgroundColor: Colors.grey[100],
            side: BorderSide(color: Colors.grey.shade300),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(20),
            ),
            onPressed: _isSending
                ? null
                : () {
                    _messageCtrl.text = text;
                    _messageCtrl.selection = TextSelection.fromPosition(
                      TextPosition(offset: _messageCtrl.text.length),
                    );
                    _sendMessage();
                  },
          );
        },
      ),
    );
  }

  // ============================================================
  // HELPERS
  // ============================================================
  bool _isMyMessage(Map<String, dynamic> m) => m['sender_id'] == _myUserId;

  DateTime? _parseTime(dynamic iso) {
    if (iso == null) return null;
    try {
      if (iso is int) {
        return iso > 100000000000
            ? DateTime.fromMillisecondsSinceEpoch(iso, isUtc: true).toLocal()
            : DateTime.fromMillisecondsSinceEpoch(iso * 1000, isUtc: true)
                .toLocal();
      }
      if (iso is double) return _parseTime(iso.toInt());
      return DateTime.parse(iso.toString()).toLocal();
    } catch (_) {
      return null;
    }
  }

  String _timeLabel(dynamic iso) {
    final dt = _parseTime(iso);
    if (dt == null) return '';
    return DateFormat('h:mm a').format(dt);
  }

  String _dayLabel(DateTime t) {
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final that = DateTime(t.year, t.month, t.day);
    final diffDays = today.difference(that).inDays;

    if (diffDays == 0) {
      final d = now.difference(t);
      if (d.inMinutes < 1) return 'Just now';
      if (d.inHours < 1) return '${d.inMinutes}m ago';
      return 'Today';
    }
    if (diffDays == 1) return 'Yesterday';
    if (diffDays < 7) return '${diffDays}d ago';
    return DateFormat('d MMM').format(t);
  }

  String _otherName() {
    if (_otherUser == null) return 'User';
    final f = _otherUser!['first_name'] ?? '';
    final s = _otherUser!['surname'] ?? '';
    final full = _otherUser!['full_name'] ?? '';
    final composed = '$f $s'.trim();
    if (composed.isNotEmpty) return composed;
    if (full.toString().isNotEmpty) return full.toString();
    return 'User';
  }

  bool _shouldShowDateSeparator(int index) {
    if (index == 0) return true;
    final curr = _parseTime(_messages[index]['created_at']);
    final prev = _parseTime(_messages[index - 1]['created_at']);
    if (curr == null || prev == null) return false;
    return curr.year != prev.year ||
        curr.month != prev.month ||
        curr.day != prev.day;
  }

  bool _shouldGroupWithPrev(int index) {
    if (index == 0) return false;
    if (_shouldShowDateSeparator(index)) return false;
    final prev = _messages[index - 1];
    final curr = _messages[index];
    if (prev['sender_id'] != curr['sender_id']) return false;
    final pt = _parseTime(prev['created_at']);
    final ct = _parseTime(curr['created_at']);
    if (pt == null || ct == null) return false;
    return ct.difference(pt) < _groupWindow;
  }

  // ============================================================
  // BUILD
  // ============================================================
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _Palette.cream,
      appBar: _buildAppBar(),
      body: Column(
        children: [
          if (_rideInfo != null) _buildRideBanner(),
          Expanded(
            child: Stack(
              children: [
                _buildBody(),
                if (_showJumpPill)
                  Positioned(
                    right: 16,
                    bottom: 16,
                    child: _buildJumpPill(),
                  ),
              ],
            ),
          ),
          if (_otherIsTyping) _buildTypingIndicator(),
          if (_error == null &&
              _rideInfo != null &&
              _rideInfo!['status'] != 'completed' &&
              _rideInfo!['status'] != 'cancelled')
            _buildQuickReplies(),
          if (_error == null && !_chatClosed) _buildInputBar(),
          if (_error == null && _chatClosed)
            SafeArea(
              top: false,
              child: Container(
                width: double.infinity,
                padding: const EdgeInsets.all(16),
                color: Colors.white,
                child: Text(
                  tr('This trip has ended, so the chat is closed.'),
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                      fontSize: 15, color: _Palette.inkMuted),
                ),
              ),
            ),
        ],
      ),
    );
  }

  /// Finished trips: messages stay readable, no new ones.
  bool get _chatClosed {
    final st = (_rideInfo?['status'] ?? '').toString();
    return st == 'completed' || st == 'cancelled' || st == 'returned';
  }

  void _markRead() {
    Supabase.instance.client
        .rpc('mark_chat_read', params: {'p_ride': widget.rideId})
        .then((_) {}, onError: (_) {});
  }

  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      backgroundColor: _Palette.cream,
      elevation: 1,
      iconTheme: const IconThemeData(color: _Palette.ink),
      titleSpacing: 0,
      title: Row(
        children: [
          CircleAvatar(
            radius: 20,
            backgroundColor: Colors.indigo.shade100,
            backgroundImage: _avatarProvider(_otherUser?['profile_picture_url']),
            child: _avatarProvider(_otherUser?['profile_picture_url']) == null
                ? Text(
                    _otherName().isNotEmpty
                        ? _otherName()[0].toUpperCase()
                        : '?',
                    style: const TextStyle(
                        fontWeight: FontWeight.bold, color: Colors.white),
                  )
                : null,
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  _otherName(),
                  style: const TextStyle(
                    color: _Palette.ink,
                    fontSize: 15,
                    fontWeight: FontWeight.bold,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 2),
                Text(
                  _myRole == 'customer' ? 'Your driver' : 'Your passenger',
                  style: const TextStyle(
                    color: _Palette.inkMuted,
                    fontSize: 13,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
      actions: [
        if (_canCall)
          IconButton(
            tooltip: tr('Call {0}', [_otherName()]),
            onPressed: _isCalling ? null : _openCallSheet,
            icon: _isCalling
                ? const SizedBox(
                    width: 20,
                    height: 20,
                    child: CircularProgressIndicator(
                      strokeWidth: 2,
                      color: _Palette.pickup,
                    ),
                  )
                : const Icon(Icons.call, color: _Palette.pickup),
          ),
      ],
    );
  }

  ImageProvider? _avatarProvider(dynamic url) {
    final s = url?.toString() ?? '';
    if (s.isEmpty) return null;
    return NetworkImage(s);
  }

  Widget _buildBody() {
    if (_isLoading) {
      return const Center(
          child: CircularProgressIndicator(color: _Palette.accent));
    }
    if (_error != null) {
      return Center(child: ErrorUI.inline(_error!));
    }
    if (_messages.isEmpty) return _buildEmptyState();

    return ListView.builder(
      controller: _scrollCtrl,
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 16),
      itemCount: _messages.length,
      itemBuilder: (context, index) {
        final msg = _messages[index];
        final mine = _isMyMessage(msg);
        final showDate = _shouldShowDateSeparator(index);
        final grouped = _shouldGroupWithPrev(index);

        final children = <Widget>[];
        if (showDate) {
          children.add(_buildDateSeparator(_parseTime(msg['created_at'])));
        }
        children.add(_buildBubble(msg, mine, grouped: grouped));

        return Column(children: children);
      },
    );
  }

  Widget _buildJumpPill() {
    return GestureDetector(
      onTap: () => _maybeScrollToBottom(force: true),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(
          color: _Palette.blue,
          borderRadius: BorderRadius.circular(20),
          boxShadow: [
            BoxShadow(
              color: _Palette.blue.withValues(alpha: 0.35),
              blurRadius: 10,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.arrow_downward, color: Colors.white, size: 14),
            SizedBox(width: 6),
            Text(
              tr('New messages'),
              style: TextStyle(
                color: Colors.white,
                fontSize: 13.5,
                fontWeight: FontWeight.w700,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDateSeparator(DateTime? t) {
    if (t == null) return const SizedBox.shrink();
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 12),
      child: Center(
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: _Palette.divider),
          ),
          child: Text(
            _dayLabel(t),
            style: const TextStyle(
              fontSize: 13,
              fontWeight: FontWeight.w700,
              color: _Palette.inkMuted,
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildTypingIndicator() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      alignment: Alignment.centerLeft,
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          const _TypingDots(),
          const SizedBox(width: 8),
          Text(
            tr('{0} is typing…', [_otherName()]),
            style: const TextStyle(
              fontSize: 13.5,
              color: _Palette.inkMuted,
              fontStyle: FontStyle.italic,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildRideBanner() {
    final status = (_rideInfo!['status'] ?? 'pending').toString();
    final pickup = _rideInfo!['pickup_address'] ?? '—';
    final dropoff = _rideInfo!['dropoff_address'] ?? '—';
    final serviceType = _rideInfo!['service_type'] ?? 'Ride';
    final isDelivery = serviceType == 'Delivery';

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      color: Colors.white,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(
                isDelivery ? Icons.local_shipping : Icons.local_taxi,
                size: 16,
                color: _Palette.blue,
              ),
              const SizedBox(width: 6),
              Text(
                '$serviceType • ${status.toUpperCase()}',
                style: const TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.bold,
                  color: _Palette.blue,
                ),
              ),
            ],
          ),
          const SizedBox(height: 6),
          Row(
            children: [
              const Icon(Icons.my_location,
                  size: 12, color: _Palette.pickup),
              const SizedBox(width: 6),
              Expanded(
                child: Text(
                  pickup.toString(),
                  style:
                      const TextStyle(fontSize: 13, color: _Palette.ink),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ],
          ),
          const SizedBox(height: 2),
          Row(
            children: [
              const KIcon(Icons.location_on,
                  size: 12, color: _Palette.dropoff),
              const SizedBox(width: 6),
              Expanded(
                child: Text(
                  dropoff.toString(),
                  style:
                      const TextStyle(fontSize: 13, color: _Palette.ink),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const KIcon(Icons.chat_bubble_outline,
                size: 56, color: _Palette.inkMuted),
            const SizedBox(height: 12),
            Text(
              tr('No messages yet'),
              style: TextStyle(
                fontSize: 15,
                fontWeight: FontWeight.bold,
                color: _Palette.ink,
              ),
            ),
            const SizedBox(height: 6),
            Text(
              tr('Say hi to {0} to coordinate pickup.', [_otherName()]),
              textAlign: TextAlign.center,
              style: const TextStyle(
                fontSize: 13.5,
                color: _Palette.inkMuted,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ============================================================
  // BUBBLE
  // ============================================================
  Widget _buildBubble(
    Map<String, dynamic> msg,
    bool mine, {
    required bool grouped,
  }) {
    final text = (msg['message'] ?? '').toString();
    final imageUrl = (msg['image_url'] ?? '').toString();
    final localPath = (msg['_local_path'] ?? '').toString();
    final time = _timeLabel(msg['created_at']);
    final status = (msg['_status'] ?? '').toString();
    final rawId = msg['id']?.toString() ?? '';
    final isTemp = rawId.startsWith('temp_');
    final isFailed = status == 'failed';

    final avatarUrl = mine
        ? null
        : _avatarProvider(_otherUser?['profile_picture_url']);
    final otherInitial =
        _otherName().isNotEmpty ? _otherName()[0].toUpperCase() : '?';

    final radius = BorderRadius.only(
      topLeft: const Radius.circular(16),
      topRight: const Radius.circular(16),
      bottomLeft: Radius.circular(mine ? 16 : (grouped ? 16 : 4)),
      bottomRight: Radius.circular(mine ? (grouped ? 16 : 4) : 16),
    );

    return Padding(
      padding: EdgeInsets.only(
        top: grouped ? 2 : 6,
        bottom: 2,
        left: 4,
        right: 4,
      ),
      child: Row(
        mainAxisAlignment:
            mine ? MainAxisAlignment.end : MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          if (!mine) ...[
            SizedBox(
              width: 32,
              child: grouped
                  ? null
                  : CircleAvatar(
                      radius: 16,
                      backgroundColor: Colors.indigo.shade100,
                      backgroundImage: avatarUrl,
                      child: avatarUrl == null
                          ? Text(
                              otherInitial,
                              style: const TextStyle(
                                fontSize: 13.5,
                                fontWeight: FontWeight.bold,
                                color: Colors.white,
                              ),
                            )
                          : null,
                    ),
            ),
            const SizedBox(width: 6),
          ],
          Flexible(
            child: GestureDetector(
              onLongPress: () => _copyMessage(text),
              child: Container(
                padding: (imageUrl.isNotEmpty || localPath.isNotEmpty)
                    ? const EdgeInsets.all(4)
                    : const EdgeInsets.symmetric(
                        horizontal: 12, vertical: 8),
                constraints: BoxConstraints(
                  maxWidth: MediaQuery.of(context).size.width * 0.72,
                ),
                decoration: BoxDecoration(
                  color: mine ? _Palette.blue : Colors.white,
                  borderRadius: radius,
                  border: mine
                      ? null
                      : Border.all(color: _Palette.divider),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withValues(alpha: 0.05),
                      blurRadius: 4,
                      offset: const Offset(0, 2),
                    ),
                  ],
                ),
                child: Column(
                  crossAxisAlignment: mine
                      ? CrossAxisAlignment.end
                      : CrossAxisAlignment.start,
                  children: [
                    if (localPath.isNotEmpty)
                      _buildLocalImage(localPath, status)
                    else if (imageUrl.isNotEmpty)
                      _buildRemoteImage(imageUrl),
                    if (text.isNotEmpty)
                      Padding(
                        padding: (imageUrl.isNotEmpty || localPath.isNotEmpty)
                            ? const EdgeInsets.fromLTRB(8, 6, 8, 0)
                            : EdgeInsets.zero,
                        child: Text(
                          text,
                          style: TextStyle(
                            color: mine ? Colors.white : _Palette.ink,
                            fontSize: 14,
                            height: 1.3,
                          ),
                        ),
                      ),
                    const SizedBox(height: 3),
                    Padding(
                      padding: (imageUrl.isNotEmpty || localPath.isNotEmpty)
                          ? const EdgeInsets.symmetric(horizontal: 8)
                          : EdgeInsets.zero,
                      child: _buildMetaRow(
                        mine: mine,
                        time: time,
                        isTemp: isTemp && !isFailed,
                        isFailed: isFailed,
                        onRetry: isFailed
                            ? () => _retryMessage(msg)
                            : null,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          if (mine) const SizedBox(width: 6),
        ],
      ),
    );
  }

  Widget _buildMetaRow({
    required bool mine,
    required String time,
    required bool isTemp,
    required bool isFailed,
    VoidCallback? onRetry,
  }) {
    final color = mine
        ? (isFailed ? Colors.red.shade100 : Colors.white70)
        : (isFailed ? _Palette.danger : _Palette.inkMuted);

    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(
          isFailed ? 'Failed' : (isTemp ? 'Sending…' : time),
          style: TextStyle(
            color: color,
            fontSize: 12,
            fontStyle:
                (isTemp || isFailed) ? FontStyle.italic : FontStyle.normal,
          ),
        ),
        if (isTemp) ...[
          const SizedBox(width: 4),
          const SizedBox(
            width: 8,
            height: 8,
            child: CircularProgressIndicator(
                strokeWidth: 1.5, color: Colors.white70),
          ),
        ],
        if (isFailed) ...[
          const SizedBox(width: 4),
          GestureDetector(
            onTap: onRetry,
            child: Icon(Icons.refresh,
                size: 14,
                color: mine ? Colors.red.shade100 : _Palette.danger),
          ),
        ],
      ],
    );
  }

  Widget _buildLocalImage(String path, String status) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(12),
      child: Stack(
        alignment: Alignment.center,
        children: [
          Image.file(
            File(path),
            width: 200,
            fit: BoxFit.cover,
          ),
          if (status == 'sending')
            Container(
              width: 200,
              height: 120,
              color: Colors.black.withValues(alpha: 0.25),
              child: const Center(
                child: SizedBox(
                  width: 22,
                  height: 22,
                  child: CircularProgressIndicator(
                      color: Colors.white, strokeWidth: 2),
                ),
              ),
            ),
        ],
      ),
    );
  }

  /// Full-screen photo, pinch to zoom.
  void _openPhoto(String url) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => Scaffold(
          backgroundColor: Colors.black,
          appBar: AppBar(
            backgroundColor: Colors.black,
            foregroundColor: Colors.white,
            elevation: 0,
          ),
          body: Center(
            child: InteractiveViewer(
              minScale: 1,
              maxScale: 5,
              child: Image.network(url, fit: BoxFit.contain),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildRemoteImage(String url) {
    return GestureDetector(
      onTap: () => _openPhoto(url),
      child: _remoteImageBox(url),
    );
  }

  Widget _remoteImageBox(String url) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(12),
      child: Image.network(
        url,
        width: 200,
        fit: BoxFit.cover,
        loadingBuilder: (_, child, progress) {
          if (progress == null) return child;
          return Container(
            width: 200,
            height: 120,
            color: Colors.grey.shade200,
            child: const Center(
              child: SizedBox(
                width: 20,
                height: 20,
                child: CircularProgressIndicator(strokeWidth: 2),
              ),
            ),
          );
        },
        errorBuilder: (_, __, ___) => Container(
          width: 200,
          height: 120,
          color: Colors.grey.shade200,
          alignment: Alignment.center,
          child: const Icon(Icons.broken_image, color: _Palette.inkMuted),
        ),
      ),
    );
  }

  void _copyMessage(String text) {
    if (text.isEmpty) return;
    Clipboard.setData(ClipboardData(text: text));
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(
        SnackBar(
          content: Text(tr('Message copied')),
          duration: Duration(milliseconds: 900),
        ),
      );
  }

  // ============================================================
  // INPUT BAR
  // ============================================================
  Widget _buildInputBar() {
    final busy = _isSending || _isUploading;
    return SafeArea(
      top: false,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
        decoration: BoxDecoration(
          color: Colors.white,
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.05),
              blurRadius: 6,
              offset: const Offset(0, -2),
            ),
          ],
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            IconButton(
              onPressed: busy ? null : _sendImage,
              icon: _isUploading
                  ? const SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                  : const Icon(Icons.add_a_photo_outlined,
                      color: _Palette.ink, size: 24),
              tooltip: tr('Send a photo'),
            ),
            Expanded(
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 14),
                decoration: BoxDecoration(
                  color: _Palette.cream,
                  borderRadius: BorderRadius.circular(24),
                  border: Border.all(color: _Palette.divider),
                ),
                child: TextField(
                  controller: _messageCtrl,
                  focusNode: _focusNode,
                  textInputAction: TextInputAction.send,
                  keyboardType: TextInputType.text,
                  maxLines: 4,
                  minLines: 1,
                  onSubmitted: (_) => _sendMessage(),
                  decoration: InputDecoration(
                    hintText: tr('Type a message...'),
                    hintStyle: TextStyle(color: _Palette.inkMuted),
                    border: InputBorder.none,
                    contentPadding: EdgeInsets.symmetric(vertical: 12),
                  ),
                ),
              ),
            ),
            const SizedBox(width: 8),
            GestureDetector(
              onTap: busy ? null : _sendMessage,
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 150),
                width: 44,
                height: 44,
                decoration: BoxDecoration(
                  color: busy ? _Palette.blue.withValues(alpha: 0.6) : _Palette.blue,
                  shape: BoxShape.circle,
                  boxShadow: [
                    BoxShadow(
                      color: _Palette.blue.withValues(alpha: 0.35),
                      blurRadius: 8,
                      offset: const Offset(0, 3),
                    ),
                  ],
                ),
                child: busy
                    ? const Padding(
                        padding: EdgeInsets.all(12),
                        child: CircularProgressIndicator(
                            color: Colors.white, strokeWidth: 2),
                      )
                    : const Icon(Icons.send,
                        color: Colors.white, size: 20),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ============================================================
// TYPING DOTS
// ============================================================
class _TypingDots extends StatefulWidget {
  const _TypingDots();

  @override
  State<_TypingDots> createState() => _TypingDotsState();
}

class _TypingDotsState extends State<_TypingDots>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    )..repeat();
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _ctrl,
      builder: (_, __) {
        final v = _ctrl.value;
        return Row(
          mainAxisSize: MainAxisSize.min,
          children: List.generate(3, (i) {
            final phase = (v + i * 0.2) % 1.0;
            final scale = 0.6 + 0.6 * (1 - (phase - 0.5).abs() * 2);
            return Padding(
              padding: const EdgeInsets.symmetric(horizontal: 1.5),
              child: Transform.scale(
                scale: scale,
                child: Container(
                  width: 6,
                  height: 6,
                  decoration: const BoxDecoration(
                    color: _Palette.inkMuted,
                    shape: BoxShape.circle,
                  ),
                ),
              ),
            );
          }),
        );
      },
    );
  }
}
