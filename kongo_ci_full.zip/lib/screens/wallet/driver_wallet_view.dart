// lib/screens/wallet/driver_wallet_view.dart

import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:efuride_app/config/country_config.dart';
import 'package:efuride_app/config/efuride_palette.dart';
import 'package:efuride_app/services/wallet_service.dart';
import 'package:efuride_app/services/pricing_service.dart';
import 'package:efuride_app/widgets/wallet/wallet_status_badge.dart';
import 'package:efuride_app/widgets/wallet/payout_sheet.dart';
import 'package:efuride_app/widgets/wallet/topup_sheet.dart';
import 'package:efuride_app/utils/money.dart';
import 'package:efuride_app/utils/app_error.dart';
import 'package:efuride_app/utils/error_ui.dart';
import 'package:efuride_app/l10n/app_strings.dart';
import 'package:efuride_app/widgets/k_icon.dart';

class _Palette {
  static const cream = Color(0xFFFAF6EE);
  static const ink = Color(0xFF1A1A1A);
  static const inkMuted = Color(0xFF575047);
  static const accent = Color(0xFFF2B705);
  static const divider = Color(0xFFE8E2D5);
  static const blue = Color(0xFF1E88E5);
  static const pickup = Color(0xFF34C759);
  static const dropoff = Color(0xFFE53935);
}

class DriverWalletView extends StatefulWidget {
  const DriverWalletView({super.key});

  @override
  State<DriverWalletView> createState() => _DriverWalletViewState();
}

class _DriverWalletViewState extends State<DriverWalletView>
    with SingleTickerProviderStateMixin {
  late TabController _tabs;

  double _balance = 0;
  double _pending = 0;

  /// Server wallet (step 21). Null on an older database.
  MyWallet? _w;
  int _commissionPercent = 15;
  int _completedTrips = 0;

  bool _loading = true;
  AppError? _error;

  List<Map<String, dynamic>> _tx = [];
  List<Map<String, dynamic>> _payouts = [];
  List<Map<String, dynamic>> _earnings = [];

  @override
  void initState() {
    super.initState();
    _tabs = TabController(length: 3, vsync: this);
    _loadAll();
  }

  @override
  void dispose() {
    _tabs.dispose();
    super.dispose();
  }

  Future<void> _loadAll() async {
    setState(() {
      _loading = true;
      _error = null;
    });

    try {
      final user = Supabase.instance.client.auth.currentUser;
      if (user == null) throw Exception('Not signed in');

      // Commission — read once, default to 15% if it fails.
      try {
        _commissionPercent = await WalletService.getCommissionPercent();
      } catch (e) {
        debugPrint('commission read failed, defaulting to 15%: $e');
        _commissionPercent = 15;
      }
      // Commission is set per country by ko!ngo (admin → Pricing).
      try {
        final cp = await PricingService.current();
        if (cp.countryCode.isNotEmpty) {
          _commissionPercent = cp.driverCommissionPct.round();
        }
      } catch (_) {}

      try {
        _w = await WalletService.myWallet();
        _balance = _w!.balance;
        _pending = 0;
      } catch (_) {
        _w = null;
        final snapshot = await WalletService.getSnapshot(isDriver: true);
        _balance = snapshot.balance;
        _pending = snapshot.pending;
      }

      final trips = await Supabase.instance.client
          .from('rides')
          .select(
              'id, pickup_address, dropoff_address, fare, created_at, distance_km, '
              'driver_earning, payment_status, order_id')
          .eq('driver_id', user.id)
          .eq('status', 'completed')
          .order('created_at', ascending: false)
          .limit(30);

      _earnings = List<Map<String, dynamic>>.from(trips);

      // Real completed-trip count (not capped at 30).
      try {
        final count = await Supabase.instance.client
            .from('rides')
            .count(CountOption.exact)
            .eq('driver_id', user.id)
            .eq('status', 'completed');
        _completedTrips = count;
      } catch (e) {
        debugPrint('trip count failed: $e');
        _completedTrips = _earnings.length;
      }

      final tx = await WalletService.listTransactions();
      final payouts = await WalletService.listMyPayouts();

      if (!mounted) return;
      setState(() {
        _tx = tx;
        _payouts = payouts;
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _error = AppError.from(e, onRetry: _loadAll);
      });
    }
  }

  // ============================================================
  // PAYOUT
  // ============================================================
  Future<void> _openPayoutSheet() async {
    final available = _w?.available ?? (_balance + _pending);
    final sent = await showPayoutSheet(context, available);
    if (sent) _loadAll();
  }

  // ============================================================
  // BUILD — plain page, same style as the customer wallet:
  // balance card + "Request payout", then payouts and trip earnings.
  // ============================================================
  @override
  Widget build(BuildContext context) {
    final available = _w?.available ?? (_balance + _pending);
    final waiting = _payouts
        .where((p) =>
            (p['status'] ?? 'pending').toString().toLowerCase() == 'pending')
        .toList();
    final multiplier = WalletService.commissionMultiplier(_commissionPercent);

    return Scaffold(
      backgroundColor: EfuridePalette.cream,
      appBar: AppBar(
        backgroundColor: EfuridePalette.cream,
        foregroundColor: EfuridePalette.ink,
        elevation: 0,
        scrolledUnderElevation: 0,
        title: Text(tr('Wallet & payouts'),
            style: const TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.w800,
                color: EfuridePalette.ink)),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _error != null
              ? ErrorUI.inline(_error!)
              : RefreshIndicator(
                  onRefresh: _loadAll,
                  child: ListView(
                    physics: const AlwaysScrollableScrollPhysics(),
                    padding: const EdgeInsets.fromLTRB(16, 4, 16, 28),
                    children: [
                      _balanceCard(available),
                      if (waiting.isNotEmpty) ...[
                        _sectionTitle(tr('Payouts on the way')),
                        for (final p in waiting) _payoutRow(p),
                      ],
                      _sectionTitle(tr('Trip earnings')),
                      if (_earnings.isEmpty)
                        _emptyBox(tr('Completed trips and what you earned on each will show here.'))
                      else
                        for (final t in _earnings) _earningRow(t, multiplier),
                      if (_payouts.length > waiting.length) ...[
                        _sectionTitle(tr('Past payouts')),
                        for (final p in _payouts)
                          if (!waiting.contains(p)) _payoutRow(p),
                      ],
                      if (_tx.isNotEmpty) ...[
                        _sectionTitle(tr('Activity')),
                        for (final t in _tx) _txRow(t),
                      ],
                    ],
                  ),
                ),
    );
  }

  Widget _balanceCard(double available) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: EfuridePalette.divider),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(tr('Available to withdraw'),
              style: const TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.w600,
                  color: EfuridePalette.inkMuted)),
          const SizedBox(height: 4),
          FittedBox(
            fit: BoxFit.scaleDown,
            alignment: Alignment.centerLeft,
            child: Text(fmtMoney(available),
                style: const TextStyle(
                    fontSize: 36,
                    fontWeight: FontWeight.w900,
                    color: EfuridePalette.ink)),
          ),
          const SizedBox(height: 6),
          Text(
            _w != null
                ? tr('Wallet {0} · Waiting payouts {1}',
                    [fmtMoney(_w!.balance), fmtMoney(_w!.held)])
                : tr('Wallet {0} · Unpaid trips {1}',
                    [fmtMoney(_balance), fmtMoney(_pending)]),
            style: const TextStyle(
                fontSize: 14.5, color: EfuridePalette.inkMuted),
          ),
          if ((_w?.owed ?? 0) > 0) ...[
            const SizedBox(height: 8),
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: const Color(0xFFFDE8E8),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Text(
                tr('You owe ko!ngo {0} from cash you collected. It comes off your next earnings, or pay it at a ko!ngo office.',
                    [fmtMoney(_w!.owed)]),
                style: const TextStyle(
                    fontSize: 13.5,
                    color: Color(0xFFB91C1C),
                    fontWeight: FontWeight.w600),
              ),
            ),
          ],
          const SizedBox(height: 2),
          Text(
            tr('ko!ngo fee {0}% · {1} completed trips',
                ['$_commissionPercent', '$_completedTrips']),
            style: const TextStyle(
                fontSize: 14.5, color: EfuridePalette.inkMuted),
          ),
          if (available < PricingService.last.lowBalanceLevel) ...[
            const SizedBox(height: 10),
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: const Color(0xFFFEF3C7),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Icon(Icons.warning_amber_rounded,
                      size: 20, color: Color(0xFFB45309)),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      tr('Your balance is low. Top up so you can keep working without interruption.'),
                      style: const TextStyle(
                          fontSize: 13.5,
                          color: Color(0xFF92400E),
                          fontWeight: FontWeight.w600),
                    ),
                  ),
                ],
              ),
            ),
          ],
          const SizedBox(height: 16),
          SizedBox(
            width: double.infinity,
            child: OutlinedButton.icon(
              onPressed: () async {
                final sent = await showTopupSheet(context);
                if (sent && mounted) _loadAll();
              },
              icon: const Icon(Icons.add),
              label: Text(tr('Top up'),
                  style: const TextStyle(
                      fontSize: 17, fontWeight: FontWeight.w800)),
              style: OutlinedButton.styleFrom(
                foregroundColor: EfuridePalette.ink,
                minimumSize: const Size(0, 52),
                side: const BorderSide(color: EfuridePalette.accent, width: 1.6),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14)),
              ),
            ),
          ),
          const SizedBox(height: 10),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: _openPayoutSheet,
              icon: const KIcon(Icons.account_balance),
              label: Text(tr('Request payout'),
                  style: const TextStyle(
                      fontSize: 17, fontWeight: FontWeight.w800)),
              style: ElevatedButton.styleFrom(
                backgroundColor: EfuridePalette.accent,
                foregroundColor: EfuridePalette.accentInk,
                minimumSize: const Size(0, 52),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14)),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _sectionTitle(String text) => Padding(
        padding: const EdgeInsets.fromLTRB(4, 20, 4, 8),
        child: Text(text,
            style: const TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w800,
                color: EfuridePalette.ink)),
      );

  Widget _emptyBox(String text) => Container(
        padding: const EdgeInsets.all(22),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: EfuridePalette.divider),
        ),
        child: Text(text,
            textAlign: TextAlign.center,
            style:
                const TextStyle(fontSize: 15, color: EfuridePalette.inkMuted)),
      );

  Widget _row({
    required IconData icon,
    required String title,
    required String subtitle,
    required Widget trailing,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: EfuridePalette.divider),
      ),
      child: Row(
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: EfuridePalette.greyBg,
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(icon, color: EfuridePalette.ink, size: 22),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                        fontSize: 15.5, fontWeight: FontWeight.w700)),
                const SizedBox(height: 2),
                Text(subtitle,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                        fontSize: 14, color: EfuridePalette.inkMuted)),
              ],
            ),
          ),
          const SizedBox(width: 8),
          trailing,
        ],
      ),
    );
  }

  Widget _earningRow(Map<String, dynamic> t, double multiplier) {
    final fare = (t['fare'] as num?)?.toDouble() ?? 0;
    final earned =
        (t['driver_earning'] as num?)?.toDouble() ?? fare * multiplier;
    final cash = (t['payment_status'] ?? '') == 'cash';
    final km = (t['distance_km'] as num?)?.toDouble();
    String short(String s) {
      final parts = s
          .split(RegExp(r'[,·]'))
          .map((p) => p.trim())
          .where((p) => p.isNotEmpty && !RegExp(r'^-?\d+(\.\d+)?$').hasMatch(p))
          .toList();
      return parts.isEmpty ? tr('Pinned location') : parts.first;
    }

    return _row(
      icon: Icons.local_taxi_outlined,
      title: '${short((t['pickup_address'] ?? '').toString())} → '
          '${short((t['dropoff_address'] ?? '').toString())}',
      subtitle: '${fmtDate(t['created_at'])}'
          '${km != null && km > 0 ? '  ·  ${km.toStringAsFixed(1)} km' : ''}'
          '${cash ? '  ·  ${tr('Cash')}' : ''}',
      trailing: Text('+${fmtMoney(earned)}',
          style: const TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w800,
              color: Color(0xFF15803D))),
    );
  }

  Widget _payoutRow(Map<String, dynamic> p) {
    return _row(
      icon: Icons.account_balance_outlined,
      title: fmtMoney((p['amount'] as num?)?.toDouble() ?? 0),
      subtitle: [
        (p['bank_name'] ?? '').toString(),
        fmtDate(p['created_at']),
      ].where((x) => x.isNotEmpty).join(' · '),
      trailing:
          WalletStatusBadge(status: (p['status'] ?? 'pending').toString()),
    );
  }

  Widget _txRow(Map<String, dynamic> t) {
    final amt = (t['amount'] as num?)?.toDouble() ?? 0;
    final credit = amt >= 0;
    final notes = (t['notes'] ?? '').toString().toLowerCase();
    final ref = (t['reference'] ?? '').toString().toLowerCase();
    final title = notes.startsWith('[earning]')
        ? (credit ? tr('Trip earnings') : tr('Cash you kept'))
        : notes.contains('payout') || ref.contains('payout')
        ? tr('Payout')
        : notes.contains('tip')
            ? tr('Tip')
            : notes.contains('bonus')
                ? tr('Bonus')
                : credit
                    ? tr('Credit')
                    : tr('Deduction');
    return _row(
      icon: credit ? Icons.add_circle_outline : Icons.remove_circle_outline,
      title: title,
      subtitle: notes.startsWith('[')
          ? '${fmtDate(t['created_at'])} · ${WalletService.lineText(t)}'
          : fmtDate(t['created_at']),
      trailing: Text(
        '${credit ? '+' : ''}${fmtMoney(amt)}',
        style: TextStyle(
          fontSize: 16,
          fontWeight: FontWeight.w800,
          color: credit ? const Color(0xFF15803D) : EfuridePalette.ink,
        ),
      ),
    );
  }
}
