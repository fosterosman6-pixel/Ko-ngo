// lib/screens/wallet/wallet_screen.dart

import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:efuride_app/screens/wallet/customer_wallet_view.dart';
import 'package:efuride_app/screens/wallet/driver_wallet_view.dart';
import 'package:efuride_app/utils/app_error.dart';
import 'package:efuride_app/utils/error_ui.dart';

class _Palette {
  static const cream = Color(0xFFFAF6EE);
  static const ink = Color(0xFF1A1A1A);
  static const accent = Color(0xFFF2B705);
}

class WalletScreen extends StatefulWidget {
  const WalletScreen({super.key});

  @override
  State<WalletScreen> createState() => _WalletScreenState();
}

class _WalletScreenState extends State<WalletScreen>
    with WidgetsBindingObserver {
  String _role = 'Customer';
  bool _loading = true;
  AppError? _error;
  DateTime? _lastResolve;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _resolveRole();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state != AppLifecycleState.resumed) return;
    // Throttle: don't hit the server more than once every 60 s.
    final last = _lastResolve;
    if (last != null &&
        DateTime.now().difference(last).inSeconds < 60) {
      return;
    }
    _resolveRole(silent: true);
  }

  Future<void> _resolveRole({bool silent = false}) async {
    if (!silent) {
      setState(() {
        _loading = true;
        _error = null;
      });
    }

    try {
      final user = Supabase.instance.client.auth.currentUser;
      if (user == null) {
        if (mounted) {
          setState(() {
            _role = 'Customer';
            _loading = false;
          });
        }
        return;
      }

      final p = await Supabase.instance.client
          .from('profiles')
          .select('role')
          .eq('id', user.id)
          .maybeSingle()
          .timeout(const Duration(seconds: 8));

      if (!mounted) return;
      _lastResolve = DateTime.now();
      setState(() {
        _role = (p?['role'] ?? 'Customer').toString();
        _loading = false;
        _error = null;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _error = AppError.from(e, onRetry: _resolveRole);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Scaffold(
        backgroundColor: _Palette.cream,
        body: Center(
          child: CircularProgressIndicator(color: _Palette.accent),
        ),
      );
    }

    // If the role fetch failed AND we have no value yet, show retry.
    if (_error != null) {
      return Scaffold(
        backgroundColor: _Palette.cream,
        body: ErrorUI.inline(_error!),
      );
    }

    final isDriver = _role.toLowerCase() == 'driver';

    // Key by role so the child view is rebuilt fresh when role changes.
    return KeyedSubtree(
      key: ValueKey('wallet_view_$isDriver'),
      child: isDriver
          ? const DriverWalletView()
          : const CustomerWalletView(),
    );
  }
}
