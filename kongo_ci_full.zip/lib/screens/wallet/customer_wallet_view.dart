// lib/screens/wallet/customer_wallet_view.dart
//
// Customer wallet (opened from Profile). Plain and readable:
//   • balance card with one "Top up" button
//   • top-ups waiting for ko!ngo's approval
//   • all wallet activity in one list, with clear names
//     ("Order payment", "Top-up", "Refund") instead of raw types.

import 'package:flutter/material.dart';

import 'package:efuride_app/config/country_config.dart';
import 'package:efuride_app/config/efuride_palette.dart';
import 'package:efuride_app/l10n/app_strings.dart';
import 'package:efuride_app/services/pricing_service.dart';
import 'package:efuride_app/services/wallet_service.dart';
import 'package:efuride_app/utils/app_error.dart';
import 'package:efuride_app/utils/error_ui.dart';
import 'package:efuride_app/utils/money.dart';
import 'package:efuride_app/widgets/wallet/wallet_status_badge.dart';

class CustomerWalletView extends StatefulWidget {
  const CustomerWalletView({super.key});

  @override
  State<CustomerWalletView> createState() => _CustomerWalletViewState();
}

class _CustomerWalletViewState extends State<CustomerWalletView> {
  double _balance = 0;
  bool _loading = true;
  AppError? _error;
  List<Map<String, dynamic>> _tx = [];
  List<Map<String, dynamic>> _topups = [];

  @override
  void initState() {
    super.initState();
    _loadAll();
  }

  Future<void> _loadAll() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final res = await Future.wait([
        WalletService.getSnapshot(isDriver: false),
        WalletService.listTransactions(),
        WalletService.listMyTopups(),
        PricingService.current(),
      ]);
      if (!mounted) return;
      setState(() {
        _balance = (res[0] as WalletSnapshot).balance;
        _tx = res[1] as List<Map<String, dynamic>>;
        _topups = res[2] as List<Map<String, dynamic>>;
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _error = AppError.from(e, onRetry: _loadAll);
      });
    }
  }

  List<Map<String, dynamic>> get _waiting => _topups
      .where((t) =>
          (t['status'] ?? 'pending').toString().toLowerCase() == 'pending')
      .toList();

  double get _waitingTotal => _waiting.fold<double>(
      0, (s, t) => s + ((t['amount'] as num?)?.toDouble() ?? 0));

  /// Friendly name for a wallet line.
  (String, IconData) _describe(Map<String, dynamic> t) {
    final amt = (t['amount'] as num?)?.toDouble() ?? 0;
    final ref = (t['reference'] ?? '').toString().toLowerCase();
    final notes = (t['notes'] ?? '').toString().toLowerCase();
    final type = (t['type'] ?? '').toString().toLowerCase();
    if (ref.startsWith('order:')) {
      return (tr('Order payment'), Icons.shopping_bag_outlined);
    }
    if (ref.startsWith('ride:') || notes.contains('ride')) {
      return (tr('Ride payment'), Icons.local_taxi_outlined);
    }
    if (notes.contains('refund') || ref.contains('refund')) {
      return (tr('Refund'), Icons.undo);
    }
    if (notes.contains('bonus') || notes.contains('referral')) {
      return (tr('Bonus'), Icons.card_giftcard);
    }
    if (type == 'topup' || amt > 0) {
      return (tr('Top-up'), Icons.add_circle_outline);
    }
    return (tr('Payment'), Icons.remove_circle_outline);
  }

  // ============================================================
  // TOP UP
  // ============================================================
  /// Quick amounts that make sense in this country's currency.
  List<double> get _quickAmounts {
    final base = PricingService.last.minimumFare;
    double nice(double v) {
      if (v >= 1000) return (v / 500).round() * 500;
      if (v >= 100) return (v / 50).round() * 50;
      if (v >= 10) return (v / 10).round() * 10;
      return v.roundToDouble().clamp(1, double.infinity);
    }

    final out = <double>{
      for (final m in [2, 4, 8, 20]) nice(base * m),
    }.toList()
      ..sort();
    return out;
  }

  Future<void> _openTopupSheet() async {
    final amountCtrl = TextEditingController();
    final refCtrl = TextEditingController();
    // Ways to pay in this country (admin app → Pricing → Top-up methods).
    final methods = PricingService.last.topupMethods.isNotEmpty
        ? PricingService.last.topupMethods
        : CountryPricing.fallback.topupMethods;
    var method = methods.first.id;
    TopupMethod picked() =>
        methods.firstWhere((m) => m.id == method, orElse: () => methods.first);

    try {
      final ok = await showModalBottomSheet<bool>(
        context: context,
        isScrollControlled: true,
        backgroundColor: Colors.white,
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
        ),
        builder: (ctx) => StatefulBuilder(
          builder: (ctx, setS) => Padding(
            padding: EdgeInsets.fromLTRB(
                20, 20, 20, MediaQuery.of(ctx).viewInsets.bottom + 20),
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Text(tr('Top up your wallet'),
                      style: const TextStyle(
                          fontSize: 21, fontWeight: FontWeight.w800)),
                  const SizedBox(height: 6),
                  Text(
                    tr('Pay ko!ngo with one of the methods below, then send this request. Your balance goes up when ko!ngo confirms the payment.'),
                    style: const TextStyle(
                        fontSize: 15, height: 1.4, color: EfuridePalette.inkMuted),
                  ),
                  const SizedBox(height: 16),
                  TextField(
                    controller: amountCtrl,
                    autofocus: true,
                    keyboardType:
                        const TextInputType.numberWithOptions(decimal: true),
                    style: const TextStyle(
                        fontSize: 22, fontWeight: FontWeight.w800),
                    decoration: InputDecoration(
                      labelText: tr('Amount'),
                      prefixText: '${CountryConfig.symbol} ',
                      filled: true,
                      fillColor: EfuridePalette.greyBg,
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: BorderSide.none,
                      ),
                    ),
                  ),
                  const SizedBox(height: 10),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: [
                      for (final a in _quickAmounts)
                        ActionChip(
                          label: Text(CountryConfig.money(a),
                              style: const TextStyle(
                                  fontSize: 15, fontWeight: FontWeight.w700)),
                          onPressed: () => setS(() => amountCtrl.text =
                              a == a.roundToDouble()
                                  ? a.toStringAsFixed(0)
                                  : a.toString()),
                        ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  Text(tr('How did you pay?'),
                      style: const TextStyle(
                          fontSize: 15, fontWeight: FontWeight.w700)),
                  const SizedBox(height: 8),
                  for (final m in methods)
                    Padding(
                      padding: const EdgeInsets.only(bottom: 8),
                      child: Material(
                        color: method == m.id
                            ? EfuridePalette.accent.withValues(alpha: 0.12)
                            : Colors.white,
                        borderRadius: BorderRadius.circular(12),
                        child: InkWell(
                          borderRadius: BorderRadius.circular(12),
                          onTap: () => setS(() => method = m.id),
                          child: Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 14, vertical: 14),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(
                                color: method == m.id
                                    ? EfuridePalette.accent
                                    : EfuridePalette.divider,
                                width: method == m.id ? 1.6 : 1,
                              ),
                            ),
                            child: Row(children: [
                              Icon(_methodIcon(m), color: EfuridePalette.ink),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Text(tr(m.name),
                                    style: const TextStyle(
                                        fontSize: 16,
                                        fontWeight: FontWeight.w700)),
                              ),
                              Icon(
                                method == m.id
                                    ? Icons.radio_button_checked
                                    : Icons.radio_button_off,
                                color: method == m.id
                                    ? EfuridePalette.ink
                                    : EfuridePalette.inkMuted,
                              ),
                            ]),
                          ),
                        ),
                      ),
                    ),
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: EfuridePalette.greyBg,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Icon(Icons.info_outline,
                            size: 20, color: EfuridePalette.inkMuted),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Text(
                            picked().details.isNotEmpty
                                ? tr('Pay to: {0}', [picked().details])
                                : tr('Contact ko!ngo support for the {0} payment details.',
                                    [tr(picked().name)]),
                            style: const TextStyle(
                                fontSize: 15, height: 1.35),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: refCtrl,
                    style: const TextStyle(fontSize: 16),
                    decoration: InputDecoration(
                      labelText: picked().isMobileMoney
                          ? tr('Transaction code (from the SMS)')
                          : tr('Payment reference (optional)'),
                      filled: true,
                      fillColor: EfuridePalette.greyBg,
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: BorderSide.none,
                      ),
                    ),
                  ),
                  const SizedBox(height: 18),
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: EfuridePalette.accent,
                      foregroundColor: EfuridePalette.accentInk,
                      minimumSize: const Size(0, 54),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(14)),
                    ),
                    onPressed: () {
                      final amt = double.tryParse(
                              amountCtrl.text.trim().replaceAll(',', '.')) ??
                          0;
                      if (amt <= 0) return;
                      Navigator.pop(ctx, true);
                    },
                    child: Text(tr('Send top-up request'),
                        style: const TextStyle(
                            fontSize: 17, fontWeight: FontWeight.w900)),
                  ),
                ],
              ),
            ),
          ),
        ),
      );

      if (ok != true) return;
      final amount =
          double.tryParse(amountCtrl.text.trim().replaceAll(',', '.')) ?? 0;
      if (amount <= 0) return;

      final result = await WalletService.requestTopup(
        amount: amount,
        method: method,
        reference: refCtrl.text.trim().isEmpty ? null : refCtrl.text.trim(),
      );
      if (!mounted) return;
      ErrorUI.showSnack(
        context,
        result.success
            ? AppError(
                title: tr('Top-up request sent'),
                message: tr('Your balance goes up when ko!ngo confirms it.'),
                icon: Icons.check_circle_outline,
              )
            : AppError(
                title: tr('Couldn\'t send request'),
                message: result.message ?? tr('Please try again in a moment.'),
                icon: Icons.error_outline,
              ),
      );
      if (result.success) _loadAll();
    } finally {
      amountCtrl.dispose();
      refCtrl.dispose();
    }
  }

  // ============================================================
  // BUILD
  // ============================================================
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: EfuridePalette.cream,
      appBar: AppBar(
        backgroundColor: EfuridePalette.cream,
        foregroundColor: EfuridePalette.ink,
        elevation: 0,
        scrolledUnderElevation: 0,
        title: Text(tr('Wallet'),
            style: const TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.w800,
                color: EfuridePalette.ink)),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _error != null
              ? ErrorUI.inline(_error!)
              : RefreshIndicator(
                  onRefresh: _loadAll,
                  child: ListView(
                    physics: const AlwaysScrollableScrollPhysics(),
                    padding: const EdgeInsets.fromLTRB(16, 4, 16, 28),
                    children: [
                      _balanceCard(),
                      if (_waiting.isNotEmpty) ...[
                        const SizedBox(height: 20),
                        _sectionTitle(tr('Waiting for approval')),
                        for (final t in _waiting) _topupRow(t),
                      ],
                      const SizedBox(height: 20),
                      _sectionTitle(tr('Activity')),
                      if (_tx.isEmpty)
                        _emptyActivity()
                      else
                        for (final t in _tx) _txRow(t),
                    ],
                  ),
                ),
    );
  }

  Widget _balanceCard() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: EfuridePalette.divider),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(tr('Available balance'),
              style: const TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.w600,
                  color: EfuridePalette.inkMuted)),
          const SizedBox(height: 4),
          FittedBox(
            fit: BoxFit.scaleDown,
            alignment: Alignment.centerLeft,
            child: Text(fmtMoney(_balance),
                style: const TextStyle(
                    fontSize: 36,
                    fontWeight: FontWeight.w900,
                    color: EfuridePalette.ink)),
          ),
          if (_waitingTotal > 0) ...[
            const SizedBox(height: 4),
            Text(
              tr('{0} waiting for approval', [fmtMoney(_waitingTotal)]),
              style: const TextStyle(
                  fontSize: 14.5,
                  fontWeight: FontWeight.w600,
                  color: Color(0xFFB45309)),
            ),
          ] else if (_balance == 0) ...[
            const SizedBox(height: 4),
            Text(tr('Add money to pay for rides and orders without cash.'),
                style: const TextStyle(
                    fontSize: 14.5, color: EfuridePalette.inkMuted)),
          ],
          const SizedBox(height: 16),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: _openTopupSheet,
              icon: const Icon(Icons.add),
              label: Text(tr('Top up'),
                  style: const TextStyle(
                      fontSize: 17, fontWeight: FontWeight.w800)),
              style: ElevatedButton.styleFrom(
                backgroundColor: EfuridePalette.accent,
                foregroundColor: EfuridePalette.accentInk,
                minimumSize: const Size(0, 52),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14)),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _sectionTitle(String text) => Padding(
        padding: const EdgeInsets.only(left: 4, bottom: 8),
        child: Text(text,
            style: const TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w800,
                color: EfuridePalette.ink)),
      );

  Widget _emptyActivity() => Container(
        padding: const EdgeInsets.all(22),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: EfuridePalette.divider),
        ),
        child: Text(
          tr('Payments, top-ups and refunds will show here.'),
          textAlign: TextAlign.center,
          style: const TextStyle(fontSize: 15, color: EfuridePalette.inkMuted),
        ),
      );

  Widget _row({
    required IconData icon,
    required String title,
    required String subtitle,
    required Widget trailing,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: EfuridePalette.divider),
      ),
      child: Row(
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: EfuridePalette.greyBg,
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(icon, color: EfuridePalette.ink, size: 22),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title,
                    style: const TextStyle(
                        fontSize: 15.5, fontWeight: FontWeight.w700)),
                const SizedBox(height: 2),
                Text(subtitle,
                    style: const TextStyle(
                        fontSize: 14, color: EfuridePalette.inkMuted)),
              ],
            ),
          ),
          trailing,
        ],
      ),
    );
  }

  Widget _txRow(Map<String, dynamic> t) {
    final amt = (t['amount'] as num?)?.toDouble() ?? 0;
    final credit = amt >= 0;
    final (title, icon) = _describe(t);
    return _row(
      icon: icon,
      title: title,
      subtitle: fmtDate(t['created_at']),
      trailing: Text(
        '${credit ? '+' : ''}${fmtMoney(amt)}',
        style: TextStyle(
          fontSize: 16,
          fontWeight: FontWeight.w800,
          color: credit ? const Color(0xFF15803D) : EfuridePalette.ink,
        ),
      ),
    );
  }

  IconData _methodIcon(TopupMethod m) {
    switch (m.id) {
      case 'eft':
      case 'bank':
        return Icons.account_balance;
      case 'cash':
        return Icons.payments_outlined;
      case 'snapscan':
        return Icons.qr_code_2;
      case 'card':
        return Icons.credit_card;
      default:
        return Icons.phone_android; // mobile money
    }
  }

  Widget _topupRow(Map<String, dynamic> t) {
    final id = (t['method'] ?? '').toString();
    final known = [
      ...PricingService.last.topupMethods,
      ...CountryPricing.fallback.topupMethods,
    ].where((m) => m.id == id);
    final method = known.isNotEmpty ? tr(known.first.name) : id;
    return _row(
      icon: Icons.hourglass_top,
      title: fmtMoney((t['amount'] as num?)?.toDouble() ?? 0),
      subtitle: '$method · ${fmtDate(t['created_at'])}',
      trailing:
          WalletStatusBadge(status: (t['status'] ?? 'pending').toString()),
    );
  }
}
