// lib/screens/driver/driver_training_screen.dart

import 'package:flutter/material.dart';
import 'package:efuride_app/config/app_images.dart';
import 'package:efuride_app/widgets/app_image.dart';
import 'package:efuride_app/services/training_service.dart';
import 'package:efuride_app/screens/driver/training_module_screen.dart';
import 'package:efuride_app/utils/app_error.dart';
import 'package:efuride_app/utils/error_ui.dart';
import 'package:efuride_app/l10n/app_strings.dart';
import 'package:efuride_app/widgets/k_icon.dart';

class _Palette {
  static const cream = Color(0xFFFAF6EE);
  static const ink = Color(0xFF1A1A1A);
  static const inkMuted = Color(0xFF575047);
  static const accent = Color(0xFFF2B705);
  static const accentInk = Color(0xFF0B1220);
  static const divider = Color(0xFFE8E2D5);
  static const blue = Color(0xFF1E88E5);
  static const pickup = Color(0xFF34C759);
  static const dropoff = Color(0xFFE53935);
}

class DriverTrainingScreen extends StatefulWidget {
  /// If true, this is being shown as a hard gate during onboarding.
  /// The back button will be hidden and completing all modules
  /// returns `true` to the caller.
  final bool isOnboardingGate;

  const DriverTrainingScreen({super.key, this.isOnboardingGate = false});

  @override
  State<DriverTrainingScreen> createState() => _DriverTrainingScreenState();
}

class _DriverTrainingScreenState extends State<DriverTrainingScreen> {
  TrainingSnapshot? _snapshot;
  bool _isLoading = true;
  AppError? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _isLoading = true;
      _error = null;
    });
    try {
      final snap = await TrainingService.instance.load();
      if (!mounted) return;
      setState(() {
        _snapshot = snap;
        _isLoading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _isLoading = false;
        _error = AppError.from(e, onRetry: _load);
      });
    }
  }

  Future<void> _openModule(TrainingModule m) async {
    await Navigator.push<bool>(
      context,
      MaterialPageRoute(
        builder: (_) => TrainingModuleScreen(module: m),
      ),
    );
    // Reload progress when returning
    await _load();
  }

  @override
  Widget build(BuildContext context) {
    final snap = _snapshot;

    return PopScope(
      canPop: !widget.isOnboardingGate ||
          (snap?.isCertified ?? false),
      child: Scaffold(
        backgroundColor: _Palette.cream,
        appBar: AppBar(
          backgroundColor: _Palette.cream,
          elevation: 0,
          automaticallyImplyLeading: !widget.isOnboardingGate,
          iconTheme: const IconThemeData(color: _Palette.ink),
          title: Text(
            tr('Driver Academy'),
            style: TextStyle(
              color: _Palette.ink,
              fontWeight: FontWeight.bold,
              fontSize: 18,
            ),
          ),
        ),
        body: _isLoading
            ? const Center(
                child:
                    CircularProgressIndicator(color: _Palette.accent))
            : _error != null
                ? ErrorUI.inline(_error!)
                : _buildBody(snap!),
      ),
    );
  }

  Widget _buildBody(TrainingSnapshot snap) {
    final required =
        snap.modules.where((m) => m.isRequired).toList();
    final recommended =
        snap.modules.where((m) => !m.isRequired).toList();

    return SafeArea(
      child: RefreshIndicator(
        onRefresh: _load,
        color: _Palette.accent,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
          physics: const AlwaysScrollableScrollPhysics(),
          children: [
            _headerCard(snap),
            const SizedBox(height: 20),

            if (required.isNotEmpty) ...[
              _sectionLabel(tr('Required')),
              const SizedBox(height: 8),
              ...required.map((m) => Padding(
                    padding: const EdgeInsets.only(bottom: 8),
                    child: _moduleTile(m, snap.progressFor(m.id)),
                  )),
              const SizedBox(height: 20),
            ],

            if (recommended.isNotEmpty) ...[
              _sectionLabel(tr('Recommended')),
              const SizedBox(height: 8),
              ...recommended.map((m) => Padding(
                    padding: const EdgeInsets.only(bottom: 8),
                    child: _moduleTile(m, snap.progressFor(m.id)),
                  )),
              const SizedBox(height: 20),
            ],

            _certificateCard(snap),
          ],
        ),
      ),
    );
  }

  Widget _headerCard(TrainingSnapshot snap) {
    final done = snap.requiredCompleted;
    final total = snap.requiredTotal;
    final pct = snap.progressFraction;

    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: const Color(0xFFFDF5DA),
        border: Border.all(color: const Color(0xFFF2D27A)),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: _Palette.ink.withValues(alpha: 0.06),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: const KIcon(Icons.school_outlined,
                    color: _Palette.ink, size: 22),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  tr('Welcome to ko!ngo Academy'),
                  style: TextStyle(
                    color: _Palette.ink,
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Text(
            snap.isCertified
                ? tr('You\'re certified. Happy driving!')
                : tr('Complete all required modules to go online.'),
            style: const TextStyle(
              color: _Palette.inkMuted,
              fontSize: 14,
              height: 1.4,
            ),
          ),
          const SizedBox(height: 16),
          ClipRRect(
            borderRadius: BorderRadius.circular(6),
            child: LinearProgressIndicator(
              value: pct,
              minHeight: 8,
              backgroundColor: _Palette.ink.withValues(alpha: 0.06),
              valueColor:
                  const AlwaysStoppedAnimation<Color>(_Palette.accent),
            ),
          ),
          const SizedBox(height: 10),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                tr('{0} of {1} modules complete', [done, total]),
                style: const TextStyle(
                  color: _Palette.ink,
                  fontSize: 13.5,
                  fontWeight: FontWeight.w600,
                ),
              ),
              Text(
                '${(pct * 100).round()}%',
                style: const TextStyle(
                  color: _Palette.ink,
                  fontSize: 13.5,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _sectionLabel(String text) {
    return Padding(
      padding: const EdgeInsets.only(left: 4),
      child: Text(
        text.toUpperCase(),
        style: const TextStyle(
          fontSize: 13,
          fontWeight: FontWeight.w700,
          letterSpacing: 0.8,
          color: _Palette.inkMuted,
        ),
      ),
    );
  }

  Widget _moduleTile(TrainingModule m, TrainingProgress? p) {
    final isCompleted = p?.status == 'completed';
    final isInProgress = p?.status == 'in_progress';

    Color iconColor;
    IconData icon;
    if (isCompleted) {
      iconColor = _Palette.pickup;
      icon = Icons.check_circle;
    } else if (isInProgress) {
      iconColor = _Palette.accent;
      icon = Icons.play_circle_outline;
    } else {
      iconColor = _Palette.inkMuted;
      icon = Icons.play_circle_outline;
    }

    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: () => _openModule(m),
        borderRadius: BorderRadius.circular(14),
        child: Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(
              color: isCompleted
                  ? _Palette.pickup.withValues(alpha: 0.4)
                  : _Palette.divider,
              width: isCompleted ? 1.4 : 1,
            ),
          ),
          child: Row(
            children: [
              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  color: iconColor.withValues(alpha: 0.12),
                  shape: BoxShape.circle,
                ),
                child: Icon(icon, color: iconColor, size: 22),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      m.title,
                      style: const TextStyle(
                        fontSize: 14.5,
                        fontWeight: FontWeight.w700,
                        color: _Palette.ink,
                      ),
                    ),
                    if (m.description != null &&
                        m.description!.isNotEmpty) ...[
                      const SizedBox(height: 2),
                      Text(
                        m.description!,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          fontSize: 13.5,
                          color: _Palette.inkMuted,
                          height: 1.3,
                        ),
                      ),
                    ],
                    const SizedBox(height: 6),
                    Row(
                      children: [
                        const KIcon(Icons.schedule,
                            size: 12, color: _Palette.inkMuted),
                        const SizedBox(width: 4),
                        Text(
                          tr('{0} min', [m.durationMinutes]),
                          style: const TextStyle(
                            fontSize: 13,
                            color: _Palette.inkMuted,
                          ),
                        ),
                        if (isCompleted &&
                            p?.quizScore != null) ...[
                          const SizedBox(width: 12),
                          const Icon(Icons.star,
                              size: 12, color: _Palette.accent),
                          const SizedBox(width: 4),
                          Text(
                            '${p!.quizScore}%',
                            style: const TextStyle(
                              fontSize: 13,
                              fontWeight: FontWeight.w700,
                              color: _Palette.accent,
                            ),
                          ),
                        ],
                      ],
                    ),
                  ],
                ),
              ),
              const Icon(Icons.chevron_right,
                  color: _Palette.inkMuted, size: 22),
            ],
          ),
        ),
      ),
    );
  }

  Widget _certificateCard(TrainingSnapshot snap) {
    final certified = snap.isCertified;
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: certified
            ? _Palette.accent.withValues(alpha: 0.10)
            : _Palette.cream,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: certified
              ? _Palette.accent.withValues(alpha: 0.5)
              : _Palette.divider,
          width: certified ? 1.5 : 1,
        ),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: certified
                  ? _Palette.accent.withValues(alpha: 0.20)
                  : Colors.white,
              shape: BoxShape.circle,
            ),
            child: Icon(
              certified ? Icons.workspace_premium : Icons.lock_outline,
              color: certified ? _Palette.accent : _Palette.inkMuted,
              size: 24,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  certified
                      ? tr('Certificate of completion')
                      : tr('Certificate locked'),
                  style: const TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                    color: _Palette.ink,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  certified
                      ? tr('You have completed all required training.')
                      : tr('Complete all required modules to unlock.'),
                  style: const TextStyle(
                    fontSize: 13.5,
                    color: _Palette.inkMuted,
                    height: 1.3,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
