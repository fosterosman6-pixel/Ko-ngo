﻿// lib/screens/driver/active_trip_execution_screen.dart
//
// Driver-side active trip. Drives the pickup → in-progress → completed
// flow, tracks live customer location, verifies the pickup OTP, handles
// driver cancellation, and terminates at /trip_ended.
//
// Navigation: Google Maps, Waze, or ko!ngo in-app turn-by-turn (Google
// Routes). The driver's choice is remembered.
//
// Deliveries (parcel, food, grocery, pharmacy): once the driver reaches
// the drop-off, "Return" becomes available. A return sends the package
// to the nearest company office (status 'returning' → 'returned').
//
// i18n-clean · currency-clean · uses CountryConfig + S.

import 'dart:async';
import 'dart:math' as math;
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:geolocator/geolocator.dart';
import 'package:supabase_flutter/supabase_flutter.dart' hide MapType;
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';

import 'package:efuride_app/config/app_images.dart';
import 'package:efuride_app/config/country_config.dart';
import 'package:efuride_app/config/efuride_palette.dart';
import 'package:efuride_app/l10n/app_strings.dart';
import 'package:efuride_app/providers/ride_provider.dart';
import 'package:efuride_app/services/driver_location_service.dart';
import 'package:efuride_app/services/google_maps_service.dart';
import 'package:efuride_app/services/nav_voice.dart';
import 'package:efuride_app/services/road_reports_service.dart';
import 'package:efuride_app/services/notification_service.dart';
import 'package:efuride_app/utils/app_error.dart';
import 'package:efuride_app/utils/error_ui.dart';
import 'package:efuride_app/widgets/app_image.dart';
import 'package:efuride_app/services/connection_service.dart';
import 'package:efuride_app/services/call_service.dart';
import 'package:efuride_app/screens/shared/in_app_call_screen.dart';
import 'package:efuride_app/widgets/k_icon.dart';

class _Palette {
  static const cream = Color(0xFFFAF6EE);
  static const ink = Color(0xFF1A1A1A);
  static const inkMuted = Color(0xFF575047);
  static const accent = Color(0xFFF2B705);
  static const accentInk = Color(0xFF0B1220);
  static const pickup = Color(0xFF34C759);
  static const dropoff = Color(0xFFE53935);
  static const divider = Color(0xFFE8E2D5);
  static const blue = Color(0xFF1E88E5);
}

/// Trips this driver let go of (before pickup) during this app session —
/// they are not offered to the same driver again.
final Set<String> driverReleasedRideIds = <String>{};

class ActiveTripExecutionView extends StatefulWidget {
  final String rideId;
  final String serviceType;
  final String? pickupOtp;

  const ActiveTripExecutionView({
    super.key,
    required this.rideId,
    required this.serviceType,
    this.pickupOtp,
  });

  @override
  State<ActiveTripExecutionView> createState() =>
      _ActiveTripExecutionViewState();
}

class _ActiveTripExecutionViewState extends State<ActiveTripExecutionView> {
  bool isLoadingAction = false;

  final Completer<GoogleMapController> _mapController = Completer();
  GoogleMapController? _gMapController;

  LatLng? pickupCoord;
  LatLng? dropoffCoord;
  double finalFareVal = 0;
  double? tripDistanceKm;

  BitmapDescriptor? _driverIcon;
  BitmapDescriptor? _pickupIcon;
  BitmapDescriptor? _dropoffIcon;
  BitmapDescriptor? _customerIcon;

  Timer? _routeRefreshTimer;
  Timer? _driverPositionMirror;
  bool _isMapCentered = false;

  LatLng? _lastRouteOrigin;
  DateTime? _lastRouteFetch;

  LatLng? _customerLiveLocation;
  RealtimeChannel? _customerLocationChannel;
  RealtimeChannel? _customerProfileWatch;
  RealtimeChannel? _rideCancelWatch;
  String? _customerId;

  Map<String, dynamic>? _customerProfile;
  int _customerCompletedTrips = 0;

  Timer? _distanceCheckTimer;
  Timer? _cancelPoll; // safety net if the live update is missed
  double? _distanceToDropoffKm;
  bool _canCompleteTrip = false;

  bool _otpVerified = false;
  bool _isAdminAssigned = false;
  bool _rideEnded = false;

  // ── Navigation ──
  static const _prefNavApp = 'driver_nav_app'; // google | waze | kongo
  String? _preferredNav;
  bool _inAppNav = false;
  double? _lastHeading;
  LatLng? _lastRouteTarget;
  List<RouteStep> _routeSteps = [];
  int? _routeEtaMin;
  double? _routeRemainingKm;

  // ── Voice, traffic and road reports ──
  bool _voiceOn = true;
  final Set<String> _spoken = {};
  int _delayMin = 0; // extra minutes caused by traffic
  int _toldDelay = 0;
  List<RoadReport> _reports = [];
  DateTime? _reportsFetched;

  String get _langCode => Localizations.localeOf(context).languageCode;

  void _say(String text) {
    if (!_voiceOn || !_inAppNav) return;
    NavVoice.instance.speak(text, _langCode);
  }

  /// Called after every fresh route while in-app navigation is on.
  void _navAssist(RouteResult route, LatLng me) {
    if (!_inAppNav || !mounted) return;

    // Traffic: tell the driver once, and again if it gets 4+ min worse.
    final delay = route.delayMin;
    if (delay != _delayMin) setState(() => _delayMin = delay);
    if (delay >= 4 && delay >= _toldDelay + 4) {
      _toldDelay = delay;
      String where = '';
      if (route.jamSpots.isNotEmpty) {
        final km = _haversineKm(me, route.jamSpots.first);
        where = ' ${tr('Slow traffic in {0} km.', [km.toStringAsFixed(1)])}';
      }
      _say('${tr('Heavy traffic ahead. About {0} extra minutes.', [delay])}$where');
    } else if (delay < 4) {
      _toldDelay = 0;
    }

    // Turns: once at ~300 m, once at ~50 m.
    if (route.steps.length > 1) {
      final d = route.steps.first.distanceM;
      final next = route.steps[1];
      final key = '${next.instruction}|${next.end?.latitude.toStringAsFixed(4)}';
      if (next.instruction.isNotEmpty) {
        if (d <= 60 && _spoken.add('b$key')) {
          _spoken.add('a$key');
          _say(next.instruction);
        } else if (d <= 350 && d > 60 && _spoken.add('a$key')) {
          final m = ((d / 50).round() * 50).clamp(50, 350);
          _say(tr('In {0} metres: {1}', [m, next.instruction]));
        }
      }
    }

    _refreshReports(me, route);
  }

  Future<void> _refreshReports(LatLng me, RouteResult route) async {
    final now = DateTime.now();
    if (_reportsFetched == null ||
        now.difference(_reportsFetched!).inSeconds > 60) {
      _reportsFetched = now;
      final list = await RoadReportsService.near(me);
      if (!mounted) return;
      setState(() => _reports = list);
    }
    // Warn once when a report is within 800 m and on our route.
    for (final r in _reports) {
      if (_spoken.contains('r${r.id}')) continue;
      if (_haversineMeters(me, r.pos) > 800) continue;
      var onRoute = false;
      for (final p in route.points) {
        if (_haversineMeters(p, r.pos) < 150) {
          onRoute = true;
          break;
        }
      }
      if (!onRoute) continue;
      _spoken.add('r${r.id}');
      _say(tr('{0} reported ahead.', [_reportName(r.kind)]));
    }
  }

  String _reportName(String kind) {
    switch (kind) {
      case 'police':
        return tr('Police');
      case 'accident':
        return tr('Accident');
      case 'hazard':
        return tr('Hazard on the road');
      default:
        return tr('Traffic jam');
    }
  }

  Set<Marker> _reportMarkers() {
    if (!_inAppNav) return const {};
    double hue(String k) {
      switch (k) {
        case 'police':
          return BitmapDescriptor.hueAzure;
        case 'accident':
          return BitmapDescriptor.hueRed;
        case 'hazard':
          return BitmapDescriptor.hueOrange;
        default:
          return BitmapDescriptor.hueYellow;
      }
    }

    return {
      for (final r in _reports)
        Marker(
          markerId: MarkerId('rep_${r.id}'),
          position: r.pos,
          icon: BitmapDescriptor.defaultMarkerWithHue(hue(r.kind)),
          infoWindow: InfoWindow(title: _reportName(r.kind)),
        ),
    };
  }

  Future<void> _openReportSheet() async {
    final kind = await showModalBottomSheet<String>(
      context: context,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (ctx) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(8, 14, 8, 12),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Text(tr('Report on the road'),
                style:
                    const TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
            const SizedBox(height: 6),
            for (final k in RoadReportsService.kinds)
              ListTile(
                leading: Icon(
                    k == 'police'
                        ? Icons.local_police_outlined
                        : k == 'accident'
                            ? Icons.car_crash_outlined
                            : k == 'hazard'
                                ? Icons.warning_amber_rounded
                                : Icons.traffic_outlined,
                    size: 30,
                    color: _Palette.ink),
                title: Text(_reportName(k),
                    style: const TextStyle(
                        fontSize: 17, fontWeight: FontWeight.w700)),
                onTap: () => Navigator.pop(ctx, k),
              ),
          ]),
        ),
      ),
    );
    if (kind == null || !mounted) return;
    try {
      final pos = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high,
        timeLimit: const Duration(seconds: 6),
      );
      await RoadReportsService.report(kind, LatLng(pos.latitude, pos.longitude));
      if (!mounted) return;
      _reportsFetched = null;
      ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(tr('Thanks, other drivers will be warned.'))));
    } catch (e) {
      if (mounted) ErrorUI.showSnack(context, AppError.from(e));
    }
  }

  // ── Delivery return ──
  /// Same radius used for "arrived": completing and returning.
  static const double _arrivalRadiusKm = 1.0;
  String? _orderId;
  bool _returning = false;
  LatLng? _returnTarget;
  String _returnTargetName = '';
  double? _distanceToReturnKm;
  bool _canConfirmReturned = false;

  // ═══════════════════════════════════════════════════════════
  // LIFECYCLE
  // ═══════════════════════════════════════════════════════════
  @override
  void initState() {
    super.initState();
    _loadMarkerIcons();
    _loadNavPreference();
    _fetchRideCoordinatesAndRoute();
    _startTimers();
    _watchRideCancellation();
    _startDistanceCheck();
    _setupCall();
  }

  void _setupCall() {
    final svc = CallService.instance;
    svc.onIncoming = () {
      if (mounted) InAppCallScreen.show(context);
    };
    svc.onOutgoing = () {
      if (mounted) InAppCallScreen.show(context);
    };
    svc.attach(widget.rideId, myName: tr('Your driver'));
  }

  void _callCustomer() {
    final n = '${_customerProfile?['first_name'] ?? ''}'.trim();
    CallService.instance.call(toName: n.isEmpty ? tr('Customer') : n);
  }

  @override
  void dispose() {
    CallService.instance.onIncoming = null;
    CallService.instance.onOutgoing = null;
    CallService.instance.detach();
    NavVoice.instance.stop();
    _routeRefreshTimer?.cancel();
    _driverPositionMirror?.cancel();
    _customerLocationChannel?.unsubscribe();
    _customerProfileWatch?.unsubscribe();
    _rideCancelWatch?.unsubscribe();
    _distanceCheckTimer?.cancel();
    _cancelPoll?.cancel();
    _gMapController?.dispose();
    super.dispose();
  }

  // ═══════════════════════════════════════════════════════════
  // MAP MARKERS
  // ═══════════════════════════════════════════════════════════
  Future<void> _loadMarkerIcons() async {
    try {
      _driverIcon = await BitmapDescriptor.asset(
        const ImageConfiguration(size: Size(48, 48)),
        AppImages.driverCar,
      );
    } catch (e) {
      debugPrint('driver marker load failed: $e');
      _driverIcon = null;
    }

    try {
      _pickupIcon = await BitmapDescriptor.asset(
        const ImageConfiguration(size: Size(48, 48)),
        AppImages.rideMinibus,
      );
    } catch (e) {
      debugPrint('pickup marker load failed: $e');
      _pickupIcon = null;
    }

    try {
      _dropoffIcon = await BitmapDescriptor.asset(
        const ImageConfiguration(size: Size(48, 48)),
        widget.serviceType != 'Ride'
            ? AppImages.deliveryTruck
            : AppImages.driverSedan,
      );
    } catch (e) {
      debugPrint('dropoff marker load failed: $e');
      _dropoffIcon = null;
    }

    try {
      _customerIcon = await BitmapDescriptor.asset(
        const ImageConfiguration(size: Size(48, 48)),
        AppImages.mapPinUser,
      );
    } catch (e) {
      debugPrint('customer marker load failed: $e');
      _customerIcon = null;
    }

    if (mounted) setState(() {});
  }

  // ═══════════════════════════════════════════════════════════
  // DRIVER STAMP
  // ═══════════════════════════════════════════════════════════
  Future<void> _stampDriverOnRide() async {
    final myId = Supabase.instance.client.auth.currentUser?.id;
    if (myId == null) return;
    try {
      final existing = await Supabase.instance.client
          .from('rides')
          .select('driver_id, status')
          .eq('id', widget.rideId)
          .maybeSingle();

      if (existing == null) return;

      final existingDriver = existing['driver_id']?.toString();
      final hasDriver =
          existingDriver != null && existingDriver.trim().isNotEmpty;

      if (!hasDriver) {
        await Supabase.instance.client
            .from('rides')
            .update({'driver_id': myId})
            .eq('id', widget.rideId);
      }
    } catch (e) {
      debugPrint('driver_id stamp failed: $e');
    }
  }

  // ═══════════════════════════════════════════════════════════
  // CUSTOMER PROFILE
  // ═══════════════════════════════════════════════════════════
  Future<void> _loadCustomerProfile(String customerId) async {
    try {
      final p = await Supabase.instance.client
          .from('profiles')
          .select(
            'id, first_name, surname, full_name, '
            'profile_picture_url, average_rating, total_ratings, phone_number',
          )
          .eq('id', customerId)
          .maybeSingle();

      int completedCount = 0;
      try {
        final count = await Supabase.instance.client
            .from('rides')
            .count(CountOption.exact)
            .eq('customer_id', customerId)
            .eq('status', 'completed');
        completedCount = count;
      } catch (e) {
        debugPrint('completed count failed (non-fatal): $e');
      }

      if (!mounted) return;
      setState(() {
        _customerProfile = p;
        _customerCompletedTrips = completedCount;
      });
    } catch (e) {
      debugPrint('loadCustomerProfile failed: $e');
    }
  }

  void _subscribeToCustomerProfile(String customerId) {
    _customerProfileWatch?.unsubscribe();
    _customerProfileWatch = Supabase.instance.client
        .channel('active_customer_profile_$customerId')
        .onPostgresChanges(
          event: PostgresChangeEvent.update,
          schema: 'public',
          table: 'profiles',
          filter: PostgresChangeFilter(
            type: PostgresChangeFilterType.eq,
            column: 'id',
            value: customerId,
          ),
          callback: (payload) {
            if (!mounted) return;
            final row = payload.newRecord;
            if (row.isEmpty) return;

            final merged = Map<String, dynamic>.from(_customerProfile ?? {});
            merged.addAll(Map<String, dynamic>.from(row));

            setState(() {
              _customerProfile = merged;
              final lat = row['lat'];
              final lng = row['lng'];
              if (lat != null && lng != null) {
                _customerLiveLocation = LatLng(
                  (lat as num).toDouble(),
                  (lng as num).toDouble(),
                );
              }
            });
          },
        )
        .subscribe();
  }

  void _subscribeToCustomerLocation(String customerId) {
    _customerLocationChannel?.unsubscribe();
    _customerLocationChannel = Supabase.instance.client
        .channel('active_customer_location_$customerId')
        .onPostgresChanges(
          event: PostgresChangeEvent.update,
          schema: 'public',
          table: 'profiles',
          filter: PostgresChangeFilter(
            type: PostgresChangeFilterType.eq,
            column: 'id',
            value: customerId,
          ),
          callback: (payload) {
            final lat = payload.newRecord['lat'];
            final lng = payload.newRecord['lng'];
            if (lat != null && lng != null && mounted) {
              setState(() {
                _customerLiveLocation = LatLng(
                  (lat as num).toDouble(),
                  (lng as num).toDouble(),
                );
              });
            }
          },
        )
        .subscribe();
  }

  // ═══════════════════════════════════════════════════════════
  // DISTANCE CHECK
  // ═══════════════════════════════════════════════════════════
  void _startDistanceCheck() {
    _distanceCheckTimer?.cancel();
    _distanceCheckTimer =
        Timer.periodic(const Duration(seconds: 5), (_) async {
      if (!mounted) return;
      if (_rideEnded) return;
      if (dropoffCoord == null && _returnTarget == null) return;
      try {
        final pos = await Geolocator.getCurrentPosition(
          desiredAccuracy: LocationAccuracy.high,
          timeLimit: const Duration(seconds: 5),
        );
        final current = LatLng(pos.latitude, pos.longitude);
        if (!mounted) return;
        if (_returning && _returnTarget != null) {
          final km = _haversineKm(current, _returnTarget!);
          setState(() {
            _distanceToReturnKm = km;
            _canConfirmReturned = km <= _arrivalRadiusKm;
          });
        } else if (dropoffCoord != null) {
          final km = _haversineKm(current, dropoffCoord!);
          setState(() {
            _distanceToDropoffKm = km;
            _canCompleteTrip = km <= _arrivalRadiusKm &&
                context.read<RideProvider>().currentTripState ==
                    'in_progress';
          });
        }
      } catch (_) {}
    });
  }

  // ═══════════════════════════════════════════════════════════
  // OTP DIALOG
  // ═══════════════════════════════════════════════════════════
  Future<void> _showOtpDialog() async {
    final t = S.of(context);
    final ctrl = TextEditingController();
    String? errorMsg;
    bool verifying = false;

    try {
      await showDialog(
        context: context,
        barrierDismissible: false,
        builder: (ctx) => StatefulBuilder(
          builder: (ctx, setDialogState) {
            Future<void> verify() async {
              final entered = ctrl.text.trim();
              if (entered.isEmpty) {
                setDialogState(
                    () => errorMsg = t.t('otp_enter_code'));
                return;
              }
              setDialogState(() {
                verifying = true;
                errorMsg = null;
              });

              try {
                final row = await Supabase.instance.client
                    .from('rides')
                    .select('pickup_otp_verified, status')
                    .eq('id', widget.rideId)
                    .maybeSingle();

                final alreadyVerified =
                    row?['pickup_otp_verified'] == true;
                final rideStatus = (row?['status'] ?? '').toString();

                if (alreadyVerified) {
                  if (mounted) setState(() => _otpVerified = true);
                  if (ctx.mounted) Navigator.pop(ctx);
                  return;
                }

                if (rideStatus == 'cancelled') {
                  setDialogState(() {
                    verifying = false;
                    errorMsg = t.t('otp_ride_cancelled');
                  });
                  return;
                }

                final result = await Supabase.instance.client.rpc(
                  'verify_pickup_otp',
                  params: {
                    'p_ride_id': widget.rideId,
                    'p_otp': entered,
                  },
                ).timeout(const Duration(seconds: 10));

                if (result == true) {
                  if (!mounted) return;
                  setState(() => _otpVerified = true);
                  if (ctx.mounted) Navigator.pop(ctx);
                  ErrorUI.showSnack(
                    context,
                    AppError(
                      title: t.t('otp_verified'),
                      message: t.t('otp_verified_hint'),
                      icon: Icons.check_circle_outline,
                    ),
                  );
                } else {
                  setDialogState(() {
                    verifying = false;
                    errorMsg = t.t('otp_wrong_code');
                  });
                }
              } catch (e) {
                final msg = e.toString().toLowerCase();
                setDialogState(() {
                  verifying = false;
                  if (msg.contains('too many')) {
                    errorMsg = t.t('otp_too_many');
                  } else {
                    errorMsg = t.t('otp_verify_failed');
                  }
                });
              }
            }

            return AlertDialog(
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16)),
              title: Row(
                children: [
                  AppImage(
                    AppImages.shieldCheck,
                    size: 24,
                    tint: _Palette.blue,
                    fallbackIcon: Icons.shield_outlined,
                  ),
                  const SizedBox(width: 10),
                  Text(t.t('otp_title')),
                ],
              ),
              content: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    t.t('otp_hint_driver'),
                    style: const TextStyle(
                        fontSize: 13.5, color: _Palette.inkMuted),
                  ),
                  const SizedBox(height: 16),
                  TextField(
                    controller: ctrl,
                    autofocus: true,
                    keyboardType: TextInputType.number,
                    maxLength: 6,
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 6),
                    decoration: InputDecoration(
                      hintText: '••••••',
                      counterText: '',
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12)),
                    ),
                  ),
                  if (errorMsg != null) ...[
                    const SizedBox(height: 8),
                    Text(errorMsg!,
                        style: const TextStyle(
                            color: Colors.red, fontSize: 13.5)),
                  ],
                ],
              ),
              actions: [
                TextButton(
                  onPressed: verifying ? null : () => Navigator.pop(ctx),
                  child: Text(t.t('cancel')),
                ),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFFF2B705),
        foregroundColor: const Color(0xFF0B1220)),
                  onPressed: verifying ? null : verify,
                  child: verifying
                      ? const SizedBox(
                          width: 18,
                          height: 18,
                          child: CircularProgressIndicator(
                              color: const Color(0xFF0B1220), strokeWidth: 2),
                        )
                      : Text(t.t('verify'),
                          style: const TextStyle(
                              color: const Color(0xFF0B1220),
                              fontWeight: FontWeight.bold)),
                ),
              ],
            );
          },
        ),
      );
    } finally {
      ctrl.dispose();
    }
  }

  // ═══════════════════════════════════════════════════════════
  // DRIVER CANCEL
  // ═══════════════════════════════════════════════════════════
  Future<void> _confirmDriverCancel() async {
    final t = S.of(context);
    final reasons = <String>[
      t.t('cancel_reason_no_customer'),
      t.t('cancel_reason_safety'),
      t.t('cancel_reason_vehicle'),
      t.t('cancel_reason_customer_asked'),
      t.t('cancel_reason_other'),
    ];
    String? selected;
    final otherCtrl = TextEditingController();

    try {
      final confirmed = await showDialog<bool>(
        context: context,
        barrierDismissible: false,
        builder: (ctx) => StatefulBuilder(
          builder: (ctx, setSt) => AlertDialog(
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16)),
            title: Text(t.t('driver_cancel_title')),
            content: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(t.t('driver_cancel_hint')),
                  const SizedBox(height: 12),
                  ...reasons.map((r) => RadioListTile<String>(
                        title: Text(r),
                        value: r,
                        groupValue: selected,
                        contentPadding: EdgeInsets.zero,
                        onChanged: (v) => setSt(() => selected = v),
                      )),
                  if (selected == t.t('cancel_reason_other'))
                    TextField(
                      controller: otherCtrl,
                      decoration: InputDecoration(
                        hintText: t.t('driver_cancel_more'),
                        border: const OutlineInputBorder(),
                      ),
                    ),
                ],
              ),
            ),
            actions: [
              TextButton(
                  onPressed: () => Navigator.pop(ctx, false),
                  child: Text(t.t('keep_trip'))),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                    backgroundColor: EfuridePalette.dropoff),
                onPressed:
                    selected == null ? null : () => Navigator.pop(ctx, true),
                child: Text(t.t('confirm_cancel')),
              ),
            ],
          ),
        ),
      );

      if (confirmed != true) return;

      final reason = selected == t.t('cancel_reason_other')
          ? (otherCtrl.text.trim().isEmpty
              ? t.t('cancel_reason_other')
              : otherCtrl.text.trim())
          : selected!;

      final isPickupStage = context.read<RideProvider>().currentTripState ==
          'en_route_to_pickup';
      if (isPickupStage) {
        driverReleasedRideIds.add(widget.rideId);
        // Not picked up yet: release the trip so another driver can take
        // it. The customer keeps their booking and sees "finding another
        // driver" instead of losing the trip.
        await Supabase.instance.client.from('rides').update({
          'status': 'pending',
          'driver_id': null,
          'accepted_at': null,
          'pickup_otp_verified': false,
          'cancellation_reason': 'released_by_driver: $reason',
          'dispatched_at': DateTime.now().toUtc().toIso8601String(),
        }).eq('id', widget.rideId);
      } else {
        await Supabase.instance.client.from('rides').update({
          'status': 'cancelled',
          'cancelled_by': 'driver',
          'cancellation_reason': reason,
          'cancelled_at': DateTime.now().toUtc().toIso8601String(),
        }).eq('id', widget.rideId);
      }

      _rideEnded = true;
      _cleanupListeners();
      DriverLocationService.instance.setActiveRide(null);

      if (!mounted) return;
      ErrorUI.showSnack(
        context,
        AppError(
          title: t.t('trip_cancelled'),
          message: t.t('trip_cancelled_hint'),
          icon: Icons.cancel_outlined,
        ),
      );
      Navigator.pushNamedAndRemoveUntil(
          context, '/driver', (route) => false);
    } catch (e) {
      if (!mounted) return;
      ErrorUI.showSnack(
        context,
        AppError.from(e, onRetry: _confirmDriverCancel),
      );
    } finally {
      otherCtrl.dispose();
    }
  }

  // ═══════════════════════════════════════════════════════════
  // WATCH RIDE CANCELLATION
  // ═══════════════════════════════════════════════════════════
  void _watchRideCancellation() {
    _cancelPoll?.cancel();
    _cancelPoll = Timer.periodic(const Duration(seconds: 10), (_) async {
      if (_rideEnded || !mounted) return;
      try {
        final row = await Supabase.instance.client
            .from('rides')
            .select('status, driver_id')
            .eq('id', widget.rideId)
            .maybeSingle();
        if (row == null || _rideEnded || !mounted) return;
        final myId = Supabase.instance.client.auth.currentUser?.id;
        final released = row['status'] == 'pending' &&
            row['driver_id']?.toString() != myId;
        if (row['status'] == 'cancelled' || released) {
          _rideEnded = true;
          _cleanupListeners();
          DriverLocationService.instance.setActiveRide(null);
          if (!mounted) return;
          ErrorUI.showSnack(
            context,
            AppError(
              title: S.of(context).t('trip_cancelled'),
              message: S.of(context).t('trip_cancelled_customer'),
              icon: Icons.cancel_outlined,
            ),
          );
          Navigator.pushNamedAndRemoveUntil(
              context, '/driver', (route) => false);
        }
      } catch (_) {}
    });
    _rideCancelWatch?.unsubscribe();
    _rideCancelWatch = Supabase.instance.client
        .channel('active_trip_cancel_watch_${widget.rideId}')
        .onPostgresChanges(
          event: PostgresChangeEvent.update,
          schema: 'public',
          table: 'rides',
          filter: PostgresChangeFilter(
              type: PostgresChangeFilterType.eq,
              column: 'id',
              value: widget.rideId),
          callback: (payload) async {
            final row = payload.newRecord;
            if (_rideEnded) return;
            // A delivery released back to the queue no longer belongs
            // to this driver — treat it like a cancellation here.
            final myId = Supabase.instance.client.auth.currentUser?.id;
            final released = row['status'] == 'pending' &&
                row['driver_id']?.toString() != myId;
            if (row['status'] == 'cancelled' || released) {
              _rideEnded = true;
              _cleanupListeners();
              DriverLocationService.instance.setActiveRide(null);

              if (!mounted) return;
              ErrorUI.showSnack(
                context,
                AppError(
                  title: S.of(context).t('trip_cancelled'),
                  message: S.of(context).t('trip_cancelled_customer'),
                  icon: Icons.cancel_outlined,
                ),
              );
              Navigator.pushNamedAndRemoveUntil(
                  context, '/driver', (route) => false);
            } else if (row['pickup_otp_verified'] == true) {
              if (mounted && !_otpVerified) {
                setState(() => _otpVerified = true);
              }
            }
          },
        )
        .subscribe();
  }

  void _cleanupListeners() {
    _routeRefreshTimer?.cancel();
    _driverPositionMirror?.cancel();
    _customerLocationChannel?.unsubscribe();
    _customerProfileWatch?.unsubscribe();
    _rideCancelWatch?.unsubscribe();
    _distanceCheckTimer?.cancel();
    _cancelPoll?.cancel();
  }

  // ═══════════════════════════════════════════════════════════
  // TIMERS
  // ═══════════════════════════════════════════════════════════
  void _startTimers() {
    _driverPositionMirror =
        Timer.periodic(const Duration(seconds: 5), (timer) async {
      if (_rideEnded) return;
      await _mirrorDriverPositionToProvider();
    });

    _routeRefreshTimer =
        Timer.periodic(const Duration(seconds: 10), (timer) async {
      if (!mounted || _rideEnded) return;
      final target = _currentNavTarget();
      if (target != null) await _loadRoutePath(target);
    });
  }

  Future<void> _mirrorDriverPositionToProvider() async {
    if (!mounted) return;
    try {
      final pos = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high,
        timeLimit: const Duration(seconds: 5),
      );
      if (!mounted) return;
      final loc = LatLng(pos.latitude, pos.longitude);
      if (pos.heading > 0) _lastHeading = pos.heading;
      context.read<RideProvider>().updateDriverPosition(loc);

      if (_inAppNav && _gMapController != null) {
        // ko!ngo navigation: follow the car, heading-up.
        _gMapController!.animateCamera(
          CameraUpdate.newCameraPosition(CameraPosition(
            target: loc,
            zoom: 17,
            bearing: _lastHeading ?? 0,
            tilt: 45,
          )),
        );
        _isMapCentered = true;
      } else if (!_isMapCentered && _gMapController != null) {
        _gMapController!
            .animateCamera(CameraUpdate.newLatLngZoom(loc, 15.0));
        _isMapCentered = true;
      }
    } catch (_) {}
  }

  // ═══════════════════════════════════════════════════════════
  // FETCH RIDE + ROUTE
  // ═══════════════════════════════════════════════════════════
  Future<void> _fetchRideCoordinatesAndRoute() async {
    try {
      await _stampDriverOnRide();

      final data = await Supabase.instance.client
          .from('rides')
          .select()
          .eq('id', widget.rideId)
          .single();
      if (!mounted) return;

      final t = S.of(context);
      final status = (data['status'] ?? '').toString();
      if (status == 'cancelled' ||
          status == 'completed' ||
          status == 'returned') {
        _rideEnded = true;
        _cleanupListeners();
        DriverLocationService.instance.setActiveRide(null);
        ErrorUI.showSnack(
          context,
          AppError(
            title: t.t('ride_no_longer'),
            message: status == 'cancelled'
                ? t.t('ride_was_cancelled')
                : t.t('ride_already_completed'),
            icon: Icons.cancel_outlined,
          ),
        );
        Navigator.pushNamedAndRemoveUntil(
            context, '/driver', (route) => false);
        return;
      }

      final myId = Supabase.instance.client.auth.currentUser?.id;
      final assignedByAdmin = data['assigned_by_admin'] == true ||
          (data['driver_id'] != null &&
              data['driver_id'].toString() == myId &&
              data['accepted_at'] == null);

      setState(() {
        pickupCoord = LatLng(
          (data['pickup_lat'] as num).toDouble(),
          (data['pickup_lng'] as num).toDouble(),
        );
        dropoffCoord = LatLng(
          (data['dropoff_lat'] as num).toDouble(),
          (data['dropoff_lng'] as num).toDouble(),
        );
        finalFareVal = (data['fare'] ?? 0).toDouble();
        tripDistanceKm = (data['distance_km'] as num?)?.toDouble();
        _customerId = data['customer_id'];
        _otpVerified = data['pickup_otp_verified'] == true;
        _isAdminAssigned = assignedByAdmin;
        _orderId = data['order_id']?.toString();
      });

      // Re-opening mid-trip: put the screen back on the right stage.
      // The stage always comes from the server, never from what an earlier
      // trip left in the provider: a stale stage is what showed "Complete
      // trip" before the pickup code was entered.
      if (status == 'in_progress' || status == 'returning') {
        context.read<RideProvider>().updateTripStatus('in_progress');
      } else {
        context.read<RideProvider>().updateTripStatus('en_route_to_pickup');
        _canCompleteTrip = false;
      }
      if (status == 'returning') {
        final rl = (data['return_lat'] as num?)?.toDouble();
        final rg = (data['return_lng'] as num?)?.toDouble();
        setState(() {
          _returning = true;
          _returnTarget =
              (rl != null && rg != null) ? LatLng(rl, rg) : pickupCoord;
          _returnTargetName = (data['return_address'] ?? '').toString();
        });
      }

      if (_isAdminAssigned) {
        ErrorUI.showSnack(
          context,
          AppError(
            title: t.t('admin_assigned'),
            message: t.t('admin_assigned_hint'),
            icon: Icons.admin_panel_settings,
          ),
        );
      }

      if (_customerId != null) {
        _subscribeToCustomerLocation(_customerId!);
        _subscribeToCustomerProfile(_customerId!);
        await _loadCustomerProfile(_customerId!);
      }

      DriverLocationService.instance.setActiveRide(widget.rideId);

      await _mirrorDriverPositionToProvider();
      final target = _currentNavTarget();
      if (target != null) await _loadRoutePath(target);
    } catch (e) {
      if (!mounted) return;
      ErrorUI.showErrorDialog(
        context,
        AppError.from(e, onRetry: _fetchRideCoordinatesAndRoute),
      );
    }
  }

  Future<void> _loadRoutePath(LatLng destination) async {
    if (!mounted || _rideEnded) return;
    try {
      final pos = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high,
        timeLimit: const Duration(seconds: 5),
      );
      if (!mounted) return;
      final currentDriverPos = LatLng(pos.latitude, pos.longitude);
      if (pos.heading > 0) _lastHeading = pos.heading;
      context.read<RideProvider>().updateDriverPosition(currentDriverPos);

      // Throttle re-routing, but always re-route when the target changes
      // (pickup → drop-off → office). In-app navigation refreshes faster.
      final now = DateTime.now();
      final sameTarget = _lastRouteTarget == destination;
      if (sameTarget && _lastRouteOrigin != null && _lastRouteFetch != null) {
        final sinceSec = now.difference(_lastRouteFetch!).inSeconds;
        final movedMeters =
            _haversineMeters(_lastRouteOrigin!, currentDriverPos);
        final minSec = _inAppNav ? 8 : 20;
        final minMoved = _inAppNav ? 40.0 : 200.0;
        if (sinceSec < minSec && movedMeters < minMoved) {
          return;
        }
      }
      _lastRouteOrigin = currentDriverPos;
      _lastRouteFetch = now;
      _lastRouteTarget = destination;

      final route = await GoogleMapsService.route(currentDriverPos, destination);
      if (route == null || !mounted || _rideEnded) return;
      context.read<RideProvider>().updateRoutePoints(route.points);
      setState(() {
        _routeSteps = route.steps;
        _routeEtaMin = route.durationMin;
        _routeRemainingKm = route.distanceKm;
        tripDistanceKm ??= route.distanceKm;
      });
      _navAssist(route, currentDriverPos);
    } catch (e) {
      debugPrint('loadRoutePath failed: $e');
    }
  }

  double _haversineMeters(LatLng a, LatLng b) {
    const R = 6371000.0;
    final dLat = (b.latitude - a.latitude) * math.pi / 180;
    final dLng = (b.longitude - a.longitude) * math.pi / 180;
    final h = math.sin(dLat / 2) * math.sin(dLat / 2) +
        math.cos(a.latitude * math.pi / 180) *
            math.cos(b.latitude * math.pi / 180) *
            math.sin(dLng / 2) *
            math.sin(dLng / 2);
    return 2 * R * math.asin(math.sqrt(h));
  }

  double _haversineKm(LatLng a, LatLng b) {
    const R = 6371.0;
    final dLat = (b.latitude - a.latitude) * math.pi / 180;
    final dLng = (b.longitude - a.longitude) * math.pi / 180;
    final h = math.sin(dLat / 2) * math.sin(dLat / 2) +
        math.cos(a.latitude * math.pi / 180) *
            math.cos(b.latitude * math.pi / 180) *
            math.sin(dLng / 2) *
            math.sin(dLng / 2);
    return 2 * R * math.asin(math.sqrt(h));
  }

  // ═══════════════════════════════════════════════════════════
  // TRIP STATUS UPDATES
  // ═══════════════════════════════════════════════════════════
  Future<void> _updateTripStatus(String newStatus) async {
    if (!await ConnectionService.instance.ensureOnline(context)) return;
    if (!mounted) return;
    final t = S.of(context);
    if (newStatus == 'in_progress' && !_otpVerified) {
      // The customer's PIN is required, always: ask for it right here.
      await _showOtpDialog();
      if (!mounted || !_otpVerified) {
        if (mounted) {
          ErrorUI.showSnack(
            context,
            AppError(
              title: t.t('verify_pickup_code'),
              message: t.t('verify_pickup_code_hint'),
              icon: Icons.shield_outlined,
            ),
          );
        }
        return;
      }
    }

    // Completing needs a started trip: check the real status first and, if
    // the screen was out of step, put it back on the pickup stage.
    if (newStatus == 'completed') {
      try {
        final row = await Supabase.instance.client
            .from('rides')
            .select('status, pickup_otp_verified')
            .eq('id', widget.rideId)
            .maybeSingle();
        final st = (row?['status'] ?? '').toString();
        if (st != 'in_progress') {
          if (!mounted) return;
          context.read<RideProvider>().updateTripStatus('en_route_to_pickup');
          setState(() {
            _canCompleteTrip = false;
            _otpVerified = row?['pickup_otp_verified'] == true;
          });
          ErrorUI.showSnack(
            context,
            AppError(
              title: t.t('verify_pickup_code'),
              message: t.t('verify_pickup_code_hint'),
              icon: Icons.shield_outlined,
            ),
          );
          return;
        }
      } catch (_) {}
    }

    setState(() => isLoadingAction = true);
    try {
      final myId = Supabase.instance.client.auth.currentUser?.id;
      final update = <String, dynamic>{'status': newStatus};

      if (myId != null) {
        update['driver_id'] = myId;
      }
      if (newStatus == 'in_progress') {
        update['started_at'] = DateTime.now().toUtc().toIso8601String();
      } else if (newStatus == 'completed') {
        update['completed_at'] = DateTime.now().toUtc().toIso8601String();
      }

      await Supabase.instance.client
          .from('rides')
          .update(update)
          .eq('id', widget.rideId);

      if (!mounted) return;
      context.read<RideProvider>().updateTripStatus(newStatus);
      setState(() => isLoadingAction = false);

      if (newStatus == 'in_progress' && dropoffCoord != null) {
        await _loadRoutePath(dropoffCoord!);
        _gMapController?.animateCamera(
            CameraUpdate.newLatLngZoom(dropoffCoord!, 15.0));
        _isMapCentered = true;
      } else if (newStatus == 'en_route_to_pickup' && pickupCoord != null) {
        await _loadRoutePath(pickupCoord!);
      }

      if (newStatus == 'completed') {
        _rideEnded = true;
        DriverLocationService.instance.setActiveRide(null);
        _cleanupListeners();

        if (!mounted) return;
        context.read<RideProvider>().clearTripData();

        try {
          await Supabase.instance.client.from('rides').update({
            'driver_lat': null,
            'driver_lng': null,
          }).eq('id', widget.rideId);
        } catch (_) {}

        final distanceText = tripDistanceKm != null
            ? '${tripDistanceKm!.toStringAsFixed(1)} km'
            : '—';

        final customerName =
            '${_customerProfile?['first_name'] ?? ''} ${_customerProfile?['surname'] ?? ''}'
                .trim();

        if (!mounted) return;
        Navigator.pushNamedAndRemoveUntil(
          context,
          '/trip_ended',
          (route) => false,
          arguments: {
            'fare': finalFareVal,
            'distance': distanceText,
            'rideId': widget.rideId,
            'customerId': _customerId,
            'customerName': customerName.isEmpty ? null : customerName,
          },
        );
      }
    } catch (e) {
      if (!mounted) return;
      setState(() => isLoadingAction = false);
      ErrorUI.showErrorDialog(
        context,
        AppError.from(e, onRetry: () => _updateTripStatus(newStatus)),
      );
    }
  }

  // ═══════════════════════════════════════════════════════════
  // AVATAR
  // ═══════════════════════════════════════════════════════════
  /// Full photo of the customer, so the driver knows who to look for.
  void _showCustomerPhoto() {
    final p = _customerProfile;
    final url = p?['profile_picture_url']?.toString().trim() ?? '';
    if (p == null) return;
    final name =
        '${p['first_name'] ?? ''} ${p['surname'] ?? ''}'.trim();
    showDialog(
      context: context,
      builder: (ctx) => Dialog(
        clipBehavior: Clip.antiAlias,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (url.isNotEmpty)
              InteractiveViewer(
                child: Image.network(url,
                    height: 360,
                    width: double.infinity,
                    fit: BoxFit.cover,
                    errorBuilder: (_, __, ___) => const SizedBox(
                        height: 200,
                        child: Center(child: KIcon(Icons.person, size: 80)))),
              )
            else
              const SizedBox(
                  height: 200,
                  child: Center(child: KIcon(Icons.person, size: 80))),
            Padding(
              padding: const EdgeInsets.all(16),
              child: Column(children: [
                if (name.isNotEmpty)
                  Text(name,
                      style: const TextStyle(
                          fontSize: 18, fontWeight: FontWeight.w800)),
                const SizedBox(height: 8),
                TextButton(
                    onPressed: () => Navigator.pop(ctx), child: Text(tr('OK'))),
              ]),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCustomerAvatar({double radius = 26}) {
    final url = _customerProfile?['profile_picture_url']?.toString().trim();
    final hasUrl = url != null && url.isNotEmpty;

    final first = _customerProfile?['first_name']?.toString() ?? '';
    final surname = _customerProfile?['surname']?.toString() ?? '';
    final fullName = _customerProfile?['full_name']?.toString() ?? '';

    String initials = '';
    if (first.isNotEmpty) initials += first[0].toUpperCase();
    if (surname.isNotEmpty) initials += surname[0].toUpperCase();
    if (initials.isEmpty && fullName.isNotEmpty) {
      initials = fullName[0].toUpperCase();
    }
    if (initials.isEmpty) initials = '?';

    return CircleAvatar(
      radius: radius,
      backgroundColor: Colors.indigo,
      foregroundImage: hasUrl ? NetworkImage(url) : null,
      onForegroundImageError: hasUrl ? (_, __) {} : null,
      child: Text(
        initials,
        style: TextStyle(
          color: Colors.white,
          fontWeight: FontWeight.bold,
          fontSize: radius * 0.7,
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // MARKERS + POLYLINES
  // ═══════════════════════════════════════════════════════════
  Set<Marker> _buildMarkers(RideProvider rideProvider, bool isPickupStage) {
    final markers = <Marker>{};

    if (isPickupStage && pickupCoord != null) {
      markers.add(Marker(
        markerId: const MarkerId('pickup'),
        position: pickupCoord!,
        // A pin, not a vehicle picture: with a car icon here the pickup
        // looked like a second car next to the driver.
        icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueGreen),
        infoWindow: InfoWindow(title: tr('Pickup')),
      ));
    }

    if (_returning && _returnTarget != null) {
      markers.add(Marker(
        markerId: const MarkerId('return_office'),
        position: _returnTarget!,
        icon: BitmapDescriptor.defaultMarkerWithHue(
            BitmapDescriptor.hueOrange),
        infoWindow: InfoWindow(title: _returnTargetName),
      ));
    } else if (!isPickupStage && dropoffCoord != null) {
      markers.add(Marker(
        markerId: const MarkerId('dropoff'),
        position: dropoffCoord!,
        icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueRed),
        infoWindow: InfoWindow(title: tr('Drop-off')),
      ));
    }

    if (rideProvider.driverPosition != null) {
      markers.add(Marker(
        markerId: const MarkerId('driver'),
        position: rideProvider.driverPosition!,
        icon: _driverIcon ?? BitmapDescriptor.defaultMarker,
        anchor: const Offset(0.5, 0.5),
        infoWindow: InfoWindow(title: tr('You')),
      ));
    }

    if (_customerLiveLocation != null) {
      markers.add(Marker(
        markerId: const MarkerId('customer'),
        position: _customerLiveLocation!,
        icon: _customerIcon ??
            BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueAzure),
        anchor: const Offset(0.5, 0.5),
        infoWindow: InfoWindow(title: tr('Customer')),
      ));
    }

    return markers;
  }

  Set<Polyline> _buildPolylines(
      RideProvider rideProvider, bool isPickupStage) {
    if (rideProvider.routePolylinePoints.isEmpty) return {};
    return {
      Polyline(
        polylineId: const PolylineId('route'),
        points: rideProvider.routePolylinePoints,
        width: 5,
        color: _returning
            ? Colors.deepOrange
            : (isPickupStage ? _Palette.accent : _Palette.pickup),
        geodesic: true,
      ),
    };
  }

  // ═══════════════════════════════════════════════════════════
  // NAVIGATION (Google Maps · Waze · ko!ngo)
  // ═══════════════════════════════════════════════════════════

  /// Where the driver should be heading right now.
  LatLng? _currentNavTarget() {
    if (_returning) return _returnTarget;
    final state = context.read<RideProvider>().currentTripState;
    return state == 'en_route_to_pickup' ? pickupCoord : dropoffCoord;
  }

  String _currentNavTargetLabel(S t) {
    if (_returning) {
      return _returnTargetName.isNotEmpty
          ? _returnTargetName
          : t.t('ret_office');
    }
    final state = context.read<RideProvider>().currentTripState;
    return state == 'en_route_to_pickup'
        ? t.t('nav_pickup')
        : t.t('nav_dropoff');
  }

  String _navAppName(S t, String app) {
    switch (app) {
      case 'google':
        return 'Google Maps';
      case 'waze':
        return 'Waze';
      default:
        return t.t('nav_kongo');
    }
  }

  Future<void> _loadNavPreference() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final v = prefs.getString(_prefNavApp);
      if (mounted) setState(() => _preferredNav = v);
    } catch (_) {}
  }

  Future<void> _saveNavPreference(String? app) async {
    setState(() => _preferredNav = app);
    try {
      final prefs = await SharedPreferences.getInstance();
      if (app == null) {
        await prefs.remove(_prefNavApp);
      } else {
        await prefs.setString(_prefNavApp, app);
      }
    } catch (_) {}
  }

  /// Navigate button: use the remembered app, or ask.
  Future<void> _onNavigatePressed() async {
    final pref = _preferredNav;
    if (pref != null) {
      await _startNavigation(pref);
    } else {
      await _openNavigationSheet();
    }
  }

  Future<void> _startNavigation(String app) async {
    final target = _currentNavTarget();
    if (target == null) return;
    switch (app) {
      case 'google':
        await _launchGoogleMaps(target);
        break;
      case 'waze':
        await _launchWaze(target);
        break;
      default:
        _startInAppNav(target);
    }
  }

  void _startInAppNav(LatLng target) {
    setState(() {
      _inAppNav = true;
      _lastRouteFetch = null; // force a fresh route with steps
      _spoken.clear();
      _toldDelay = 0;
      _reportsFetched = null;
    });
    _say(tr('Navigation started'));
    _loadRoutePath(target);
    _mirrorDriverPositionToProvider();
  }

  void _stopInAppNav() {
    NavVoice.instance.stop();
    setState(() {
      _inAppNav = false;
      _delayMin = 0;
    });
    _isMapCentered = false;
    final target = _currentNavTarget();
    if (target != null && _gMapController != null) {
      _gMapController!.animateCamera(CameraUpdate.newCameraPosition(
        CameraPosition(target: target, zoom: 15, bearing: 0, tilt: 0),
      ));
    }
  }

  Future<void> _openNavigationSheet() async {
    final t = S.of(context);
    final target = _currentNavTarget();
    if (target == null || !mounted) return;
    final label = _currentNavTargetLabel(t);
    var remember = _preferredNav != null;

    await showModalBottomSheet(
      context: context,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setSheet) {
          Widget option(String app, Widget icon) {
            final isPref = _preferredNav == app;
            return ListTile(
              leading: icon,
              title: Text(_navAppName(t, app),
                  style: const TextStyle(fontWeight: FontWeight.w600)),
              trailing: isPref
                  ? const Icon(Icons.check_circle, color: _Palette.pickup)
                  : null,
              onTap: () async {
                Navigator.pop(ctx);
                await _saveNavPreference(remember ? app : null);
                await _startNavigation(app);
              },
            );
          }

          return SafeArea(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(20, 16, 20, 8),
                  child: Row(
                    children: [
                      const Icon(Icons.navigation_outlined,
                          color: _Palette.blue),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Text(
                          '${t.t('nav_to')} $label',
                          style: const TextStyle(
                              fontSize: 16, fontWeight: FontWeight.w800),
                        ),
                      ),
                    ],
                  ),
                ),
                const Divider(height: 1),
                option('google',
                    const Icon(Icons.map_outlined, color: _Palette.blue)),
                option('waze',
                    const Icon(Icons.alt_route, color: Color(0xFF33CCFF))),
                option(
                    'kongo',
                    AppImage(AppImages.leopardLogo,
                        size: 24, fallbackIcon: Icons.my_location)),
                SwitchListTile(
                  value: remember,
                  onChanged: (v) {
                    setSheet(() => remember = v);
                    if (!v) _saveNavPreference(null);
                  },
                  title: Text(t.t('nav_remember'),
                      style: const TextStyle(fontSize: 14)),
                  dense: true,
                ),
                const SizedBox(height: 8),
              ],
            ),
          );
        },
      ),
    );
  }

  Future<void> _launchGoogleMaps(LatLng target) async {
    final uri = Uri.parse(
      'https://www.google.com/maps/dir/?api=1'
      '&destination=${target.latitude},${target.longitude}'
      '&travelmode=driving&dir_action=navigate',
    );

    try {
      if (kIsWeb) {
        // Chrome / web build — open in a new tab.
        await launchUrl(uri, webOnlyWindowName: '_blank');
      } else {
        // Android / iOS — hand off to the native Maps app.
        await launchUrl(uri, mode: LaunchMode.externalApplication);
      }
    } catch (e) {
      debugPrint('Google Maps launch failed: $e');
    }
  }

  Future<void> _launchWaze(LatLng target) async {
    final webUri = Uri.parse(
      'https://waze.com/ul?ll=${target.latitude},${target.longitude}&navigate=yes',
    );

    // On web, the waze:// custom scheme can't be opened by the browser,
    // so go straight to the web URL in a new tab.
    if (kIsWeb) {
      try {
        await launchUrl(webUri, webOnlyWindowName: '_blank');
      } catch (e) {
        debugPrint('Waze web launch failed: $e');
      }
      return;
    }

    // Native — try the app first, fall back to the web URL.
    final wazeUri = Uri.parse(
      'waze://?ll=${target.latitude},${target.longitude}&navigate=yes',
    );
    try {
      final ok =
          await launchUrl(wazeUri, mode: LaunchMode.externalApplication);
      if (!ok) {
        await launchUrl(webUri, mode: LaunchMode.externalApplication);
      }
    } catch (e) {
      debugPrint('Waze launch failed, falling back to web: $e');
      try {
        await launchUrl(webUri, mode: LaunchMode.externalApplication);
      } catch (_) {}
    }
  }

  // ── In-app turn-by-turn banner ──
  IconData _maneuverIcon(String m) {
    switch (m) {
      case 'TURN_LEFT':
        return Icons.turn_left;
      case 'TURN_RIGHT':
        return Icons.turn_right;
      case 'TURN_SLIGHT_LEFT':
        return Icons.turn_slight_left;
      case 'TURN_SLIGHT_RIGHT':
        return Icons.turn_slight_right;
      case 'TURN_SHARP_LEFT':
        return Icons.turn_sharp_left;
      case 'TURN_SHARP_RIGHT':
        return Icons.turn_sharp_right;
      case 'UTURN_LEFT':
        return Icons.u_turn_left;
      case 'UTURN_RIGHT':
        return Icons.u_turn_right;
      case 'ROUNDABOUT_LEFT':
        return Icons.roundabout_left;
      case 'ROUNDABOUT_RIGHT':
        return Icons.roundabout_right;
      case 'MERGE':
        return Icons.merge;
      case 'FORK_LEFT':
        return Icons.fork_left;
      case 'FORK_RIGHT':
        return Icons.fork_right;
      case 'RAMP_LEFT':
        return Icons.ramp_left;
      case 'RAMP_RIGHT':
        return Icons.ramp_right;
      case 'STRAIGHT':
        return Icons.straight;
      default:
        return Icons.navigation;
    }
  }

  String _fmtDistance(double meters) {
    if (meters < 1000) {
      final rounded = (meters / 10).round() * 10;
      return '$rounded m';
    }
    return '${(meters / 1000).toStringAsFixed(1)} km';
  }

  Widget _navBanner(S t) {
    // steps[0] is the stretch we're on; the next manoeuvre is steps[1].
    final hasSteps = _routeSteps.isNotEmpty;
    final next = _routeSteps.length > 1
        ? _routeSteps[1]
        : (hasSteps ? _routeSteps.first : null);
    final distToNext = hasSteps ? _routeSteps.first.distanceM : null;

    return Material(
      color: const Color(0xFF0B1E3F),
      borderRadius: BorderRadius.circular(16),
      elevation: 6,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(14, 12, 6, 12),
        child: Row(
          children: [
            Icon(_maneuverIcon(next?.maneuver ?? ''),
                color: Colors.white, size: 34),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    distToNext == null
                        ? t.t('nav_calculating')
                        : _fmtDistance(distToNext),
                    style: const TextStyle(
                        color: Colors.white,
                        fontSize: 20,
                        fontWeight: FontWeight.w900),
                  ),
                  if (next != null && next.instruction.isNotEmpty)
                    Text(
                      next.instruction,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                          color: Colors.white70, fontSize: 14, height: 1.25),
                    ),
                  if (_delayMin >= 4)
                    Padding(
                      padding: const EdgeInsets.only(top: 4),
                      child: Row(children: [
                        const Icon(Icons.traffic,
                            size: 16, color: Color(0xFFFF8A80)),
                        const SizedBox(width: 4),
                        Text(tr('Heavy traffic: +{0} min', [_delayMin]),
                            style: const TextStyle(
                                color: Color(0xFFFF8A80),
                                fontSize: 13,
                                fontWeight: FontWeight.w800)),
                      ]),
                    ),
                  if (_routeEtaMin != null && _routeRemainingKm != null)
                    Padding(
                      padding: const EdgeInsets.only(top: 4),
                      child: Text(
                        '${_routeEtaMin!} ${t.t('min')} · ${_routeRemainingKm!.toStringAsFixed(1)} km · ${_currentNavTargetLabel(t)}',
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                            color: _Palette.accent,
                            fontSize: 13,
                            fontWeight: FontWeight.w700),
                      ),
                    ),
                ],
              ),
            ),
            IconButton(
              tooltip: tr('Voice directions'),
              onPressed: () {
                setState(() => _voiceOn = !_voiceOn);
                if (!_voiceOn) NavVoice.instance.stop();
              },
              icon: Icon(_voiceOn ? Icons.volume_up : Icons.volume_off,
                  color: Colors.white70),
            ),
            IconButton(
              tooltip: t.t('nav_stop'),
              onPressed: _stopInAppNav,
              icon: const Icon(Icons.close, color: Colors.white70),
            ),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // RETURN FLOW (deliveries only, unlocked at the drop-off)
  // ═══════════════════════════════════════════════════════════
  bool get _isDeliveryJob => widget.serviceType != 'Ride';

  /// Return is offered only once the driver has reached the drop-off.
  bool get _canReturn {
    if (_rideEnded || _returning || !_isDeliveryJob) return false;
    final stage = context.read<RideProvider>().currentTripState;
    return stage == 'in_progress' && _canCompleteTrip;
  }

  /// Nearest active company office to [from], or null if none is set up.
  Future<Map<String, dynamic>?> _nearestOffice(LatLng from) async {
    try {
      final rows = await Supabase.instance.client
          .from('company_offices')
          .select('id, name, address, lat, lng')
          .eq('is_active', true)
          .timeout(const Duration(seconds: 10));
      Map<String, dynamic>? best;
      double bestKm = double.infinity;
      for (final raw in rows as List) {
        final r = Map<String, dynamic>.from(raw as Map);
        final lat = (r['lat'] as num?)?.toDouble();
        final lng = (r['lng'] as num?)?.toDouble();
        if (lat == null || lng == null) continue;
        final km = _haversineKm(from, LatLng(lat, lng));
        if (km < bestKm) {
          bestKm = km;
          best = r;
        }
      }
      return best;
    } catch (e) {
      debugPrint('nearest office lookup failed: $e');
      return null;
    }
  }

  Future<void> _confirmReturn() async {
    final t = S.of(context);
    final reasons = <String>[
      t.t('ret_reason_unreachable'),
      t.t('ret_reason_absent'),
      t.t('ret_reason_refused'),
      t.t('ret_reason_address'),
      t.t('ret_reason_other'),
    ];
    final otherLabel = reasons.last;
    String? selected;
    final otherCtrl = TextEditingController();

    try {
      final confirmed = await showDialog<bool>(
        context: context,
        barrierDismissible: false,
        builder: (ctx) => StatefulBuilder(
          builder: (ctx, setSt) => AlertDialog(
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16)),
            title: Row(
              children: [
                const Icon(Icons.keyboard_return, color: _Palette.accent),
                const SizedBox(width: 10),
                Expanded(child: Text(t.t('ret_title'))),
              ],
            ),
            content: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    t.t('ret_hint'),
                    style: const TextStyle(
                        fontSize: 13.5, color: _Palette.inkMuted),
                  ),
                  const SizedBox(height: 12),
                  ...reasons.map((r) => RadioListTile<String>(
                        title: Text(r, style: const TextStyle(fontSize: 14)),
                        value: r,
                        groupValue: selected,
                        contentPadding: EdgeInsets.zero,
                        onChanged: (v) => setSt(() => selected = v),
                      )),
                  if (selected == otherLabel)
                    TextField(
                      controller: otherCtrl,
                      decoration: InputDecoration(
                        hintText: t.t('ret_tell_more'),
                        border: const OutlineInputBorder(),
                      ),
                    ),
                ],
              ),
            ),
            actions: [
              TextButton(
                  onPressed: () => Navigator.pop(ctx, false),
                  child: Text(t.t('ret_keep_trying'))),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                    backgroundColor: _Palette.accent,
                    foregroundColor: _Palette.accentInk),
                onPressed:
                    selected == null ? null : () => Navigator.pop(ctx, true),
                child: Text(t.t('ret_confirm')),
              ),
            ],
          ),
        ),
      );

      if (confirmed != true || !mounted) return;

      final reason = selected == otherLabel
          ? (otherCtrl.text.trim().isEmpty
              ? otherLabel
              : otherCtrl.text.trim())
          : selected!;

      setState(() => isLoadingAction = true);

      try {
        final here = context.read<RideProvider>().driverPosition ??
            dropoffCoord ??
            pickupCoord!;
        final office = await _nearestOffice(here);

        // No office configured yet → bring it back to the pickup point.
        final targetLat = (office?['lat'] as num?)?.toDouble() ??
            pickupCoord!.latitude;
        final targetLng = (office?['lng'] as num?)?.toDouble() ??
            pickupCoord!.longitude;
        final targetName = office != null
            ? [office['name'], office['address']]
                .where((e) => e != null && e.toString().trim().isNotEmpty)
                .join(' · ')
            : t.t('ret_pickup_point');

        await Supabase.instance.client.from('rides').update({
          'status': 'returning',
          'return_reason': reason,
          'return_started_at': DateTime.now().toUtc().toIso8601String(),
          'return_office_id': office?['id'],
          'return_lat': targetLat,
          'return_lng': targetLng,
          'return_address': targetName,
        }).eq('id', widget.rideId);

        if (_customerId != null) {
          unawaited(NotificationService.send(
            toUserId: _customerId!,
            type: 'ride_returning',
            title: t.t('ret_notif_title'),
            body: '${t.t('ret_notif_body')} $targetName',
            params: {'ride_id': widget.rideId},
          ));
        }

        if (!mounted) return;
        setState(() {
          _returning = true;
          _returnTarget = LatLng(targetLat, targetLng);
          _returnTargetName = targetName;
          _distanceToReturnKm = null;
          _canConfirmReturned = false;
          isLoadingAction = false;
        });
        _lastRouteFetch = null;
        await _loadRoutePath(_returnTarget!);

        if (!mounted) return;
        ErrorUI.showSnack(
          context,
          AppError(
            title: t.t('ret_started'),
            message: targetName,
            icon: Icons.keyboard_return,
          ),
        );
      } catch (e) {
        if (!mounted) return;
        setState(() => isLoadingAction = false);
        ErrorUI.showSnack(context, AppError.from(e));
      }
    } finally {
      otherCtrl.dispose();
    }
  }

  /// Driver is at the office and hands the package in.
  Future<void> _confirmReturned() async {
    final t = S.of(context);
    setState(() => isLoadingAction = true);
    try {
      await Supabase.instance.client.from('rides').update({
        'status': 'returned',
        'returned_at': DateTime.now().toUtc().toIso8601String(),
      }).eq('id', widget.rideId);

      if (_customerId != null) {
        unawaited(NotificationService.send(
          toUserId: _customerId!,
          type: 'ride_returned',
          title: t.t('ret_done_notif_title'),
          body: '${t.t('ret_done_notif_body')} $_returnTargetName',
          params: {'ride_id': widget.rideId},
        ));
      }

      _rideEnded = true;
      _cleanupListeners();
      DriverLocationService.instance.setActiveRide(null);
      if (!mounted) return;
      context.read<RideProvider>().clearTripData();
      ErrorUI.showSnack(
        context,
        AppError(
          title: t.t('ret_done'),
          message: _returnTargetName,
          icon: Icons.check_circle_outline,
        ),
      );
      Navigator.pushNamedAndRemoveUntil(context, '/driver', (route) => false);
    } catch (e) {
      if (!mounted) return;
      setState(() => isLoadingAction = false);
      ErrorUI.showSnack(context, AppError.from(e));
    }
  }

  Widget _returnStatusCard(S t) {
    final km = _distanceToReturnKm;
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.deepOrange.withValues(alpha: 0.07),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.deepOrange.withValues(alpha: 0.35)),
      ),
      child: Row(
        children: [
          const Icon(Icons.keyboard_return, color: Colors.deepOrange),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  '${t.t('ret_heading_to')} $_returnTargetName',
                  style: const TextStyle(
                      fontWeight: FontWeight.w700, fontSize: 14),
                ),
                const SizedBox(height: 2),
                Text(
                  km == null
                      ? t.t('checking_distance')
                      : _canConfirmReturned
                          ? t.t('ret_at_office')
                          : '${t.t('ret_distance_left')} ${km.toStringAsFixed(2)} km',
                  style: const TextStyle(
                      fontSize: 13.5, color: _Palette.inkMuted),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // BUILD
  // ═══════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    final t = S.of(context);
    final isRide = widget.serviceType == 'Ride';
    final rideProvider = context.watch<RideProvider>();
    final isPickupStage =
        rideProvider.currentTripState == 'en_route_to_pickup';

    final markers = <Marker>{
      ..._buildMarkers(rideProvider, isPickupStage),
      ..._reportMarkers(),
    };
    final polylines = _buildPolylines(rideProvider, isPickupStage);

    return Scaffold(
      backgroundColor: _Palette.cream,
      appBar: AppBar(
        backgroundColor: EfuridePalette.cream,
        elevation: 0,
        iconTheme: const IconThemeData(color: _Palette.ink),
        title: Text(
          _returning
              ? t.t('ret_title_bar')
              : (isPickupStage
                  ? t.t('en_route_pickup')
                  : t.t('active_transport')),
          style: const TextStyle(
              color: _Palette.ink,
              fontWeight: FontWeight.bold,
              fontSize: 17),
        ),
        automaticallyImplyLeading: false,
        actions: [
          GestureDetector(
            onLongPress: _openNavigationSheet,
            child: IconButton(
              tooltip: t.t('nav_navigate'),
              onPressed: _onNavigatePressed,
              icon: Icon(_inAppNav
                  ? Icons.navigation
                  : Icons.navigation_outlined),
            ),
          ),
          IconButton(
            tooltip: t.t('chat_with_customer'),
            onPressed: () {
              Navigator.pushNamed(
                context,
                '/chat',
                arguments: {'rideId': widget.rideId},
              );
            },
            icon: AppImage(
              AppImages.chatBubble,
              size: 22,
              fallbackIcon: Icons.chat_bubble_outline,
            ),
          ),
          IconButton(
            tooltip: tr('Call customer'),
            onPressed: _callCustomer,
            icon: const Icon(Icons.call_outlined, size: 22),
          ),
          IconButton(
            tooltip: tr('Support'),
            onPressed: () => Navigator.pushNamed(context, '/support'),
            icon: const KIcon(Icons.support_agent, size: 22),
          ),
          IconButton(
            tooltip: t.t('cancel_trip'),
            onPressed: _confirmDriverCancel,
            icon: AppImage(
              AppImages.lock,
              size: 22,
              tint: _Palette.dropoff,
              fallbackIcon: Icons.close,
            ),
          ),
          IconButton(
            tooltip: t.t('sos'),
            onPressed: () => Navigator.pushNamed(
              context,
              '/sos',
              arguments: {'role': 'driver', 'rideId': widget.rideId},
            ),
            icon: AppImage(
              AppImages.shieldInfo,
              size: 22,
              tint: _Palette.dropoff,
              fallbackIcon: Icons.sos,
            ),
          ),
        ],
      ),
      body: SafeArea(
        child: Stack(
          children: [
            // ── Full-screen map (the panel below is draggable) ──
            Positioned.fill(
              child: Padding(
                padding: EdgeInsets.zero,
                child: Stack(
                  children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(20),
                  child: GoogleMap(
                    mapType: MapType.normal,
                    initialCameraPosition: CameraPosition(
                      target: pickupCoord ??
                          rideProvider.driverPosition ??
                          const LatLng(-33.9249, 18.4241),
                      zoom: 14.0,
                    ),
                    onMapCreated: (GoogleMapController controller) {
                      if (!_mapController.isCompleted) {
                        _mapController.complete(controller);
                      }
                      _gMapController = controller;
                    },
                    markers: markers,
                    polylines: polylines,
                    myLocationEnabled: false,
                    myLocationButtonEnabled: false,
                    zoomControlsEnabled: false,
                    compassEnabled: true,
                    mapToolbarEnabled: false,
                    buildingsEnabled: true,
                    indoorViewEnabled: false,
                    trafficEnabled: _inAppNav,
                  ),
                ),
                    if (_inAppNav)
                      Positioned(
                        top: 10,
                        left: 10,
                        right: 10,
                        child: _navBanner(t),
                      ),
                    if (_inAppNav)
                      Positioned(
                        right: 12,
                        top: 140,
                        child: FloatingActionButton.small(
                          heroTag: 'road_report',
                          backgroundColor: Colors.white,
                          foregroundColor: _Palette.ink,
                          onPressed: _openReportSheet,
                          child: const Icon(Icons.campaign_outlined),
                        ),
                      ),
                  ],
                ),
              ),
            ),

            // ── Bottom panel: drag up for details, down for the map ──
            DraggableScrollableSheet(
              initialChildSize: 0.42,
              minChildSize: 0.14,
              maxChildSize: 0.88,
              snap: true,
              snapSizes: const [0.14, 0.42, 0.88],
              builder: (sheetCtx, sheetScroll) {
              return Container(
                padding: const EdgeInsets.all(20.0),
                decoration: const BoxDecoration(
                  color: Colors.white,
                  borderRadius:
                      BorderRadius.vertical(top: Radius.circular(24)),
                  boxShadow: [
                    BoxShadow(
                        color: Colors.black12,
                        blurRadius: 10,
                        offset: Offset(0, -4))
                  ],
                ),
                child: SingleChildScrollView(
                  controller: sheetScroll,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Center(
                        child: Container(
                          width: 44,
                          height: 5,
                          margin: const EdgeInsets.only(bottom: 12),
                          decoration: BoxDecoration(
                              color: _Palette.divider,
                              borderRadius: BorderRadius.circular(3)),
                        ),
                      ),
                      if (_isAdminAssigned)
                        Container(
                          margin: const EdgeInsets.only(bottom: 12),
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: const Color(0xFFEDE7F6),
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(
                                color: const Color(0xFF7E57C2),
                                width: 1.2),
                          ),
                          child: Row(
                            children: [
                              const Icon(Icons.admin_panel_settings,
                                  color: Color(0xFF5E35B1)),
                              const SizedBox(width: 10),
                              Expanded(
                                child: Text(
                                  t.t('admin_assigned_banner'),
                                  style: const TextStyle(
                                      fontWeight: FontWeight.w600,
                                      color: Color(0xFF4527A0),
                                      fontSize: 13.5),
                                ),
                              ),
                            ],
                          ),
                        ),

                      if (_customerProfile != null)
                        Container(
                          margin: const EdgeInsets.only(bottom: 12),
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: _Palette.cream,
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(color: _Palette.divider),
                          ),
                          child: Row(
                            children: [
                              GestureDetector(
                                onTap: _showCustomerPhoto,
                                child: _buildCustomerAvatar(radius: 32),
                              ),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment:
                                      CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      '${_customerProfile!['first_name'] ?? t.t('role_customer')} ${_customerProfile!['surname'] ?? ''}'
                                          .trim(),
                                      style: const TextStyle(
                                          fontWeight: FontWeight.bold,
                                          fontSize: 15),
                                    ),
                                    const SizedBox(height: 4),
                                    Row(
                                      children: [
                                        const Icon(Icons.star,
                                            color: Colors.amber, size: 14),
                                        const SizedBox(width: 4),
                                        Text(
                                          ((_customerProfile![
                                                          'average_rating'] ??
                                                      5.0) as num)
                                              .toStringAsFixed(1),
                                          style: const TextStyle(
                                              fontWeight: FontWeight.w600,
                                              fontSize: 13.5),
                                        ),
                                        const SizedBox(width: 6),
                                        Text(
                                          '(${_customerProfile!['total_ratings'] ?? 0})',
                                          style: const TextStyle(
                                              fontSize: 13,
                                              color: _Palette.inkMuted),
                                        ),
                                        const SizedBox(width: 12),
                                        const Icon(Icons.check_circle,
                                            color: _Palette.pickup,
                                            size: 14),
                                        const SizedBox(width: 4),
                                        Text(
                                          '$_customerCompletedTrips ${t.t('trips_label')}',
                                          style: const TextStyle(
                                              fontSize: 13,
                                              color: _Palette.ink,
                                              fontWeight: FontWeight.w600),
                                        ),
                                      ],
                                    ),
                                    if ('${_customerProfile!['phone_number'] ?? ''}'
                                        .isNotEmpty) ...[
                                      const SizedBox(height: 4),
                                      Row(children: [
                                        const Icon(Icons.phone,
                                            size: 14,
                                            color: _Palette.inkMuted),
                                        const SizedBox(width: 4),
                                        Text(
                                          '${_customerProfile!['phone_number']}',
                                          style: const TextStyle(
                                              fontSize: 13.5,
                                              fontWeight: FontWeight.w600),
                                        ),
                                      ]),
                                    ],
                                  ],
                                ),
                              ),
                              IconButton.filled(
                                tooltip: tr('Call customer'),
                                onPressed: _callCustomer,
                                style: IconButton.styleFrom(
                                    backgroundColor: _Palette.pickup),
                                icon: const Icon(Icons.call,
                                    color: Colors.white),
                              ),
                            ],
                          ),
                        ),

                      if (isPickupStage)
                        Container(
                          margin: const EdgeInsets.only(bottom: 12),
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: _otpVerified
                                ? _Palette.pickup.withValues(alpha: 0.08)
                                : Colors.orange.shade50,
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(
                              color: _otpVerified
                                  ? _Palette.pickup.withValues(alpha: 0.4)
                                  : Colors.orange.shade300,
                            ),
                          ),
                          child: Row(
                            children: [
                              AppImage(
                                _otpVerified
                                    ? AppImages.shieldCheck
                                    : AppImages.shieldInfo,
                                size: 24,
                                tint: _otpVerified
                                    ? _Palette.pickup
                                    : Colors.orange,
                                fallbackIcon: _otpVerified
                                    ? Icons.verified
                                    : Icons.shield_outlined,
                              ),
                              const SizedBox(width: 10),
                              Expanded(
                                child: Text(
                                  _otpVerified
                                      ? t.t('otp_verified_banner')
                                      : t.t('otp_need_code'),
                                  style: TextStyle(
                                    fontWeight: FontWeight.w600,
                                    color: _otpVerified
                                        ? _Palette.pickup
                                        : Colors.orange.shade800,
                                    fontSize: 13.5,
                                  ),
                                ),
                              ),
                              if (!_otpVerified)
                                TextButton(
                                  onPressed: _showOtpDialog,
                                  child: Text(t.t('enter_code')),
                                ),
                            ],
                          ),
                        ),

                      Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: _Palette.blue.withValues(alpha: 0.08),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Row(
                          children: [
                            AppImage(
                              isRide
                                  ? AppImages.driverSedan
                                  : AppImages.deliveryTruck,
                              size: 40,
                              fallbackIcon: isRide
                                  ? Icons.directions_car_filled
                                  : Icons.local_shipping,
                            ),
                            const SizedBox(width: 16),
                            Expanded(
                              child: Column(
                                crossAxisAlignment:
                                    CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    isPickupStage
                                        ? t.t('en_route_pickup')
                                        : t.t('active_transport'),
                                    style: const TextStyle(
                                        fontSize: 16,
                                        fontWeight: FontWeight.bold),
                                  ),
                                  const SizedBox(height: 4),
                                  Text(
                                    isPickupStage
                                        ? t.t('navigate_pickup')
                                        : (isRide
                                            ? t.t('safely_transport')
                                            : t.t('safely_deliver_pkg')),
                                    style: const TextStyle(
                                        color: _Palette.inkMuted,
                                        fontSize: 14),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),

                      if (tripDistanceKm != null && tripDistanceKm! > 0) ...[
                        const SizedBox(height: 10),
                        Row(
                          children: [
                            AppImage(
                              AppImages.mapPin,
                              size: 16,
                              tint: _Palette.inkMuted,
                              fallbackIcon: Icons.straighten,
                            ),
                            const SizedBox(width: 6),
                            Text(
                              '${t.t('trip_distance')} ${tripDistanceKm!.toStringAsFixed(1)} km',
                              style: const TextStyle(
                                  color: _Palette.inkMuted,
                                  fontSize: 14,
                                  fontWeight: FontWeight.w600),
                            ),
                          ],
                        ),
                      ],
                      const SizedBox(height: 14),

                      // ── Navigate (remembered app) + change ──
                      Row(
                        children: [
                          Expanded(
                            child: OutlinedButton.icon(
                              style: OutlinedButton.styleFrom(
                                foregroundColor: _Palette.blue,
                                side: const BorderSide(color: _Palette.blue),
                                padding:
                                    const EdgeInsets.symmetric(vertical: 12),
                              ),
                              onPressed: _onNavigatePressed,
                              icon: const Icon(Icons.navigation_outlined),
                              label: Text(
                                _preferredNav == null
                                    ? t.t('nav_navigate')
                                    : '${t.t('nav_with')} ${_navAppName(t, _preferredNav!)}',
                                style: const TextStyle(
                                    fontWeight: FontWeight.bold),
                              ),
                            ),
                          ),
                          if (_preferredNav != null)
                            TextButton(
                              onPressed: _openNavigationSheet,
                              child: Text(t.t('nav_change')),
                            ),
                        ],
                      ),
                      const SizedBox(height: 14),

                      isLoadingAction
                          ? const Center(
                              child: CircularProgressIndicator())
                          : Column(
                              crossAxisAlignment: CrossAxisAlignment.stretch,
                              children: [
                                if (isPickupStage) ...[
                                  if (!_otpVerified)
                                    OutlinedButton.icon(
                                      style: OutlinedButton.styleFrom(
                                        foregroundColor: _Palette.blue,
                                        side: const BorderSide(
                                            color: _Palette.blue),
                                        padding: const EdgeInsets.symmetric(
                                            vertical: 14),
                                      ),
                                      onPressed: _showOtpDialog,
                                      icon: const KIcon(Icons.shield_outlined),
                                      label: Text(
                                          t.t('enter_pickup_code'),
                                          style: const TextStyle(
                                              fontWeight: FontWeight.bold)),
                                    ),
                                  if (!_otpVerified)
                                    const SizedBox(height: 8),
                                  ElevatedButton.icon(
                                    style: ElevatedButton.styleFrom(
                                      backgroundColor: _otpVerified
                                          ? _Palette.accent
                                          : Colors.grey,
                                      foregroundColor: _otpVerified
                                          ? _Palette.accentInk
                                          : Colors.white,
                                      padding: const EdgeInsets.symmetric(
                                          vertical: 16),
                                    ),
                                    onPressed: _otpVerified
                                        ? () =>
                                            _updateTripStatus('in_progress')
                                        : null,
                                    icon: const Icon(Icons.play_arrow),
                                    label: Text(
                                      isRide
                                          ? t.t('picked_up_ride')
                                          : t.t('picked_up_delivery'),
                                      style: const TextStyle(
                                          fontSize: 16,
                                          fontWeight: FontWeight.bold),
                                    ),
                                  ),
                                ],
                                if (_returning) ...[
                                  _returnStatusCard(t),
                                  const SizedBox(height: 12),
                                  ElevatedButton.icon(
                                    style: ElevatedButton.styleFrom(
                                      backgroundColor: _canConfirmReturned
                                          ? Colors.deepOrange
                                          : Colors.grey,
                                      foregroundColor: Colors.white,
                                      padding: const EdgeInsets.symmetric(
                                          vertical: 16),
                                    ),
                                    onPressed: _canConfirmReturned
                                        ? _confirmReturned
                                        : null,
                                    icon: const KIcon(Icons.inventory_2),
                                    label: Text(
                                      t.t('ret_confirm_done'),
                                      style: const TextStyle(
                                          fontSize: 16,
                                          fontWeight: FontWeight.bold),
                                    ),
                                  ),
                                ],
                                if (!isPickupStage && !_returning) ...[
                                  if (_isDeliveryJob) ...[
                                    OutlinedButton.icon(
                                      style: OutlinedButton.styleFrom(
                                        foregroundColor: _Palette.accent,
                                        side: BorderSide(
                                            color: _canReturn
                                                ? _Palette.accent
                                                : _Palette.divider),
                                        padding: const EdgeInsets.symmetric(
                                            vertical: 14),
                                      ),
                                      onPressed:
                                          _canReturn ? _confirmReturn : null,
                                      icon: const Icon(Icons.keyboard_return),
                                      label: Text(
                                        t.t('ret_button'),
                                        style: const TextStyle(
                                            fontWeight: FontWeight.bold),
                                      ),
                                    ),
                                    if (!_canReturn)
                                      Padding(
                                        padding: const EdgeInsets.only(top: 4),
                                        child: Text(
                                          t.t('ret_available_on_arrival'),
                                          textAlign: TextAlign.center,
                                          style: const TextStyle(
                                              fontSize: 13,
                                              color: _Palette.inkMuted),
                                        ),
                                      ),
                                    const SizedBox(height: 12),
                                  ],
                                  Container(
                                    padding: const EdgeInsets.all(10),
                                    decoration: BoxDecoration(
                                      color: _canCompleteTrip
                                          ? _Palette.pickup
                                              .withValues(alpha: 0.08)
                                          : Colors.orange.shade50,
                                      borderRadius: BorderRadius.circular(10),
                                      border: Border.all(
                                        color: _canCompleteTrip
                                            ? _Palette.pickup
                                                .withValues(alpha: 0.4)
                                            : Colors.orange.shade200,
                                      ),
                                    ),
                                    child: Row(
                                      children: [
                                        Icon(
                                          _canCompleteTrip
                                              ? Icons.check_circle_outline
                                              : Icons.info_outline,
                                          color: _canCompleteTrip
                                              ? _Palette.pickup
                                              : Colors.orange.shade700,
                                          size: 18,
                                        ),
                                        const SizedBox(width: 8),
                                        Expanded(
                                          child: Text(
                                            _distanceToDropoffKm == null
                                                ? t.t('checking_distance')
                                                : _canCompleteTrip
                                                    ? t.t('within_range')
                                                    : '${t.t('move_within_1km')} (${_distanceToDropoffKm!.toStringAsFixed(2)} km)',
                                            style: TextStyle(
                                                fontSize: 13.5,
                                                fontWeight: FontWeight.w600,
                                                color: _canCompleteTrip
                                                    ? _Palette.pickup
                                                    : Colors.orange.shade800),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  const SizedBox(height: 12),
                                  ElevatedButton.icon(
                                    style: ElevatedButton.styleFrom(
                                      backgroundColor: _canCompleteTrip
                                          ? _Palette.pickup
                                          : Colors.grey,
                                      foregroundColor: Colors.white,
                                      padding: const EdgeInsets.symmetric(
                                          vertical: 16),
                                    ),
                                    onPressed: _canCompleteTrip
                                        ? () =>
                                            _updateTripStatus('completed')
                                        : null,
                                    icon: const Icon(Icons.check_circle),
                                    label: Text(
                                      isRide
                                          ? t.t('complete_trip')
                                          : t.t('confirm_dropoff'),
                                      style: const TextStyle(
                                          fontSize: 16,
                                          fontWeight: FontWeight.bold),
                                    ),
                                  ),
                                ],
                              ],
                            ),
                      const SizedBox(height: 20),
                    ],
                  ),
                ),
              );
              },
            ),
          ],
        ),
      ),
    );
  }
}
