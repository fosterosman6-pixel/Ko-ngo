// lib/screens/driver/driver_week_card.dart
//
// "This week": trips, earnings and rating, with a comparison to last week.
// Works from the driver's own completed rides (Monday to Sunday). Money is
// the trip fare, the same figure the home screen shows for today.

import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'package:efuride_app/config/country_config.dart';
import 'package:efuride_app/config/efuride_palette.dart';
import 'package:efuride_app/l10n/app_strings.dart';

class DriverWeekCard extends StatefulWidget {
  const DriverWeekCard({super.key});

  @override
  State<DriverWeekCard> createState() => _DriverWeekCardState();
}

class _DriverWeekCardState extends State<DriverWeekCard> {
  int _trips = 0, _lastTrips = 0;
  double _earned = 0, _lastEarned = 0;
  double? _rating;
  bool _loaded = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final db = Supabase.instance.client;
      final uid = db.auth.currentUser?.id;
      if (uid == null) return;

      final now = DateTime.now();
      final monday = DateTime(now.year, now.month, now.day)
          .subtract(Duration(days: now.weekday - 1));
      final lastMonday = monday.subtract(const Duration(days: 7));

      final rows = await db
          .from('rides')
          .select('fare, created_at')
          .eq('driver_id', uid)
          .eq('status', 'completed')
          .gte('created_at', lastMonday.toUtc().toIso8601String())
          .limit(2000)
          .timeout(const Duration(seconds: 12));

      var t = 0, lt = 0;
      var e = 0.0, le = 0.0;
      for (final r in rows) {
        final at = DateTime.tryParse('${r['created_at']}')?.toLocal();
        if (at == null) continue;
        final fare = (r['fare'] as num?)?.toDouble() ?? 0;
        if (!at.isBefore(monday)) {
          t++;
          e += fare;
        } else {
          lt++;
          le += fare;
        }
      }

      double? rating;
      try {
        final me = await db
            .from('profiles')
            .select('average_rating')
            .eq('id', uid)
            .maybeSingle();
        rating = (me?['average_rating'] as num?)?.toDouble();
      } catch (_) {}

      if (!mounted) return;
      setState(() {
        _trips = t;
        _lastTrips = lt;
        _earned = e;
        _lastEarned = le;
        _rating = rating;
        _loaded = true;
      });
    } catch (_) {
      // No connection: simply do not show the card.
    }
  }

  Widget _change() {
    if (_lastEarned <= 0 && _earned <= 0) return const SizedBox.shrink();
    String text;
    Color color;
    IconData icon;
    if (_lastEarned <= 0) {
      return const SizedBox.shrink();
    }
    final pct = ((_earned - _lastEarned) / _lastEarned * 100).round();
    if (pct > 0) {
      text = tr('Up {0}% on last week', ['$pct']);
      color = const Color(0xFF16A34A);
      icon = Icons.trending_up;
    } else if (pct < 0) {
      text = tr('Down {0}% on last week', ['${-pct}']);
      color = const Color(0xFFB91C1C);
      icon = Icons.trending_down;
    } else {
      text = tr('Same as last week');
      color = EfuridePalette.inkMuted;
      icon = Icons.trending_flat;
    }
    return Padding(
      padding: const EdgeInsets.only(top: 10),
      child: Row(
        children: [
          Icon(icon, size: 18, color: color),
          const SizedBox(width: 6),
          Text(text,
              style: TextStyle(
                  fontSize: 13.5, fontWeight: FontWeight.w700, color: color)),
        ],
      ),
    );
  }

  Widget _stat(String label, String value) {
    return Expanded(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label,
              style: const TextStyle(
                  fontSize: 12.5, color: EfuridePalette.inkMuted)),
          const SizedBox(height: 2),
          Text(value,
              style: const TextStyle(
                  fontSize: 19,
                  fontWeight: FontWeight.w900,
                  color: EfuridePalette.ink)),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (!_loaded) return const SizedBox.shrink();
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: const Color(0xFFE8E2D5)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(tr('This week'),
                style: const TextStyle(
                    fontSize: 15.5,
                    fontWeight: FontWeight.w800,
                    color: EfuridePalette.ink)),
            const SizedBox(height: 10),
            Row(
              children: [
                _stat(tr('Trips'), '$_trips'),
                _stat(tr('Earnings'), CountryConfig.money(_earned)),
                _stat(tr('Rating'),
                    _rating == null ? '–' : _rating!.toStringAsFixed(1)),
              ],
            ),
            _change(),
            if (_trips == 0 && _lastTrips == 0)
              Padding(
                padding: const EdgeInsets.only(top: 10),
                child: Text(tr('No trips yet this week'),
                    style: const TextStyle(
                        fontSize: 13.5, color: EfuridePalette.inkMuted)),
              ),
          ],
        ),
      ),
    );
  }
}
