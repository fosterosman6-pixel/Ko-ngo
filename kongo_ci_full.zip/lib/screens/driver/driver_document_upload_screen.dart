﻿// lib/screens/driver/driver_document_upload_screen.dart

import 'package:efuride_app/widgets/private_image.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:efuride_app/config/app_images.dart';
import 'package:efuride_app/widgets/app_image.dart';
import 'package:efuride_app/utils/app_error.dart';
import 'package:efuride_app/utils/error_ui.dart';
import 'package:efuride_app/l10n/app_strings.dart';

class _Palette {
  static const cream = Color(0xFFFAF6EE);
  static const ink = Color(0xFF1A1A1A);
  static const inkMuted = Color(0xFF575047);
  static const accent = Color(0xFFF2B705);
  static const divider = Color(0xFFE8E2D5);
  static const blue = Color(0xFF1E88E5);
  static const pickup = Color(0xFF34C759);
  static const dropoff = Color(0xFFE53935);
}

class DriverDocumentUploadScreen extends StatefulWidget {
  const DriverDocumentUploadScreen({super.key});

  @override
  State<DriverDocumentUploadScreen> createState() =>
      _DriverDocumentUploadScreenState();
}

class _DriverDocumentUploadScreenState
    extends State<DriverDocumentUploadScreen> {
  final _picker = ImagePicker();

  final Map<String, Map<String, dynamic>> _docs = {
    'id_card': {
      'label': 'National ID / Passport',
      'status': 'Not Uploaded',
      'url': null,
      'busy': false,
    },
    'license': {
      'label': 'Driving Licence / Permits',
      'status': 'Not Uploaded',
      'url': null,
      'busy': false,
    },
    'logbook': {
      'label': 'Vehicle/Bike Logbook & Insurance',
      'status': 'Not Uploaded',
      'url': null,
      'busy': false,
    },
  };

  bool _isLoading = true;
  bool _isSubmitting = false;
  AppError? _error;

  @override
  void initState() {
    super.initState();
    _loadExistingDocs();
  }

  Future<void> _loadExistingDocs() async {
    setState(() {
      _isLoading = true;
      _error = null;
    });
    try {
      final userId = Supabase.instance.client.auth.currentUser?.id;
      if (userId == null) {
        if (mounted) setState(() => _isLoading = false);
        return;
      }

      final rows = await Supabase.instance.client
          .from('documents')
          .select('type, status, file_url')
          .eq('user_id', userId)
          .timeout(const Duration(seconds: 15));

      for (var row in rows) {
        final type = (row['type'] ?? '').toString();
        if (_docs.containsKey(type)) {
          _docs[type]!['status'] = row['status'] ?? 'Uploaded';
          _docs[type]!['url'] = row['file_url'];
        }
      }

      if (mounted) setState(() => _isLoading = false);
    } catch (e) {
      debugPrint('Error loading docs: $e');
      if (!mounted) return;
      setState(() {
        _isLoading = false;
        _error = AppError.from(e, onRetry: _loadExistingDocs);
      });
    }
  }

  Future<void> _pickAndUpload(String type) async {
    final info = _docs[type]!;
    if (info['busy'] == true) return;

    setState(() => info['busy'] = true);

    try {
      final XFile? image = await _picker.pickImage(
        source: ImageSource.gallery,
        maxWidth: 1600,
        maxHeight: 1600,
        imageQuality: 80,
      );

      if (image == null) {
        if (mounted) setState(() => info['busy'] = false);
        return;
      }

      final userId = Supabase.instance.client.auth.currentUser?.id;
      if (userId == null) throw Exception('Not signed in');

      final bytes = await image.readAsBytes();
      final fileExt =
          image.name.contains('.') ? image.name.split('.').last : 'jpg';
      final storagePath =
          '$userId/$type-${DateTime.now().millisecondsSinceEpoch}.$fileExt';

      await Supabase.instance.client.storage
          .from('driver_documents')
          .uploadBinary(
            storagePath,
            bytes,
            fileOptions: const FileOptions(upsert: true),
          );

      final publicUrl = Supabase.instance.client.storage
          .from('driver_documents')
          .getPublicUrl(storagePath);

      final existing = await Supabase.instance.client
          .from('documents')
          .select('id')
          .eq('user_id', userId)
          .eq('type', type)
          .maybeSingle();

      if (existing == null) {
        await Supabase.instance.client.from('documents').insert({
          'user_id': userId,
          'type': type,
          'name': info['label'],
          'file_url': publicUrl,
          'status': 'Pending',
          'created_at': DateTime.now().toUtc().toIso8601String(),
        });
      } else {
        await Supabase.instance.client.from('documents').update({
          'file_url': publicUrl,
          'status': 'Pending',
          'created_at': DateTime.now().toUtc().toIso8601String(),
        }).eq('id', existing['id']);
      }

      if (!mounted) return;
      setState(() {
        info['busy'] = false;
        info['status'] = 'Pending';
        info['url'] = publicUrl;
      });

      ErrorUI.showSnack(
        context,
        AppError(
          title: tr('Uploaded'),
          message: '${info['label']} uploaded successfully.',
          icon: Icons.check_circle_outline,
        ),
      );
    } catch (e) {
      debugPrint('Upload failed: $e');
      if (!mounted) return;
      setState(() => info['busy'] = false);
      ErrorUI.showSnack(
        context,
        AppError.from(e, onRetry: () => _pickAndUpload(type)),
      );
    }
  }

  void _submitForApproval() {
    final uploaded = _docs.values
        .where((d) => (d['url'] as String?)?.isNotEmpty == true)
        .length;

    if (uploaded < _docs.length) {
      ErrorUI.showSnack(
        context,
        AppError(
          title: tr('Missing documents'),
          message: tr('Please upload all required documents first.'),
          icon: Icons.info_outline,
        ),
      );
      return;
    }

    setState(() => _isSubmitting = true);
    Future.delayed(const Duration(milliseconds: 600), () {
      if (!mounted) return;
      setState(() => _isSubmitting = false);
      Navigator.pop(context, true);
    });
  }

  void _previewDocument(String? url, String label) {
    if (url == null || url.isEmpty) return;
    showDialog(
      context: context,
      builder: (_) => Dialog(
        backgroundColor: Colors.black87,
        insetPadding: const EdgeInsets.all(12),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Padding(
              padding: const EdgeInsets.all(12),
              child: Text(label,
                  style: const TextStyle(
                      color: Colors.white,
                      fontSize: 16,
                      fontWeight: FontWeight.bold)),
            ),
            Flexible(
              child: InteractiveViewer(
                child: PrivateImage(
                  url: url,
                  fit: BoxFit.contain,
                  errorBuilder: (_, __, ___) => Padding(
                    padding: EdgeInsets.all(24),
                    child: Text(tr('Could not load preview'),
                        style: TextStyle(color: Colors.white70)),
                  ),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(12),
              child: TextButton.icon(
                onPressed: () => Navigator.pop(context),
                icon: const Icon(Icons.close, color: Colors.white),
                label: Text(tr('Close'),
                    style: TextStyle(color: Colors.white)),
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _Palette.cream,
      appBar: AppBar(
        backgroundColor: _Palette.cream,
        elevation: 0,
        iconTheme: const IconThemeData(color: _Palette.ink),
        title: Text(
          tr('KYC documents'),
          style: TextStyle(
              color: _Palette.ink,
              fontWeight: FontWeight.bold,
              fontSize: 18),
        ),
      ),
      body: _isLoading
          ? const Center(
              child: CircularProgressIndicator(color: _Palette.accent))
          : _error != null
              ? ErrorUI.inline(_error!)
              : SafeArea(
                  child: Padding(
                    padding: const EdgeInsets.all(20.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Text(tr('Step 1 · Upload your documents'),
                            style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                                color: _Palette.ink)),
                        const SizedBox(height: 4),
                        Text(
                          tr('Drivers and couriers must complete KYC documentation.'),
                          style: TextStyle(
                              color: _Palette.inkMuted, fontSize: 14),
                        ),
                        const SizedBox(height: 16),
                        Expanded(
                          child: ListView(
                            children: _docs.entries.map((entry) {
                              return Padding(
                                padding: const EdgeInsets.only(bottom: 10),
                                child: _buildDocTile(
                                  type: entry.key,
                                  info: entry.value,
                                ),
                              );
                            }).toList(),
                          ),
                        ),
                        const SizedBox(height: 12),
                        _isSubmitting
                            ? const Center(
                                child: CircularProgressIndicator(
                                    color: _Palette.accent))
                            : ElevatedButton(
                                onPressed: _submitForApproval,
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: const Color(0xFFF2B705),
                                  foregroundColor: const Color(0xFF0B1220),
                                  padding: const EdgeInsets.symmetric(
                                      vertical: 14),
                                  shape: RoundedRectangleBorder(
                                      borderRadius:
                                          BorderRadius.circular(12)),
                                ),
                                child: Text(
                                    tr('Save & continue to vehicle')),
                              ),
                      ],
                    ),
                  ),
                ),
    );
  }

  Widget _buildDocTile({
    required String type,
    required Map<String, dynamic> info,
  }) {
    final url = info['url'] as String?;
    final status = info['status'] as String;
    final busy = info['busy'] as bool;
    final label = info['label'] as String;

    // Asset/fallback that matches the status.
    String? asset;
    IconData statusIcon;
    Color statusColor;

    switch (status.toLowerCase()) {
      case 'verified':
        asset = AppImages.shieldCheck;
        statusColor = _Palette.pickup;
        statusIcon = Icons.verified_user;
        break;
      case 'rejected':
        asset = null;
        statusColor = _Palette.dropoff;
        statusIcon = Icons.cancel;
        break;
      case 'pending':
        asset = null;
        statusColor = Colors.orange;
        statusIcon = Icons.pending;
        break;
      default:
        asset = AppImages.shieldInfo;
        statusColor = _Palette.inkMuted;
        statusIcon = Icons.upload_file;
    }

    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: _Palette.divider),
      ),
      child: Row(
        children: [
          asset != null
              ? AppImage(
                  asset,
                  size: 28,
                  tint: status.toLowerCase() == 'not uploaded'
                      ? null
                      : statusColor,
                  fallbackIcon: statusIcon,
                )
              : Icon(statusIcon, color: statusColor, size: 28),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(label,
                    style: const TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 14,
                        color: _Palette.ink)),
                const SizedBox(height: 2),
                Text(status,
                    style: TextStyle(
                        color: statusColor,
                        fontSize: 13,
                        fontWeight: FontWeight.w500)),
              ],
            ),
          ),
          if (url != null)
            IconButton(
              icon: const Icon(Icons.visibility, color: _Palette.blue),
              tooltip: tr('View uploaded file'),
              onPressed: () => _previewDocument(url, label),
            ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: url == null
                  ? _Palette.blue
                  : _Palette.cream,
              foregroundColor:
                  url == null ? Colors.white : _Palette.ink,
              padding:
                  const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8)),
            ),
            onPressed: busy ? null : () => _pickAndUpload(type),
            child: busy
                ? const SizedBox(
                    width: 16,
                    height: 16,
                    child: CircularProgressIndicator(
                        strokeWidth: 2, color: Colors.white))
                : Text(url == null ? 'Upload' : 'Change',
                    style: const TextStyle(fontSize: 13.5)),
          ),
        ],
      ),
    );
  }
}
