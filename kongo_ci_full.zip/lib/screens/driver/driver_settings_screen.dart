// lib/screens/driver/driver_settings_screen.dart

import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:efuride_app/config/app_images.dart';
import 'package:efuride_app/l10n/app_strings.dart';
import 'package:efuride_app/config/readability.dart';
import 'package:efuride_app/widgets/text_size_sheet.dart';
import 'package:efuride_app/main.dart' show appLanguageNotifier;
import 'package:efuride_app/widgets/app_image.dart';
import 'package:efuride_app/services/driver_location_service.dart';
import 'package:efuride_app/services/notification_service.dart';
import 'package:efuride_app/services/ring_launcher.dart';
import 'package:efuride_app/utils/app_error.dart';
import 'package:efuride_app/utils/error_ui.dart';

class _Palette {
  static const cream = Color(0xFFFAF6EE);
  static const ink = Color(0xFF1A1A1A);
  static const inkMuted = Color(0xFF575047);
  static const accent = Color(0xFFF2B705);
  static const divider = Color(0xFFE8E2D5);
  static const blue = Color(0xFF1E88E5);
  static const pickup = Color(0xFF34C759);
  static const danger = Color(0xFFE53935);
}

class DriverSettingsScreen extends StatefulWidget {
  const DriverSettingsScreen({super.key});

  @override
  State<DriverSettingsScreen> createState() =>
      _DriverSettingsScreenState();
}

class _DriverSettingsScreenState extends State<DriverSettingsScreen> {
  bool _isLoading = true;
  bool _isLoggingOut = false;

  // Preferences (all persisted on profiles).
  String _language = 'en';
  bool _pushRideRequests = true;
  bool _pushChats = true;
  bool _pushPromotions = false;
  bool _pushPayouts = true;
  bool _ringSoundEnabled = true;
  String _navApp = 'google'; // 'google' | 'waze' | 'in_app'

  @override
  void initState() {
    super.initState();
    _loadPreferences();
  }

  Future<void> _loadPreferences() async {
    try {
      final userId = Supabase.instance.client.auth.currentUser?.id;
      if (userId == null) {
        if (mounted) setState(() => _isLoading = false);
        return;
      }
      // Some columns may not exist yet on older installs; guard each one.
      final row = await Supabase.instance.client
          .from('profiles')
          .select(
            'language, '
            'push_ride_requests, push_chats, push_promotions, push_payouts, '
            'ring_sound_enabled, nav_app',
          )
          .eq('id', userId)
          .maybeSingle();

      if (!mounted) return;
      setState(() {
        _language = (row?['language'] ?? 'en').toString();
        _pushRideRequests =
            row?['push_ride_requests'] as bool? ?? true;
        _pushChats = row?['push_chats'] as bool? ?? true;
        _pushPromotions = row?['push_promotions'] as bool? ?? false;
        _pushPayouts = row?['push_payouts'] as bool? ?? true;
        _ringSoundEnabled =
            row?['ring_sound_enabled'] as bool? ?? true;
        _navApp = (row?['nav_app'] ?? 'google').toString();
        _isLoading = false;
      });
    } catch (e) {
      // Column missing → fall back to defaults instead of breaking the
      // screen. Driver still gets to use everything below.
      debugPrint('loadPreferences failed (using defaults): $e');
      if (mounted) setState(() => _isLoading = false);
    }
  }

  Future<void> _savePreference(String key, dynamic value) async {
    final userId = Supabase.instance.client.auth.currentUser?.id;
    if (userId == null) return;
    try {
      await Supabase.instance.client
          .from('profiles')
          .update({key: value}).eq('id', userId);
    } catch (e) {
      debugPrint('savePreference($key) failed: $e');
      if (!mounted) return;
      ErrorUI.showSnack(
        context,
        AppError(
          title: tr('Couldn\'t save'),
          message: tr('Check your connection and try again.'),
          icon: Icons.cloud_off_outlined,
        ),
      );
    }
  }

  // ============================================================
  // COMMUNICATION — driver-specific toggles
  // ============================================================
  void _openCommunication() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (_) => StatefulBuilder(
        builder: (ctx, setSheet) {
          Widget toggleRow({
            required String title,
            required String subtitle,
            required bool value,
            required ValueChanged<bool> onChanged,
          }) {
            return Padding(
              padding: const EdgeInsets.symmetric(
                  horizontal: 20, vertical: 10),
              child: Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(title,
                            style: const TextStyle(
                                fontSize: 15,
                                fontWeight: FontWeight.w600,
                                color: _Palette.ink)),
                        const SizedBox(height: 2),
                        Text(subtitle,
                            style: const TextStyle(
                                fontSize: 13.5,
                                color: _Palette.inkMuted,
                                height: 1.3)),
                      ],
                    ),
                  ),
                  Switch.adaptive(
                    value: value,
                    activeColor: _Palette.pickup,
                    onChanged: onChanged,
                  ),
                ],
              ),
            );
          }

          return SafeArea(
            child: Padding(
              padding: const EdgeInsets.only(top: 16, bottom: 24),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Center(
                    child: Container(
                      width: 40,
                      height: 4,
                      decoration: BoxDecoration(
                        color: Colors.grey.shade300,
                        borderRadius: BorderRadius.circular(2),
                      ),
                    ),
                  ),
                  const SizedBox(height: 20),
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: 20),
                    child: Text(
                      tr('Notifications'),
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: _Palette.ink,
                      ),
                    ),
                  ),
                  const SizedBox(height: 4),
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: 20),
                    child: Text(
                      tr('Control what alerts you receive while you\'re online.'),
                      style: TextStyle(
                          fontSize: 13.5, color: _Palette.inkMuted),
                    ),
                  ),
                  const SizedBox(height: 16),
                  toggleRow(
                    title: tr('New ride requests'),
                    subtitle:
                        tr('Ring + push when a customer books nearby. Turn off and you won\'t see new rides.'),
                    value: _pushRideRequests,
                    onChanged: (v) async {
                      setSheet(() => _pushRideRequests = v);
                      setState(() {});
                      await _savePreference('push_ride_requests', v);
                    },
                  ),
                  toggleRow(
                    title: tr('Chat messages'),
                    subtitle:
                        tr('Messages from customers during an active trip.'),
                    value: _pushChats,
                    onChanged: (v) async {
                      setSheet(() => _pushChats = v);
                      setState(() {});
                      await _savePreference('push_chats', v);
                    },
                  ),
                  toggleRow(
                    title: tr('Promotions and bonuses'),
                    subtitle:
                        tr('Peak-hour bonuses, referral rewards, and ko!ngo news.'),
                    value: _pushPromotions,
                    onChanged: (v) async {
                      setSheet(() => _pushPromotions = v);
                      setState(() {});
                      await _savePreference('push_promotions', v);
                    },
                  ),
                  toggleRow(
                    title: tr('Payout confirmations'),
                    subtitle:
                        tr('When a payout is processed or rejected.'),
                    value: _pushPayouts,
                    onChanged: (v) async {
                      setSheet(() => _pushPayouts = v);
                      setState(() {});
                      await _savePreference('push_payouts', v);
                    },
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 20, vertical: 10),
                    child: Row(
                      children: [
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(tr('Pop-up over other apps'),
                                  style: const TextStyle(
                                      fontSize: 16,
                                      fontWeight: FontWeight.w700)),
                              const SizedBox(height: 2),
                              Text(
                                tr('Lets a ride request open ko!ngo on top of other apps. Switch it on for ko!ngo on the page that opens.'),
                                style: const TextStyle(
                                    fontSize: 13.5,
                                    color: _Palette.inkMuted),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(width: 12),
                        OutlinedButton(
                          onPressed: RingLauncher.openOverlaySettings,
                          child: Text(tr('Open settings')),
                        ),
                      ],
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 20, vertical: 10),
                    child: Row(
                      children: [
                        Expanded(
                          child: Text(
                            tr('Not ringing? See what happened to the last request on this phone.'),
                            style: const TextStyle(
                                fontSize: 13.5, color: _Palette.inkMuted),
                          ),
                        ),
                        const SizedBox(width: 12),
                        OutlinedButton(
                          onPressed: () async {
                            final lines = await PushDiag.read();
                            var tokenEnd = 'unknown';
                            var allowed = 'unknown';
                            try {
                              final t =
                                  await FirebaseMessaging.instance.getToken();
                              if (t != null && t.length > 10) {
                                tokenEnd = t.substring(t.length - 10);
                              }
                              final st = await FirebaseMessaging.instance
                                  .getNotificationSettings();
                              allowed = st.authorizationStatus.name;
                            } catch (e) {
                              tokenEnd = 'error: $e';
                            }
                            if (!mounted) return;
                            showDialog<void>(
                              context: context,
                              builder: (ctx) => AlertDialog(
                                title: Text(tr('Check last ring')),
                                content: SingleChildScrollView(
                                  child: Text(
                                    'Build: ring-check 3\n'
                                    'Push address ends: $tokenEnd\n'
                                    'Notifications: $allowed\n\n'
                                    '${lines.isEmpty ? tr('No ring has reached this phone yet.') : lines.reversed.join('\n')}',
                                    style: const TextStyle(fontSize: 14),
                                  ),
                                ),
                                actions: [
                                  TextButton(
                                    onPressed: () => Navigator.pop(ctx),
                                    child: Text(tr('Close')),
                                  ),
                                ],
                              ),
                            );
                          },
                          child: Text(tr('Check last ring')),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  // ============================================================
  // SOUND & ALERTS
  // ============================================================
  void _openSound() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (_) => StatefulBuilder(
        builder: (ctx, setSheet) => SafeArea(
          child: Padding(
            padding: const EdgeInsets.only(top: 16, bottom: 24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Center(
                  child: Container(
                    width: 40,
                    height: 4,
                    decoration: BoxDecoration(
                      color: Colors.grey.shade300,
                      borderRadius: BorderRadius.circular(2),
                    ),
                  ),
                ),
                const SizedBox(height: 20),
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 20),
                  child: Text(
                    tr('Sound & alerts'),
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: _Palette.ink,
                    ),
                  ),
                ),
                const SizedBox(height: 4),
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 20),
                  child: Text(
                    tr('Control how new ride requests interrupt you.'),
                    style: TextStyle(
                        fontSize: 13.5, color: _Palette.inkMuted),
                  ),
                ),
                const SizedBox(height: 16),
                Padding(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 20, vertical: 10),
                  child: Row(
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(tr('Ring sound'),
                                style: TextStyle(
                                    fontSize: 15,
                                    fontWeight: FontWeight.w600,
                                    color: _Palette.ink)),
                            SizedBox(height: 2),
                            Text(
                              tr('Play an audible alert when a new ride comes in.'),
                              style: TextStyle(
                                  fontSize: 13.5,
                                  color: _Palette.inkMuted,
                                  height: 1.3),
                            ),
                          ],
                        ),
                      ),
                      Switch.adaptive(
                        value: _ringSoundEnabled,
                        activeColor: _Palette.pickup,
                        onChanged: (v) async {
                          setSheet(() => _ringSoundEnabled = v);
                          setState(() {});
                          await _savePreference('ring_sound_enabled', v);
                        },
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 8),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: _Palette.accent.withValues(alpha: 0.10),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                          color:
                              _Palette.accent.withValues(alpha: 0.35)),
                    ),
                    child: Row(
                      children: [
                        Icon(Icons.volume_off_outlined,
                            size: 18, color: Color(0xFF7A5A00)),
                        SizedBox(width: 10),
                        Expanded(
                          child: Text(
                            tr('Even with sound off, the full-screen ring still appears so you won\'t miss a ride.'),
                            style: TextStyle(
                                fontSize: 13,
                                color: Color(0xFF7A5A00),
                                height: 1.4),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ============================================================
  // NAVIGATION APP
  // ============================================================
  void _openNavigation() {
    const options = [
      {
        'value': 'google',
        'label': 'Google Maps',
        'subtitle': 'Turn-by-turn with live traffic',
      },
      {
        'value': 'waze',
        'label': 'Waze',
        'subtitle': 'Community-reported hazards',
      },
      {
        'value': 'in_app',
        'label': 'ko!ngo in-app',
        'subtitle': 'Map-only view inside the app',
      },
    ];

    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (ctx) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.only(top: 16, bottom: 24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: Colors.grey.shade300,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
              const SizedBox(height: 20),
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 20),
                child: Text(
                  tr('Navigation app'),
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: _Palette.ink,
                  ),
                ),
              ),
              const SizedBox(height: 4),
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 20),
                child: Text(
                  tr('Which app should open when you tap "Start trip"?'),
                  style:
                      TextStyle(fontSize: 13.5, color: _Palette.inkMuted),
                ),
              ),
              const SizedBox(height: 12),
              ...options.map((opt) {
                final selected = opt['value'] == _navApp;
                return RadioListTile<String>(
                  value: opt['value']!,
                  groupValue: _navApp,
                  activeColor: _Palette.pickup,
                  title: Text(opt['label']!,
                      style: const TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                          color: _Palette.ink)),
                  subtitle: Text(opt['subtitle']!,
                      style: const TextStyle(
                          fontSize: 13.5, color: _Palette.inkMuted)),
                  onChanged: (v) async {
                    if (v == null) return;
                    Navigator.pop(ctx);
                    setState(() => _navApp = v);
                    await _savePreference('nav_app', v);
                  },
                );
              }),
              const SizedBox(height: 8),
            ],
          ),
        ),
      ),
    );
  }

  // ============================================================
  // LANGUAGE — 7 languages, wired to appLanguageNotifier
  // ============================================================
  void _openLanguage() {
    final languages = AppLang.available
        .map((l) => {'code': l.code, 'label': l.label})
        .toList();

    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (ctx) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.only(top: 16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: Colors.grey.shade300,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
              const SizedBox(height: 20),
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 20),
                child: Text(
                  tr('Language'),
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: _Palette.ink,
                  ),
                ),
              ),
              const SizedBox(height: 12),
              Flexible(
                child: ListView.builder(
                  shrinkWrap: true,
                  itemCount: languages.length,
                  itemBuilder: (_, i) {
                    final lang = languages[i];
                    final selected = lang['code'] == _language;
                    return RadioListTile<String>(
                      value: lang['code']!,
                      groupValue: _language,
                      activeColor: _Palette.pickup,
                      title: Text(lang['label']!,
                          style: const TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.w600,
                              color: _Palette.ink)),
                      onChanged: (v) async {
                        if (v == null) return;
                        Navigator.pop(ctx);
                        setState(() => _language = v);

                        await _savePreference('language', v);
                        appLanguageNotifier.value = AppLang.fromCode(v);

                        if (!mounted) return;
                        ErrorUI.showSnack(
                          context,
                          AppError(
                            title: tr('Language updated'),
                            message:
                                'Preferred language set to ${lang['label']}.',
                            icon: Icons.check_circle_outline,
                          ),
                        );
                      },
                    );
                  },
                ),
              ),
              const SizedBox(height: 12),
            ],
          ),
        ),
      ),
    );
  }

  // ============================================================
  // SIGN IN AND SECURITY
  // ============================================================
  void _openSecurity() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (ctx) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.only(top: 16, bottom: 24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: Colors.grey.shade300,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
              const SizedBox(height: 20),
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 20),
                child: Text(
                  tr('Sign in and security'),
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: _Palette.ink,
                  ),
                ),
              ),
              const SizedBox(height: 12),
              _sheetTile(
                icon: Icons.password,
                title: tr('Change password'),
                subtitle: tr('Update your account password'),
                onTap: () {
                  Navigator.pop(ctx);
                  Navigator.pushNamedAndRemoveUntil(
                      context, '/driver?tab=more', (_) => false);
                },
              ),
              _sheetTile(
                icon: Icons.email_outlined,
                title: tr('Change email'),
                subtitle: tr('Update the email on your account'),
                onTap: () {
                  Navigator.pop(ctx);
                  Navigator.pushNamedAndRemoveUntil(
                      context, '/driver?tab=more', (_) => false);
                },
              ),
              _sheetTile(
                icon: Icons.devices_outlined,
                title: tr('Active sessions'),
                subtitle: tr('Manage devices signed in to your account'),
                onTap: () {
                  Navigator.pop(ctx);
                  _showActiveSessions();
                },
              ),
              _sheetTile(
                icon: Icons.verified_user_outlined,
                title: tr('Two-factor authentication'),
                subtitle: tr('Add an extra layer of security'),
                onTap: () {
                  Navigator.pop(ctx);
                  ErrorUI.showSnack(
                    context,
                    AppError(
                      title: tr('Two-factor authentication'),
                      message:
                          tr('Setup is available from your Supabase dashboard. Coming to the app soon.'),
                      icon: Icons.shield_outlined,
                    ),
                  );
                },
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showActiveSessions() {
    final exp = Supabase.instance.client.auth.currentSession?.expiresAt;
    String expires = 'Unknown';
    if (exp != null) {
      final dt = DateTime.fromMillisecondsSinceEpoch(exp * 1000);
      expires = dt.toLocal().toString().split('.').first;
    }

    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16)),
        title: Text(tr('Active sessions')),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(tr('Current session:')),
            const SizedBox(height: 8),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: _Palette.cream,
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: _Palette.divider),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Icon(Icons.phone_android,
                          size: 16, color: _Palette.blue),
                      SizedBox(width: 8),
                      Text(tr('This device'),
                          style: TextStyle(
                              fontWeight: FontWeight.bold, fontSize: 14)),
                    ],
                  ),
                  const SizedBox(height: 6),
                  Text(tr('Expires: {0}', [expires]),
                      style: const TextStyle(
                          fontSize: 13, color: _Palette.inkMuted)),
                ],
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(tr('Close')),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // LEGAL
  // ============================================================
  void _openLegal() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (ctx) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.only(top: 16, bottom: 24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: Colors.grey.shade300,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
              const SizedBox(height: 20),
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 20),
                child: Text(
                  tr('Legal'),
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: _Palette.ink,
                  ),
                ),
              ),
              const SizedBox(height: 12),
              _sheetTile(
                icon: Icons.description_outlined,
                title: tr('Driver Terms'),
                onTap: () {
                  Navigator.pop(ctx);
                  _showLegalDoc(
                    title: tr('Driver Terms of Service'),
                    body: 'By accepting trips on ko!ngo you agree to:\n\n'
                        '• Operate a roadworthy, licensed, and insured vehicle.\n'
                        '• Hold all required permits, licences, and '
                        'professional driving credentials.\n'
                        '• Treat every passenger with respect and '
                        'professionalism.\n'
                        '• Follow all local traffic and transport laws.\n\n'
                        'ko!ngo is not an employer; you operate as an '
                        'independent contractor. Commission is set per '
                        'region and shown on your earnings screen.\n\n'
                        'Full version available from ko!ngo support.',
                  );
                },
              ),
              _sheetTile(
                icon: Icons.privacy_tip_outlined,
                title: tr('Privacy Policy'),
                onTap: () {
                  Navigator.pop(ctx);
                  Navigator.pushNamed(context, '/customer_privacy');
                },
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showLegalDoc({required String title, required String body}) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16)),
        title: Text(title),
        content: SizedBox(
          width: 400,
          child: SingleChildScrollView(
            child: Text(body,
                style: const TextStyle(height: 1.5, fontSize: 14)),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(tr('Close')),
          ),
        ],
      ),
    );
  }

  Widget _sheetTile({
    required IconData icon,
    required String title,
    String? subtitle,
    required VoidCallback onTap,
  }) {
    return ListTile(
      leading: Icon(icon, color: _Palette.ink, size: 22),
      title: Text(title,
          style: const TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.w600,
              color: _Palette.ink)),
      subtitle: subtitle != null
          ? Text(subtitle,
              style: const TextStyle(
                  fontSize: 13, color: _Palette.inkMuted))
          : null,
      trailing: const Icon(Icons.chevron_right,
          color: _Palette.inkMuted, size: 20),
      onTap: onTap,
    );
  }

  // ============================================================
  // LOGOUT
  // ============================================================
  Future<void> _confirmLogout() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16)),
        title: Text(tr('Log out?')),
        content: Text(
            tr('You\'ll stop receiving ride requests until you sign in again.')),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: Text(tr('Cancel')),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: _Palette.danger,
              foregroundColor: Colors.white,
            ),
            onPressed: () => Navigator.pop(ctx, true),
            child: Text(tr('Log out')),
          ),
        ],
      ),
    );
    if (confirmed != true) return;

    setState(() => _isLoggingOut = true);
    try {
      // Best-effort: go offline so requests stop arriving.
      try {
        final userId = Supabase.instance.client.auth.currentUser?.id;
        if (userId != null) {
          await Supabase.instance.client
              .from('profiles')
              .update({'is_online': false}).eq('id', userId);
        }
      } catch (_) {}
      try {
        await DriverLocationService.instance.stop();
      } catch (_) {}
      try {
        await NotificationService.instance.unregister();
      } catch (_) {}

      await Supabase.instance.client.auth.signOut();

      if (!mounted) return;
      Navigator.pushNamedAndRemoveUntil(
          context, '/role_select', (route) => false);
    } catch (e) {
      if (!mounted) return;
      setState(() => _isLoggingOut = false);
      ErrorUI.showSnack(context, AppError.from(e));
    }
  }

  // ============================================================
  // BUILD
  // ============================================================
  @override
  Widget build(BuildContext context) {
    final s = S.of(context);
    return Scaffold(
      backgroundColor: _Palette.cream,
      appBar: AppBar(
        backgroundColor: _Palette.cream,
        elevation: 0,
        iconTheme: const IconThemeData(color: _Palette.ink),
        title: Text(
          s.t('settings'),
          style: const TextStyle(
            color: _Palette.ink,
            fontWeight: FontWeight.bold,
            fontSize: 22,
          ),
        ),
      ),
      body: _isLoading
          ? const Center(
              child: CircularProgressIndicator(color: _Palette.accent))
          : SafeArea(
              child: ListView(
                padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
                children: [
                  // ── Section 1: Preferences ──
                  _sectionCard(
                    children: [
                      _rowTile(
                        asset: AppImages.speaker,
                        title: tr('Notifications'),
                        subtitle: tr('Ride requests, chat, bonuses'),
                        onTap: _openCommunication,
                      ),
                      _divider(),
                      _rowTile(
                        asset: AppImages.globe,
                        title: s.t('language'),
                        subtitle: AppLang.fromCode(_language).label,
                        onTap: _openLanguage,
                      ),
                      _divider(),
                      _rowTile(
                        asset: AppImages.textSize,
                        title: s.t('text_size'),
                        subtitle: s.t(Readability.labelKeyFor(
                            Readability.textScale.value)),
                        onTap: () async {
                          await showTextSizeSheet(context);
                          if (mounted) setState(() {});
                        },
                      ),
                      _divider(),
                      _rowTile(
                        asset: AppImages.gear,
                        title: tr('Navigation app'),
                        subtitle: _navAppLabel(),
                        onTap: _openNavigation,
                      ),
                      _divider(),
                      _rowTile(
                        asset: AppImages.calendar,
                        title: tr('Sound & alerts'),
                        subtitle:
                            _ringSoundEnabled ? 'On' : 'Silent',
                        onTap: _openSound,
                      ),
                    ],
                  ),

                  const SizedBox(height: 16),

                  // ── Section 2: Account ──
                  _sectionCard(
                    children: [
                      _rowTile(
                        asset: AppImages.driverCar,
                        title: tr('My vehicles'),
                        subtitle: tr('Add, edit, or remove'),
                        onTap: () => Navigator.pushNamed(
                            context, '/vehicles'),
                      ),
                      _divider(),
                      _rowTile(
                        asset: AppImages.shieldCheck,
                        title: tr('KYC documents'),
                        subtitle: tr('ID, licence, logbook'),
                        onTap: () => Navigator.pushNamed(
                            context, '/verify'),
                      ),
                      _divider(),
                      _rowTile(
                        asset: AppImages.bank,
                        title: tr('Bank details'),
                        subtitle: tr('Payout account'),
                        onTap: () => Navigator.pushNamed(
                            context, '/driver_bank'),
                      ),
                    ],
                  ),

                  const SizedBox(height: 16),

                  // ── Section 3: Security & legal ──
                  _sectionCard(
                    children: [
                      _rowTile(
                        asset: AppImages.lock,
                        title: tr('Sign in and security'),
                        subtitle: tr('Password, sessions, 2FA'),
                        onTap: _openSecurity,
                      ),
                      _divider(),
                      _rowTile(
                        asset: AppImages.shieldInfo,
                        title: s.t('legal'),
                        onTap: _openLegal,
                      ),
                    ],
                  ),

                  const SizedBox(height: 16),

                  // ── Log out ──
                  Material(
                    color: Colors.transparent,
                    child: InkWell(
                      onTap: _isLoggingOut ? null : _confirmLogout,
                      borderRadius: BorderRadius.circular(12),
                      child: Padding(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 16, vertical: 14),
                        child: Row(
                          children: [
                            _isLoggingOut
                                ? const SizedBox(
                                    width: 20,
                                    height: 20,
                                    child: CircularProgressIndicator(
                                        strokeWidth: 2,
                                        color: _Palette.danger),
                                  )
                                : AppImage(
                                    AppImages.logout,
                                    size: 22,
                                    fallbackIcon: Icons.logout,
                                  ),
                            const SizedBox(width: 16),
                            Text(
                              _isLoggingOut
                                  ? 'Logging out…'
                                  : s.t('sign_out'),
                              style: const TextStyle(
                                fontSize: 15,
                                fontWeight: FontWeight.w600,
                                color: _Palette.danger,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
    );
  }

  String _navAppLabel() {
    switch (_navApp) {
      case 'waze':
        return 'Waze';
      case 'in_app':
        return 'ko!ngo in-app';
      case 'google':
      default:
        return 'Google Maps';
    }
  }

  Widget _sectionCard({required List<Widget> children}) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: _Palette.divider),
      ),
      child: Column(children: children),
    );
  }

  Widget _divider() => const Divider(
        height: 1,
        thickness: 1,
        color: _Palette.divider,
        indent: 56,
      );

  Widget _rowTile({
    required String asset,
    required String title,
    String? subtitle,
    required VoidCallback onTap,
  }) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(16),
        child: Padding(
          padding:
              const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
          child: Row(
            children: [
              AppImage(
                asset,
                size: 24,
                fallbackIcon: Icons.circle_outlined,
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title,
                        style: const TextStyle(
                            fontSize: 15,
                            fontWeight: FontWeight.w600,
                            color: _Palette.ink)),
                    if (subtitle != null) ...[
                      const SizedBox(height: 2),
                      Text(subtitle,
                          style: const TextStyle(
                              fontSize: 13.5, color: _Palette.inkMuted)),
                    ],
                  ],
                ),
              ),
              const Icon(Icons.chevron_right,
                  color: _Palette.inkMuted, size: 22),
            ],
          ),
        ),
      ),
    );
  }
}
