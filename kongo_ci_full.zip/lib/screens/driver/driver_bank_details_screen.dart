// lib/screens/driver/driver_bank_details_screen.dart

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:efuride_app/config/app_images.dart';
import 'package:efuride_app/widgets/app_image.dart';
import 'package:efuride_app/utils/app_error.dart';
import 'package:efuride_app/utils/error_ui.dart';
import 'package:efuride_app/l10n/app_strings.dart';

class _Palette {
  static const cream = Color(0xFFFAF6EE);
  static const ink = Color(0xFF1A1A1A);
  static const inkMuted = Color(0xFF575047);
  static const accent = Color(0xFFF2B705);
  static const divider = Color(0xFFE8E2D5);
  static const blue = Color(0xFF1E88E5);
  static const pickup = Color(0xFF34C759);
  static const dropoff = Color(0xFFE53935);
}

class DriverBankDetailsScreen extends StatefulWidget {
  const DriverBankDetailsScreen({super.key});

  @override
  State<DriverBankDetailsScreen> createState() =>
      _DriverBankDetailsScreenState();
}

class _DriverBankDetailsScreenState extends State<DriverBankDetailsScreen> {
  final _formKey = GlobalKey<FormState>();

  final _bankNameCtrl = TextEditingController();
  final _customBankCtrl = TextEditingController();
  final _holderCtrl = TextEditingController();
  final _accountCtrl = TextEditingController();
  final _branchCtrl = TextEditingController();

  String _accountType = 'cheque';
  String? _selectedBank;
  bool _isLoading = true;
  bool _isSaving = false;
  bool _hasExisting = false;
  String? _existingStatus;

  static const _banks = [
    'ABSA',
    'Capitec',
    'Discovery Bank',
    'FNB',
    'Investec',
    'Nedbank',
    'Standard Bank',
    'TymeBank',
    'African Bank',
    'Bidvest Bank',
    'Other',
  ];

  @override
  void initState() {
    super.initState();
    _loadExisting();
  }

  @override
  void dispose() {
    _bankNameCtrl.dispose();
    _customBankCtrl.dispose();
    _holderCtrl.dispose();
    _accountCtrl.dispose();
    _branchCtrl.dispose();
    super.dispose();
  }

  Future<void> _loadExisting() async {
    try {
      final userId = Supabase.instance.client.auth.currentUser?.id;
      if (userId == null) {
        if (mounted) setState(() => _isLoading = false);
        return;
      }
      final row = await Supabase.instance.client
          .from('driver_bank_details')
          .select()
          .eq('driver_id', userId)
          .maybeSingle();

      if (!mounted) return;
      if (row == null) {
        setState(() => _isLoading = false);
        return;
      }

      final bankName = (row['bank_name'] ?? '').toString();
      final isKnownBank = _banks.contains(bankName);

      setState(() {
        _selectedBank = isKnownBank ? bankName : 'Other';
        if (!isKnownBank && bankName.isNotEmpty) {
          _customBankCtrl.text = bankName;
        }
        _bankNameCtrl.text = bankName;
        _holderCtrl.text = (row['account_holder'] ?? '').toString();
        _accountCtrl.text = (row['account_number'] ?? '').toString();
        _branchCtrl.text = (row['branch_code'] ?? '').toString();
        _accountType = (row['account_type'] ?? 'cheque').toString();
        _existingStatus = (row['status'] ?? 'pending').toString();
        _hasExisting = true;
        _isLoading = false;
      });
    } catch (e) {
      debugPrint('load bank details failed: $e');
      if (mounted) setState(() => _isLoading = false);
    }
  }

  Future<void> _save({required bool submit}) async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _isSaving = true);

    try {
      final userId = Supabase.instance.client.auth.currentUser?.id;
      if (userId == null) throw Exception('Not signed in');

      final bankName = _selectedBank == 'Other'
          ? _customBankCtrl.text.trim()
          : (_selectedBank ?? '').trim();

      // Any save re-enters review unless it's the very first draft.
      final nextStatus = submit ? 'pending' : (_existingStatus ?? 'pending');

      final payload = {
        'driver_id': userId,
        'bank_name': bankName,
        'account_holder': _holderCtrl.text.trim().toUpperCase(),
        'account_number': _accountCtrl.text.trim(),
        'branch_code': _branchCtrl.text.trim(),
        'account_type': _accountType,
        'status': nextStatus,
        'updated_at': DateTime.now().toUtc().toIso8601String(),
      };

      if (_hasExisting) {
        await Supabase.instance.client
            .from('driver_bank_details')
            .update(payload)
            .eq('driver_id', userId);
      } else {
        await Supabase.instance.client
            .from('driver_bank_details')
            .insert(payload);
      }

      if (!mounted) return;
      setState(() {
        _isSaving = false;
        _existingStatus = nextStatus;
      });

      ErrorUI.showSnack(
        context,
        AppError(
          title: tr('Bank details saved'),
          message: submit
              ? 'Your banking info is now under review.'
              : 'You can edit these later.',
          icon: Icons.check_circle_outline,
        ),
      );

      if (submit) {
        Navigator.pop(context, true);
      } else {
        await _loadExisting();
      }
    } catch (e) {
      if (!mounted) return;
      setState(() => _isSaving = false);
      ErrorUI.showSnack(
        context,
        AppError.from(e, onRetry: () => _save(submit: submit)),
      );
    }
  }

  String? _validateAccountNumber(String? v) {
    final s = (v ?? '').trim();
    if (s.isEmpty) return 'Account number is required';
    if (s.length < 6) return 'Too short';
    if (s.length > 16) return 'Too long';
    if (!RegExp(r'^\d+$').hasMatch(s)) return 'Digits only';
    return null;
  }

  String? _validateBranch(String? v) {
    final s = (v ?? '').trim();
    if (s.isEmpty) return null;
    if (s.length > 8) return 'Too long';
    return null;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _Palette.cream,
      appBar: AppBar(
        backgroundColor: _Palette.cream,
        elevation: 0,
        iconTheme: const IconThemeData(color: _Palette.ink),
        title: Text(
          tr('Bank details'),
          style: TextStyle(
              color: _Palette.ink,
              fontWeight: FontWeight.bold,
              fontSize: 18),
        ),
      ),
      body: _isLoading
          ? const Center(
              child: CircularProgressIndicator(color: _Palette.accent))
          : SafeArea(
              child: Form(
                key: _formKey,
                child: ListView(
                  padding: const EdgeInsets.fromLTRB(20, 8, 20, 24),
                  children: [
                    _statusBanner(),
                    if (_hasExisting) const SizedBox(height: 16),

                    Text(tr('Bank'),
                        style: TextStyle(
                            fontSize: 13.5,
                            fontWeight: FontWeight.w600,
                            color: _Palette.inkMuted)),
                    const SizedBox(height: 6),
                    DropdownButtonFormField<String>(
                      value: _selectedBank,
                      decoration: _inputDecoration('Select your bank'),
                      items: _banks
                          .map((b) =>
                              DropdownMenuItem(value: b, child: Text(b)))
                          .toList(),
                      onChanged: (v) => setState(() => _selectedBank = v),
                      validator: (v) =>
                          (v == null || v.isEmpty) ? 'Select a bank' : null,
                    ),

                    if (_selectedBank == 'Other') ...[
                      const SizedBox(height: 12),
                      TextFormField(
                        controller: _customBankCtrl,
                        decoration: _inputDecoration('Bank name'),
                        validator: (v) => (v ?? '').trim().isEmpty
                            ? 'Enter bank name'
                            : null,
                      ),
                    ],

                    const SizedBox(height: 14),

                    Text(tr('Account holder'),
                        style: TextStyle(
                            fontSize: 13.5,
                            fontWeight: FontWeight.w600,
                            color: _Palette.inkMuted)),
                    const SizedBox(height: 6),
                    TextFormField(
                      controller: _holderCtrl,
                      textCapitalization: TextCapitalization.characters,
                      decoration: _inputDecoration(
                          'Full name as printed on the account'),
                      validator: (v) => (v ?? '').trim().isEmpty
                          ? 'Account holder is required'
                          : null,
                    ),

                    const SizedBox(height: 14),

                    Text(tr('Account number'),
                        style: TextStyle(
                            fontSize: 13.5,
                            fontWeight: FontWeight.w600,
                            color: _Palette.inkMuted)),
                    const SizedBox(height: 6),
                    TextFormField(
                      controller: _accountCtrl,
                      keyboardType: TextInputType.number,
                      inputFormatters: [
                        FilteringTextInputFormatter.digitsOnly,
                        LengthLimitingTextInputFormatter(16),
                      ],
                      decoration: _inputDecoration('e.g. 1234567890'),
                      validator: _validateAccountNumber,
                    ),

                    const SizedBox(height: 14),

                    Text(tr('Branch code (optional)'),
                        style: TextStyle(
                            fontSize: 13.5,
                            fontWeight: FontWeight.w600,
                            color: _Palette.inkMuted)),
                    const SizedBox(height: 6),
                    TextFormField(
                      controller: _branchCtrl,
                      keyboardType: TextInputType.number,
                      inputFormatters: [
                        FilteringTextInputFormatter.digitsOnly,
                        LengthLimitingTextInputFormatter(8),
                      ],
                      decoration: _inputDecoration('e.g. 632005'),
                      validator: _validateBranch,
                    ),

                    const SizedBox(height: 14),

                    Text(tr('Account type'),
                        style: TextStyle(
                            fontSize: 13.5,
                            fontWeight: FontWeight.w600,
                            color: _Palette.inkMuted)),
                    const SizedBox(height: 6),
                    Wrap(
                      spacing: 8,
                      children: [
                        _typeChip('cheque', 'Cheque'),
                        _typeChip('savings', 'Savings'),
                        _typeChip('transmission', 'Transmission'),
                      ],
                    ),

                    const SizedBox(height: 20),

                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: _Palette.blue.withValues(alpha: 0.08),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(
                            color: _Palette.blue.withValues(alpha: 0.3)),
                      ),
                      child: Row(
                        children: [
                          AppImage(
                            AppImages.bank,
                            size: 20,
                            fallbackIcon: Icons.info_outline,
                          ),
                          const SizedBox(width: 10),
                          const Expanded(
                            child: Text(
                              'Payouts to this account are made weekly. '
                              'Double-check the digits — mistakes delay payouts.',
                              style: TextStyle(
                                  fontSize: 13.5,
                                  color: _Palette.ink,
                                  height: 1.4),
                            ),
                          ),
                        ],
                      ),
                    ),

                    const SizedBox(height: 24),

                    Row(
                      children: [
                        Expanded(
                          child: OutlinedButton(
                            onPressed: _isSaving
                                ? null
                                : () => _save(submit: false),
                            style: OutlinedButton.styleFrom(
                              padding:
                                  const EdgeInsets.symmetric(vertical: 14),
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(12)),
                            ),
                            child: Text(tr('Save draft')),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          flex: 2,
                          child: ElevatedButton(
                            onPressed: _isSaving
                                ? null
                                : () => _save(submit: true),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: const Color(0xFFF2B705),
                              foregroundColor: const Color(0xFF0B1220),
                              padding:
                                  const EdgeInsets.symmetric(vertical: 14),
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(12)),
                            ),
                            child: _isSaving
                                ? const SizedBox(
                                    width: 18,
                                    height: 18,
                                    child: CircularProgressIndicator(
                                      strokeWidth: 2,
                                      color: const Color(0xFF0B1220),
                                    ),
                                  )
                                : Text(_hasExisting
                                    ? 'Save changes'
                                    : 'Submit for review'),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
    );
  }

  Widget _statusBanner() {
    if (!_hasExisting) return const SizedBox.shrink();
    final s = _existingStatus ?? 'pending';
    Color color;
    IconData icon;
    String text;
    switch (s) {
      case 'verified':
        color = _Palette.pickup;
        icon = Icons.verified;
        text = 'Your bank details are verified.';
        break;
      case 'rejected':
        color = _Palette.dropoff;
        icon = Icons.cancel_outlined;
        text = 'Admin rejected your bank details. Please re-enter.';
        break;
      default:
        color = Colors.orange;
        icon = Icons.hourglass_top;
        text = 'Under review — admin will verify soon.';
    }
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.08),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color.withValues(alpha: 0.35)),
      ),
      child: Row(
        children: [
          Icon(icon, color: color, size: 20),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              text,
              style: TextStyle(
                  fontSize: 13.5, color: color, fontWeight: FontWeight.w600),
            ),
          ),
        ],
      ),
    );
  }

  Widget _typeChip(String value, String label) {
    final selected = _accountType == value;
    return GestureDetector(
      onTap: () => setState(() => _accountType = value),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
        decoration: BoxDecoration(
          color: selected ? _Palette.blue : Colors.white,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: selected ? _Palette.blue : _Palette.divider,
            width: 1.2,
          ),
        ),
        child: Text(
          label,
          style: TextStyle(
            fontSize: 13.5,
            fontWeight: FontWeight.w600,
            color: selected ? Colors.white : _Palette.ink,
          ),
        ),
      ),
    );
  }

  InputDecoration _inputDecoration(String hint) {
    return InputDecoration(
      hintText: hint,
      filled: true,
      fillColor: Colors.white,
      contentPadding:
          const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: _Palette.divider),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: _Palette.divider),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: _Palette.blue, width: 1.5),
      ),
    );
  }
}
