﻿// lib/screens/driver/driver_home_screen.dart
//
// ko!ngo — Driver Home
//
// i18n-clean, currency-clean, no inner nav bar (owned by DriverShell).
// All user-facing strings go through S.of(context).t(...).
// All monetary values go through CountryConfig.money(...).

import 'dart:async';
import 'dart:math' as math;
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:efuride_app/widgets/kongo_brand.dart';
import 'package:flutter/services.dart';
import 'package:flutter/foundation.dart'
    show kIsWeb, defaultTargetPlatform, TargetPlatform;
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart' as gmaps;
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:firebase_messaging/firebase_messaging.dart';

import 'package:efuride_app/config/app_images.dart';
import 'package:efuride_app/config/efuride_palette.dart';
import 'package:efuride_app/config/country_config.dart';
import 'package:efuride_app/screens/shared/messages_screen.dart';
import 'package:efuride_app/l10n/app_strings.dart';
import 'package:efuride_app/widgets/app_image.dart';
import 'package:efuride_app/widgets/debouncer.dart';
import 'package:efuride_app/services/google_maps_service.dart';
import 'package:efuride_app/screens/driver/active_trip_execution_screen.dart';
import 'package:efuride_app/screens/driver/incoming_ride_ring_screen.dart';
import 'package:efuride_app/screens/driver/vehicle_management_screen.dart';
import 'package:efuride_app/services/driver_location_service.dart';
import 'package:efuride_app/services/notification_service.dart';
import 'package:efuride_app/services/ring_service.dart';
import 'package:efuride_app/screens/driver/driver_goal_card.dart';
import 'package:efuride_app/screens/driver/driver_recommendations_screen.dart';
import 'package:efuride_app/screens/driver/driver_week_card.dart';
import 'package:efuride_app/screens/driver/live_photo_check_screen.dart';
import 'package:efuride_app/widgets/wallet/topup_sheet.dart';
import 'package:efuride_app/services/keep_awake_service.dart';
import 'package:efuride_app/services/ring_launcher.dart' show PushDiag;
import 'package:efuride_app/services/photo_check_service.dart';
import 'package:efuride_app/services/training_service.dart';
import 'package:efuride_app/utils/app_error.dart';
import 'package:efuride_app/utils/error_ui.dart';
import 'package:efuride_app/widgets/k_icon.dart';

// ════════════════════════════════════════════════════════════════
// PALETTE
// ════════════════════════════════════════════════════════════════
class _Palette {
  static const cream = Color(0xFFFAF6EE);
  static const ink = Color(0xFF1A1A1A);
  static const inkMuted = Color(0xFF575047);
  static const accent = Color(0xFFF2B705);
  static const accentInk = Color(0xFF0B1220);
  static const online = Color(0xFF22C55E);
  static const onlineDeep = Color(0xFF16A34A);
  static const divider = Color(0xFFE8E2D5);
  static const cancelled = Color(0xFFE53935);
  static const blue = Color(0xFF1E88E5);
  static const bid = Color(0xFFFFB300);
  static const heat = Color(0xFFE53935);

  static const blueDeep = Color(0xFF1565C0);
  static const navy = Color(0xFF0B1E3F);
  static const lightBlue = Color(0xFFEBF5FF);
  static const dropoff = Color(0xFFE53935);
  static const pickup = Color(0xFF34C759);
}

enum DispatchMode { auto, manual, bidding }

extension _DispatchModeX on DispatchMode {
  IconData get icon => switch (this) {
        DispatchMode.auto => Icons.bolt,
        DispatchMode.manual => Icons.touch_app,
        DispatchMode.bidding => Icons.gavel_rounded,
      };

  String get assetPath => switch (this) {
        DispatchMode.auto => AppImages.gear,
        DispatchMode.manual => AppImages.mapPinUser,
        DispatchMode.bidding => AppImages.percentTag,
      };

  String label(BuildContext ctx) => switch (this) {
        DispatchMode.auto => S.of(ctx).t('auto'),
        DispatchMode.manual => S.of(ctx).t('manual'),
        DispatchMode.bidding => S.of(ctx).t('bid'),
      };
}

class _DemandCluster {
  final gmaps.LatLng center;
  final double weight;
  const _DemandCluster({required this.center, required this.weight});
}

class DriverHomeScreen extends StatefulWidget {
  const DriverHomeScreen({super.key});

  @override
  State<DriverHomeScreen> createState() => _DriverHomeScreenState();
}

class _DriverHomeScreenState extends State<DriverHomeScreen>
    with WidgetsBindingObserver {
  // ── Map ──────────────────────────────────────────────────────
  gmaps.GoogleMapController? _mapController;
  gmaps.CameraPosition? _lastCameraPosition;
  gmaps.BitmapDescriptor? _driverMarkerIcon;
  gmaps.BitmapDescriptor? _customerMarkerIcon;
  bool _pendingCenterOnDriver = false;
  gmaps.LatLng? _lastCenteredOn;

  // ── Demand heat ──────────────────────────────────────────────
  bool _showDemandHeat = false;
  List<_DemandCluster> _demandClusters = [];
  Timer? _demandRefreshTimer;
  bool _loadingDemand = false;

  // ── Destination filter ───────────────────────────────────────
  gmaps.LatLng? _destinationFilterLatLng;
  String _destinationFilterLabel = '';
  bool _destinationFilterActive = false;

  // ── Online state ─────────────────────────────────────────────
  bool isOnline = false;
  bool _isTogglingOnline = false;

  DateTime? _onlineSince;
  Timer? _onlineTimeTicker;

  int _unreadNotifications = 0;
  RealtimeChannel? _notificationsChannel;

  static const _driverOnlineChannel =
      MethodChannel('efuride/driver_online_service');

  Future<void> _startOnlineService() async {
    if (kIsWeb) return;
    try {
      // The online service uses location. Starting it before location is
      // allowed (fresh install, driver still marked online) can close the
      // app on newer Android, so wait until the permission is granted.
      final perm = await Geolocator.checkPermission();
      if (perm == LocationPermission.denied ||
          perm == LocationPermission.deniedForever) {
        debugPrint('DriverOnlineService not started: no location permission');
        return;
      }
    } catch (e) {
      debugPrint('location permission check failed: $e');
      return;
    }
    try {
      await _driverOnlineChannel.invokeMethod('start');
      debugPrint('✅ DriverOnlineService started');
    } on MissingPluginException catch (e) {
      debugPrint('❌ DriverOnlineService NOT wired in MainActivity: $e');
    } catch (e) {
      debugPrint('DriverOnlineService start failed: $e');
    }
  }

  Future<void> _stopOnlineService() async {
    if (kIsWeb) return;
    try {
      await _driverOnlineChannel.invokeMethod('stop');
      debugPrint('✅ DriverOnlineService stopped');
    } catch (e) {
      debugPrint('DriverOnlineService stop failed: $e');
    }
  }

  DispatchMode _dispatchMode = DispatchMode.manual;

  String currentAssignment = 'Waiting for requests...';

  gmaps.LatLng? driverLocation;
  double _headingRadians = 0.0;

  RealtimeChannel? _rideCancelSubscription;
  RealtimeChannel? _customerLocationChannel;
  RealtimeChannel? _rideInsertSubscription;
  RealtimeChannel? _counterResponseChannel;
  RealtimeChannel? _adminAssignSubscription;

  Map<String, dynamic>? activeIncomingRide;
  String? activeAcceptedRideId;

  final Set<String> _shownRideIds = {};
  final Set<String> _locallyAcceptedRideIds = {};

  String? _pendingCounterRideId;
  double? _pendingCounterAmount;

  gmaps.LatLng? _customerLiveLocation;
  String? _otpFromRide;

  String? _driverName;
  String? _driverFirstName;
  String? _driverAvatarUrl;

  bool _hasActiveVehicle = true;
  bool _isCheckingVehicle = true;
  String _driverVehicleType = 'car';
  Set<String> _activeVehicleServices = {'Ride', 'Delivery'};
  String _activeVehicleLabel = '';
  String _activeVehicleCategory = 'sedan';

  double _todayEarnings = 0.0;
  int _todayTrips = 0;

  TrainingSnapshot? _trainingSnapshot;

  Timer? _activationWatchdog;
  Timer? _headingWatcher; // no longer used; kept so old calls compile
  StreamSubscription<Position>? _livePositionSub;

  /// Map stays centred on the driver ("locked") until the driver taps the
  /// lock button to look around. Pinch-zoom is kept while locked.
  bool _followLock = true;
  double _followZoom = 17.0;
  Timer? _greetingTimer;
  bool _isRefreshing = false;
  bool _ringOpen = false;

  /// Shop orders nobody has accepted yet (they rang for a minute and were
  /// put aside). They stay here until accepted or cancelled.
  List<Map<String, dynamic>> _waitingOrders = [];
  Timer? _waitingOrdersTimer;

  // ════════════════════════════════════════════════════════════
  // LIFECYCLE
  // ════════════════════════════════════════════════════════════
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.dark,
      statusBarBrightness: Brightness.light,
    ));
    _ensureOnboardingComplete();
    _loadMarkerIcons();
    _initDriverLocation();
    _restoreDestinationFilter();
    _fetchExistingPendingRides();
    _setupRealtimeRideListener();
    _setupAdminAssignmentListener();
    _setupFCMListeners();
    PushDiag.note('driver home opened');
    _checkIfDriverIsOnline();
    _loadHeader();
    _loadTodayEarningsStrip();
    _loadDriverVehicleType();
    _checkActiveVehicle();
    _loadTraining();
    _askPhotoCheckOnOpen();
    _startActivationWatchdog();
    _startHeadingWatcher();
    _recoverPendingCounterOffer();
    _checkForAdminAssignedTrips();

    _loadOnlineSince();
    _loadUnreadNotifications();
    _subscribeToNotifications();
    _startOnlineTimeTicker();

    _greetingTimer = Timer.periodic(const Duration(minutes: 1), (_) {
      if (mounted) setState(() {});
    });

    _loadWaitingOrders();
    _waitingOrdersTimer = Timer.periodic(
        const Duration(seconds: 10), (_) => _loadWaitingOrders());
  }

  Future<void> _loadWaitingOrders() async {
    if (!mounted) return;
    if (!isOnline || activeAcceptedRideId != null) {
      if (_waitingOrders.isNotEmpty) setState(() => _waitingOrders = []);
      return;
    }
    try {
      final since = DateTime.now()
          .toUtc()
          .subtract(const Duration(hours: 12))
          .toIso8601String();
      final rows = List<Map<String, dynamic>>.from(await Supabase
          .instance.client
          .from('rides')
          .select()
          .eq('status', 'pending')
          .not('order_id', 'is', null)
          .gte('created_at', since)
          .order('created_at', ascending: true)
          .limit(30));
      final list = rows.where(_rideMatchesActiveVehicle).toList();
      if (mounted) setState(() => _waitingOrders = list);
    } catch (e) {
      debugPrint('loadWaitingOrders failed: $e');
    }
  }

  void _openWaitingOrders() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: _Palette.cream,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (ctx) => DraggableScrollableSheet(
        expand: false,
        initialChildSize: 0.6,
        maxChildSize: 0.92,
        builder: (ctx, scroll) => Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 16, 20, 4),
              child: Text(tr('Orders waiting for a driver'),
                  style: const TextStyle(
                      fontSize: 20, fontWeight: FontWeight.w800)),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 0, 20, 10),
              child: Text(
                tr('Tap an order to see it and accept it.'),
                style: const TextStyle(
                    fontSize: 14.5, color: _Palette.inkMuted),
              ),
            ),
            Expanded(
              child: _waitingOrders.isEmpty
                  ? Center(
                      child: Text(tr('No orders waiting right now'),
                          style: const TextStyle(
                              fontSize: 15, color: _Palette.inkMuted)))
                  : ListView.separated(
                      controller: scroll,
                      padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
                      itemCount: _waitingOrders.length,
                      separatorBuilder: (_, __) => const SizedBox(height: 10),
                      itemBuilder: (_, i) {
                        final r = _waitingOrders[i];
                        final created =
                            DateTime.tryParse('${r['created_at'] ?? ''}');
                        final mins = created == null
                            ? null
                            : DateTime.now()
                                .difference(created.toLocal())
                                .inMinutes;
                        double? km;
                        final plat = (r['pickup_lat'] as num?)?.toDouble();
                        final plng = (r['pickup_lng'] as num?)?.toDouble();
                        if (driverLocation != null &&
                            plat != null &&
                            plng != null) {
                          km = _haversineKm(
                              driverLocation!, gmaps.LatLng(plat, plng));
                        }
                        final service =
                            (r['service_type'] ?? 'Delivery').toString();
                        return Material(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(14),
                          child: InkWell(
                            borderRadius: BorderRadius.circular(14),
                            onTap: () {
                              Navigator.pop(ctx);
                              _openWaitingOrder(r);
                            },
                            child: Container(
                              padding: const EdgeInsets.all(14),
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(14),
                                border:
                                    Border.all(color: const Color(0xFFE8E2D5)),
                              ),
                              child: Row(
                                children: [
                                  Icon(
                                    service == 'Grocery'
                                        ? Icons.shopping_basket
                                        : service == 'Pharmacy'
                                            ? Icons.local_pharmacy
                                            : Icons.restaurant,
                                    color: _Palette.ink,
                                    size: 28,
                                  ),
                                  const SizedBox(width: 12),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          (r['pickup_address'] ?? '')
                                              .toString()
                                              .split('·')
                                              .first
                                              .trim(),
                                          maxLines: 1,
                                          overflow: TextOverflow.ellipsis,
                                          style: const TextStyle(
                                              fontSize: 16,
                                              fontWeight: FontWeight.w800),
                                        ),
                                        Text(
                                          '→ ${(r['dropoff_address'] ?? '').toString().split(',').first}',
                                          maxLines: 1,
                                          overflow: TextOverflow.ellipsis,
                                          style: const TextStyle(
                                              fontSize: 14.5,
                                              color: _Palette.inkMuted),
                                        ),
                                        const SizedBox(height: 4),
                                        Text(
                                          [
                                            if (km != null)
                                              '${km.toStringAsFixed(1)} km ${tr('away')}',
                                            if (mins != null)
                                              tr('waiting {0} min',
                                                  ['$mins']),
                                          ].join('  ·  '),
                                          style: const TextStyle(
                                              fontSize: 13.5,
                                              fontWeight: FontWeight.w700,
                                              color: _Palette.inkMuted),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Text(
                                    CountryConfig.money(
                                        (r['fare'] as num?)?.toDouble() ??
                                            0),
                                    style: const TextStyle(
                                        fontSize: 17,
                                        fontWeight: FontWeight.w900),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }

  /// Show one waiting order again (no ringing) so the driver can accept.
  Future<void> _openWaitingOrder(Map<String, dynamic> ride) async {
    if (_ringOpen || globalRingShowing.value) return;
    setState(() {
      activeIncomingRide = ride;
      _otpFromRide = ride['pickup_otp']?.toString();
    });
    await _openRingAndHandle(ride, silent: true);
    _loadWaitingOrders();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _rideCancelSubscription?.unsubscribe();
    _rideInsertSubscription?.unsubscribe();
    _customerLocationChannel?.unsubscribe();
    _counterResponseChannel?.unsubscribe();
    _adminAssignSubscription?.unsubscribe();
    _notificationsChannel?.unsubscribe();
    _activationWatchdog?.cancel();
    _headingWatcher?.cancel();
    _stopLivePosition();
    _greetingTimer?.cancel();
    _demandRefreshTimer?.cancel();
    _onlineTimeTicker?.cancel();
    _waitingOrdersTimer?.cancel();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      _restoreOnlineState();
      _loadHeader();
      _checkActiveVehicle();
      _checkForAdminAssignedTrips();
      _recoverPendingCounterOffer();
      _startHeadingWatcher();
      _loadTraining();
      _loadOnlineSince();
      _loadUnreadNotifications();
      if (_showDemandHeat) _loadDemandClusters();
    } else {
      _headingWatcher?.cancel();
      _headingWatcher = null;
      // Background location is handled by DriverLocationService while online.
      _stopLivePosition();
      _demandRefreshTimer?.cancel();
      _demandRefreshTimer = null;
    }
  }

  Future<void> _ensureOnboardingComplete() async {
    try {
      final userId = Supabase.instance.client.auth.currentUser?.id;
      if (userId == null) return;
      final profile = await Supabase.instance.client
          .from('profiles')
          .select('is_active, onboarding_complete, onboarding_step, role')
          .eq('id', userId)
          .maybeSingle();
      if (!mounted || profile == null) return;
      if ((profile['role'] ?? '').toString().toLowerCase() != 'driver') {
        return;
      }
      final isActive = profile['is_active'] == true;
      final step = (profile['onboarding_step'] ?? 'kyc').toString();
      if (isActive) return;
      if (step == 'pending') {
        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (!mounted) return;
          Navigator.pushReplacementNamed(context, '/pending_approval');
        });
        return;
      }
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (!mounted) return;
        Navigator.pushReplacementNamed(context, '/driver_onboarding');
      });
    } catch (e) {
      debugPrint('onboarding gate failed: $e');
    }
  }

  String _greeting(BuildContext ctx) {
    final h = DateTime.now().hour;
    final s = S.of(ctx);
    if (h < 12) return s.t('good_morning');
    if (h < 17) return s.t('good_afternoon');
    return s.t('good_evening');
  }

  // ════════════════════════════════════════════════════════════
  // ONLINE TIME
  // ════════════════════════════════════════════════════════════
  Future<void> _loadOnlineSince() async {
    try {
      final userId = Supabase.instance.client.auth.currentUser?.id;
      if (userId == null) return;
      final row = await Supabase.instance.client
          .from('profiles')
          .select('is_online, online_since')
          .eq('id', userId)
          .maybeSingle();
      if (!mounted || row == null) return;

      final online = row['is_online'] == true;
      final sinceRaw = row['online_since']?.toString();
      DateTime? since;
      if (sinceRaw != null && sinceRaw.isNotEmpty) {
        since = DateTime.tryParse(sinceRaw)?.toLocal();
      }
      setState(() {
        _onlineSince = online ? since : null;
      });
    } catch (e) {
      debugPrint('loadOnlineSince failed: $e');
    }
  }

  void _startOnlineTimeTicker() {
    _onlineTimeTicker?.cancel();
    _onlineTimeTicker = Timer.periodic(const Duration(seconds: 60), (_) {
      if (!mounted) return;
      if (isOnline) setState(() {});
    });
  }

  String _formatOnlineTime() {
    final since = _onlineSince;
    if (since == null || !isOnline) return '0m';
    final elapsed = DateTime.now().difference(since);
    if (elapsed.inMinutes < 1) return '< 1m';
    final h = elapsed.inHours;
    final m = elapsed.inMinutes % 60;
    if (h == 0) return '${m}m';
    return '${h}h ${m}m';
  }

  // ════════════════════════════════════════════════════════════
  // UNREAD NOTIFICATIONS
  // ════════════════════════════════════════════════════════════
  Future<void> _loadUnreadNotifications() async {
    try {
      final userId = Supabase.instance.client.auth.currentUser?.id;
      if (userId == null) return;
      final res = await Supabase.instance.client
          .from('notifications')
          .select('id')
          .eq('user_id', userId)
          .eq('read', false);
      if (!mounted) return;
      setState(() => _unreadNotifications = (res as List).length);
    } catch (e) {
      debugPrint('loadUnreadNotifications failed: $e');
    }
  }

  void _subscribeToNotifications() {
    final userId = Supabase.instance.client.auth.currentUser?.id;
    if (userId == null) return;
    _notificationsChannel?.unsubscribe();
    _notificationsChannel = Supabase.instance.client
        .channel('driver_notif_badge_$userId')
        .onPostgresChanges(
          event: PostgresChangeEvent.all,
          schema: 'public',
          table: 'notifications',
          filter: PostgresChangeFilter(
            type: PostgresChangeFilterType.eq,
            column: 'user_id',
            value: userId,
          ),
          callback: (_) => _loadUnreadNotifications(),
        )
        .subscribe();
  }

  // ════════════════════════════════════════════════════════════
  // TRAINING / ACADEMY
  // ════════════════════════════════════════════════════════════
  Future<void> _loadTraining() async {
    try {
      final snap = await TrainingService.instance.load();
      if (!mounted) return;
      setState(() => _trainingSnapshot = snap);
    } catch (e) {
      debugPrint('loadTraining failed: $e');
    }
    _loadRecos();
  }

  // When the home opens and this week's selfie check is due, ask for it.
  bool _photoCheckAsked = false;
  Future<void> _askPhotoCheckOnOpen() async {
    if (_photoCheckAsked) return;
    _photoCheckAsked = true;
    await Future.delayed(const Duration(seconds: 2));
    if (!mounted || !await PhotoCheckService.isDue() || !mounted) return;
    await Navigator.push<bool>(
      context,
      MaterialPageRoute(builder: (_) => const LivePhotoCheckScreen()),
    );
    if (mounted) _loadRecos();
  }

  // ── Recommendations (things the driver can still fix) ───────
  List<DriverReco> _recos = [];

  bool get _academyIncomplete =>
      (_trainingSnapshot?.requiredTotal ?? 0) > 0 &&
      !(_trainingSnapshot?.isCertified ?? false);

  Future<void> _loadRecos() async {
    try {
      final list = await DriverRecommendations.load(
        hasVehicle: _hasActiveVehicle,
        academyIncomplete: _academyIncomplete,
      );
      if (mounted) setState(() => _recos = list);
    } catch (_) {}
  }

  Future<void> _openRecos() async {
    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => DriverRecommendationsScreen(
          hasVehicle: _hasActiveVehicle,
          academyIncomplete: _academyIncomplete,
        ),
      ),
    );
    if (mounted) {
      _checkActiveVehicle();
      _loadRecos();
    }
  }

  // Warning when the wallet is low, with a one-tap Top up.
  Widget _lowBalanceBanner() {
    DriverReco? low;
    for (final r in _recos) {
      if (r.kind == 'low_balance') low = r;
    }
    if (low == null) return const SizedBox.shrink();
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 0),
      child: Container(
        padding: const EdgeInsets.fromLTRB(14, 10, 8, 10),
        decoration: BoxDecoration(
          color: const Color(0xFFFEF3C7),
          borderRadius: BorderRadius.circular(14),
        ),
        child: Row(
          children: [
            const Icon(Icons.warning_amber_rounded,
                color: Color(0xFFB45309)),
            const SizedBox(width: 10),
            Expanded(
              child: Text(low.text,
                  style: const TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w700,
                      color: Color(0xFF92400E))),
            ),
            TextButton(
              onPressed: () async {
                final sent = await showTopupSheet(context);
                if (sent && mounted) _loadRecos();
              },
              child: Text(tr('Top up'),
                  style: const TextStyle(fontWeight: FontWeight.w900)),
            ),
          ],
        ),
      ),
    );
  }

  Widget _recoBanner() {
    if (_recos.isEmpty) return const SizedBox.shrink();
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 0),
      child: InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: _openRecos,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
          decoration: BoxDecoration(
            color: EfuridePalette.accent.withValues(alpha: 0.22),
            borderRadius: BorderRadius.circular(14),
          ),
          child: Row(
            children: [
              const Icon(Icons.lightbulb_outline, color: EfuridePalette.ink),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(tr('Recommendations'),
                        style: const TextStyle(
                            fontSize: 15.5,
                            fontWeight: FontWeight.w800,
                            color: EfuridePalette.ink)),
                    Text(tr('Tap to see what to fix'),
                        style: const TextStyle(
                            fontSize: 13, color: EfuridePalette.inkMuted)),
                  ],
                ),
              ),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 9, vertical: 3),
                decoration: BoxDecoration(
                    color: EfuridePalette.ink,
                    borderRadius: BorderRadius.circular(12)),
                child: Text('${_recos.length}',
                    style: const TextStyle(
                        color: Colors.white,
                        fontSize: 13,
                        fontWeight: FontWeight.w800)),
              ),
              const SizedBox(width: 6),
              const Icon(Icons.chevron_right, color: EfuridePalette.inkMuted),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _openTraining() async {
    await Navigator.pushNamed(context, '/driver_training');
    await _loadTraining();
  }

  // ════════════════════════════════════════════════════════════
  // MAP MARKER ICONS
  // ════════════════════════════════════════════════════════════
  Future<void> _loadMarkerIcons() async {
    final String assetPath;
    switch (_driverVehicleType) {
      case 'bike':
        assetPath = AppImages.driverBike;
        break;
      case 'truck':
        assetPath = AppImages.deliveryTruck;
        break;
      case 'bus':
        assetPath = AppImages.driverVan;
        break;
      default:
        assetPath = AppImages.driverCar;
    }

    try {
      if (kIsWeb) {
        _driverMarkerIcon = await gmaps.BitmapDescriptor.asset(
          const ImageConfiguration(size: Size(36, 36)),
          assetPath,
        );
      } else {
        _driverMarkerIcon = await _buildVehicleMarker(
          size: 40,
          assetPath: assetPath,
        );
      }
    } catch (e) {
      debugPrint('driver marker icon load failed: $e');
      _driverMarkerIcon = null;
    }

    try {
      _customerMarkerIcon = await gmaps.BitmapDescriptor.asset(
        const ImageConfiguration(size: Size(36, 36)),
        AppImages.mapPinUser,
      );
    } catch (e) {
      debugPrint('customer marker icon load failed: $e');
      _customerMarkerIcon = null;
    }

    if (mounted) setState(() {});
  }

  Future<gmaps.BitmapDescriptor> _buildVehicleMarker({
    required double size,
    required String assetPath,
  }) async {
    final recorder = ui.PictureRecorder();
    final canvas = Canvas(recorder);
    final center = Offset(size / 2, size / 2);
    final radius = size / 2;

    canvas.drawCircle(
      center.translate(0, 1.5),
      radius - 1,
      Paint()
        ..color = Colors.black.withValues(alpha: 0.22)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 3),
    );
    canvas.drawCircle(center, radius, Paint()..color = Colors.white);
    canvas.drawCircle(
      center,
      radius - 2.5,
      Paint()..color = const Color(0xFFF1F3F4),
    );

    try {
      final data = await rootBundle.load(assetPath);
      final codec = await ui.instantiateImageCodec(data.buffer.asUint8List());
      final frame = await codec.getNextFrame();
      final img = frame.image;

      final innerSize = size * 0.62;
      final dst = Rect.fromCenter(
        center: center,
        width: innerSize,
        height: innerSize,
      );
      final src = Rect.fromLTWH(
        0,
        0,
        img.width.toDouble(),
        img.height.toDouble(),
      );
      canvas.drawImageRect(img, src, dst, Paint());
    } catch (_) {
      canvas.drawCircle(
        center,
        radius * 0.5,
        Paint()..color = _Palette.online,
      );
    }

    final picture = recorder.endRecording();
    final out = await picture.toImage(size.toInt(), size.toInt());
    final bytes = await out.toByteData(format: ui.ImageByteFormat.png);
    return gmaps.BitmapDescriptor.fromBytes(bytes!.buffer.asUint8List());
  }

  // ════════════════════════════════════════════════════════════
  // HEADER DATA
  // ════════════════════════════════════════════════════════════
  Future<void> _loadHeader() async {
    try {
      final userId = Supabase.instance.client.auth.currentUser?.id;
      if (userId == null) return;
      final p = await Supabase.instance.client
          .from('profiles')
          .select(
              'first_name, surname, full_name, profile_picture_url, avatar_url')
          .eq('id', userId)
          .maybeSingle();
      if (!mounted || p == null) return;
      final first = (p['first_name'] ?? '').toString().trim();
      final surname = (p['surname'] ?? '').toString().trim();
      final full = (p['full_name'] ?? '').toString().trim();
      String name = '$first $surname'.trim();
      if (name.isEmpty) name = full;
      if (name.isEmpty) name = 'Driver';
      setState(() {
        _driverName = name;
        _driverFirstName = first.isNotEmpty ? first : name.split(' ').first;
        _driverAvatarUrl =
            (p['profile_picture_url'] ?? p['avatar_url'])?.toString().trim();
      });
    } catch (e) {
      debugPrint('loadHeader failed: $e');
    }
  }

  Widget _avatarFallback({double size = 44, double fontSize = 18}) {
    return Container(
      width: size,
      height: size,
      alignment: Alignment.center,
      decoration: const BoxDecoration(
        color: Colors.white,
        shape: BoxShape.circle,
      ),
      child: Text(
        (_driverFirstName?.isNotEmpty == true)
            ? _driverFirstName![0].toUpperCase()
            : '?',
        style: TextStyle(
          color: _Palette.blueDeep,
          fontSize: fontSize,
          fontWeight: FontWeight.w900,
        ),
      ),
    );
  }

  // ════════════════════════════════════════════════════════════
  // VEHICLE
  // ════════════════════════════════════════════════════════════
  Future<void> _checkActiveVehicle() async {
    try {
      final userId = Supabase.instance.client.auth.currentUser?.id;
      if (userId == null) {
        if (mounted) {
          setState(() {
            _hasActiveVehicle = false;
            _isCheckingVehicle = false;
          });
        }
        return;
      }
      final res = await Supabase.instance.client
          .from('vehicles')
          .select('id, status')
          .eq('driver_id', userId)
          .eq('status', 'active')
          .limit(1);
      final hasActive = (res as List).isNotEmpty;
      if (mounted) {
        setState(() {
          _hasActiveVehicle = hasActive;
          _isCheckingVehicle = false;
        });
      }
    } catch (e) {
      debugPrint('checkActiveVehicle failed: $e');
      if (mounted) {
        setState(() {
          _hasActiveVehicle = false;
          _isCheckingVehicle = false;
        });
      }
    }
  }

  Future<void> _loadDriverVehicleType() async {
    try {
      final userId = Supabase.instance.client.auth.currentUser?.id;
      if (userId == null) return;

      final row = await Supabase.instance.client
          .from('vehicles')
          .select('make, model, category, service_type, service_types')
          .eq('driver_id', userId)
          .eq('status', 'active')
          .order('created_at', ascending: false)
          .limit(1)
          .maybeSingle();

      if (row != null) {
        final category =
            (row['category'] ?? 'sedan').toString().toLowerCase();
        final make = (row['make'] ?? '').toString().trim();
        final model = (row['model'] ?? '').toString().trim();
        final label = '$make $model'.trim();

        Set<String> services;
        final raw = row['service_types'];
        if (raw is List && raw.isNotEmpty) {
          services = raw
              .map((e) => e.toString().trim())
              .where((e) => e == 'Ride' || e == 'Delivery')
              .toSet();
          if (services.isEmpty) services = {'Ride'};
        } else {
          final single = row['service_type']?.toString().trim();
          services = (single == 'Ride' || single == 'Delivery')
              ? {single!}
              : {'Ride'};
        }

        String type;
        switch (category) {
          case 'bike':
            type = 'bike';
            break;
          case 'van':
          case 'large_van':
            type = 'bus';
            break;
          case 'truck':
            type = 'truck';
            break;
          default:
            type = 'car'; // sedan, xl

        }

        if (mounted) {
          setState(() {
            _driverVehicleType = type;
            _activeVehicleCategory = category;
            _activeVehicleServices = services;
            _activeVehicleLabel = label;
          });
        }
        await _loadMarkerIcons();
        return;
      }

      final profile = await Supabase.instance.client
          .from('profiles')
          .select('vehicle_make, vehicle_model')
          .eq('id', userId)
          .maybeSingle();
      if (!mounted || profile == null) return;
      final make = (profile['vehicle_make'] ?? '').toString().toLowerCase();
      final model = (profile['vehicle_model'] ?? '').toString().toLowerCase();
      String type = 'car';
      if (make.contains('bike') ||
          model.contains('bike') ||
          model.contains('motor')) {
        type = 'bike';
      } else if (make.contains('truck') ||
          model.contains('truck') ||
          make.contains('bakkie')) {
        type = 'truck';
      } else if (make.contains('bus') ||
          model.contains('bus') ||
          model.contains('van')) {
        type = 'bus';
      }
      setState(() => _driverVehicleType = type);
      await _loadMarkerIcons();
    } catch (e) {
      debugPrint('loadDriverVehicleType failed: $e');
    }
  }

  // ════════════════════════════════════════════════════════════
  // TODAY EARNINGS
  // ════════════════════════════════════════════════════════════
  Future<void> _loadTodayEarningsStrip() async {
    try {
      final userId = Supabase.instance.client.auth.currentUser?.id;
      if (userId == null) return;
      final response = await Supabase.instance.client
          .from('rides')
          .select('fare, status, created_at')
          .eq('driver_id', userId)
          .eq('status', 'completed')
          .order('created_at', ascending: false)
          .limit(50);
      final now = DateTime.now();
      final todayStart = DateTime(now.year, now.month, now.day).toUtc();
      double today = 0.0;
      int trips = 0;
      for (final r in response as List) {
        final created = DateTime.tryParse(r['created_at']?.toString() ?? '');
        if (created == null) continue;
        if (created.isAfter(todayStart)) {
          today += (r['fare'] as num?)?.toDouble() ?? 0.0;
          trips++;
        }
      }
      if (mounted) {
        setState(() {
          _todayEarnings = today;
          _todayTrips = trips;
        });
      }
    } catch (e) {
      debugPrint('loadTodayEarningsStrip failed: $e');
    }
  }

  // ════════════════════════════════════════════════════════════
  // DESTINATION FILTER
  // ════════════════════════════════════════════════════════════
  Future<void> _restoreDestinationFilter() async {
    try {
      final userId = Supabase.instance.client.auth.currentUser?.id;
      if (userId == null) return;
      final row = await Supabase.instance.client
          .from('profiles')
          .select(
              'destination_filter_label, destination_filter_lat, destination_filter_lng')
          .eq('id', userId)
          .maybeSingle();
      if (!mounted || row == null) return;
      final lat = row['destination_filter_lat'];
      final lng = row['destination_filter_lng'];
      final label = (row['destination_filter_label'] ?? '').toString();
      if (lat != null && lng != null && label.isNotEmpty) {
        setState(() {
          _destinationFilterLatLng = gmaps.LatLng(
            (lat as num).toDouble(),
            (lng as num).toDouble(),
          );
          _destinationFilterLabel = label;
          _destinationFilterActive = true;
        });
      }
    } catch (e) {
      debugPrint('restoreDestinationFilter failed: $e');
    }
  }

  Future<void> _openDestinationFilterPicker() async {
    final t = S.of(context);
    final ctrl = TextEditingController();
    final debouncer = Debouncer(milliseconds: 350);
    int requestId = 0;
    List<PlacePrediction> suggestions = [];
    bool searching = false;

    await showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setSheet) {
          void onSearch(String q) {
            final trimmed = q.trim();
            if (trimmed.isEmpty) {
              requestId++;
              setSheet(() {
                suggestions = [];
                searching = false;
              });
              return;
            }
            setSheet(() => searching = true);
            final rid = ++requestId;
            debouncer.debounce(() async {
              try {
                final origin = driverLocation ??
                    const gmaps.LatLng(-33.9249, 18.4241);
                final preds = await GoogleMapsService.autocomplete(
                  query: trimmed,
                  origin: origin,
                  radiusMeters: 80000,
                );
                if (rid != requestId) return;
                if (!ctx.mounted) return;
                setSheet(() {
                  suggestions = preds;
                  searching = false;
                });
              } catch (e) {
                debugPrint('dest filter autocomplete failed: $e');
                if (rid == requestId && ctx.mounted) {
                  setSheet(() => searching = false);
                }
              }
            });
          }

          return Padding(
            padding: EdgeInsets.only(
              left: 16,
              right: 16,
              top: 16,
              bottom: MediaQuery.of(ctx).viewInsets.bottom + 20,
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Center(
                  child: Container(
                    width: 40,
                    height: 4,
                    decoration: BoxDecoration(
                      color: Colors.grey.shade300,
                      borderRadius: BorderRadius.circular(2),
                    ),
                  ),
                ),
                const SizedBox(height: 18),
                Row(
                  children: [
                    AppImage(
                      AppImages.homeBlue,
                      size: 22,
                      fallbackIcon: Icons.home_outlined,
                    ),
                    const SizedBox(width: 10),
                    Text(
                      t.t('where_heading'),
                      style: const TextStyle(
                        fontSize: 17,
                        fontWeight: FontWeight.bold,
                        color: _Palette.ink,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 6),
                Text(
                  t.t('dest_filter_hint'),
                  style: const TextStyle(
                      fontSize: 13.5, color: _Palette.inkMuted),
                ),
                const SizedBox(height: 16),
                TextField(
                  controller: ctrl,
                  autofocus: true,
                  onChanged: onSearch,
                  decoration: InputDecoration(
                    hintText: t.t('dest_filter_search_hint'),
                    prefixIcon: const Icon(Icons.search),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                ),
                if (searching || suggestions.isNotEmpty) ...[
                  const SizedBox(height: 8),
                  Container(
                    constraints: const BoxConstraints(maxHeight: 260),
                    decoration: BoxDecoration(
                      color: Colors.grey.shade50,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: Colors.grey.shade300),
                    ),
                    child: searching && suggestions.isEmpty
                        ? const Padding(
                            padding: EdgeInsets.all(20),
                            child: Center(
                              child: SizedBox(
                                width: 22,
                                height: 22,
                                child: CircularProgressIndicator(
                                    strokeWidth: 2),
                              ),
                            ),
                          )
                        : ListView.separated(
                            shrinkWrap: true,
                            itemCount: suggestions.length,
                            separatorBuilder: (_, __) =>
                                const Divider(height: 1),
                            itemBuilder: (_, i) {
                              final p = suggestions[i];
                              return ListTile(
                                dense: true,
                                leading: const KIcon(Icons.location_on,
                                    color: Colors.grey, size: 20),
                                title: Text(
                                  p.primaryText,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(fontSize: 14),
                                ),
                                subtitle: p.secondaryText.isEmpty
                                    ? null
                                    : Text(
                                        p.secondaryText,
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                        style:
                                            const TextStyle(fontSize: 13),
                                      ),
                                onTap: () async {
                                  setSheet(() => searching = true);
                                  final details = await GoogleMapsService
                                      .details(p.placeId);
                                  if (!ctx.mounted) return;
                                  if (details == null) {
                                    setSheet(() => searching = false);
                                    return;
                                  }
                                  Navigator.pop(ctx, {
                                    'lat': details.latLng.latitude,
                                    'lng': details.latLng.longitude,
                                    'label': details.formattedAddress
                                            .isNotEmpty
                                        ? details.formattedAddress
                                        : p.fullDescription,
                                  });
                                },
                              );
                            },
                          ),
                  ),
                ],
                if (_destinationFilterActive) ...[
                  const SizedBox(height: 12),
                  OutlinedButton.icon(
                    onPressed: () => Navigator.pop(ctx, 'clear'),
                    icon: const Icon(Icons.close, size: 16),
                    label: Text(t.t('clear_dest_filter')),
                    style: OutlinedButton.styleFrom(
                      foregroundColor: _Palette.cancelled,
                      side: const BorderSide(color: _Palette.cancelled),
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12)),
                    ),
                  ),
                ],
              ],
            ),
          );
        },
      ),
    ).then((result) {
      debouncer.dispose();
      if (!mounted || result == null) return;
      if (result == 'clear') {
        _clearDestinationFilter();
      } else if (result is Map) {
        _applyDestinationFilter(
          gmaps.LatLng(
            (result['lat'] as num).toDouble(),
            (result['lng'] as num).toDouble(),
          ),
          result['label'].toString(),
        );
      }
    });
  }

  Future<void> _applyDestinationFilter(
      gmaps.LatLng point, String label) async {
    setState(() {
      _destinationFilterLatLng = point;
      _destinationFilterLabel = label;
      _destinationFilterActive = true;
    });
    try {
      final userId = Supabase.instance.client.auth.currentUser?.id;
      if (userId == null) return;
      await Supabase.instance.client.from('profiles').update({
        'destination_filter_lat': point.latitude,
        'destination_filter_lng': point.longitude,
        'destination_filter_label': label,
      }).eq('id', userId);
    } catch (e) {
      debugPrint('save destination filter failed: $e');
    }
    if (!mounted) return;
    ErrorUI.showSnack(
      context,
      AppError(
        title: S.of(context).t('filter_on'),
        message: S.of(context).t('filter_on_hint'),
        icon: Icons.check_circle_outline,
      ),
    );
  }

  Future<void> _clearDestinationFilter() async {
    setState(() {
      _destinationFilterLatLng = null;
      _destinationFilterLabel = '';
      _destinationFilterActive = false;
    });
    try {
      final userId = Supabase.instance.client.auth.currentUser?.id;
      if (userId == null) return;
      await Supabase.instance.client.from('profiles').update({
        'destination_filter_lat': null,
        'destination_filter_lng': null,
        'destination_filter_label': null,
      }).eq('id', userId);
    } catch (e) {
      debugPrint('clear destination filter failed: $e');
    }
    if (!mounted) return;
    ErrorUI.showSnack(
      context,
      AppError(
        title: S.of(context).t('filter_cleared'),
        message: S.of(context).t('filter_cleared_hint'),
        icon: Icons.check_circle_outline,
      ),
    );
  }

  bool _ridePassesDestinationFilter(Map<String, dynamic> ride) {
    if (!_destinationFilterActive || _destinationFilterLatLng == null) {
      return true;
    }
    final lat = (ride['dropoff_lat'] as num?)?.toDouble();
    final lng = (ride['dropoff_lng'] as num?)?.toDouble();
    if (lat == null || lng == null) return true;
    final km = _haversineKm(
      _destinationFilterLatLng!,
      gmaps.LatLng(lat, lng),
    );
    return km <= 5.0;
  }

  /// Identity of one offer of a ride. A delivery released by a driver is
  /// re-offered with a new dispatched_at, so it counts as a new offer.
  String _offerKey(Map<String, dynamic> ride) =>
      '${ride['id']}@${ride['dispatched_at'] ?? ''}';

  bool _rideMatchesActiveVehicle(Map<String, dynamic> ride) {
    final rideService = (ride['service_type'] ?? 'Ride').toString().trim();
    if (rideService.isEmpty) return true;
    // Shop orders (food, grocery, pharmacy) are deliveries for vehicles.
    const deliveryKinds = {'Delivery', 'Food', 'Grocery', 'Pharmacy', 'Parcel'};
    final needed = deliveryKinds.contains(rideService) ? 'Delivery' : rideService;
    return _activeVehicleServices.contains(needed);
  }

  double _haversineKm(gmaps.LatLng a, gmaps.LatLng b) {
    const R = 6371.0;
    final dLat = (b.latitude - a.latitude) * math.pi / 180;
    final dLng = (b.longitude - a.longitude) * math.pi / 180;
    final h = math.sin(dLat / 2) * math.sin(dLat / 2) +
        math.cos(a.latitude * math.pi / 180) *
            math.cos(b.latitude * math.pi / 180) *
            math.sin(dLng / 2) *
            math.sin(dLng / 2);
    return 2 * R * math.asin(math.sqrt(h));
  }

  // ════════════════════════════════════════════════════════════
  // DEMAND HEAT
  // ════════════════════════════════════════════════════════════
  Future<void> _toggleDemandHeat() async {
    final next = !_showDemandHeat;
    setState(() => _showDemandHeat = next);
    if (next) {
      await _loadDemandClusters();
      _demandRefreshTimer?.cancel();
      _demandRefreshTimer =
          Timer.periodic(const Duration(minutes: 2), (_) {
        if (mounted && _showDemandHeat) _loadDemandClusters();
      });
    } else {
      _demandRefreshTimer?.cancel();
      _demandRefreshTimer = null;
      setState(() => _demandClusters = []);
    }
  }

  Future<void> _loadDemandClusters() async {
    final center = driverLocation;
    if (center == null) return;
    setState(() => _loadingDemand = true);
    try {
      final res = await Supabase.instance.client.rpc(
        'get_demand_clusters',
        params: {
          'p_lat': center.latitude,
          'p_lng': center.longitude,
          'p_radius_km': 8.0,
          'p_minutes': 20,
        },
      );
      final rows = (res as List?) ?? const [];
      final list = <_DemandCluster>[];
      for (final r in rows) {
        final lat = (r['lat'] as num?)?.toDouble();
        final lng = (r['lng'] as num?)?.toDouble();
        final weight = (r['weight'] as num?)?.toDouble() ?? 0.5;
        if (lat == null || lng == null) continue;
        list.add(_DemandCluster(
          center: gmaps.LatLng(lat, lng),
          weight: weight.clamp(0.0, 1.0),
        ));
      }
      if (!mounted) return;
      setState(() {
        _demandClusters = list;
        _loadingDemand = false;
      });
    } catch (e) {
      debugPrint('loadDemandClusters failed (non-fatal): $e');
      if (mounted) {
        setState(() {
          _demandClusters = [];
          _loadingDemand = false;
        });
      }
    }
  }

  // ════════════════════════════════════════════════════════════
  // LOCATION
  // ════════════════════════════════════════════════════════════
  Future<void> _initDriverLocation() async {
    try {
      final serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!serviceEnabled) return;
      LocationPermission permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
        if (permission == LocationPermission.denied) return;
      }
      if (permission == LocationPermission.deniedForever) return;
      final position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.best,
        timeLimit: const Duration(seconds: 15),
      );
      if (!mounted) return;
      final loc = gmaps.LatLng(position.latitude, position.longitude);
      setState(() {
        driverLocation = loc;
        if (position.speed >= 0.5) {
          _headingRadians = position.heading * math.pi / 180.0;
        }
      });
      if (_mapController == null) {
        _pendingCenterOnDriver = true;
      } else {
        _followCamera(loc);
      }
    } catch (e) {
      debugPrint('initDriverLocation failed: $e');
    }
  }

  void _animateCameraTo(gmaps.LatLng point, double zoom) {
    final ctrl = _mapController;
    if (ctrl == null) return;
    final last = _lastCenteredOn;
    if (last != null) {
      final dLat = (last.latitude - point.latitude).abs();
      final dLng = (last.longitude - point.longitude).abs();
      if (dLat < 0.00005 && dLng < 0.00005) return;
    }
    ctrl.animateCamera(
      gmaps.CameraUpdate.newLatLngZoom(
        gmaps.LatLng(point.latitude, point.longitude),
        zoom,
      ),
    );
    _lastCenteredOn = point;
  }

  /// Live GPS for the map: every fix the phone produces (about once a
  /// second — the fastest GPS chips report), no minimum distance.
  /// Runs while this screen is open, online or offline.
  void _startHeadingWatcher() {
    _headingWatcher?.cancel();
    _headingWatcher = null;
    _livePositionSub?.cancel();
    final LocationSettings settings =
        !kIsWeb && defaultTargetPlatform == TargetPlatform.android
            ? AndroidSettings(
                accuracy: LocationAccuracy.bestForNavigation,
                distanceFilter: 0,
                intervalDuration: const Duration(milliseconds: 1000),
              )
            : const LocationSettings(
                accuracy: LocationAccuracy.bestForNavigation,
                distanceFilter: 0,
              );
    _livePositionSub =
        Geolocator.getPositionStream(locationSettings: settings).listen(
      (pos) {
        if (!mounted) return;
        final loc = gmaps.LatLng(pos.latitude, pos.longitude);
        setState(() {
          driverLocation = loc;
          if (pos.speed >= 0.5) {
            _headingRadians = pos.heading * math.pi / 180.0;
          }
        });
        if (_followLock) _followCamera(loc);
      },
      onError: (e) => debugPrint('live position stream error: $e'),
    );
  }

  void _stopLivePosition() {
    _livePositionSub?.cancel();
    _livePositionSub = null;
  }

  /// Keep the camera on the driver (no dedupe: it must track every move).
  void _followCamera(gmaps.LatLng loc) {
    final ctrl = _mapController;
    if (ctrl == null) {
      _pendingCenterOnDriver = true;
      return;
    }
    ctrl.moveCamera(gmaps.CameraUpdate.newLatLngZoom(loc, _followZoom));
    _lastCenteredOn = loc;
  }

  void _setFollowLock(bool on) {
    setState(() => _followLock = on);
    if (on && driverLocation != null) _followCamera(driverLocation!);
  }

  // ════════════════════════════════════════════════════════════
  // ONLINE STATE
  // ════════════════════════════════════════════════════════════
  Future<void> _restoreOnlineState() async {
    final userId = Supabase.instance.client.auth.currentUser?.id;
    if (userId == null) return;
    try {
      final profile = await Supabase.instance.client
          .from('profiles')
          .select('is_online, is_active, online_since')
          .eq('id', userId)
          .maybeSingle();
      final active = profile?['is_active'] == true;
      final online = profile?['is_online'] == true;

      final sinceRaw = profile?['online_since']?.toString();
      DateTime? since;
      if (sinceRaw != null && sinceRaw.isNotEmpty) {
        since = DateTime.tryParse(sinceRaw)?.toLocal();
      }

      if (!active) {
        if (online) {
          await Supabase.instance.client.from('profiles').update({
            'is_online': false,
            'online_since': null,
          }).eq('id', userId);
        }
        if (mounted) {
          setState(() {
            isOnline = false;
            _onlineSince = null;
            currentAssignment = 'Account inactive — cannot go online.';
          });
        }
        return;
      }
      if (mounted) {
        setState(() {
          isOnline = online;
          _onlineSince = online ? since : null;
        });
      }
      if (online) {
        KeepAwake.on();
        await _startOnlineService();
        if (!DriverLocationService.instance.isRunning) {
          await DriverLocationService.instance.start();
        }
      } else {
        KeepAwake.off();
      }
    } catch (e) {
      debugPrint('restoreOnlineState failed: $e');
    }
  }

  Future<void> _checkIfDriverIsOnline() async {
    try {
      final userId = Supabase.instance.client.auth.currentUser?.id;
      if (userId == null) return;
      final profile = await Supabase.instance.client
          .from('profiles')
          .select('is_online, is_active, online_since')
          .eq('id', userId)
          .single();
      final active = profile['is_active'] == true;
      final online = profile['is_online'] == true;

      final sinceRaw = profile['online_since']?.toString();
      DateTime? since;
      if (sinceRaw != null && sinceRaw.isNotEmpty) {
        since = DateTime.tryParse(sinceRaw)?.toLocal();
      }

      if (!active) {
        if (online) {
          await Supabase.instance.client.from('profiles').update({
            'is_online': false,
            'online_since': null,
          }).eq('id', userId);
        }
        if (mounted) {
          setState(() {
            isOnline = false;
            _onlineSince = null;
            currentAssignment =
                'Account pending admin approval — cannot go online yet.';
          });
        }
        return;
      }
      if (mounted && online) {
        setState(() {
          isOnline = true;
          _onlineSince = since ?? DateTime.now();
          currentAssignment = 'Scanning for nearby requests...';
        });
        await _startOnlineService();
        if (!DriverLocationService.instance.isRunning) {
          await DriverLocationService.instance.start();
        }
        _fetchExistingPendingRides();
      }
    } catch (e) {
      debugPrint('checkIfDriverIsOnline failed: $e');
    }
  }

  Future<void> _toggleOnlineStatus(bool value) async {
    if (_isTogglingOnline) return;
    if (value == isOnline) return;
    final userId = Supabase.instance.client.auth.currentUser?.id;
    if (userId == null) return;
    final t = S.of(context);

    if (value) {
      if (!_hasActiveVehicle) {
        ErrorUI.showSnack(
          context,
          AppError(
            title: t.t('no_vehicle'),
            message: t.t('no_vehicle_hint'),
            icon: Icons.warning_amber_rounded,
            actionLabel: t.t('add'),
            onRetry: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => const VehicleManagementScreen(),
                ),
              ).then((_) => _checkActiveVehicle());
            },
          ),
        );
        return;
      }

      final snap = _trainingSnapshot;
      if (snap != null && snap.requiredTotal > 0 && !snap.isCertified) {
        ErrorUI.showSnack(
          context,
          AppError(
            title: t.t('finish_academy'),
            message: t.t('finish_academy_hint'),
            icon: Icons.school_outlined,
            actionLabel: t.t('open_academy'),
            onRetry: _openTraining,
          ),
        );
        return;
      }

      // Weekly live selfie check: must be done before going online.
      if (await PhotoCheckService.isDue()) {
        if (!mounted) return;
        final sent = await Navigator.push<bool>(
          context,
          MaterialPageRoute(builder: (_) => const LivePhotoCheckScreen()),
        );
        if (sent != true) {
          if (mounted) {
            ErrorUI.showSnack(
              context,
              AppError(
                title: tr('Quick photo check'),
                message: tr('Photo check needed before you go online'),
                icon: Icons.face_retouching_natural,
              ),
            );
          }
          return;
        }
        _loadRecos();
      }

      try {
        final profile = await Supabase.instance.client
            .from('profiles')
            .select('is_active')
            .eq('id', userId)
            .maybeSingle();
        if (profile?['is_active'] != true) {
          if (!mounted) return;
          ErrorUI.showSnack(
            context,
            AppError(
              title: t.t('pending_approval'),
              message: t.t('pending_approval_hint'),
              icon: Icons.hourglass_top,
            ),
          );
          return;
        }
      } catch (e) {
        if (!mounted) return;
        ErrorUI.showSnack(
          context,
          AppError.from(e, onRetry: () => _toggleOnlineStatus(true)),
        );
        return;
      }
      try {
        await RingService.instance.requestFullScreenIntentPermission();
      } catch (e) {
        debugPrint('fullScreenIntent permission check failed: $e');
      }
    }

    setState(() => _isTogglingOnline = true);
    try {
      final nowIso = DateTime.now().toUtc().toIso8601String();
      await Supabase.instance.client.from('profiles').update({
        'is_online': value,
        'online_since': value ? nowIso : null,
      }).eq('id', userId);

      if (value) {
        KeepAwake.on();
        await _startOnlineService();
        await DriverLocationService.instance.start();
        _startHeadingWatcher();
        _fetchExistingPendingRides();
        await _loadDriverVehicleType();
      } else {
        KeepAwake.off();
        await _stopOnlineService();
        await DriverLocationService.instance.stop();
      }
      if (!mounted) return;
      setState(() {
        isOnline = value;
        _onlineSince = value ? DateTime.now() : null;
        currentAssignment = value
            ? 'Scanning for nearby requests...'
            : 'You are offline.';
        _isTogglingOnline = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => _isTogglingOnline = false);
      ErrorUI.showSnack(
        context,
        AppError.from(e, onRetry: () => _toggleOnlineStatus(value)),
      );
    }
  }

  // ════════════════════════════════════════════════════════════
  // FCM
  // ════════════════════════════════════════════════════════════
  void _setupFCMListeners() {
    if (kIsWeb) return;

    FirebaseMessaging.instance
        .getInitialMessage()
        .then((RemoteMessage? message) {
      if (message != null && message.data['ride_id'] != null) {
        _fetchAndShowRide(message.data['ride_id']);
      }
    });
    FirebaseMessaging.onMessageOpenedApp.listen((RemoteMessage message) {
      if (message.data['ride_id'] != null) {
        _fetchAndShowRide(message.data['ride_id']);
      }
    });
    FirebaseMessaging.onMessage.listen((RemoteMessage message) {
      PushDiag.note('push arrived while app open: type=${message.data['type']}');
      if (message.data['ride_id'] != null) {
        _fetchAndShowRide(message.data['ride_id']);
      }
    });
  }

  // ════════════════════════════════════════════════════════════
  // REALTIME — NEW RIDES
  // ════════════════════════════════════════════════════════════
  void _setupRealtimeRideListener() {
    _rideInsertSubscription = Supabase.instance.client
        .channel(
            'new_ride_notifications_${DateTime.now().millisecondsSinceEpoch}')
        .onPostgresChanges(
          event: PostgresChangeEvent.insert,
          schema: 'public',
          table: 'rides',
          callback: (payload) => _onRideOffered(payload.newRecord),
        )
        // A delivery released by another driver goes back to 'pending'
        // with a fresh dispatched_at — offer it again.
        .onPostgresChanges(
          event: PostgresChangeEvent.update,
          schema: 'public',
          table: 'rides',
          filter: PostgresChangeFilter(
            type: PostgresChangeFilterType.eq,
            column: 'status',
            value: 'pending',
          ),
          callback: (payload) {
            final r = payload.newRecord;
            if (r['driver_id'] == null && r['dispatched_at'] != null) {
              _onRideOffered(r);
            }
          },
        )
        .subscribe();
  }

  Future<void> _onRideOffered(Map<String, dynamic> newRide) async {
    final myId = Supabase.instance.client.auth.currentUser?.id;
    if (newRide['driver_id'] != null &&
        newRide['driver_id'].toString() == myId &&
        newRide['status'] != 'pending') {
      if (activeAcceptedRideId == null) {
        await _handleAdminAssignment(newRide);
      }
      return;
    }
    if (newRide['status'] != 'pending') return;
    if (driverReleasedRideIds.contains(newRide['id']?.toString())) return;
    if (!isOnline) return;
    if (activeAcceptedRideId != null) return;

    if (!_rideMatchesActiveVehicle(newRide)) return;
    if (!_ridePassesDestinationFilter(newRide)) return;

    // Key by dispatch so a re-offered delivery can ring again.
    final offerKey = _offerKey(newRide);
    if (_shownRideIds.contains(offerKey)) return;
    _shownRideIds.add(offerKey);
    // Age from the latest dispatch (re-offers) or creation.
    final offeredAt = DateTime.tryParse(
            (newRide['dispatched_at'] ?? newRide['created_at'] ?? '')
                .toString())
        ?.toUtc();
    if (offeredAt != null) {
      final ageMinutes =
          DateTime.now().toUtc().difference(offeredAt).inMinutes;
      if (ageMinutes > 5) return;
    }
    if (!mounted) return;
    // A request is already ringing: keep this one for the driver to choose.
    if (_ringOpen || globalRingShowing.value) {
      _enqueueOffer(newRide);
      return;
    }
    setState(() => activeIncomingRide = newRide);
    await _openRingAndHandle(newRide);
  }

  void _enqueueOffer(Map<String, dynamic> r) {
    final id = r['id']?.toString();
    if (id == null) return;
    if (activeIncomingRide?['id']?.toString() == id) return;
    final q = List<Map<String, dynamic>>.from(globalOfferQueue.value);
    if (q.any((x) => x['id']?.toString() == id)) return;
    if (q.length >= 5) return;
    q.add(Map<String, dynamic>.from(r));
    globalOfferQueue.value = q;
  }

  /// After a ring closes without an accept, ring the next waiting request.
  void _openNextQueued() {
    if (!mounted) return;
    final q = globalOfferQueue.value;
    if (q.isEmpty) return;
    if (!isOnline || activeAcceptedRideId != null) {
      globalOfferQueue.value = [];
      return;
    }
    final next = q.first;
    globalOfferQueue.value = q.skip(1).toList();
    setState(() => activeIncomingRide = next);
    _openRingAndHandle(next);
  }

  // ════════════════════════════════════════════════════════════
  // REALTIME — ADMIN ASSIGNMENT
  // ════════════════════════════════════════════════════════════
  void _setupAdminAssignmentListener() {
    _adminAssignSubscription?.unsubscribe();
    final myId = Supabase.instance.client.auth.currentUser?.id;
    if (myId == null) return;
    _adminAssignSubscription = Supabase.instance.client
        .channel('admin_assigned_$myId')
        .onPostgresChanges(
          event: PostgresChangeEvent.update,
          schema: 'public',
          table: 'rides',
          filter: PostgresChangeFilter(
            type: PostgresChangeFilterType.eq,
            column: 'driver_id',
            value: myId,
          ),
          callback: (payload) async {
            final row = payload.newRecord;
            final old = payload.oldRecord;
            final newStatus = row['status']?.toString();
            final oldStatus = old['status']?.toString();
            final rideId = row['id']?.toString();
            if (rideId == null) return;
            if (_locallyAcceptedRideIds.contains(rideId)) return;
            if (activeAcceptedRideId != null) return;
            final becameActive = (newStatus == 'accepted' ||
                    newStatus == 'in_progress') &&
                oldStatus != newStatus;
            if (becameActive) {
              await _handleAdminAssignment(row);
            }
          },
        )
        .subscribe();
  }

  Future<void> _handleAdminAssignment(Map<String, dynamic> ride) async {
    final rideId = ride['id'].toString();
    if (activeAcceptedRideId != null) return;
    if (_locallyAcceptedRideIds.contains(rideId)) return;

    final serviceType = (ride['service_type'] ?? 'Ride').toString();
    final customerId = ride['customer_id']?.toString();
    final pickupOtp = ride['pickup_otp']?.toString();

    DriverLocationService.instance.setActiveRide(rideId);
    if (customerId != null) _subscribeToCustomerLocation(customerId);
    _listenToActiveRideCancellation(rideId);

    if (!mounted) return;
    setState(() {
      activeAcceptedRideId = rideId;
      activeIncomingRide = null;
      _otpFromRide = pickupOtp;
      currentAssignment = 'Admin-assigned trip — heading to pickup.';
    });
    ErrorUI.showSnack(
      context,
      AppError(
        title: S.of(context).t('admin_assigned'),
        message: S.of(context).t('admin_assigned_hint'),
        icon: Icons.admin_panel_settings,
      ),
    );
    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => ActiveTripExecutionView(
          rideId: rideId,
          serviceType: serviceType,
          pickupOtp: pickupOtp,
        ),
      ),
    );
    if (mounted) {
      setState(() {
        activeAcceptedRideId = null;
        currentAssignment = 'Scanning for nearby requests...';
        _customerLiveLocation = null;
        _otpFromRide = null;
      });
      _customerLocationChannel?.unsubscribe();
      DriverLocationService.instance.setActiveRide(null);
      await _loadTodayEarningsStrip();
      await _checkIfDriverIsOnline();
    }
  }

  Future<void> _checkForAdminAssignedTrips() async {
    final myId = Supabase.instance.client.auth.currentUser?.id;
    if (myId == null) return;
    if (activeAcceptedRideId != null) return;
    try {
      final res = await Supabase.instance.client
          .from('rides')
          .select()
          .eq('driver_id', myId)
          .inFilter('status', ['accepted', 'in_progress', 'returning'])
          .order('created_at', ascending: false)
          .limit(1);
      if (res.isEmpty) return;
      final ride = Map<String, dynamic>.from(res.first as Map);
      final rideId = ride['id'].toString();
      if (_locallyAcceptedRideIds.contains(rideId)) return;
      await _handleAdminAssignment(ride);
    } catch (e) {
      debugPrint('checkForAdminAssignedTrips failed: $e');
    }
  }

  // ════════════════════════════════════════════════════════════
  // RING HANDLER
  // ════════════════════════════════════════════════════════════
  Future<void> _openRingAndHandle(Map<String, dynamic> rideData,
      {bool silent = false}) async {
    if (_ringOpen) return;
    if (globalRingShowing.value) return;
    _ringOpen = true;
    globalRingShowing.value = true;
    try {
      if (!mounted) return;
      final result = await Navigator.push<dynamic>(
        context,
        IncomingRideRingScreen.route(rideData, silent: silent),
      );
      if (result == 'hidden') {
        // Rang for a minute: it now waits in the list on the map.
        if (!mounted) return;
        setState(() => activeIncomingRide = null);
        _loadWaitingOrders();
        return;
      }
      if (result == 'cancelled') {
        if (!mounted) return;
        setState(() {
          activeIncomingRide = null;
          currentAssignment =
              'Request no longer available. Waiting for the next…';
        });
        ErrorUI.showSnack(
          context,
          AppError(
            title: S.of(context).t('request_unavailable'),
            message: S.of(context).t('request_unavailable_hint'),
            icon: Icons.info_outline,
          ),
        );
        return;
      }
      if (result == true) {
        // The ring screen has already accepted the trip on the server;
        // accepting again here found it "not pending" and wrongly said
        // "Too slow – another driver accepted".
        await _acceptTripReal(
          rideData['id'],
          rideData['fare'],
          rideData['service_type'] ?? 'Ride',
          rideData['customer_id'],
          alreadyAccepted: true,
        );
      } else if (result == 'countered') {
        if (!mounted) return;
        final rideId = rideData['id'].toString();
        setState(() {
          activeIncomingRide = null;
          _pendingCounterRideId = rideId;
          _pendingCounterAmount = null;
        });
        ErrorUI.showSnack(
          context,
          AppError(
            title: S.of(context).t('counter_sent'),
            message: S.of(context).t('counter_sent_hint'),
            icon: Icons.gavel_rounded,
          ),
        );
        try {
          final row = await Supabase.instance.client
              .from('rides')
              .select('driver_counter')
              .eq('id', rideId)
              .maybeSingle();
          final amt = (row?['driver_counter'] as num?)?.toDouble();
          if (mounted && amt != null) {
            setState(() => _pendingCounterAmount = amt);
          }
        } catch (e) {
          debugPrint('fetch counter amount failed: $e');
        }
        _watchCounterResponse(rideId);
      } else {
        if (mounted) setState(() => activeIncomingRide = null);
      }
    } finally {
      _ringOpen = false;
      globalRingShowing.value = false;
      WidgetsBinding.instance.addPostFrameCallback((_) => _openNextQueued());
    }
  }

  // ════════════════════════════════════════════════════════════
  // FETCH RIDE
  // ════════════════════════════════════════════════════════════
  Future<void> _fetchAndShowRide(String rideId) async {
    try {
      final res = await Supabase.instance.client
          .from('rides')
          .select()
          .eq('id', rideId)
          .single();
      final myId = Supabase.instance.client.auth.currentUser?.id;
      if (res['driver_id'] != null &&
          res['driver_id'].toString() == myId &&
          res['status'] != 'pending') {
        await _handleAdminAssignment(res);
        return;
      }
      if (res['status'] != 'pending') return;
      if (!_rideMatchesActiveVehicle(res)) return;
      if (!_ridePassesDestinationFilter(res)) return;
      if (_shownRideIds.contains(_offerKey(res))) return;
      _shownRideIds.add(_offerKey(res));
      setState(() {
        activeIncomingRide = res;
        _otpFromRide = res['pickup_otp']?.toString();
      });
      await _openRingAndHandle(res);
    } catch (e) {
      debugPrint('fetchAndShowRide failed: $e');
    }
  }

  Future<void> _fetchExistingPendingRides() async {
    try {
      final fiveMinutesAgo = DateTime.now()
          .toUtc()
          .subtract(const Duration(minutes: 5))
          .toIso8601String();
      final response = await Supabase.instance.client
          .from('rides')
          .select()
          .eq('status', 'pending')
          .or('created_at.gte.$fiveMinutesAgo,dispatched_at.gte.$fiveMinutesAgo')
          .order('created_at', ascending: false)
          .limit(3);
      if (!isOnline ||
          activeAcceptedRideId != null ||
          _ringOpen ||
          globalRingShowing.value) {
        return;
      }
      final eligible = <Map<String, dynamic>>[];
      for (final raw in response) {
        final ride = Map<String, dynamic>.from(raw as Map);
        if (driverReleasedRideIds.contains(ride['id']?.toString())) continue;
        if (!_rideMatchesActiveVehicle(ride)) continue;
        if (!_ridePassesDestinationFilter(ride)) continue;
        if (_shownRideIds.contains(_offerKey(ride))) continue;
        _shownRideIds.add(_offerKey(ride));
        eligible.add(ride);
      }
      if (eligible.isEmpty) return;
      // The first rings; the rest wait so the driver can choose.
      globalOfferQueue.value = eligible.skip(1).toList();
      setState(() {
        activeIncomingRide = eligible.first;
        _otpFromRide = eligible.first['pickup_otp']?.toString();
      });
      await _openRingAndHandle(eligible.first);
      return;
    } catch (e) {
      debugPrint('fetchExistingPendingRides failed: $e');
    }
  }

  // ════════════════════════════════════════════════════════════
  // CUSTOMER LOCATION
  // ════════════════════════════════════════════════════════════
  void _subscribeToCustomerLocation(String customerId) {
    _customerLocationChannel?.unsubscribe();
    _customerLocationChannel = Supabase.instance.client
        .channel('customer_location_$customerId')
        .onPostgresChanges(
          event: PostgresChangeEvent.update,
          schema: 'public',
          table: 'profiles',
          filter: PostgresChangeFilter(
            type: PostgresChangeFilterType.eq,
            column: 'id',
            value: customerId,
          ),
          callback: (payload) {
            final lat = payload.newRecord['lat'];
            final lng = payload.newRecord['lng'];
            if (lat != null && lng != null && mounted) {
              setState(() {
                _customerLiveLocation = gmaps.LatLng(
                  (lat as num).toDouble(),
                  (lng as num).toDouble(),
                );
              });
            }
          },
        )
        .subscribe();
  }

  void _listenToActiveRideCancellation(String rideId) {
    _rideCancelSubscription?.unsubscribe();
    _rideCancelSubscription = Supabase.instance.client
        .channel('driver_cancel_watch:$rideId')
        .onPostgresChanges(
          event: PostgresChangeEvent.update,
          schema: 'public',
          table: 'rides',
          filter: PostgresChangeFilter(
              type: PostgresChangeFilterType.eq,
              column: 'id',
              value: rideId),
          callback: (payload) {
            final updated = payload.newRecord;
            if (updated['status'] == 'cancelled') {
              DriverLocationService.instance.setActiveRide(null);
              _customerLocationChannel?.unsubscribe();
              _rideCancelSubscription?.unsubscribe();
              _rideCancelSubscription = null;
              if (mounted) {
                setState(() {
                  activeAcceptedRideId = null;
                  activeIncomingRide = null;
                  currentAssignment = 'Request was cancelled.';
                  _customerLiveLocation = null;
                  _otpFromRide = null;
                });
                Navigator.of(context).popUntil((r) => r.isFirst);
                ErrorUI.showSnack(
                  context,
                  AppError(
                    title: S.of(context).t('ride_cancelled'),
                    message: S.of(context).t('ride_cancelled_hint'),
                    icon: Icons.cancel_outlined,
                  ),
                );
                _loadTodayEarningsStrip();
              }
            }
          },
        )
        .subscribe();
  }

  // ════════════════════════════════════════════════════════════
  // ACCEPT TRIP
  // ════════════════════════════════════════════════════════════
  bool _acceptBusy = false;

  Future<void> _acceptTripReal(
    dynamic rideId,
    dynamic fareAmt,
    String serviceType,
    String? customerId, {
    bool alreadyAccepted = false,
    double? agreedFare,
  }) async {
    try {
      final driverId = Supabase.instance.client.auth.currentUser?.id;
      if (driverId == null) {
        ErrorUI.showSnack(
          context,
          AppError(
            title: S.of(context).t('not_signed_in'),
            message: S.of(context).t('not_signed_in_hint'),
            icon: Icons.lock_outline,
          ),
        );
        return;
      }
      final finalFare = agreedFare ?? (fareAmt as num?)?.toDouble();

      if (!alreadyAccepted) {
        _locallyAcceptedRideIds.add(rideId.toString());
        final updated = await Supabase.instance.client
            .from('rides')
            .update({
              'status': 'accepted',
              'driver_id': driverId,
              'accepted_at': DateTime.now().toUtc().toIso8601String(),
              if (finalFare != null) 'fare': finalFare,
            })
            .eq('id', rideId)
            .eq('status', 'pending')
            .select('id');
        if ((updated as List).isEmpty) {
          // Maybe it is already ours (double tap, or accepted on the ring
          // screen a moment ago): then just open the trip.
          final now = await Supabase.instance.client
              .from('rides')
              .select('status, driver_id')
              .eq('id', rideId)
              .maybeSingle();
          final mine = now != null &&
              now['driver_id']?.toString() == driverId &&
              ['accepted', 'in_progress'].contains(now['status']?.toString());
          if (mine) {
            alreadyAccepted = true;
          }
        }
        if (!alreadyAccepted && (updated as List).isEmpty) {
          _locallyAcceptedRideIds.remove(rideId.toString());
          if (!mounted) return;
          ErrorUI.showSnack(
            context,
            AppError(
              title: S.of(context).t('too_slow'),
              message: S.of(context).t('too_slow_hint'),
              icon: Icons.info_outline,
            ),
          );
          return;
        }
      }

      DriverLocationService.instance.setActiveRide(rideId.toString());
      if (customerId != null) {
        _subscribeToCustomerLocation(customerId);
      }

      unawaited(NotificationService.send(
        toUserId: driverId,
        type: 'ride_accepted',
        route: '/driver',
        tab: 'home',
        params: {'ride_id': rideId.toString()},
      ).catchError((e) => debugPrint('driver notify failed: $e')));

      if (customerId != null) {
        unawaited(NotificationService.send(
          toUserId: customerId,
          type: 'ride_accepted',
          route: '/order_tracking',
          params: {'order_id': rideId.toString()},
        ).catchError((e) => debugPrint('customer notify failed: $e')));
      }

      if (mounted) {
        setState(() {
          activeIncomingRide = null;
          activeAcceptedRideId = rideId.toString();
          currentAssignment = 'Navigating to pickup location!';
          _pendingCounterRideId = null;
          _pendingCounterAmount = null;
        });
      }

      _listenToActiveRideCancellation(rideId.toString());
      if (!mounted) return;
      await Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => ActiveTripExecutionView(
            rideId: rideId.toString(),
            serviceType: serviceType,
            pickupOtp: _otpFromRide,
          ),
        ),
      );
      if (mounted) {
        setState(() {
          activeAcceptedRideId = null;
          currentAssignment = 'Scanning for nearby requests...';
          _customerLiveLocation = null;
          _otpFromRide = null;
        });
        _customerLocationChannel?.unsubscribe();
        DriverLocationService.instance.setActiveRide(null);
        await _loadTodayEarningsStrip();
        await _checkIfDriverIsOnline();
      }
    } catch (e) {
      debugPrint('acceptTrip failed: $e');
      _locallyAcceptedRideIds.remove(rideId.toString());
      if (!mounted) return;
      ErrorUI.showSnack(
        context,
        AppError.from(
          e,
          onRetry: () => _acceptTripReal(
            rideId,
            fareAmt,
            serviceType,
            customerId,
            alreadyAccepted: alreadyAccepted,
            agreedFare: agreedFare,
          ),
        ),
      );
    }
  }

  // ════════════════════════════════════════════════════════════
  // COUNTER RESPONSE
  // ════════════════════════════════════════════════════════════
  void _watchCounterResponse(String rideId) {
    _counterResponseChannel?.unsubscribe();
    _counterResponseChannel = Supabase.instance.client
        .channel('counter_response_$rideId')
        .onPostgresChanges(
          event: PostgresChangeEvent.update,
          schema: 'public',
          table: 'rides',
          filter: PostgresChangeFilter(
            type: PostgresChangeFilterType.eq,
            column: 'id',
            value: rideId,
          ),
          callback: (payload) async {
            final row = payload.newRecord;
            final status = (row['status'] ?? '').toString();
            final bidStatus = (row['bid_status'] ?? '').toString();
            final myId = Supabase.instance.client.auth.currentUser?.id;
            final mine = row['driver_id']?.toString() == myId;
            // Still waiting for the customer.
            if (status == 'pending' && bidStatus == 'countered' &&
                row['counter_driver_id']?.toString() == myId) {
              return;
            }
            if (status == 'accepted' && bidStatus == 'accepted' && mine) {
              _counterResponseChannel?.unsubscribe();
              _counterResponseChannel = null;
              if (!mounted) return;
              final agreed = (row['driver_counter'] as num?)?.toDouble() ??
                  (row['fare'] as num?)?.toDouble() ??
                  0;
              final serviceType = (row['service_type'] ?? 'Ride').toString();
              final customerId = row['customer_id']?.toString();
              await _acceptTripReal(
                rideId,
                agreed,
                serviceType,
                customerId,
                alreadyAccepted: true,
                agreedFare: agreed,
              );
            } else if (status == 'cancelled' ||
                bidStatus == 'rejected' ||
                (status == 'accepted' && !mine) ||
                status == 'pending') {
              _counterResponseChannel?.unsubscribe();
              _counterResponseChannel = null;
              if (!mounted) return;
              setState(() {
                _pendingCounterRideId = null;
                _pendingCounterAmount = null;
              });
              ErrorUI.showSnack(
                context,
                AppError(
                  title: S.of(context).t('counter_declined'),
                  message: S.of(context).t('counter_declined_hint'),
                  icon: Icons.info_outline,
                ),
              );
              _fetchExistingPendingRides();
            }
          },
        )
        .subscribe();
  }

  Future<void> _recoverPendingCounterOffer() async {
    final myId = Supabase.instance.client.auth.currentUser?.id;
    if (myId == null) return;
    try {
      final res = await Supabase.instance.client
          .from('rides')
          .select()
          .eq('counter_driver_id', myId)
          .eq('bid_status', 'countered')
          .order('created_at', ascending: false)
          .limit(1);
      if (res.isEmpty) return;
      final ride = Map<String, dynamic>.from(res.first as Map);
      final rideId = ride['id'].toString();
      if (mounted) {
        setState(() {
          _pendingCounterRideId = rideId;
          _pendingCounterAmount =
              (ride['driver_counter'] as num?)?.toDouble();
        });
      }
      _watchCounterResponse(rideId);
    } catch (e) {
      debugPrint('recoverPendingCounterOffer failed: $e');
    }
  }

  Future<void> _cancelPendingCounter() async {
    final rideId = _pendingCounterRideId;
    if (rideId == null) return;
    _counterResponseChannel?.unsubscribe();
    _counterResponseChannel = null;
    try {
      await Supabase.instance.client
          .rpc('ride_withdraw_counter', params: {'p_ride': rideId});
    } catch (e) {
      debugPrint('cancelPendingCounter failed: $e');
    }
    if (mounted) {
      setState(() {
        _pendingCounterRideId = null;
        _pendingCounterAmount = null;
      });
    }
  }

  // ════════════════════════════════════════════════════════════
  // DISPATCH MODE
  // ════════════════════════════════════════════════════════════
  Future<void> _setDispatchMode(DispatchMode mode) async {
    if (mode == _dispatchMode) return;
    setState(() => _dispatchMode = mode);
    try {
      final userId = Supabase.instance.client.auth.currentUser?.id;
      if (userId == null) return;
      await Supabase.instance.client
          .from('profiles')
          .update({'dispatch_mode': mode.name}).eq('id', userId);
    } catch (e) {
      debugPrint('setDispatchMode failed: $e');
    }
  }

  Future<void> _openDispatchModeSheet() async {
    final t = S.of(context);
    await showModalBottomSheet(
      context: context,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (ctx) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.only(top: 16, bottom: 24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: Colors.grey.shade300,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
              const SizedBox(height: 20),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Text(
                  t.t('dispatch_mode'),
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: _Palette.ink,
                  ),
                ),
              ),
              const SizedBox(height: 4),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Text(
                  t.t('dispatch_mode_hint'),
                  style: const TextStyle(
                      fontSize: 13.5, color: _Palette.inkMuted),
                ),
              ),
              const SizedBox(height: 16),
              ...DispatchMode.values.map((mode) {
                return RadioListTile<DispatchMode>(
                  value: mode,
                  groupValue: _dispatchMode,
                  activeColor: _Palette.accent,
                  title: Text(
                    mode.label(context),
                    style: const TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w700,
                        color: _Palette.ink),
                  ),
                  onChanged: (v) {
                    Navigator.pop(ctx);
                    if (v != null) _setDispatchMode(v);
                  },
                );
              }),
              const SizedBox(height: 8),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: _Palette.accent.withValues(alpha: 0.10),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Row(
                    children: [
                      const Icon(Icons.info_outline,
                          size: 16, color: Color(0xFF7A5A00)),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Text(
                          t.t('dispatch_mode_info'),
                          style: TextStyle(
                              fontSize: 13,
                              color: const Color(0xFF7A5A00)
                                  .withValues(alpha: 0.9),
                              height: 1.4),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ════════════════════════════════════════════════════════════
  // MANUAL REFRESH
  // ════════════════════════════════════════════════════════════
  Future<void> _manualRefresh() async {
    if (_isRefreshing) return;
    setState(() => _isRefreshing = true);
    try {
      await _initDriverLocation();
      await _restoreOnlineState();
      await _restoreDestinationFilter();
      await _fetchExistingPendingRides();
      await _loadTodayEarningsStrip();
      await _loadDriverVehicleType();
      await _loadHeader();
      await _checkActiveVehicle();
      await _loadTraining();
      await _checkForAdminAssignedTrips();
      await _recoverPendingCounterOffer();
      await _loadOnlineSince();
      await _loadUnreadNotifications();
      if (_showDemandHeat) await _loadDemandClusters();
      if (mounted) {
        ErrorUI.showSnack(
          context,
          AppError(
            title: S.of(context).t('refreshed'),
            message: S.of(context).t('refreshed_hint'),
            icon: Icons.check_circle_outline,
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ErrorUI.showSnack(context, AppError.from(e, onRetry: _manualRefresh));
      }
    } finally {
      if (mounted) setState(() => _isRefreshing = false);
    }
  }

  // ════════════════════════════════════════════════════════════
  // ACTIVATION WATCHDOG
  // ════════════════════════════════════════════════════════════
  void _startActivationWatchdog() {
    _activationWatchdog?.cancel();
    _activationWatchdog =
        Timer.periodic(const Duration(seconds: 60), (_) async {
      if (!mounted || !isOnline) return;
      final userId = Supabase.instance.client.auth.currentUser?.id;
      if (userId == null) return;
      try {
        final p = await Supabase.instance.client
            .from('profiles')
            .select('is_active')
            .eq('id', userId)
            .maybeSingle();
        if (p?['is_active'] != true) {
          await Supabase.instance.client.from('profiles').update({
            'is_online': false,
            'online_since': null,
          }).eq('id', userId);
          await _stopOnlineService();
          await DriverLocationService.instance.stop();
          if (!mounted) return;
          setState(() {
            isOnline = false;
            _onlineSince = null;
            currentAssignment = 'Account deactivated — you are now offline.';
          });
          ErrorUI.showSnack(
            context,
            AppError(
              title: S.of(context).t('account_deactivated'),
              message: S.of(context).t('account_deactivated_hint'),
              icon: Icons.warning_amber_rounded,
            ),
          );
        }
      } catch (e) {
        debugPrint('watchdog error: $e');
      }
    });
  }

  // ════════════════════════════════════════════════════════════
  // BUILD
  // ════════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        _header(),
        if (!_isCheckingVehicle && !_hasActiveVehicle) _noVehicleBanner(),
        _lowBalanceBanner(),
        _recoBanner(),
        if (_pendingCounterRideId != null) _pendingCounterBanner(),
        Expanded(
          child: RefreshIndicator(
            color: _Palette.blue,
            onRefresh: _manualRefresh,
            child: SingleChildScrollView(
              physics: const AlwaysScrollableScrollPhysics(),
              child: Column(
                children: [
                  const SizedBox(height: 16),
                  _statRow(),
                  DriverGoalCard(earnedToday: _todayEarnings),
                  const SizedBox(height: 14),
                  _serviceTabs(),
                  const SizedBox(height: 14),
                  if (_homeTab == 0) ...[
                    _mapCard(),
                    const SizedBox(height: 14),
                    _incomingRequestCard(),
                    const SizedBox(height: 14),
                    _quickActionsRow(),
                    const SizedBox(height: 16),
                    if ((_trainingSnapshot?.isCertified ?? false) == false &&
                        (_trainingSnapshot?.requiredTotal ?? 0) > 0) ...[
                      _academyCard(),
                      const SizedBox(height: 16),
                    ],
                    if (isOnline) _opportunitiesSection(),
                    if (!isOnline) _offlineNudge(),
                    DriverWeekCard(key: ValueKey('wk$_todayTrips')),
                  ] else ...[
                    if (_waitingOrders.isNotEmpty)
                      _waitingOrdersCard()
                    else
                      _marketplaceEmpty(),
                    const SizedBox(height: 14),
                    if (!isOnline) _offlineNudge(),
                  ],
                  const SizedBox(height: 24),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }


  // ════════════════════════════════════════════════════════════
  // TRANSPORT / MARKETPLACE TABS
  // ════════════════════════════════════════════════════════════
  int _homeTab = 0; // 0 = Transport, 1 = Marketplace

  Widget _serviceTabs() {
    Widget seg(int i, IconData icon, String label, {int badge = 0}) {
      final on = _homeTab == i;
      return Expanded(
        child: GestureDetector(
          onTap: () => setState(() => _homeTab = i),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 180),
            padding: const EdgeInsets.symmetric(vertical: 12),
            decoration: BoxDecoration(
              color: on ? EfuridePalette.accent : Colors.transparent,
              borderRadius: BorderRadius.circular(14),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(icon,
                    size: 20,
                    color: on ? EfuridePalette.ink : _Palette.inkMuted),
                const SizedBox(width: 8),
                Text(label,
                    style: TextStyle(
                        fontSize: 15.5,
                        fontWeight: on ? FontWeight.w900 : FontWeight.w700,
                        color: on ? EfuridePalette.ink : _Palette.inkMuted)),
                if (badge > 0) ...[
                  const SizedBox(width: 6),
                  Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                    decoration: BoxDecoration(
                        color: _Palette.dropoff,
                        borderRadius: BorderRadius.circular(10)),
                    child: Text('$badge',
                        style: const TextStyle(
                            color: Colors.white,
                            fontSize: 12,
                            fontWeight: FontWeight.w800)),
                  ),
                ],
              ],
            ),
          ),
        ),
      );
    }

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(4),
            decoration: BoxDecoration(
              color: const Color(0xFFF1EBDD),
              borderRadius: BorderRadius.circular(18),
            ),
            child: Row(
              children: [
                seg(0, Icons.directions_car_filled_outlined, tr('Transport')),
                seg(1, Icons.shopping_cart_outlined, tr('Marketplace'),
                    badge: _waitingOrders.length),
              ],
            ),
          ),
          if (_homeTab == 1)
            Padding(
              padding: const EdgeInsets.only(top: 8),
              child: Text(
                  tr('Marketplace: delivery requests from shops and stores'),
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                      fontSize: 13.5, color: _Palette.inkMuted)),
            ),
        ],
      ),
    );
  }

  Widget _marketplaceEmpty() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Container(
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(
          color: _Palette.lightBlue,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: _Palette.blue.withValues(alpha: 0.15)),
        ),
        child: Row(
          children: [
            const Icon(Icons.shopping_bag_outlined,
                size: 28, color: _Palette.blueDeep),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                isOnline
                    ? tr('No shop deliveries right now. New ones appear here and ring your phone.')
                    : tr('Go online to receive shop deliveries.'),
                style: const TextStyle(
                    fontSize: 14.5, color: _Palette.inkMuted, height: 1.4),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ════════════════════════════════════════════════════════════
  // HEADER
  // ════════════════════════════════════════════════════════════
  Widget _header() {
    final s = S.of(context);
    final bikeMode = _driverVehicleType == 'bike';

    return Container(
      decoration: const BoxDecoration(
        color: EfuridePalette.cream,
      ),
      child: SafeArea(
        bottom: false,
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 4, 16, 6),
              child: Row(
                children: [
                  KongoBrand(role: s.t('role_driver')),
                  const Spacer(),
                  Material(
                    color: EfuridePalette.ink.withValues(alpha: 0.06),
                    shape: const CircleBorder(),
                    child: InkWell(
                      customBorder: const CircleBorder(),
                      onTap: _openDispatchModeSheet,
                      child: Padding(
                        padding: const EdgeInsets.all(8),
                        child: Icon(
                          _dispatchMode.icon,
                          color: EfuridePalette.ink,
                          size: 20,
                        ),
                      ),
                    ),
                  ),
                  const MessagesIconButton(color: EfuridePalette.ink),
                  GestureDetector(
                    onTap: () async {
                      await Navigator.pushNamed(context, '/notifications');
                      _loadUnreadNotifications();
                    },
                    child: Stack(
                      clipBehavior: Clip.none,
                      children: [
                        const Icon(
                          Icons.notifications_none_rounded,
                          color: EfuridePalette.ink,
                          size: 26,
                        ),
                        if (_unreadNotifications > 0)
                          Positioned(
                            right: -2,
                            top: -3,
                            child: Container(
                              padding: const EdgeInsets.all(4),
                              constraints: const BoxConstraints(
                                  minWidth: 18, minHeight: 18),
                              decoration: const BoxDecoration(
                                color: _Palette.dropoff,
                                shape: BoxShape.circle,
                              ),
                              child: Center(
                                child: Text(
                                  _unreadNotifications > 9
                                      ? '9+'
                                      : '$_unreadNotifications',
                                  style: const TextStyle(
                                    color: Colors.white,
                                    fontSize: 12,
                                    fontWeight: FontWeight.w900,
                                    height: 1.0,
                                  ),
                                ),
                              ),
                            ),
                          ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 14),
              decoration: const BoxDecoration(
                color: EfuridePalette.cream,
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(24),
                  topRight: Radius.circular(24),
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Greeting and profile picture sit on the same level.
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Expanded(
                        child: SizedBox(
                          height: 60,
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                _greeting(context),
                                style: const TextStyle(
                                  color: EfuridePalette.inkMuted,
                                  fontSize: 14.5,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                              const SizedBox(height: 2),
                              Text(
                                _driverFirstName ?? s.t('role_driver'),
                                style: const TextStyle(
                                  color: EfuridePalette.ink,
                                  fontSize: 26,
                                  fontWeight: FontWeight.w900,
                                  letterSpacing: -0.4,
                                  height: 1.1,
                                ),
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                              ),
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      GestureDetector(
                        // Opens the Profile ("More") tab, so the bottom bar stays.
                        onTap: () => Navigator.pushNamedAndRemoveUntil(
                            context, '/driver?tab=more', (_) => false),
                        child: Container(
                          width: 60,
                          height: 60,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            border: Border.all(
                              color: EfuridePalette.accent,
                              width: 2.5,
                            ),
                          ),
                          child: ClipOval(
                            child: (_driverAvatarUrl?.isNotEmpty == true)
                                ? Image.network(
                                    _driverAvatarUrl!,
                                    width: 60,
                                    height: 60,
                                    fit: BoxFit.cover,
                                    errorBuilder: (_, __, ___) =>
                                        _avatarFallback(
                                            size: 60, fontSize: 22),
                                  )
                                : _avatarFallback(size: 60, fontSize: 22),
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  // Status on the left, the ONLINE toggle right under the
                  // profile picture.
                  Container(
                    padding: const EdgeInsets.fromLTRB(14, 8, 8, 8),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(22),
                      border: Border.all(
                          color: EfuridePalette.ink.withValues(alpha: 0.06)),
                    ),
                    child: Row(
                      children: [
                        Container(
                          width: 9,
                          height: 9,
                          decoration: BoxDecoration(
                            color: isOnline
                                ? _Palette.online
                                : _Palette.inkMuted,
                            shape: BoxShape.circle,
                            boxShadow: isOnline
                                ? [
                                    BoxShadow(
                                      color: _Palette.online
                                          .withValues(alpha: 0.6),
                                      blurRadius: 6,
                                      spreadRadius: 1,
                                    ),
                                  ]
                                : null,
                          ),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Text(
                            isOnline
                                ? '${s.t('you_online')}${bikeMode ? ' · 🏍️ ${s.t('bike_mode')}' : ''}'
                                : s.t('you_offline'),
                            style: TextStyle(
                              fontSize: 13.5,
                              color: isOnline
                                  ? _Palette.online
                                  : _Palette.inkMuted,
                              fontWeight: FontWeight.w700,
                            ),
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                        const SizedBox(width: 8),
                        _onlinePill(),
                      ],
                    ),
                  ),
                  if (isOnline && _destinationFilterActive) ...[
                    const SizedBox(height: 12),
                    _destinationFilterChip(),
                  ],
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _onlinePill() {
    final s = S.of(context);
    return GestureDetector(
      onTap: _isTogglingOnline
          ? null
          : () => _toggleOnlineStatus(!isOnline),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 300),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
        decoration: BoxDecoration(
          color: isOnline ? _Palette.online : _Palette.inkMuted,
          borderRadius: BorderRadius.circular(30),
          boxShadow: isOnline
              ? [
                  BoxShadow(
                    color: _Palette.online.withValues(alpha: 0.4),
                    blurRadius: 12,
                    spreadRadius: 1,
                  ),
                ]
              : null,
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              isOnline ? s.t('online') : s.t('offline'),
              style: const TextStyle(
                color: Colors.white,
                fontSize: 14,
                fontWeight: FontWeight.w800,
                letterSpacing: 0.3,
              ),
            ),
            const SizedBox(width: 10),
            Container(
              width: 24,
              height: 24,
              decoration: const BoxDecoration(
                color: Colors.white,
                shape: BoxShape.circle,
              ),
              child: _isTogglingOnline
                  ? const Padding(
                      padding: EdgeInsets.all(6),
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        color: _Palette.online,
                      ),
                    )
                  : Center(
                      child: Container(
                        width: 10,
                        height: 10,
                        decoration: BoxDecoration(
                          color: isOnline
                              ? _Palette.online
                              : _Palette.inkMuted,
                          shape: BoxShape.circle,
                        ),
                      ),
                    ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _destinationFilterChip() {
    final label = _destinationFilterLabel;
    final shortLabel =
        label.length > 32 ? '${label.substring(0, 32)}…' : label;

    return InkWell(
      onTap: _openDestinationFilterPicker,
      borderRadius: BorderRadius.circular(20),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(
          color: _Palette.accent.withValues(alpha: 0.18),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: _Palette.accent.withValues(alpha: 0.6),
            width: 1.2,
          ),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            const KIcon(Icons.home_outlined,
                size: 14, color: _Palette.accent),
            const SizedBox(width: 8),
            Flexible(
              child: Text(
                shortLabel,
                style: const TextStyle(
                  fontSize: 13.5,
                  fontWeight: FontWeight.w700,
                  color: _Palette.accent,
                ),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
            ),
            const SizedBox(width: 8),
            GestureDetector(
              onTap: _clearDestinationFilter,
              child: const Icon(Icons.close,
                  size: 14, color: _Palette.accent),
            ),
          ],
        ),
      ),
    );
  }

  // ════════════════════════════════════════════════════════════
  // STAT ROW
  // ════════════════════════════════════════════════════════════
  Widget _statRow() {
    final s = S.of(context);
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Row(
        children: [
          _statCard(
            icon: Icons.payments_outlined,
            label: s.t('today_earnings'),
            value: CountryConfig.money(_todayEarnings),
          ),
          const SizedBox(width: 10),
          _statCard(
            icon: Icons.check_circle_outline,
            label: s.t('completed_trips'),
            value: '$_todayTrips',
          ),
          const SizedBox(width: 10),
          _statCard(
            icon: Icons.access_time_rounded,
            label: s.t('online_time'),
            value: _formatOnlineTime(),
          ),
        ],
      ),
    );
  }

  Widget _statCard({
    required IconData icon,
    required String label,
    required String value,
  }) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: _Palette.divider),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.03),
              blurRadius: 6,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  width: 22,
                  height: 22,
                  decoration: BoxDecoration(
                    color: _Palette.blue.withValues(alpha: 0.12),
                    borderRadius: BorderRadius.circular(6),
                  ),
                  child: Icon(icon,
                      size: 14, color: _Palette.blueDeep),
                ),
                const SizedBox(width: 6),
                Expanded(
                  child: Text(
                    label,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      fontSize: 12,
                      color: _Palette.inkMuted,
                      fontWeight: FontWeight.w600,
                      height: 1.2,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
            Text(
              value,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w900,
                color: _Palette.ink,
                letterSpacing: -0.3,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ════════════════════════════════════════════════════════════
  // MAP CARD
  // ════════════════════════════════════════════════════════════
  /// Orders nobody has taken yet, right under the map: the first three
  /// with Accept, plus "See all".
  Widget _waitingOrdersCard() {
    final shown = _waitingOrders.take(3).toList();
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Container(
        padding: const EdgeInsets.fromLTRB(14, 12, 14, 8),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: _Palette.accent, width: 1.6),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              children: [
                const Icon(Icons.shopping_bag_outlined,
                    color: _Palette.ink, size: 22),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    tr('{0} orders waiting',
                        ['${_waitingOrders.length}']),
                    style: const TextStyle(
                        fontSize: 17, fontWeight: FontWeight.w800),
                  ),
                ),
                if (_waitingOrders.length > 3)
                  TextButton(
                    onPressed: _openWaitingOrders,
                    child: Text(tr('See all'),
                        style: const TextStyle(
                            fontSize: 15, fontWeight: FontWeight.w800)),
                  ),
              ],
            ),
            for (final r in shown) _waitingOrderRow(r),
          ],
        ),
      ),
    );
  }

  Widget _waitingOrderRow(Map<String, dynamic> r) {
    final created = DateTime.tryParse('${r['created_at'] ?? ''}');
    final mins = created == null
        ? null
        : DateTime.now().difference(created.toLocal()).inMinutes;
    double? km;
    final plat = (r['pickup_lat'] as num?)?.toDouble();
    final plng = (r['pickup_lng'] as num?)?.toDouble();
    if (driverLocation != null && plat != null && plng != null) {
      km = _haversineKm(driverLocation!, gmaps.LatLng(plat, plng));
    }
    final service = (r['service_type'] ?? 'Delivery').toString();
    return InkWell(
      borderRadius: BorderRadius.circular(12),
      onTap: () => _openWaitingOrder(r),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 10),
        child: Row(
          children: [
            Icon(
              service == 'Grocery'
                  ? Icons.shopping_basket
                  : service == 'Pharmacy'
                      ? Icons.local_pharmacy
                      : Icons.restaurant,
              color: _Palette.ink,
              size: 26,
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    (r['pickup_address'] ?? '').toString().split('·').first.trim(),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                        fontSize: 15.5, fontWeight: FontWeight.w800),
                  ),
                  Text(
                    [
                      if (km != null) '${km.toStringAsFixed(1)} km ${tr('away')}',
                      if (mins != null) tr('waiting {0} min', ['$mins']),
                    ].join('  ·  '),
                    style: const TextStyle(
                        fontSize: 13.5,
                        fontWeight: FontWeight.w600,
                        color: _Palette.inkMuted),
                  ),
                ],
              ),
            ),
            Text(
              CountryConfig.money((r['fare'] as num?)?.toDouble() ?? 0),
              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w900),
            ),
            const SizedBox(width: 8),
            ElevatedButton(
              onPressed: () => _openWaitingOrder(r),
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFFF2B705),
                foregroundColor: const Color(0xFF0B1220),
                elevation: 0,
                minimumSize: const Size(0, 40),
                padding: const EdgeInsets.symmetric(horizontal: 14),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10)),
              ),
              child: Text(tr('View'),
                  style: const TextStyle(fontWeight: FontWeight.w800)),
            ),
          ],
        ),
      ),
    );
  }

  Widget _mapCard() {
    final s = S.of(context);
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: SizedBox(
        height: 260,
        child: ClipRRect(
          borderRadius: BorderRadius.circular(18),
          child: Stack(
            children: [
              Positioned.fill(child: _buildGoogleMap()),
              Positioned(
                left: 12,
                top: 12,
                child: Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 12, vertical: 8),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(22),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withValues(alpha: 0.10),
                        blurRadius: 8,
                        offset: const Offset(0, 2),
                      ),
                    ],
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Container(
                        width: 9,
                        height: 9,
                        decoration: BoxDecoration(
                          color: isOnline
                              ? _Palette.online
                              : _Palette.inkMuted,
                          shape: BoxShape.circle,
                        ),
                      ),
                      const SizedBox(width: 8),
                      Text(
                        isOnline
                            ? s.t('you_online_short')
                            : s.t('you_offline_short'),
                        style: const TextStyle(
                          fontSize: 13.5,
                          fontWeight: FontWeight.w700,
                          color: _Palette.ink,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Positioned(
                right: 12,
                top: 12,
                child: _mapFab(
                  icon: Icons.layers_outlined,
                  onTap: _toggleDemandHeat,
                  color: _showDemandHeat ? _Palette.heat : Colors.white,
                  iconColor: _showDemandHeat
                      ? Colors.white
                      : _Palette.ink,
                ),
              ),
              Positioned(
                right: 12,
                top: 60,
                child: _mapFab(
                  icon: Icons.near_me_outlined,
                  onTap: () => _setFollowLock(true),
                ),
              ),
              if (_waitingOrders.isNotEmpty)
                Positioned(
                  left: 12,
                  bottom: 12,
                  child: Material(
                    color: _Palette.ink,
                    borderRadius: BorderRadius.circular(22),
                    elevation: 3,
                    child: InkWell(
                      borderRadius: BorderRadius.circular(22),
                      onTap: _openWaitingOrders,
                      child: Padding(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 14, vertical: 10),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const Icon(Icons.shopping_bag_outlined,
                                color: Colors.white, size: 18),
                            const SizedBox(width: 8),
                            Text(
                              tr('{0} orders waiting',
                                  ['${_waitingOrders.length}']),
                              style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 14.5,
                                  fontWeight: FontWeight.w800),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              Positioned(
                right: 12,
                bottom: 12,
                // Lock / unlock the map on the driver.
                child: _mapFab(
                  icon: _followLock ? Icons.lock : Icons.lock_open,
                  color: _followLock ? _Palette.accent : Colors.white,
                  iconColor: _followLock ? Colors.white : _Palette.ink,
                  onTap: () => _setFollowLock(!_followLock),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _mapFab({
    required IconData icon,
    required VoidCallback onTap,
    Color color = Colors.white,
    Color iconColor = _Palette.ink,
  }) {
    return Material(
      color: color,
      shape: const CircleBorder(),
      elevation: 3,
      shadowColor: Colors.black.withValues(alpha: 0.15),
      child: InkWell(
        customBorder: const CircleBorder(),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(10),
          child: _loadingDemand && icon == Icons.layers_outlined
              ? SizedBox(
                  width: 20,
                  height: 20,
                  child: CircularProgressIndicator(
                    strokeWidth: 2,
                    color: iconColor,
                  ),
                )
              : Icon(icon, size: 20, color: iconColor),
        ),
      ),
    );
  }

  Widget _buildGoogleMap() {
    final initialCenter = driverLocation ??
        _lastCameraPosition?.target ??
        const gmaps.LatLng(-1.2921, 36.8219);

    final markers = <gmaps.Marker>{
      if (driverLocation != null)
        gmaps.Marker(
          markerId: const gmaps.MarkerId('driver'),
          position: gmaps.LatLng(
            driverLocation!.latitude,
            driverLocation!.longitude,
          ),
          rotation: _headingRadians * 180.0 / math.pi,
          anchor: const Offset(0.5, 0.5),
          flat: true,
          zIndex: 10,
          icon: _driverMarkerIcon ??
              gmaps.BitmapDescriptor.defaultMarkerWithHue(
                  gmaps.BitmapDescriptor.hueAzure),
        ),
      if (_customerLiveLocation != null)
        gmaps.Marker(
          markerId: const gmaps.MarkerId('customer'),
          position: gmaps.LatLng(
            _customerLiveLocation!.latitude,
            _customerLiveLocation!.longitude,
          ),
          anchor: const Offset(0.5, 0.5),
          zIndex: 5,
          icon: _customerMarkerIcon ??
              gmaps.BitmapDescriptor.defaultMarkerWithHue(
                  gmaps.BitmapDescriptor.hueGreen),
        ),
      if (_destinationFilterActive && _destinationFilterLatLng != null)
        gmaps.Marker(
          markerId: const gmaps.MarkerId('dest_filter'),
          position: gmaps.LatLng(
            _destinationFilterLatLng!.latitude,
            _destinationFilterLatLng!.longitude,
          ),
          anchor: const Offset(0.5, 1.0),
          zIndex: 6,
          icon: gmaps.BitmapDescriptor.defaultMarkerWithHue(
              gmaps.BitmapDescriptor.hueOrange),
        ),
    };

    final circles = <gmaps.Circle>{
      if (_showDemandHeat)
        for (int i = 0; i < _demandClusters.length; i++)
          gmaps.Circle(
            circleId: gmaps.CircleId('heat_$i'),
            center: gmaps.LatLng(
              _demandClusters[i].center.latitude,
              _demandClusters[i].center.longitude,
            ),
            radius: 400 + (_demandClusters[i].weight * 600),
            fillColor: _Palette.heat.withValues(
                alpha: 0.12 + _demandClusters[i].weight * 0.30),
            strokeColor: _Palette.heat.withValues(alpha: 0.05),
            strokeWidth: 1,
          ),
      if (_destinationFilterActive && _destinationFilterLatLng != null)
        gmaps.Circle(
          circleId: const gmaps.CircleId('dest_filter_radius'),
          center: gmaps.LatLng(
            _destinationFilterLatLng!.latitude,
            _destinationFilterLatLng!.longitude,
          ),
          radius: 5000,
          fillColor: _Palette.accent.withValues(alpha: 0.10),
          strokeColor: _Palette.accent.withValues(alpha: 0.55),
          strokeWidth: 2,
        ),
    };

    return gmaps.GoogleMap(
      initialCameraPosition: gmaps.CameraPosition(
        target:
            gmaps.LatLng(initialCenter.latitude, initialCenter.longitude),
        zoom: _followZoom,
      ),
      onMapCreated: (controller) {
        _mapController = controller;
        if (_pendingCenterOnDriver && driverLocation != null) {
          _pendingCenterOnDriver = false;
          _followCamera(driverLocation!);
        }
      },
      onCameraMove: (pos) {
        _lastCameraPosition = pos;
        // Pinch-zoom while locked keeps the new zoom level.
        if (_followLock) _followZoom = pos.zoom.clamp(12.0, 20.0);
      },
      // Locked: the map can't be dragged away from the driver.
      scrollGesturesEnabled: !_followLock,
      myLocationEnabled: false,
      myLocationButtonEnabled: false,
      zoomControlsEnabled: false,
      compassEnabled: false,
      mapToolbarEnabled: false,
      tiltGesturesEnabled: false,
      rotateGesturesEnabled: false,
      markers: markers,
      circles: circles,
    );
  }

  // ════════════════════════════════════════════════════════════
  // INCOMING RIDE REQUEST
  // ════════════════════════════════════════════════════════════
  Widget _incomingRequestCard() {
    final s = S.of(context);
    final hasRequest = activeIncomingRide != null;

    if (!hasRequest) {
      return Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: _Palette.lightBlue,
            borderRadius: BorderRadius.circular(18),
            border: Border.all(
              color: _Palette.blue.withValues(alpha: 0.15),
            ),
          ),
          child: Row(
            children: [
              Container(
                width: 42,
                height: 42,
                decoration: BoxDecoration(
                  color: _Palette.blue.withValues(alpha: 0.12),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(
                  isOnline
                      ? Icons.hourglass_empty
                      : Icons.power_settings_new,
                  color: _Palette.blueDeep,
                  size: 22,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      isOnline
                          ? s.t('waiting_requests')
                          : s.t('you_are_offline'),
                      style: const TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w800,
                        color: _Palette.blueDeep,
                      ),
                    ),
                    const SizedBox(height: 3),
                    Text(
                      isOnline
                          ? s.t('waiting_requests_hint')
                          : s.t('go_online_hint_short'),
                      style: const TextStyle(
                        fontSize: 13,
                        color: _Palette.inkMuted,
                        height: 1.35,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      );
    }

    final pickup =
        (activeIncomingRide!['pickup_address'] ?? '—').toString();
    final dropoff =
        (activeIncomingRide!['dropoff_address'] ?? '—').toString();
    final fare =
        (activeIncomingRide!['fare'] as num?)?.toDouble() ?? 0.0;
    final distance =
        (activeIncomingRide!['distance_km'] as num?)?.toDouble() ?? 0.0;
    final eta = (activeIncomingRide!['eta_minutes'] as num?)?.toInt() ?? 8;

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: _Palette.lightBlue,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(
            color: _Palette.blue.withValues(alpha: 0.15),
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(Icons.directions_car_rounded,
                    size: 22, color: _Palette.blueDeep),
                const SizedBox(width: 10),
                Text(
                  s.t('new_ride_request'),
                  style: const TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.w900,
                    color: _Palette.blueDeep,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _routeRow(
                        color: _Palette.pickup,
                        icon: Icons.location_on,
                        title: pickup,
                        subtitle: s.t('pickup_location'),
                      ),
                      const SizedBox(height: 12),
                      _routeRow(
                        color: _Palette.dropoff,
                        icon: Icons.location_on,
                        title: dropoff,
                        subtitle: s.t('dropoff_location'),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 12),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(
                      CountryConfig.money(fare),
                      style: const TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.w900,
                        color: _Palette.blueDeep,
                        letterSpacing: -0.4,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      '${distance.toStringAsFixed(1)} km • $eta ${s.t('min')}',
                      style: TextStyle(
                        fontSize: 13.5,
                        color: _Palette.blueDeep
                            .withValues(alpha: 0.65),
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ],
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () {
                      final key = _offerKey(activeIncomingRide!);
                      setState(() => activeIncomingRide = null);
                      _shownRideIds.add(key);
                    },
                    icon: const Icon(Icons.close_rounded, size: 18),
                    label: Text(s.t('decline'),
                        style: const TextStyle(
                            fontSize: 14, fontWeight: FontWeight.w800)),
                    style: OutlinedButton.styleFrom(
                      foregroundColor: _Palette.dropoff,
                      side: const BorderSide(
                          color: _Palette.dropoff, width: 1.5),
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12)),
                      backgroundColor: Colors.white,
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: () {
                      if (_acceptBusy) return; // no double taps
                      _acceptBusy = true;
                      final ride = activeIncomingRide!;
                      _acceptTripReal(
                        ride['id'],
                        ride['fare'],
                        (ride['service_type'] ?? 'Ride').toString(),
                        ride['customer_id'],
                      ).whenComplete(() => _acceptBusy = false);
                    },
                    icon: const Icon(Icons.check_rounded, size: 20),
                    label: Text(s.t('accept'),
                        style: const TextStyle(
                            fontSize: 14, fontWeight: FontWeight.w900)),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: _Palette.onlineDeep,
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12)),
                      elevation: 0,
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _routeRow({
    required Color color,
    required IconData icon,
    required String title,
    required String subtitle,
  }) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(top: 2),
          child: Icon(icon, color: color, size: 20),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: const TextStyle(
                  fontSize: 14.5,
                  fontWeight: FontWeight.w800,
                  color: _Palette.ink,
                  height: 1.2,
                ),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
              const SizedBox(height: 2),
              Text(
                subtitle,
                style: TextStyle(
                  fontSize: 13,
                  color: _Palette.blueDeep.withValues(alpha: 0.55),
                  fontWeight: FontWeight.w500,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  // ════════════════════════════════════════════════════════════
  // QUICK ACTIONS
  // ════════════════════════════════════════════════════════════
  Widget _quickActionsRow() {
    final s = S.of(context);
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Row(
        children: [
          _quickTile(
            icon: Icons.school_outlined,
            label: s.t('driver_academy'),
            onTap: _openTraining,
          ),
          const SizedBox(width: 10),
          _quickTile(
            icon: Icons.person_pin_circle_outlined,
            label: s.t('destination_filter'),
            onTap: _openDestinationFilterPicker,
          ),
          const SizedBox(width: 10),
          _quickTile(
            icon: Icons.directions_car_outlined,
            label: s.t('my_vehicle'),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => const VehicleManagementScreen(),
                ),
              ).then((_) {
                _checkActiveVehicle();
                _loadDriverVehicleType();
              });
            },
          ),
        ],
      ),
    );
  }

  Widget _quickTile({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
  }) {
    return Expanded(
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(14),
        child: Container(
          padding:
              const EdgeInsets.symmetric(vertical: 16, horizontal: 8),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: _Palette.divider),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withValues(alpha: 0.03),
                blurRadius: 6,
                offset: const Offset(0, 2),
              ),
            ],
          ),
          child: Column(
            children: [
              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  color: _Palette.blue.withValues(alpha: 0.10),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(icon,
                    color: _Palette.blueDeep, size: 22),
              ),
              const SizedBox(height: 8),
              Text(
                label,
                textAlign: TextAlign.center,
                style: const TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w700,
                  color: _Palette.ink,
                  height: 1.25,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ════════════════════════════════════════════════════════════
  // DRIVER ACADEMY
  // ════════════════════════════════════════════════════════════
  Widget _academyCard() {
    final s = S.of(context);
    final snap = _trainingSnapshot;
    final done = snap?.requiredCompleted ?? 0;
    final total = snap?.requiredTotal ?? 0;
    final pct = snap?.progressFraction ?? 0.0;

    final subtitle = total > 0
        ? '$done ${s.t('of')} $total ${s.t('modules_complete')}'
        : s.t('get_started');

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: _openTraining,
          borderRadius: BorderRadius.circular(16),
          child: Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(
                color: _Palette.blue.withValues(alpha: 0.35),
                width: 1.4,
              ),
            ),
            child: Row(
              children: [
                Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    color: _Palette.blue.withValues(alpha: 0.12),
                    shape: BoxShape.circle,
                  ),
                  child: const KIcon(Icons.school_outlined,
                      color: _Palette.blueDeep, size: 22),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        s.t('driver_academy'),
                        style: const TextStyle(
                          fontSize: 14.5,
                          fontWeight: FontWeight.w800,
                          color: _Palette.ink,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        subtitle,
                        style: const TextStyle(
                          fontSize: 13,
                          color: _Palette.inkMuted,
                          height: 1.3,
                        ),
                      ),
                      if (total > 0) ...[
                        const SizedBox(height: 8),
                        ClipRRect(
                          borderRadius: BorderRadius.circular(3),
                          child: LinearProgressIndicator(
                            value: pct,
                            minHeight: 5,
                            backgroundColor: _Palette.divider,
                            valueColor:
                                const AlwaysStoppedAnimation<Color>(
                              _Palette.blueDeep,
                            ),
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          '${(pct * 100).round()}%',
                          style: const TextStyle(
                            fontSize: 12.5,
                            fontWeight: FontWeight.w700,
                            color: _Palette.blueDeep,
                          ),
                        ),
                      ],
                    ],
                  ),
                ),
                const Icon(Icons.chevron_right,
                    color: _Palette.inkMuted, size: 22),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ════════════════════════════════════════════════════════════
  // OPPORTUNITIES
  // ════════════════════════════════════════════════════════════
  Widget _opportunitiesSection() {
    final s = S.of(context);
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: _Palette.cream,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: _Palette.divider),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                AppImage(
                  AppImages.briefcase,
                  size: 20,
                  fallbackIcon: Icons.work_outline,
                ),
                const SizedBox(width: 8),
                Text(
                  s.t('opportunities'),
                  style: const TextStyle(
                    fontSize: 14.5,
                    fontWeight: FontWeight.w800,
                    color: _Palette.ink,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: _Palette.divider),
              ),
              child: Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: _Palette.blue.withValues(alpha: 0.12),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: const Icon(Icons.hourglass_empty,
                        size: 20, color: _Palette.blueDeep),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          s.t('waiting_request'),
                          style: const TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w700,
                            color: _Palette.ink,
                          ),
                        ),
                        const SizedBox(height: 2),
                        Text(
                          s.t('offers_hint'),
                          style: const TextStyle(
                            fontSize: 13.5,
                            color: _Palette.inkMuted,
                            height: 1.4,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ════════════════════════════════════════════════════════════
  // OFFLINE NUDGE
  // ════════════════════════════════════════════════════════════
  Widget _offlineNudge() {
    final s = S.of(context);
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Container(
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [
              _Palette.blue.withValues(alpha: 0.15),
              _Palette.blue.withValues(alpha: 0.04),
            ],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(18),
          border:
              Border.all(color: _Palette.blue.withValues(alpha: 0.4)),
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: _Palette.blue.withValues(alpha: 0.2),
                shape: BoxShape.circle,
              ),
              child: const Icon(Icons.power_settings_new,
                  color: _Palette.blueDeep, size: 26),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    s.t('go_online'),
                    style: const TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w800,
                      color: _Palette.ink,
                    ),
                  ),
                  const SizedBox(height: 3),
                  Text(
                    s.t('go_online_hint'),
                    style: const TextStyle(
                      fontSize: 14,
                      color: _Palette.inkMuted,
                      height: 1.3,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ════════════════════════════════════════════════════════════
  // NO VEHICLE BANNER
  // ════════════════════════════════════════════════════════════
  Widget _noVehicleBanner() {
    final s = S.of(context);
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: Colors.orange.shade50,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: Colors.orange.shade300, width: 1.2),
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(Icons.warning_amber_rounded,
                color: Colors.orange.shade800, size: 22),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    s.t('no_vehicle'),
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 14,
                      color: Colors.orange.shade900,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    s.t('no_vehicle_hint'),
                    style: TextStyle(
                      fontSize: 13,
                      color:
                          Colors.orange.shade900.withValues(alpha: 0.85),
                      height: 1.3,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 8),
            TextButton(
              style: TextButton.styleFrom(
                backgroundColor: Colors.orange.shade800,
                foregroundColor: Colors.white,
                padding:
                    const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                minimumSize: const Size(0, 32),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(20)),
              ),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => const VehicleManagementScreen(),
                  ),
                ).then((_) {
                  _checkActiveVehicle();
                  _loadDriverVehicleType();
                });
              },
              child: Text(
                s.t('add'),
                style: const TextStyle(
                    fontSize: 13.5, fontWeight: FontWeight.bold),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ════════════════════════════════════════════════════════════
  // PENDING COUNTER BANNER
  // ════════════════════════════════════════════════════════════
  Widget _pendingCounterBanner() {
    final s = S.of(context);
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: const Color(0xFFFFF8E1),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: _Palette.bid, width: 1.2),
        ),
        child: Row(
          children: [
            const SizedBox(
              width: 18,
              height: 18,
              child: CircularProgressIndicator(
                  strokeWidth: 2, color: _Palette.bid),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Text(
                '${s.t('pending_counter')}'
                '${_pendingCounterAmount != null ? ' — ${CountryConfig.money(_pendingCounterAmount!)}' : ''}…',
                style: const TextStyle(
                    fontSize: 13.5,
                    fontWeight: FontWeight.w600,
                    color: Color(0xFF7A5A00)),
              ),
            ),
            TextButton(
              style: TextButton.styleFrom(
                padding:
                    const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                minimumSize: const Size(0, 30),
              ),
              onPressed: _cancelPendingCounter,
              child: Text(
                s.t('cancel'),
                style: const TextStyle(
                    fontSize: 13.5, fontWeight: FontWeight.bold),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
