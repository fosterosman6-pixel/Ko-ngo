// lib/screens/driver/live_photo_check_screen.dart
//
// The weekly selfie check. Camera only (no gallery), so it is a live photo
// of the person driving. An admin looks at it and can reject it.
// Pops with true once the photo was sent.

import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

import 'package:efuride_app/config/efuride_palette.dart';
import 'package:efuride_app/l10n/app_strings.dart';
import 'package:efuride_app/services/photo_check_service.dart';

class LivePhotoCheckScreen extends StatefulWidget {
  const LivePhotoCheckScreen({super.key});

  @override
  State<LivePhotoCheckScreen> createState() => _LivePhotoCheckScreenState();
}

class _LivePhotoCheckScreenState extends State<LivePhotoCheckScreen> {
  final _picker = ImagePicker();
  Uint8List? _shot;
  bool _sending = false;
  String? _error;

  Future<void> _take() async {
    try {
      final img = await _picker.pickImage(
        source: ImageSource.camera,
        preferredCameraDevice: CameraDevice.front,
        maxWidth: 1200,
        imageQuality: 80,
      );
      if (img == null) return;
      final bytes = await img.readAsBytes();
      if (mounted) {
        setState(() {
          _shot = bytes;
          _error = null;
        });
      }
    } catch (_) {
      if (mounted) {
        setState(() => _error =
            tr('Could not open the camera. Allow camera access for ko!ngo in your phone settings.'));
      }
    }
  }

  Future<void> _send() async {
    final shot = _shot;
    if (shot == null || _sending) return;
    setState(() {
      _sending = true;
      _error = null;
    });
    try {
      await PhotoCheckService.submit(shot);
      if (!mounted) return;
      ScaffoldMessenger.maybeOf(context)?.showSnackBar(
          SnackBar(content: Text(tr('Photo check sent. Thank you.'))));
      Navigator.pop(context, true);
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _sending = false;
        _error = tr(
            'Could not send the photo. Check your internet and try again.');
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final shot = _shot;
    return Scaffold(
      backgroundColor: EfuridePalette.cream,
      appBar: AppBar(
        backgroundColor: EfuridePalette.cream,
        elevation: 0,
        iconTheme: const IconThemeData(color: EfuridePalette.ink),
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(24, 4, 24, 20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text(tr('Quick photo check'),
                  style: const TextStyle(
                      fontSize: 28,
                      fontWeight: FontWeight.w900,
                      color: EfuridePalette.ink)),
              const SizedBox(height: 10),
              Text(
                  tr('Take a live selfie now so we know it is you. This takes a few seconds.'),
                  style: const TextStyle(
                      fontSize: 16,
                      height: 1.4,
                      color: EfuridePalette.inkMuted)),
              const SizedBox(height: 6),
              Text(
                  tr('Your face must be clearly visible. Photos from the gallery are not accepted.'),
                  style: const TextStyle(
                      fontSize: 14,
                      height: 1.4,
                      color: EfuridePalette.inkMuted)),
              const SizedBox(height: 20),
              Expanded(
                child: Center(
                  child: shot == null
                      ? Container(
                          width: 220,
                          height: 220,
                          decoration: const BoxDecoration(
                              color: Color(0xFFF1EBDD),
                              shape: BoxShape.circle),
                          child: const Icon(Icons.face_retouching_natural,
                              size: 96, color: EfuridePalette.inkMuted),
                        )
                      : ClipOval(
                          child: Image.memory(shot,
                              width: 260, height: 260, fit: BoxFit.cover),
                        ),
                ),
              ),
              if (_error != null)
                Padding(
                  padding: const EdgeInsets.only(bottom: 12),
                  child: Text(_error!,
                      textAlign: TextAlign.center,
                      style: const TextStyle(
                          color: Color(0xFFB91C1C),
                          fontWeight: FontWeight.w600)),
                ),
              if (shot == null)
                _bigButton(tr('Take selfie'), _take, primary: true)
              else ...[
                _bigButton(
                    _sending ? tr('Sending…') : tr('Send photo'),
                    _sending ? null : _send,
                    primary: true),
                const SizedBox(height: 10),
                _bigButton(tr('Retake'), _sending ? null : _take),
              ],
            ],
          ),
        ),
      ),
    );
  }

  Widget _bigButton(String label, VoidCallback? onTap,
      {bool primary = false}) {
    return SizedBox(
      height: 56,
      child: ElevatedButton(
        style: ElevatedButton.styleFrom(
          backgroundColor:
              primary ? EfuridePalette.accent : const Color(0xFFF1EBDD),
          foregroundColor: EfuridePalette.ink,
          elevation: 0,
          shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(16)),
        ),
        onPressed: onTap,
        child: Text(label,
            style:
                const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
      ),
    );
  }
}
