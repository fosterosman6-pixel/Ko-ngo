// lib/screens/driver/driver_onboarding_screen.dart

import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:efuride_app/config/app_images.dart';
import 'package:efuride_app/widgets/app_image.dart';
import 'package:efuride_app/screens/driver/driver_bank_details_screen.dart';
import 'package:efuride_app/screens/driver/driver_document_upload_screen.dart';
import 'package:efuride_app/screens/driver/vehicle_management_screen.dart';
import 'package:efuride_app/services/ring_service.dart';
import 'package:efuride_app/utils/app_error.dart';
import 'package:efuride_app/utils/error_ui.dart';
import 'package:efuride_app/l10n/app_strings.dart';

class _Palette {
  static const cream = Color(0xFFFAF6EE);
  static const ink = Color(0xFF1A1A1A);
  static const inkMuted = Color(0xFF575047);
  static const accent = Color(0xFFF2B705);
  static const divider = Color(0xFFE8E2D5);
  static const blue = Color(0xFF1E88E5);
  static const pickup = Color(0xFF34C759);
}

class DriverOnboardingScreen extends StatefulWidget {
  const DriverOnboardingScreen({super.key});

  @override
  State<DriverOnboardingScreen> createState() =>
      _DriverOnboardingScreenState();
}

class _DriverOnboardingScreenState extends State<DriverOnboardingScreen> {
  bool _isLoading = true;
  bool _isSubmitting = false;

  int _documentsUploaded = 0;
  int _documentsRequired = 3;
  bool _hasActiveVehicle = false;
  bool _hasVehiclePending = false;
  bool _hasBankDetails = false;

  bool get _documentsComplete => _documentsUploaded >= _documentsRequired;
  bool get _vehicleComplete => _hasActiveVehicle || _hasVehiclePending;
  bool get _allComplete =>
      _documentsComplete && _vehicleComplete && _hasBankDetails;

  @override
  void initState() {
    super.initState();
    _loadProgress();
  }

  Future<void> _loadProgress() async {
    if (!mounted) return;
    setState(() => _isLoading = true);

    try {
      final userId = Supabase.instance.client.auth.currentUser?.id;
      if (userId == null) {
        if (mounted) setState(() => _isLoading = false);
        return;
      }

      final docs = await Supabase.instance.client
          .from('documents')
          .select('type')
          .eq('user_id', userId);
      final docTypes = (docs as List)
          .map((d) => d['type']?.toString() ?? '')
          .toSet();
      final uploaded = ['id_card', 'license', 'logbook']
          .where(docTypes.contains)
          .length;

      final vehicles = await Supabase.instance.client
          .from('vehicles')
          .select('status')
          .eq('driver_id', userId);
      final vehicleList = vehicles as List;
      final hasActive = vehicleList
          .any((v) => (v['status'] ?? '').toString() == 'active');
      final hasPending = vehicleList.any((v) {
        final s = (v['status'] ?? '').toString();
        return s == 'under_review' || s == 'pending';
      });

      final bank = await Supabase.instance.client
          .from('driver_bank_details')
          .select('id')
          .eq('driver_id', userId)
          .maybeSingle();

      if (!mounted) return;
      setState(() {
        _documentsUploaded = uploaded;
        _hasActiveVehicle = hasActive;
        _hasVehiclePending = hasPending;
        _hasBankDetails = bank != null;
        _isLoading = false;
      });
    } catch (e) {
      debugPrint('load progress failed: $e');
      if (mounted) setState(() => _isLoading = false);
    }
  }

  Future<void> _openDocuments() async {
    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => const DriverDocumentUploadScreen(),
      ),
    );
    await _loadProgress();
  }

  Future<void> _openVehicles() async {
    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => const VehicleManagementScreen(),
      ),
    );
    await _loadProgress();
  }

  Future<void> _openBank() async {
    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => const DriverBankDetailsScreen(),
      ),
    );
    await _loadProgress();
  }

  Future<void> _submitForApproval() async {
    if (!_allComplete) return;
    setState(() => _isSubmitting = true);

    try {
      final userId = Supabase.instance.client.auth.currentUser?.id;
      if (userId == null) throw Exception('Not signed in');

      await Supabase.instance.client.from('profiles').update({
        'onboarding_step': 'pending',
        'kyc_submitted_at': DateTime.now().toUtc().toIso8601String(),
      }).eq('id', userId);

      if (!mounted) return;
      await _requestRingPermissions();

      if (!mounted) return;
      Navigator.pushReplacementNamed(context, '/pending_approval');
    } catch (e) {
      if (!mounted) return;
      setState(() => _isSubmitting = false);
      ErrorUI.showSnack(context, AppError.from(e));
    }
  }

  Future<void> _requestRingPermissions() async {
    if (!mounted) return;

    await showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (dialogContext) => AlertDialog(
        title: Text(tr('Never miss a trip')),
        content: const Text(
          "On the next screen, Android will ask to let ko!ngo show "
          "full-screen alerts. Please allow it — otherwise ride "
          "requests may not wake your phone when it's locked.",
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(),
            child: Text(tr('Continue')),
          ),
        ],
      ),
    );

    await RingService.instance.requestFullScreenIntentPermission();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _Palette.cream,
      appBar: AppBar(
        backgroundColor: _Palette.cream,
        elevation: 0,
        iconTheme: const IconThemeData(color: _Palette.ink),
        title: Text(
          tr('Complete your profile'),
          style: TextStyle(
              color: _Palette.ink,
              fontWeight: FontWeight.bold,
              fontSize: 18),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh, color: _Palette.ink),
            onPressed: _loadProgress,
          ),
        ],
      ),
      body: _isLoading
          ? const Center(
              child: CircularProgressIndicator(color: _Palette.accent))
          : SafeArea(
              child: RefreshIndicator(
                color: _Palette.accent,
                onRefresh: _loadProgress,
                child: ListView(
                  padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
                  physics: const AlwaysScrollableScrollPhysics(),
                  children: [
                    _progressHeader(),
                    const SizedBox(height: 20),

                    _stepCard(
                      step: 1,
                      title: tr('KYC documents'),
                      subtitle: _documentsComplete
                          ? 'All $_documentsRequired documents uploaded'
                          : '$_documentsUploaded of $_documentsRequired uploaded',
                      complete: _documentsComplete,
                      asset: AppImages.shieldCheck,
                      fallbackIcon: Icons.badge_outlined,
                      onTap: _openDocuments,
                    ),
                    const SizedBox(height: 12),

                    _stepCard(
                      step: 2,
                      title: tr('Vehicle'),
                      subtitle: _hasActiveVehicle
                          ? 'Approved and active'
                          : _hasVehiclePending
                              ? 'Pending admin review'
                              : 'No vehicle added yet',
                      complete: _vehicleComplete,
                      asset: AppImages.driverCar,
                      fallbackIcon: Icons.directions_car_outlined,
                      onTap: _openVehicles,
                    ),
                    const SizedBox(height: 12),

                    _stepCard(
                      step: 3,
                      title: tr('Bank details'),
                      subtitle: _hasBankDetails
                          ? 'Submitted for review'
                          : 'Add your payout account',
                      complete: _hasBankDetails,
                      asset: AppImages.bank,
                      fallbackIcon: Icons.account_balance_outlined,
                      onTap: _openBank,
                    ),

                    const SizedBox(height: 24),

                    _submitButton(),
                  ],
                ),
              ),
            ),
    );
  }

  Widget _progressHeader() {
    final total = 3;
    final done = [
      _documentsComplete,
      _vehicleComplete,
      _hasBankDetails,
    ].where((x) => x).length;
    final pct = done / total;

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFFFDF5DA),
        border: Border.all(color: const Color(0xFFF2D27A)),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            tr('Onboarding progress'),
            style: TextStyle(
                color: _Palette.inkMuted,
                fontSize: 13.5,
                fontWeight: FontWeight.w600),
          ),
          const SizedBox(height: 6),
          Text(
            tr('{0} of {1} complete', [done, total]),
            style: const TextStyle(
                color: _Palette.ink,
                fontSize: 22,
                fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 14),
          ClipRRect(
            borderRadius: BorderRadius.circular(6),
            child: LinearProgressIndicator(
              minHeight: 8,
              value: pct,
              backgroundColor: _Palette.ink.withValues(alpha: 0.06),
              valueColor:
                  const AlwaysStoppedAnimation<Color>(_Palette.accent),
            ),
          ),
          const SizedBox(height: 10),
          Text(
            _allComplete
                ? 'Ready to submit — tap the button below.'
                : 'Complete all three steps to submit for admin approval.',
            style: const TextStyle(
                color: _Palette.inkMuted, fontSize: 13.5, height: 1.4),
          ),
        ],
      ),
    );
  }

  Widget _stepCard({
    required int step,
    required String title,
    required String subtitle,
    required bool complete,
    required String asset,
    required IconData fallbackIcon,
    required VoidCallback onTap,
  }) {
    final color = complete ? _Palette.pickup : _Palette.inkMuted;
    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(16),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(16),
        child: Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
              color: complete
                  ? _Palette.pickup.withValues(alpha: 0.4)
                  : _Palette.divider,
              width: complete ? 1.5 : 1,
            ),
          ),
          child: Row(
            children: [
              Container(
                width: 52,
                height: 52,
                padding: const EdgeInsets.all(6),
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: complete
                      ? _Palette.pickup.withValues(alpha: 0.12)
                      : _Palette.blue.withValues(alpha: 0.10),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: complete
                    ? const Icon(Icons.check,
                        color: _Palette.pickup, size: 24)
                    : AppImage(
                        asset,
                        size: 40,
                        fallbackIcon: fallbackIcon,
                      ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Text(
                          tr('STEP {0}', [step]),
                          style: const TextStyle(
                              fontSize: 12,
                              color: _Palette.inkMuted,
                              fontWeight: FontWeight.w700,
                              letterSpacing: 0.5),
                        ),
                        if (complete) ...[
                          const SizedBox(width: 8),
                          Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 6, vertical: 1),
                            decoration: BoxDecoration(
                              color: _Palette.pickup
                                  .withValues(alpha: 0.15),
                              borderRadius: BorderRadius.circular(4),
                            ),
                            child: Text(
                              tr('DONE'),
                              style: TextStyle(
                                  fontSize: 12,
                                  fontWeight: FontWeight.bold,
                                  color: _Palette.pickup),
                            ),
                          ),
                        ],
                      ],
                    ),
                    const SizedBox(height: 4),
                    Text(
                      title,
                      style: const TextStyle(
                          fontSize: 15,
                          fontWeight: FontWeight.bold,
                          color: _Palette.ink),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      subtitle,
                      style: TextStyle(fontSize: 13.5, color: color),
                    ),
                  ],
                ),
              ),
              const Icon(Icons.chevron_right,
                  color: _Palette.inkMuted, size: 22),
            ],
          ),
        ),
      ),
    );
  }

  Widget _submitButton() {
    return Column(
      children: [
        if (!_allComplete)
          Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.orange.withValues(alpha: 0.08),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: Colors.orange.shade300),
              ),
              child: Row(
                children: [
                  Icon(Icons.info_outline,
                      color: Colors.orange, size: 18),
                  SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      tr('Complete all three steps before submitting.'),
                      style:
                          TextStyle(fontSize: 13.5, color: _Palette.ink),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ElevatedButton(
          onPressed: _allComplete && !_isSubmitting
              ? _submitForApproval
              : null,
          style: ElevatedButton.styleFrom(
            backgroundColor: const Color(0xFFF2B705),
            foregroundColor: const Color(0xFF0B1220),
            disabledBackgroundColor: Colors.grey.shade300,
            disabledForegroundColor: Colors.grey.shade600,
            padding: const EdgeInsets.symmetric(vertical: 16),
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(14)),
          ),
          child: _isSubmitting
              ? const SizedBox(
                  width: 20,
                  height: 20,
                  child: CircularProgressIndicator(
                      strokeWidth: 2, color: const Color(0xFF0B1220)),
                )
              : Text(
                  tr('Submit for admin approval'),
                  style: TextStyle(
                      fontSize: 15, fontWeight: FontWeight.w700),
                ),
        ),
      ],
    );
  }
}
