// lib/screens/driver/driver_recommendations_screen.dart
//
// "Recommendations": a short list of things a driver can still fix, each
// one a tap away from the screen where it is fixed. Only real, checked
// facts are listed (a check that fails to load adds nothing, so there are
// no false alarms).

import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'package:efuride_app/config/country_config.dart';
import 'package:efuride_app/config/efuride_palette.dart';
import 'package:efuride_app/l10n/app_strings.dart';
import 'package:efuride_app/services/photo_check_service.dart';
import 'package:efuride_app/services/pricing_service.dart';
import 'package:efuride_app/services/wallet_service.dart';

class DriverReco {
  final IconData icon;
  final String text;
  final String route;

  /// 'low_balance' for the low-balance warning, empty otherwise.
  final String kind;
  const DriverReco(this.icon, this.text, this.route, {this.kind = ''});
}

class DriverRecommendations {
  static const _requiredDocs = [
    'id_card',
    'selfie',
    'license',
    'logbook',
    'police_clearance',
  ];

  /// Works out the list. [hasVehicle] and [academyIncomplete] come from the
  /// driver home screen, which already knows them.
  static Future<List<DriverReco>> load({
    required bool hasVehicle,
    required bool academyIncomplete,
  }) async {
    final out = <DriverReco>[];
    final db = Supabase.instance.client;
    final uid = db.auth.currentUser?.id;
    if (uid == null) return out;

    if (!hasVehicle) {
      out.add(DriverReco(
          Icons.directions_car_outlined, tr('Add your vehicle'), '/vehicles'));
    }

    // The weekly live selfie check.
    if (await PhotoCheckService.isDue()) {
      out.add(DriverReco(Icons.face_retouching_natural,
          tr('Take your weekly selfie check'), '/driver_photo_check'));
    }

    // Money owed to ko!ngo from cash trips.
    try {
      final w = await WalletService.myWallet();
      try {
        await PricingService.current();
      } catch (_) {}
      if (w.available < PricingService.last.lowBalanceLevel) {
        out.add(DriverReco(
            Icons.account_balance_wallet_outlined,
            tr('Your balance is low ({0}). Top up.',
                [CountryConfig.money(w.available)]),
            '/wallet',
            kind: 'low_balance'));
      }
      if (w.owed > 0) {
        out.add(DriverReco(
            Icons.savings_outlined,
            tr('You owe ko!ngo {0}', [CountryConfig.money(w.owed)]),
            '/wallet'));
      }
    } catch (_) {}

    Map<String, dynamic>? me;
    try {
      me = await db
          .from('profiles')
          .select(
              'profile_picture_url, is_verified, bank_name, bank_account_number')
          .eq('id', uid)
          .maybeSingle()
          .timeout(const Duration(seconds: 10));
    } catch (_) {}

    if (me != null) {
      if ((me['profile_picture_url'] ?? '').toString().trim().isEmpty) {
        out.add(DriverReco(Icons.account_circle_outlined,
            tr('Add your profile picture'), '/driver_profile'));
      }

      if (me['is_verified'] != true) {
        try {
          final rows = await db
              .from('documents')
              .select('type, status')
              .eq('user_id', uid)
              .timeout(const Duration(seconds: 10));
          final status = <String, String>{
            for (final r in rows)
              (r['type'] ?? '').toString():
                  (r['status'] ?? '').toString().toLowerCase(),
          };
          var missing = 0;
          var waiting = 0;
          for (final t in _requiredDocs) {
            final s = status[t];
            if (s == null || s.isEmpty || s == 'rejected') {
              missing++;
            } else if (s == 'pending') {
              waiting++;
            }
          }
          if (missing > 0) {
            out.add(DriverReco(Icons.badge_outlined,
                tr('Upload your papers ({0} missing)', ['$missing']), '/verify'));
          } else if (waiting > 0) {
            out.add(DriverReco(Icons.schedule,
                tr('Your papers are being checked'), '/verify'));
          }
        } catch (_) {}
      }

      final bank = (me['bank_name'] ?? '').toString().trim();
      final acct = (me['bank_account_number'] ?? '').toString().trim();
      if (bank.isEmpty && acct.isEmpty) {
        out.add(DriverReco(Icons.account_balance_outlined,
            tr('Add your bank details to get paid'), '/driver_bank'));
      }
    }

    if (academyIncomplete) {
      out.add(DriverReco(Icons.school_outlined, tr('Finish driver academy'),
          '/driver_training'));
    }
    return out;
  }
}

class DriverRecommendationsScreen extends StatefulWidget {
  final bool hasVehicle;
  final bool academyIncomplete;
  const DriverRecommendationsScreen({
    super.key,
    required this.hasVehicle,
    required this.academyIncomplete,
  });

  @override
  State<DriverRecommendationsScreen> createState() =>
      _DriverRecommendationsScreenState();
}

class _DriverRecommendationsScreenState
    extends State<DriverRecommendationsScreen> {
  List<DriverReco>? _items;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final items = await DriverRecommendations.load(
      hasVehicle: widget.hasVehicle,
      academyIncomplete: widget.academyIncomplete,
    );
    if (mounted) setState(() => _items = items);
  }

  Future<void> _open(DriverReco r) async {
    await Navigator.pushNamed(context, r.route);
    if (mounted) _load(); // the list updates once something is fixed
  }

  @override
  Widget build(BuildContext context) {
    final items = _items;
    return Scaffold(
      backgroundColor: EfuridePalette.cream,
      appBar: AppBar(
        backgroundColor: EfuridePalette.cream,
        elevation: 0,
        iconTheme: const IconThemeData(color: EfuridePalette.ink),
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 4, 20, 20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text(tr('Recommendations'),
                  style: const TextStyle(
                      fontSize: 32,
                      fontWeight: FontWeight.w900,
                      color: EfuridePalette.ink)),
              const SizedBox(height: 18),
              Expanded(
                child: items == null
                    ? const Center(child: CircularProgressIndicator())
                    : items.isEmpty
                        ? Padding(
                            padding: const EdgeInsets.only(top: 24),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const Icon(Icons.check_circle,
                                    color: Color(0xFF16A34A)),
                                const SizedBox(width: 10),
                                Expanded(
                                  child: Text(
                                      tr('You are all set. Nothing to fix.'),
                                      style: const TextStyle(
                                          fontSize: 17,
                                          color: EfuridePalette.ink)),
                                ),
                              ],
                            ),
                          )
                        : ListView.separated(
                            itemCount: items.length,
                            separatorBuilder: (_, __) =>
                                const SizedBox(height: 6),
                            itemBuilder: (_, i) => _row(items[i]),
                          ),
              ),
              SizedBox(
                height: 56,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFFF1EBDD),
                    foregroundColor: EfuridePalette.ink,
                    elevation: 0,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(16)),
                  ),
                  onPressed: () => Navigator.pop(context),
                  child: Text(tr('Close'),
                      style: const TextStyle(
                          fontSize: 18, fontWeight: FontWeight.w700)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _row(DriverReco r) {
    return InkWell(
      borderRadius: BorderRadius.circular(14),
      onTap: () => _open(r),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 10),
        child: Row(
          children: [
            Container(
              width: 52,
              height: 52,
              decoration: const BoxDecoration(
                  color: Color(0xFFF1EBDD), shape: BoxShape.circle),
              child: Icon(r.icon, color: EfuridePalette.ink),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Text(r.text,
                  style: const TextStyle(
                      fontSize: 17,
                      fontWeight: FontWeight.w600,
                      color: EfuridePalette.ink)),
            ),
            const Icon(Icons.chevron_right, color: EfuridePalette.inkMuted),
          ],
        ),
      ),
    );
  }
}
