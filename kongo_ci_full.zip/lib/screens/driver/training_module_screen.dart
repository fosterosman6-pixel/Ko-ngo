// lib/screens/driver/training_module_screen.dart

import 'package:flutter/material.dart';
import 'package:efuride_app/services/training_service.dart';
import 'package:efuride_app/utils/app_error.dart';
import 'package:efuride_app/utils/error_ui.dart';
import 'package:efuride_app/l10n/app_strings.dart';

class _Palette {
  static const cream = Color(0xFFFAF6EE);
  static const ink = Color(0xFF1A1A1A);
  static const inkMuted = Color(0xFF575047);
  static const accent = Color(0xFFF2B705);
  static const accentInk = Color(0xFF0B1220);
  static const divider = Color(0xFFE8E2D5);
  static const blue = Color(0xFF1E88E5);
  static const pickup = Color(0xFF34C759);
  static const dropoff = Color(0xFFE53935);
}

class TrainingModuleScreen extends StatefulWidget {
  final TrainingModule module;
  const TrainingModuleScreen({super.key, required this.module});

  @override
  State<TrainingModuleScreen> createState() => _TrainingModuleScreenState();
}

class _TrainingModuleScreenState extends State<TrainingModuleScreen> {
  bool _isLoading = true;
  AppError? _error;
  List<QuizQuestion> _questions = const [];

  /// Question index -> chosen option ('a'|'b'|'c'|'d')
  final Map<int, String> _answers = {};
  bool _showResults = false;
  int? _score;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _isLoading = true;
      _error = null;
    });
    try {
      await TrainingService.instance.markStarted(widget.module.id);
      final qs =
          await TrainingService.instance.loadQuiz(widget.module.id);
      if (!mounted) return;
      setState(() {
        _questions = qs;
        _isLoading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _isLoading = false;
        _error = AppError.from(e, onRetry: _load);
      });
    }
  }

  void _choose(int index, String opt) {
    if (_showResults) return;
    setState(() => _answers[index] = opt);
  }

  Future<void> _submitQuiz() async {
    if (_answers.length < _questions.length) {
      ErrorUI.showSnack(
        context,
        AppError(
          title: tr('Answer every question'),
          message: tr('Please choose an option for each.'),
          icon: Icons.info_outline,
        ),
      );
      return;
    }

    var correct = 0;
    for (var i = 0; i < _questions.length; i++) {
      if (_answers[i] == _questions[i].correctOption) {
        correct++;
      }
    }
    final score = ((correct / _questions.length) * 100).round();

    setState(() {
      _score = score;
      _showResults = true;
    });

    try {
      await TrainingService.instance.markCompleted(
        moduleId: widget.module.id,
        scorePercent: score,
      );
    } catch (e) {
      debugPrint('save progress failed: $e');
    }
  }

  void _retry() {
    setState(() {
      _answers.clear();
      _showResults = false;
      _score = null;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _Palette.cream,
      appBar: AppBar(
        backgroundColor: _Palette.cream,
        elevation: 0,
        iconTheme: const IconThemeData(color: _Palette.ink),
        title: Text(
          widget.module.title,
          style: const TextStyle(
            color: _Palette.ink,
            fontWeight: FontWeight.bold,
            fontSize: 17,
          ),
        ),
      ),
      body: _isLoading
          ? const Center(
              child: CircularProgressIndicator(color: _Palette.accent))
          : _error != null
              ? ErrorUI.inline(_error!)
              : SafeArea(
                  child: ListView(
                    padding:
                        const EdgeInsets.fromLTRB(16, 8, 16, 24),
                    children: [
                      _contentCard(),
                      if (_questions.isNotEmpty) ...[
                        const SizedBox(height: 20),
                        _quizHeader(),
                        const SizedBox(height: 12),
                        ..._questions.asMap().entries.map(
                              (e) => _questionCard(e.key, e.value),
                            ),
                        const SizedBox(height: 20),
                        _submitBar(),
                      ] else
                        _noQuizCard(),
                    ],
                  ),
                ),
    );
  }

  Widget _contentCard() {
    final content = widget.module.content ?? '';
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: _Palette.divider),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (widget.module.videoUrl != null &&
              widget.module.videoUrl!.isNotEmpty) ...[
            Container(
              height: 160,
              decoration: BoxDecoration(
                color: _Palette.blue.withValues(alpha: 0.08),
                borderRadius: BorderRadius.circular(12),
              ),
              child: const Center(
                child: Icon(Icons.play_circle_fill,
                    size: 60, color: _Palette.blue),
              ),
            ),
            const SizedBox(height: 16),
          ],
          if (widget.module.description != null) ...[
            Text(
              widget.module.description!,
              style: const TextStyle(
                fontSize: 14,
                color: _Palette.inkMuted,
                height: 1.5,
              ),
            ),
            const SizedBox(height: 16),
          ],
          if (content.isNotEmpty)
            Text(
              content,
              style: const TextStyle(
                fontSize: 14,
                color: _Palette.ink,
                height: 1.6,
              ),
            ),
        ],
      ),
    );
  }

  Widget _quizHeader() {
    return Padding(
      padding: EdgeInsets.only(left: 4),
      child: Text(
        tr('QUICK QUIZ'),
        style: TextStyle(
          fontSize: 13,
          fontWeight: FontWeight.w700,
          letterSpacing: 0.8,
          color: _Palette.inkMuted,
        ),
      ),
    );
  }

  Widget _questionCard(int index, QuizQuestion q) {
    final chosen = _answers[index];

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: _Palette.divider),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            '${index + 1}. ${q.question}',
            style: const TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.w700,
              color: _Palette.ink,
              height: 1.4,
            ),
          ),
          const SizedBox(height: 12),
          // Every option tap now passes the question index explicitly.
          _option(index, 'a', q.optionA, chosen, q.correctOption),
          const SizedBox(height: 6),
          _option(index, 'b', q.optionB, chosen, q.correctOption),
          const SizedBox(height: 6),
          _option(index, 'c', q.optionC, chosen, q.correctOption),
          const SizedBox(height: 6),
          _option(index, 'd', q.optionD, chosen, q.correctOption),
        ],
      ),
    );
  }

  /// Renders a single quiz option.
  ///
  /// [qIndex] is the index of the question this option belongs to — it
  /// is threaded through so the tap handler can record the answer
  /// against the correct question. Without it we'd have no way to
  /// derive the question index from the option key alone.
  Widget _option(
    int qIndex,
    String key,
    String label,
    String? chosen,
    String correct,
  ) {
    final isChosen = chosen == key;
    final isCorrect = key == correct;

    Color bg = Colors.white;
    Color border = _Palette.divider;
    Color textColor = _Palette.ink;
    IconData? trailing;

    if (_showResults) {
      if (isCorrect) {
        bg = _Palette.pickup.withValues(alpha: 0.10);
        border = _Palette.pickup;
        textColor = _Palette.pickup;
        trailing = Icons.check_circle;
      } else if (isChosen) {
        bg = _Palette.dropoff.withValues(alpha: 0.10);
        border = _Palette.dropoff;
        textColor = _Palette.dropoff;
        trailing = Icons.cancel;
      }
    } else if (isChosen) {
      bg = _Palette.accent.withValues(alpha: 0.10);
      border = _Palette.accent;
      textColor = _Palette.ink;
    }

    return InkWell(
      onTap: _showResults ? null : () => _choose(qIndex, key),
      borderRadius: BorderRadius.circular(10),
      child: Container(
        padding:
            const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        decoration: BoxDecoration(
          color: bg,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: border, width: 1.2),
        ),
        child: Row(
          children: [
            Container(
              width: 22,
              height: 22,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: isChosen || (_showResults && isCorrect)
                    ? border.withValues(alpha: 0.15)
                    : _Palette.cream,
                shape: BoxShape.circle,
                border: Border.all(color: border, width: 1),
              ),
              child: Text(
                key.toUpperCase(),
                style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.bold,
                  color: textColor,
                ),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Text(
                label,
                style: TextStyle(
                  fontSize: 14,
                  color: textColor,
                  height: 1.35,
                ),
              ),
            ),
            if (trailing != null)
              Icon(trailing, color: border, size: 18),
          ],
        ),
      ),
    );
  }

  Widget _noQuizCard() {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: _Palette.blue.withValues(alpha: 0.06),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        children: [
          Icon(Icons.info_outline, size: 18, color: _Palette.blue),
          SizedBox(width: 10),
          Expanded(
            child: Text(
              tr('No quiz for this module. It will be marked complete when you finish reading.'),
              style: TextStyle(fontSize: 13.5, color: _Palette.ink),
            ),
          ),
        ],
      ),
    );
  }

  Widget _submitBar() {
    if (_showResults) {
      final passed = (_score ?? 0) >= 80;
      return Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: passed
                  ? _Palette.pickup.withValues(alpha: 0.10)
                  : _Palette.dropoff.withValues(alpha: 0.10),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(
                color: passed ? _Palette.pickup : _Palette.dropoff,
                width: 1.4,
              ),
            ),
            child: Row(
              children: [
                Icon(
                  passed ? Icons.check_circle : Icons.cancel,
                  color: passed ? _Palette.pickup : _Palette.dropoff,
                  size: 26,
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        passed
                            ? tr('Passed · {0}%', ['$_score'])
                            : tr('Score {0}% · 80% to pass', ['$_score']),
                        style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                          color: passed
                              ? _Palette.pickup
                              : _Palette.dropoff,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        passed
                            ? tr('Well done. This module is now complete.')
                            : tr('Review the answers above and try again.'),
                        style: const TextStyle(
                          fontSize: 13.5,
                          color: _Palette.inkMuted,
                          height: 1.3,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          if (passed)
            ElevatedButton(
              onPressed: () => Navigator.pop(context, true),
              style: ElevatedButton.styleFrom(
                backgroundColor: _Palette.pickup,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 14),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12)),
              ),
              child: Text(tr('Done'),
                  style: TextStyle(fontWeight: FontWeight.bold)),
            )
          else
            ElevatedButton(
              onPressed: _retry,
              style: ElevatedButton.styleFrom(
                backgroundColor: _Palette.accent,
                foregroundColor: _Palette.accentInk,
                padding: const EdgeInsets.symmetric(vertical: 14),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12)),
              ),
              child: Text(tr('Try again'),
                  style: TextStyle(fontWeight: FontWeight.bold)),
            ),
        ],
      );
    }

    final remaining = _questions.length - _answers.length;
    return ElevatedButton(
      onPressed: remaining > 0 ? null : _submitQuiz,
      style: ElevatedButton.styleFrom(
        backgroundColor: _Palette.accent,
        foregroundColor: _Palette.accentInk,
        disabledBackgroundColor: Colors.grey.shade300,
        padding: const EdgeInsets.symmetric(vertical: 14),
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12)),
      ),
      child: Text(
        remaining > 0
            ? tr('Answer {0} more', ['$remaining'])
            : tr('Submit quiz'),
        style: const TextStyle(fontWeight: FontWeight.bold),
      ),
    );
  }
}
