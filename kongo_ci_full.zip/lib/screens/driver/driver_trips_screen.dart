// lib/screens/driver/driver_trips_screen.dart
//
// The driver's trips: the one in progress, accepted rides booked for
// later, finished trips and cancelled ones. (Money is on the Earnings tab.)
// Tap a trip for its details; tap the active trip to go back to it.

import 'dart:async';
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:efuride_app/config/efuride_palette.dart';
import 'package:efuride_app/config/country_config.dart';
import 'package:efuride_app/l10n/app_strings.dart';
import 'package:efuride_app/utils/app_error.dart';
import 'package:efuride_app/utils/error_ui.dart';

enum _Filter { active, upcoming, done, cancelled }

class DriverTripsScreen extends StatefulWidget {
  const DriverTripsScreen({super.key});

  @override
  State<DriverTripsScreen> createState() => _DriverTripsScreenState();
}

class _DriverTripsScreenState extends State<DriverTripsScreen>
    with WidgetsBindingObserver {
  _Filter _filter = _Filter.done;
  List<Map<String, dynamic>> _rows = [];
  bool _loading = true;
  AppError? _error;
  Timer? _poll;

  static const _activeStatuses = ['accepted', 'arrived', 'in_progress', 'returning'];
  static const _doneStatuses = ['completed', 'returned'];

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _load();
    // Keeps the list fresh while a trip is going on.
    _poll = Timer.periodic(const Duration(seconds: 30), (_) => _load(quiet: true));
  }

  @override
  void dispose() {
    _poll?.cancel();
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) _load(quiet: true);
  }

  Future<void> _load({bool quiet = false}) async {
    if (!quiet) {
      setState(() {
        _loading = true;
        _error = null;
      });
    }
    try {
      final uid = Supabase.instance.client.auth.currentUser?.id;
      if (uid == null) {
        if (mounted) setState(() => _loading = false);
        return;
      }
      final rows = await Supabase.instance.client
          .from('rides')
          .select()
          .eq('driver_id', uid)
          .order('created_at', ascending: false)
          .limit(300);
      final list = List<Map<String, dynamic>>.from(rows as List);
      if (!mounted) return;
      setState(() {
        _rows = list;
        _loading = false;
        _error = null;
        // First open: show the trip in progress if there is one.
        if (!quiet && _filter == _Filter.done && _count(_Filter.active) > 0) {
          _filter = _Filter.active;
        }
      });
    } catch (e) {
      if (!mounted || quiet) return;
      setState(() {
        _loading = false;
        _error = AppError.from(e, onRetry: _load);
      });
    }
  }

  String _status(Map<String, dynamic> r) =>
      (r['status'] ?? '').toString().toLowerCase();

  bool _match(Map<String, dynamic> r, _Filter f) {
    final s = _status(r);
    switch (f) {
      case _Filter.active:
        return _activeStatuses.contains(s) && !_isUpcoming(r);
      case _Filter.upcoming:
        return s == 'scheduled' || (_activeStatuses.contains(s) && _isUpcoming(r));
      case _Filter.done:
        return _doneStatuses.contains(s);
      case _Filter.cancelled:
        return s == 'cancelled' || s == 'expired';
    }
  }

  /// Accepted ride whose booked time is still more than 15 minutes away.
  bool _isUpcoming(Map<String, dynamic> r) {
    final at = DateTime.tryParse((r['scheduled_at'] ?? '').toString())?.toLocal();
    if (at == null || _status(r) != 'accepted') return false;
    return at.isAfter(DateTime.now().add(const Duration(minutes: 15)));
  }

  int _count(_Filter f) => _rows.where((r) => _match(r, f)).length;

  // ═══════════════════════════════════════════════════════════
  // BUILD
  // ═══════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    final shown = _rows.where((r) => _match(r, _filter)).toList();
    return Container(
      color: EfuridePalette.cream,
      child: Column(
        children: [
          _header(),
          _filters(),
          Expanded(
            child: _loading
                ? const Center(
                    child: CircularProgressIndicator(color: EfuridePalette.accent))
                : _error != null
                    ? ErrorUI.inline(_error!)
                    : RefreshIndicator(
                        color: EfuridePalette.accent,
                        onRefresh: _load,
                        child: shown.isEmpty
                            ? ListView(
                                physics: const AlwaysScrollableScrollPhysics(),
                                children: [_empty()],
                              )
                            : ListView.separated(
                                physics: const AlwaysScrollableScrollPhysics(),
                                padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
                                itemCount: shown.length,
                                separatorBuilder: (_, __) => const SizedBox(height: 10),
                                itemBuilder: (_, i) => _tripCard(shown[i]),
                              ),
                      ),
          ),
        ],
      ),
    );
  }

  Widget _header() {
    return SafeArea(
      bottom: false,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(20, 14, 8, 6),
        child: Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(tr('My trips'),
                      style: const TextStyle(
                          color: EfuridePalette.ink,
                          fontSize: 24,
                          fontWeight: FontWeight.w800)),
                  const SizedBox(height: 2),
                  Text(tr('Every trip you took, in order'),
                      style: const TextStyle(
                          color: EfuridePalette.inkMuted, fontSize: 15)),
                ],
              ),
            ),
            IconButton(
              tooltip: tr('Refresh'),
              onPressed: _load,
              icon: const Icon(Icons.refresh, color: EfuridePalette.ink),
            ),
          ],
        ),
      ),
    );
  }

  Widget _filters() {
    final items = [
      (_Filter.active, tr('Now')),
      (_Filter.upcoming, tr('Booked')),
      (_Filter.done, tr('Done')),
      (_Filter.cancelled, tr('Cancelled')),
    ];
    return SizedBox(
      height: 54,
      child: ListView.separated(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
        scrollDirection: Axis.horizontal,
        itemCount: items.length,
        separatorBuilder: (_, __) => const SizedBox(width: 8),
        itemBuilder: (_, i) {
          final (f, label) = items[i];
          final active = _filter == f;
          final n = _loading ? 0 : _count(f);
          return GestureDetector(
            onTap: () => setState(() => _filter = f),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: active ? EfuridePalette.accent : Colors.white,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(
                    color: active ? EfuridePalette.accent : EfuridePalette.divider),
              ),
              child: Text(
                n > 0 ? '$label · $n' : label,
                style: const TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w800,
                  color: EfuridePalette.ink,
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _empty() {
    final text = switch (_filter) {
      _Filter.active => tr('No trip in progress'),
      _Filter.upcoming => tr('No rides booked for later'),
      _Filter.done => tr('No finished trips yet'),
      _Filter.cancelled => tr('No cancelled trips'),
    };
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 40, 16, 0),
      child: Column(
        children: [
          Icon(Icons.route_outlined, size: 48, color: Colors.grey.shade400),
          const SizedBox(height: 10),
          Text(text,
              textAlign: TextAlign.center,
              style: const TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.w700,
                  color: EfuridePalette.inkMuted)),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // TRIP CARD
  // ═══════════════════════════════════════════════════════════
  bool _isDelivery(Map<String, dynamic> r) {
    final s = (r['service_type'] ?? '').toString().toLowerCase();
    return r['order_id'] != null ||
        ['delivery', 'food', 'grocery', 'pharmacy', 'parcel'].contains(s);
  }

  double _fare(Map<String, dynamic> r) {
    num? v(dynamic x) => x is num ? x : num.tryParse('${x ?? ''}');
    return (v(r['fare_after_discount']) ?? v(r['fare']) ?? 0).toDouble();
  }

  DateTime _when(Map<String, dynamic> r) {
    for (final k in ['completed_at', 'cancelled_at', 'scheduled_at', 'accepted_at', 'created_at']) {
      final d = DateTime.tryParse((r[k] ?? '').toString());
      if (d != null) return d.toLocal();
    }
    return DateTime.now();
  }

  (String, Color) _statusChip(Map<String, dynamic> r) {
    switch (_status(r)) {
      case 'accepted':
        return _isUpcoming(r)
            ? (tr('Booked'), EfuridePalette.blueDeep)
            : (tr('Going to pickup'), EfuridePalette.merchantAccent);
      case 'arrived':
        return (tr('At pickup'), EfuridePalette.merchantAccent);
      case 'in_progress':
        return (tr('On the way'), EfuridePalette.merchantAccent);
      case 'returning':
        return (tr('Returning parcel'), EfuridePalette.merchantAccent);
      case 'completed':
        return (tr('Completed'), EfuridePalette.onlineDeep);
      case 'returned':
        return (tr('Returned'), EfuridePalette.onlineDeep);
      case 'cancelled':
        return (tr('Cancelled'), EfuridePalette.dropoff);
      case 'expired':
        return (tr('Expired'), EfuridePalette.inkMuted);
      default:
        return (_status(r), EfuridePalette.inkMuted);
    }
  }

  Widget _tripCard(Map<String, dynamic> r) {
    final (label, color) = _statusChip(r);
    final delivery = _isDelivery(r);
    final km = (r['distance_km'] is num)
        ? (r['distance_km'] as num).toDouble()
        : double.tryParse('${r['distance_km'] ?? ''}') ?? 0;
    final pay = (r['payment_method'] ?? '').toString();
    final active = _match(r, _Filter.active);

    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(16),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: () => active ? _openActive(r) : _details(r),
        child: Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
                color: active ? EfuridePalette.accent : EfuridePalette.divider,
                width: active ? 1.5 : 1),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    width: 38,
                    height: 38,
                    decoration: BoxDecoration(
                      color: EfuridePalette.accent.withValues(alpha: 0.18),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Icon(
                        delivery ? Icons.inventory_2_outlined : Icons.local_taxi_outlined,
                        size: 20,
                        color: EfuridePalette.ink),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(delivery ? tr('Delivery') : tr('Ride'),
                            style: const TextStyle(
                                fontSize: 15, fontWeight: FontWeight.w800)),
                        Text(_timeLabel(_when(r)),
                            style: const TextStyle(
                                fontSize: 13, color: EfuridePalette.inkMuted)),
                      ],
                    ),
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Text(CountryConfig.money(_fare(r)),
                          style: const TextStyle(
                              fontSize: 15.5, fontWeight: FontWeight.w900)),
                      const SizedBox(height: 4),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                        decoration: BoxDecoration(
                          color: color.withValues(alpha: 0.12),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Text(label,
                            style: TextStyle(
                                fontSize: 12,
                                fontWeight: FontWeight.w800,
                                color: color)),
                      ),
                    ],
                  ),
                ],
              ),
              const SizedBox(height: 12),
              _place(EfuridePalette.pickup, (r['pickup_address'] ?? '').toString()),
              const SizedBox(height: 6),
              _place(EfuridePalette.dropoff, (r['dropoff_address'] ?? '').toString()),
              if (km > 0 || pay.isNotEmpty) ...[
                const SizedBox(height: 10),
                Text(
                  [
                    if (km > 0) tr('{0} km', [km.toStringAsFixed(1)]),
                    if (pay.isNotEmpty) _payLabel(pay),
                  ].join('  ·  '),
                  style: const TextStyle(fontSize: 13, color: EfuridePalette.inkMuted),
                ),
              ],
              if (active) ...[
                const SizedBox(height: 10),
                Row(
                  children: [
                    const Icon(Icons.navigation_outlined, size: 16),
                    const SizedBox(width: 6),
                    Text(tr('Tap to go back to this trip'),
                        style: const TextStyle(
                            fontSize: 13.5, fontWeight: FontWeight.w800)),
                  ],
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }

  Widget _place(Color c, String text) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(top: 5),
          child: Icon(Icons.circle, size: 9, color: c),
        ),
        const SizedBox(width: 8),
        Expanded(
          child: Text(text.isEmpty ? '—' : text,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontSize: 14, color: EfuridePalette.ink)),
        ),
      ],
    );
  }

  String _payLabel(String p) {
    switch (p.toLowerCase()) {
      case 'cash':
        return tr('Cash');
      case 'wallet':
        return tr('Wallet');
      case 'card':
        return tr('Card');
      default:
        return p;
    }
  }

  String _timeLabel(DateTime when) {
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final day = DateTime(when.year, when.month, when.day);
    final diff = day.difference(today).inDays;
    final hhmm =
        '${when.hour.toString().padLeft(2, '0')}:${when.minute.toString().padLeft(2, '0')}';
    if (diff == 0) return '${tr('Today')} · $hhmm';
    if (diff == -1) return '${tr('Yesterday')} · $hhmm';
    if (diff == 1) return '${tr('Tomorrow')} · $hhmm';
    return '${when.day}/${when.month}/${when.year} · $hhmm';
  }

  void _openActive(Map<String, dynamic> r) {
    Navigator.pushNamed(context, '/driver_active_trip', arguments: {
      'rideId': r['id'].toString(),
      'serviceType': (r['service_type'] ?? 'Ride').toString(),
      'pickupOtp': r['pickup_otp']?.toString(),
    }).then((_) => _load(quiet: true));
  }

  void _details(Map<String, dynamic> r) {
    final (label, color) = _statusChip(r);
    String at(String k) {
      final d = DateTime.tryParse((r[k] ?? '').toString())?.toLocal();
      return d == null ? '' : _timeLabel(d);
    }

    final lines = <(String, String)>[
      (tr('Status'), label),
      (tr('Price'), CountryConfig.money(_fare(r))),
      if ((r['payment_method'] ?? '').toString().isNotEmpty)
        (tr('Payment'), _payLabel(r['payment_method'].toString())),
      if (at('scheduled_at').isNotEmpty) (tr('Booked for'), at('scheduled_at')),
      if (at('created_at').isNotEmpty) (tr('Requested'), at('created_at')),
      if (at('accepted_at').isNotEmpty) (tr('Accepted'), at('accepted_at')),
      if (at('completed_at').isNotEmpty) (tr('Finished'), at('completed_at')),
      if (at('cancelled_at').isNotEmpty) (tr('Cancelled'), at('cancelled_at')),
      if ((r['cancel_reason'] ?? r['cancellation_reason'] ?? '').toString().isNotEmpty)
        (tr('Reason'), (r['cancel_reason'] ?? r['cancellation_reason']).toString()),
      if (r['customer_rating'] != null)
        (tr('Your rating from the customer'), '★ ${r['customer_rating']}'),
    ];

    showModalBottomSheet(
      context: context,
      backgroundColor: EfuridePalette.cream,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (_) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 16, 20, 20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                      color: EfuridePalette.divider,
                      borderRadius: BorderRadius.circular(2)),
                ),
              ),
              const SizedBox(height: 14),
              Row(
                children: [
                  Expanded(
                    child: Text(_isDelivery(r) ? tr('Delivery') : tr('Ride'),
                        style: const TextStyle(
                            fontSize: 20, fontWeight: FontWeight.w900)),
                  ),
                  Text(label,
                      style: TextStyle(
                          color: color, fontWeight: FontWeight.w800, fontSize: 14)),
                ],
              ),
              const SizedBox(height: 12),
              _place(EfuridePalette.pickup, (r['pickup_address'] ?? '').toString()),
              const SizedBox(height: 6),
              _place(EfuridePalette.dropoff, (r['dropoff_address'] ?? '').toString()),
              const SizedBox(height: 14),
              const Divider(color: EfuridePalette.divider),
              for (final (k, v) in lines)
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 5),
                  child: Row(
                    children: [
                      Expanded(
                          child: Text(k,
                              style: const TextStyle(
                                  color: EfuridePalette.inkMuted, fontSize: 14))),
                      Text(v,
                          style: const TextStyle(
                              fontWeight: FontWeight.w700, fontSize: 14)),
                    ],
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}
