// lib/screens/driver/driver_more_screen.dart

import 'package:flutter/material.dart';
import 'package:efuride_app/screens/driver/driver_profile_screen.dart';

class DriverMoreScreen extends StatelessWidget {
  const DriverMoreScreen({super.key});

  @override
  Widget build(BuildContext context) => const DriverProfileScreen();
}
