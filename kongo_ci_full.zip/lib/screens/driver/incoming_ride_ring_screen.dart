// lib/screens/driver/incoming_ride_ring_screen.dart
//
// Ride request card that slides up over the driver's map (not full
// screen). Open it with IncomingRideRingScreen.route(ride).
// Returns:
//   true       → accepted
//   false      → declined
//   'countered'→ driver sent a counter-offer
//   'cancelled'→ request disappeared (taken/cancelled)
//
// i18n-clean · currency-clean · uses CountryConfig + S.

import 'dart:async';
import 'package:flutter/material.dart';
import 'package:efuride_app/utils/money.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'package:efuride_app/config/country_config.dart';
import 'package:efuride_app/config/efuride_palette.dart';
import 'package:efuride_app/l10n/app_strings.dart';
import 'package:efuride_app/services/ring_service.dart';
import 'package:efuride_app/utils/app_error.dart';
import 'package:efuride_app/utils/error_ui.dart';
import 'package:efuride_app/services/connection_service.dart';

class _Palette {
  static const dark = Color(0xFF0F1A2B);
  static const pickup = Color(0xFF34C759);
  static const dropoff = Color(0xFFE53935);
  static const blue = Color(0xFF1E88E5);
  static const bid = Color(0xFFFFB300);
  static const bidInk = Color(0xFF0B1220);
}

class IncomingRideRingScreen extends StatefulWidget {
  final Map<String, dynamic> rideData;

  /// Opened by the driver from the waiting-orders list: no ringing.
  final bool silent;
  const IncomingRideRingScreen(
      {super.key, required this.rideData, this.silent = false});

  /// Opens as a card over the current screen; the map stays visible
  /// behind a light shade. Taps outside the card do nothing (so the
  /// driver can't dismiss a request by accident).
  static Route<dynamic> route(Map<String, dynamic> ride,
      {bool silent = false}) {
    return PageRouteBuilder<dynamic>(
      opaque: false,
      barrierDismissible: false,
      barrierColor: Colors.black38,
      transitionDuration: const Duration(milliseconds: 260),
      reverseTransitionDuration: const Duration(milliseconds: 200),
      pageBuilder: (_, __, ___) =>
          IncomingRideRingScreen(rideData: ride, silent: silent),
      transitionsBuilder: (_, anim, __, child) => SlideTransition(
        position: Tween<Offset>(
          begin: const Offset(0, 1),
          end: Offset.zero,
        ).animate(CurvedAnimation(parent: anim, curve: Curves.easeOutCubic)),
        child: child,
      ),
    );
  }

  @override
  State<IncomingRideRingScreen> createState() =>
      _IncomingRideRingScreenState();
}

class _IncomingRideRingScreenState extends State<IncomingRideRingScreen> {
  late Map<String, dynamic> _ride = widget.rideData;
  Timer? _countdown;
  int _secondsLeft = 60; // one minute to answer
  bool _responding = false;
  Map<String, dynamic>? _customerProfile;

  RealtimeChannel? _rideStatusWatch;

  bool get _isBidding => _ride['is_bidding'] == true;

  /// Shop orders (food, grocery, pharmacy): after the minute the card
  /// just hides — the order stays in the driver's "waiting orders" list
  /// until someone accepts it or the customer cancels.
  bool get _isShopOrder =>
      (_ride['order_id']?.toString() ?? '').isNotEmpty;

  String get _serviceType =>
      (_ride['service_type'] ?? 'Ride').toString();

  /// Parcels and shop orders (food, grocery, pharmacy) are deliveries.
  bool get _isDelivery => _serviceType != 'Ride';

  String _deliveryLabel(S t) {
    switch (_serviceType) {
      case 'Food':
        return t.t('svc_food_delivery');
      case 'Grocery':
        return t.t('svc_grocery_delivery');
      case 'Pharmacy':
        return t.t('svc_pharmacy_delivery');
      default:
        return t.t('svc_parcel');
    }
  }

  String get _rideId => (_ride['id'] ?? '').toString();

  String get _shortRideId {
    if (_rideId.isEmpty) return '—';
    final id = _rideId.replaceAll('-', '').toUpperCase();
    return id.length >= 6 ? id.substring(0, 6) : id;
  }

  double get _customerBid =>
      (_ride['customer_bid'] as num?)?.toDouble() ??
      (_ride['fare'] as num?)?.toDouble() ??
      0;

  double get _fare =>
      (_ride['fare'] as num?)?.toDouble() ?? 0;

  double get _originalFare =>
      (_ride['original_fare'] as num?)?.toDouble() ?? _fare;

  double get _displayFare => _isBidding ? _customerBid : _fare;

  @override
  void initState() {
    super.initState();
    if (!widget.silent) RingService.instance.startRing();
    _loadCustomer();
    _watchRideStatus();
    _startCountdown();
  }

  void _startCountdown() {
    _countdown?.cancel();
    _countdown = Timer.periodic(const Duration(seconds: 1), (t) {
      if (!mounted) return;
      if (_secondsLeft <= 1) {
        t.cancel();
        if (_responding) return;
        if (_isShopOrder) {
          _hide();
        } else {
          _decline(auto: true);
        }
        return;
      }
      setState(() => _secondsLeft--);
    });
  }

  // ── Several requests at once: the driver picks one ──
  List<Map<String, dynamic>> get _others => globalOfferQueue.value
      .where((r) => r['id']?.toString() != _rideId)
      .toList();

  /// Show another request on this card. [keepCurrent] puts the one being
  /// left back in the list so the driver can come back to it.
  void _switchTo(Map<String, dynamic> next, {required bool keepCurrent}) {
    final cur = _ride;
    _rideStatusWatch?.unsubscribe();
    final q = List<Map<String, dynamic>>.from(globalOfferQueue.value)
      ..removeWhere((x) => x['id']?.toString() == next['id']?.toString());
    if (keepCurrent) q.add(cur);
    globalOfferQueue.value = q;
    setState(() {
      _ride = next;
      _customerProfile = null;
      _secondsLeft = _ringSeconds;
      _responding = false;
    });
    _loadCustomer();
    _watchRideStatus();
    _startCountdown();
    if (!widget.silent) RingService.instance.startRing();
  }

  /// This request is gone or answered: show the next waiting one, if any.
  bool _advance() {
    final q = _others;
    if (q.isEmpty) return false;
    _switchTo(q.first, keepCurrent: false);
    return true;
  }

  Future<bool> _driverHasActiveTrip() async {
    try {
      final me = Supabase.instance.client.auth.currentUser?.id;
      if (me == null) return false;
      final rows = await Supabase.instance.client
          .from('rides')
          .select('id')
          .eq('driver_id', me)
          .inFilter('status', ['accepted', 'in_progress', 'returning'])
          .neq('id', _rideId)
          .limit(1);
      return (rows as List).isNotEmpty;
    } catch (_) {
      return false; // the server also refuses a second trip
    }
  }

  void _showOthers() {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (ctx) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(8, 14, 8, 12),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Text(tr('Other requests'),
                style:
                    const TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
            const SizedBox(height: 6),
            for (final r in _others)
              ListTile(
                leading: Icon(
                    (r['service_type'] ?? 'Ride').toString() == 'Ride'
                        ? Icons.local_taxi
                        : Icons.inventory_2,
                    color: EfuridePalette.ink),
                title: Text(
                    '${(r['service_type'] ?? 'Ride')} · ${fmtMoney(((r['is_bidding'] == true ? r['customer_bid'] : r['fare']) as num?)?.toDouble() ?? 0)}',
                    style: const TextStyle(fontWeight: FontWeight.w800)),
                subtitle: Text(
                    '${r['pickup_address'] ?? ''} → ${r['dropoff_address'] ?? ''}',
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis),
                onTap: () {
                  Navigator.pop(ctx);
                  if (!_responding) _switchTo(r, keepCurrent: true);
                },
              ),
          ]),
        ),
      ),
    );
  }

  Widget _othersBanner() {
    return ValueListenableBuilder<List<Map<String, dynamic>>>(
      valueListenable: globalOfferQueue,
      builder: (_, __, ___) {
        final n = _others.length;
        if (n == 0) return const SizedBox.shrink();
        return Padding(
          padding: const EdgeInsets.only(bottom: 10),
          child: InkWell(
            onTap: _responding ? null : _showOthers,
            borderRadius: BorderRadius.circular(12),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
              decoration: BoxDecoration(
                color: const Color(0xFFFFF1CC),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Row(children: [
                const Icon(Icons.layers_outlined, size: 20),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                      tr('{0} other requests waiting. Choose one.', [n]),
                      style: const TextStyle(
                          fontWeight: FontWeight.w800, fontSize: 14)),
                ),
                const Icon(Icons.chevron_right),
              ]),
            ),
          ),
        );
      },
    );
  }

  @override
  void dispose() {
    _countdown?.cancel();
    _rideStatusWatch?.unsubscribe();
    RingService.instance.stopRing();
    super.dispose();
  }

  void _watchRideStatus() {
    if (_rideId.isEmpty) return;
    _rideStatusWatch = Supabase.instance.client
        .channel('ring_status_$_rideId')
        .onPostgresChanges(
          event: PostgresChangeEvent.update,
          schema: 'public',
          table: 'rides',
          filter: PostgresChangeFilter(
            type: PostgresChangeFilterType.eq,
            column: 'id',
            value: _rideId,
          ),
          callback: (payload) {
            if (!mounted || _responding) return;
            final row = payload.newRecord;
            final newStatus = (row['status'] ?? '').toString();
            final newDriverId = row['driver_id']?.toString();
            final myId = Supabase.instance.client.auth.currentUser?.id;

            if (newStatus == 'cancelled') {
              _responding = true;
              _countdown?.cancel();
              RingService.instance.stopRing();
              if (!mounted) return;
              if (_advance()) return;
              Navigator.pop(context, 'cancelled');
              return;
            }

            final takenByOther = newStatus == 'accepted' &&
                newDriverId != null &&
                newDriverId.isNotEmpty &&
                newDriverId != myId;
            if (takenByOther) {
              _responding = true;
              _countdown?.cancel();
              RingService.instance.stopRing();
              if (!mounted) return;
              if (_advance()) return;
              Navigator.pop(context, 'cancelled');
            }
          },
        )
        .subscribe();
  }

  Future<void> _loadCustomer() async {
    // Server card first: name, photo, rating and trips (drivers can't read
    // customer profiles directly).
    try {
      final res = await Supabase.instance.client
          .rpc('get_ride_customer', params: {'p_ride': _rideId});
      if (res is Map) {
        if (!mounted) return;
        setState(() => _customerProfile = {
              'first_name': res['first_name'],
              'surname': res['surname_initial'] == null ||
                      '${res['surname_initial']}'.isEmpty
                  ? ''
                  : '${res['surname_initial']}.',
              'profile_picture_url': res['photo'],
              'average_rating': res['rating'],
              'total_ratings': res['ratings'],
              'trips': res['trips'],
            });
        return;
      }
    } catch (e) {
      debugPrint('get_ride_customer failed: $e');
    }
    final custId = _ride['customer_id'];
    if (custId == null) return;
    try {
      final p = await Supabase.instance.client
          .from('profiles')
          .select(
              'first_name, surname, full_name, profile_picture_url, '
              'average_rating, total_ratings')
          .eq('id', custId)
          .maybeSingle();
      if (!mounted) return;
      setState(() => _customerProfile = p);
    } catch (e) {
      debugPrint('loadCustomer in ring failed: $e');
    }
  }

  // ═══════════════════════════════════════════════════════════
  // ACTIONS
  // ═══════════════════════════════════════════════════════════
  Future<void> _accept() async {
    if (_responding) return;
    if (!await ConnectionService.instance.ensureOnline(context)) return;
    if (await _driverHasActiveTrip()) {
      if (!mounted) return;
      ErrorUI.showSnack(
        context,
        AppError(
          title: tr('Finish your current trip first'),
          message: tr('You can accept one order at a time.'),
          icon: Icons.info_outline,
        ),
      );
      return;
    }
    _responding = true;
    _countdown?.cancel();
    await RingService.instance.stopRing();
    final t = S.of(context);

    try {
      final driverId = Supabase.instance.client.auth.currentUser?.id;
      if (driverId == null) throw Exception('Not signed in');

      final current = await Supabase.instance.client
          .from('rides')
          .select('status, driver_id')
          .eq('id', _rideId)
          .maybeSingle();

      final currentStatus = (current?['status'] ?? '').toString();
      final currentDriver = current?['driver_id']?.toString();

      if (currentStatus == 'cancelled') {
        if (!mounted) return;
        if (_advance()) return;
        Navigator.pop(context, 'cancelled');
        return;
      }

      if (currentStatus != 'pending' ||
          (currentDriver != null &&
              currentDriver.isNotEmpty &&
              currentDriver != driverId)) {
        if (!mounted) return;
        ErrorUI.showSnack(
          context,
          AppError(
            title: t.t('request_unavailable'),
            message: t.t('request_unavailable_hint'),
            icon: Icons.info_outline,
          ),
        );
        if (_advance()) return;
        Navigator.pop(context, false);
        return;
      }

      final updated = await Supabase.instance.client
          .from('rides')
          .update({
            'status': 'accepted',
            'driver_id': driverId,
            'accepted_at': DateTime.now().toUtc().toIso8601String(),
            'assigned_by_admin': false,
          })
          .eq('id', _rideId)
          .eq('status', 'pending')
          .select('id');

      if ((updated as List).isEmpty) {
        if (!mounted) return;
        ErrorUI.showSnack(
          context,
          AppError(
            title: t.t('request_unavailable'),
            message: t.t('request_unavailable_hint'),
            icon: Icons.info_outline,
          ),
        );
        if (_advance()) return;
        Navigator.pop(context, false);
        return;
      }

      if (!mounted) return;
      globalOfferQueue.value = [];
      Navigator.pop(context, true);
    } catch (e) {
      debugPrint('ring accept failed: $e');
      if (!mounted) return;
      setState(() => _responding = false);
      if (e.toString().contains('kongo_driver_busy')) {
        ErrorUI.showSnack(
          context,
          AppError(
            title: tr('Finish your current trip first'),
            message: tr('You can accept one order at a time.'),
            icon: Icons.info_outline,
          ),
        );
        return;
      }
      ErrorUI.showSnack(context, AppError.from(e, onRetry: _accept));
    }
  }

  /// Time's up on a shop order: stop ringing and put it aside (no
  /// decline), so it waits in the list on the home screen.
  Future<void> _hide() async {
    if (_responding) return;
    _responding = true;
    _countdown?.cancel();
    await RingService.instance.stopRing();
    if (!mounted) return;
    Navigator.pop(context, 'hidden');
  }

  Future<void> _decline({bool auto = false}) async {
    if (_responding) return;
    _responding = true;
    _countdown?.cancel();
    await RingService.instance.stopRing();

    try {
      await Supabase.instance.client.from('ride_declines').insert({
        'ride_id': _ride['id'],
        'driver_id': Supabase.instance.client.auth.currentUser?.id,
        'reason': auto ? 'Timeout' : 'Declined from ring',
        'created_at': DateTime.now().toUtc().toIso8601String(),
      });
    } catch (e) {
      debugPrint('decline log failed: $e');
    }

    if (!mounted) return;
    if (_advance()) return;
    Navigator.pop(context, false);
  }

  // ═══════════════════════════════════════════════════════════
  // COUNTER SHEET
  // ═══════════════════════════════════════════════════════════
  void _showCounterSheet() {
    final t = S.of(context);
    final bid = _customerBid;
    final suggested = _originalFare;

    double counterValue = suggested > bid ? suggested : bid * 1.2;
    if (counterValue < bid) counterValue = bid;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: _Palette.dark,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setSheet) {
          final minVal = bid * 0.8;
          final maxVal = bid * 2.0;

          return Padding(
            padding: EdgeInsets.only(
              left: 20,
              right: 20,
              top: 20,
              bottom: MediaQuery.of(ctx).viewInsets.bottom + 24,
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Center(
                  child: Container(
                    width: 40,
                    height: 4,
                    decoration: BoxDecoration(
                      color: Colors.white24,
                      borderRadius: BorderRadius.circular(2),
                    ),
                  ),
                ),
                const SizedBox(height: 20),

                Row(
                  children: [
                    const Icon(Icons.gavel_rounded,
                        color: _Palette.bid, size: 22),
                    const SizedBox(width: 8),
                    Text(
                      t.t('counter_offer'),
                      style: const TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.w900,
                        color: Colors.white,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 6),
                Text(
                  '${_isBidding ? t.t('customer_bid') : tr('Trip price')} ${CountryConfig.money(bid)}',
                  style: const TextStyle(
                      fontSize: 14, color: Colors.white54),
                ),
                if (suggested > 0 && suggested != bid) ...[
                  const SizedBox(height: 2),
                  Text(
                    '${t.t('suggested_fare')} ${CountryConfig.money(suggested)}',
                    style: const TextStyle(
                        fontSize: 13.5, color: Colors.white38),
                  ),
                ],

                const SizedBox(height: 24),

                Text(
                  CountryConfig.money(counterValue),
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    fontSize: 40,
                    fontWeight: FontWeight.w900,
                    color: _Palette.bid,
                  ),
                ),

                const SizedBox(height: 8),

                Slider(
                  value: counterValue.clamp(minVal, maxVal),
                  min: minVal,
                  max: maxVal,
                  divisions: 24,
                  activeColor: _Palette.bid,
                  inactiveColor: Colors.white24,
                  label: CountryConfig.money(counterValue),
                  onChanged: (v) => setSheet(() => counterValue = v),
                ),

                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(CountryConfig.money(minVal),
                        style: const TextStyle(
                            fontSize: 13.5, color: Colors.white38)),
                    Text(CountryConfig.money(maxVal),
                        style: const TextStyle(
                            fontSize: 13.5, color: Colors.white38)),
                  ],
                ),

                const SizedBox(height: 8),

                Row(
                  children: [
                    _quickChip(
                      label: t.t('match_bid'),
                      onTap: () => setSheet(() => counterValue = bid),
                    ),
                    const SizedBox(width: 8),
                    _quickChip(
                      label: t.t('suggested'),
                      onTap: () => setSheet(() => counterValue =
                          suggested > 0 ? suggested : bid),
                    ),
                    const SizedBox(width: 8),
                    _quickChip(
                      label: '+20%',
                      onTap: () =>
                          setSheet(() => counterValue = bid * 1.2),
                    ),
                  ],
                ),

                const SizedBox(height: 24),

                Row(
                  children: [
                    Expanded(
                      child: OutlinedButton(
                        onPressed: () => Navigator.pop(ctx),
                        style: OutlinedButton.styleFrom(
                          foregroundColor: Colors.white70,
                          side: const BorderSide(color: Colors.white24),
                          padding:
                              const EdgeInsets.symmetric(vertical: 16),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(14),
                          ),
                        ),
                        child: Text(t.t('cancel')),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      flex: 2,
                      child: ElevatedButton(
                        onPressed: () {
                          Navigator.pop(ctx);
                          _sendCounterOffer(counterValue);
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: _Palette.bid,
                          foregroundColor: _Palette.bidInk,
                          padding:
                              const EdgeInsets.symmetric(vertical: 16),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(14),
                          ),
                        ),
                        child: Text(
                          t.t('send_counter'),
                          style: const TextStyle(
                              fontSize: 15,
                              fontWeight: FontWeight.w800),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  Widget _quickChip({required String label, required VoidCallback onTap}) {
    return Expanded(
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(10),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 10),
          alignment: Alignment.center,
          decoration: BoxDecoration(
            color: Colors.white.withValues(alpha: 0.06),
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: Colors.white24),
          ),
          child: Text(
            label,
            style: const TextStyle(
              fontSize: 13.5,
              fontWeight: FontWeight.w600,
              color: Colors.white70,
            ),
          ),
        ),
      ),
    );
  }

  Future<void> _sendCounterOffer(double amount) async {
    if (_responding) return;
    setState(() => _responding = true);
    _countdown?.cancel();
    await RingService.instance.stopRing();
    final t = S.of(context);

    try {
      final myId = Supabase.instance.client.auth.currentUser?.id;
      if (myId == null) throw Exception('Not signed in');

      // The server keeps one price offer at a time and leaves the
      // request open for other drivers.
      try {
        await Supabase.instance.client.rpc('ride_send_counter',
            params: {'p_ride': _rideId, 'p_amount': amount});
      } on PostgrestException catch (e) {
        final gone = e.message.contains('kongo_ride_gone');
        final busy = e.message.contains('kongo_counter_busy');
        if (!gone && !busy) rethrow;
        if (!mounted) return;
        ErrorUI.showSnack(
          context,
          AppError(
            title: t.t('request_unavailable'),
            message: busy
                ? tr('Another driver has already sent a price. Try again in a moment.')
                : t.t('request_cancelled'),
            icon: Icons.info_outline,
          ),
        );
        Navigator.pop(context, 'cancelled');
        return;
      }

      if (!mounted) return;
      Navigator.pop(context, 'countered');
    } catch (e) {
      debugPrint('sendCounterOffer failed: $e');
      if (!mounted) return;
      setState(() => _responding = false);
      ErrorUI.showSnack(
        context,
        AppError.from(e, onRetry: () => _sendCounterOffer(amount)),
      );
    }
  }

  // ═══════════════════════════════════════════════════════════
  // BUILD
  // ═══════════════════════════════════════════════════════════
  // ════════════════════════════════════════════════════════════
  // LAYOUT
  // A card at the bottom of the screen, over the driver's map: the
  // driver still sees where they are, and the important things (price,
  // pickup, time left, Accept) are big and in thumb reach.
  // ════════════════════════════════════════════════════════════
  static const int _ringSeconds = 60;

  @override
  Widget build(BuildContext context) {
    final t = S.of(context);
    final ride = _ride;
    final accent = _isDelivery ? _Palette.blue : _Palette.pickup;

    return PopScope(
      canPop: false,
      child: Scaffold(
        backgroundColor: Colors.transparent,
        body: SafeArea(
          top: false,
          child: Align(
            alignment: Alignment.bottomCenter,
            child: ConstrainedBox(
              constraints: BoxConstraints(
                maxWidth: 560,
                maxHeight: MediaQuery.of(context).size.height * 0.72,
              ),
              child: Material(
                color: Colors.white,
                elevation: 16,
                shadowColor: Colors.black54,
                borderRadius:
                    const BorderRadius.vertical(top: Radius.circular(24)),
                clipBehavior: Clip.antiAlias,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    // Time-left bar across the top of the card.
                    _TimeBar(
                      fraction: _secondsLeft / _ringSeconds,
                      color: _secondsLeft <= 10 ? _Palette.dropoff : accent,
                    ),
                    Flexible(
                      child: SingleChildScrollView(
                        padding: const EdgeInsets.fromLTRB(20, 14, 20, 8),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            _othersBanner(),
                            _header(t, accent),
                            const SizedBox(height: 14),
                            _priceBlock(t),
                            const SizedBox(height: 12),
                            _tripFacts(t, ride),
                            const SizedBox(height: 14),
                            _route(t, ride),
                            if (_isDelivery &&
                                (ride['recipient_name'] != null ||
                                    ride['recipient_phone'] != null)) ...[
                              const SizedBox(height: 12),
                              _recipientRow(ride, t),
                            ],
                            const SizedBox(height: 12),
                            _customerRow(t),
                          ],
                        ),
                      ),
                    ),
                    _buttons(t),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  // ── Service type, request number, seconds left ──
  Widget _header(S t, Color accent) {
    return Row(
      children: [
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
          decoration: BoxDecoration(
            color: accent.withValues(alpha: 0.12),
            borderRadius: BorderRadius.circular(20),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(_serviceIcon, size: 18, color: accent),
              const SizedBox(width: 6),
              Text(
                _isDelivery ? _deliveryLabel(t) : t.t('svc_ride'),
                style: TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.w800,
                  color: accent,
                ),
              ),
            ],
          ),
        ),
        const SizedBox(width: 8),
        Flexible(
          child: Text(
            '#$_shortRideId',
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.w600,
              color: EfuridePalette.inkMuted,
            ),
          ),
        ),
        const Spacer(),
        _CountdownDial(
          secondsLeft: _secondsLeft,
          total: _ringSeconds,
          busy: _responding,
        ),
      ],
    );
  }

  IconData get _serviceIcon {
    if (_isDelivery) {
      switch (_serviceType) {
        case 'Food':
          return Icons.restaurant;
        case 'Grocery':
          return Icons.shopping_basket;
        case 'Pharmacy':
          return Icons.local_pharmacy;
        default:
          return Icons.inventory_2;
      }
    }
    final v = (_ride['vehicle_type'] ?? '').toString().toLowerCase();
    if (v.contains('bike') || v.contains('moto')) return Icons.two_wheeler;
    if (v.contains('truck') || v.contains('large')) return Icons.local_shipping;
    if (v.contains('van')) return Icons.airport_shuttle;
    if (v.contains('xl')) return Icons.directions_car_filled;
    return Icons.local_taxi;
  }

  // ── The money: biggest thing on the card ──
  Widget _priceBlock(S t) {
    final color = _isBidding ? const Color(0xFFB45309) : EfuridePalette.ink;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          _isBidding ? t.t('customer_bid') : t.t('estimated_payout'),
          style: const TextStyle(
            fontSize: 15,
            fontWeight: FontWeight.w700,
            color: EfuridePalette.inkMuted,
          ),
        ),
        const SizedBox(height: 2),
        FittedBox(
          fit: BoxFit.scaleDown,
          alignment: Alignment.centerLeft,
          child: Text(
            CountryConfig.money(_displayFare),
            style: TextStyle(
              fontSize: 40,
              height: 1.1,
              fontWeight: FontWeight.w900,
              color: color,
            ),
          ),
        ),
        if (_isBidding && _originalFare > 0 && _originalFare != _customerBid)
          Padding(
            padding: const EdgeInsets.only(top: 2),
            child: Text(
              '${t.t('suggested_fare')} ${CountryConfig.money(_originalFare)}',
              style: const TextStyle(
                fontSize: 14,
                color: EfuridePalette.inkMuted,
              ),
            ),
          ),
      ],
    );
  }

  // ── Distance and time of the trip ──
  Widget _tripFacts(S t, Map<String, dynamic> ride) {
    final km = (ride['distance_km'] as num?)?.toDouble();
    final mins = (ride['eta_minutes'] as num?)?.toInt();
    final facts = <Widget>[
      if (km != null && km > 0)
        _fact(Icons.route, '${km.toStringAsFixed(km < 10 ? 1 : 0)} km'),
      if (mins != null && mins > 0) _fact(Icons.schedule, '$mins min'),
      if (_isBidding) _fact(Icons.gavel_rounded, t.t('counter')),
      // How the customer pays: the driver must know whether to collect cash.
      switch ((ride['payment_method'] ?? 'cash').toString()) {
        'wallet' => _fact(Icons.account_balance_wallet_outlined,
            tr('Paid from wallet')),
        'card' => _fact(Icons.credit_card, tr('Paid by card')),
        _ => _fact(Icons.payments_outlined, tr('Cash: collect from customer')),
      },
    ];
    if (facts.isEmpty) return const SizedBox.shrink();
    return Wrap(spacing: 8, runSpacing: 8, children: facts);
  }

  Widget _fact(IconData icon, String text) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: EfuridePalette.greyBg,
        borderRadius: BorderRadius.circular(10),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 16, color: EfuridePalette.inkMuted),
          const SizedBox(width: 5),
          Text(
            text,
            style: const TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.w700,
              color: EfuridePalette.ink,
            ),
          ),
        ],
      ),
    );
  }

  // ── Pickup → destination, drawn as a small timeline ──
  Widget _route(S t, Map<String, dynamic> ride) {
    Widget stop(Color color, String label, String value, {bool last = false}) {
      return IntrinsicHeight(
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            SizedBox(
              width: 22,
              child: Column(
                children: [
                  const SizedBox(height: 4),
                  Container(
                    width: 14,
                    height: 14,
                    decoration: BoxDecoration(
                      color: color,
                      shape: last ? BoxShape.rectangle : BoxShape.circle,
                      borderRadius: last ? BorderRadius.circular(3) : null,
                      border: Border.all(color: Colors.white, width: 2),
                      boxShadow: [
                        BoxShadow(
                            color: color.withValues(alpha: 0.4),
                            blurRadius: 4),
                      ],
                    ),
                  ),
                  if (!last)
                    Expanded(
                      child: Container(
                        width: 2,
                        margin: const EdgeInsets.symmetric(vertical: 2),
                        color: EfuridePalette.divider,
                      ),
                    ),
                ],
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Padding(
                padding: EdgeInsets.only(bottom: last ? 0 : 12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      label,
                      style: const TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w700,
                        color: EfuridePalette.inkMuted,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      value,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        fontSize: 16,
                        height: 1.3,
                        fontWeight: FontWeight.w700,
                        color: EfuridePalette.ink,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      );
    }

    return Column(
      children: [
        stop(_Palette.pickup, t.t('pickup'), _addr(ride['pickup_address'])),
        stop(_Palette.dropoff, t.t('destination'), _addr(ride['dropoff_address']),
            last: true),
      ],
    );
  }

  /// Address text, or a clear note when the customer only dropped a pin.
  String _addr(dynamic v) {
    final s = (v ?? '').toString().trim();
    return s.isEmpty ? tr('Pinned on the map') : s;
  }

  // ── Who is asking ──
  Widget _customerRow(S t) {
    final cust = _customerProfile ?? {};
    final name =
        '${cust['first_name'] ?? ''} ${cust['surname'] ?? ''}'.trim();
    final shown = name.isEmpty ? t.t('role_customer') : name;
    final url = cust['profile_picture_url']?.toString();
    num? n(dynamic v) => v is num ? v : num.tryParse('${v ?? ''}');
    final rating = n(cust['average_rating'])?.toDouble() ?? 5.0;
    final count = n(cust['total_ratings'])?.toInt() ?? 0;
    final trips = n(cust['trips'])?.toInt();

    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: EfuridePalette.cream,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: EfuridePalette.divider),
      ),
      child: Row(
      children: [
        CircleAvatar(
          radius: 26,
          backgroundColor: EfuridePalette.lightBlue,
          backgroundImage:
              (url != null && url.isNotEmpty) ? NetworkImage(url) : null,
          child: (url == null || url.isEmpty)
              ? Text(
                  shown[0].toUpperCase(),
                  style: const TextStyle(
                    color: EfuridePalette.blueDeep,
                    fontSize: 16,
                    fontWeight: FontWeight.w800,
                  ),
                )
              : null,
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                shown,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  fontSize: 16.5,
                  fontWeight: FontWeight.w800,
                  color: EfuridePalette.ink,
                ),
              ),
              const SizedBox(height: 3),
              Row(
                children: [
                  const Icon(Icons.star_rounded,
                      color: Color(0xFFF59E0B), size: 18),
                  const SizedBox(width: 2),
                  Text(
                    count > 0
                        ? tr('{0} ({1} ratings)', [rating.toStringAsFixed(1), count])
                        : tr('No ratings yet'),
                    style: const TextStyle(
                      fontSize: 13.5,
                      fontWeight: FontWeight.w600,
                      color: EfuridePalette.inkMuted,
                    ),
                  ),
                ],
              ),
              if (trips != null) ...[
                const SizedBox(height: 2),
                Text(
                  trips == 0
                      ? tr('New customer · first trip')
                      : trips == 1
                          ? tr('1 trip with ko!ngo')
                          : tr('{0} trips with ko!ngo', [trips]),
                  style: const TextStyle(
                    fontSize: 13.5,
                    fontWeight: FontWeight.w600,
                    color: EfuridePalette.inkMuted,
                  ),
                ),
              ],
            ],
          ),
        ),
      ],
      ),
    );
  }

  Widget _recipientRow(Map<String, dynamic> ride, S t) {
    final name = (ride['recipient_name'] ?? '').toString();
    final phone = (ride['recipient_phone'] ?? '').toString();
    if (name.isEmpty && phone.isEmpty) return const SizedBox.shrink();
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: _Palette.blue.withValues(alpha: 0.08),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        children: [
          const Icon(Icons.person_pin, color: _Palette.blue, size: 22),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              [t.t('recipient'), name, phone]
                  .where((x) => x.isNotEmpty)
                  .join(' · '),
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                fontSize: 14.5,
                fontWeight: FontWeight.w600,
                color: EfuridePalette.ink,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ── Decline · (Counter) · ACCEPT ──
  Widget _buttons(S t) {
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 16),
      decoration: const BoxDecoration(
        border: Border(top: BorderSide(color: EfuridePalette.divider)),
      ),
      child: Row(
        children: [
          // Small, so it isn't hit by accident.
          SizedBox(
            width: 64,
            height: 64,
            child: OutlinedButton(
              onPressed: _responding ? null : () => _decline(auto: false),
              style: OutlinedButton.styleFrom(
                padding: EdgeInsets.zero,
                foregroundColor: _Palette.dropoff,
                side: const BorderSide(color: _Palette.dropoff, width: 2),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16)),
              ),
              child: Tooltip(
                message: t.t('decline'),
                child: const Icon(Icons.close_rounded, size: 30),
              ),
            ),
          ),
          // Counter: any ride or parcel (shop orders have a fixed fee).
          if (!_isShopOrder) ...[
            const SizedBox(width: 10),
            SizedBox(
              height: 64,
              child: OutlinedButton.icon(
                onPressed: _responding ? null : _showCounterSheet,
                icon: const Icon(Icons.gavel_rounded, size: 20),
                label: Text(
                  t.t('counter'),
                  style: const TextStyle(
                      fontSize: 16, fontWeight: FontWeight.w800),
                ),
                style: OutlinedButton.styleFrom(
                  foregroundColor: const Color(0xFFB45309),
                  side: const BorderSide(color: _Palette.bid, width: 2),
                  padding: const EdgeInsets.symmetric(horizontal: 14),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16)),
                ),
              ),
            ),
          ],
          const SizedBox(width: 10),
          // Big, in thumb reach.
          Expanded(
            child: SizedBox(
              height: 64,
              child: ElevatedButton(
                onPressed: _responding ? null : _accept,
                style: ElevatedButton.styleFrom(
                  backgroundColor: _Palette.pickup,
                  foregroundColor: Colors.white,
                  disabledBackgroundColor:
                      _Palette.pickup.withValues(alpha: 0.6),
                  elevation: 0,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16)),
                ),
                child: _responding
                    ? const SizedBox(
                        width: 24,
                        height: 24,
                        child: CircularProgressIndicator(
                            strokeWidth: 3, color: Colors.white),
                      )
                    : Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const Icon(Icons.check_rounded, size: 28),
                          const SizedBox(width: 8),
                          Flexible(
                            child: Text(
                              t.t('accept'),
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.w900,
                              ),
                            ),
                          ),
                        ],
                      ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

/// Thin bar across the top of the card that shrinks as time runs out.
class _TimeBar extends StatelessWidget {
  final double fraction;
  final Color color;
  const _TimeBar({required this.fraction, required this.color});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 6,
      child: Align(
        alignment: Alignment.centerLeft,
        child: AnimatedFractionallySizedBox(
          duration: const Duration(milliseconds: 900),
          widthFactor: fraction.clamp(0.0, 1.0),
          child: Container(color: color),
        ),
      ),
    );
  }
}

/// Round countdown: seconds left inside a shrinking ring.
class _CountdownDial extends StatelessWidget {
  final int secondsLeft;
  final int total;
  final bool busy;
  const _CountdownDial({
    required this.secondsLeft,
    required this.total,
    required this.busy,
  });

  @override
  Widget build(BuildContext context) {
    final urgent = secondsLeft <= 10;
    final color = urgent ? _Palette.dropoff : EfuridePalette.ink;
    return SizedBox(
      width: 52,
      height: 52,
      child: Stack(
        alignment: Alignment.center,
        children: [
          SizedBox(
            width: 52,
            height: 52,
            child: CircularProgressIndicator(
              value: busy ? null : (secondsLeft / total).clamp(0.0, 1.0),
              strokeWidth: 5,
              backgroundColor: EfuridePalette.greyBg,
              color: urgent ? _Palette.dropoff : _Palette.pickup,
            ),
          ),
          if (!busy)
            Text(
              '$secondsLeft',
              style: TextStyle(
                fontSize: 19,
                fontWeight: FontWeight.w900,
                color: color,
              ),
            ),
        ],
      ),
    );
  }
}
