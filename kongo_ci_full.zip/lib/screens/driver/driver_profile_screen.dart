﻿// lib/screens/driver/driver_profile_screen.dart
//
// Driver profile. Shows identity, contact info, account status, and
// entry points to settings, vehicles, KYC docs, bank details, and
// support. Uses AuthProvider as single source of truth.
//
// i18n-clean · uses S + AuthProvider + StorageService.

import 'package:efuride_app/screens/driver/driver_shell.dart';
import 'package:efuride_app/widgets/kongo_brand.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'package:efuride_app/config/efuride_palette.dart';
import 'package:efuride_app/l10n/app_strings.dart';
import 'package:efuride_app/providers/auth_provider.dart';
import 'package:efuride_app/services/storage_service.dart';
import 'package:efuride_app/utils/app_error.dart';
import 'package:efuride_app/utils/error_ui.dart';
import 'package:efuride_app/widgets/k_icon.dart';

class DriverProfileScreen extends StatefulWidget {
  const DriverProfileScreen({super.key});

  @override
  State<DriverProfileScreen> createState() => _DriverProfileScreenState();
}

class _DriverProfileScreenState extends State<DriverProfileScreen> {
  String _t(String key) => S.of(context).t(key);

  bool _uploadingAvatar = false;

  // ═══════════════════════════════════════════════════════════
  // AVATAR UPLOAD
  // ═══════════════════════════════════════════════════════════
  Future<void> _changeAvatar() async {
    final auth = context.read<AuthProvider>();
    final uid = auth.user?.id;
    if (uid == null) return;

    final file = await StorageService.instance.pickImage(
      fromCamera: false,
      maxWidth: 800,
      imageQuality: 80,
    );
    if (file == null || !mounted) return;

    setState(() => _uploadingAvatar = true);
    try {
      final url = await StorageService.instance.uploadAvatar(
        userId: uid,
        file: file,
      );
      if (url == null) throw StateError('Upload failed');

      await Supabase.instance.client
          .from('profiles')
          .update({'profile_picture_url': url})
          .eq('id', uid);

      await auth.refresh();
      if (!mounted) return;
      ErrorUI.showSnack(
        context,
        AppError(
          title: _t('photo_updated'),
          message: _t('photo_updated_hint'),
          icon: Icons.check_circle_outline,
        ),
      );
    } catch (e) {
      if (!mounted) return;
      ErrorUI.showSnack(context, AppError.from(e));
    } finally {
      if (mounted) setState(() => _uploadingAvatar = false);
    }
  }

  // ═══════════════════════════════════════════════════════════
  // LOGOUT
  // ═══════════════════════════════════════════════════════════
  Future<void> _confirmLogout() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16)),
        title: Text(_t('logout_title')),
        content: Text(_t('logout_body_driver')),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: Text(_t('cancel')),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
                backgroundColor: EfuridePalette.dropoff,
                foregroundColor: Colors.white),
            onPressed: () => Navigator.pop(context, true),
            child: Text(_t('sign_out')),
          ),
        ],
      ),
    );
    if (ok != true) return;

    try {
      await Supabase.instance.client.auth.signOut();
      if (!mounted) return;
      Navigator.pushNamedAndRemoveUntil(
          context, '/role_select', (r) => false);
    } catch (e) {
      if (!mounted) return;
      ErrorUI.showSnack(context, AppError.from(e));
    }
  }

  // ═══════════════════════════════════════════════════════════
  // BUILD
  // ═══════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();

    return Column(
      children: [
        _header(auth),
        Expanded(
          child: RefreshIndicator(
            color: EfuridePalette.blueDeep,
            onRefresh: auth.refresh,
            child: ListView(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
              physics: const AlwaysScrollableScrollPhysics(),
              children: [
                _identityCard(auth),
                const SizedBox(height: 16),
                _accountSection(auth),
                const SizedBox(height: 16),
                _driverSection(),
                const SizedBox(height: 16),
                _preferencesSection(),
                const SizedBox(height: 16),
                _supportSection(),
                const SizedBox(height: 24),
                _logoutButton(),
                const SizedBox(height: 24),
              ],
            ),
          ),
        ),
      ],
    );
  }

  // ═══════════════════════════════════════════════════════════
  // HEADER
  // ═══════════════════════════════════════════════════════════
  Widget _header(AuthProvider auth) {
    return Container(
      decoration: const BoxDecoration(
        color: EfuridePalette.cream,
      ),
      child: SafeArea(
        bottom: false,
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(8, 8, 16, 12),
              child: Row(
                children: [
                  // Back arrow only when Profile was opened as its own
                  // page. As the "More" tab there is nothing behind it
                  // (going back used to land on sign-in).
                  if (context.findAncestorWidgetOfExactType<DriverShell>() == null &&
                      (ModalRoute.of(context)?.canPop ?? false))
                    IconButton(
                      onPressed: () => Navigator.maybePop(context),
                      icon: const Icon(Icons.arrow_back,
                          color: EfuridePalette.ink),
                    )
                  else
                    const SizedBox(width: 8),
                  const SizedBox(width: 4),
                  KongoBrand(role: _t('profile_driver_subtitle')),
                ],
              ),
            ),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.fromLTRB(16, 14, 16, 18),
              decoration: const BoxDecoration(
                color: EfuridePalette.cream,
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(24),
                  topRight: Radius.circular(24),
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(auth.displayName,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        color: EfuridePalette.ink,
                        fontSize: 20,
                        fontWeight: FontWeight.w900,
                        letterSpacing: -0.3,
                      )),
                  const SizedBox(height: 6),
                  Row(
                    children: [
                      _pill(
                        icon: Icons.check_circle_outline,
                        label: auth.isActive
                            ? _t('status_active')
                            : _t('status_pending'),
                        color: auth.isActive
                            ? EfuridePalette.online
                            : EfuridePalette.merchantAccent,
                      ),
                      const SizedBox(width: 8),
                      _pill(
                        icon: auth.isOnline
                            ? Icons.wifi_tethering
                            : Icons.wifi_tethering_off,
                        label: auth.isOnline
                            ? _t('online')
                            : _t('offline'),
                        color: auth.isOnline
                            ? EfuridePalette.online
                            : EfuridePalette.inkMuted,
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _pill({
    required IconData icon,
    required String label,
    required Color color,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.15),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: color.withValues(alpha: 0.5)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 12, color: color),
          const SizedBox(width: 4),
          Text(
            label,
            style: TextStyle(
              fontSize: 13,
              fontWeight: FontWeight.w900,
              letterSpacing: 0.4,
              color: color,
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // IDENTITY CARD
  // ═══════════════════════════════════════════════════════════
  Widget _identityCard(AuthProvider auth) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: EfuridePalette.divider),
      ),
      child: Column(
        children: [
          Stack(
            children: [
              Container(
                width: 100,
                height: 100,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(
                      color: EfuridePalette.blueDeep.withValues(alpha: 0.3),
                      width: 3),
                ),
                child: ClipOval(
                  child: (auth.avatarUrl?.isNotEmpty == true)
                      ? Image.network(
                          auth.avatarUrl!,
                          width: 100,
                          height: 100,
                          fit: BoxFit.cover,
                          errorBuilder: (_, __, ___) =>
                              _initialsFallback(auth),
                        )
                      : _initialsFallback(auth),
                ),
              ),
              if (_uploadingAvatar)
                Positioned.fill(
                  child: Container(
                    decoration: const BoxDecoration(
                      color: Colors.black26,
                      shape: BoxShape.circle,
                    ),
                    child: const Center(
                      child: CircularProgressIndicator(
                          strokeWidth: 2, color: Colors.white),
                    ),
                  ),
                ),
              Positioned(
                bottom: 0,
                right: 0,
                child: GestureDetector(
                  onTap: _uploadingAvatar ? null : _changeAvatar,
                  child: Container(
                    width: 32,
                    height: 32,
                    decoration: BoxDecoration(
                      color: EfuridePalette.blueDeep,
                      shape: BoxShape.circle,
                      border: Border.all(color: Colors.white, width: 2),
                    ),
                    child: const KIcon(Icons.camera_alt,
                        size: 15, color: Colors.white),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          Text(
            auth.displayName,
            style: const TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w900,
              color: EfuridePalette.ink,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            _t('role_driver'),
            style: const TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.w700,
              color: EfuridePalette.blueDeep,
              letterSpacing: 0.6,
            ),
          ),
          if (auth.profile?['total_ratings'] != null &&
              (auth.profile!['total_ratings'] as num) > 0) ...[
            const SizedBox(height: 10),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(Icons.star,
                    size: 16, color: EfuridePalette.accent),
                const SizedBox(width: 4),
                Text(
                  ((auth.profile!['average_rating'] ?? 5.0) as num)
                      .toStringAsFixed(2),
                  style: const TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w900,
                    color: EfuridePalette.ink,
                  ),
                ),
                const SizedBox(width: 6),
                Text(
                  '(${auth.profile!['total_ratings']})',
                  style: const TextStyle(
                      fontSize: 13.5, color: EfuridePalette.inkMuted),
                ),
              ],
            ),
          ],
        ],
      ),
    );
  }

  Widget _initialsFallback(AuthProvider auth) {
    final name = auth.displayName;
    final initial = name.isNotEmpty ? name[0].toUpperCase() : '?';
    return Container(
      width: 100,
      height: 100,
      alignment: Alignment.center,
      color: EfuridePalette.blueDeep.withValues(alpha: 0.10),
      child: Text(
        initial,
        style: const TextStyle(
          fontSize: 40,
          fontWeight: FontWeight.w900,
          color: EfuridePalette.blueDeep,
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // ACCOUNT SECTION
  // ═══════════════════════════════════════════════════════════
  Widget _accountSection(AuthProvider auth) {
    final first = (auth.profile?['first_name'] ?? '').toString();
    final surname = (auth.profile?['surname'] ?? '').toString();
    final fullName =
        '${first.isEmpty ? '' : first} ${surname.isEmpty ? '' : surname}'
            .trim();
    final email = (auth.profile?['email'] ?? auth.user?.email ?? '').toString();
    final phone =
        (auth.profile?['phone'] ?? auth.profile?['phone_number'] ?? '')
            .toString();
    final gender = (auth.profile?['gender'] ?? '').toString();

    return _sectionCard(
      title: _t('account'),
      children: [
        _detailRow(
          icon: Icons.person_outline,
          label: _t('full_name'),
          value: fullName.isEmpty ? _t('not_set') : fullName,
        ),
        _divider(),
        _detailRow(
          icon: Icons.email_outlined,
          label: _t('email'),
          value: email.isEmpty ? _t('not_set') : email,
        ),
        _divider(),
        _detailRow(
          icon: Icons.phone_outlined,
          label: _t('phone'),
          value: phone.isEmpty ? _t('not_set') : phone,
          actionLabel: phone.isEmpty ? _t('add') : _t('edit'),
          onAction: () => Navigator.pushNamed(context, '/driver_settings'),
        ),
        _divider(),
        _detailRow(
          icon: Icons.wc_outlined,
          label: _t('gender'),
          value: gender.isEmpty ? _t('not_set') : _capitalize(gender),
          actionLabel: gender.isEmpty ? _t('add') : _t('edit'),
          onAction: () => Navigator.pushNamed(context, '/driver_settings'),
        ),
      ],
    );
  }

  String _capitalize(String s) =>
      s.isEmpty ? s : s[0].toUpperCase() + s.substring(1);

  // ═══════════════════════════════════════════════════════════
  // DRIVER SECTION
  // ═══════════════════════════════════════════════════════════
  Widget _driverSection() {
    return _sectionCard(
      title: _t('driver_section'),
      children: [
        _navRow(
          icon: Icons.directions_car_outlined,
          title: _t('my_vehicles'),
          subtitle: _t('my_vehicles_hint'),
          onTap: () => Navigator.pushNamed(context, '/vehicles'),
        ),
        _divider(),
        _navRow(
          icon: Icons.verified_user_outlined,
          title: _t('kyc_documents'),
          subtitle: _t('kyc_documents_hint'),
          onTap: () => Navigator.pushNamed(context, '/driver_documents'),
        ),
        _divider(),
        _navRow(
          icon: Icons.account_balance_outlined,
          title: _t('bank_details'),
          subtitle: _t('bank_details_hint'),
          onTap: () => Navigator.pushNamed(context, '/driver_bank'),
        ),
        _divider(),
        _navRow(
          icon: Icons.school_outlined,
          title: _t('driver_academy'),
          subtitle: _t('driver_academy_hint'),
          onTap: () => Navigator.pushNamed(context, '/driver_training'),
        ),
      ],
    );
  }

  // ═══════════════════════════════════════════════════════════
  // PREFERENCES
  // ═══════════════════════════════════════════════════════════
  Widget _preferencesSection() {
    return _sectionCard(
      title: _t('preferences'),
      children: [
        _navRow(
          icon: Icons.tune,
          title: _t('settings'),
          subtitle: _t('settings_hint'),
          onTap: () => Navigator.pushNamed(context, '/driver_settings'),
        ),
      ],
    );
  }

  // ═══════════════════════════════════════════════════════════
  // SUPPORT
  // ═══════════════════════════════════════════════════════════
  Widget _supportSection() {
    return _sectionCard(
      title: _t('support_legal'),
      children: [
        _navRow(
          icon: Icons.help_outline,
          title: _t('help_support'),
          onTap: () => Navigator.pushNamed(context, '/support'),
        ),
        _divider(),
        _navRow(
          icon: Icons.privacy_tip_outlined,
          title: _t('privacy'),
          onTap: () => Navigator.pushNamed(context, '/customer_privacy'),
        ),
      ],
    );
  }

  // ═══════════════════════════════════════════════════════════
  // LOGOUT
  // ═══════════════════════════════════════════════════════════
  Widget _logoutButton() {
    return SizedBox(
      width: double.infinity,
      child: OutlinedButton.icon(
        onPressed: _confirmLogout,
        icon: const KIcon(Icons.logout,
            size: 18, color: EfuridePalette.dropoff),
        label: Text(_t('sign_out'),
            style: const TextStyle(
              color: EfuridePalette.dropoff,
              fontSize: 14.5,
              fontWeight: FontWeight.w800,
            )),
        style: OutlinedButton.styleFrom(
          minimumSize: const Size(double.infinity, 54),
          side: const BorderSide(
              color: EfuridePalette.dropoff, width: 1.4),
          shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(14)),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // SECTION PRIMITIVES
  // ═══════════════════════════════════════════════════════════
  Widget _sectionCard({
    required String title,
    required List<Widget> children,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(left: 4, bottom: 8),
          child: Text(
            title.toUpperCase(),
            style: const TextStyle(
              fontSize: 13,
              fontWeight: FontWeight.w800,
              letterSpacing: 0.8,
              color: EfuridePalette.inkMuted,
            ),
          ),
        ),
        Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: EfuridePalette.divider),
          ),
          child: Column(children: children),
        ),
      ],
    );
  }

  Widget _divider() => const Divider(
        height: 1,
        indent: 56,
        endIndent: 14,
        color: EfuridePalette.divider,
      );

  Widget _detailRow({
    required IconData icon,
    required String label,
    required String value,
    String? actionLabel,
    VoidCallback? onAction,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      child: Row(
        children: [
          Container(
            width: 32,
            height: 32,
            decoration: BoxDecoration(
              color: EfuridePalette.blueDeep.withValues(alpha: 0.10),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Icon(icon, size: 16, color: EfuridePalette.blueDeep),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: const TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w700,
                    color: EfuridePalette.inkMuted,
                    letterSpacing: 0.3,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  value,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: value == _t('not_set')
                        ? FontWeight.w500
                        : FontWeight.w700,
                    color: value == _t('not_set')
                        ? EfuridePalette.inkMuted
                        : EfuridePalette.ink,
                  ),
                ),
              ],
            ),
          ),
          if (actionLabel != null && onAction != null)
            TextButton(
              onPressed: onAction,
              style: TextButton.styleFrom(
                minimumSize: const Size(0, 32),
                padding:
                    const EdgeInsets.symmetric(horizontal: 12),
              ),
              child: Text(
                actionLabel,
                style: const TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w800,
                  color: EfuridePalette.blueDeep,
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _navRow({
    required IconData icon,
    required String title,
    String? subtitle,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        child: Row(
          children: [
            Container(
              width: 32,
              height: 32,
              decoration: BoxDecoration(
                color: EfuridePalette.blueDeep.withValues(alpha: 0.10),
                borderRadius: BorderRadius.circular(8),
              ),
              child:
                  Icon(icon, size: 16, color: EfuridePalette.blueDeep),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title,
                      style: const TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w700,
                        color: EfuridePalette.ink,
                      )),
                  if (subtitle != null && subtitle.isNotEmpty) ...[
                    const SizedBox(height: 2),
                    Text(subtitle,
                        style: const TextStyle(
                          fontSize: 13,
                          color: EfuridePalette.inkMuted,
                          height: 1.3,
                        )),
                  ],
                ],
              ),
            ),
            const Icon(Icons.chevron_right,
                size: 20, color: EfuridePalette.inkMuted),
          ],
        ),
      ),
    );
  }
}
