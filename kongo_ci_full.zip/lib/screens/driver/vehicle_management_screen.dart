﻿// lib/screens/driver/vehicle_management_screen.dart

import 'package:efuride_app/widgets/private_image.dart';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:efuride_app/config/app_images.dart';
import 'package:efuride_app/widgets/app_image.dart';
import 'package:efuride_app/utils/app_error.dart';
import 'package:efuride_app/utils/error_ui.dart';
import 'package:efuride_app/l10n/app_strings.dart';

class _Palette {
  static const cream = Color(0xFFFAF6EE);
  static const ink = Color(0xFF1A1A1A);
  static const inkMuted = Color(0xFF575047);
  static const accent = Color(0xFFF2B705);
  static const accentInk = Color(0xFF0B1220);
  static const divider = Color(0xFFE8E2D5);
  static const blue = Color(0xFF1E88E5);
  static const pickup = Color(0xFF34C759);
  static const dropoff = Color(0xFFE53935);
  static const delivery = Color(0xFFE88A1A);
}

/// Vehicle classes a driver can register.
/// Each class has its own picture; XL and Large van show a clean icon until
/// their own pictures are added (assets/images/vehicle_xl.png and
/// assets/images/vehicle_large_van.png — drop them in, no code change).
enum RideClass {
  sedan('sedan', 'Sedan (up to 4 seats)', Icons.directions_car),
  xl('xl', 'XL (6 seats, SUV / minivan)', Icons.directions_car_filled),
  van('van', 'Van / minibus (up to 14 seats)', Icons.airport_shuttle),
  largeVan('large_van', 'Large van (cargo)', Icons.local_shipping_outlined),
  truck('truck', 'Truck', Icons.local_shipping),
  bike('bike', 'Motorbike / Scooter', Icons.two_wheeler);

  const RideClass(this.value, this.label, this.icon);
  final String value;
  final String label;
  final IconData icon;

  static RideClass fromValue(String? v) => RideClass.values.firstWhere(
        (e) => e.value == (v ?? '').toLowerCase(),
        orElse: () => RideClass.sedan,
      );

  /// Picture per class (never the same picture for two classes).
  String get asset {
    switch (this) {
      case RideClass.bike:
        return AppImages.driverBike;
      case RideClass.van:
        return AppImages.driverVan;
      case RideClass.truck:
        return AppImages.deliveryTruck;
      case RideClass.xl:
        return 'assets/images/vehicle_xl.png';
      case RideClass.largeVan:
        return 'assets/images/vehicle_large_van.png';
      case RideClass.sedan:
        return AppImages.driverSedan;
    }
  }

  /// Default passenger capacity when this class is picked.
  String get defaultSeats {
    switch (this) {
      case RideClass.bike:
        return '1';
      case RideClass.xl:
        return '6';
      case RideClass.van:
        return '14';
      case RideClass.largeVan:
        return '3';
      case RideClass.truck:
        return '2';
      case RideClass.sedan:
        return '4';
    }
  }

  /// Which services this class can serve. Large vans and trucks carry
  /// goods only (deliveries / moving), everything else does both.
  Set<String> get defaultServices {
    switch (this) {
      case RideClass.largeVan:
      case RideClass.truck:
        return {'Delivery'};
      default:
        return {'Ride', 'Delivery'};
    }
  }
}

class VehicleManagementScreen extends StatefulWidget {
  const VehicleManagementScreen({super.key});

  @override
  State<VehicleManagementScreen> createState() =>
      _VehicleManagementScreenState();
}

class _VehicleManagementScreenState extends State<VehicleManagementScreen> {
  List<Map<String, dynamic>> _vehicles = [];
  bool _isLoading = true;
  AppError? _error;

  @override
  void initState() {
    super.initState();
    _loadVehicles();
  }

  Future<void> _loadVehicles() async {
    if (!mounted) return;
    setState(() {
      _isLoading = true;
      _error = null;
    });

    try {
      final userId = Supabase.instance.client.auth.currentUser?.id;
      if (userId == null) {
        if (mounted) setState(() => _isLoading = false);
        return;
      }

      final response = await Supabase.instance.client
          .from('vehicles')
          .select('*')
          .eq('driver_id', userId)
          .order('created_at', ascending: false)
          .timeout(const Duration(seconds: 15));

      if (!mounted) return;
      setState(() {
        _vehicles = List<Map<String, dynamic>>.from(response);
        _isLoading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _error = AppError.from(e, onRetry: _loadVehicles);
        _vehicles = [];
        _isLoading = false;
      });
    }
  }

  Future<void> _deleteVehicle(String vehicleId, String label) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Text(tr('Delete vehicle?')),
        content: Text(
            tr('Are you sure you want to delete "{0}"? This cannot be undone.', [label])),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: Text(tr('Cancel')),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            onPressed: () => Navigator.pop(context, true),
            child: Text(tr('Delete')),
          ),
        ],
      ),
    );

    if (confirmed != true) return;

    try {
      await Supabase.instance.client
          .from('vehicles')
          .delete()
          .eq('id', vehicleId);
      if (!mounted) return;
      setState(() => _vehicles.removeWhere((v) => v['id'] == vehicleId));
      ErrorUI.showSnack(
        context,
        AppError(
          title: tr('Vehicle deleted'),
          message: tr('Your vehicle has been removed.'),
          icon: Icons.check_circle_outline,
        ),
      );
    } catch (e) {
      if (!mounted) return;
      ErrorUI.showSnack(
        context,
        AppError.from(e, onRetry: () => _deleteVehicle(vehicleId, label)),
      );
    }
  }

  Future<String?> _uploadVehicleFile(File file, String prefix) async {
    try {
      final ext = file.path.split('.').last;
      final fileName =
          '${prefix}_${DateTime.now().millisecondsSinceEpoch}.$ext';
      // Each driver's own folder (the storage rule only allows uid/...).
      final uid = Supabase.instance.client.auth.currentUser?.id ?? 'unknown';
      final path = '$uid/$fileName';

      await Supabase.instance.client.storage
          .from('vehicle_documents')
          .upload(path, file);

      return Supabase.instance.client.storage
          .from('vehicle_documents')
          .getPublicUrl(path);
    } catch (e) {
      debugPrint('upload error: $e');
      return null;
    }
  }

  Future<void> _showVehicleForm({Map<String, dynamic>? existing}) async {
    final isEdit = existing != null;

    final makeController =
        TextEditingController(text: existing?['make']?.toString() ?? '');
    final modelController =
        TextEditingController(text: existing?['model']?.toString() ?? '');
    final plateController = TextEditingController(
        text: existing?['plate_number']?.toString() ?? '');
    final yearController = TextEditingController(
        text: existing?['year']?.toString() ?? '2024');
    final colorController =
        TextEditingController(text: existing?['color']?.toString() ?? '');

    RideClass selectedClass =
        RideClass.fromValue(existing?['category']?.toString());

    final seatsController = TextEditingController(
        text: existing?['seats']?.toString() ?? selectedClass.defaultSeats);

    // ── Service types (Ride / Delivery) — multi-select ──
    // Reads from service_types array; falls back to single service_type.
    Set<String> selectedServices = _readServicesFromRow(existing);

    File? vehicleImage;
    File? discImage;
    File? ownerDocImage;

    String? vehicleImageUrl = existing?['vehicle_image_url']?.toString();
    String? discImageUrl = existing?['disc_image_url']?.toString();
    String? ownerDocUrl = existing?['owner_doc_url']?.toString();

    final picker = ImagePicker();
    bool isSaving = false;

    final saved = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setDialogState) {
          Future<void> pickAndSet(String type) async {
            try {
              final picked = await picker.pickImage(
                source: ImageSource.gallery,
                imageQuality: 70,
              );
              if (picked == null) return;
              setDialogState(() {
                if (type == 'vehicle') vehicleImage = File(picked.path);
                if (type == 'disc') discImage = File(picked.path);
                if (type == 'owner') ownerDocImage = File(picked.path);
              });
            } catch (e) {
              if (!ctx.mounted) return;
              ErrorUI.showSnack(ctx, AppError.from(e));
            }
          }

          Widget uploadTile({
            required String label,
            required File? file,
            required String? url,
            required VoidCallback onTap,
            bool required = false,
          }) {
            final hasImage = file != null || (url != null && url.isNotEmpty);
            final showError = required && !hasImage;
            return Column(
              children: [
                GestureDetector(
                  onTap: onTap,
                  child: Container(
                    height: 90,
                    width: 90,
                    decoration: BoxDecoration(
                      color: hasImage ? null : _Palette.cream,
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(
                        color: showError
                            ? _Palette.dropoff
                            : _Palette.divider,
                        width: showError ? 1.5 : 1,
                      ),
                    ),
                    child: hasImage
                        ? ClipRRect(
                            borderRadius: BorderRadius.circular(8),
                            child: file != null
                                ? Image.file(file, fit: BoxFit.cover)
                                : PrivateImage(url: url!, fit: BoxFit.cover),
                          )
                        : Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(
                                Icons.add_a_photo,
                                color: showError
                                    ? _Palette.dropoff
                                    : _Palette.inkMuted,
                                size: 22,
                              ),
                              const SizedBox(height: 4),
                              Text(
                                label,
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  fontSize: 12,
                                  color: showError
                                      ? _Palette.dropoff
                                      : _Palette.inkMuted,
                                ),
                              ),
                            ],
                          ),
                  ),
                ),
                if (required)
                  Padding(
                    padding: const EdgeInsets.only(top: 4),
                    child: Text(
                      tr('Required'),
                      style: TextStyle(
                        fontSize: 12,
                        color: showError
                            ? _Palette.dropoff
                            : _Palette.inkMuted,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
              ],
            );
          }

          Widget serviceChip(String label, IconData icon, Color color) {
            final selected = selectedServices.contains(label);
            return InkWell(
              onTap: () {
                setDialogState(() {
                  if (selected) {
                    // Never allow empty set — a vehicle must serve something
                    if (selectedServices.length > 1) {
                      selectedServices = Set<String>.from(selectedServices)
                        ..remove(label);
                    }
                  } else {
                    selectedServices =
                        Set<String>.from(selectedServices)..add(label);
                  }
                });
              },
              borderRadius: BorderRadius.circular(12),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 160),
                padding:
                    const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                decoration: BoxDecoration(
                  color: selected
                      ? color.withOpacity(0.12)
                      : Colors.transparent,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: selected ? color : _Palette.divider,
                    width: selected ? 1.6 : 1,
                  ),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(icon,
                        size: 16,
                        color: selected ? color : _Palette.inkMuted),
                    const SizedBox(width: 6),
                    Text(
                      label,
                      style: TextStyle(
                        fontSize: 14,
                        fontWeight: selected
                            ? FontWeight.w700
                            : FontWeight.w500,
                        color: selected ? color : _Palette.inkMuted,
                      ),
                    ),
                  ],
                ),
              ),
            );
          }

          return AlertDialog(
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16)),
            title: Text(isEdit ? 'Edit Vehicle' : 'Add Vehicle'),
            content: SingleChildScrollView(
              child: SizedBox(
                width: 440,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    TextField(
                      controller: makeController,
                      decoration: InputDecoration(
                        labelText: tr('Make (e.g. Toyota)'),
                        border: OutlineInputBorder(),
                      ),
                    ),
                    const SizedBox(height: 12),
                    TextField(
                      controller: modelController,
                      decoration: InputDecoration(
                        labelText: tr('Model (e.g. Corolla)'),
                        border: OutlineInputBorder(),
                      ),
                    ),
                    const SizedBox(height: 12),
                    TextField(
                      controller: plateController,
                      decoration: InputDecoration(
                        labelText: tr('Plate Number (e.g. CA123-45)'),
                        border: OutlineInputBorder(),
                      ),
                    ),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        Expanded(
                          child: TextField(
                            controller: yearController,
                            keyboardType: TextInputType.number,
                            decoration: InputDecoration(
                              labelText: tr('Year'),
                              border: OutlineInputBorder(),
                            ),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: TextField(
                            controller: colorController,
                            decoration: InputDecoration(
                              labelText: tr('Colour'),
                              border: OutlineInputBorder(),
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    DropdownButtonFormField<RideClass>(
                      value: selectedClass,
                      decoration: InputDecoration(
                        labelText: tr('Vehicle class'),
                        border: OutlineInputBorder(),
                      ),
                      items: RideClass.values
                          .map(
                            (c) => DropdownMenuItem(
                              value: c,
                              child: Row(
                                children: [
                                  AppImage(
                                    c.asset,
                                    size: 24,
                                    fallbackIcon: c.icon,
                                  ),
                                  const SizedBox(width: 8),
                                  Flexible(
                                    child: Text(
                                      tr(c.label),
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          )
                          .toList(),
                      onChanged: (v) {
                        setDialogState(() {
                          selectedClass = v ?? RideClass.sedan;
                          seatsController.text = selectedClass.defaultSeats;
                          // Refresh default services when class changes
                          // (they're the same for now, but future-proof).
                          if (!isEdit) {
                            selectedServices = Set<String>.from(
                                selectedClass.defaultServices);
                          }
                        });
                      },
                    ),
                    const SizedBox(height: 12),
                    TextField(
                      controller: seatsController,
                      keyboardType: TextInputType.number,
                      decoration: InputDecoration(
                        labelText: tr('Seats / capacity'),
                        border: OutlineInputBorder(),
                      ),
                    ),

                    const SizedBox(height: 16),
                    Text(
                      tr('Services this vehicle can serve'),
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 14,
                        color: _Palette.inkMuted,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Wrap(
                      spacing: 10,
                      runSpacing: 8,
                      children: [
                        serviceChip('Ride', Icons.person_pin_circle_outlined,
                            _Palette.blue),
                        serviceChip('Delivery', Icons.local_shipping_outlined,
                            _Palette.delivery),
                      ],
                    ),

                    const SizedBox(height: 18),
                    Align(
                      alignment: Alignment.centerLeft,
                      child: Text(
                        tr('Documents (upload pictures)'),
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 14,
                          color: _Palette.inkMuted,
                        ),
                      ),
                    ),
                    const SizedBox(height: 8),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        uploadTile(
                          label: tr('Vehicle photo'),
                          file: vehicleImage,
                          url: vehicleImageUrl,
                          onTap: () => pickAndSet('vehicle'),
                          required: true,
                        ),
                        uploadTile(
                          label: tr('Disc'),
                          file: discImage,
                          url: discImageUrl,
                          onTap: () => pickAndSet('disc'),
                        ),
                        uploadTile(
                          label: tr('Owner doc'),
                          file: ownerDocImage,
                          url: ownerDocUrl,
                          onTap: () => pickAndSet('owner'),
                        ),
                      ],
                    ),

                    const SizedBox(height: 16),
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: Colors.orange.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(
                            color: Colors.orange.withOpacity(0.3)),
                      ),
                      child: Row(
                        children: [
                          Icon(Icons.info_outline,
                              color: Colors.orange, size: 18),
                          SizedBox(width: 8),
                          Expanded(
                            child: Text(
                              tr('Your vehicle will be reviewed by an admin before it becomes active.'),
                              style: TextStyle(fontSize: 13.5),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            actions: [
              TextButton(
                onPressed: isSaving ? null : () => Navigator.pop(ctx, false),
                child: Text(tr('Cancel')),
              ),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFFF2B705),
                  foregroundColor: const Color(0xFF0B1220),
                ),
                onPressed: isSaving
                    ? null
                    : () async {
                        if (makeController.text.trim().isEmpty ||
                            plateController.text.trim().isEmpty) {
                          ErrorUI.showSnack(
                            ctx,
                            AppError(
                              title: tr('Missing details'),
                              message:
                                  tr('Make and plate number are required.'),
                              icon: Icons.info_outline,
                            ),
                          );
                          return;
                        }

                        if (selectedServices.isEmpty) {
                          ErrorUI.showSnack(
                            ctx,
                            AppError(
                              title: tr('Pick a service'),
                              message:
                                  tr('Choose at least Ride or Delivery.'),
                              icon: Icons.info_outline,
                            ),
                          );
                          return;
                        }

                        final hasVehiclePhoto = vehicleImage != null ||
                            (vehicleImageUrl != null &&
                                vehicleImageUrl!.isNotEmpty);
                        if (!hasVehiclePhoto) {
                          ErrorUI.showSnack(
                            ctx,
                            AppError(
                              title: tr('Missing vehicle photo'),
                              message:
                                  tr('Please upload a photo of the vehicle.'),
                              icon: Icons.image_not_supported_outlined,
                            ),
                          );
                          return;
                        }

                        setDialogState(() => isSaving = true);

                        try {
                          String? vUrl = vehicleImageUrl;
                          String? dUrl = discImageUrl;
                          String? oUrl = ownerDocUrl;

                          if (vehicleImage != null) {
                            vUrl = await _uploadVehicleFile(
                                vehicleImage!, 'vehicle');
                          }
                          if (discImage != null) {
                            dUrl =
                                await _uploadVehicleFile(discImage!, 'disc');
                          }
                          if (ownerDocImage != null) {
                            oUrl = await _uploadVehicleFile(
                                ownerDocImage!, 'owner');
                          }

                          final userId = Supabase
                              .instance.client.auth.currentUser?.id;
                          if (userId == null) {
                            throw Exception('Not signed in');
                          }

                          // Sorted, stable order so DB comparisons are simple
                          final svcList = selectedServices.toList()..sort();
                          final primaryService = svcList.contains('Ride')
                              ? 'Ride'
                              : svcList.first;

                          final payload = {
                            'driver_id': userId,
                            'make': makeController.text.trim(),
                            'model': modelController.text.trim(),
                            'plate_number': plateController.text.trim(),
                            'year':
                                int.tryParse(yearController.text.trim()),
                            'color': colorController.text.trim(),
                            'seats':
                                int.tryParse(seatsController.text.trim()),
                            'category': selectedClass.value,
                            'service_type': primaryService,
                            'service_types': svcList,
                            'status': 'under_review',
                            'vehicle_image_url': vUrl,
                            'disc_image_url': dUrl,
                            'owner_doc_url': oUrl,
                            'updated_at':
                                DateTime.now().toUtc().toIso8601String(),
                          };

                          if (isEdit) {
                            await Supabase.instance.client
                                .from('vehicles')
                                .update(payload)
                                .eq('id', existing!['id']);
                          } else {
                            await Supabase.instance.client
                                .from('vehicles')
                                .insert({
                              ...payload,
                              'created_at':
                                  DateTime.now().toUtc().toIso8601String(),
                            });
                          }

                          if (!mounted) return;
                          Navigator.pop(ctx, true);
                        } catch (e) {
                          if (!mounted) return;
                          setDialogState(() => isSaving = false);
                          ErrorUI.showSnack(ctx, AppError.from(e));
                        }
                      },
                child: isSaving
                    ? const SizedBox(
                        width: 16,
                        height: 16,
                        child: CircularProgressIndicator(
                            strokeWidth: 2, color: Colors.white),
                      )
                    : Text(isEdit ? 'Save' : 'Submit'),
              ),
            ],
          );
        },
      ),
    );

    if (saved != true) return;

    if (!mounted) return;
    ErrorUI.showSnack(
      context,
      AppError(
        title: isEdit ? 'Vehicle updated' : 'Vehicle submitted',
        message: tr('Pending admin review.'),
        icon: Icons.check_circle_outline,
      ),
    );
    _loadVehicles();
  }

  /// Reads services from either `service_types` (array) or `service_type`
  /// (single). Always returns a non-empty set.
  Set<String> _readServicesFromRow(Map<String, dynamic>? row) {
    if (row == null) return {'Ride', 'Delivery'};

    final raw = row['service_types'];
    if (raw is List && raw.isNotEmpty) {
      final set = raw
          .map((e) => e.toString().trim())
          .where((e) => e == 'Ride' || e == 'Delivery')
          .toSet();
      if (set.isNotEmpty) return set;
    }

    final single = row['service_type']?.toString().trim();
    if (single == 'Ride' || single == 'Delivery') return {single!};

    return {'Ride', 'Delivery'};
  }

  Color _statusColor(String status) {
    switch (status.toLowerCase()) {
      case 'active':
        return _Palette.pickup;
      case 'under_review':
      case 'pending':
        return Colors.orange;
      case 'rejected':
        return _Palette.dropoff;
      case 'inactive':
        return _Palette.inkMuted;
      default:
        return _Palette.blue;
    }
  }

  /// PNG per vehicle category, tinted by status.
  Widget _vehicleThumb({
    required Map<String, dynamic> vehicle,
    required Color statusColor,
  }) {
    final category = vehicle['category']?.toString() ?? 'sedan';
    final asset = RideClass.fromValue(category).asset;
    final url = vehicle['vehicle_image_url']?.toString();

    return ClipRRect(
      borderRadius: BorderRadius.circular(10),
      child: (url != null && url.isNotEmpty)
          ? PrivateImage(
              url: url,
              width: 64,
              height: 64,
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => _vehicleThumbFallback(
                asset: asset,
                statusColor: statusColor,
              ),
            )
          : _vehicleThumbFallback(
              asset: asset,
              statusColor: statusColor,
            ),
    );
  }

  Widget _vehicleThumbFallback({
    required String asset,
    required Color statusColor,
  }) {
    return Container(
      width: 64,
      height: 64,
      color: statusColor.withOpacity(0.12),
      padding: const EdgeInsets.all(8),
      child: AppImage(
        asset,
        size: 48,
        tint: statusColor,
        fallbackIcon: _iconForAsset(asset),
      ),
    );
  }

  IconData _iconForAsset(String asset) {
    for (final c in RideClass.values) {
      if (c.asset == asset) return c.icon;
    }
    return Icons.directions_car_filled;
  }

  Widget _serviceBadge(String label) {
    final isRide = label == 'Ride';
    final color = isRide ? _Palette.blue : _Palette.delivery;
    final icon = isRide
        ? Icons.person_pin_circle_outlined
        : Icons.local_shipping_outlined;

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: color.withOpacity(0.12),
        borderRadius: BorderRadius.circular(6),
        border: Border.all(color: color.withOpacity(0.35), width: 0.8),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 11, color: color),
          const SizedBox(width: 4),
          Text(
            label,
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w700,
              color: color,
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _Palette.cream,
      appBar: AppBar(
        backgroundColor: _Palette.cream,
        elevation: 0,
        iconTheme: const IconThemeData(color: _Palette.ink),
        title: Text(
          tr('My Vehicles'),
          style: TextStyle(
              color: _Palette.ink,
              fontWeight: FontWeight.bold,
              fontSize: 18),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh, color: _Palette.ink),
            onPressed: _loadVehicles,
            tooltip: tr('Refresh'),
          ),
        ],
      ),
      body: _isLoading
          ? const Center(
              child: CircularProgressIndicator(color: _Palette.accent))
          : _error != null
              ? ErrorUI.inline(_error!)
              : _vehicles.isEmpty
                  ? Center(
                      child: Padding(
                        padding: const EdgeInsets.all(24),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            AppImage(
                              AppImages.driverCar,
                              size: 80,
                              tint: _Palette.inkMuted,
                              fallbackIcon:
                                  Icons.directions_car_outlined,
                            ),
                            const SizedBox(height: 16),
                            Text(tr('No vehicles added'),
                                style: TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.bold,
                                    color: _Palette.ink)),
                            const SizedBox(height: 8),
                            Text(
                                tr('Add your vehicle or bike to start accepting rides and deliveries.'),
                                style: TextStyle(
                                    color: _Palette.inkMuted, fontSize: 13.5),
                                textAlign: TextAlign.center),
                            const SizedBox(height: 24),
                            ElevatedButton.icon(
                              onPressed: () => _showVehicleForm(),
                              icon: const Icon(Icons.add),
                              label: Text(tr('Add Vehicle')),
                              style: ElevatedButton.styleFrom(
                                backgroundColor: _Palette.accent,
                                foregroundColor: _Palette.accentInk,
                              ),
                            ),
                          ],
                        ),
                      ),
                    )
                  : RefreshIndicator(
                      onRefresh: _loadVehicles,
                      color: _Palette.accent,
                      child: ListView.builder(
                        padding: const EdgeInsets.fromLTRB(16, 16, 16, 96),
                        itemCount: _vehicles.length,
                        itemBuilder: (context, index) {
                          final v = _vehicles[index];
                          final id = v['id']?.toString() ?? '';
                          final make = v['make']?.toString() ?? '';
                          final model = v['model']?.toString() ?? '';
                          final plate =
                              v['plate_number']?.toString() ?? '—';
                          final category =
                              v['category']?.toString() ?? 'sedan';
                          final status =
                              v['status']?.toString() ?? 'under_review';
                          final year = v['year']?.toString() ?? '';
                          final color = v['color']?.toString() ?? '';
                          final seats = v['seats']?.toString() ?? '';
                          final services = _readServicesFromRow(v).toList()
                            ..sort();

                          final statusColor = _statusColor(status);
                          final isVerified =
                              status.toLowerCase() == 'active';
                          final isRejected =
                              status.toLowerCase() == 'rejected';

                          final title = '$make $model'.trim();

                          return Container(
                            margin: const EdgeInsets.only(bottom: 12),
                            padding: const EdgeInsets.all(14),
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(14),
                              border: Border.all(
                                color: statusColor.withOpacity(0.3),
                                width: 1.5,
                              ),
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                // ── Header row: thumb + title + status ──
                                Row(
                                  crossAxisAlignment:
                                      CrossAxisAlignment.start,
                                  children: [
                                    _vehicleThumb(
                                      vehicle: v,
                                      statusColor: statusColor,
                                    ),
                                    const SizedBox(width: 12),
                                    Expanded(
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            title.isEmpty
                                                ? '(unnamed vehicle)'
                                                : title,
                                            maxLines: 1,
                                            overflow:
                                                TextOverflow.ellipsis,
                                            style: const TextStyle(
                                                fontWeight: FontWeight.bold,
                                                fontSize: 15,
                                                color: _Palette.ink),
                                          ),
                                          const SizedBox(height: 4),
                                          Text(
                                            tr('Plate: {0}', [plate]),
                                            maxLines: 1,
                                            overflow:
                                                TextOverflow.ellipsis,
                                            style: const TextStyle(
                                                color: _Palette.inkMuted,
                                                fontSize: 13.5,
                                                fontWeight:
                                                    FontWeight.w600),
                                          ),
                                          const SizedBox(height: 2),
                                          Text(
                                            [
                                              tr(RideClass.fromValue(category)
                                                  .label),
                                              if (seats.isNotEmpty)
                                                '$seats seats',
                                              if (year.isNotEmpty) year,
                                              if (color.isNotEmpty) color,
                                            ].join(' • '),
                                            maxLines: 2,
                                            overflow:
                                                TextOverflow.ellipsis,
                                            style: const TextStyle(
                                                color: _Palette.inkMuted,
                                                fontSize: 13.5),
                                          ),
                                        ],
                                      ),
                                    ),
                                    const SizedBox(width: 8),
                                    Container(
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 10, vertical: 4),
                                      decoration: BoxDecoration(
                                        color:
                                            statusColor.withOpacity(0.15),
                                        borderRadius:
                                            BorderRadius.circular(8),
                                      ),
                                      child: Text(
                                        status.toUpperCase(),
                                        style: TextStyle(
                                            color: statusColor,
                                            fontSize: 12,
                                            fontWeight: FontWeight.bold),
                                      ),
                                    ),
                                  ],
                                ),

                                // ── Service badges ──
                                if (services.isNotEmpty) ...[
                                  const SizedBox(height: 10),
                                  Wrap(
                                    spacing: 6,
                                    runSpacing: 6,
                                    children: services
                                        .map(_serviceBadge)
                                        .toList(),
                                  ),
                                ],

                                if (isRejected) ...[
                                  const SizedBox(height: 10),
                                  Container(
                                    padding: const EdgeInsets.all(10),
                                    decoration: BoxDecoration(
                                      color: _Palette.dropoff
                                          .withOpacity(0.08),
                                      borderRadius:
                                          BorderRadius.circular(8),
                                    ),
                                    child: Row(
                                      children: [
                                        Icon(
                                            Icons.warning_amber_rounded,
                                            color: _Palette.dropoff,
                                            size: 16),
                                        SizedBox(width: 8),
                                        Expanded(
                                          child: Text(
                                            tr('Rejected — please edit and resubmit.'),
                                            style: TextStyle(
                                                color: _Palette.dropoff,
                                                fontSize: 13.5),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                                if (!isVerified) ...[
                                  const SizedBox(height: 12),
                                  Row(
                                    children: [
                                      Expanded(
                                        child: OutlinedButton.icon(
                                          onPressed: () => _showVehicleForm(
                                              existing: v),
                                          icon: const Icon(Icons.edit,
                                              size: 16),
                                          label: Text(tr('Edit')),
                                        ),
                                      ),
                                      const SizedBox(width: 8),
                                      Expanded(
                                        child: OutlinedButton.icon(
                                          style: OutlinedButton.styleFrom(
                                              foregroundColor:
                                                  _Palette.dropoff),
                                          onPressed: () => _deleteVehicle(
                                              id, title),
                                          icon: const Icon(Icons.delete,
                                              size: 16),
                                          label: Text(tr('Delete')),
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ],
                            ),
                          );
                        },
                      ),
                    ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _showVehicleForm(),
        backgroundColor: const Color(0xFFF2B705),
        icon: const Icon(Icons.add, color: const Color(0xFF0B1220)),
        label: Text(tr('Add Vehicle'),
            style: TextStyle(color: const Color(0xFF0B1220))),
      ),
    );
  }
}
