import 'package:efuride_app/config/efuride_palette.dart';
// lib/screens/driver/driver_shell.dart

import 'package:flutter/material.dart';
import 'package:efuride_app/config/tab_routes.dart';
import 'package:efuride_app/widgets/efuride_bottom_nav.dart';
import 'package:efuride_app/screens/driver/driver_home_screen.dart';
import 'package:efuride_app/screens/driver/driver_trips_screen.dart';
import 'package:efuride_app/screens/driver/driver_earnings_screen.dart';
import 'package:efuride_app/screens/driver/driver_profile_screen.dart';

class DriverShell extends StatefulWidget {
  final int initialIndex;
  const DriverShell({super.key, this.initialIndex = 0});

  @override
  State<DriverShell> createState() => _DriverShellState();
}

class _DriverShellState extends State<DriverShell> {
  late int _index;

  @override
  void initState() {
    super.initState();
    _index = widget.initialIndex.clamp(0, kDriverTabs.length - 1);
  }

  @override
  Widget build(BuildContext context) {
    // Phone Back button: from another tab go to the first tab; on the
    // first tab leave the app as usual (never back to sign-in).
    return PopScope(
      canPop: _index == 0,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop && _index != 0) setState(() => _index = 0);
      },
      child: Scaffold(
      backgroundColor: EfuridePalette.cream,
      body: IndexedStack(
        index: _index,
        children: const [
          DriverHomeScreen(),
          DriverTripsScreen(),
          DriverEarningsScreen(),
          DriverProfileScreen(),
        ],
      ),
      bottomNavigationBar: EfurideBottomNav(
        role: EfurideRole.driver,
        currentIndex: _index,
        onTap: (i) => setState(() => _index = i),
        items: kDriverTabs,
      ),
    ),
    );
  }
}

DriverShell buildDriverShell(Uri uri) => DriverShell(
      initialIndex: TabRoute.indexFor('driver', uri.queryParameters['tab']),
    );
