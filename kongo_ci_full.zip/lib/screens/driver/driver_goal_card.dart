// lib/screens/driver/driver_goal_card.dart
//
// Daily earnings goal: the driver sets a target and sees a progress bar
// under the day's figures. The goal is kept on the phone (no server needed).

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:efuride_app/config/country_config.dart';
import 'package:efuride_app/config/efuride_palette.dart';
import 'package:efuride_app/l10n/app_strings.dart';

class DriverGoalCard extends StatefulWidget {
  /// What the driver has earned today (the same figure the home shows).
  final double earnedToday;
  const DriverGoalCard({super.key, required this.earnedToday});

  @override
  State<DriverGoalCard> createState() => _DriverGoalCardState();
}

class _DriverGoalCardState extends State<DriverGoalCard> {
  static const _key = 'kongo_driver_daily_goal';
  double _goal = 0;
  bool _loaded = false;

  @override
  void initState() {
    super.initState();
    _read();
  }

  Future<void> _read() async {
    try {
      final p = await SharedPreferences.getInstance();
      _goal = p.getDouble(_key) ?? 0;
    } catch (_) {}
    if (mounted) setState(() => _loaded = true);
  }

  Future<void> _save(double v) async {
    try {
      final p = await SharedPreferences.getInstance();
      if (v <= 0) {
        await p.remove(_key);
      } else {
        await p.setDouble(_key, v);
      }
    } catch (_) {}
    if (mounted) setState(() => _goal = v < 0 ? 0 : v);
  }

  Future<void> _edit() async {
    final ctl = TextEditingController(
        text: _goal > 0 ? _goal.toStringAsFixed(0) : '');
    final result = await showDialog<double>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(tr('Daily goal')),
        content: TextField(
          controller: ctl,
          autofocus: true,
          keyboardType: const TextInputType.numberWithOptions(decimal: false),
          inputFormatters: [FilteringTextInputFormatter.digitsOnly],
          decoration:
              InputDecoration(hintText: tr('Amount you want to earn today')),
        ),
        actions: [
          if (_goal > 0)
            TextButton(
              onPressed: () => Navigator.pop(ctx, 0),
              child: Text(tr('Remove')),
            ),
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: Text(tr('Cancel')),
          ),
          ElevatedButton(
            onPressed: () =>
                Navigator.pop(ctx, double.tryParse(ctl.text.trim()) ?? -1),
            child: Text(tr('Save')),
          ),
        ],
      ),
    );
    if (result == null || result < 0) return;
    await _save(result);
  }

  @override
  Widget build(BuildContext context) {
    if (!_loaded) return const SizedBox.shrink();

    if (_goal <= 0) {
      return Padding(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
        child: InkWell(
          borderRadius: BorderRadius.circular(14),
          onTap: _edit,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: const Color(0xFFE8E2D5)),
            ),
            child: Row(
              children: [
                const Icon(Icons.flag_outlined, color: EfuridePalette.ink),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(tr('Set a daily goal'),
                      style: const TextStyle(
                          fontSize: 15, fontWeight: FontWeight.w700)),
                ),
                const Icon(Icons.chevron_right,
                    color: EfuridePalette.inkMuted),
              ],
            ),
          ),
        ),
      );
    }

    final done = widget.earnedToday >= _goal;
    final pct = (widget.earnedToday / _goal).clamp(0.0, 1.0);
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
      child: Container(
        padding: const EdgeInsets.fromLTRB(14, 12, 6, 12),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: const Color(0xFFE8E2D5)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(done ? Icons.emoji_events_outlined : Icons.flag_outlined,
                    color: done
                        ? const Color(0xFF16A34A)
                        : EfuridePalette.ink),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    done ? tr('Goal reached!') : tr('Daily goal'),
                    style: TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w800,
                        color: done
                            ? const Color(0xFF16A34A)
                            : EfuridePalette.ink),
                  ),
                ),
                IconButton(
                  visualDensity: VisualDensity.compact,
                  onPressed: _edit,
                  icon: const Icon(Icons.edit_outlined,
                      size: 20, color: EfuridePalette.inkMuted),
                ),
              ],
            ),
            const SizedBox(height: 6),
            Padding(
              padding: const EdgeInsets.only(right: 8),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: LinearProgressIndicator(
                  value: pct,
                  minHeight: 10,
                  backgroundColor: const Color(0xFFF1EBDD),
                  color: done
                      ? const Color(0xFF16A34A)
                      : EfuridePalette.accent,
                ),
              ),
            ),
            const SizedBox(height: 6),
            Text(
              tr('{0} of {1}', [
                CountryConfig.money(widget.earnedToday),
                CountryConfig.money(_goal),
              ]),
              style: const TextStyle(
                  fontSize: 13.5, color: EfuridePalette.inkMuted),
            ),
          ],
        ),
      ),
    );
  }
}
