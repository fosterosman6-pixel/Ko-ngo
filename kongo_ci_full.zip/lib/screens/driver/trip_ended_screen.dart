// lib/screens/driver/trip_ended_screen.dart

import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:efuride_app/config/country_config.dart';
import 'package:efuride_app/config/app_images.dart';
import 'package:efuride_app/widgets/app_image.dart';
import 'package:efuride_app/utils/app_error.dart';
import 'package:efuride_app/utils/error_ui.dart';
import 'package:efuride_app/l10n/app_strings.dart';

class _Palette {
  static const cream = Color(0xFFFAF6EE);
  static const ink = Color(0xFF1A1A1A);
  static const inkMuted = Color(0xFF575047);
  static const accent = Color(0xFFF2B705);
  static const accentInk = Color(0xFF0B1220);
  static const divider = Color(0xFFE8E2D5);
  static const blue = Color(0xFF1E88E5);
}

class TripEndedScreen extends StatefulWidget {
  final double finalFare;
  final String tripDistance;
  final String? rideId;
  final String? customerId;
  final String? customerName;

  const TripEndedScreen({
    super.key,
    required this.finalFare,
    required this.tripDistance,
    this.rideId,
    this.customerId,
    this.customerName,
  });

  @override
  State<TripEndedScreen> createState() => _TripEndedScreenState();
}

class _TripEndedScreenState extends State<TripEndedScreen> {
  int _rating = 0;
  bool _submitting = false;
  bool _submitted = false;

  /// How the customer paid ('cash' | 'wallet' | 'card'), from the ride.
  String _payMethod = 'cash';
  String _payStatus = '';

  @override
  void initState() {
    super.initState();
    _loadPayment();
  }

  Future<void> _loadPayment() async {
    if (widget.rideId == null) return;
    try {
      final r = await Supabase.instance.client
          .from('rides')
          .select('payment_method, payment_status')
          .eq('id', widget.rideId!)
          .maybeSingle();
      if (!mounted || r == null) return;
      setState(() {
        _payMethod = (r['payment_method'] ?? 'cash').toString();
        _payStatus = (r['payment_status'] ?? '').toString();
      });
    } catch (_) {}
  }

  Widget _paymentBanner() {
    final cash = _payMethod == 'cash';
    final paid = _payStatus == 'paid';
    final (IconData icon, String text, Color bg, Color fg) = cash
        ? (
            Icons.payments_outlined,
            tr('Collect {0} cash from the customer',
                [CountryConfig.money(widget.finalFare)]),
            const Color(0xFFFEF3C7),
            const Color(0xFF92400E),
          )
        : _payMethod == 'wallet' && paid
            ? (
                Icons.account_balance_wallet_outlined,
                tr('Paid from the customer\'s wallet. No cash to collect.'),
                const Color(0xFFDCFCE7),
                const Color(0xFF166534),
              )
            : (
                Icons.credit_card,
                tr('Paid in the app. No cash to collect.'),
                const Color(0xFFDCFCE7),
                const Color(0xFF166534),
              );
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(14),
      ),
      child: Row(
        children: [
          Icon(icon, color: fg, size: 26),
          const SizedBox(width: 12),
          Expanded(
            child: Text(text,
                style: TextStyle(
                    fontSize: 16, fontWeight: FontWeight.w800, color: fg)),
          ),
        ],
      ),
    );
  }

  Future<void> _submitRating() async {
    if (_rating == 0) {
      ErrorUI.showSnack(
        context,
        AppError(
          title: tr('Pick a rating'),
          message: tr('Tap a star to rate your customer.'),
          icon: Icons.star_border,
        ),
      );
      return;
    }

    setState(() => _submitting = true);
    try {
      final userId = Supabase.instance.client.auth.currentUser?.id;
      if (userId == null) throw Exception('Not signed in');

      if (widget.rideId != null) {
        await Supabase.instance.client.from('rides').update({
          'driver_rating': _rating,
          'driver_rated_at': DateTime.now().toUtc().toIso8601String(),
        }).eq('id', widget.rideId!);
      }

      // The customer's average is worked out on the server.

      if (!mounted) return;
      setState(() {
        _submitting = false;
        _submitted = true;
      });

      ErrorUI.showSnack(
        context,
        AppError(
          title: tr('Thanks for rating!'),
          message: tr('Your feedback helps improve ko!ngo.'),
          icon: Icons.check_circle_outline,
        ),
      );
    } catch (e) {
      if (!mounted) return;
      setState(() => _submitting = false);
      ErrorUI.showSnack(
        context,
        AppError.from(e, onRetry: _submitRating),
      );
    }
  }

  void _goHome() {
    Navigator.pushNamedAndRemoveUntil(
      context,
      '/driver',
      (r) => false,
    );
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      child: Scaffold(
        backgroundColor: _Palette.cream,
        appBar: AppBar(
          backgroundColor: _Palette.cream,
          elevation: 0,
          automaticallyImplyLeading: false,
          title: Text(
            tr('Trip completed'),
            style: TextStyle(
              color: _Palette.ink,
              fontWeight: FontWeight.bold,
              fontSize: 18,
            ),
          ),
        ),
        body: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const SizedBox(height: 12),
                Center(
                  child: AppImage(
                    AppImages.coinsBlue,
                    size: 80,
                    fallbackIcon: Icons.check_circle,
                  ),
                ),
                const SizedBox(height: 16),
                Text(
                  tr('Trip completed!'),
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                    color: _Palette.ink,
                  ),
                ),
                const SizedBox(height: 6),
                const SizedBox(height: 10),
                _paymentBanner(),
                const SizedBox(height: 24),

                Container(
                  padding: const EdgeInsets.all(18),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: _Palette.divider),
                  ),
                  child: Column(
                    children: [
                      _summaryRow(
                        'Fare earned',
                        CountryConfig.money(widget.finalFare),
                        bold: true,
                      ),
                      const SizedBox(height: 10),
                      _summaryRow('Distance', widget.tripDistance),
                      if (widget.rideId != null) ...[
                        const SizedBox(height: 10),
                        _summaryRow('Trip ID',
                            '#${widget.rideId!.substring(0, 8)}'),
                      ],
                    ],
                  ),
                ),

                const SizedBox(height: 28),

                if (!_submitted) ...[
                  Text(
                    widget.customerName != null &&
                            widget.customerName!.isNotEmpty
                        ? 'Rate ${widget.customerName}'
                        : 'Rate your customer',
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.bold,
                      color: _Palette.ink,
                    ),
                  ),
                  const SizedBox(height: 12),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: List.generate(5, (i) {
                      final filled = i < _rating;
                      return IconButton(
                        iconSize: 40,
                        onPressed: _submitting
                            ? null
                            : () => setState(() => _rating = i + 1),
                        icon: Icon(
                          filled ? Icons.star : Icons.star_border,
                          color: _Palette.accent,
                        ),
                      );
                    }),
                  ),
                  const SizedBox(height: 12),
                  ElevatedButton(
                    onPressed: _submitting ? null : _submitRating,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: _Palette.accent,
                      foregroundColor: _Palette.accentInk,
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    child: _submitting
                        ? const SizedBox(
                            width: 18,
                            height: 18,
                            child: CircularProgressIndicator(
                              strokeWidth: 2,
                              color: _Palette.accentInk,
                            ),
                          )
                        : Text(
                            tr('Submit rating'),
                            style: TextStyle(
                              fontSize: 15,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                  ),
                  const SizedBox(height: 8),
                  TextButton(
                    onPressed: _submitting
                        ? null
                        : () => setState(() => _submitted = true),
                    child: Text(
                      tr('Skip'),
                      style: TextStyle(color: _Palette.inkMuted),
                    ),
                  ),
                ] else ...[
                  Text(
                    tr('Thanks — your rating was recorded.'),
                    textAlign: TextAlign.center,
                    style:
                        TextStyle(fontSize: 14, color: _Palette.inkMuted),
                  ),
                ],

                const Spacer(),

                ElevatedButton(
                  onPressed: _goHome,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFFF2B705),
                    foregroundColor: const Color(0xFF0B1220),
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  child: Text(
                    tr('Back to home'),
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _summaryRow(String label, String value, {bool bold = false}) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          label,
          style: const TextStyle(fontSize: 14, color: _Palette.inkMuted),
        ),
        Text(
          value,
          style: TextStyle(
            fontSize: bold ? 18 : 13,
            fontWeight: bold ? FontWeight.bold : FontWeight.w500,
            color: _Palette.ink,
          ),
        ),
      ],
    );
  }
}
