﻿// lib/screens/driver/driver_earnings_screen.dart
//
// Driver earnings. Period filter (Today / Week / Month / All),
// total earnings card, breakdown stats, and a full trip list.
//
// i18n-clean · currency-clean · real data.

import 'dart:async';
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:efuride_app/config/efuride_palette.dart';
import 'package:efuride_app/config/country_config.dart';
import 'package:efuride_app/widgets/incentives_card.dart';
import 'package:efuride_app/l10n/app_strings.dart';
import 'package:efuride_app/utils/app_error.dart';
import 'package:efuride_app/utils/error_ui.dart';
import 'package:efuride_app/services/pricing_service.dart';
import 'package:efuride_app/widgets/k_icon.dart';

enum _Period { today, week, month, all }

class DriverEarningsScreen extends StatefulWidget {
  const DriverEarningsScreen({super.key});

  @override
  State<DriverEarningsScreen> createState() =>
      _DriverEarningsScreenState();
}

class _DriverEarningsScreenState extends State<DriverEarningsScreen>
    with WidgetsBindingObserver {
  String _t(String key) => S.of(context).t(key);
  String _tf(String key, Map<String, Object> args) =>
      S.of(context).tf(key, args);

  _Period _period = _Period.today;
  List<_Trip> _trips = [];
  bool _loading = true;
  AppError? _error;

  @override
  void initState() {
    super.initState();
    PricingService.changes.addListener(_onPricesChanged);
    WidgetsBinding.instance.addObserver(this);
    _load();
  }

  void _onPricesChanged() {
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    PricingService.changes.removeListener(_onPricesChanged);
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) _load();
  }

  // ═══════════════════════════════════════════════════════════
  // LOAD
  // ═══════════════════════════════════════════════════════════
  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });

    try {
      final userId = Supabase.instance.client.auth.currentUser?.id;
      if (userId == null) {
        setState(() {
          _loading = false;
          _trips = [];
        });
        return;
      }

      DateTime? since;
      switch (_period) {
        case _Period.today:
          final now = DateTime.now();
          since = DateTime(now.year, now.month, now.day);
          break;
        case _Period.week:
          final now = DateTime.now();
          since = DateTime(now.year, now.month, now.day)
              .subtract(Duration(days: now.weekday - 1));
          break;
        case _Period.month:
          final now = DateTime.now();
          since = DateTime(now.year, now.month, 1);
          break;
        case _Period.all:
          since = null;
          break;
      }

      var query = Supabase.instance.client
          .from('rides')
          .select(
            'id, fare, distance_km, completed_at, created_at, '
            'pickup_address, dropoff_address, service_type, '
            'customer_id, vehicle_type',
          )
          .eq('driver_id', userId)
          .eq('status', 'completed');
        
        

      if (since != null) {
        query = query.gte('completed_at', since.toUtc().toIso8601String());
      }

      final orderedQuery = query
        .order('completed_at', ascending: false)
        .limit(200);
      final rows = await orderedQuery;

      final trips = <_Trip>[];
      for (final r in rows as List) {
        final m = Map<String, dynamic>.from(r);
        final raw = (m['completed_at'] ?? m['created_at'])?.toString();
        final when = raw == null
            ? DateTime.now()
            : (DateTime.tryParse(raw)?.toLocal() ?? DateTime.now());

        trips.add(_Trip(
          id: (m['id'] ?? '').toString(),
          fare: (m['fare'] as num?)?.toDouble() ?? 0,
          distanceKm: (m['distance_km'] as num?)?.toDouble() ?? 0,
          when: when,
          pickup: (m['pickup_address'] ?? '').toString(),
          dropoff: (m['dropoff_address'] ?? '').toString(),
          serviceType: (m['service_type'] ?? 'Ride').toString(),
        ));
      }

      if (!mounted) return;
      setState(() {
        _trips = trips;
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _error = AppError.from(e, onRetry: _load);
      });
    }
  }

  // ═══════════════════════════════════════════════════════════
  // DERIVED
  // ═══════════════════════════════════════════════════════════
  /// Trip prices customers paid.
  double get _totalFares =>
      _trips.fold<double>(0, (sum, t) => sum + t.fare);

  /// ko!ngo's share for this country (admin sets it in Pricing).
  double get _commissionPct => PricingService.last.driverCommissionPct;

  /// What the driver keeps: the same sum the wallet gets.
  double get _totalEarnings => _totalFares * (1 - _commissionPct / 100);

  int get _tripCount => _trips.length;

  double get _avgPerTrip =>
      _trips.isEmpty ? 0 : _totalEarnings / _trips.length;

  double get _totalDistanceKm =>
      _trips.fold<double>(0, (sum, t) => sum + t.distanceKm);

  // ═══════════════════════════════════════════════════════════
  // BUILD
  // ═══════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        _header(),
        Expanded(
          child: _loading
              ? const Center(
                  child: CircularProgressIndicator(
                      color: EfuridePalette.blueDeep))
              : _error != null
                  ? ErrorUI.inline(_error!)
                  : RefreshIndicator(
                      color: EfuridePalette.blueDeep,
                      onRefresh: _load,
                      child: ListView(
                        padding:
                            const EdgeInsets.fromLTRB(16, 16, 16, 24),
                        physics: const AlwaysScrollableScrollPhysics(),
                        children: [
                          const IncentivesCard(),
                          _periodChips(),
                          const SizedBox(height: 16),
                          _earningsCard(),
                          const SizedBox(height: 12),
                          _walletButton(),
                          const SizedBox(height: 14),
                          _statRow(),
                          const SizedBox(height: 20),
                          _tripsSection(),
                          const SizedBox(height: 24),
                        ],
                      ),
                    ),
        ),
      ],
    );
  }

  // ═══════════════════════════════════════════════════════════
  // HEADER
  // ═══════════════════════════════════════════════════════════
  /// Plain title row with a shortcut to the wallet (payouts).
  Widget _header() {
    return Container(
      color: EfuridePalette.cream,
      child: SafeArea(
        bottom: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 14, 8, 6),
          child: Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(_t('earnings'),
                        style: const TextStyle(
                          color: EfuridePalette.ink,
                          fontSize: 24,
                          fontWeight: FontWeight.w800,
                        )),
                    const SizedBox(height: 2),
                    Text(_t('earnings_driver_sub'),
                        style: const TextStyle(
                            color: EfuridePalette.inkMuted, fontSize: 15)),
                  ],
                ),
              ),
              IconButton(
                tooltip: tr('Refresh'),
                onPressed: _load,
                icon: const Icon(Icons.refresh, color: EfuridePalette.ink),
              ),
            ],
          ),
        ),
      ),
    );
  }

  /// Wallet & payouts — the driver's way to request a payout.
  Widget _walletButton() {
    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(14),
      child: InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: () => Navigator.pushNamed(context, '/wallet'),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: EfuridePalette.divider),
          ),
          child: Row(
            children: [
              const KIcon(Icons.account_balance_wallet_outlined,
                  color: EfuridePalette.ink),
              const SizedBox(width: 12),
              Expanded(
                child: Text(tr('Wallet & payouts'),
                    style: const TextStyle(
                        fontSize: 16, fontWeight: FontWeight.w800)),
              ),
              Text(tr('Request payout'),
                  style: const TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w700,
                      color: EfuridePalette.blueDeep)),
              const Icon(Icons.chevron_right, color: EfuridePalette.inkMuted),
            ],
          ),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // PERIOD CHIPS
  // ═══════════════════════════════════════════════════════════
  Widget _periodChips() {
    const items = [
      (_Period.today, 'period_today'),
      (_Period.week, 'period_week'),
      (_Period.month, 'period_month'),
      (_Period.all, 'period_all'),
    ];
    return SizedBox(
      height: 38,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        itemCount: items.length,
        separatorBuilder: (_, __) => const SizedBox(width: 8),
        itemBuilder: (_, i) {
          final (period, labelKey) = items[i];
          final active = _period == period;
          return GestureDetector(
            onTap: () {
              if (_period == period) return;
              setState(() => _period = period);
              _load();
            },
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: active
                    ? EfuridePalette.accent
                    : Colors.white,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(
                  color: active
                      ? EfuridePalette.accent
                      : EfuridePalette.divider,
                ),
              ),
              child: Text(
                _t(labelKey),
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w800,
                  color: EfuridePalette.ink,
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // EARNINGS CARD
  // ═══════════════════════════════════════════════════════════
  Widget _earningsCard() {
    final t = S.of(context);
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: EfuridePalette.accent,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: const KIcon(Icons.payments_outlined,
                    color: EfuridePalette.ink, size: 20),
              ),
              const SizedBox(width: 10),
              Text(
                _periodLabel(),
                style: const TextStyle(
                  color: EfuridePalette.ink,
                  fontSize: 14.5,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          Text(
            CountryConfig.money(_totalEarnings),
            style: const TextStyle(
              color: EfuridePalette.ink,
              fontSize: 34,
              fontWeight: FontWeight.w900,
              letterSpacing: -0.6,
              height: 1.0,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            tr('Trip prices {0} · ko!ngo fee {1}%', [
              CountryConfig.money(_totalFares),
              _commissionPct.toStringAsFixed(_commissionPct % 1 == 0 ? 0 : 1),
            ]),
            style: const TextStyle(
              color: EfuridePalette.ink,
              fontSize: 13.5,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 4),
          Row(
            children: [
              Text(
                '$_tripCount ${_t('trips').toLowerCase()}',
                style: const TextStyle(
                  color: EfuridePalette.ink,
                  fontSize: 13.5,
                  fontWeight: FontWeight.w600,
                ),
              ),
              if (_tripCount > 0) ...[
                const SizedBox(width: 6),
                Text('·',
                    style: TextStyle(
                        color: EfuridePalette.ink)),
                const SizedBox(width: 6),
                Text(
                  tr('{0} km', [_totalDistanceKm.toStringAsFixed(1)]),
                  style: const TextStyle(
                    color: EfuridePalette.ink,
                    fontSize: 13.5,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ],
          ),
        ],
      ),
    );
  }

  String _periodLabel() {
    switch (_period) {
      case _Period.today: return _t('earnings_today');
      case _Period.week:  return _t('earnings_this_week');
      case _Period.month: return _t('earnings_this_month');
      case _Period.all:   return _t('earnings_all_time');
    }
  }

  // ═══════════════════════════════════════════════════════════
  // STAT ROW
  // ═══════════════════════════════════════════════════════════
  Widget _statRow() {
    final t = S.of(context);
    return Row(
      children: [
        _statTile(
          icon: Icons.local_taxi_outlined,
          label: t.t('trips'),
          value: '$_tripCount',
        ),
        const SizedBox(width: 10),
        _statTile(
          icon: Icons.trending_up,
          label: t.t('avg_per_trip'),
          value: CountryConfig.money(_avgPerTrip),
        ),
        const SizedBox(width: 10),
        _statTile(
          icon: Icons.straighten,
          label: t.t('total_distance'),
          value: '${_totalDistanceKm.toStringAsFixed(0)} km',
        ),
      ],
    );
  }

  Widget _statTile({
    required IconData icon,
    required String label,
    required String value,
  }) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: EfuridePalette.divider),
        ),
        child: Column(
          children: [
            Icon(icon, size: 18, color: EfuridePalette.blueDeep),
            const SizedBox(height: 8),
            Text(
              value,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                fontSize: 14.5,
                fontWeight: FontWeight.w900,
                color: EfuridePalette.ink,
              ),
            ),
            const SizedBox(height: 2),
            Text(
              label,
              textAlign: TextAlign.center,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                fontSize: 12.5,
                color: EfuridePalette.inkMuted,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // TRIPS SECTION
  // ═══════════════════════════════════════════════════════════
  Widget _tripsSection() {
    if (_trips.isEmpty) {
      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.only(left: 4, bottom: 10),
            child: Text(_t('recent_trips'),
                style: const TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w800,
                    color: EfuridePalette.ink)),
          ),
          Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: EfuridePalette.divider),
            ),
            child: Column(
              children: [
                KIcon(Icons.local_taxi_outlined,
                    size: 40, color: Colors.grey.shade400),
                const SizedBox(height: 10),
                Text(
                  _t('no_trips_period'),
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w700,
                    color: EfuridePalette.inkMuted,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  _t('no_trips_period_hint'),
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                      fontSize: 13, color: EfuridePalette.inkMuted),
                ),
              ],
            ),
          ),
        ],
      );
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(left: 4, bottom: 10),
          child: Text(_t('recent_trips'),
              style: const TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w800,
                  color: EfuridePalette.ink)),
        ),
        Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: EfuridePalette.divider),
          ),
          child: Column(
            children: List.generate(_trips.length, (i) {
              final trip = _trips[i];
              return Column(
                children: [
                  _tripRow(trip),
                  if (i < _trips.length - 1)
                    const Divider(
                      height: 1,
                      indent: 14,
                      endIndent: 14,
                      color: EfuridePalette.divider,
                    ),
                ],
              );
            }),
          ),
        ),
      ],
    );
  }

  Widget _tripRow(_Trip t) {
    final timeLabel = _timeLabel(t.when);
    final isDelivery = t.serviceType.toLowerCase() == 'delivery';

    return Padding(
      padding: const EdgeInsets.all(14),
      child: Row(
        children: [
          Container(
            width: 42,
            height: 42,
            decoration: BoxDecoration(
              color: EfuridePalette.blueDeep.withValues(alpha: 0.10),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(
              isDelivery
                  ? Icons.inventory_2_outlined
                  : Icons.local_taxi_outlined,
              size: 20,
              color: EfuridePalette.blueDeep,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  _shortAddr(t.dropoff),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontSize: 14.5,
                    fontWeight: FontWeight.w800,
                    color: EfuridePalette.ink,
                  ),
                ),
                const SizedBox(height: 3),
                Row(
                  children: [
                    const KIcon(Icons.access_time,
                        size: 11, color: EfuridePalette.inkMuted),
                    const SizedBox(width: 4),
                    Text(
                      timeLabel,
                      style: const TextStyle(
                        fontSize: 13,
                        color: EfuridePalette.inkMuted,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    if (t.distanceKm > 0) ...[
                      const SizedBox(width: 10),
                      const Icon(Icons.straighten,
                          size: 11, color: EfuridePalette.inkMuted),
                      const SizedBox(width: 4),
                      Text(
                        tr('{0} km', [t.distanceKm.toStringAsFixed(1)]),
                        style: const TextStyle(
                          fontSize: 13,
                          color: EfuridePalette.inkMuted,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(width: 8),
          Text(
            CountryConfig.money(t.fare),
            style: const TextStyle(
              fontSize: 14.5,
              fontWeight: FontWeight.w900,
              color: EfuridePalette.online,
            ),
          ),
        ],
      ),
    );
  }

  String _shortAddr(String addr) {
    if (addr.isEmpty) return '—';
    final first = addr.split(',').first.trim();
    return first.isEmpty ? addr : first;
  }

  String _timeLabel(DateTime when) {
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final day = DateTime(when.year, when.month, when.day);
    final diffDays = today.difference(day).inDays;

    final hhmm =
        '${when.hour.toString().padLeft(2, '0')}:${when.minute.toString().padLeft(2, '0')}';

    if (diffDays == 0) return '${_t('today')} · $hhmm';
    if (diffDays == 1) return '${_t('yesterday')} · $hhmm';
    if (diffDays < 7) {
      final d = diffDays;
      return '$d${_t('days_short')} · $hhmm';
    }
    return '${when.day}/${when.month} · $hhmm';
  }
}

// ══════════════════════════════════════════════════════════════
// MODEL
// ══════════════════════════════════════════════════════════════
class _Trip {
  final String id;
  final double fare;
  final double distanceKm;
  final DateTime when;
  final String pickup;
  final String dropoff;
  final String serviceType;

  const _Trip({
    required this.id,
    required this.fare,
    required this.distanceKm,
    required this.when,
    required this.pickup,
    required this.dropoff,
    required this.serviceType,
  });
}
