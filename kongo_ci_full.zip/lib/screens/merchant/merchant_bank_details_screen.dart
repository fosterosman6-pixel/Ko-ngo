// lib/screens/merchant/merchant_bank_details_screen.dart
//
// Merchant bank details. Collects bank name, account holder, account
// number, branch code, and account type. Status is reviewed by admin.
//
// i18n-clean · uses MerchantService + Supabase directly.

import 'package:flutter/material.dart';
import 'package:efuride_app/widgets/merchant_top_bar.dart';
import 'package:flutter/services.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:efuride_app/config/efuride_palette.dart';
import 'package:efuride_app/l10n/app_strings.dart';
import 'package:efuride_app/services/merchant_service.dart';
import 'package:efuride_app/utils/app_error.dart';
import 'package:efuride_app/utils/error_ui.dart';

class MerchantBankDetailsScreen extends StatefulWidget {
  const MerchantBankDetailsScreen({super.key});

  @override
  State<MerchantBankDetailsScreen> createState() =>
      _MerchantBankDetailsScreenState();
}

class _MerchantBankDetailsScreenState
    extends State<MerchantBankDetailsScreen> {
  String _t(String key) => S.of(context).t(key);

  final _bankCtrl = TextEditingController();
  final _holderCtrl = TextEditingController();
  final _accountCtrl = TextEditingController();
  final _branchCtrl = TextEditingController();

  String _accountType = 'cheque';
  String _status = 'new'; // 'new' | 'pending' | 'verified' | 'rejected'

  bool _loading = true;
  bool _saving = false;
  String? _rejectionReason;
  String? _existingId;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _bankCtrl.dispose();
    _holderCtrl.dispose();
    _accountCtrl.dispose();
    _branchCtrl.dispose();
    super.dispose();
  }

  // ═══════════════════════════════════════════════════════════
  // LOAD
  // ═══════════════════════════════════════════════════════════
  Future<void> _load() async {
    setState(() => _loading = true);
    try {
      final pid = await MerchantService.instance.getPartnerId();
      if (pid == null) {
        setState(() => _loading = false);
        return;
      }

      final row = await Supabase.instance.client
          .from('merchant_bank_details')
          .select()
          .eq('partner_id', pid)
          .maybeSingle();

      if (!mounted) return;
      if (row != null) {
        setState(() {
          _existingId = row['id']?.toString();
          _bankCtrl.text = (row['bank_name'] ?? '').toString();
          _holderCtrl.text = (row['account_holder'] ?? '').toString();
          _accountCtrl.text = (row['account_number'] ?? '').toString();
          _branchCtrl.text = (row['branch_code'] ?? '').toString();
          _accountType = (row['account_type'] ?? 'cheque').toString();
          _status = (row['status'] ?? 'pending').toString();
          _rejectionReason = row['failure_reason']?.toString();
          _loading = false;
        });
      } else {
        setState(() {
          _status = 'new';
          _loading = false;
        });
      }
    } catch (e) {
      if (!mounted) return;
      setState(() => _loading = false);
      ErrorUI.showSnack(context, AppError.from(e, onRetry: _load));
    }
  }

  // ═══════════════════════════════════════════════════════════
  // SAVE
  // ═══════════════════════════════════════════════════════════
  bool get _isFormValid =>
      _bankCtrl.text.trim().isNotEmpty &&
      _holderCtrl.text.trim().isNotEmpty &&
      _accountCtrl.text.trim().length >= 6;

  Future<void> _save({required bool submitForReview}) async {
    if (!_isFormValid || _saving) return;

    setState(() => _saving = true);
    try {
      final pid = await MerchantService.instance.getPartnerId();
      if (pid == null) throw StateError('No partner account');

      final payload = {
        'partner_id': pid,
        'bank_name': _bankCtrl.text.trim(),
        'account_holder': _holderCtrl.text.trim(),
        'account_number': _accountCtrl.text.trim(),
        'branch_code': _branchCtrl.text.trim().isEmpty
            ? null
            : _branchCtrl.text.trim(),
        'account_type': _accountType,
        'status': submitForReview ? 'pending' : 'draft',
        'updated_at': DateTime.now().toUtc().toIso8601String(),
      };

      if (_existingId != null) {
        await Supabase.instance.client
            .from('merchant_bank_details')
            .update(payload)
            .eq('id', _existingId!);
      } else {
        final inserted = await Supabase.instance.client
            .from('merchant_bank_details')
            .insert(payload)
            .select('id')
            .single();
        _existingId = inserted['id']?.toString();
      }

      if (!mounted) return;
      setState(() {
        _saving = false;
        _status = submitForReview ? 'pending' : 'draft';
        _rejectionReason = null;
      });

      ErrorUI.showSnack(
        context,
        AppError(
          title: submitForReview
              ? _t('bank_under_review')
              : _t('bank_saved'),
          message: submitForReview
              ? _t('bank_edit_later')
              : _t('save_draft_hint'),
          icon: Icons.check_circle_outline,
        ),
      );
    } catch (e) {
      if (!mounted) return;
      setState(() => _saving = false);
      ErrorUI.showSnack(
        context,
        AppError.from(e, onRetry: () => _save(submitForReview: submitForReview)),
      );
    }
  }

  // ═══════════════════════════════════════════════════════════
  // BUILD
  // ═══════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: EfuridePalette.cream,
      body: Column(
        children: [
          _header(),
          Expanded(
            child: _loading
                ? const Center(
                    child: CircularProgressIndicator(
                        color: EfuridePalette.merchantAccent))
                : ListView(
                    padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
                    children: [
                      if (_status != 'new' && _status != 'draft')
                        _statusBanner(),
                      _formCard(),
                      const SizedBox(height: 14),
                      _noticeCard(),
                      const SizedBox(height: 20),
                    ],
                  ),
          ),
          if (!_loading) _stickyBar(),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // HEADER
  // ═══════════════════════════════════════════════════════════
  Widget _header() {
    final t = S.of(context);
    return MerchantTopBar(
      title: t.t('bank_details'),
      subtitle: t.t('bank_merchant_sub'),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // STATUS BANNER
  // ═══════════════════════════════════════════════════════════
  Widget _statusBanner() {
    final (color, icon, title, message) = _bannerContent();

    return Container(
      margin: const EdgeInsets.only(bottom: 14),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.10),
        borderRadius: BorderRadius.circular(14),
        border:
            Border.all(color: color.withValues(alpha: 0.4), width: 1.4),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: color,
              borderRadius: BorderRadius.circular(8),
            ),
            child: Icon(icon, color: Colors.white, size: 16),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title,
                    style: TextStyle(
                      fontSize: 14.5,
                      fontWeight: FontWeight.w900,
                      color: color,
                    )),
                const SizedBox(height: 2),
                Text(message,
                    style: const TextStyle(
                      fontSize: 13.5,
                      color: EfuridePalette.inkMuted,
                      height: 1.4,
                    )),
              ],
            ),
          ),
        ],
      ),
    );
  }

  (Color, IconData, String, String) _bannerContent() {
    switch (_status) {
      case 'verified':
        return (
          EfuridePalette.online,
          Icons.verified_outlined,
          _t('bank_verified'),
          _t('bank_verified_hint'),
        );
      case 'pending':
        return (
          EfuridePalette.merchantAccent,
          Icons.hourglass_top,
          _t('bank_review'),
          _t('bank_review_hint'),
        );
      case 'rejected':
        return (
          EfuridePalette.dropoff,
          Icons.error_outline,
          _t('bank_rejected'),
          _rejectionReason?.isNotEmpty == true
              ? _rejectionReason!
              : _t('bank_rejected_hint'),
        );
      case 'draft':
        return (
          EfuridePalette.blueDeep,
          Icons.edit_outlined,
          _t('bank_draft'),
          _t('bank_draft_hint'),
        );
      default:
        return (
          EfuridePalette.inkMuted,
          Icons.info_outline,
          _t('bank_new'),
          _t('bank_new_hint'),
        );
    }
  }

  // ═══════════════════════════════════════════════════════════
  // FORM
  // ═══════════════════════════════════════════════════════════
  Widget _formCard() {
    final t = S.of(context);
    final readOnly = _status == 'pending' || _status == 'verified';

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: EfuridePalette.divider),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _label(t.t('bank_name')),
          const SizedBox(height: 6),
          _textField(
            _bankCtrl,
            hint: t.t('bank_name_hint'),
            readOnly: readOnly,
            capitalization: TextCapitalization.words,
          ),
          const SizedBox(height: 14),

          _label(t.t('account_holder')),
          const SizedBox(height: 6),
          _textField(
            _holderCtrl,
            hint: t.t('account_holder_hint'),
            readOnly: readOnly,
            capitalization: TextCapitalization.words,
          ),
          const SizedBox(height: 14),

          _label(t.t('account_number')),
          const SizedBox(height: 6),
          _textField(
            _accountCtrl,
            hint: t.t('account_number_hint'),
            readOnly: readOnly,
            keyboard: TextInputType.number,
            inputFormatters: [
              FilteringTextInputFormatter.digitsOnly,
            ],
          ),
          const SizedBox(height: 14),

          _label(t.t('branch_code')),
          const SizedBox(height: 6),
          _textField(
            _branchCtrl,
            hint: t.t('branch_code_hint'),
            readOnly: readOnly,
            keyboard: TextInputType.text,
          ),
          const SizedBox(height: 16),

          _label(t.t('account_type')),
          const SizedBox(height: 8),
          _accountTypeRow(readOnly),
        ],
      ),
    );
  }

  Widget _accountTypeRow(bool readOnly) {
    final t = S.of(context);
    const types = [
      ('cheque', 'type_cheque'),
      ('savings', 'type_savings'),
      ('transmission', 'type_transmission'),
    ];

    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: types.map((entry) {
        final (key, labelKey) = entry;
        final active = _accountType == key;
        return GestureDetector(
          onTap: readOnly
              ? null
              : () => setState(() => _accountType = key),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 180),
            padding: const EdgeInsets.symmetric(
                horizontal: 16, vertical: 10),
            decoration: BoxDecoration(
              color: active
                  ? EfuridePalette.merchantAccent
                      .withValues(alpha: 0.12)
                  : Colors.transparent,
              borderRadius: BorderRadius.circular(10),
              border: Border.all(
                color: active
                    ? EfuridePalette.merchantAccent
                    : EfuridePalette.divider,
                width: active ? 1.4 : 1,
              ),
            ),
            child: Text(
              t.t(labelKey),
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w800,
                color: active
                    ? EfuridePalette.merchantAccent
                    : EfuridePalette.ink,
              ),
            ),
          ),
        );
      }).toList(),
    );
  }

  Widget _label(String s) => Text(
        s,
        style: const TextStyle(
          fontSize: 13.5,
          fontWeight: FontWeight.w800,
          color: EfuridePalette.ink,
          letterSpacing: 0.2,
        ),
      );

  Widget _textField(
    TextEditingController ctrl, {
    required String hint,
    bool readOnly = false,
    TextInputType? keyboard,
    List<TextInputFormatter>? inputFormatters,
    TextCapitalization capitalization = TextCapitalization.none,
  }) {
    return TextField(
      controller: ctrl,
      readOnly: readOnly,
      keyboardType: keyboard,
      inputFormatters: inputFormatters,
      textCapitalization: capitalization,
      onChanged: (_) => setState(() {}),
      style: TextStyle(
        fontSize: 14,
        color: readOnly
            ? EfuridePalette.inkMuted
            : EfuridePalette.ink,
        fontWeight: FontWeight.w600,
      ),
      decoration: InputDecoration(
        hintText: hint,
        hintStyle: const TextStyle(
            fontSize: 14, color: EfuridePalette.inkMuted),
        filled: true,
        fillColor: readOnly
            ? EfuridePalette.divider.withValues(alpha: 0.4)
            : EfuridePalette.cream,
        contentPadding: const EdgeInsets.symmetric(
            horizontal: 14, vertical: 14),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide.none,
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // NOTICE
  // ═══════════════════════════════════════════════════════════
  Widget _noticeCard() {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: EfuridePalette.blueDeep.withValues(alpha: 0.06),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
            color: EfuridePalette.blueDeep.withValues(alpha: 0.3)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Icon(Icons.info_outline,
              size: 16, color: EfuridePalette.blueDeep),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              _t('payout_notice'),
              style: const TextStyle(
                fontSize: 13,
                color: EfuridePalette.ink,
                height: 1.5,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // STICKY BAR
  // ═══════════════════════════════════════════════════════════
  Widget _stickyBar() {
    final readOnly = _status == 'pending' || _status == 'verified';
    final canSubmit = _isFormValid && !readOnly && !_saving;

    return Container(
      padding: EdgeInsets.fromLTRB(
        16,
        12,
        16,
        12 + MediaQuery.of(context).padding.bottom,
      ),
      decoration: BoxDecoration(
        color: Colors.white,
        border:
            const Border(top: BorderSide(color: EfuridePalette.divider)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.05),
            blurRadius: 10,
            offset: const Offset(0, -3),
          ),
        ],
      ),
      child: Row(
        children: [
          if (!readOnly)
            Expanded(
              child: OutlinedButton(
                onPressed: _saving || !_isFormValid
                    ? null
                    : () => _save(submitForReview: false),
                style: OutlinedButton.styleFrom(
                  minimumSize: const Size(0, 54),
                  side: const BorderSide(color: EfuridePalette.divider),
                  foregroundColor: EfuridePalette.ink,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(14)),
                ),
                child: Text(_t('save_draft'),
                    style: const TextStyle(
                        fontSize: 14, fontWeight: FontWeight.w800)),
              ),
            ),
          if (!readOnly) const SizedBox(width: 10),
          Expanded(
            flex: readOnly ? 1 : 2,
            child: ElevatedButton(
              onPressed: canSubmit
                  ? () => _save(submitForReview: true)
                  : null,
              style: ElevatedButton.styleFrom(
                backgroundColor: EfuridePalette.merchantAccent,
                foregroundColor: Colors.white,
                minimumSize: const Size(0, 54),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14)),
                elevation: 0,
              ),
              child: _saving
                  ? const SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(
                          strokeWidth: 2, color: Colors.white),
                    )
                  : Text(
                      readOnly
                          ? _t('submitted')
                          : _t('submit_review'),
                      style: const TextStyle(
                          fontSize: 14.5,
                          fontWeight: FontWeight.w900),
                    ),
            ),
          ),
        ],
      ),
    );
  }
}
