// lib/screens/merchant/merchant_stats_screen.dart
//
// Merchant analytics. Revenue trend (14 days), top products, order
// heatmap (by hour), and headline KPIs.
//
// i18n-clean · currency-clean · real data.

import 'dart:async';
import 'package:flutter/material.dart';
import 'package:efuride_app/widgets/merchant_top_bar.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:efuride_app/config/efuride_palette.dart';
import 'package:efuride_app/config/country_config.dart';
import 'package:efuride_app/l10n/app_strings.dart';
import 'package:efuride_app/services/merchant_service.dart';
import 'package:efuride_app/utils/app_error.dart';
import 'package:efuride_app/utils/error_ui.dart';

class MerchantStatsScreen extends StatefulWidget {
  const MerchantStatsScreen({super.key});

  @override
  State<MerchantStatsScreen> createState() => _MerchantStatsScreenState();
}

class _MerchantStatsScreenState extends State<MerchantStatsScreen>
    with WidgetsBindingObserver {
  String _t(String key) => S.of(context).t(key);

  // Headline
  MerchantStats? _stats;

  // Revenue trend (14 days, oldest → newest)
  List<double> _dailyRevenue = List.filled(14, 0);

  // Top products
  List<_TopProduct> _topProducts = [];

  // Heatmap: [dayOfWeek 0..6][hour 0..23] = count
  List<List<int>> _heatmap =
      List.generate(7, (_) => List<int>.filled(24, 0));

  bool _loading = true;
  AppError? _error;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    WidgetsBinding.instance.addPostFrameCallback((_) => _load());
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) _load();
  }

  // ═══════════════════════════════════════════════════════════
  // LOAD
  // ═══════════════════════════════════════════════════════════
  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });

    try {
      final partnerId = await MerchantService.instance.getPartnerId();
      if (partnerId == null) {
        throw StateError('No partner account');
      }

      final results = await Future.wait([
        MerchantService.instance.loadTodayStats(),
        _loadRevenueTrend(partnerId),
        _loadTopProducts(partnerId),
        _loadHeatmap(partnerId),
      ]);

      if (!mounted) return;
      setState(() {
        _stats = results[0] as MerchantStats;
        _dailyRevenue = results[1] as List<double>;
        _topProducts = results[2] as List<_TopProduct>;
        _heatmap = results[3] as List<List<int>>;
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _error = AppError.from(e, onRetry: _load);
      });
    }
  }

  Future<List<double>> _loadRevenueTrend(String partnerId) async {
    final out = List<double>.filled(14, 0);
    try {
      final now = DateTime.now();
      final start = DateTime(now.year, now.month, now.day)
          .subtract(const Duration(days: 13));

      final rows = await Supabase.instance.client
          .from('orders')
          .select('total, delivered_at')
          .eq('partner_id', partnerId)
          .eq('status', 'delivered')
          .gte('delivered_at', start.toUtc().toIso8601String());

      for (final r in rows as List) {
        final raw = r['delivered_at']?.toString();
        if (raw == null) continue;
        final d = DateTime.tryParse(raw)?.toLocal();
        if (d == null) continue;

        final idx = DateTime(d.year, d.month, d.day)
            .difference(start)
            .inDays;
        if (idx < 0 || idx > 13) continue;

        out[idx] += (r['total'] as num?)?.toDouble() ?? 0;
      }
    } catch (e) {
      debugPrint('revenue trend failed: $e');
    }
    return out;
  }

  Future<List<_TopProduct>> _loadTopProducts(String partnerId) async {
    try {
      final now = DateTime.now();
      final start = DateTime(now.year, now.month, now.day)
          .subtract(const Duration(days: 30));

      final orderRows = await Supabase.instance.client
          .from('orders')
          .select('id')
          .eq('partner_id', partnerId)
          .eq('status', 'delivered')
          .gte('delivered_at', start.toUtc().toIso8601String());

      final orderIds =
          (orderRows as List).map((r) => r['id'].toString()).toList();
      if (orderIds.isEmpty) return [];

      final itemRows = await Supabase.instance.client
          .from('order_items')
          .select('name, qty, unit_price')
          .inFilter('order_id', orderIds);

      final agg = <String, _TopProduct>{};
      for (final r in itemRows as List) {
        final name = (r['name'] ?? '').toString();
        if (name.isEmpty) continue;
        final qty = (r['qty'] as num?)?.toInt() ?? 0;
        final price = (r['unit_price'] as num?)?.toDouble() ?? 0;
        final revenue = qty * price;

        agg.update(
          name,
          (existing) => existing.copyWith(
            qty: existing.qty + qty,
            revenue: existing.revenue + revenue,
          ),
          ifAbsent: () => _TopProduct(name: name, qty: qty, revenue: revenue),
        );
      }

      final sorted = agg.values.toList()
        ..sort((a, b) => b.revenue.compareTo(a.revenue));
      return sorted.take(5).toList();
    } catch (e) {
      debugPrint('top products failed: $e');
      return [];
    }
  }

  Future<List<List<int>>> _loadHeatmap(String partnerId) async {
    final out = List.generate(7, (_) => List<int>.filled(24, 0));
    try {
      final now = DateTime.now();
      final start = DateTime(now.year, now.month, now.day)
          .subtract(const Duration(days: 30));

      final rows = await Supabase.instance.client
          .from('orders')
          .select('delivered_at, created_at')
          .eq('partner_id', partnerId)
          .eq('status', 'delivered')
          .gte('delivered_at', start.toUtc().toIso8601String());

      for (final r in rows as List) {
        final raw =
            (r['delivered_at'] ?? r['created_at'])?.toString();
        if (raw == null) continue;
        final d = DateTime.tryParse(raw)?.toLocal();
        if (d == null) continue;
        final dayIdx = (d.weekday - 1) % 7;
        final hour = d.hour.clamp(0, 23);
        out[dayIdx][hour] += 1;
      }
    } catch (e) {
      debugPrint('heatmap failed: $e');
    }
    return out;
  }

  // ═══════════════════════════════════════════════════════════
  // BUILD
  // ═══════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: EfuridePalette.cream,
      body: Column(
      children: [
        _header(),
        Expanded(
          child: _loading
              ? const Center(
                  child: CircularProgressIndicator(
                      color: EfuridePalette.merchantAccent))
              : _error != null
                  ? ErrorUI.inline(_error!)
                  : RefreshIndicator(
                      color: EfuridePalette.merchantAccent,
                      onRefresh: _load,
                      child: ListView(
                        padding:
                            const EdgeInsets.fromLTRB(16, 16, 16, 24),
                        physics: const AlwaysScrollableScrollPhysics(),
                        children: [
                          _kpiRow(),
                          const SizedBox(height: 20),
                          _revenueTrendCard(),
                          const SizedBox(height: 20),
                          _topProductsCard(),
                          const SizedBox(height: 20),
                          _heatmapCard(),
                          const SizedBox(height: 24),
                        ],
                      ),
                    ),
        ),
      ],
    ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // HEADER
  // ═══════════════════════════════════════════════════════════
  Widget _header() {
    final t = S.of(context);
    return MerchantTopBar(
      title: t.t('performance_overview'),
      subtitle: t.t('last_30_days'),
      actions: [
        IconButton(
          onPressed: _load,
          icon: const Icon(Icons.refresh, color: EfuridePalette.ink),
        ),
      ],
    );
  }

  // ═══════════════════════════════════════════════════════════
  // KPI ROW
  // ═══════════════════════════════════════════════════════════
  Widget _kpiRow() {
    final t = S.of(context);
    final s = _stats;
    final avg = (s?.ordersToday ?? 0) == 0
        ? 0.0
        : (s!.revenueToday / s.ordersToday);

    return Column(
      children: [
        Row(
          children: [
            _kpi(
              icon: Icons.attach_money,
              label: t.t('revenue'),
              value: CountryConfig.money(s?.revenueToday ?? 0),
              accent: EfuridePalette.online,
            ),
            const SizedBox(width: 10),
            _kpi(
              icon: Icons.receipt_long_outlined,
              label: t.t('orders'),
              value: '${s?.ordersToday ?? 0}',
              accent: EfuridePalette.merchantAccent,
            ),
          ],
        ),
        const SizedBox(height: 10),
        Row(
          children: [
            _kpi(
              icon: Icons.trending_up,
              label: t.t('avg_order'),
              value: CountryConfig.money(avg),
              accent: EfuridePalette.blueDeep,
            ),
            const SizedBox(width: 10),
            _kpi(
              icon: Icons.repeat,
              label: t.t('active_now'),
              value: '${s?.activeOrders ?? 0}',
              accent: EfuridePalette.accent,
            ),
          ],
        ),
      ],
    );
  }

  Widget _kpi({
    required IconData icon,
    required String label,
    required String value,
    required Color accent,
  }) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: EfuridePalette.divider),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.03),
              blurRadius: 6,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: 32,
              height: 32,
              decoration: BoxDecoration(
                color: accent.withValues(alpha: 0.12),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Icon(icon, size: 18, color: accent),
            ),
            const SizedBox(height: 10),
            Text(value,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w900,
                    color: EfuridePalette.ink,
                    letterSpacing: -0.3,
                    height: 1.1)),
            const SizedBox(height: 2),
            Text(label,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                    fontSize: 13,
                    color: EfuridePalette.inkMuted,
                    fontWeight: FontWeight.w600)),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // REVENUE TREND
  // ═══════════════════════════════════════════════════════════
  Widget _revenueTrendCard() {
    final t = S.of(context);
    final maxVal = _dailyRevenue.isEmpty
        ? 0.0
        : _dailyRevenue.reduce((a, b) => a > b ? a : b);
    final total = _dailyRevenue.fold<double>(0, (a, b) => a + b);

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: EfuridePalette.divider),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Text(t.t('revenue_trend'),
                  style: const TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w800,
                      color: EfuridePalette.ink)),
              const Spacer(),
              Text(CountryConfig.money(total),
                  style: const TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w900,
                      color: EfuridePalette.merchantAccent)),
            ],
          ),
          const SizedBox(height: 20),
          SizedBox(
            height: 120,
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: List.generate(_dailyRevenue.length, (i) {
                final v = _dailyRevenue[i];
                final height = maxVal == 0
                    ? 4.0
                    : (v / maxVal) * 100.0;
                final isToday = i == _dailyRevenue.length - 1;

                return Expanded(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 1.5),
                    child: Container(
                      height: height.clamp(4, 100),
                      decoration: BoxDecoration(
                        color: isToday
                            ? EfuridePalette.merchantAccent
                            : EfuridePalette.merchantAccent
                                .withValues(alpha: 0.35),
                        borderRadius: BorderRadius.circular(4),
                      ),
                    ),
                  ),
                );
              }),
            ),
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Text(t.t('14_days_ago'),
                  style: const TextStyle(
                      fontSize: 12, color: EfuridePalette.inkMuted)),
              const Spacer(),
              Text(t.t('today'),
                  style: const TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w800,
                      color: EfuridePalette.merchantAccent)),
            ],
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // TOP PRODUCTS
  // ═══════════════════════════════════════════════════════════
  Widget _topProductsCard() {
    final t = S.of(context);

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: EfuridePalette.divider),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(t.t('top_products'),
              style: const TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w800,
                  color: EfuridePalette.ink)),
          const SizedBox(height: 14),
          if (_topProducts.isEmpty)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 20),
              child: Center(
                child: Text(t.t('no_sales_yet'),
                    style: const TextStyle(
                        fontSize: 14,
                        color: EfuridePalette.inkMuted)),
              ),
            )
          else
            ...List.generate(_topProducts.length, (i) {
              final p = _topProducts[i];
              final maxRevenue = _topProducts.first.revenue;
              final ratio =
                  maxRevenue == 0 ? 0.0 : (p.revenue / maxRevenue);

              return Padding(
                padding: EdgeInsets.only(
                    bottom: i == _topProducts.length - 1 ? 0 : 14),
                child: Row(
                  children: [
                    Container(
                      width: 28,
                      height: 28,
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                        color: EfuridePalette.merchantAccent
                            .withValues(alpha: 0.15),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Text('${i + 1}',
                          style: const TextStyle(
                              fontSize: 13.5,
                              fontWeight: FontWeight.w900,
                              color: EfuridePalette.merchantAccent)),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(p.name,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                  fontSize: 14,
                                  fontWeight: FontWeight.w700,
                                  color: EfuridePalette.ink)),
                          const SizedBox(height: 4),
                          ClipRRect(
                            borderRadius: BorderRadius.circular(3),
                            child: LinearProgressIndicator(
                              value: ratio,
                              minHeight: 5,
                              backgroundColor: EfuridePalette.divider,
                              valueColor: const AlwaysStoppedAnimation(
                                  EfuridePalette.merchantAccent),
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(width: 12),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Text(CountryConfig.money(p.revenue),
                            style: const TextStyle(
                                fontSize: 14,
                                fontWeight: FontWeight.w900,
                                color: EfuridePalette.ink)),
                        Text('${p.qty} ${t.t('orders').toLowerCase()}',
                            style: const TextStyle(
                                fontSize: 12,
                                color: EfuridePalette.inkMuted)),
                      ],
                    ),
                  ],
                ),
              );
            }),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // HEATMAP
  // ═══════════════════════════════════════════════════════════
  Widget _heatmapCard() {
    final t = S.of(context);

    // Find max count to normalize.
    int maxCount = 0;
    for (final row in _heatmap) {
      for (final v in row) {
        if (v > maxCount) maxCount = v;
      }
    }

    const dayLabels = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
    // Render every 3rd hour for compactness.
    final hourStops = [6, 9, 12, 15, 18, 21];

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: EfuridePalette.divider),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(t.t('order_heatmap'),
              style: const TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w800,
                  color: EfuridePalette.ink)),
          const SizedBox(height: 4),
          Text(t.t('heatmap_hint'),
              style: const TextStyle(
                  fontSize: 13,
                  color: EfuridePalette.inkMuted,
                  height: 1.35)),
          const SizedBox(height: 16),

          // Hour axis
          Padding(
            padding: const EdgeInsets.only(left: 34, bottom: 6),
            child: Row(
              children: hourStops.map((h) {
                return Expanded(
                  flex: 4,
                  child: Text(
                    '${h}h',
                    style: const TextStyle(
                        fontSize: 12, color: EfuridePalette.inkMuted),
                  ),
                );
              }).toList(),
            ),
          ),

          // Rows
          for (int d = 0; d < 7; d++)
            Padding(
              padding: const EdgeInsets.only(bottom: 4),
              child: Row(
                children: [
                  SizedBox(
                    width: 34,
                    child: Text(
                      dayLabels[d],
                      style: TextStyle(
                        fontSize: 12.5,
                        fontWeight: d == (DateTime.now().weekday - 1) % 7
                            ? FontWeight.w900
                            : FontWeight.w600,
                        color: d == (DateTime.now().weekday - 1) % 7
                            ? EfuridePalette.merchantAccent
                            : EfuridePalette.inkMuted,
                      ),
                    ),
                  ),
                  Expanded(
                    child: Row(
                      children: List.generate(24, (h) {
                        final count = _heatmap[d][h];
                        final intensity = maxCount == 0
                            ? 0.0
                            : (count / maxCount).clamp(0.0, 1.0);
                        return Expanded(
                          child: Container(
                            height: 14,
                            margin: const EdgeInsets.symmetric(
                                horizontal: 0.5),
                            decoration: BoxDecoration(
                              color: intensity == 0
                                  ? EfuridePalette.divider
                                      .withValues(alpha: 0.4)
                                  : EfuridePalette.merchantAccent
                                      .withValues(
                                          alpha: 0.20 + intensity * 0.80),
                              borderRadius: BorderRadius.circular(2),
                            ),
                          ),
                        );
                      }),
                    ),
                  ),
                ],
              ),
            ),

          const SizedBox(height: 10),
          Row(
            children: [
              Text(t.t('quiet'),
                  style: const TextStyle(
                      fontSize: 12, color: EfuridePalette.inkMuted)),
              const SizedBox(width: 8),
              ...List.generate(5, (i) {
                final alpha = 0.20 + (i / 4) * 0.80;
                return Container(
                  width: 14,
                  height: 10,
                  margin: const EdgeInsets.symmetric(horizontal: 1),
                  decoration: BoxDecoration(
                    color: EfuridePalette.merchantAccent
                        .withValues(alpha: alpha),
                    borderRadius: BorderRadius.circular(2),
                  ),
                );
              }),
              const SizedBox(width: 8),
              Text(t.t('busy'),
                  style: const TextStyle(
                      fontSize: 12, color: EfuridePalette.inkMuted)),
            ],
          ),
        ],
      ),
    );
  }
}

// ══════════════════════════════════════════════════════════════
// MODEL
// ══════════════════════════════════════════════════════════════
class _TopProduct {
  final String name;
  final int qty;
  final double revenue;

  const _TopProduct({
    required this.name,
    required this.qty,
    required this.revenue,
  });

  _TopProduct copyWith({int? qty, double? revenue}) => _TopProduct(
        name: name,
        qty: qty ?? this.qty,
        revenue: revenue ?? this.revenue,
      );
}
