// lib/screens/merchant/merchant_promote_screen.dart
//
// "Promote my store": the merchant pays from the wallet to be listed first
// (with a Sponsored label) for 1 or more weeks. The admin sets the price per
// week for the country and can switch it off (then this screen says so).

import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:efuride_app/config/country_config.dart';
import 'package:efuride_app/config/efuride_palette.dart';
import 'package:efuride_app/l10n/app_strings.dart';
import 'package:efuride_app/services/merchant_service.dart';
import 'package:efuride_app/utils/app_error.dart';
import 'package:efuride_app/utils/error_ui.dart';
import 'package:efuride_app/widgets/merchant_top_bar.dart';
import 'package:efuride_app/widgets/k_icon.dart';

class MerchantPromoteScreen extends StatefulWidget {
  const MerchantPromoteScreen({super.key});

  @override
  State<MerchantPromoteScreen> createState() => _MerchantPromoteScreenState();
}

class _MerchantPromoteScreenState extends State<MerchantPromoteScreen> {
  String? _partnerId;
  Map<String, dynamic>? _quote;
  bool _loading = true;
  bool _buying = false;
  AppError? _error;
  int _weeks = 1;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final id = await MerchantService.instance.getPartnerId();
      if (id == null) throw Exception('No store found');
      final r = await Supabase.instance.client
          .rpc('kongo_sponsor_quote', params: {'p_partner': id});
      if (!mounted) return;
      setState(() {
        _partnerId = id;
        _quote = Map<String, dynamic>.from(r as Map);
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _error = AppError.from(e);
        _loading = false;
      });
    }
  }

  double _d(dynamic v) => double.tryParse('$v') ?? 0;

  DateTime? get _until {
    final v = _quote?['sponsored_until'];
    if (v == null) return null;
    final d = DateTime.tryParse(v.toString())?.toLocal();
    return (d != null && d.isAfter(DateTime.now())) ? d : null;
  }

  String _date(DateTime d) =>
      '${d.day.toString().padLeft(2, '0')}/${d.month.toString().padLeft(2, '0')}/${d.year}';

  Future<void> _buy() async {
    final id = _partnerId;
    if (id == null || _buying) return;
    setState(() => _buying = true);
    try {
      await Supabase.instance.client.rpc('kongo_sponsor_buy',
          params: {'p_partner': id, 'p_weeks': _weeks});
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(tr('Your store is now sponsored'))));
      await _load();
    } catch (e) {
      if (mounted) ErrorUI.showSnack(context, AppError.from(e));
    } finally {
      if (mounted) setState(() => _buying = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: EfuridePalette.cream,
      body: Column(
        children: [
          MerchantTopBar(
            title: tr('Promote my store'),
            subtitle: tr('Be listed first and get more orders'),
          ),
          Expanded(
            child: _loading
                ? const Center(
                    child: CircularProgressIndicator(
                        color: EfuridePalette.merchantAccent))
                : _error != null
                    ? ErrorUI.inline(_error!)
                    : _body(),
          ),
        ],
      ),
    );
  }

  Widget _body() {
    final q = _quote ?? const {};
    final enabled = q['enabled'] == true;
    if (!enabled) {
      return Padding(
        padding: const EdgeInsets.all(24),
        child: Center(
          child: Text(
            tr('Sponsored spots are not available in your country yet.'),
            textAlign: TextAlign.center,
            style: const TextStyle(
                fontSize: 16, color: EfuridePalette.inkMuted),
          ),
        ),
      );
    }
    final fee = _d(q['fee_per_week']);
    final maxWeeks = (int.tryParse('${q['max_weeks']}') ?? 4).clamp(1, 52);
    final balance = _d(q['balance']);
    final total = fee * _weeks;
    final short = balance < total;
    final until = _until;
    if (_weeks > maxWeeks) _weeks = maxWeeks;

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
      children: [
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: EfuridePalette.accent.withValues(alpha: 0.18),
            borderRadius: BorderRadius.circular(16),
          ),
          child: Row(
            children: [
              const Icon(Icons.campaign_outlined,
                  size: 32, color: EfuridePalette.ink),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  until != null
                      ? tr('Sponsored until {0}', [_date(until)])
                      : tr(
                          'Your store appears first in the list with a Sponsored label.'),
                  style: const TextStyle(
                      fontSize: 15.5,
                      fontWeight: FontWeight.w700,
                      color: EfuridePalette.ink),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 18),
        Text(tr('How many weeks?'),
            style: const TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w800,
                color: EfuridePalette.ink)),
        const SizedBox(height: 8),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: [
            for (var w = 1; w <= maxWeeks; w++)
              ChoiceChip(
                label: Text('$w ${w == 1 ? tr('week') : tr('weeks')}'),
                selected: _weeks == w,
                selectedColor: EfuridePalette.accent,
                onSelected: (_) => setState(() => _weeks = w),
              ),
          ],
        ),
        const SizedBox(height: 18),
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: EfuridePalette.divider),
          ),
          child: Column(
            children: [
              _line(tr('Price per week'), CountryConfig.money(fee)),
              _line(tr('Total'), CountryConfig.money(total), bold: true),
              _line(tr('Wallet balance'), CountryConfig.money(balance),
                  color: short ? EfuridePalette.dropoff : null),
            ],
          ),
        ),
        const SizedBox(height: 18),
        if (short)
          OutlinedButton.icon(
            onPressed: () => Navigator.pushNamed(context, '/wallet'),
            icon: const KIcon(Icons.account_balance_wallet_outlined),
            label: Text(tr('Top up wallet')),
          )
        else
          SizedBox(
            height: 52,
            child: ElevatedButton(
              onPressed: _buying ? null : _buy,
              style: ElevatedButton.styleFrom(
                  backgroundColor: EfuridePalette.accent,
                  foregroundColor: EfuridePalette.ink),
              child: _buying
                  ? const SizedBox(
                      width: 22,
                      height: 22,
                      child: CircularProgressIndicator(strokeWidth: 2.5))
                  : Text(
                      tr('Sponsor my store · {0}',
                          [CountryConfig.money(total)]),
                      style: const TextStyle(
                          fontSize: 16, fontWeight: FontWeight.w800)),
            ),
          ),
      ],
    );
  }

  Widget _line(String k, String v, {bool bold = false, Color? color}) {
    final st = TextStyle(
        fontSize: 15.5,
        fontWeight: bold ? FontWeight.w900 : FontWeight.w600,
        color: color ?? EfuridePalette.ink);
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Row(children: [
        Expanded(child: Text(k, style: st)),
        Text(v, style: st),
      ]),
    );
  }
}
