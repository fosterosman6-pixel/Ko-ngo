// lib/screens/merchant/merchant_settings_screen.dart
//
// Merchant settings. Language, notification toggles (persisted to
// profiles.prefs), and quick links to store profile, bank details,
// support, privacy, and sign-out.

import 'package:flutter/material.dart';
import 'package:efuride_app/widgets/merchant_top_bar.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:efuride_app/config/efuride_palette.dart';
import 'package:efuride_app/l10n/app_strings.dart';
import 'package:efuride_app/config/readability.dart';
import 'package:efuride_app/widgets/text_size_sheet.dart';
import 'package:efuride_app/utils/app_error.dart';
import 'package:efuride_app/utils/error_ui.dart';

// Same global notifier main.dart uses.
import 'package:efuride_app/main.dart' show appLanguageNotifier;
import 'package:efuride_app/widgets/k_icon.dart';

class MerchantSettingsScreen extends StatefulWidget {
  const MerchantSettingsScreen({super.key});

  @override
  State<MerchantSettingsScreen> createState() =>
      _MerchantSettingsScreenState();
}

class _MerchantSettingsScreenState
    extends State<MerchantSettingsScreen> {
  String _t(String key) => S.of(context).t(key);

  bool _notifNewOrders  = true;
  bool _notifStatus     = true;
  bool _notifPromos     = false;
  bool _soundAlerts     = true;

  bool _loading = true;
  bool _saving  = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  // ═══════════════════════════════════════════════════════════
  // LOAD / SAVE PREFS
  // ═══════════════════════════════════════════════════════════
  Future<void> _load() async {
    try {
      final uid = Supabase.instance.client.auth.currentUser?.id;
      if (uid == null) {
        setState(() => _loading = false);
        return;
      }

      final row = await Supabase.instance.client
          .from('profiles')
          .select('prefs')
          .eq('id', uid)
          .maybeSingle();

      final prefs = (row?['prefs'] as Map?)?.cast<String, dynamic>() ?? {};

      if (!mounted) return;
      setState(() {
        _notifNewOrders = prefs['merchant_notif_new_orders'] != false;
        _notifStatus    = prefs['merchant_notif_status']     != false;
        _notifPromos    = prefs['merchant_notif_promos']     == true;
        _soundAlerts    = prefs['merchant_sound_alerts']     != false;
        _loading        = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => _loading = false);
      // Non-fatal — fall back to defaults, no snackbar.
      debugPrint('merchant settings load failed: $e');
    }
  }

  Future<void> _persistPrefs() async {
    if (_saving) return;
    setState(() => _saving = true);
    try {
      final uid = Supabase.instance.client.auth.currentUser?.id;
      if (uid == null) return;

      // Merge into the existing prefs jsonb so we don't clobber
      // keys other screens might own.
      final row = await Supabase.instance.client
          .from('profiles')
          .select('prefs')
          .eq('id', uid)
          .maybeSingle();

      final existing =
          (row?['prefs'] as Map?)?.cast<String, dynamic>() ?? <String, dynamic>{};

      existing['merchant_notif_new_orders'] = _notifNewOrders;
      existing['merchant_notif_status']     = _notifStatus;
      existing['merchant_notif_promos']     = _notifPromos;
      existing['merchant_sound_alerts']     = _soundAlerts;

      await Supabase.instance.client
          .from('profiles')
          .update({'prefs': existing})
          .eq('id', uid);
    } catch (e) {
      if (!mounted) return;
      ErrorUI.showSnack(context, AppError.from(e));
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  Future<void> _saveLanguage(AppLang lang) async {
    appLanguageNotifier.value = lang;
    final uid = Supabase.instance.client.auth.currentUser?.id;
    if (uid == null) return;
    try {
      await Supabase.instance.client
          .from('profiles')
          .update({'language': lang.code})
          .eq('id', uid);
    } catch (e) {
      debugPrint('language persist failed: $e');
    }
  }

  // ═══════════════════════════════════════════════════════════
  // SIGN OUT
  // ═══════════════════════════════════════════════════════════
  Future<void> _confirmSignOut() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16)),
        title: Text(_t('logout_title')),
        content: Text(_t('logout_body_merchant')),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: Text(_t('keep_signed_in')),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: EfuridePalette.dropoff,
              foregroundColor: Colors.white,
            ),
            onPressed: () => Navigator.pop(context, true),
            child: Text(_t('sign_out')),
          ),
        ],
      ),
    );
    if (ok != true || !mounted) return;

    await Supabase.instance.client.auth.signOut();
    if (!mounted) return;
    Navigator.pushNamedAndRemoveUntil(context, '/role_select', (_) => false);
  }

  // ═══════════════════════════════════════════════════════════
  // LANGUAGE PICKER
  // ═══════════════════════════════════════════════════════════
  Future<void> _openLanguagePicker() async {
    final current = appLanguageNotifier.value;

    final picked = await showModalBottomSheet<AppLang>(
      context: context,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (_) => _LanguageSheet(current: current),
    );
    if (picked == null || !mounted) return;
    await _saveLanguage(picked);
    if (!mounted) return;
    ErrorUI.showSnack(
      context,
      AppError(
        title: _t('language_changed'),
        message: _t('language_changed_hint'),
        icon: Icons.check_circle_outline,
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // BUILD
  // ═══════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: EfuridePalette.cream,
      body: Column(
        children: [
          _header(),
          Expanded(
            child: _loading
                ? const Center(
                    child: CircularProgressIndicator(
                        color: EfuridePalette.merchantAccent))
                : ListView(
                    padding:
                        const EdgeInsets.fromLTRB(16, 16, 16, 24),
                    children: [
                      _notificationsCard(),
                      const SizedBox(height: 14),
                      _preferencesCard(),
                      const SizedBox(height: 14),
                      _accountCard(),
                      const SizedBox(height: 14),
                      _aboutCard(),
                      const SizedBox(height: 20),
                      _signOutButton(),
                      const SizedBox(height: 20),
                    ],
                  ),
          ),
        ],
      ),
    );
  }

  // ── Header ──
  Widget _header() {
    return MerchantTopBar(
      title: _t('settings'),
      subtitle: _t('merchant_settings_hint'),
    );
  }

  // ── Notifications ──
  Widget _notificationsCard() {
    return _card(
      icon: Icons.notifications_outlined,
      title: _t('notif_section'),
      children: [
        _toggle(
          icon: Icons.receipt_long_outlined,
          title: _t('notif_new_orders'),
          subtitle: _t('notif_new_orders_sub'),
          value: _notifNewOrders,
          onChanged: (v) {
            setState(() => _notifNewOrders = v);
            _persistPrefs();
          },
        ),
        _divider(),
        _toggle(
          icon: Icons.local_shipping_outlined,
          title: _t('notif_order_status'),
          subtitle: _t('notif_order_status_sub'),
          value: _notifStatus,
          onChanged: (v) {
            setState(() => _notifStatus = v);
            _persistPrefs();
          },
        ),
        _divider(),
        _toggle(
          icon: Icons.campaign_outlined,
          title: _t('notif_promos'),
          subtitle: _t('notif_promos_sub'),
          value: _notifPromos,
          onChanged: (v) {
            setState(() => _notifPromos = v);
            _persistPrefs();
          },
        ),
        _divider(),
        _toggle(
          icon: Icons.volume_up_outlined,
          title: _t('sound_alerts'),
          subtitle: _t('sound_alerts_sub'),
          value: _soundAlerts,
          onChanged: (v) {
            setState(() => _soundAlerts = v);
            _persistPrefs();
          },
        ),
      ],
    );
  }

  // ── Preferences ──
  Widget _preferencesCard() {
    return _card(
      icon: Icons.tune,
      title: _t('preferences'),
      children: [
        _tile(
          icon: Icons.language,
          title: _t('language'),
          subtitle: appLanguageNotifier.value.label,
          onTap: _openLanguagePicker,
        ),
        _tile(
          icon: Icons.format_size,
          title: _t('text_size'),
          subtitle: _t(Readability.labelKeyFor(Readability.textScale.value)),
          onTap: () async {
            await showTextSizeSheet(context);
            if (mounted) setState(() {});
          },
        ),
      ],
    );
  }

  // ── Account ──
  Widget _accountCard() {
    return _card(
      icon: Icons.person_outline,
      title: _t('account'),
      children: [
        _tile(
          icon: Icons.store_mall_directory_outlined,
          title: _t('store_profile'),
          subtitle: _t('store_profile_hint'),
          onTap: () =>
              Navigator.pushNamed(context, '/merchant_profile'),
        ),
        _divider(),
        _tile(
          icon: Icons.account_balance_outlined,
          title: _t('bank_details'),
          subtitle: _t('payout_account_hint'),
          onTap: () =>
              Navigator.pushNamed(context, '/merchant_bank'),
        ),
      ],
    );
  }

  // ── About / legal ──
  Widget _aboutCard() {
    return _card(
      icon: Icons.info_outline,
      title: _t('support_legal'),
      children: [
        _tile(
          icon: Icons.help_outline,
          title: _t('help_support'),
          subtitle: _t('need_help_hint'),
          onTap: () => Navigator.pushNamed(context, '/support'),
        ),
        _divider(),
        _tile(
          icon: Icons.privacy_tip_outlined,
          title: _t('privacy'),
          subtitle: _t('privacy_data'),
          onTap: () =>
              Navigator.pushNamed(context, '/customer_privacy'),
        ),
        _divider(),
        _tile(
          icon: Icons.info_outline,
          title: _t('version_label'),
          subtitle: tr('1.0.0 · build 1'),
          onTap: null,
        ),
      ],
    );
  }

  // ── Sign-out ──
  Widget _signOutButton() {
    return SizedBox(
      width: double.infinity,
      child: OutlinedButton.icon(
        onPressed: _confirmSignOut,
        icon: const KIcon(Icons.logout, size: 18,
            color: EfuridePalette.dropoff),
        label: Text(_t('sign_out'),
            style: const TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w900,
                color: EfuridePalette.dropoff)),
        style: OutlinedButton.styleFrom(
          minimumSize: const Size(0, 54),
          side: const BorderSide(color: EfuridePalette.dropoff, width: 1.4),
          shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(14)),
        ),
      ),
    );
  }

  // ── Building blocks ──
  Widget _card({
    required IconData icon,
    required String title,
    required List<Widget> children,
  }) {
    return Container(
      padding: const EdgeInsets.fromLTRB(4, 14, 4, 4),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: EfuridePalette.divider),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(14, 0, 14, 8),
            child: Row(
              children: [
                Icon(icon, size: 16,
                    color: EfuridePalette.merchantAccent),
                const SizedBox(width: 8),
                Text(title,
                    style: const TextStyle(
                      fontSize: 13.5,
                      fontWeight: FontWeight.w900,
                      color: EfuridePalette.inkMuted,
                      letterSpacing: 0.6,
                    )),
              ],
            ),
          ),
          ...children,
        ],
      ),
    );
  }

  Widget _divider() => const Divider(
        height: 1,
        indent: 14,
        endIndent: 14,
        color: EfuridePalette.divider,
      );

  Widget _toggle({
    required IconData icon,
    required String title,
    required String subtitle,
    required bool value,
    required ValueChanged<bool> onChanged,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      child: Row(
        children: [
          Icon(icon, size: 18, color: EfuridePalette.merchantAccent),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title,
                    style: const TextStyle(
                        fontSize: 14.5,
                        fontWeight: FontWeight.w700,
                        color: EfuridePalette.ink)),
                const SizedBox(height: 2),
                Text(subtitle,
                    style: const TextStyle(
                        fontSize: 13,
                        color: EfuridePalette.inkMuted,
                        height: 1.35)),
              ],
            ),
          ),
          Switch.adaptive(
            value: value,
            activeColor: EfuridePalette.merchantAccent,
            onChanged: onChanged,
          ),
        ],
      ),
    );
  }

  Widget _tile({
    required IconData icon,
    required String title,
    required String subtitle,
    required VoidCallback? onTap,
  }) {
    return InkWell(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        child: Row(
          children: [
            Icon(icon, size: 18, color: EfuridePalette.merchantAccent),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title,
                      style: const TextStyle(
                          fontSize: 14.5,
                          fontWeight: FontWeight.w700,
                          color: EfuridePalette.ink)),
                  const SizedBox(height: 2),
                  Text(subtitle,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                          fontSize: 13,
                          color: EfuridePalette.inkMuted,
                          height: 1.35)),
                ],
              ),
            ),
            if (onTap != null)
              const Icon(Icons.chevron_right,
                  size: 20, color: EfuridePalette.inkMuted),
          ],
        ),
      ),
    );
  }
}

// ══════════════════════════════════════════════════════════════
// LANGUAGE PICKER SHEET
// ══════════════════════════════════════════════════════════════
class _LanguageSheet extends StatelessWidget {
  final AppLang current;
  const _LanguageSheet({required this.current});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(20, 16, 20, 24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Center(
              child: Container(
                width: 40, height: 4,
                decoration: BoxDecoration(
                  color: Colors.grey.shade300,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
            ),
            const SizedBox(height: 18),
            Text(S.of(context).t('choose_language'),
                style: const TextStyle(
                  fontSize: 17,
                  fontWeight: FontWeight.w900,
                  color: EfuridePalette.ink,
                )),
            const SizedBox(height: 12),
            ...AppLang.available.map((l) {
              final selected = l == current;
              return InkWell(
                onTap: () => Navigator.pop(context, l),
                borderRadius: BorderRadius.circular(12),
                child: Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 14, vertical: 14),
                  margin: const EdgeInsets.only(bottom: 6),
                  decoration: BoxDecoration(
                    color: selected
                        ? EfuridePalette.merchantAccent
                            .withValues(alpha: 0.10)
                        : Colors.transparent,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                      color: selected
                          ? EfuridePalette.merchantAccent
                          : EfuridePalette.divider,
                      width: selected ? 1.4 : 1,
                    ),
                  ),
                  child: Row(
                    children: [
                      Expanded(
                        child: Text(l.label,
                            style: TextStyle(
                              fontSize: 14,
                              fontWeight: selected
                                  ? FontWeight.w900
                                  : FontWeight.w600,
                              color: selected
                                  ? EfuridePalette.merchantAccent
                                  : EfuridePalette.ink,
                            )),
                      ),
                      if (selected)
                        const Icon(Icons.check_circle,
                            color: EfuridePalette.merchantAccent,
                            size: 20),
                    ],
                  ),
                ),
              );
            }),
          ],
        ),
      ),
    );
  }
}
