// lib/screens/merchant/merchant_home_screen.dart
//
// Merchant dashboard. Real stats from MerchantService, live order
// count stream, weekly sales chart, online/offline toggle, and
// action cards.
//
// i18n-clean · currency-clean · real data.

import 'dart:async';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:efuride_app/providers/auth_provider.dart';
import 'package:efuride_app/screens/shared/messages_screen.dart';
import 'package:efuride_app/widgets/merchant_top_bar.dart';
import 'package:efuride_app/config/efuride_palette.dart';
import 'package:efuride_app/config/country_config.dart';
import 'package:efuride_app/l10n/app_strings.dart';
import 'package:efuride_app/services/merchant_service.dart';
import 'package:efuride_app/utils/app_error.dart';
import 'package:efuride_app/utils/error_ui.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class MerchantHomeScreen extends StatefulWidget {
  const MerchantHomeScreen({super.key});

  @override
  State<MerchantHomeScreen> createState() => _MerchantHomeScreenState();
}

class _MerchantHomeScreenState extends State<MerchantHomeScreen>
    with WidgetsBindingObserver {
  String _t(String key) => S.of(context).t(key);

  Map<String, dynamic>? _partner;
  MerchantStats? _stats;
  List<int> _weeklyRevenue = List.filled(7, 0);
  double _weeklyDelta = 0; // percent change vs previous week

  StreamSubscription<List<MerchantOrder>>? _ordersSub;
  int _newOrdersCount = 0;

  bool _loading = true;
  AppError? _error;
  bool _togglingOpen = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _boot();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _ordersSub?.cancel();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) _load();
  }

  // ═══════════════════════════════════════════════════════════
  // BOOT
  // ═══════════════════════════════════════════════════════════
  Future<void> _boot() async {
    try {
      await MerchantService.instance.getPartnerId();
      await _load();
      _subscribeToOrders();
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _error = AppError.from(e, onRetry: _boot);
      });
    }
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final results = await Future.wait([
        MerchantService.instance.loadPartner(),
        MerchantService.instance.loadTodayStats(),
        _loadWeeklyRevenue(),
      ]);
      if (!mounted) return;

      final weekly = results[2] as Map<String, dynamic>;
      setState(() {
        _partner = results[0] as Map<String, dynamic>?;
        _stats = results[1] as MerchantStats;
        _weeklyRevenue = weekly['thisWeek'] as List<int>;
        _weeklyDelta = weekly['delta'] as double;
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _error = AppError.from(e, onRetry: _load);
      });
    }
  }

  /// Query last 14 days of delivered orders, bucket into two 7-day windows.
  Future<Map<String, dynamic>> _loadWeeklyRevenue() async {
    final empty = {
      'thisWeek': List<int>.filled(7, 0),
      'delta': 0.0,
    };
    final pid = await MerchantService.instance.getPartnerId();
    if (pid == null) return empty;

    try {
      final now = DateTime.now();
      final start = DateTime(now.year, now.month, now.day)
          .subtract(const Duration(days: 13));

      final rows = await Supabase.instance.client
          .from('orders')
          .select('total, delivered_at')
          .eq('partner_id', pid)
          .eq('status', 'delivered')
          .gte('delivered_at', start.toUtc().toIso8601String());

      final thisWeek = List<int>.filled(7, 0);
      final prevWeek = List<int>.filled(7, 0);

      for (final r in rows as List) {
        final raw = r['delivered_at']?.toString();
        final total = (r['total'] as num?)?.toDouble() ?? 0;
        if (raw == null) continue;

        final d = DateTime.tryParse(raw)?.toLocal();
        if (d == null) continue;

        final daysAgo = DateTime(now.year, now.month, now.day)
            .difference(DateTime(d.year, d.month, d.day))
            .inDays;

        if (daysAgo < 0 || daysAgo > 13) continue;
        final idx = 6 - (daysAgo % 7);

        if (daysAgo < 7) {
          thisWeek[idx] += total.round();
        } else {
          prevWeek[idx] += total.round();
        }
      }

      final thisTotal = thisWeek.fold<int>(0, (a, b) => a + b);
      final prevTotal = prevWeek.fold<int>(0, (a, b) => a + b);
      final delta = prevTotal == 0
          ? (thisTotal > 0 ? 100.0 : 0.0)
          : ((thisTotal - prevTotal) / prevTotal) * 100.0;

      return {'thisWeek': thisWeek, 'delta': delta};
    } catch (e) {
      debugPrint('weekly revenue load failed: $e');
      return empty;
    }
  }

  void _subscribeToOrders() {
    _ordersSub?.cancel();
    _ordersSub =
        MerchantService.instance.streamOrders().listen((orders) {
      if (!mounted) return;
      setState(() {
        _newOrdersCount =
            orders.where((o) => o.status == 'pending').length;
      });
    }, onError: (e) {
      debugPrint('orders stream error: $e');
    });
  }

  // ═══════════════════════════════════════════════════════════
  // ONLINE TOGGLE
  // ═══════════════════════════════════════════════════════════
  Future<void> _toggleOpen() async {
    if (_togglingOpen || _partner == null) return;
    final next = _partner!['is_open'] != true;

    setState(() {
      _togglingOpen = true;
      _partner = {..._partner!, 'is_open': next};
    });

    try {
      await MerchantService.instance.setOpen(next);
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _partner = {..._partner!, 'is_open': !next};
      });
      ErrorUI.showSnack(context, AppError.from(e));
    } finally {
      if (mounted) setState(() => _togglingOpen = false);
    }
  }

  // ═══════════════════════════════════════════════════════════
  // BUILD
  // ═══════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: EfuridePalette.cream,
      body: Column(
      children: [
        _header(),
        Expanded(
          child: _loading
              ? const Center(
                  child: CircularProgressIndicator(
                      color: EfuridePalette.merchantAccent))
              : _error != null
                  ? ErrorUI.inline(_error!)
                  : RefreshIndicator(
                      color: EfuridePalette.merchantAccent,
                      onRefresh: _load,
                      child: ListView(
                        padding:
                            const EdgeInsets.fromLTRB(16, 16, 16, 24),
                        physics: const AlwaysScrollableScrollPhysics(),
                        children: [
                          if (_newOrdersCount > 0)
                            _pendingActionsCard(),
                          if (_newOrdersCount > 0)
                            const SizedBox(height: 14),
                          _statGrid(),
                          const SizedBox(height: 20),
                          _salesCard(),
                          const SizedBox(height: 20),
                          _quickActionsRow(),
                          const SizedBox(height: 24),
                        ],
                      ),
                    ),
        ),
      ],
    ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // HEADER
  // ═══════════════════════════════════════════════════════════
  Widget _header() {
    final t = S.of(context);
    final name = (_partner?['name'] ?? t.t('your_store')).toString();
    final category = (_partner?['category'] ?? 'restaurant').toString();
    final city = (_partner?['city'] ?? '').toString();
    final isOpen = _partner?['is_open'] == true;
    final categoryLabel = _categoryLabel(category, t);
    final locationLine =
        city.isEmpty ? categoryLabel : '$city · $categoryLabel';

    return MerchantTopBar(
      title: name,
      subtitle: locationLine,
      brandRole: t.t('role_merchant'),
      actions: [
        const MessagesIconButton(),
        IconButton(
          onPressed: () async {
            await Navigator.pushNamed(context, '/notifications');
            _load();
          },
          icon: Badge(
            isLabelVisible: _newOrdersCount > 0,
            label: Text(_newOrdersCount > 9 ? '9+' : '$_newOrdersCount'),
            child: const Icon(Icons.notifications_none_rounded,
                color: EfuridePalette.ink, size: 26),
          ),
        ),
      ],
      trailing: GestureDetector(
        onTap: () => Navigator.pushNamed(context, '/merchant_settings'),
        child: Builder(builder: (ctx) {
          final pic = ctx.watch<AuthProvider>().avatarUrl;
          return CircleAvatar(
            radius: 26,
            backgroundColor: EfuridePalette.greyBg,
            backgroundImage:
                (pic != null && pic.isNotEmpty) ? NetworkImage(pic) : null,
            child: (pic == null || pic.isEmpty)
                ? const Icon(Icons.storefront,
                    size: 26, color: EfuridePalette.merchantAccent)
                : null,
          );
        }),
      ),
      bottom: Row(
        children: [
          _openPill(isOpen),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  isOpen
                      ? tr('Customers can order now')
                      : tr('Closed: customers cannot order'),
                  style: const TextStyle(
                      fontSize: 14.5, color: EfuridePalette.inkMuted),
                ),
                const SizedBox(height: 4),
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: EfuridePalette.accent.withValues(alpha: 0.22),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(
                    tr('{0} · Business type', [categoryLabel]),
                    style: const TextStyle(
                        fontSize: 12.5, fontWeight: FontWeight.w700),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  String _categoryLabel(String category, S t) {
    switch (category.toLowerCase()) {
      case 'restaurant': return t.t('cat_restaurant');
      case 'grocery':    return t.t('svc_grocery');
      case 'pharmacy':   return t.t('svc_pharmacy');
      case 'bakery':     return t.t('cat_bakery');
      case 'fashion':    return tr('Fashion');
      case 'electronics':return tr('Electronics');
      case 'home_living':return tr('Home & Living');
      case 'beauty':     return tr('Beauty');
      case 'butchery':   return tr('Butchery');
      case 'general_retail': return tr('General Retail');
      case 'other':      return tr('Other');
      default:           return category;
    }
  }

  Widget _openPill(bool isOpen) {
    final t = S.of(context);
    return GestureDetector(
      onTap: _togglingOpen ? null : _toggleOpen,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 250),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
        decoration: BoxDecoration(
          color: isOpen
              ? EfuridePalette.onlineDeep
              : EfuridePalette.inkMuted,
          borderRadius: BorderRadius.circular(20),
          boxShadow: isOpen
              ? [
                  BoxShadow(
                    color: EfuridePalette.online.withValues(alpha: 0.35),
                    blurRadius: 10,
                    spreadRadius: 1,
                  ),
                ]
              : null,
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (_togglingOpen)
              const SizedBox(
                width: 10,
                height: 10,
                child: CircularProgressIndicator(
                    strokeWidth: 2, color: Colors.white),
              )
            else
              Container(
                width: 8,
                height: 8,
                decoration: const BoxDecoration(
                  color: Colors.white,
                  shape: BoxShape.circle,
                ),
              ),
            const SizedBox(width: 8),
            Text(
              isOpen ? t.t('online') : t.t('offline'),
              style: const TextStyle(
                color: Colors.white,
                fontSize: 13,
                fontWeight: FontWeight.w900,
                letterSpacing: 0.8,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // PENDING ACTIONS
  // ═══════════════════════════════════════════════════════════
  Widget _pendingActionsCard() {
    final t = S.of(context);
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: () => Navigator.pushNamed(context, '/merchant_orders'),
        borderRadius: BorderRadius.circular(14),
        child: Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: EfuridePalette.dropoff.withValues(alpha: 0.08),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(
                color: EfuridePalette.dropoff.withValues(alpha: 0.4),
                width: 1.4),
          ),
          child: Row(
            children: [
              Container(
                width: 42,
                height: 42,
                decoration: BoxDecoration(
                  color: EfuridePalette.dropoff.withValues(alpha: 0.15),
                  shape: BoxShape.circle,
                ),
                child: const Icon(Icons.warning_amber_rounded,
                    color: EfuridePalette.dropoff, size: 22),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      _newOrdersCount == 1
                          ? '${_newOrdersCount} ${t.t('new_orders_waiting')}'
                          : '${_newOrdersCount} ${t.t('new_orders_waiting_plural')}',
                      style: const TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w900,
                        color: EfuridePalette.dropoff,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(t.t('waiting_accept'),
                        style: const TextStyle(
                            fontSize: 13,
                            color: EfuridePalette.inkMuted)),
                  ],
                ),
              ),
              const Icon(Icons.chevron_right,
                  color: EfuridePalette.dropoff, size: 20),
            ],
          ),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // STAT GRID (2x2)
  // ═══════════════════════════════════════════════════════════
  Widget _statGrid() {
    final t = S.of(context);
    final s = _stats;

    return Column(
      children: [
        Row(
          children: [
            _statCard(
              icon: Icons.receipt_long_outlined,
              label: t.t('active_orders'),
              value: '${s?.activeOrders ?? 0}',
              accent: EfuridePalette.merchantAccent,
            ),
            const SizedBox(width: 10),
            _statCard(
              icon: Icons.add_business_outlined,
              label: t.t('new_products'),
              value: '+${s?.ordersToday ?? 0}',
              accent: EfuridePalette.blueDeep,
            ),
          ],
        ),
        const SizedBox(height: 10),
        Row(
          children: [
            _statCard(
              icon: Icons.trending_up,
              label: t.t('revenue_today'),
              value: CountryConfig.money(s?.revenueToday ?? 0),
              accent: EfuridePalette.online,
            ),
            const SizedBox(width: 10),
            _statCard(
              icon: Icons.account_balance_wallet_outlined,
              label: t.t('wallet_balance'),
              value: CountryConfig.money(s?.walletBalance ?? 0),
              accent: EfuridePalette.accent,
            ),
          ],
        ),
      ],
    );
  }

  Widget _statCard({
    required IconData icon,
    required String label,
    required String value,
    required Color accent,
  }) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: EfuridePalette.divider),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.03),
              blurRadius: 6,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: 32,
              height: 32,
              decoration: BoxDecoration(
                color: accent.withValues(alpha: 0.12),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Icon(icon, size: 18, color: accent),
            ),
            const SizedBox(height: 10),
            Text(
              value,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w900,
                color: EfuridePalette.ink,
                letterSpacing: -0.3,
                height: 1.1,
              ),
            ),
            const SizedBox(height: 2),
            Text(
              label,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                fontSize: 13,
                color: EfuridePalette.inkMuted,
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // SALES CARD
  // ═══════════════════════════════════════════════════════════
  Widget _salesCard() {
    final t = S.of(context);
    final maxVal =
        _weeklyRevenue.isEmpty ? 0 : _weeklyRevenue.reduce((a, b) => a > b ? a : b);

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: EfuridePalette.divider),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Text(t.t('sales_this_week'),
                  style: const TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w800,
                    color: EfuridePalette.ink,
                  )),
              const Spacer(),
              _deltaChip(_weeklyDelta, t),
            ],
          ),
          const SizedBox(height: 20),
          SizedBox(
            height: 120,
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: List.generate(7, (i) {
                final v = i < _weeklyRevenue.length
                    ? _weeklyRevenue[i]
                    : 0;
                final height = maxVal == 0
                    ? 4.0
                    : (v / maxVal) * 100.0;
                final isToday = i == 6;

                return Expanded(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 4),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        Container(
                          height: height.clamp(4, 100),
                          decoration: BoxDecoration(
                            color: isToday
                                ? EfuridePalette.merchantAccent
                                : EfuridePalette.merchantAccent
                                    .withValues(alpha: 0.35),
                            borderRadius: BorderRadius.circular(6),
                          ),
                        ),
                        const SizedBox(height: 6),
                        Text(
                          _dayLabel(i, t),
                          style: TextStyle(
                            fontSize: 12,
                            fontWeight: isToday
                                ? FontWeight.w900
                                : FontWeight.w600,
                            color: isToday
                                ? EfuridePalette.merchantAccent
                                : EfuridePalette.inkMuted,
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              }),
            ),
          ),
        ],
      ),
    );
  }

  Widget _deltaChip(double delta, S t) {
    final positive = delta >= 0;
    final color =
        positive ? EfuridePalette.online : EfuridePalette.dropoff;
    final icon = positive ? Icons.trending_up : Icons.trending_down;
    final label =
        '${positive ? '+' : ''}${delta.toStringAsFixed(1)}%';

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.12),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 12, color: color),
          const SizedBox(width: 4),
          Text(
            label,
            style: TextStyle(
              fontSize: 13,
              fontWeight: FontWeight.w900,
              color: color,
            ),
          ),
        ],
      ),
    );
  }

  String _dayLabel(int index, S t) {
    final now = DateTime.now();
    final daysAgo = 6 - index;
    final d = now.subtract(Duration(days: daysAgo));
    const short = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
    return short[(d.weekday - 1) % 7];
  }

  // ═══════════════════════════════════════════════════════════
  // QUICK ACTIONS
  // ═══════════════════════════════════════════════════════════
  Widget _quickActionsRow() {
    final t = S.of(context);
    final category = (_partner?['category'] ?? 'restaurant').toString();
    final forLabel = tr('For {0}', [_categoryLabel(category, t)]);
    final tiles = <Widget>[
      _quickTile(
        icon: Icons.receipt_long_outlined,
        label: t.t('orders'),
        color: const Color(0xFFFCD9B0),
        onTap: () => Navigator.pushNamed(context, '/merchant_orders'),
      ),
      _quickTile(
        icon: Icons.inventory_2_outlined,
        label: category == 'restaurant' ? t.t('menu') : tr('Restock'),
        color: const Color(0xFFC9EBD3),
        onTap: () => Navigator.pushNamed(context, '/merchant_menu'),
      ),
      _quickTile(
        icon: Icons.insights_outlined,
        label: t.t('analytics'),
        color: const Color(0xFFFBE8A6),
        onTap: () => Navigator.pushNamed(context, '/merchant_stats'),
      ),
      _quickTile(
        icon: Icons.storefront_outlined,
        label: tr('Store profile'),
        color: const Color(0xFFFCD9B0),
        onTap: () => Navigator.pushNamed(context, '/merchant_profile'),
      ),
      _quickTile(
        icon: Icons.verified_user_outlined,
        label: tr('Verify my business'),
        color: const Color(0xFFFFE9A8),
        onTap: () => Navigator.pushNamed(context, '/verify'),
      ),
      _quickTile(
        icon: Icons.campaign_outlined,
        label: tr('Promote my store'),
        color: const Color(0xFFC9EBD3),
        onTap: () => Navigator.pushNamed(context, '/merchant_promote'),
      ),
      _quickTile(
        icon: Icons.payments_outlined,
        label: t.t('payouts'),
        color: const Color(0xFFBFDDF5),
        onTap: () => Navigator.pushNamed(context, '/merchant_payouts'),
      ),
      _quickTile(
        icon: Icons.settings_outlined,
        label: t.t('settings'),
        color: const Color(0xFFFBE8A6),
        onTap: () => Navigator.pushNamed(context, '/merchant_settings'),
      ),
    ];
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: EfuridePalette.cream,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: EfuridePalette.divider),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(tr('Quick Actions'),
              style: const TextStyle(
                  fontSize: 20, fontWeight: FontWeight.w900)),
          const SizedBox(height: 2),
          Text(forLabel,
              style: const TextStyle(
                  fontSize: 14.5, color: EfuridePalette.inkMuted)),
          const SizedBox(height: 14),
          GridView.count(
            crossAxisCount: 3,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            mainAxisSpacing: 12,
            crossAxisSpacing: 12,
            childAspectRatio: 0.95,
            children: tiles,
          ),
        ],
      ),
    );
  }

  Widget _quickTile({
    required IconData icon,
    required String label,
    required Color color,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(16),
      child: Column(
        children: [
          Expanded(
            child: Container(
              width: double.infinity,
              decoration: BoxDecoration(
                color: color,
                borderRadius: BorderRadius.circular(16),
              ),
              child: Icon(icon, color: const Color(0xFF3B2F1E), size: 34),
            ),
          ),
          const SizedBox(height: 6),
          Text(
            label,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            textAlign: TextAlign.center,
            style: const TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.w700,
              color: EfuridePalette.ink,
            ),
          ),
        ],
      ),
    );
  }
}
