// lib/screens/merchant/merchant_shell.dart

import 'package:flutter/material.dart';
import 'package:efuride_app/config/efuride_palette.dart';
import 'package:efuride_app/config/tab_routes.dart';
import 'package:efuride_app/l10n/app_strings.dart';
import 'package:efuride_app/providers/auth_provider.dart';
import 'package:efuride_app/services/ring_service.dart';
import 'package:efuride_app/services/merchant_service.dart';
import 'package:efuride_app/widgets/efuride_bottom_nav.dart';
import 'package:efuride_app/screens/merchant/merchant_home_screen.dart';
import 'package:efuride_app/screens/merchant/merchant_orders_screen.dart';
import 'package:efuride_app/screens/merchant/merchant_menu_editor_screen.dart';
import 'package:efuride_app/screens/merchant/merchant_payouts_screen.dart';
import 'package:provider/provider.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class MerchantShell extends StatefulWidget {
  final int initialIndex;
  const MerchantShell({super.key, this.initialIndex = 0});

  @override
  State<MerchantShell> createState() => _MerchantShellState();
}

class _MerchantShellState extends State<MerchantShell> {
  late int _index;
  final _scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _index = widget.initialIndex.clamp(0, kMerchantTabs.length - 1);
    if (_index == 1) RingService.instance.cancelRingNotification();
  }


  /// A merchant can have several shops: pick the one to work in, or add
  /// another.
  Future<void> _openShopSwitcher() async {
    List<Map<String, dynamic>> shops = const [];
    try {
      shops = await MerchantService.instance.myShops();
    } catch (_) {}
    final current = await MerchantService.instance.getPartnerId();
    if (!mounted) return;
    await showModalBottomSheet<void>(
      context: context,
      backgroundColor: EfuridePalette.cream,
      isScrollControlled: true,
      builder: (ctx) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 16, 16, 12),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text(tr('My shops'),
                  style: const TextStyle(
                      fontSize: 20, fontWeight: FontWeight.w900)),
              const SizedBox(height: 10),
              Flexible(
                child: ListView(
                  shrinkWrap: true,
                  children: [
                    for (final sh in shops)
                      ListTile(
                        leading: Icon(
                          sh['id'].toString() == current
                              ? Icons.radio_button_checked
                              : Icons.radio_button_off,
                          color: EfuridePalette.merchantAccent,
                        ),
                        title: Text((sh['name'] ?? '').toString(),
                            style: const TextStyle(
                                fontWeight: FontWeight.w800)),
                        subtitle: Text(
                            [sh['address'], sh['city']]
                                .where((e) => (e ?? '').toString().isNotEmpty)
                                .join(', '),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis),
                        onTap: () async {
                          Navigator.pop(ctx);
                          await MerchantService.instance
                              .selectShop(sh['id'].toString());
                          if (!mounted) return;
                          Navigator.pushNamedAndRemoveUntil(
                              context, '/merchant', (_) => false);
                        },
                      ),
                  ],
                ),
              ),
              const SizedBox(height: 6),
              ElevatedButton.icon(
                onPressed: () {
                  Navigator.pop(ctx);
                  Navigator.pushNamed(context, '/merchant_profile',
                      arguments: {'new': true}).then((_) {
                    if (!mounted) return;
                    Navigator.pushNamedAndRemoveUntil(
                        context, '/merchant', (_) => false);
                  });
                },
                icon: const Icon(Icons.add_business_outlined),
                label: Text(tr('Add another shop')),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _openDrawer() => _scaffoldKey.currentState?.openDrawer();

  Future<void> _logout(BuildContext ctx) async {
    final ok = await showDialog<bool>(
      context: ctx,
      builder: (_) => AlertDialog(
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16)),
        title: Text(tr('Sign out?')),
        content: Text(
            tr('You will stop receiving new orders until you sign in again.')),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: Text(tr('Keep signed in')),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
                backgroundColor: EfuridePalette.dropoff,
                foregroundColor: Colors.white),
            onPressed: () => Navigator.pop(ctx, true),
            child: Text(tr('Sign out')),
          ),
        ],
      ),
    );
    if (ok != true) return;
    await Supabase.instance.client.auth.signOut();
    if (!ctx.mounted) return;
    Navigator.pushNamedAndRemoveUntil(ctx, '/role_select', (_) => false);
  }

  @override
  Widget build(BuildContext context) {
    final t = S.of(context);
    final auth = context.watch<AuthProvider>();

    // Phone Back button: from another tab go to the first tab; on the
    // first tab leave the app as usual (never back to sign-in).
    return PopScope(
      canPop: _index == 0,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop && _index != 0) setState(() => _index = 0);
      },
      child: Scaffold(
      key: _scaffoldKey,
      backgroundColor: EfuridePalette.cream,
      drawer: Drawer(
        backgroundColor: EfuridePalette.cream,
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.horizontal(right: Radius.circular(0)),
        ),
        child: SafeArea(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // ── Header ──
              Container(
                padding: const EdgeInsets.fromLTRB(20, 20, 20, 24),
                decoration: const BoxDecoration(
                  border: Border(
                      bottom: BorderSide(color: EfuridePalette.divider)),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Container(
                          width: 52,
                          height: 52,
                          decoration: BoxDecoration(
                            color: EfuridePalette.greyBg,
                            shape: BoxShape.circle,
                            image: (auth.avatarUrl?.isNotEmpty ?? false)
                                ? DecorationImage(
                                    image: NetworkImage(auth.avatarUrl!),
                                    fit: BoxFit.cover,
                                  )
                                : null,
                          ),
                          child: (auth.avatarUrl?.isNotEmpty ?? false)
                              ? null
                              : const Icon(Icons.storefront,
                                  color: EfuridePalette.merchantAccent,
                                  size: 24),
                        ),
                        const Spacer(),
                      ],
                    ),
                    const SizedBox(height: 14),
                    Text(
                      auth.displayName,
                      style: const TextStyle(
                        color: EfuridePalette.ink,
                        fontSize: 18,
                        fontWeight: FontWeight.w900,
                        letterSpacing: -0.3,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 2),
                    Text(
                      t.t('role_merchant'),
                      style: const TextStyle(
                          color: EfuridePalette.inkMuted, fontSize: 13.5),
                    ),
                  ],
                ),
              ),

              // ── Items ──
              _drawerItem(
                icon: Icons.dashboard_outlined,
                label: t.t('dashboard'),
                onTap: () {
                  Navigator.pop(context);
                  setState(() => _index = 0);
                },
              ),
              _drawerItem(
                icon: Icons.receipt_long_outlined,
                label: t.t('orders'),
                onTap: () {
                  Navigator.pop(context);
                  setState(() => _index = 1);
                },
              ),
              _drawerItem(
                icon: Icons.restaurant_menu_outlined,
                label: t.t('menu'),
                onTap: () {
                  Navigator.pop(context);
                  setState(() => _index = 2);
                },
              ),
              _drawerItem(
                icon: Icons.payments_outlined,
                label: t.t('payouts'),
                onTap: () {
                  Navigator.pop(context);
                  setState(() => _index = 3);
                },
              ),
              const Divider(height: 1, color: EfuridePalette.divider),
              _drawerItem(
                icon: Icons.swap_horiz_rounded,
                label: tr('My shops'),
                onTap: () {
                  Navigator.pop(context);
                  _openShopSwitcher();
                },
              ),
              _drawerItem(
                icon: Icons.store_mall_directory_outlined,
                label: t.t('store_profile'),
                onTap: () {
                  Navigator.pop(context);
                  Navigator.pushNamed(context, '/merchant_profile');
                },
              ),
              _drawerItem(
                icon: Icons.account_balance_outlined,
                label: t.t('bank_details'),
                onTap: () {
                  Navigator.pop(context);
                  Navigator.pushNamed(context, '/merchant_bank');
                },
              ),
              _drawerItem(
                icon: Icons.settings_outlined,
                label: t.t('settings'),
                onTap: () {
                  Navigator.pop(context);
                  Navigator.pushNamed(context, '/merchant_settings');
                },
              ),
              _drawerItem(
                icon: Icons.chat_bubble_outline,
                label: tr('Messages'),
                onTap: () {
                  Navigator.pop(context);
                  Navigator.pushNamed(context, '/messages');
                },
              ),
              _drawerItem(
                icon: Icons.help_outline,
                label: t.t('support'),
                onTap: () {
                  Navigator.pop(context);
                  Navigator.pushNamed(context, '/support');
                },
              ),
              const Spacer(),
              const Divider(height: 1, color: EfuridePalette.divider),
              _drawerItem(
                icon: Icons.logout,
                label: t.t('sign_out'),
                color: EfuridePalette.dropoff,
                onTap: () => _logout(context),
              ),
              const SizedBox(height: 12),
            ],
          ),
        ),
      ),
      body: IndexedStack(
        index: _index,
        children: const [
          MerchantHomeScreen(),
          MerchantOrdersScreen(),
          MerchantMenuEditorScreen(),
          MerchantPayoutsScreen(),
        ],
      ),
      bottomNavigationBar: EfurideBottomNav(
        role: EfurideRole.merchant,
        currentIndex: _index,
        onTap: (i) {
          if (i == 1) RingService.instance.cancelRingNotification();
          setState(() => _index = i);
        },
        items: kMerchantTabs,
      ),
    ),
    );
  }

  Widget _drawerItem({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
    Color? color,
  }) {
    final c = color ?? EfuridePalette.ink;
    return ListTile(
      leading: Icon(icon, color: c, size: 22),
      title: Text(label,
          style: TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.w600,
            color: c,
          )),
      onTap: onTap,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.horizontal(right: Radius.circular(24)),
      ),
    );
  }
}

MerchantShell buildMerchantShell(Uri uri) => MerchantShell(
      initialIndex: TabRoute.indexFor('merchant', uri.queryParameters['tab']),
    );
