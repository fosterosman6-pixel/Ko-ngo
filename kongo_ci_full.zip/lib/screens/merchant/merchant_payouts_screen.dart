// lib/screens/merchant/merchant_payouts_screen.dart
//
// Merchant payouts. Available balance, pending amount, next settlement
// date, YTD stats, and settlement history from MerchantService.
//
// i18n-clean · currency-clean · real data.

import 'dart:async';
import 'package:flutter/material.dart';
import 'package:efuride_app/widgets/merchant_top_bar.dart';
import 'package:efuride_app/config/efuride_palette.dart';
import 'package:efuride_app/config/country_config.dart';
import 'package:efuride_app/l10n/app_strings.dart';
import 'package:efuride_app/services/merchant_service.dart';
import 'package:efuride_app/services/pricing_service.dart';
import 'package:efuride_app/services/wallet_service.dart';
import 'package:efuride_app/utils/money.dart';
import 'package:efuride_app/widgets/wallet/payout_sheet.dart';
import 'package:efuride_app/utils/app_error.dart';
import 'package:efuride_app/utils/error_ui.dart';
import 'package:efuride_app/widgets/k_icon.dart';

class MerchantPayoutsScreen extends StatefulWidget {
  const MerchantPayoutsScreen({super.key});

  @override
  State<MerchantPayoutsScreen> createState() =>
      _MerchantPayoutsScreenState();
}

class _MerchantPayoutsScreenState extends State<MerchantPayoutsScreen>
    with WidgetsBindingObserver {
  String _t(String key) => S.of(context).t(key);
  String _tf(String key, Map<String, Object> args) =>
      S.of(context).tf(key, args);

  Map<String, dynamic>? _partner;
  MerchantStats? _stats;
  List<MerchantSettlement> _settlements = [];

  /// Server wallet (step 21): every delivered order is credited here.
  MyWallet? _w;
  List<Map<String, dynamic>> _sales = [];

  bool _loading = true;
  AppError? _error;

  @override
  void initState() {
    super.initState();
    PricingService.changes.addListener(_onPricesChanged);
    WidgetsBinding.instance.addObserver(this);
    _load();
  }

  void _onPricesChanged() {
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    PricingService.changes.removeListener(_onPricesChanged);
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) _load();
  }

  // ═══════════════════════════════════════════════════════════
  // LOAD
  // ═══════════════════════════════════════════════════════════
  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final results = await Future.wait([
        MerchantService.instance.loadPartner(),
        MerchantService.instance.loadTodayStats(),
        MerchantService.instance.loadSettlements(),
        PricingService.current(),
      ]);
      MyWallet? w;
      List<Map<String, dynamic>> sales = [];
      var settlements = results[2] as List<MerchantSettlement>;
      try {
        w = await WalletService.myWallet();
        sales = await WalletService.listLines('sale', limit: 20);
        // Payout requests shown in the settlement history.
        final reqs = await WalletService.listMyPayouts();
        settlements = [
          for (final r in reqs)
            MerchantSettlement.fromMap({
              'id': (r['id'] ?? '').toString(),
              'period_start': r['created_at'],
              'period_end': r['paid_at'] ?? r['created_at'],
              'net_payout': r['amount'],
              'status': r['status'],
              'reference': r['bank_name'],
              'paid_at': r['paid_at'],
            }),
          ...settlements,
        ];
      } catch (_) {
        w = null;
      }
      if (!mounted) return;
      setState(() {
        _partner = results[0] as Map<String, dynamic>?;
        _stats = results[1] as MerchantStats;
        _settlements = settlements;
        _w = w;
        _sales = sales;
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _error = AppError.from(e, onRetry: _load);
      });
    }
  }

  // ═══════════════════════════════════════════════════════════
  // DERIVED VALUES
  // ═══════════════════════════════════════════════════════════
  double get _availableBalance =>
      _w?.available ?? _stats?.walletBalance ?? 0;

  double get _pendingAmount => _settlements
      .where((s) => s.status == 'pending' || s.status == 'processing')
      .fold<double>(0, (sum, s) => sum + s.netPayout);

  double get _paidYtd => _settlements
      .where((s) => s.status == 'paid')
      .fold<double>(0, (sum, s) => sum + s.netPayout);

  int get _totalOrdersYtd =>
      _settlements.fold<int>(0, (sum, s) => sum + s.orderCount);

  /// ko!ngo's commission for this country (set by admin).
  double get _commissionPct =>
      PricingService.last.merchantCommissionPct;

  /// Next Friday from today (the app's settlement day).
  DateTime _nextFriday() {
    final now = DateTime.now();
    final daysUntilFriday = (DateTime.friday - now.weekday + 7) % 7;
    return DateTime(now.year, now.month, now.day)
        .add(Duration(days: daysUntilFriday == 0 ? 7 : daysUntilFriday));
  }

  // ═══════════════════════════════════════════════════════════
  // BUILD
  // ═══════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: EfuridePalette.cream,
      body: Column(
      children: [
        _header(),
        Expanded(
          child: _loading
              ? const Center(
                  child: CircularProgressIndicator(
                      color: EfuridePalette.merchantAccent))
              : _error != null
                  ? ErrorUI.inline(_error!)
                  : RefreshIndicator(
                      color: EfuridePalette.merchantAccent,
                      onRefresh: _load,
                      child: ListView(
                        padding:
                            const EdgeInsets.fromLTRB(16, 16, 16, 24),
                        physics: const AlwaysScrollableScrollPhysics(),
                        children: [
                          _balanceCard(),
                          const SizedBox(height: 16),
                          _statsRow(),
                          const SizedBox(height: 20),
                          if (_sales.isNotEmpty) ...[
                            _salesSection(),
                            const SizedBox(height: 20),
                          ],
                          _settlementHistorySection(),
                          const SizedBox(height: 20),
                          _payoutAccountCard(),
                          const SizedBox(height: 24),
                        ],
                      ),
                    ),
        ),
      ],
    ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // HEADER
  // ═══════════════════════════════════════════════════════════
  Widget _header() {
    return MerchantTopBar(
      title: _t('payouts'),
      subtitle: _t('weekly_settlement_sub'),
      actions: [
        IconButton(
          onPressed: _load,
          icon: const Icon(Icons.refresh, color: EfuridePalette.ink),
        ),
      ],
    );
  }

  // ═══════════════════════════════════════════════════════════
  // BALANCE CARD
  // ═══════════════════════════════════════════════════════════
  Widget _balanceCard() {
    final next = _nextFriday();
    final daysUntil = next.difference(DateTime.now()).inDays;

    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: EfuridePalette.divider),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: EfuridePalette.greyBg,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: const KIcon(Icons.account_balance_wallet_outlined,
                    color: EfuridePalette.ink, size: 18),
              ),
              const SizedBox(width: 10),
              Text(_t('available_balance'),
                  style: const TextStyle(
                    color: EfuridePalette.ink,
                    fontSize: 14.5,
                    fontWeight: FontWeight.w800,
                  )),
            ],
          ),
          const SizedBox(height: 14),
          Text(CountryConfig.money(_availableBalance),
              style: const TextStyle(
                color: EfuridePalette.ink,
                fontSize: 32,
                fontWeight: FontWeight.w900,
                letterSpacing: -0.5,
                height: 1.0,
              )),
          const SizedBox(height: 14),
          if (_pendingAmount > 0)
            Container(
              padding: const EdgeInsets.symmetric(
                  horizontal: 12, vertical: 10),
              decoration: BoxDecoration(
                color: EfuridePalette.greyBg,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Row(
                children: [
                  const KIcon(Icons.schedule,
                      color: EfuridePalette.ink, size: 16),
                  const SizedBox(width: 8),
                  Text(
                    '${CountryConfig.money(_pendingAmount)} ${_t('pending_label').toLowerCase()}',
                    style: const TextStyle(
                      color: EfuridePalette.ink,
                      fontSize: 14,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  const Spacer(),
                  Text(_t('weekly_settlement'),
                      style: const TextStyle(
                        color: EfuridePalette.inkMuted,
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                      )),
                ],
              ),
            ),
          if (_w != null) ...[
            const SizedBox(height: 4),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                onPressed: () async {
                  final sent =
                      await showPayoutSheet(context, _w!.available);
                  if (sent) _load();
                },
                icon: const KIcon(Icons.account_balance),
                label: Text(tr('Request payout'),
                    style: const TextStyle(
                        fontSize: 16, fontWeight: FontWeight.w800)),
                style: ElevatedButton.styleFrom(
                  backgroundColor: EfuridePalette.accent,
                  foregroundColor: EfuridePalette.accentInk,
                  minimumSize: const Size(0, 50),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(14)),
                ),
              ),
            ),
          ],
          const SizedBox(height: 10),
          Text(
            daysUntil == 0
                ? _t('next_settlement_today')
                : _tf('next_settlement_in_days', {'n': daysUntil}),
            style: const TextStyle(
              color: EfuridePalette.inkMuted,
              fontSize: 13,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // SALES (one line per delivered order, from the server)
  // ═══════════════════════════════════════════════════════════
  Widget _salesSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(left: 4, bottom: 10),
          child: Text(tr('Sales credited'),
              style: const TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w800,
                  color: EfuridePalette.ink)),
        ),
        Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: EfuridePalette.divider),
          ),
          child: Column(
            children: [
              for (final l in _sales)
                ListTile(
                  dense: true,
                  leading: const KIcon(Icons.receipt_long_outlined,
                      color: EfuridePalette.ink),
                  title: Text(WalletService.lineText(l),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontSize: 13.5)),
                  subtitle: Text(fmtDate(l['created_at']),
                      style: const TextStyle(fontSize: 12.5)),
                  trailing: Text(
                    '+${CountryConfig.money((l['amount'] as num?)?.toDouble() ?? 0)}',
                    style: const TextStyle(
                        fontWeight: FontWeight.w800,
                        color: Color(0xFF15803D)),
                  ),
                ),
            ],
          ),
        ),
      ],
    );
  }

  // ═══════════════════════════════════════════════════════════
  // STATS ROW
  // ═══════════════════════════════════════════════════════════
  Widget _statsRow() {
    return Row(
      children: [
        _statTile(
          icon: Icons.check_circle_outline,
          label: _t('paid_ytd'),
          value: CountryConfig.money(_paidYtd),
        ),
        const SizedBox(width: 10),
        _statTile(
          icon: Icons.percent,
          label: _t('commission'),
          value: '${_commissionPct.toStringAsFixed(0)}%',
        ),
        const SizedBox(width: 10),
        _statTile(
          icon: Icons.receipt_long_outlined,
          label: _t('orders'),
          value: '$_totalOrdersYtd',
        ),
      ],
    );
  }

  Widget _statTile({
    required IconData icon,
    required String label,
    required String value,
  }) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: EfuridePalette.divider),
        ),
        child: Column(
          children: [
            Icon(icon,
                size: 18, color: EfuridePalette.merchantAccent),
            const SizedBox(height: 8),
            Text(value,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                    fontSize: 14.5,
                    fontWeight: FontWeight.w900,
                    color: EfuridePalette.ink)),
            const SizedBox(height: 2),
            Text(label,
                textAlign: TextAlign.center,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                    fontSize: 12.5, color: EfuridePalette.inkMuted)),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // SETTLEMENT HISTORY
  // ═══════════════════════════════════════════════════════════
  Widget _settlementHistorySection() {
    if (_settlements.isEmpty) {
      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.only(left: 4, bottom: 10),
            child: Text(_t('settlement_history'),
                style: const TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w800,
                    color: EfuridePalette.ink)),
          ),
          Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: EfuridePalette.divider),
            ),
            child: Column(
              children: [
                Icon(Icons.history_toggle_off,
                    size: 40, color: Colors.grey.shade400),
                const SizedBox(height: 10),
                Text(
                  _t('no_settlements_yet'),
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w700,
                    color: EfuridePalette.inkMuted,
                  ),
                ),
              ],
            ),
          ),
        ],
      );
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(left: 4, bottom: 10),
          child: Text(_t('settlement_history'),
              style: const TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w800,
                  color: EfuridePalette.ink)),
        ),
        Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: EfuridePalette.divider),
          ),
          child: Column(
            children: List.generate(_settlements.length, (i) {
              final s = _settlements[i];
              return Column(
                children: [
                  _settlementRow(s),
                  if (i < _settlements.length - 1)
                    const Divider(
                      height: 1,
                      indent: 14,
                      endIndent: 14,
                      color: EfuridePalette.divider,
                    ),
                ],
              );
            }),
          ),
        ),
      ],
    );
  }

  Widget _settlementRow(MerchantSettlement s) {
    final statusColor = _statusColor(s.status);
    final statusLabel = _statusLabel(s.status);
    final ref = (s.reference ?? '').trim();
    final refLabel = ref.isEmpty
        ? 'SET-${s.id.substring(0, 6).toUpperCase()}'
        : ref;

    return Padding(
      padding: const EdgeInsets.all(14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: 6, vertical: 2),
                decoration: BoxDecoration(
                  color: statusColor.withValues(alpha: 0.12),
                  borderRadius: BorderRadius.circular(4),
                ),
                child: Text(
                  statusLabel,
                  style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 0.5,
                    color: statusColor,
                  ),
                ),
              ),
              const SizedBox(width: 8),
              Flexible(
                child: Text(
                  refLabel,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w800,
                    color: EfuridePalette.ink,
                  ),
                ),
              ),
              const Spacer(),
              Text(
                CountryConfig.money(s.netPayout),
                style: const TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w900,
                  color: EfuridePalette.ink,
                ),
              ),
            ],
          ),
          const SizedBox(height: 6),
          Row(
            children: [
              const Icon(Icons.calendar_today_outlined,
                  size: 12, color: EfuridePalette.inkMuted),
              const SizedBox(width: 4),
              Text(
                _periodLabel(s.periodStart, s.periodEnd),
                style: const TextStyle(
                    fontSize: 13, color: EfuridePalette.inkMuted),
              ),
              const SizedBox(width: 14),
              const KIcon(Icons.receipt_long_outlined,
                  size: 12, color: EfuridePalette.inkMuted),
              const SizedBox(width: 4),
              Text(
                '${s.orderCount} ${_t('orders').toLowerCase()}',
                style: const TextStyle(
                    fontSize: 13, color: EfuridePalette.inkMuted),
              ),
            ],
          ),
          if (s.status == 'failed' && (s.failureReason ?? '').isNotEmpty)
            Padding(
              padding: const EdgeInsets.only(top: 6),
              child: Row(
                children: [
                  const Icon(Icons.error_outline,
                      size: 12, color: EfuridePalette.dropoff),
                  const SizedBox(width: 4),
                  Expanded(
                    child: Text(
                      s.failureReason!,
                      style: const TextStyle(
                          fontSize: 13,
                          color: EfuridePalette.dropoff,
                          fontWeight: FontWeight.w600),
                    ),
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }

  String _periodLabel(DateTime a, DateTime b) {
    String fmt(DateTime d) => '${d.day} ${_monthShort(d.month)} ${d.year}';
    return '${fmt(a)} – ${fmt(b)}';
  }

  String _monthShort(int m) {
    const months = [
      'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
      'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec',
    ];
    return months[(m - 1).clamp(0, 11)];
  }

  Color _statusColor(String s) {
    switch (s) {
      case 'paid':       return EfuridePalette.online;
      case 'failed':     return EfuridePalette.dropoff;
      case 'processing': return EfuridePalette.blueDeep;
      case 'pending':
      default:           return EfuridePalette.merchantAccent;
    }
  }

  String _statusLabel(String s) {
    switch (s) {
      case 'paid':       return _t('paid_label');
      case 'failed':     return _t('failed_label');
      case 'processing': return _t('processing_label');
      case 'pending':
      default:           return _t('pending_label');
    }
  }

  // ═══════════════════════════════════════════════════════════
  // PAYOUT ACCOUNT
  // ═══════════════════════════════════════════════════════════
  Widget _payoutAccountCard() {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: () => Navigator.pushNamed(context, '/merchant_bank'),
        borderRadius: BorderRadius.circular(14),
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: EfuridePalette.divider),
          ),
          child: Row(
            children: [
              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  color: EfuridePalette.blueDeep.withValues(alpha: 0.12),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: const KIcon(Icons.account_balance,
                    color: EfuridePalette.blueDeep, size: 20),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(_t('payout_account'),
                        style: const TextStyle(
                          fontSize: 14.5,
                          fontWeight: FontWeight.w800,
                          color: EfuridePalette.ink,
                        )),
                    const SizedBox(height: 2),
                    Text(_t('payout_account_hint'),
                        style: const TextStyle(
                          fontSize: 13,
                          color: EfuridePalette.inkMuted,
                          height: 1.35,
                        )),
                  ],
                ),
              ),
              const Icon(Icons.chevron_right,
                  size: 20, color: EfuridePalette.inkMuted),
            ],
          ),
        ),
      ),
    );
  }
}
