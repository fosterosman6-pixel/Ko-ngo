// lib/screens/merchant/merchant_store_profile_screen.dart
//
// Merchant store profile editor. Name, category, description, address,
// contact, prep time, delivery fee, min order, logo + cover.
// Reads/writes the same `partners` row customers see in the storefront.

import 'package:flutter/material.dart';
import 'package:efuride_app/widgets/photo_source_sheet.dart';
import 'package:efuride_app/widgets/merchant_top_bar.dart';
import 'package:flutter/services.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart' show LatLng;
import 'package:image_picker/image_picker.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:efuride_app/services/pricing_service.dart';
import 'package:efuride_app/config/country_config.dart';
import 'package:efuride_app/config/efuride_palette.dart';
import 'package:efuride_app/l10n/app_strings.dart';
import 'package:efuride_app/services/merchant_service.dart';
import 'package:efuride_app/services/storage_service.dart';
import 'package:efuride_app/utils/app_error.dart';
import 'package:efuride_app/utils/error_ui.dart';
import 'package:efuride_app/widgets/place_search_sheet.dart';
import 'package:efuride_app/services/google_maps_service.dart';
import 'package:efuride_app/widgets/k_icon.dart';

class MerchantStoreProfileScreen extends StatefulWidget {
  /// true: add another shop (a merchant can have several).
  final bool newShop;
  const MerchantStoreProfileScreen({super.key, this.newShop = false});

  @override
  State<MerchantStoreProfileScreen> createState() =>
      _MerchantStoreProfileScreenState();
}

class _MerchantStoreProfileScreenState
    extends State<MerchantStoreProfileScreen> {
  String _t(String key) => S.of(context).t(key);

  final _nameCtrl     = TextEditingController();
  final _descCtrl     = TextEditingController();
  final _addressCtrl  = TextEditingController();
  final _cityCtrl     = TextEditingController();
  final _phoneCtrl    = TextEditingController();
  final _emailCtrl    = TextEditingController();
  final _prepCtrl     = TextEditingController();
  final _deliveryCtrl = TextEditingController();
  final _minOrderCtrl = TextEditingController();

  String _category = 'restaurant';
  double? _lat;
  double? _lng;
  String? _logoUrl;
  String? _coverUrl;

  bool _loading = true;
  bool _saving  = false;
  bool _uploadingLogo  = false;
  bool _uploadingCover = false;

  String? _partnerId;

  static const _categories = [
    ('restaurant', 'cat_restaurant'),
    ('grocery',    'svc_grocery'),
    ('pharmacy',   'svc_pharmacy'),
    ('bakery',     'cat_bakery'),
    ('fashion',        'Fashion'),
    ('electronics',    'Electronics'),
    ('home_living',    'Home & Living'),
    ('beauty',         'Beauty'),
    ('butchery',       'Butchery'),
    ('general_retail', 'General Retail'),
    ('other',          'Other'),
  ];

  /// Existing types use the app's translation keys; the newer ones are
  /// plain English phrases translated with tr().
  String _catLabel(String k) =>
      (k.startsWith('cat_') || k.startsWith('svc_')) ? _t(k) : tr(k);

  @override
  void initState() {
    super.initState();
    PricingService.changes.addListener(_onPricesChanged);
    // Country prices first, so defaults are in the right currency.
    PricingService.current().whenComplete(() {
      if (mounted) _load();
    });
  }

  void _onPricesChanged() {
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    PricingService.changes.removeListener(_onPricesChanged);
    _nameCtrl.dispose();
    _descCtrl.dispose();
    _addressCtrl.dispose();
    _cityCtrl.dispose();
    _phoneCtrl.dispose();
    _emailCtrl.dispose();
    _prepCtrl.dispose();
    _deliveryCtrl.dispose();
    _minOrderCtrl.dispose();
    super.dispose();
  }

  // ═══════════════════════════════════════════════════════════
  // LOAD
  // ═══════════════════════════════════════════════════════════
  Future<void> _load() async {
    setState(() => _loading = true);
    try {
      // "Add another shop": start with an empty form, nothing loaded.
      _partnerId = widget.newShop
          ? null
          : await MerchantService.instance.getPartnerId();
      if (_partnerId == null) {
        setState(() => _loading = false);
        return;
      }

      final row = await Supabase.instance.client
          .from('partners')
          .select()
          .eq('id', _partnerId!)
          .maybeSingle();

      if (!mounted) return;
      if (row != null) {
        _nameCtrl.text     = (row['name'] ?? '').toString();
        _descCtrl.text     = (row['description'] ?? '').toString();
        _addressCtrl.text  = (row['address'] ?? '').toString();
        _cityCtrl.text     = (row['city'] ?? 'Brazzaville').toString();
        _phoneCtrl.text    = (row['phone'] ?? '').toString();
        _emailCtrl.text    = (row['email'] ?? '').toString();
        _prepCtrl.text     =
            ((row['prep_minutes'] as num?)?.toInt() ?? 15).toString();
        _deliveryCtrl.text =
            ((row['delivery_fee'] as num?)?.toDouble() ??
                    PricingService.last.parcelSmall)
                .toStringAsFixed(0);
        _minOrderCtrl.text =
            ((row['min_order'] as num?)?.toDouble() ?? 0)
                .toStringAsFixed(0);
        _category  = (row['category'] ?? 'restaurant').toString();
        _lat       = (row['lat'] as num?)?.toDouble();
        _lng       = (row['lng'] as num?)?.toDouble();
        _logoUrl   = row['logo_url']?.toString();
        _coverUrl  = row['cover_url']?.toString();
      }
      setState(() => _loading = false);
    } catch (e) {
      if (!mounted) return;
      setState(() => _loading = false);
      ErrorUI.showSnack(context, AppError.from(e, onRetry: _load));
    }
  }

  // ═══════════════════════════════════════════════════════════
  // IMAGE UPLOADS
  // ═══════════════════════════════════════════════════════════
  Future<void> _pickLogo() async {
    final f = await pickPhotoLiveOrGallery(context,
        maxWidth: 800, imageQuality: 80);
    if (f == null || !mounted) return;

    setState(() => _uploadingLogo = true);
    try {
      final pid = await _ensurePartner();
      if (pid == null) throw StateError('Store could not be created');
      final url = await StorageService.instance.uploadMerchantLogo(
        partnerId: pid,
        file: f,
      );
      if (!mounted) return;
      if (url == null) throw StateError('Logo upload failed');
      setState(() => _logoUrl = url);
      await _saveField({'logo_url': url}, silent: true);
    } catch (e) {
      if (!mounted) return;
      ErrorUI.showSnack(context, AppError.from(e));
    } finally {
      if (mounted) setState(() => _uploadingLogo = false);
    }
  }

  Future<void> _pickCover() async {
    final f = await pickPhotoLiveOrGallery(context,
        maxWidth: 1600, imageQuality: 80);
    if (f == null || !mounted) return;

    setState(() => _uploadingCover = true);
    try {
      final pid = await _ensurePartner();
      if (pid == null) throw StateError('Store could not be created');
      final url = await StorageService.instance.uploadMerchantCover(
        partnerId: pid,
        file: f,
      );
      if (!mounted) return;
      if (url == null) throw StateError('Cover upload failed');
      setState(() => _coverUrl = url);
      await _saveField({'cover_url': url}, silent: true);
    } catch (e) {
      if (!mounted) return;
      ErrorUI.showSnack(context, AppError.from(e));
    } finally {
      if (mounted) setState(() => _uploadingCover = false);
    }
  }

  // ═══════════════════════════════════════════════════════════
  // SAVE
  // ═══════════════════════════════════════════════════════════
  bool get _formValid =>
      _nameCtrl.text.trim().isNotEmpty &&
      _addressCtrl.text.trim().isNotEmpty &&
      _cityCtrl.text.trim().isNotEmpty;

  /// A new merchant has no store row yet. Create it (owned by this
  /// user) the first time something needs saving.
  Future<String?> _ensurePartner() async {
    if (_partnerId != null) return _partnerId;
    final uid = Supabase.instance.client.auth.currentUser?.id;
    if (uid == null) return null;
    final name = _nameCtrl.text.trim();
    await _geocodeIfNeeded();
    final row = await Supabase.instance.client
        .from('partners')
        .insert({
          'owner_id': uid,
          'name': name.isEmpty ? _t('my_store') : name,
          'category': _category,
          'address': _addressCtrl.text.trim(),
          'city': _cityCtrl.text.trim(),
          'lat': _lat,
          'lng': _lng,
          'is_active': true,
          // Sensible amounts for this country (not old franc defaults).
          'delivery_fee': PricingService.last.parcelSmall,
          'min_order': 0,
        })
        .select('id')
        .single();
    _partnerId = row['id']?.toString();
    if (_partnerId != null) {
      await MerchantService.instance.selectShop(_partnerId!);
    }
    return _partnerId;
  }

  /// A typed address without a map pin: find its position, so customers,
  /// drivers and shoppers can still navigate to the shop. If it can't be
  /// found the shop is saved with the address only.
  Future<void> _geocodeIfNeeded() async {
    if (_lat != null && _lng != null) return;
    final q = [_addressCtrl.text.trim(), _cityCtrl.text.trim()]
        .where((e) => e.isNotEmpty)
        .join(', ');
    if (q.isEmpty) return;
    try {
      final origin = const LatLng(-15.0, 25.0);
      final preds = await GoogleMapsService.autocomplete(
          query: q, origin: origin, radiusMeters: 50000,
          countryCode: CountryConfig.servedIso);
      if (preds.isEmpty) return;
      final d = await GoogleMapsService.details(preds.first.placeId);
      if (d == null) return;
      _lat = d.lat;
      _lng = d.lng;
    } catch (_) {/* address only is fine */}
  }

  /// Store location via Google: fills address + city + map position.
  Future<void> _pickStoreLocation() async {
    final place = await showPlaceSearchSheet(
      context,
      near: (_lat != null && _lng != null) ? LatLng(_lat!, _lng!) : null,
      title: _t('store_location'),
      initialQuery: _addressCtrl.text.trim().isEmpty
          ? null
          : _addressCtrl.text.trim(),
    );
    if (place == null || !mounted) return;
    setState(() {
      _addressCtrl.text = place.displayAddress;
      if ((place.city ?? '').isNotEmpty) _cityCtrl.text = place.city!;
      _lat = place.lat;
      _lng = place.lng;
    });
  }

  Future<void> _saveField(
    Map<String, dynamic> patch, {
    bool silent = false,
  }) async {
    if (await _ensurePartner() == null) return;
    await Supabase.instance.client
        .from('partners')
        .update({
          ...patch,
          'updated_at': DateTime.now().toUtc().toIso8601String(),
        })
        .eq('id', _partnerId!);

    if (!silent && mounted) {
      ErrorUI.showSnack(
        context,
        AppError(
          title: _t('saved'),
          message: _t('store_profile_saved'),
          icon: Icons.check_circle_outline,
        ),
      );
    }
  }

  Future<void> _save() async {
    if (!_formValid || _saving) return;

    setState(() => _saving = true);
    try {
      await _geocodeIfNeeded();
      await _saveField({
        'name':          _nameCtrl.text.trim(),
        'description':   _descCtrl.text.trim().isEmpty
                            ? null : _descCtrl.text.trim(),
        'address':       _addressCtrl.text.trim(),
        'city':          _cityCtrl.text.trim(),
        'phone':         _phoneCtrl.text.trim().isEmpty
                            ? null : _phoneCtrl.text.trim(),
        'email':         _emailCtrl.text.trim().isEmpty
                            ? null : _emailCtrl.text.trim(),
        'category':      _category,
        'prep_minutes':  int.tryParse(_prepCtrl.text.trim()) ?? 15,
        'delivery_fee':  double.tryParse(_deliveryCtrl.text.trim()) ??
                            PricingService.last.parcelSmall,
        'min_order':     double.tryParse(_minOrderCtrl.text.trim()) ?? 0,
        'lat':           _lat,
        'lng':           _lng,
      });
    } catch (e) {
      if (!mounted) return;
      ErrorUI.showSnack(context, AppError.from(e, onRetry: _save));
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  // ═══════════════════════════════════════════════════════════
  // BUILD
  // ═══════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: EfuridePalette.cream,
      body: Column(
        children: [
          _header(),
          Expanded(
            child: _loading
                ? const Center(
                    child: CircularProgressIndicator(
                        color: EfuridePalette.merchantAccent))
                : ListView(
                    padding: const EdgeInsets.fromLTRB(16, 16, 16, 100),
                    children: [
                      _coverCard(),
                      const SizedBox(height: 14),
                      _identityCard(),
                      const SizedBox(height: 14),
                      _contactCard(),
                      const SizedBox(height: 14),
                      _operationsCard(),
                      const SizedBox(height: 20),
                    ],
                  ),
          ),
          if (!_loading) _stickyBar(),
        ],
      ),
    );
  }

  // ── Header ──
  Widget _header() {
    return MerchantTopBar(
      title: _t('store_profile'),
      subtitle: _t('store_profile_hint'),
    );
  }

  // ── Cover + logo ──
  Widget _coverCard() {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: EfuridePalette.divider),
      ),
      clipBehavior: Clip.antiAlias,
      child: Column(
        children: [
          // Cover strip
          GestureDetector(
            onTap: _uploadingCover ? null : _pickCover,
            child: Container(
              height: 130,
              width: double.infinity,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    EfuridePalette.merchantAccent.withValues(alpha: 0.20),
                    EfuridePalette.merchantAccent.withValues(alpha: 0.05),
                  ],
                ),
              ),
              child: Stack(
                children: [
                  if (_coverUrl != null && _coverUrl!.isNotEmpty)
                    Positioned.fill(
                      child: Image.network(
                        _coverUrl!,
                        fit: BoxFit.cover,
                        errorBuilder: (_, __, ___) =>
                            _coverPlaceholder(),
                      ),
                    )
                  else
                    _coverPlaceholder(),
                  if (_uploadingCover)
                    Positioned.fill(
                      child: Container(
                        color: Colors.black.withValues(alpha: 0.4),
                        child: const Center(
                          child: CircularProgressIndicator(
                              color: Colors.white),
                        ),
                      ),
                    ),
                  Positioned(
                    bottom: 8, right: 8,
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 10, vertical: 5),
                      decoration: BoxDecoration(
                        color: Colors.black.withValues(alpha: 0.55),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const KIcon(Icons.camera_alt,
                              color: Colors.white, size: 12),
                          const SizedBox(width: 4),
                          Text(_t('change_cover'),
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 12.5,
                                fontWeight: FontWeight.w800,
                              )),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),

          // Logo circle overlapping
          Transform.translate(
            offset: const Offset(0, -30),
            child: GestureDetector(
              onTap: _uploadingLogo ? null : _pickLogo,
              child: Container(
                width: 80, height: 80,
                decoration: BoxDecoration(
                  color: Colors.white,
                  shape: BoxShape.circle,
                  border: Border.all(color: Colors.white, width: 4),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withValues(alpha: 0.10),
                      blurRadius: 8,
                      offset: const Offset(0, 2),
                    ),
                  ],
                ),
                clipBehavior: Clip.antiAlias,
                child: Stack(
                  children: [
                    if (_logoUrl != null && _logoUrl!.isNotEmpty)
                      Positioned.fill(
                        child: Image.network(
                          _logoUrl!,
                          fit: BoxFit.cover,
                          errorBuilder: (_, __, ___) => _logoPlaceholder(),
                        ),
                      )
                    else
                      _logoPlaceholder(),
                    if (_uploadingLogo)
                      Positioned.fill(
                        child: Container(
                          color: Colors.black.withValues(alpha: 0.4),
                          child: const Center(
                            child: SizedBox(
                              width: 20, height: 20,
                              child: CircularProgressIndicator(
                                  strokeWidth: 2, color: Colors.white),
                            ),
                          ),
                        ),
                      ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _coverPlaceholder() {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.wallpaper_outlined,
              size: 36, color: EfuridePalette.merchantAccent
                  .withValues(alpha: 0.6)),
          const SizedBox(height: 6),
          Text(_t('add_cover'),
              style: TextStyle(
                fontSize: 13.5,
                color: EfuridePalette.merchantAccent
                    .withValues(alpha: 0.8),
                fontWeight: FontWeight.w700,
              )),
        ],
      ),
    );
  }

  Widget _logoPlaceholder() {
    return const Center(
      child: Icon(Icons.storefront,
          size: 34, color: EfuridePalette.merchantAccent),
    );
  }

  // ── Identity card ──
  Widget _identityCard() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: EfuridePalette.divider),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _label(_t('store_name')),
          const SizedBox(height: 6),
          _field(_nameCtrl,
              capitalization: TextCapitalization.words,
              hint: _t('store_name_hint')),
          const SizedBox(height: 14),

          _label(_t('description')),
          const SizedBox(height: 6),
          _field(_descCtrl,
              maxLines: 3,
              capitalization: TextCapitalization.sentences,
              hint: _t('store_desc_hint')),
          const SizedBox(height: 14),

          _label(_t('category')),
          const SizedBox(height: 8),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: _categories.map((entry) {
              final (key, labelKey) = entry;
              final active = _category == key;
              return GestureDetector(
                onTap: () => setState(() => _category = key),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 180),
                  padding: const EdgeInsets.symmetric(
                      horizontal: 14, vertical: 10),
                  decoration: BoxDecoration(
                    color: active
                        ? EfuridePalette.merchantAccent
                            .withValues(alpha: 0.12)
                        : Colors.transparent,
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(
                      color: active
                          ? EfuridePalette.merchantAccent
                          : EfuridePalette.divider,
                      width: active ? 1.4 : 1,
                    ),
                  ),
                  child: Text(_catLabel(labelKey),
                      style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w800,
                        color: active
                            ? EfuridePalette.merchantAccent
                            : EfuridePalette.ink,
                      )),
                ),
              );
            }).toList(),
          ),
        ],
      ),
    );
  }

  // ── Contact card ──
  Widget _contactCard() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: EfuridePalette.divider),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _sectionTitle(Icons.location_on_outlined, _t('location')),
          const SizedBox(height: 12),
          _label(_t('address')),
          const SizedBox(height: 6),
          // Type the address, or pick it on the map. A typed address
          // is located automatically when you save.
          _field(_addressCtrl,
              capitalization: TextCapitalization.words,
              hint: _t('address_hint'),
              onChanged: (_) {
                // Edited by hand: the old map pin no longer matches.
                if (_lat != null || _lng != null) {
                  setState(() {
                    _lat = null;
                    _lng = null;
                  });
                }
              }),
          const SizedBox(height: 6),
          Row(
            children: [
              Icon(
                _lat != null ? Icons.check_circle : Icons.info_outline,
                size: 14,
                color: _lat != null
                    ? EfuridePalette.online
                    : EfuridePalette.merchantAccent,
              ),
              const SizedBox(width: 6),
              Expanded(
                child: Text(
                  _lat != null
                      ? _t('store_location_set')
                      : _t('store_location_needed'),
                  style: const TextStyle(
                      fontSize: 13, color: EfuridePalette.inkMuted),
                ),
              ),
              TextButton(
                onPressed: _pickStoreLocation,
                child: Text(_t('store_location_pick')),
              ),
            ],
          ),
          const SizedBox(height: 14),
          _label(_t('city')),
          const SizedBox(height: 6),
          _field(_cityCtrl,
              capitalization: TextCapitalization.words,
              hint: _t('city_hint')),

          const SizedBox(height: 20),
          _sectionTitle(Icons.contact_phone_outlined, _t('contact')),
          const SizedBox(height: 12),
          _label(_t('phone')),
          const SizedBox(height: 6),
          _field(_phoneCtrl,
              keyboard: TextInputType.phone,
              inputFormatters: [
                FilteringTextInputFormatter.allow(
                    RegExp(r'[0-9+\-\s()]')),
              ],
              hint: '+242 ...'),
          const SizedBox(height: 14),
          _label(_t('email')),
          const SizedBox(height: 6),
          _field(_emailCtrl,
              keyboard: TextInputType.emailAddress,
              hint: 'store@example.com'),
        ],
      ),
    );
  }

  // ── Operations card ──
  Widget _operationsCard() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: EfuridePalette.divider),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _sectionTitle(Icons.tune, _t('operations')),
          const SizedBox(height: 12),

          Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _label(_t('prep_min')),
                    const SizedBox(height: 6),
                    _field(_prepCtrl,
                        keyboard: TextInputType.number,
                        inputFormatters: [
                          FilteringTextInputFormatter.digitsOnly,
                        ]),
                  ],
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _label(_t('delivery_fee')),
                    const SizedBox(height: 6),
                    _field(_deliveryCtrl,
                        keyboard: TextInputType.number,
                        inputFormatters: [
                          FilteringTextInputFormatter.digitsOnly,
                        ]),
                  ],
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _label(_t('min_order')),
                    const SizedBox(height: 6),
                    _field(_minOrderCtrl,
                        keyboard: TextInputType.number,
                        inputFormatters: [
                          FilteringTextInputFormatter.digitsOnly,
                        ]),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _sectionTitle(IconData icon, String text) {
    return Row(
      children: [
        Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: EfuridePalette.merchantAccent.withValues(alpha: 0.12),
            borderRadius: BorderRadius.circular(10),
          ),
          child: Icon(icon,
              size: 16, color: EfuridePalette.merchantAccent),
        ),
        const SizedBox(width: 10),
        Text(text,
            style: const TextStyle(
              fontSize: 14.5,
              fontWeight: FontWeight.w900,
              color: EfuridePalette.ink,
            )),
      ],
    );
  }

  Widget _label(String s) => Text(s,
      style: const TextStyle(
        fontSize: 13.5,
        fontWeight: FontWeight.w800,
        color: EfuridePalette.ink,
        letterSpacing: 0.2,
      ));

  Widget _field(
    TextEditingController ctrl, {
    String? hint,
    TextInputType? keyboard,
    int maxLines = 1,
    List<TextInputFormatter>? inputFormatters,
    TextCapitalization capitalization = TextCapitalization.none,
    ValueChanged<String>? onChanged,
  }) {
    return TextField(
      controller: ctrl,
      keyboardType: keyboard,
      maxLines: maxLines,
      inputFormatters: inputFormatters,
      textCapitalization: capitalization,
      onChanged: (v) {
        onChanged?.call(v);
        setState(() {});
      },
      style: const TextStyle(
        fontSize: 14,
        color: EfuridePalette.ink,
        fontWeight: FontWeight.w600,
      ),
      decoration: InputDecoration(
        hintText: hint,
        hintStyle: const TextStyle(
            fontSize: 14, color: EfuridePalette.inkMuted),
        filled: true,
        fillColor: EfuridePalette.cream,
        contentPadding: const EdgeInsets.symmetric(
            horizontal: 14, vertical: 14),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide.none,
        ),
      ),
    );
  }

  // ── Sticky bar ──
  Widget _stickyBar() {
    return Container(
      padding: EdgeInsets.fromLTRB(
        16, 12, 16, 12 + MediaQuery.of(context).padding.bottom,
      ),
      decoration: BoxDecoration(
        color: Colors.white,
        border: const Border(
            top: BorderSide(color: EfuridePalette.divider)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.05),
            blurRadius: 10,
            offset: const Offset(0, -3),
          ),
        ],
      ),
      child: SizedBox(
        width: double.infinity,
        child: ElevatedButton(
          onPressed: (_formValid && !_saving) ? _save : null,
          style: ElevatedButton.styleFrom(
            backgroundColor: EfuridePalette.merchantAccent,
            foregroundColor: Colors.white,
            minimumSize: const Size(0, 54),
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(14)),
            elevation: 0,
          ),
          child: _saving
              ? const SizedBox(
                  width: 20, height: 20,
                  child: CircularProgressIndicator(
                      strokeWidth: 2, color: Colors.white),
                )
              : Text(_t('save_changes'),
                  style: const TextStyle(
                      fontSize: 15, fontWeight: FontWeight.w900)),
        ),
      ),
    );
  }
}
