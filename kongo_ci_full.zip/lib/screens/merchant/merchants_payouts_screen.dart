// lib/screens/merchant/merchant_payouts_screen.dart

import 'package:flutter/material.dart';
import 'package:efuride_app/config/efuride_palette.dart';
import 'package:intl/intl.dart';
import 'package:efuride_app/widgets/k_icon.dart';

class MerchantPayoutsScreen extends StatefulWidget {
  const MerchantPayoutsScreen({super.key});

  @override
  State<MerchantPayoutsScreen> createState() =>
      _MerchantPayoutsScreenState();
}

enum _PayoutStatus { pending, paid, failed }

class _Payout {
  final String id;
  final DateTime start;
  final DateTime end;
  final int orders;
  final double gross;
  final double commission;
  final double net;
  final _PayoutStatus status;
  final String? ref;
  final DateTime? paidAt;
  const _Payout({
    required this.id,
    required this.start,
    required this.end,
    required this.orders,
    required this.gross,
    required this.commission,
    required this.net,
    required this.status,
    this.ref,
    this.paidAt,
  });
}

class _MerchantPayoutsScreenState extends State<MerchantPayoutsScreen> {
  final double _available = 128450;
  final double _pending = 32400;
  final int _commission = 25;

  late final List<_Payout> _payouts;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    await Future.delayed(const Duration(milliseconds: 300));
    final now = DateTime.now();
    _payouts = [
      _Payout(
        id: 'SET-1042',
        start: now.subtract(const Duration(days: 7)),
        end: now,
        orders: 47,
        gross: 382500,
        commission: 95625,
        net: 286875,
        status: _PayoutStatus.pending,
      ),
      _Payout(
        id: 'SET-1041',
        start: now.subtract(const Duration(days: 14)),
        end: now.subtract(const Duration(days: 7)),
        orders: 52,
        gross: 415200,
        commission: 103800,
        net: 311400,
        status: _PayoutStatus.paid,
        ref: 'PP-9F82A1C4',
        paidAt: now.subtract(const Duration(days: 4)),
      ),
      _Payout(
        id: 'SET-1040',
        start: now.subtract(const Duration(days: 21)),
        end: now.subtract(const Duration(days: 14)),
        orders: 38,
        gross: 298700,
        commission: 74675,
        net: 224025,
        status: _PayoutStatus.paid,
        ref: 'PP-7D31B9E2',
        paidAt: now.subtract(const Duration(days: 11)),
      ),
      _Payout(
        id: 'SET-1039',
        start: now.subtract(const Duration(days: 28)),
        end: now.subtract(const Duration(days: 21)),
        orders: 44,
        gross: 356100,
        commission: 89025,
        net: 267075,
        status: _PayoutStatus.paid,
        ref: 'PP-4A18C7D5',
        paidAt: now.subtract(const Duration(days: 18)),
      ),
      _Payout(
        id: 'SET-1038',
        start: now.subtract(const Duration(days: 35)),
        end: now.subtract(const Duration(days: 28)),
        orders: 31,
        gross: 243800,
        commission: 60950,
        net: 182850,
        status: _PayoutStatus.failed,
      ),
    ];
    if (mounted) setState(() => _loading = false);
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        _header(),
        Expanded(
          child: _loading
              ? const Center(
                  child: CircularProgressIndicator(
                      color: EfuridePalette.merchantAccent))
              : ListView(
                  padding: const EdgeInsets.all(16),
                  children: [
                    _balanceCard(),
                    const SizedBox(height: 12),
                    _summaryRow(),
                    const SizedBox(height: 20),
                    const Text('Settlement history',
                        style: TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w800,
                            color: EfuridePalette.ink)),
                    const SizedBox(height: 10),
                    ..._payouts.map(_payoutCard),
                    const SizedBox(height: 20),
                    _bankCard(),
                  ],
                ),
        ),
      ],
    );
  }

  Widget _header() {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          colors: [EfuridePalette.blue, EfuridePalette.blueDeep],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
      ),
      child: SafeArea(
        bottom: false,
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 10, 16, 14),
              child: Row(
                children: [
                  Container(
                    width: 40,
                    height: 40,
                    decoration: const BoxDecoration(
                      color: Colors.white,
                      shape: BoxShape.circle,
                    ),
                    child: const Center(
                      child: Icon(Icons.storefront,
                          color: EfuridePalette.merchantAccent, size: 22),
                    ),
                  ),
                  const SizedBox(width: 12),
                  const Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('EFURIDE',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 18,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 1.4,
                            height: 1.05,
                          )),
                      SizedBox(height: 2),
                      Text('Merchant · Payouts',
                          style: TextStyle(
                            color: Colors.white70,
                            fontSize: 12,
                            fontWeight: FontWeight.w500,
                          )),
                    ],
                  ),
                  const Spacer(),
                  IconButton(
                    onPressed: _load,
                    icon: const Icon(Icons.refresh,
                        color: Colors.white, size: 22),
                  ),
                ],
              ),
            ),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 18),
              decoration: const BoxDecoration(
                color: EfuridePalette.navy,
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(24),
                  topRight: Radius.circular(24),
                ),
              ),
              child: const Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Payouts',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 22,
                        fontWeight: FontWeight.w900,
                        letterSpacing: -0.3,
                      )),
                  SizedBox(height: 4),
                  Text('Weekly settlement · PawaPay',
                      style: TextStyle(
                          color: Colors.white70, fontSize: 13)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _balanceCard() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [
            EfuridePalette.merchantAccent,
            Color(0xFFD07A0F),
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(18),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Row(
            children: [
              KIcon(Icons.account_balance_wallet,
                  color: Colors.white, size: 18),
              SizedBox(width: 8),
              Text('Available balance',
                  style: TextStyle(
                      color: Colors.white70,
                      fontSize: 12,
                      fontWeight: FontWeight.w600)),
            ],
          ),
          const SizedBox(height: 6),
          Text('${_available.toStringAsFixed(0)} XAF',
              style: const TextStyle(
                color: Colors.white,
                fontSize: 30,
                fontWeight: FontWeight.w900,
                letterSpacing: -0.5,
              )),
          const SizedBox(height: 12),
          Container(
            padding:
                const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            decoration: BoxDecoration(
              color: Colors.white.withValues(alpha: 0.15),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Row(
              children: [
                const Icon(Icons.hourglass_top,
                    color: Colors.white, size: 14),
                const SizedBox(width: 6),
                Text('${_pending.toStringAsFixed(0)} XAF pending',
                    style: const TextStyle(
                        color: Colors.white,
                        fontSize: 12,
                        fontWeight: FontWeight.w700)),
                const Spacer(),
                const Text('Weekly settlement',
                    style: TextStyle(
                        color: Colors.white70, fontSize: 11)),
              ],
            ),
          ),
          const SizedBox(height: 12),
          const Text('Next settlement: Friday, in 3 days',
              style: TextStyle(
                  color: Colors.white70,
                  fontSize: 11,
                  fontWeight: FontWeight.w600)),
        ],
      ),
    );
  }

  Widget _summaryRow() {
    final totalPaid = _payouts
        .where((p) => p.status == _PayoutStatus.paid)
        .fold<double>(0, (s, p) => s + p.net);

    return Row(
      children: [
        _summaryTile(
          'Paid YTD',
          '${(totalPaid / 1000).toStringAsFixed(1)}k',
          Icons.check_circle_outline,
          EfuridePalette.onlineDeep,
        ),
        const SizedBox(width: 10),
        _summaryTile(
          'Commission',
          '$_commission%',
          Icons.percent,
          EfuridePalette.blueDeep,
        ),
        const SizedBox(width: 10),
        _summaryTile(
          'Orders',
          '${_payouts.fold<int>(0, (s, p) => s + p.orders)}',
          Icons.receipt_long_outlined,
          EfuridePalette.merchantAccent,
        ),
      ],
    );
  }

  Widget _summaryTile(
      String label, String value, IconData icon, Color color) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: EfuridePalette.divider),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(icon, size: 16, color: color),
            const SizedBox(height: 8),
            Text(value,
                style: const TextStyle(
                    fontSize: 16, fontWeight: FontWeight.w900)),
            const SizedBox(height: 2),
            Text(label,
                style: const TextStyle(
                    fontSize: 10.5,
                    color: EfuridePalette.inkMuted)),
          ],
        ),
      ),
    );
  }

  Widget _payoutCard(_Payout p) {
    final color = _statusColor(p.status);
    final label = _statusLabel(p.status);
    final icon = _statusIcon(p.status);

    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
          color: p.status == _PayoutStatus.pending
              ? EfuridePalette.merchantAccent.withValues(alpha: 0.4)
              : p.status == _PayoutStatus.failed
                  ? EfuridePalette.dropoff.withValues(alpha: 0.4)
                  : EfuridePalette.divider,
          width: p.status == _PayoutStatus.pending ||
                  p.status == _PayoutStatus.failed
              ? 1.4
              : 1,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: 8, vertical: 3),
                decoration: BoxDecoration(
                  color: color.withValues(alpha: 0.12),
                  borderRadius: BorderRadius.circular(6),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(icon, size: 11, color: color),
                    const SizedBox(width: 4),
                    Text(label.toUpperCase(),
                        style: TextStyle(
                          fontSize: 9.5,
                          fontWeight: FontWeight.w900,
                          color: color,
                          letterSpacing: 0.5,
                        )),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              Text(p.id,
                  style: const TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w800,
                      color: EfuridePalette.ink)),
              const Spacer(),
              Text('${p.net.toStringAsFixed(0)} XAF',
                  style: const TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w900,
                      color: EfuridePalette.ink)),
            ],
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              const Icon(Icons.calendar_today_outlined,
                  size: 12, color: EfuridePalette.inkMuted),
              const SizedBox(width: 6),
              Text(
                '${DateFormat('MMM d').format(p.start)} – '
                '${DateFormat('MMM d, yyyy').format(p.end)}',
                style: const TextStyle(
                    fontSize: 11.5,
                    color: EfuridePalette.inkMuted),
              ),
            ],
          ),
          const SizedBox(height: 10),
          const Divider(height: 1, color: EfuridePalette.divider),
          const SizedBox(height: 10),
          _line('Gross sales',
              '${p.gross.toStringAsFixed(0)} XAF'),
          const SizedBox(height: 4),
          _line('Commission ($_commission%)',
              '− ${p.commission.toStringAsFixed(0)} XAF',
              color: EfuridePalette.dropoff),
          const SizedBox(height: 4),
          _line('Orders', '${p.orders}',
              color: EfuridePalette.inkMuted),
          if (p.ref != null) ...[
            const SizedBox(height: 10),
            Row(
              children: [
                Text('Ref: ${p.ref}',
                    style: const TextStyle(
                        fontSize: 10.5,
                        color: EfuridePalette.inkMuted,
                        fontFamily: 'monospace')),
                const Spacer(),
                if (p.paidAt != null)
                  Text(
                    'Paid ${DateFormat('MMM d').format(p.paidAt!)}',
                    style: const TextStyle(
                        fontSize: 10.5,
                        color: EfuridePalette.onlineDeep,
                        fontWeight: FontWeight.w700),
                  ),
              ],
            ),
          ],
          if (p.status == _PayoutStatus.failed) ...[
            const SizedBox(height: 10),
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: EfuridePalette.dropoff.withValues(alpha: 0.08),
                borderRadius: BorderRadius.circular(8),
              ),
              child: const Row(
                children: [
                  Icon(Icons.warning_amber_rounded,
                      size: 14, color: EfuridePalette.dropoff),
                  SizedBox(width: 6),
                  Expanded(
                    child: Text(
                      'Payout failed — verify bank details and retry.',
                      style: TextStyle(
                          fontSize: 11,
                          color: EfuridePalette.dropoff,
                          fontWeight: FontWeight.w600),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 8),
            OutlinedButton.icon(
              onPressed: () {},
              icon: const Icon(Icons.refresh, size: 16),
              label: const Text('Retry payout',
                  style: TextStyle(
                      fontWeight: FontWeight.w800,
                      color: EfuridePalette.dropoff)),
              style: OutlinedButton.styleFrom(
                minimumSize: const Size(double.infinity, 42),
                side: const BorderSide(color: EfuridePalette.dropoff),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10)),
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _line(String label, String value, {Color? color}) {
    return Row(
      children: [
        Text(label,
            style: const TextStyle(
                fontSize: 12, color: EfuridePalette.inkMuted)),
        const Spacer(),
        Text(value,
            style: TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w800,
                color: color ?? EfuridePalette.ink)),
      ],
    );
  }

  Widget _bankCard() {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: EfuridePalette.divider),
      ),
      child: Row(
        children: [
          const KIcon(Icons.account_balance_outlined,
              size: 22, color: EfuridePalette.merchantAccent),
          const SizedBox(width: 12),
          const Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Payout account',
                    style: TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w800,
                        color: EfuridePalette.ink)),
                SizedBox(height: 2),
                Text('MTN MoMo · +242 06 123 4567',
                    style: TextStyle(
                        fontSize: 11.5,
                        color: EfuridePalette.inkMuted)),
              ],
            ),
          ),
          TextButton(
            onPressed: () =>
                Navigator.pushNamed(context, '/merchant_bank'),
            style: TextButton.styleFrom(
              padding: EdgeInsets.zero,
              minimumSize: const Size(0, 0),
              tapTargetSize: MaterialTapTargetSize.shrinkWrap,
            ),
            child: const Text('Edit',
                style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w800,
                    color: EfuridePalette.merchantAccent)),
          ),
        ],
      ),
    );
  }

  Color _statusColor(_PayoutStatus s) => switch (s) {
        _PayoutStatus.pending => EfuridePalette.merchantAccent,
        _PayoutStatus.paid => EfuridePalette.onlineDeep,
        _PayoutStatus.failed => EfuridePalette.dropoff,
      };

  IconData _statusIcon(_PayoutStatus s) => switch (s) {
        _PayoutStatus.pending => Icons.hourglass_top,
        _PayoutStatus.paid => Icons.check_circle,
        _PayoutStatus.failed => Icons.error_outline,
      };

  String _statusLabel(_PayoutStatus s) => switch (s) {
        _PayoutStatus.pending => 'Pending',
        _PayoutStatus.paid => 'Paid',
        _PayoutStatus.failed => 'Failed',
      };
}
