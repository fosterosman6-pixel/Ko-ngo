// lib/screens/merchant/merchant_menu_editor_screen.dart
//
// Merchant menu editor. Create/update/delete products, toggle
// availability, mark featured, upload images. Streams from
// MerchantService.streamMenu().
//
// i18n-clean · currency-clean · real data.

import 'dart:async';
import 'package:flutter/material.dart';
import 'package:efuride_app/widgets/photo_source_sheet.dart';
import 'package:efuride_app/widgets/merchant_top_bar.dart';
import 'package:image_picker/image_picker.dart';
import 'package:efuride_app/config/efuride_palette.dart';
import 'package:efuride_app/config/country_config.dart';
import 'package:efuride_app/l10n/app_strings.dart';

import 'package:efuride_app/services/merchant_service.dart';
import 'package:efuride_app/services/storage_service.dart';
import 'package:efuride_app/utils/app_error.dart';
import 'package:efuride_app/utils/error_ui.dart';

class MerchantMenuEditorScreen extends StatefulWidget {
  const MerchantMenuEditorScreen({super.key});

  @override
  State<MerchantMenuEditorScreen> createState() =>
      _MerchantMenuEditorScreenState();
}

class _MerchantMenuEditorScreenState
    extends State<MerchantMenuEditorScreen> {
  String _t(String key) => S.of(context).t(key);

  StreamSubscription<List<MerchantProduct>>? _menuSub;
  List<MerchantProduct> _products = [];
  bool _loading = true;
  AppError? _error;

  // Track per-product in-flight toggles.
  final Set<String> _busy = {};

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      try {
        await MerchantService.instance.getPartnerId();
        _subscribe();
      } catch (e) {
        if (!mounted) return;
        setState(() {
          _loading = false;
          _error = AppError.from(e, onRetry: _subscribe);
        });
      }
    });
  }

  @override
  void dispose() {
    _menuSub?.cancel();
    super.dispose();
  }

  void _subscribe() {
    _menuSub?.cancel();
    _menuSub = MerchantService.instance.streamMenu().listen(
      (rows) {
        if (!mounted) return;
        setState(() {
          _products = rows;
          _loading = false;
          _error = null;
        });
      },
      onError: (e) {
        if (!mounted) return;
        setState(() {
          _loading = false;
          _error = AppError.from(e, onRetry: _subscribe);
        });
      },
    );
  }

  // ═══════════════════════════════════════════════════════════
  // ACTIONS
  // ═══════════════════════════════════════════════════════════
  Future<void> _toggleAvailability(MerchantProduct p) async {
    if (_busy.contains(p.id)) return;
    setState(() => _busy.add(p.id));
    try {
      await MerchantService.instance
          .toggleProductAvailability(p.id, !p.isAvailable);
    } catch (e) {
      if (!mounted) return;
      ErrorUI.showSnack(context, AppError.from(e));
    } finally {
      if (mounted) setState(() => _busy.remove(p.id));
    }
  }

  Future<void> _confirmDelete(MerchantProduct p) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16)),
        title: Text(_t('delete_product_q')),
        content: Text(
          '${_t('delete_product_body')}\n\n"${p.name}"',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: Text(_t('cancel')),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
                backgroundColor: EfuridePalette.dropoff,
                foregroundColor: Colors.white),
            onPressed: () => Navigator.pop(context, true),
            child: Text(_t('delete')),
          ),
        ],
      ),
    );
    if (ok != true) return;

    setState(() => _busy.add(p.id));
    try {
      await MerchantService.instance.deleteProduct(p.id);
      if (!mounted) return;
      ErrorUI.showSnack(
        context,
        AppError(
          title: _t('product_deleted'),
          message: _t('menu_live'),
          icon: Icons.check_circle_outline,
        ),
      );
    } catch (e) {
      if (!mounted) return;
      ErrorUI.showSnack(context, AppError.from(e));
    } finally {
      if (mounted) setState(() => _busy.remove(p.id));
    }
  }

  Future<void> _openEditor({MerchantProduct? existing}) async {
    final result = await showModalBottomSheet<Map<String, dynamic>>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (_) => _ProductEditorSheet(existing: existing),
    );
    if (result == null || !mounted) return;

    try {
      await MerchantService.instance.upsertProduct(
        id: existing?.id,
        name: result['name'] as String,
        description: result['description'] as String?,
        category: result['category'] as String?,
        price: result['price'] as double,
        emoji: result['emoji'] as String?,
        imageUrl: result['image_url'] as String?,
        prepMinutes: result['prep_minutes'] as int,
        stockLeft: result['stock_left'] as int?,
        isAvailable: result['is_available'] as bool,
        isFeatured: result['is_featured'] as bool,
      );
      if (!mounted) return;
      ErrorUI.showSnack(
        context,
        AppError(
          title: existing == null
              ? _t('product_added')
              : _t('product_updated'),
          message: _t('menu_live'),
          icon: Icons.check_circle_outline,
        ),
      );
    } catch (e) {
      if (!mounted) return;
      ErrorUI.showSnack(context, AppError.from(e));
    }
  }

  // ═══════════════════════════════════════════════════════════
  // BUILD
  // ═══════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: EfuridePalette.cream,
      body: Column(
      children: [
        _header(),
        Expanded(
          child: _loading
              ? const Center(
                  child: CircularProgressIndicator(
                      color: EfuridePalette.merchantAccent))
              : _error != null
                  ? ErrorUI.inline(_error!)
                  : _products.isEmpty
                      ? _emptyState()
                      : RefreshIndicator(
                          color: EfuridePalette.merchantAccent,
                          // ✅ FIX: re-subscribe to the live menu stream.
                          onRefresh: () async => _subscribe(),
                          child: ListView.builder(
                            padding: const EdgeInsets.fromLTRB(
                                16, 12, 16, 100),
                            itemCount: _products.length,
                            itemBuilder: (_, i) =>
                                _productCard(_products[i]),
                          ),
                        ),
        ),
      ],
    ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // HEADER
  // ═══════════════════════════════════════════════════════════
  Widget _header() {
    final t = S.of(context);
    return MerchantTopBar(
      title: t.t('my_menu'),
      subtitle: t.t('manage_products'),
      actions: [
        ElevatedButton.icon(
          onPressed: () => _openEditor(),
          icon: const Icon(Icons.add, size: 18),
          label: Text(t.t('add_product'),
              style: const TextStyle(
                  fontSize: 15, fontWeight: FontWeight.w800)),
          style: ElevatedButton.styleFrom(
            backgroundColor: EfuridePalette.accent,
            foregroundColor: EfuridePalette.accentInk,
            elevation: 0,
            minimumSize: const Size(0, 44),
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12)),
          ),
        ),
      ],
    );
  }

  // ═══════════════════════════════════════════════════════════
  // EMPTY STATE
  // ═══════════════════════════════════════════════════════════
  Widget _emptyState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 90,
              height: 90,
              decoration: BoxDecoration(
                color: EfuridePalette.merchantAccent
                    .withValues(alpha: 0.12),
                shape: BoxShape.circle,
              ),
              child: const Icon(Icons.restaurant_menu_outlined,
                  size: 44, color: EfuridePalette.merchantAccent),
            ),
            const SizedBox(height: 16),
            Text(_t('no_products'),
                style: const TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.w800,
                    color: EfuridePalette.ink)),
            const SizedBox(height: 4),
            Text(_t('add_first_product'),
                textAlign: TextAlign.center,
                style: const TextStyle(
                    fontSize: 13.5, color: EfuridePalette.inkMuted)),
            const SizedBox(height: 20),
            ElevatedButton.icon(
              onPressed: () => _openEditor(),
              icon: const Icon(Icons.add, size: 18),
              label: Text(_t('add_product'),
                  style: const TextStyle(
                      fontSize: 14, fontWeight: FontWeight.w900)),
              style: ElevatedButton.styleFrom(
                backgroundColor: EfuridePalette.merchantAccent,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(
                    horizontal: 20, vertical: 14),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12)),
                elevation: 0,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // PRODUCT CARD
  // ═══════════════════════════════════════════════════════════
  Widget _productCard(MerchantProduct p) {
    final busy = _busy.contains(p.id);
    final lowStock = p.stockLeft != null && p.stockLeft! <= 3;

    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
          color: p.isAvailable
              ? EfuridePalette.divider
              : EfuridePalette.inkMuted.withValues(alpha: 0.3),
        ),
      ),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Row(
          children: [
            // Image / emoji
            Container(
              width: 60,
              height: 60,
              decoration: BoxDecoration(
                color: EfuridePalette.merchantAccent
                    .withValues(alpha: 0.10),
                borderRadius: BorderRadius.circular(10),
              ),
              clipBehavior: Clip.antiAlias,
              child: p.imageUrl != null && p.imageUrl!.isNotEmpty
                  ? Image.network(
                      p.imageUrl!,
                      fit: BoxFit.cover,
                      errorBuilder: (_, __, ___) =>
                          _emojiOrIcon(p.emoji),
                    )
                  : _emojiOrIcon(p.emoji),
            ),
            const SizedBox(width: 12),

            // Middle: name, price, meta
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          p.name,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w800,
                            color: p.isAvailable
                                ? EfuridePalette.ink
                                : EfuridePalette.inkMuted,
                          ),
                        ),
                      ),
                      if (p.isFeatured)
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 6, vertical: 2),
                          decoration: BoxDecoration(
                            color: EfuridePalette.accent
                                .withValues(alpha: 0.15),
                            borderRadius: BorderRadius.circular(4),
                          ),
                          child: const Icon(Icons.star,
                              size: 12, color: EfuridePalette.accent),
                        ),
                    ],
                  ),
                  if ((p.description ?? '').isNotEmpty) ...[
                    const SizedBox(height: 2),
                    Text(
                      p.description!,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                          fontSize: 13,
                          color: EfuridePalette.inkMuted),
                    ),
                  ],
                  const SizedBox(height: 4),
                  Row(
                    children: [
                      Text(
                        CountryConfig.money(p.price),
                        style: const TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w900,
                          color: EfuridePalette.merchantAccent,
                        ),
                      ),
                      const SizedBox(width: 10),
                      if (p.stockLeft != null)
                        Text(
                          '${p.stockLeft} ${_t('left_suffix')}',
                          style: TextStyle(
                            fontSize: 13,
                            fontWeight: FontWeight.w700,
                            color: lowStock
                                ? EfuridePalette.dropoff
                                : EfuridePalette.inkMuted,
                          ),
                        )
                      else
                        Text(_t('stock_unlimited'),
                            style: const TextStyle(
                                fontSize: 13,
                                color: EfuridePalette.inkMuted,
                                fontWeight: FontWeight.w600)),
                    ],
                  ),
                ],
              ),
            ),

            // Right: actions
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                if (busy)
                  const SizedBox(
                    width: 24,
                    height: 24,
                    child: CircularProgressIndicator(
                      strokeWidth: 2,
                      color: EfuridePalette.merchantAccent,
                    ),
                  )
                else
                  Switch.adaptive(
                    value: p.isAvailable,
                    activeColor: EfuridePalette.onlineDeep,
                    onChanged: (_) => _toggleAvailability(p),
                  ),
                const SizedBox(height: 2),
                Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    _iconBtn(
                      icon: Icons.edit_outlined,
                      onTap: busy
                          ? null
                          : () => _openEditor(existing: p),
                    ),
                    const SizedBox(width: 4),
                    _iconBtn(
                      icon: Icons.delete_outline,
                      color: EfuridePalette.dropoff,
                      onTap: busy ? null : () => _confirmDelete(p),
                    ),
                  ],
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _emojiOrIcon(String? emoji) {
    if (emoji != null && emoji.isNotEmpty) {
      return Center(
        child: Text(emoji, style: const TextStyle(fontSize: 30)),
      );
    }
    return const Center(
      child: Icon(Icons.fastfood,
          size: 26, color: EfuridePalette.merchantAccent),
    );
  }

  Widget _iconBtn({
    required IconData icon,
    Color? color,
    required VoidCallback? onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(8),
      child: Container(
        width: 32,
        height: 32,
        decoration: BoxDecoration(
          color: (color ?? EfuridePalette.inkMuted)
              .withValues(alpha: 0.08),
          borderRadius: BorderRadius.circular(8),
        ),
        child: Icon(icon,
            size: 16, color: color ?? EfuridePalette.inkMuted),
      ),
    );
  }
}

// ══════════════════════════════════════════════════════════════
// PRODUCT EDITOR SHEET
// ══════════════════════════════════════════════════════════════
class _ProductEditorSheet extends StatefulWidget {
  final MerchantProduct? existing;
  const _ProductEditorSheet({this.existing});

  @override
  State<_ProductEditorSheet> createState() => _ProductEditorSheetState();
}

class _ProductEditorSheetState extends State<_ProductEditorSheet> {
  String _t(String key) => S.of(context).t(key);

  final _nameCtrl = TextEditingController();
  final _descCtrl = TextEditingController();
  final _categoryCtrl = TextEditingController();
  final _priceCtrl = TextEditingController();
  final _prepCtrl = TextEditingController();
  final _stockCtrl = TextEditingController();
  final _emojiCtrl = TextEditingController();

  XFile? _pickedImage;
  String? _uploadedImageUrl;
  bool _uploadingImage = false;
  bool _submitting = false;

  bool _isAvailable = true;
  bool _isFeatured = false;

  @override
  void initState() {
    super.initState();
    final e = widget.existing;
    if (e != null) {
      _nameCtrl.text = e.name;
      _descCtrl.text = e.description ?? '';
      _categoryCtrl.text = e.category ?? '';
      _priceCtrl.text = e.price.toStringAsFixed(0);
      _prepCtrl.text = e.prepMinutes.toString();
      _stockCtrl.text = e.stockLeft?.toString() ?? '';
      _emojiCtrl.text = e.emoji ?? '';
      _uploadedImageUrl = e.imageUrl;
      _isAvailable = e.isAvailable;
      _isFeatured = e.isFeatured;
    } else {
      _prepCtrl.text = '10';
    }
  }

  @override
  void dispose() {
    _nameCtrl.dispose();
    _descCtrl.dispose();
    _categoryCtrl.dispose();
    _priceCtrl.dispose();
    _prepCtrl.dispose();
    _stockCtrl.dispose();
    _emojiCtrl.dispose();
    super.dispose();
  }

  Future<void> _pickImage() async {
    final f = await pickPhotoLiveOrGallery(context,
        maxWidth: 1200, imageQuality: 75);
    if (f == null) return;
    setState(() {
      _pickedImage = f;
      // Clear any previously uploaded URL so preview shows the new pick.
      _uploadedImageUrl = null;
    });
  }

  /// Upload the picked image. Returns the public URL on success,
  /// throws on failure. Caller decides what to do.
  Future<String> _uploadPickedImage() async {
    final partnerId = await MerchantService.instance.getPartnerId();
    if (partnerId == null) {
      throw StateError('No partner account');
    }

    final url = await StorageService.instance.uploadProductImage(
      partnerId: partnerId,
      productId: widget.existing?.id ??
          'new-${DateTime.now().millisecondsSinceEpoch}',
      file: _pickedImage!,
    );

    if (url == null || url.isEmpty) {
      throw StateError(StorageService.instance.lastUploadError ??
          'Image upload failed');
    }
    return url;
  }

  /// Fired by the small "Upload image" button — keeps the manual
  /// option for merchants who want to preview before saving.
  Future<void> _uploadIfNeeded() async {
    if (_pickedImage == null || _uploadingImage) return;

    setState(() => _uploadingImage = true);
    try {
      final url = await _uploadPickedImage();
      if (!mounted) return;
      setState(() => _uploadedImageUrl = url);
    } catch (e) {
      if (!mounted) return;
      ErrorUI.showSnack(context, AppError.from(e));
    } finally {
      if (mounted) setState(() => _uploadingImage = false);
    }
  }

  Future<void> _submit() async {
    if (_submitting) return;

    final name = _nameCtrl.text.trim();
    final price = double.tryParse(_priceCtrl.text.trim());
    if (name.isEmpty || price == null || price <= 0) {
      await showDialog<void>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: Text(_t('missing_info')),
          content: Text(_t('enter_name_price')),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: Text(tr('OK')),
            ),
          ],
        ),
      );
      return;
    }

    setState(() => _submitting = true);

    try {
      // ✅ FIX: if the merchant picked an image but never tapped
      // the small "Upload image" button, upload it now — before
      // sending the form.
      String? imageUrl = _uploadedImageUrl;
      if (imageUrl == null && _pickedImage != null) {
        try {
          imageUrl = await _uploadPickedImage();
        } catch (e) {
          // Show why, in front of the form, and let the merchant save
          // the product without the picture instead of getting stuck.
          if (!mounted) return;
          final saveAnyway = await showDialog<bool>(
            context: context,
            builder: (ctx) => AlertDialog(
              title: Text(tr('The picture could not be uploaded')),
              content: Text(
                tr('{0}\n\nYou can save the product now and add the picture later.',
                    [tr(e is StateError
                        ? e.message
                        : 'The picture could not be saved. Please try again.')]),
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(ctx, false),
                  child: Text(_t('cancel')),
                ),
                ElevatedButton(
                  onPressed: () => Navigator.pop(ctx, true),
                  child: Text(tr('Save without picture')),
                ),
              ],
            ),
          );
          if (saveAnyway != true) {
            if (mounted) setState(() => _submitting = false);
            return;
          }
          imageUrl = null;
        }
      }

      final prep = int.tryParse(_prepCtrl.text.trim()) ?? 10;
      final stockRaw = _stockCtrl.text.trim();
      final stock = stockRaw.isEmpty ? null : int.tryParse(stockRaw);

      if (!mounted) return;
      Navigator.pop(context, {
        'name': name,
        'description': _descCtrl.text.trim().isEmpty
            ? null
            : _descCtrl.text.trim(),
        'category': _categoryCtrl.text.trim().isEmpty
            ? null
            : _categoryCtrl.text.trim(),
        'price': price,
        // Keep only emoji characters (letters typed by mistake are dropped).
        'emoji': _onlyEmoji(_emojiCtrl.text),
        'image_url': imageUrl,
        'prep_minutes': prep,
        'stock_left': stock,
        'is_available': _isAvailable,
        'is_featured': _isFeatured,
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => _submitting = false);
      // A dialog, not a snackbar: snackbars end up hidden behind this sheet.
      final err = AppError.from(e);
      await showDialog<void>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: Text(err.title),
          content: Text(err.message),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: Text(tr('OK')),
            ),
          ],
        ),
      );
    }
  }

  static String? _onlyEmoji(String raw) {
    final kept = raw.runes
        .where((r) => r > 0x2000) // emoji & symbols, not a–z / 0–9
        .map(String.fromCharCode)
        .join()
        .trim();
    if (kept.isEmpty) return null;
    return kept.runes.length > 4
        ? String.fromCharCodes(kept.runes.take(4))
        : kept;
  }

  @override
  Widget build(BuildContext context) {
    final isEdit = widget.existing != null;
    return Padding(
      padding: EdgeInsets.only(
        left: 20,
        right: 20,
        top: 16,
        bottom: MediaQuery.of(context).viewInsets.bottom + 24,
      ),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Center(
              child: Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                  color: Colors.grey.shade300,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
            ),
            const SizedBox(height: 18),
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: EfuridePalette.merchantAccent
                        .withValues(alpha: 0.12),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Icon(
                    isEdit
                        ? Icons.edit_outlined
                        : Icons.add_business_outlined,
                    color: EfuridePalette.merchantAccent,
                    size: 20,
                  ),
                ),
                const SizedBox(width: 12),
                Text(
                  isEdit ? _t('edit_product') : _t('add_product'),
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w900,
                    color: EfuridePalette.ink,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 20),

            // Image picker
            GestureDetector(
              onTap: _submitting ? null : _pickImage,
              child: Container(
                height: 130,
                decoration: BoxDecoration(
                  color: EfuridePalette.cream,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: EfuridePalette.divider),
                ),
                clipBehavior: Clip.antiAlias,
                child: _pickedImage != null
                    ? FutureBuilder(
                        future: _pickedImage!.readAsBytes(),
                        builder: (_, snap) {
                          if (!snap.hasData) {
                            return const Center(
                              child: CircularProgressIndicator(
                                  strokeWidth: 2),
                            );
                          }
                          return Image.memory(
                            snap.data!,
                            fit: BoxFit.cover,
                            width: double.infinity,
                          );
                        },
                      )
                    : _uploadedImageUrl != null &&
                            _uploadedImageUrl!.isNotEmpty
                        ? Image.network(
                            _uploadedImageUrl!,
                            fit: BoxFit.cover,
                            width: double.infinity,
                            errorBuilder: (_, __, ___) =>
                                _imagePlaceholder(),
                          )
                        : _imagePlaceholder(),
              ),
            ),
            const SizedBox(height: 10),
            if (_pickedImage != null && _uploadedImageUrl == null)
              TextButton.icon(
                onPressed:
                    (_uploadingImage || _submitting) ? null : _uploadIfNeeded,
                icon: _uploadingImage
                    ? const SizedBox(
                        width: 16,
                        height: 16,
                        child:
                            CircularProgressIndicator(strokeWidth: 2),
                      )
                    : const Icon(Icons.cloud_upload_outlined, size: 16),
                label: Text(_t('upload_image')),
              ),

            const SizedBox(height: 14),

            _field(_nameCtrl, _t('product_name'),
                capitalization: TextCapitalization.words),
            const SizedBox(height: 10),
            _field(_descCtrl, _t('short_description'), maxLines: 2),
            const SizedBox(height: 10),

            Row(
              children: [
                Expanded(
                  child: _field(_categoryCtrl, _t('category'),
                      capitalization: TextCapitalization.words),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: _field(_emojiCtrl, _t('emoji_label')),
                ),
              ],
            ),
            const SizedBox(height: 10),

            Row(
              children: [
                Expanded(
                  child: _field(_priceCtrl, _t('price_xaf'),
                      keyboard: TextInputType.number),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: _field(_prepCtrl, _t('prep_min'),
                      keyboard: TextInputType.number),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: _field(_stockCtrl, _t('stock_hint_short'),
                      keyboard: TextInputType.number),
                ),
              ],
            ),

            const SizedBox(height: 12),
            _switchRow(
              icon: Icons.visibility_outlined,
              title: _t('available_for_ordering'),
              value: _isAvailable,
              onChanged: (v) => setState(() => _isAvailable = v),
            ),
            _switchRow(
              icon: Icons.star_outline,
              title: _t('feature_item'),
              value: _isFeatured,
              onChanged: (v) => setState(() => _isFeatured = v),
            ),

            const SizedBox(height: 20),

            Row(
              children: [
                Expanded(
                  child: OutlinedButton(
                    onPressed: _submitting
                        ? null
                        : () => Navigator.pop(context),
                    style: OutlinedButton.styleFrom(
                      minimumSize: const Size(0, 52),
                      foregroundColor: EfuridePalette.ink,
                      side: const BorderSide(
                          color: EfuridePalette.divider),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12)),
                    ),
                    child: Text(_t('cancel')),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  flex: 2,
                  child: ElevatedButton(
                    onPressed: _submitting ? null : _submit,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: EfuridePalette.merchantAccent,
                      foregroundColor: Colors.white,
                      minimumSize: const Size(0, 52),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12)),
                      elevation: 0,
                    ),
                    child: _submitting
                        ? const SizedBox(
                            width: 20,
                            height: 20,
                            child: CircularProgressIndicator(
                                strokeWidth: 2, color: Colors.white),
                          )
                        : Text(
                            isEdit
                                ? _t('save_changes')
                                : _t('add_product'),
                            style: const TextStyle(
                                fontSize: 15,
                                fontWeight: FontWeight.w900),
                          ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _imagePlaceholder() {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        const Icon(Icons.add_photo_alternate_outlined,
            size: 36, color: EfuridePalette.inkMuted),
        const SizedBox(height: 6),
        Text(_t('upload_image_hint'),
            style: const TextStyle(
                fontSize: 13.5, color: EfuridePalette.inkMuted)),
      ],
    );
  }

  Widget _field(
    TextEditingController ctrl,
    String label, {
    TextInputType? keyboard,
    int maxLines = 1,
    TextCapitalization capitalization = TextCapitalization.none,
  }) {
    return TextField(
      controller: ctrl,
      keyboardType: keyboard,
      maxLines: maxLines,
      textCapitalization: capitalization,
      decoration: InputDecoration(
        labelText: label,
        filled: true,
        fillColor: EfuridePalette.cream,
        contentPadding:
            const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide.none,
        ),
      ),
    );
  }

  Widget _switchRow({
    required IconData icon,
    required String title,
    required bool value,
    required ValueChanged<bool> onChanged,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          Icon(icon, size: 18, color: EfuridePalette.merchantAccent),
          const SizedBox(width: 10),
          Expanded(
            child: Text(title,
                style: const TextStyle(
                    fontSize: 14.5,
                    fontWeight: FontWeight.w700,
                    color: EfuridePalette.ink)),
          ),
          Switch.adaptive(
            value: value,
            activeColor: EfuridePalette.merchantAccent,
            onChanged: onChanged,
          ),
        ],
      ),
    );
  }
}
