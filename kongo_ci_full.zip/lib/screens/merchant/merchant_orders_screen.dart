// lib/screens/merchant/merchant_orders_screen.dart
//
// The merchant's action surface. Every order shows exactly ONE
// prominent button — the next step in the workflow.
//
//   pending     → Accept / Reject
//   confirmed   → Start preparing
//   preparing   → Mark ready for pickup
//   ready       → Scan driver QR to hand off
//   picked_up / in_transit / delivered / cancelled → no action

import 'dart:async';
import 'package:flutter/material.dart';
import 'package:efuride_app/widgets/merchant_top_bar.dart';
import 'package:efuride_app/config/country_config.dart';
import 'package:efuride_app/config/efuride_palette.dart';
import 'package:efuride_app/l10n/app_strings.dart';
import 'package:efuride_app/services/merchant_service.dart';
import 'package:efuride_app/utils/app_error.dart';
import 'package:efuride_app/utils/error_ui.dart';
import 'package:efuride_app/widgets/k_icon.dart';

class MerchantOrdersScreen extends StatefulWidget {
  const MerchantOrdersScreen({super.key});

  @override
  State<MerchantOrdersScreen> createState() => _MerchantOrdersScreenState();
}

class _MerchantOrdersScreenState extends State<MerchantOrdersScreen> {
  StreamSubscription<List<MerchantOrder>>? _ordersSub;
  List<MerchantOrder> _orders = [];
  bool _loading = true;
  Object? _error;
  String _tab = 'Active';

  // Track per-order in-flight actions so buttons disable while working.
  final Set<String> _busy = {};

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      try {
        await MerchantService.instance.getPartnerId();
        _subscribe();
      } catch (e) {
        if (!mounted) return;
        setState(() { _loading = false; _error = e; });
      }
    });
  }

  @override
  void dispose() {
    _ordersSub?.cancel();
    super.dispose();
  }

  void _subscribe() {
    _ordersSub?.cancel();
    _ordersSub = MerchantService.instance.streamOrders().listen(
      (rows) {
        if (!mounted) return;
        setState(() {
          _orders = rows;
          _loading = false;
          _error = null;
        });
      },
      onError: (e) {
        if (!mounted) return;
        setState(() { _loading = false; _error = e; });
      },
    );
  }

  List<MerchantOrder> get _filtered {
    switch (_tab) {
      case 'Active':
        return _orders.where((o) => o.isActive).toList();
      case 'Completed':
        return _orders.where((o) => o.status == 'delivered').toList();
      case 'Cancelled':
        return _orders.where((o) => o.status == 'cancelled').toList();
      default:
        return _orders;
    }
  }

  int get _incomingCount =>
      _orders.where((o) => o.status == 'pending').length;

  // ══════════════════════════════════════════════════════════════
  // ACTIONS
  // ══════════════════════════════════════════════════════════════

  // ══════════════════════════════════════════════════════════════
  // BUILD
  // ══════════════════════════════════════════════════════════════

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: EfuridePalette.cream,
      body: Column(
      children: [
        _header(),
        Expanded(child: _body()),
      ],
    ),
    );
  }

  Widget _header() {
    return MerchantTopBar(
      title: tr('Orders'),
      subtitle: _incomingCount > 0
          ? tr('{0} new', [_incomingCount])
          : tr('New and active orders'),
    );
  }

  Widget _filterRow() {
    const filters = ['Active', 'Completed', 'Cancelled'];
    return Container(
      padding: const EdgeInsets.all(4),
      decoration: BoxDecoration(
        color: const Color(0xFFEFE8DA),
        borderRadius: BorderRadius.circular(24),
      ),
      child: Row(
        children: filters.map((f) {
          final active = _tab == f;
          return Expanded(
            child: GestureDetector(
              onTap: () => setState(() => _tab = f),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 180),
                padding: const EdgeInsets.symmetric(vertical: 9),
                decoration: BoxDecoration(
                  color: active ? Colors.white : Colors.transparent,
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Text(f,
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 14,
                      fontWeight:
                          active ? FontWeight.w900 : FontWeight.w600,
                      color: active
                          ? EfuridePalette.ink
                          : EfuridePalette.inkMuted,
                    )),
              ),
            ),
          );
        }).toList(),
      ),
    );
  }

  Widget _body() {
    if (_loading) {
      return const Center(
        child: CircularProgressIndicator(
            color: EfuridePalette.merchantAccent),
      );
    }

    if (_error != null) {
      return Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.wifi_off_rounded,
                size: 56, color: Colors.grey.shade400),
            const SizedBox(height: 12),
            Text(tr('Could not load orders'),
                style: TextStyle(
                    fontSize: 15, fontWeight: FontWeight.w700)),
            const SizedBox(height: 8),
            TextButton(onPressed: _subscribe, child: Text(tr('Retry'))),
          ],
        ),
      );
    }

    final list = _filtered;
    if (list.isEmpty) {
      return Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 90, height: 90,
              decoration: BoxDecoration(
                color: EfuridePalette.merchantAccent.withValues(alpha: 0.12),
                shape: BoxShape.circle,
              ),
              child: const KIcon(Icons.receipt_long_outlined,
                  size: 44, color: EfuridePalette.merchantAccent),
            ),
            const SizedBox(height: 16),
            Text(tr('No {0} orders', [_tab]),
                style: const TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.w800,
                    color: EfuridePalette.ink)),
          ],
        ),
      );
    }

    return RefreshIndicator(
      color: EfuridePalette.merchantAccent,
      onRefresh: () async {
        await MerchantService.instance.getPartnerId(refresh: true);
      },
      child: ListView.builder(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
        itemCount: list.length,
        itemBuilder: (_, i) => _orderCard(list[i]),
      ),
    );
  }

  // ══════════════════════════════════════════════════════════════
  // ORDER CARD
  // ══════════════════════════════════════════════════════════════

  Widget _orderCard(MerchantOrder o) {
    final isIncoming = o.status == 'pending';
    final color = _stageColor(o.status);
    final isBusy = _busy.contains(o.id);

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: isIncoming
              ? EfuridePalette.dropoff.withValues(alpha: 0.6)
              : EfuridePalette.divider,
          width: isIncoming ? 1.8 : 1,
        ),
      ),
      child: Column(
        children: [
          // ── Top row: badge + id + time ──
          Padding(
            padding: const EdgeInsets.all(14),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: color.withValues(alpha: 0.12),
                    borderRadius: BorderRadius.circular(6),
                  ),
                  child: Text(_stageLabel(o.status),
                      style: TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w900,
                        color: color,
                        letterSpacing: 0.5,
                      )),
                ),
                const SizedBox(width: 8),
                Text('#${_shortId(o.id)}',
                    style: const TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w800,
                        color: EfuridePalette.ink)),
                const Spacer(),
                Text(_relative(o.createdAt),
                    style: const TextStyle(
                        fontSize: 13, color: EfuridePalette.inkMuted)),
              ],
            ),
          ),

          // ── Workflow banner ──
          if (o.isActive && o.status != 'picked_up' &&
              o.status != 'in_transit')
            Container(
              margin: const EdgeInsets.symmetric(horizontal: 14),
              padding: const EdgeInsets.symmetric(
                  horizontal: 12, vertical: 10),
              decoration: BoxDecoration(
                color: color.withValues(alpha: 0.08),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Row(
                children: [
                  Icon(_nextActionIcon(o.status),
                      size: 16, color: color),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(_nextActionHint(o.status),
                        style: TextStyle(
                          fontSize: 13.5,
                          fontWeight: FontWeight.w700,
                          color: color,
                        )),
                  ),
                ],
              ),
            ),

          // ── Customer + phone ──
          Padding(
            padding: const EdgeInsets.fromLTRB(14, 12, 14, 6),
            child: Row(
              children: [
                Container(
                  width: 32, height: 32,
                  decoration: BoxDecoration(
                    color: EfuridePalette.merchantAccent
                        .withValues(alpha: 0.15),
                    shape: BoxShape.circle,
                  ),
                  child: const KIcon(Icons.person,
                      size: 18, color: EfuridePalette.merchantAccent),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(o.customerName ?? 'Customer',
                          style: const TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.w800)),
                      if (o.customerPhone != null)
                        Text(o.customerPhone!,
                            style: const TextStyle(
                                fontSize: 13,
                                color: EfuridePalette.inkMuted)),
                    ],
                  ),
                ),
              ],
            ),
          ),

          // ── Items ──
          const Divider(height: 1, color: EfuridePalette.divider),
          Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                for (final l in o.lines)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 6),
                    child: Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 6, vertical: 2),
                          decoration: BoxDecoration(
                            color: EfuridePalette.cream,
                            borderRadius: BorderRadius.circular(4),
                          ),
                          child: Text('x${l.qty}',
                              style: const TextStyle(
                                fontSize: 13,
                                fontWeight: FontWeight.w900,
                                color: EfuridePalette.ink,
                              )),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Text(l.name,
                              style: const TextStyle(
                                fontSize: 14,
                                fontWeight: FontWeight.w600,
                              )),
                        ),
                        Text(CountryConfig.money(l.lineTotal),
                            style: const TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.w800,
                            )),
                      ],
                    ),
                  ),
                const SizedBox(height: 6),
                const Divider(height: 1, color: EfuridePalette.divider),
                const SizedBox(height: 8),
                Row(
                  children: [
                    Text(tr('Total'),
                        style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w700,
                          color: EfuridePalette.inkMuted,
                        )),
                    const Spacer(),
                    Text(CountryConfig.money(o.total),
                        style: const TextStyle(
                          fontSize: 15,
                          fontWeight: FontWeight.w900,
                          color: EfuridePalette.ink,
                        )),
                  ],
                ),
              ],
            ),
          ),

          // ── Driver info when assigned ──
          if (o.driverName != null)
            Container(
              margin: const EdgeInsets.fromLTRB(14, 0, 14, 14),
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: EfuridePalette.blue.withValues(alpha: 0.08),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Row(
                children: [
                  const KIcon(Icons.directions_car,
                      size: 16, color: EfuridePalette.blueDeep),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(tr('Driver: {0}', [o.driverName]),
                        style: const TextStyle(
                          fontSize: 13.5,
                          fontWeight: FontWeight.w700,
                          color: EfuridePalette.blueDeep,
                        )),
                  ),
                ],
              ),
            ),

          // ── Action button (the ONLY next action) ──
          Padding(
            padding: const EdgeInsets.fromLTRB(14, 0, 14, 14),
            child: _actionButton(o, isBusy),
          ),
        ],
      ),
    );
  }

  /// Merchants only list products: a shopper buys the order at the
  /// store and a driver delivers it. This line just shows progress.
  Widget _actionButton(MerchantOrder o, bool isBusy) {
    final t = S.of(context);
    IconData icon;
    String key;
    Color color;
    switch (o.status) {
      case 'pending':
      case 'confirmed':
        icon = Icons.hourglass_top;
        key = 'mo_waiting_shopper';
        color = EfuridePalette.merchantAccent;
        break;
      case 'shopping':
      case 'preparing':
        icon = Icons.shopping_basket_outlined;
        key = 'mo_shopper_buying';
        color = EfuridePalette.shopperAccent;
        break;
      case 'ready':
        icon = Icons.inventory_2_outlined;
        key = 'mo_waiting_driver';
        color = EfuridePalette.blue;
        break;
      case 'picked_up':
      case 'in_transit':
        icon = Icons.delivery_dining;
        key = 'mo_on_the_way';
        color = EfuridePalette.blueDeep;
        break;
      case 'returning':
      case 'returned':
        icon = Icons.keyboard_return;
        key = 'mo_returned';
        color = EfuridePalette.dropoff;
        break;
      default:
        return const SizedBox.shrink();
    }
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.08),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color.withValues(alpha: 0.35)),
      ),
      child: Row(
        children: [
          Icon(icon, size: 18, color: color),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              t.t(key),
              style: TextStyle(
                  fontSize: 14, fontWeight: FontWeight.w700, color: color),
            ),
          ),
        ],
      ),
    );
  }

  // ══════════════════════════════════════════════════════════════
  // HELPERS
  // ══════════════════════════════════════════════════════════════

  String _shortId(String id) =>
      id.length >= 8 ? id.substring(0, 8) : id;

  Color _stageColor(String s) {
    switch (s) {
      case 'pending':   return EfuridePalette.dropoff;
      case 'confirmed':
      case 'preparing': return EfuridePalette.merchantAccent;
      case 'shopping':  return EfuridePalette.shopperAccent;
      case 'ready':     return EfuridePalette.accent;
      case 'picked_up':
      case 'in_transit':return EfuridePalette.blueDeep;
      case 'delivered': return EfuridePalette.online;
      default:          return EfuridePalette.inkMuted;
    }
  }

  String _stageLabel(String s) {
    switch (s) {
      case 'pending':   return 'NEW';
      case 'confirmed': return 'CONFIRMED';
      case 'preparing': return 'PREPARING';
      case 'shopping':  return 'SHOPPING';
      case 'ready':     return 'READY';
      case 'picked_up': return 'PICKED UP';
      case 'in_transit':return 'IN TRANSIT';
      case 'delivered': return 'DELIVERED';
      case 'cancelled': return 'CANCELLED';
      default:          return s.toUpperCase();
    }
  }

  IconData _nextActionIcon(String s) {
    switch (s) {
      case 'pending':   return Icons.info_outline;
      case 'confirmed': return Icons.outdoor_grill_outlined;
      case 'preparing':
      case 'shopping':  return Icons.check_circle_outline;
      case 'ready':     return Icons.qr_code_scanner;
      default:          return Icons.info_outline;
    }
  }

  String _nextActionHint(String s) {
    switch (s) {
      case 'pending':   return 'Accept or reject this order.';
      case 'confirmed': return 'Start preparing the order.';
      case 'preparing':
      case 'shopping':  return 'Mark ready once packed for pickup.';
      case 'ready':     return 'Waiting for a driver. Scan on handoff.';
      default:          return '';
    }
  }

  String _relative(DateTime t) {
    final d = DateTime.now().difference(t);
    if (d.inMinutes < 1) return 'just now';
    if (d.inMinutes < 60) return '${d.inMinutes}m ago';
    if (d.inHours < 24) return '${d.inHours}h ago';
    return '${d.inDays}d ago';
  }
}
