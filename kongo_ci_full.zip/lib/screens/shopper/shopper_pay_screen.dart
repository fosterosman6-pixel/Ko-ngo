// lib/screens/shopper/shopper_pay_screen.dart
//
// Shopper pay. Shows current-week earnings from loadStats(), hourly
// rate, bonus, rating, and recent payouts from loadPayouts().
//
// i18n-clean · currency-clean · real data (no mocks).

import 'dart:async';
import 'package:flutter/material.dart';
import 'package:efuride_app/config/efuride_palette.dart';
import 'package:efuride_app/config/country_config.dart';
import 'package:efuride_app/widgets/incentives_card.dart';
import 'package:efuride_app/l10n/app_strings.dart';
import 'package:efuride_app/services/pricing_service.dart';
import 'package:efuride_app/services/shopper_service.dart';
import 'package:efuride_app/services/wallet_service.dart';
import 'package:efuride_app/utils/money.dart';
import 'package:efuride_app/widgets/wallet/payout_sheet.dart';
import 'package:efuride_app/utils/app_error.dart';
import 'package:efuride_app/utils/error_ui.dart';
import 'package:efuride_app/widgets/k_icon.dart';

class ShopperPayScreen extends StatefulWidget {
  const ShopperPayScreen({super.key});

  @override
  State<ShopperPayScreen> createState() => _ShopperPayScreenState();
}

class _ShopperPayScreenState extends State<ShopperPayScreen>
    with WidgetsBindingObserver {
  String _t(String key) => S.of(context).t(key);
  String _tf(String key, Map<String, Object> args) =>
      S.of(context).tf(key, args);

  ShopperStats? _stats;
  List<ShopperPayout> _payouts = [];

  /// Server wallet (step 21): real earnings per finished task.
  MyWallet? _w;
  List<Map<String, dynamic>> _lines = [];
  bool _loading = true;
  AppError? _error;

  @override
  void initState() {
    super.initState();
    PricingService.changes.addListener(_onPricesChanged);
    WidgetsBinding.instance.addObserver(this);
    _load();
  }

  void _onPricesChanged() {
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    PricingService.changes.removeListener(_onPricesChanged);
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final results = await Future.wait([
        ShopperService.instance.loadStats(),
        ShopperService.instance.loadPayouts(),
        PricingService.current(), // hourly rate for this country
      ]);
      MyWallet? w;
      List<Map<String, dynamic>> lines = [];
      List<ShopperPayout> payouts = results[1] as List<ShopperPayout>;
      try {
        w = await WalletService.myWallet();
        lines = await WalletService.listLines('shopping', limit: 20);
        // Payout requests (same as drivers and stores) as payout rows.
        final reqs = await WalletService.listMyPayouts();
        payouts = [
          for (final r in reqs)
            ShopperPayout.fromMap({
              'id': (r['id'] ?? '').toString(),
              'period_start': r['created_at'],
              'period_end': r['paid_at'] ?? r['created_at'],
              'net_payout': r['amount'],
              'status': r['status'],
              'reference': r['bank_name'],
              'paid_at': r['paid_at'],
            }),
          ...payouts,
        ];
      } catch (_) {
        w = null;
      }
      if (!mounted) return;
      setState(() {
        _stats = results[0] as ShopperStats;
        _payouts = payouts;
        _w = w;
        _lines = lines;
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _error = AppError.from(e, onRetry: _load);
      });
    }
  }

  // ═══════════════════════════════════════════════════════════
  // BUILD
  // ═══════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        _header(),
        Expanded(
          child: _loading
              ? const Center(
                  child: CircularProgressIndicator(
                      color: EfuridePalette.shopperAccent))
              : _error != null
                  ? ErrorUI.inline(_error!)
                  : RefreshIndicator(
                      color: EfuridePalette.shopperAccent,
                      onRefresh: _load,
                      child: ListView(
                        padding:
                            const EdgeInsets.fromLTRB(16, 16, 16, 24),
                        physics: const AlwaysScrollableScrollPhysics(),
                        children: [
                          const IncentivesCard(tasks: true),
                          _w != null ? _walletCard() : _weekCard(),
                          const SizedBox(height: 16),
                          _statRow(),
                          if (_lines.isNotEmpty) ...[
                            const SizedBox(height: 20),
                            _earningsSection(),
                          ],
                          const SizedBox(height: 20),
                          _recentPayoutsSection(),
                          const SizedBox(height: 20),
                          _howItWorksCard(),
                          const SizedBox(height: 24),
                        ],
                      ),
                    ),
        ),
      ],
    );
  }

  // ═══════════════════════════════════════════════════════════
  // HEADER
  // ═══════════════════════════════════════════════════════════
  /// Plain title row (no banner): page name, what it covers, refresh.
  Widget _header() {
    return Container(
      color: EfuridePalette.cream,
      child: SafeArea(
        bottom: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 14, 8, 6),
          child: Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(_t('my_pay'),
                        style: const TextStyle(
                          color: EfuridePalette.ink,
                          fontSize: 24,
                          fontWeight: FontWeight.w800,
                        )),
                    const SizedBox(height: 2),
                    Text(_t('hourly_plus_bonus'),
                        style: const TextStyle(
                            color: EfuridePalette.inkMuted, fontSize: 15)),
                  ],
                ),
              ),
              IconButton(
                tooltip: tr('Refresh'),
                onPressed: _load,
                icon: const Icon(Icons.refresh, color: EfuridePalette.ink),
              ),
            ],
          ),
        ),
      ),
    );
  }

  double get _hourlyRate => PricingService.last.shopperHourlyRate;

  // ═══════════════════════════════════════════════════════════
  // WEEK CARD
  // ═══════════════════════════════════════════════════════════
  Widget _weekCard() {
    final s = _stats;
    final gross = (s?.hoursThisWeek ?? 0) * _hourlyRate;
    final bonus = s?.qualityBonusThisWeek ?? 0;
    final net = gross + bonus;
    final hours = s?.hoursThisWeek ?? 0;

    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: EfuridePalette.divider),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: EfuridePalette.shopperAccent.withValues(alpha: 0.12),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: const KIcon(Icons.payments_outlined,
                    color: EfuridePalette.shopperAccent, size: 20),
              ),
              const SizedBox(width: 10),
              Text(_t('this_week_earnings'),
                  style: const TextStyle(
                    color: EfuridePalette.ink,
                    fontSize: 14.5,
                    fontWeight: FontWeight.w800,
                  )),
              const Spacer(),
              Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: EfuridePalette.shopperAccent.withValues(alpha: 0.12),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Text(_t('pending_label'),
                    style: const TextStyle(
                      color: EfuridePalette.ink,
                      fontSize: 13,
                      fontWeight: FontWeight.w800,
                      letterSpacing: 0.4,
                    )),
              ),
            ],
          ),
          const SizedBox(height: 14),
          Text(CountryConfig.money(net),
              style: const TextStyle(
                color: EfuridePalette.ink,
                fontSize: 32,
                fontWeight: FontWeight.w900,
                letterSpacing: -0.5,
                height: 1.0,
              )),
          const SizedBox(height: 6),
          Text(
            '${_t('gross_label')} ${CountryConfig.money(gross)} · '
            '${_t('bonus_earned')} ${CountryConfig.money(bonus)}',
            style: const TextStyle(
              color: EfuridePalette.inkMuted,
              fontSize: 13.5,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 14),
          Container(
            padding: const EdgeInsets.symmetric(
                horizontal: 12, vertical: 10),
            decoration: BoxDecoration(
              color: EfuridePalette.greyBg,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Row(
              children: [
                const KIcon(Icons.schedule,
                    color: EfuridePalette.inkMuted, size: 18),
                const SizedBox(width: 8),
                Text(
                  '${hours.toStringAsFixed(1)}h ${_t('hours_online')}',
                  style: const TextStyle(
                    color: EfuridePalette.ink,
                    fontSize: 14,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const Spacer(),
                Text(_t('paid_friday'),
                    style: const TextStyle(
                      color: EfuridePalette.inkMuted,
                      fontSize: 13,
                      fontWeight: FontWeight.w600,
                    )),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // WALLET CARD (real money from the server)
  // ═══════════════════════════════════════════════════════════
  Widget _walletCard() {
    final w = _w!;
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: EfuridePalette.divider),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(_t('this_week_earnings'),
              style: const TextStyle(
                  color: EfuridePalette.inkMuted,
                  fontSize: 14.5,
                  fontWeight: FontWeight.w700)),
          const SizedBox(height: 6),
          Text(CountryConfig.money(w.earnedThisWeek),
              style: const TextStyle(
                  color: EfuridePalette.ink,
                  fontSize: 32,
                  fontWeight: FontWeight.w900,
                  height: 1.0)),
          const SizedBox(height: 8),
          Text(
            tr('Available {0} · Waiting payouts {1}',
                [CountryConfig.money(w.available), CountryConfig.money(w.held)]),
            style: const TextStyle(
                color: EfuridePalette.inkMuted, fontSize: 14),
          ),
          const SizedBox(height: 14),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: () async {
                final sent = await showPayoutSheet(context, w.available);
                if (sent) _load();
              },
              icon: const KIcon(Icons.account_balance),
              label: Text(tr('Request payout'),
                  style: const TextStyle(
                      fontSize: 16, fontWeight: FontWeight.w800)),
              style: ElevatedButton.styleFrom(
                backgroundColor: EfuridePalette.accent,
                foregroundColor: EfuridePalette.accentInk,
                minimumSize: const Size(0, 50),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14)),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _earningsSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(left: 4, bottom: 10),
          child: Text(tr('Earnings'),
              style: const TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w800,
                  color: EfuridePalette.ink)),
        ),
        Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: EfuridePalette.divider),
          ),
          child: Column(
            children: [
              for (final l in _lines)
                ListTile(
                  dense: true,
                  leading: const Icon(Icons.shopping_basket_outlined,
                      color: EfuridePalette.ink),
                  title: Text(WalletService.lineText(l),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontSize: 13.5)),
                  subtitle: Text(fmtDate(l['created_at']),
                      style: const TextStyle(fontSize: 12.5)),
                  trailing: Text(
                    '+${CountryConfig.money((l['amount'] as num?)?.toDouble() ?? 0)}',
                    style: const TextStyle(
                        fontWeight: FontWeight.w800,
                        color: Color(0xFF15803D)),
                  ),
                ),
            ],
          ),
        ),
      ],
    );
  }

  // ═══════════════════════════════════════════════════════════
  // STAT ROW
  // ═══════════════════════════════════════════════════════════
  Widget _statRow() {
    final s = _stats;
    // IntrinsicHeight: all three tiles the same height.
    return IntrinsicHeight(
      child: Row(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        _statTile(
          icon: Icons.schedule,
          label: _t('hourly_rate'),
          value: CountryConfig.money(_hourlyRate),
        ),
        const SizedBox(width: 10),
        _statTile(
          icon: Icons.star_outline,
          label: _t('bonus_earned'),
          value: CountryConfig.money(s?.qualityBonusThisWeek ?? 0),
        ),
        const SizedBox(width: 10),
        _statTile(
          icon: Icons.thumb_up_outlined,
          label: _t('sh_rating'),
          value: (s?.rating ?? 5.0).toStringAsFixed(1),
        ),
      ],
      ),
    );
  }

  Widget _statTile({
    required IconData icon,
    required String label,
    required String value,
  }) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: EfuridePalette.divider),
        ),
        child: Column(
          children: [
            Icon(icon, size: 18, color: EfuridePalette.shopperAccent),
            const SizedBox(height: 8),
            FittedBox(
              fit: BoxFit.scaleDown,
              child: Text(value,
                  style: const TextStyle(
                      fontSize: 17,
                      fontWeight: FontWeight.w900,
                      color: EfuridePalette.ink)),
            ),
            const SizedBox(height: 4),
            Text(label,
                textAlign: TextAlign.center,
                maxLines: 3,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                    fontSize: 14, color: EfuridePalette.inkMuted)),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // RECENT PAYOUTS
  // ═══════════════════════════════════════════════════════════
  Widget _recentPayoutsSection() {
    if (_payouts.isEmpty) {
      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.only(left: 4, bottom: 10),
            child: Text(_t('recent_payouts'),
                style: const TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w800,
                    color: EfuridePalette.ink)),
          ),
          Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: EfuridePalette.divider),
            ),
            child: Column(
              children: [
                KIcon(Icons.receipt_long_outlined,
                    size: 40, color: Colors.grey.shade400),
                const SizedBox(height: 10),
                Text(
                  _t('no_payouts_yet'),
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w700,
                    color: EfuridePalette.inkMuted,
                  ),
                ),
              ],
            ),
          ),
        ],
      );
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(left: 4, bottom: 10),
          child: Text(_t('recent_payouts'),
              style: const TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w800,
                  color: EfuridePalette.ink)),
        ),
        Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: EfuridePalette.divider),
          ),
          child: Column(
            children: List.generate(_payouts.length, (i) {
              final p = _payouts[i];
              return Column(
                children: [
                  _payoutRow(p),
                  if (i < _payouts.length - 1)
                    const Divider(
                      height: 1,
                      indent: 14,
                      endIndent: 14,
                      color: EfuridePalette.divider,
                    ),
                ],
              );
            }),
          ),
        ),
      ],
    );
  }

  Widget _payoutRow(ShopperPayout p) {
    final statusColor = _statusColor(p.status);
    final statusLabel = _statusLabel(p.status);

    return Padding(
      padding: const EdgeInsets.all(14),
      child: Row(
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: statusColor.withValues(alpha: 0.12),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(
              p.status == 'paid'
                  ? Icons.check_circle_outline
                  : p.status == 'failed'
                      ? Icons.error_outline
                      : Icons.hourglass_empty,
              color: statusColor,
              size: 20,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(
                        color: statusColor.withValues(alpha: 0.12),
                        borderRadius: BorderRadius.circular(4),
                      ),
                      child: Text(
                        statusLabel,
                        style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 0.5,
                          color: statusColor,
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Flexible(
                      child: Text(
                        _payoutRefLabel(p),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w800,
                          color: EfuridePalette.ink,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 3),
                Text(
                  _periodLabel(p.periodStart, p.periodEnd),
                  style: const TextStyle(
                      fontSize: 13, color: EfuridePalette.inkMuted),
                ),
              ],
            ),
          ),
          const SizedBox(width: 8),
          Text(
            CountryConfig.money(p.netPayout),
            style: const TextStyle(
              fontSize: 14.5,
              fontWeight: FontWeight.w900,
              color: EfuridePalette.ink,
            ),
          ),
        ],
      ),
    );
  }

  String _payoutRefLabel(ShopperPayout p) {
    final ref = p.reference?.trim() ?? '';
    if (ref.isEmpty) return '#${p.id.substring(0, 6).toUpperCase()}';
    return ref;
  }

  String _periodLabel(DateTime a, DateTime b) {
    String fmt(DateTime d) => '${d.day}/${d.month}';
    return '${fmt(a)} – ${fmt(b)}';
  }

  Color _statusColor(String s) {
    switch (s) {
      case 'paid':       return EfuridePalette.online;
      case 'failed':     return EfuridePalette.dropoff;
      case 'processing': return EfuridePalette.blueDeep;
      case 'pending':
      default:           return EfuridePalette.merchantAccent;
    }
  }

  String _statusLabel(String s) {
    switch (s) {
      case 'paid':       return _t('paid_label');
      case 'failed':     return _t('failed_label');
      case 'processing': return _t('processing_label');
      case 'pending':
      default:           return _t('pending_label');
    }
  }

  // ═══════════════════════════════════════════════════════════
  // HOW IT WORKS
  // ═══════════════════════════════════════════════════════════
  Widget _howItWorksCard() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: EfuridePalette.shopperAccent.withValues(alpha: 0.08),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
            color: EfuridePalette.shopperAccent.withValues(alpha: 0.30)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.info_outline,
                  size: 18, color: EfuridePalette.shopperAccent),
              const SizedBox(width: 8),
              Text(_t('how_it_works'),
                  style: const TextStyle(
                      fontSize: 14.5,
                      fontWeight: FontWeight.w800,
                      color: EfuridePalette.ink)),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            _t('how_it_works_body'),
            style: const TextStyle(
              fontSize: 13.5,
              color: EfuridePalette.ink,
              height: 1.5,
            ),
          ),
        ],
      ),
    );
  }
}
