// lib/screens/shopper/shopper_settings_screen.dart
//
// Shopper settings. Notification toggles, task preferences, account
// menu, language picker, and log out. Persists to profiles via
// Supabase + local prefs for the toggles the schema doesn't have yet.
//
// i18n-clean · uses AuthProvider for identity + language.

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'package:efuride_app/config/efuride_palette.dart';
import 'package:efuride_app/l10n/app_strings.dart';
import 'package:efuride_app/config/readability.dart';
import 'package:efuride_app/widgets/text_size_sheet.dart';
import 'package:efuride_app/providers/auth_provider.dart';
import 'package:efuride_app/utils/app_error.dart';
import 'package:efuride_app/utils/error_ui.dart';
import 'package:efuride_app/services/storage_service.dart';
import 'package:efuride_app/widgets/k_icon.dart';

class ShopperSettingsScreen extends StatefulWidget {
  const ShopperSettingsScreen({super.key});

  @override
  State<ShopperSettingsScreen> createState() =>
      _ShopperSettingsScreenState();
}

class _ShopperSettingsScreenState extends State<ShopperSettingsScreen> {
  String _t(String key) => S.of(context).t(key);

  // Local prefs keys for toggles that aren't in the profiles table yet.
  static const _kNewTaskAlerts  = 'shopper_push_new_tasks';
  static const _kSubstitution   = 'shopper_push_substitutions';
  static const _kBarcodeBeep    = 'shopper_barcode_beep';
  static const _kAutoGroup      = 'shopper_auto_group';

  bool _loading = true;
  bool _saving = false;
  bool _uploadingPhoto = false;

  bool _pushNewTasks     = true;
  bool _pushSubstitution = true;
  bool _pushPromotions   = false;
  bool _barcodeBeep      = true;
  bool _autoGroup        = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  // ═══════════════════════════════════════════════════════════
  // LOAD
  // ═══════════════════════════════════════════════════════════
  Future<void> _load() async {
    setState(() => _loading = true);

    try {
      final prefs = await SharedPreferences.getInstance();
      final user = Supabase.instance.client.auth.currentUser;

      // Local-only toggles (schema has no columns for these yet).
      _pushNewTasks     = prefs.getBool(_kNewTaskAlerts)   ?? true;
      _pushSubstitution = prefs.getBool(_kSubstitution)    ?? true;
      _barcodeBeep      = prefs.getBool(_kBarcodeBeep)     ?? true;
      _autoGroup        = prefs.getBool(_kAutoGroup)       ?? false;

      // Server-side toggles live on profiles.
      if (user != null) {
        final row = await Supabase.instance.client
            .from('profiles')
            .select('push_promotions')
            .eq('id', user.id)
            .maybeSingle();
        _pushPromotions = row?['push_promotions'] == true;
      }

      if (!mounted) return;
      setState(() => _loading = false);
    } catch (e) {
      debugPrint('settings load failed: $e');
      if (!mounted) return;
      setState(() => _loading = false);
    }
  }

  // ═══════════════════════════════════════════════════════════
  // SAVE
  // ═══════════════════════════════════════════════════════════
  Future<void> _saveLocal(String key, bool value) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(key, value);
  }

  Future<void> _savePromotions(bool value) async {
    final user = Supabase.instance.client.auth.currentUser;
    if (user == null) return;
    try {
      await Supabase.instance.client
          .from('profiles')
          .update({'push_promotions': value})
          .eq('id', user.id);
    } catch (e) {
      if (!mounted) return;
      ErrorUI.showSnack(
        context,
        AppError.from(e, onRetry: () => _savePromotions(value)),
      );
    }
  }


  // ═══════════════════════════════════════════════════════════
  // PROFILE PHOTO
  // ═══════════════════════════════════════════════════════════
  Future<void> _changePhoto({required bool camera}) async {
    final auth = context.read<AuthProvider>();
    final uid = auth.user?.id;
    if (uid == null) return;
    final file = await StorageService.instance.pickImage(
      fromCamera: camera,
      maxWidth: 800,
      imageQuality: 80,
    );
    if (file == null || !mounted) return;
    setState(() => _uploadingPhoto = true);
    try {
      final url =
          await StorageService.instance.uploadAvatar(userId: uid, file: file);
      if (url == null) throw StateError('Upload failed');
      await auth.refresh();
      if (!mounted) return;
      ErrorUI.showSnack(
        context,
        AppError(
          title: tr('Photo updated'),
          message: tr('Your new photo is saved.'),
          icon: Icons.check_circle_outline,
        ),
      );
    } catch (e) {
      if (!mounted) return;
      ErrorUI.showSnack(context, AppError.from(e));
    } finally {
      if (mounted) setState(() => _uploadingPhoto = false);
    }
  }

  void _photoSheet() {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: EfuridePalette.cream,
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.photo_camera_outlined),
              title: Text(tr('Take a photo')),
              onTap: () {
                Navigator.pop(ctx);
                _changePhoto(camera: true);
              },
            ),
            ListTile(
              leading: const KIcon(Icons.photo_library_outlined),
              title: Text(tr('Choose from gallery')),
              onTap: () {
                Navigator.pop(ctx);
                _changePhoto(camera: false);
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _photoCard() {
    final auth = context.watch<AuthProvider>();
    final url = auth.avatarUrl;
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: EfuridePalette.ink.withValues(alpha: 0.08)),
      ),
      child: Row(
        children: [
          GestureDetector(
            onTap: _uploadingPhoto ? null : _photoSheet,
            child: Stack(
              alignment: Alignment.center,
              children: [
                CircleAvatar(
                  radius: 36,
                  backgroundColor: const Color(0xFFF2E9D6),
                  backgroundImage: (url != null && url.isNotEmpty)
                      ? NetworkImage(url)
                      : null,
                  child: (url == null || url.isEmpty)
                      ? const KIcon(Icons.person, size: 36, color: Colors.black45)
                      : null,
                ),
                if (_uploadingPhoto) const CircularProgressIndicator(),
              ],
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(auth.displayName,
                    style: const TextStyle(
                        fontSize: 18, fontWeight: FontWeight.w800)),
                const SizedBox(height: 2),
                Text(tr('Customers see this photo when you shop for them.'),
                    style: const TextStyle(
                        fontSize: 14, color: Color(0xFF575047))),
              ],
            ),
          ),
          IconButton(
            onPressed: _uploadingPhoto ? null : _photoSheet,
            icon: const KIcon(Icons.camera_alt_outlined),
            tooltip: tr('Change photo'),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // LANGUAGE
  // ═══════════════════════════════════════════════════════════
  Future<void> _openLanguagePicker() async {
    final auth = context.read<AuthProvider>();
    final chosen = await showModalBottomSheet<AppLang>(
      context: context,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (ctx) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Center(
                child: Container(
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: Colors.grey.shade300,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
              const SizedBox(height: 20),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Row(
                  children: [
                    const KIcon(Icons.language,
                        color: EfuridePalette.blueDeep, size: 22),
                    const SizedBox(width: 10),
                    Text(
                      S.of(ctx).t('choose_language'),
                      style: const TextStyle(
                        fontSize: 17,
                        fontWeight: FontWeight.w900,
                        color: EfuridePalette.ink,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 12),
              ...AppLang.available.map((lang) {
                final active = auth.lang == lang;
                return ListTile(
                  leading: Icon(
                    active
                        ? Icons.radio_button_checked
                        : Icons.radio_button_off,
                    color: active
                        ? EfuridePalette.shopperAccent
                        : EfuridePalette.inkMuted,
                  ),
                  title: Text(
                    lang.label,
                    style: TextStyle(
                      fontSize: 14.5,
                      fontWeight:
                          active ? FontWeight.w800 : FontWeight.w600,
                      color: EfuridePalette.ink,
                    ),
                  ),
                  onTap: () => Navigator.pop(ctx, lang),
                );
              }),
            ],
          ),
        ),
      ),
    );
    if (chosen == null || chosen == auth.lang) return;

    await auth.setLanguage(chosen);
    if (!mounted) return;
    ErrorUI.showSnack(
      context,
      AppError(
        title: _t('language_changed'),
        message: _t('language_changed_hint'),
        icon: Icons.check_circle_outline,
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // LOGOUT
  // ═══════════════════════════════════════════════════════════
  Future<void> _confirmLogout() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16)),
        title: Text(_t('logout_title')),
        content: Text(_t('logout_body')),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: Text(_t('cancel')),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
                backgroundColor: EfuridePalette.dropoff,
                foregroundColor: Colors.white),
            onPressed: () => Navigator.pop(context, true),
            child: Text(_t('sign_out')),
          ),
        ],
      ),
    );
    if (ok != true) return;

    setState(() => _saving = true);
    try {
      await Supabase.instance.client.auth.signOut();
      if (!mounted) return;
      Navigator.pushNamedAndRemoveUntil(
          context, '/role_select', (r) => false);
    } catch (e) {
      if (!mounted) return;
      setState(() => _saving = false);
      ErrorUI.showSnack(context, AppError.from(e));
    }
  }

  // ═══════════════════════════════════════════════════════════
  // BUILD
  // ═══════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        _header(),
        Expanded(
          child: _loading
              ? const Center(
                  child: CircularProgressIndicator(
                      color: EfuridePalette.shopperAccent))
              : ListView(
                  padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
                  children: [
                    _photoCard(),
                    const SizedBox(height: 20),
                    _sectionLabel(_t('notif_section')),
                    const SizedBox(height: 10),
                    _sectionCard(children: [
                      _switchRow(
                        icon: Icons.notifications_active_outlined,
                        title: _t('notif_new_tasks'),
                        subtitle: _t('notif_new_tasks_sub'),
                        value: _pushNewTasks,
                        onChanged: (v) async {
                          setState(() => _pushNewTasks = v);
                          await _saveLocal(_kNewTaskAlerts, v);
                        },
                      ),
                      _divider(),
                      _switchRow(
                        icon: Icons.swap_horiz,
                        title: _t('notif_substitutions'),
                        subtitle: _t('notif_substitutions_sub'),
                        value: _pushSubstitution,
                        onChanged: (v) async {
                          setState(() => _pushSubstitution = v);
                          await _saveLocal(_kSubstitution, v);
                        },
                      ),
                      _divider(),
                      _switchRow(
                        icon: Icons.local_offer_outlined,
                        title: _t('notif_promos'),
                        subtitle: _t('notif_promos_sub'),
                        value: _pushPromotions,
                        onChanged: (v) {
                          setState(() => _pushPromotions = v);
                          _savePromotions(v);
                        },
                      ),
                    ]),

                    const SizedBox(height: 24),
                    _sectionLabel(_t('task_prefs')),
                    const SizedBox(height: 10),
                    _sectionCard(children: [
                      _switchRow(
                        icon: Icons.qr_code_scanner,
                        title: _t('barcode_beep'),
                        subtitle: _t('barcode_beep_sub'),
                        value: _barcodeBeep,
                        onChanged: (v) async {
                          setState(() => _barcodeBeep = v);
                          await _saveLocal(_kBarcodeBeep, v);
                        },
                      ),
                      _divider(),
                      _switchRow(
                        icon: Icons.merge_type,
                        title: _t('auto_group'),
                        subtitle: _t('auto_group_sub'),
                        value: _autoGroup,
                        onChanged: (v) async {
                          setState(() => _autoGroup = v);
                          await _saveLocal(_kAutoGroup, v);
                        },
                      ),
                    ]),

                    const SizedBox(height: 24),
                    _sectionLabel(_t('account')),
                    const SizedBox(height: 10),
                    _sectionCard(children: [
                      _navRow(
                        icon: Icons.language,
                        title: _t('language'),
                        trailing: Text(
                          context.watch<AuthProvider>().lang.label,
                          style: const TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w700,
                            color: EfuridePalette.inkMuted,
                          ),
                        ),
                        onTap: _openLanguagePicker,
                      ),
                      _divider(),
                      _navRow(
                        icon: Icons.format_size,
                        title: _t('text_size'),
                        trailing: Text(
                          _t(Readability.labelKeyFor(
                              Readability.textScale.value)),
                          style: const TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w700,
                            color: EfuridePalette.inkMuted,
                          ),
                        ),
                        onTap: () async {
                          await showTextSizeSheet(context);
                          if (mounted) setState(() {});
                        },
                      ),
                      _divider(),
                      _navRow(
                        icon: Icons.verified_user_outlined,
                        title: tr('Verify me'),
                        onTap: () =>
                            Navigator.pushNamed(context, '/verify'),
                      ),
                      _divider(),
                      _navRow(
                        icon: Icons.help_outline,
                        title: _t('help_support'),
                        onTap: () =>
                            Navigator.pushNamed(context, '/support'),
                      ),
                      _divider(),
                      _navRow(
                        icon: Icons.shield_outlined,
                        title: _t('privacy_data'),
                        onTap: () => Navigator.pushNamed(
                            context, '/customer_privacy'),
                      ),
                    ]),

                    const SizedBox(height: 24),
                    SizedBox(
                      width: double.infinity,
                      child: OutlinedButton.icon(
                        onPressed: _saving ? null : _confirmLogout,
                        icon: _saving
                            ? const SizedBox(
                                width: 18,
                                height: 18,
                                child: CircularProgressIndicator(
                                    strokeWidth: 2,
                                    color: EfuridePalette.dropoff),
                              )
                            : const KIcon(Icons.logout,
                                size: 18, color: EfuridePalette.dropoff),
                        label: Text(_t('sign_out'),
                            style: const TextStyle(
                              color: EfuridePalette.dropoff,
                              fontSize: 14.5,
                              fontWeight: FontWeight.w800,
                            )),
                        style: OutlinedButton.styleFrom(
                          minimumSize: const Size(double.infinity, 54),
                          side: const BorderSide(
                              color: EfuridePalette.dropoff, width: 1.4),
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(14)),
                        ),
                      ),
                    ),
                    const SizedBox(height: 24),
                  ],
                ),
        ),
      ],
    );
  }

  // ═══════════════════════════════════════════════════════════
  // HEADER
  // ═══════════════════════════════════════════════════════════
  Widget _header() {
    return Container(
      decoration: const BoxDecoration(
        color: EfuridePalette.cream,
      ),
      child: SafeArea(
        bottom: false,
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 10, 16, 14),
              child: Row(
                children: [
                  Container(
                    width: 40,
                    height: 40,
                    decoration: const BoxDecoration(
                      color: Colors.white,
                      shape: BoxShape.circle,
                    ),
                    child: const Center(
                      child: KIcon(Icons.settings_outlined,
                          color: EfuridePalette.shopperAccent, size: 22),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(tr('KO!NGO'),
                          style: TextStyle(
                            color: EfuridePalette.ink,
                            fontSize: 18,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 1.4,
                            height: 1.05,
                          )),
                      const SizedBox(height: 2),
                      Text(_t('settings'),
                          style: const TextStyle(
                            color: EfuridePalette.inkMuted,
                            fontSize: 13.5,
                            fontWeight: FontWeight.w500,
                          )),
                    ],
                  ),
                ],
              ),
            ),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 18),
              decoration: const BoxDecoration(
                color: EfuridePalette.cream,
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(24),
                  topRight: Radius.circular(24),
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(_t('settings'),
                      style: const TextStyle(
                        color: EfuridePalette.ink,
                        fontSize: 22,
                        fontWeight: FontWeight.w900,
                        letterSpacing: -0.3,
                      )),
                  const SizedBox(height: 4),
                  Text(_t('settings_subtitle'),
                      style: const TextStyle(
                          color: EfuridePalette.inkMuted, fontSize: 14)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // SECTION PRIMITIVES
  // ═══════════════════════════════════════════════════════════
  Widget _sectionLabel(String text) => Padding(
        padding: const EdgeInsets.only(left: 4),
        child: Text(
          text.toUpperCase(),
          style: const TextStyle(
            fontSize: 13,
            fontWeight: FontWeight.w800,
            letterSpacing: 0.8,
            color: EfuridePalette.inkMuted,
          ),
        ),
      );

  Widget _sectionCard({required List<Widget> children}) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: EfuridePalette.divider),
      ),
      child: Column(children: children),
    );
  }

  Widget _divider() => const Divider(
        height: 1,
        indent: 56,
        endIndent: 14,
        color: EfuridePalette.divider,
      );

  Widget _switchRow({
    required IconData icon,
    required String title,
    required String subtitle,
    required bool value,
    required ValueChanged<bool> onChanged,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      child: Row(
        children: [
          Container(
            width: 32,
            height: 32,
            decoration: BoxDecoration(
              color: EfuridePalette.shopperAccent.withValues(alpha: 0.12),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Icon(icon,
                size: 18, color: EfuridePalette.shopperAccent),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title,
                    style: const TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w700,
                        color: EfuridePalette.ink)),
                const SizedBox(height: 2),
                Text(subtitle,
                    style: const TextStyle(
                        fontSize: 13,
                        color: EfuridePalette.inkMuted,
                        height: 1.3)),
              ],
            ),
          ),
          Switch.adaptive(
            value: value,
            activeColor: EfuridePalette.shopperAccent,
            onChanged: onChanged,
          ),
        ],
      ),
    );
  }

  Widget _navRow({
    required IconData icon,
    required String title,
    Widget? trailing,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
        child: Row(
          children: [
            Container(
              width: 32,
              height: 32,
              decoration: BoxDecoration(
                color: EfuridePalette.shopperAccent.withValues(alpha: 0.12),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Icon(icon,
                  size: 18, color: EfuridePalette.shopperAccent),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Text(title,
                  style: const TextStyle(
                    fontSize: 14.5,
                    fontWeight: FontWeight.w600,
                    color: EfuridePalette.ink,
                  )),
            ),
            if (trailing != null) ...[
              trailing,
              const SizedBox(width: 8),
            ],
            const Icon(Icons.chevron_right,
                size: 20, color: EfuridePalette.inkMuted),
          ],
        ),
      ),
    );
  }
}
