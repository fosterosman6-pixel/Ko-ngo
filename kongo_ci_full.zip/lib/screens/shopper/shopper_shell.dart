import 'package:efuride_app/config/efuride_palette.dart';
// lib/screens/shopper/shopper_shell.dart

import 'package:flutter/material.dart';
import 'package:efuride_app/config/tab_routes.dart';
import 'package:efuride_app/widgets/efuride_bottom_nav.dart';
import 'package:efuride_app/screens/shopper/shopper_home_screen.dart';
import 'package:efuride_app/screens/shopper/shopper_tasks_screen.dart';
import 'package:efuride_app/screens/shopper/shopper_pay_screen.dart';
import 'package:efuride_app/screens/shopper/shopper_settings_screen.dart';

class ShopperShell extends StatefulWidget {
  final int initialIndex;
  const ShopperShell({super.key, this.initialIndex = 0});

  @override
  State<ShopperShell> createState() => _ShopperShellState();
}

class _ShopperShellState extends State<ShopperShell> {
  late int _index;

  @override
  void initState() {
    super.initState();
    _index = widget.initialIndex.clamp(0, kShopperTabs.length - 1);
  }

  @override
  Widget build(BuildContext context) {
    // Phone Back button: from another tab go to the first tab; on the
    // first tab leave the app as usual (never back to sign-in).
    return PopScope(
      canPop: _index == 0,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop && _index != 0) setState(() => _index = 0);
      },
      child: Scaffold(
      backgroundColor: EfuridePalette.cream,
      body: IndexedStack(
        index: _index,
        children: const [
          ShopperHomeScreen(),
          ShopperTasksScreen(),
          ShopperPayScreen(),
          ShopperSettingsScreen(),
        ],
      ),
      bottomNavigationBar: EfurideBottomNav(
        role: EfurideRole.shopper,
        currentIndex: _index,
        onTap: (i) => setState(() => _index = i),
        items: kShopperTabs,
      ),
    ),
    );
  }
}

ShopperShell buildShopperShell(Uri uri) => ShopperShell(
      initialIndex: TabRoute.indexFor('shopper', uri.queryParameters['tab']),
    );
