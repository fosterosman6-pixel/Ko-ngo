// lib/screens/shopper/shopper_tasks_screen.dart
//
// Shopper tasks list. Filters by Active / Completed / All.
// Streams tasks from ShopperService and taps into TaskDetail.
//
// i18n-clean · currency-clean · uses CountryConfig + S.

import 'dart:async';
import 'package:flutter/material.dart';
import 'package:efuride_app/config/efuride_palette.dart';
import 'package:efuride_app/config/country_config.dart';
import 'package:efuride_app/l10n/app_strings.dart';
import 'package:efuride_app/screens/shopper/shopper_task_detail_screen.dart';
import 'package:efuride_app/services/shopper_service.dart';
import 'package:efuride_app/utils/app_error.dart';
import 'package:efuride_app/utils/error_ui.dart';
import 'package:efuride_app/widgets/k_icon.dart';

class ShopperTasksScreen extends StatefulWidget {
  const ShopperTasksScreen({super.key});

  @override
  State<ShopperTasksScreen> createState() => _ShopperTasksScreenState();
}

class _ShopperTasksScreenState extends State<ShopperTasksScreen>
    with WidgetsBindingObserver {
  String _t(String key) => S.of(context).t(key);
  String _tf(String key, Map<String, Object> args) =>
      S.of(context).tf(key, args);

  String _filter = 'Active';

  StreamSubscription<List<ShopperTask>>? _sub;
  List<ShopperTask> _tasks = [];
  bool _loading = true;
  AppError? _error;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _subscribe();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _sub?.cancel();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      // Stream is already live; a resubscribe is cheap and refreshes
      // anything missed while backgrounded.
      _subscribe();
    }
  }

  void _subscribe() {
    setState(() {
      _loading = true;
      _error = null;
    });
    _sub?.cancel();
    _sub = ShopperService.instance.streamTasks().listen(
      (rows) {
        if (!mounted) return;
        setState(() {
          _tasks = rows.reversed.toList(); // newest first
          _loading = false;
        });
      },
      onError: (e) {
        if (!mounted) return;
        setState(() {
          _loading = false;
          _error = AppError.from(e, onRetry: _subscribe);
        });
      },
    );
  }

  List<ShopperTask> get _filtered {
    switch (_filter) {
      case 'Active':
        return _tasks.where((t) => t.isActive || t.isPacked).toList();
      case 'Completed':
        return _tasks.where((t) => t.isDone).toList();
      default:
        return _tasks;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        _header(),
        Expanded(
          child: _loading
              ? const Center(
                  child: CircularProgressIndicator(
                      color: EfuridePalette.shopperAccent))
              : _error != null
                  ? ErrorUI.inline(_error!)
                  : _filtered.isEmpty
                      ? _emptyState()
                      : RefreshIndicator(
                          color: EfuridePalette.shopperAccent,
                          onRefresh: () async => _subscribe(),
                          child: ListView.builder(
                            padding:
                                const EdgeInsets.fromLTRB(16, 12, 16, 24),
                            itemCount: _filtered.length,
                            itemBuilder: (_, i) =>
                                _taskCard(_filtered[i]),
                          ),
                        ),
        ),
      ],
    );
  }

  // ═══════════════════════════════════════════════════════════
  // HEADER
  // ═══════════════════════════════════════════════════════════
  Widget _header() {
    return Container(
      decoration: const BoxDecoration(
        color: EfuridePalette.cream,
      ),
      child: SafeArea(
        bottom: false,
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 10, 16, 14),
              child: Row(
                children: [
                  Container(
                    width: 40,
                    height: 40,
                    decoration: const BoxDecoration(
                      color: Colors.white,
                      shape: BoxShape.circle,
                    ),
                    child: const Center(
                      child: KIcon(Icons.location_on,
                          color: EfuridePalette.blue, size: 22),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(tr('KO!NGO'),
                          style: TextStyle(
                            color: EfuridePalette.ink,
                            fontSize: 18,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 1.4,
                            height: 1.05,
                          )),
                      const SizedBox(height: 2),
                      Text(_t('sh_tasks_title'),
                          style: const TextStyle(
                            color: EfuridePalette.inkMuted,
                            fontSize: 13.5,
                            fontWeight: FontWeight.w500,
                          )),
                    ],
                  ),
                  const Spacer(),
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 10, vertical: 6),
                    decoration: BoxDecoration(
                      color: EfuridePalette.shopperAccent,
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Text(
                      _tf('sh_badge_active', {
                        'n': _tasks.where((t) => t.isActive).length,
                      }),
                      style: const TextStyle(
                        color: EfuridePalette.ink,
                        fontSize: 13,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 18),
              decoration: const BoxDecoration(
                color: EfuridePalette.cream,
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(24),
                  topRight: Radius.circular(24),
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(_t('sh_my_tasks'),
                      style: const TextStyle(
                        color: EfuridePalette.ink,
                        fontSize: 22,
                        fontWeight: FontWeight.w900,
                        letterSpacing: -0.3,
                      )),
                  const SizedBox(height: 4),
                  Text(_t('sh_track'),
                      style: const TextStyle(
                          color: EfuridePalette.inkMuted, fontSize: 14)),
                  const SizedBox(height: 14),
                  _filterRow(),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _filterRow() {
    const filters = ['Active', 'Completed', 'All'];
    return Container(
      padding: const EdgeInsets.all(4),
      decoration: BoxDecoration(
        color: const Color(0xFFEFE8DA),
        borderRadius: BorderRadius.circular(24),
      ),
      child: Row(
        children: filters.map((f) {
          final active = _filter == f;
          return Expanded(
            child: GestureDetector(
              onTap: () => setState(() => _filter = f),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 180),
                padding: const EdgeInsets.symmetric(vertical: 9),
                decoration: BoxDecoration(
                  color: active ? Colors.white : Colors.transparent,
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Text(
                  _t('sh_filter_${f.toLowerCase()}'),
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight:
                        active ? FontWeight.w900 : FontWeight.w600,
                    color: active
                        ? EfuridePalette.ink
                        : EfuridePalette.inkMuted,
                  ),
                ),
              ),
            ),
          );
        }).toList(),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // EMPTY STATE
  // ═══════════════════════════════════════════════════════════
  Widget _emptyState() {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 90,
            height: 90,
            decoration: BoxDecoration(
              color: EfuridePalette.shopperAccent
                  .withValues(alpha: 0.12),
              shape: BoxShape.circle,
            ),
            child: const Icon(Icons.inbox_outlined,
                size: 44, color: EfuridePalette.shopperAccent),
          ),
          const SizedBox(height: 16),
          Text(_t('sh_empty_${_filter.toLowerCase()}'),
              style: const TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.w800,
                  color: EfuridePalette.ink)),
          const SizedBox(height: 4),
          Text(_t('sh_new_tasks_hint'),
              style: const TextStyle(
                  fontSize: 13.5, color: EfuridePalette.inkMuted)),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // TASK CARD
  // ═══════════════════════════════════════════════════════════
  Widget _taskCard(ShopperTask t) {
    final progress = t.progress;
    final isDone = t.isDone;
    final shortId = t.orderId.length >= 8
        ? t.orderId.substring(0, 8).toUpperCase()
        : t.orderId;
    final accent = isDone
        ? EfuridePalette.online
        : EfuridePalette.shopperAccent;

    final badgeLabel = isDone
        ? _t('sh_done')
        : t.isPacked
            ? _t('sh_packed_badge')
            : _t('sh_active_badge');

    return InkWell(
      onTap: () => Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => ShopperTaskDetailScreen(
            taskId: t.id,
            orderId: t.orderId,
            storeName: t.storeName,
          ),
        ),
      ),
      borderRadius: BorderRadius.circular(14),
      child: Container(
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: isDone
                ? EfuridePalette.divider
                : EfuridePalette.shopperAccent
                    .withValues(alpha: 0.4),
            width: isDone ? 1 : 1.5,
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  width: 42,
                  height: 42,
                  decoration: BoxDecoration(
                    color: accent.withValues(alpha: 0.12),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Icon(
                    Icons.shopping_bag_outlined,
                    color: accent,
                    size: 22,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('#$shortId',
                          style: const TextStyle(
                            fontSize: 14.5,
                            fontWeight: FontWeight.w900,
                            color: EfuridePalette.ink,
                          )),
                      const SizedBox(height: 2),
                      Text(t.storeName,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            fontSize: 13.5,
                            color: EfuridePalette.inkMuted,
                          )),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: accent.withValues(alpha: 0.12),
                    borderRadius: BorderRadius.circular(6),
                  ),
                  child: Text(
                    badgeLabel,
                    style: TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 0.5,
                      color: accent,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                _meta(Icons.list_alt_outlined,
                    '${t.itemsPicked}/${t.itemCount} ${_t('items_count')}'),
                const SizedBox(width: 14),
                _meta(Icons.payments_outlined,
                    CountryConfig.money(t.estimatedTotal)),
                const Spacer(),
                _meta(Icons.schedule,
                    _relative(t.startedAt ?? t.assignedAt ?? DateTime.now())),
              ],
            ),
            if (!isDone) ...[
              const SizedBox(height: 12),
              ClipRRect(
                borderRadius: BorderRadius.circular(4),
                child: LinearProgressIndicator(
                  value: progress,
                  minHeight: 6,
                  backgroundColor: EfuridePalette.divider,
                  valueColor:
                      const AlwaysStoppedAnimation(EfuridePalette.shopperAccent),
                ),
              ),
              const SizedBox(height: 6),
              Row(
                children: [
                  Text(
                    _tf('sh_complete_pct',
                        {'pct': (progress * 100).round()}),
                    style: const TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w700,
                      color: EfuridePalette.shopperAccent,
                    ),
                  ),
                  const Spacer(),
                  Text(_t('sh_continue'),
                      style: const TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w800,
                        color: EfuridePalette.shopperAccent,
                      )),
                ],
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _meta(IconData icon, String label) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(icon, size: 12, color: EfuridePalette.inkMuted),
        const SizedBox(width: 4),
        Text(label,
            style: const TextStyle(
                fontSize: 13,
                color: EfuridePalette.inkMuted,
                fontWeight: FontWeight.w600)),
      ],
    );
  }

  String _relative(DateTime t) {
    final d = DateTime.now().difference(t);
    if (d.inMinutes < 60) return '${d.inMinutes}m';
    if (d.inHours < 24) return '${d.inHours}h';
    return '${d.inDays}d';
  }
}
