// lib/screens/shopper/shopper_task_detail_screen.dart
//
// Shopper task detail. Go to the store, pick items, propose
// substitutions, capture the receipt, seal the package, then request a
// driver. The driver collects with the pickup code shown here.
//
// i18n-clean · currency-clean · realtime substitutions.

import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter/services.dart';
import 'package:geolocator/geolocator.dart';
import 'package:image_picker/image_picker.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:efuride_app/config/efuride_palette.dart';
import 'package:efuride_app/config/country_config.dart';
import 'package:efuride_app/l10n/app_strings.dart';
import 'package:efuride_app/services/shopper_service.dart';
import 'package:efuride_app/utils/app_error.dart';
import 'package:efuride_app/utils/error_ui.dart';
import 'package:efuride_app/widgets/k_icon.dart';

class ShopperTaskDetailScreen extends StatefulWidget {
  final String taskId;
  final String orderId;
  final String storeName;

  const ShopperTaskDetailScreen({
    super.key,
    required this.taskId,
    required this.orderId,
    required this.storeName,
  });

  @override
  State<ShopperTaskDetailScreen> createState() =>
      _ShopperTaskDetailScreenState();
}

class _ShopperTaskDetailScreenState
    extends State<ShopperTaskDetailScreen> {
  String _t(String key) => S.of(context).t(key);
  String _tf(String key, Map<String, Object> args) =>
      S.of(context).tf(key, args);

  final _picker = ImagePicker();

  ShopperTask? _task;
  List<Map<String, dynamic>> _items = [];
  List<Substitution> _substitutions = [];

  StreamSubscription<List<Substitution>>? _subsSub;
  StreamSubscription<Map<String, dynamic>?>? _deliverySub;
  Map<String, dynamic>? _delivery; // rides row for this order
  StoreLocation? _store;
  bool _requestingDriver = false;
  bool _isLoading = true;
  AppError? _error;

  Uint8List? _receiptBytes;

  @override
  void initState() {
    super.initState();
    _load();
    _subscribeToSubstitutions();
    _subscribeToDelivery();
    _loadStore();
  }

  @override
  void dispose() {
    _subsSub?.cancel();
    _deliverySub?.cancel();
    super.dispose();
  }

  void _subscribeToDelivery() {
    _deliverySub?.cancel();
    _deliverySub = ShopperService.instance
        .streamDeliveryForOrder(widget.orderId)
        .listen(
      (row) {
        if (!mounted) return;
        final wasCollected = _deliveryCollected;
        setState(() => _delivery = row);
        // Driver collected → the task completes on the server; refresh.
        if (!wasCollected && _deliveryCollected) _load();
      },
      onError: (e) => debugPrint('delivery stream error: $e'),
    );
  }

  Future<void> _loadStore() async {
    try {
      final s = await ShopperService.instance.loadStoreForOrder(widget.orderId);
      if (mounted) setState(() => _store = s);
    } catch (e) {
      debugPrint('loadStore failed: $e');
    }
  }

  bool get _deliveryCollected {
    final s = _delivery?['status']?.toString();
    return s == 'in_progress' ||
        s == 'completed' ||
        s == 'returning' ||
        s == 'returned';
  }

  Future<void> _openStoreInMaps() async {
    final s = _store;
    if (s == null) return;
    final dest = (s.lat != null && s.lng != null)
        ? '${s.lat},${s.lng}'
        : Uri.encodeComponent('${s.name} ${s.address}');
    final uri = Uri.parse(
        'https://www.google.com/maps/dir/?api=1&destination=$dest&travelmode=driving');
    try {
      if (kIsWeb) {
        await launchUrl(uri, webOnlyWindowName: '_blank');
      } else {
        await launchUrl(uri, mode: LaunchMode.externalApplication);
      }
    } catch (e) {
      debugPrint('open maps failed: $e');
    }
  }

  Future<void> _requestDriver() async {
    if (_requestingDriver) return;
    setState(() => _requestingDriver = true);
    try {
      // The shopper is at the store: their position backs up the store's
      // map location if the merchant never set it.
      double? lat, lng;
      try {
        final pos = await Geolocator.getCurrentPosition(
          desiredAccuracy: LocationAccuracy.high,
          timeLimit: const Duration(seconds: 6),
        );
        lat = pos.latitude;
        lng = pos.longitude;
      } catch (_) {}
      await ShopperService.instance
          .requestDelivery(widget.orderId, lat: lat, lng: lng);
      if (!mounted) return;
      ErrorUI.showSnack(
        context,
        AppError(
          title: _t('sp_driver_requested'),
          message: _t('sp_driver_requested_hint'),
          icon: Icons.delivery_dining,
        ),
      );
    } catch (e) {
      if (!mounted) return;
      ErrorUI.showSnack(
          context, AppError.from(e, onRetry: _requestDriver));
    } finally {
      if (mounted) setState(() => _requestingDriver = false);
    }
  }

  // ═══════════════════════════════════════════════════════════
  // LOAD
  // ═══════════════════════════════════════════════════════════
  Future<void> _load() async {
    setState(() {
      _isLoading = true;
      _error = null;
    });
    try {
      final task = await ShopperService.instance.loadTask(widget.taskId);
      if (task == null) throw Exception('Task not found');
      final items = await ShopperService.instance
          .loadOrderItems(task.orderId);

      if (!mounted) return;
      setState(() {
        _task = task;
        _items = items;
        _isLoading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _isLoading = false;
        _error = AppError.from(e, onRetry: _load);
      });
    }
  }

  void _subscribeToSubstitutions() {
    _subsSub?.cancel();
    _subsSub = ShopperService.instance
        .streamSubstitutionsForTask(widget.taskId)
        .listen(
      (subs) {
        if (!mounted) return;
        setState(() => _substitutions = subs);
      },
      onError: (e) => debugPrint('subs stream error: $e'),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // HELPERS
  // ═══════════════════════════════════════════════════════════
  String _extOf(String name) {
    final i = name.lastIndexOf('.');
    return (i > 0 && i < name.length - 1)
        ? name.substring(i + 1).toLowerCase()
        : 'jpg';
  }

  bool _isItemPicked(String itemId) {
    final item =
        _items.firstWhere((i) => i['id'] == itemId, orElse: () => {});
    return item['actual_price'] != null;
  }

  Substitution? _substitutionFor(String itemId) {
    try {
      return _substitutions.firstWhere(
        // An unanswered swap stops blocking the item after 2 minutes.
        (s) =>
            s.orderItemId == itemId &&
            s.status == 'pending' &&
            s.secondsLeft > 0,
      );
    } catch (_) {
      return null;
    }
  }

  int get _pickedCount =>
      _items.where((i) => i['actual_price'] != null).length;

  double get _actualTotal => _items.fold<double>(
      0, (s, i) => s + ((i['actual_price'] ?? 0) as num).toDouble());

  double get _progress =>
      _items.isEmpty ? 0 : _pickedCount / _items.length;

  bool get _allPicked =>
      _items.isNotEmpty && _pickedCount == _items.length;

  // ═══════════════════════════════════════════════════════════
  // ACTIONS
  // ═══════════════════════════════════════════════════════════
  Future<void> _startShopping() async {
    try {
      await ShopperService.instance.startShopping(widget.taskId);
      await _load();
    } catch (e) {
      if (!mounted) return;
      ErrorUI.showSnack(context, AppError.from(e));
    }
  }

  Future<void> _openPickSheet(Map<String, dynamic> item) async {
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (_) => _PickSheet(
        item: item,
        onConfirm: (price, weightKg, notes) async {
          Navigator.pop(context);
          try {
            await ShopperService.instance.markItemPicked(
              taskId: widget.taskId,
              orderItemId: item['id'].toString(),
              actualPrice: price,
              weightKg: weightKg,
              notes: notes,
            );
            await _load();
          } catch (e) {
            if (!mounted) return;
            ErrorUI.showSnack(context, AppError.from(e));
          }
        },
        onSubstitute: () {
          Navigator.pop(context);
          _openSubstitutionSheet(item);
        },
      ),
    );
  }

  Future<void> _openSubstitutionSheet(Map<String, dynamic> item) async {
    final altCtrl = TextEditingController();
    final priceCtrl = TextEditingController();
    final photo = ValueNotifier<Uint8List?>(null);
    String photoExt = 'jpg';
    bool saving = false;

    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setSheet) => Padding(
          padding: EdgeInsets.only(
            left: 20,
            right: 20,
            top: 20,
            bottom: MediaQuery.of(ctx).viewInsets.bottom + 24,
          ),
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Center(
                  child: Container(
                    width: 40,
                    height: 4,
                    decoration: BoxDecoration(
                      color: Colors.grey.shade300,
                      borderRadius: BorderRadius.circular(2),
                    ),
                  ),
                ),
                const SizedBox(height: 18),
                Row(
                  children: [
                    const Icon(Icons.swap_horiz,
                        color: EfuridePalette.shopperAccent, size: 22),
                    const SizedBox(width: 10),
                    Text(
                      S.of(ctx).t('sh_propose_sub'),
                      style: const TextStyle(
                          fontSize: 17,
                          fontWeight: FontWeight.w900,
                          color: EfuridePalette.ink),
                    ),
                  ],
                ),
                const SizedBox(height: 6),
                Text(
                  S.of(ctx).tf('sh_original', {
                    'name': (item['name'] ?? '').toString(),
                    'qty': (item['qty'] ?? 1).toString(),
                  }),
                  style: const TextStyle(
                      fontSize: 13.5, color: EfuridePalette.inkMuted),
                ),
                const SizedBox(height: 16),

                // Photo
                ValueListenableBuilder<Uint8List?>(
                  valueListenable: photo,
                  builder: (_, f, __) => GestureDetector(
                    onTap: () async {
                      final picked = await _picker.pickImage(
                        source: ImageSource.camera,
                        imageQuality: 75,
                        maxWidth: 1200,
                      );
                      if (picked != null) {
                        photoExt = _extOf(picked.name);
                        photo.value = await picked.readAsBytes();
                      }
                    },
                    child: Container(
                      height: 120,
                      decoration: BoxDecoration(
                        color: EfuridePalette.cream,
                        borderRadius: BorderRadius.circular(12),
                        border:
                            Border.all(color: EfuridePalette.divider),
                      ),
                      clipBehavior: Clip.antiAlias,
                      child: f != null
                          ? Image.memory(f,
                              fit: BoxFit.cover, width: double.infinity)
                          : Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                const KIcon(Icons.camera_alt_outlined,
                                    size: 32,
                                    color: EfuridePalette.inkMuted),
                                const SizedBox(height: 6),
                                Text(S.of(ctx).t('sh_add_photo'),
                                    style: const TextStyle(
                                        fontSize: 13.5,
                                        color: EfuridePalette.inkMuted)),
                              ],
                            ),
                    ),
                  ),
                ),
                const SizedBox(height: 14),

                TextField(
                  controller: altCtrl,
                  decoration: InputDecoration(
                    labelText: S.of(ctx).t('sh_alt_item'),
                    hintText: S.of(ctx).t('sh_alt_hint'),
                    filled: true,
                    fillColor: EfuridePalette.cream,
                    contentPadding: const EdgeInsets.symmetric(
                        horizontal: 14, vertical: 12),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: BorderSide.none,
                    ),
                  ),
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: priceCtrl,
                  keyboardType: TextInputType.number,
                  inputFormatters: [
                    FilteringTextInputFormatter.digitsOnly,
                  ],
                  decoration: InputDecoration(
                    labelText: S.of(ctx).tf('sh_new_price',
                        {'cur': CountryConfig.currencyCode}),
                    filled: true,
                    fillColor: EfuridePalette.cream,
                    contentPadding: const EdgeInsets.symmetric(
                        horizontal: 14, vertical: 12),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: BorderSide.none,
                    ),
                  ),
                ),
                const SizedBox(height: 14),

                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: EfuridePalette.shopperAccent
                        .withValues(alpha: 0.10),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Row(
                    children: [
                      const Icon(Icons.timer_outlined,
                          size: 16,
                          color: EfuridePalette.shopperAccent),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          S.of(ctx).t('sh_sub_notice'),
                          style: const TextStyle(
                              fontSize: 13,
                              color: EfuridePalette.ink,
                              height: 1.4),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 20),

                ElevatedButton(
                  onPressed: saving
                      ? null
                      : () async {
                          final alt = altCtrl.text.trim();
                          final price =
                              double.tryParse(priceCtrl.text.trim());
                          if (alt.isEmpty || price == null) {
                            ErrorUI.showSnack(
                              ctx,
                              AppError(
                                title: S.of(ctx).t('sh_missing_info'),
                                message: S.of(ctx).t('sh_enter_alt'),
                                icon: Icons.info_outline,
                              ),
                            );
                            return;
                          }

                          setSheet(() => saving = true);

                          try {
                            String? photoUrl;
                            final f = photo.value;
                            if (f != null) {
                              photoUrl = await ShopperService.instance
                                  .uploadSubstitutionPhoto(
                                substitutionId: DateTime.now()
                                    .millisecondsSinceEpoch
                                    .toString(),
                                bytes: f,
                                ext: photoExt,
                              );
                            }

                            final sub = await ShopperService.instance
                                .proposeSubstitution(
                              taskId: widget.taskId,
                              orderItemId: item['id'].toString(),
                              originalName:
                                  (item['name'] ?? '').toString(),
                              originalPrice:
                                  ((item['unit_price'] ?? 0) as num)
                                      .toDouble(),
                              proposedName: alt,
                              proposedPrice: price,
                              photoUrl: photoUrl,
                            );

                            if (!ctx.mounted) return;
                            Navigator.pop(ctx);

                            if (!mounted) return;
                            _showSubstitutionPending(sub);
                          } catch (e) {
                            if (!ctx.mounted) return;
                            setSheet(() => saving = false);
                            ErrorUI.showSnack(ctx, AppError.from(e));
                          }
                        },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: EfuridePalette.shopperAccent,
                    foregroundColor: Colors.white,
                    minimumSize: const Size(double.infinity, 52),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(14)),
                    elevation: 0,
                  ),
                  child: saving
                      ? const SizedBox(
                          width: 20,
                          height: 20,
                          child: CircularProgressIndicator(
                              strokeWidth: 2, color: Colors.white),
                        )
                      : Text(S.of(ctx).t('sh_send_approval'),
                          style: const TextStyle(
                              fontSize: 15,
                              fontWeight: FontWeight.w900)),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _showSubstitutionPending(Substitution s) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(_t('sh_waiting_approve')),
        backgroundColor: EfuridePalette.shopperAccent,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10)),
      ),
    );
  }

  Future<void> _captureReceipt() async {
    try {
      final picked = await _picker.pickImage(
        source: ImageSource.camera,
        imageQuality: 80,
        maxWidth: 1600,
      );
      if (picked == null) return;
      final bytes = await picked.readAsBytes();
      final ext = _extOf(picked.name);
      setState(() => _receiptBytes = bytes);

      final url = await ShopperService.instance.uploadReceipt(
        taskId: widget.taskId,
        bytes: bytes,
        ext: ext,
      );
      if (url == null) throw Exception('Receipt upload failed');

      await ShopperService.instance.attachReceipt(
        taskId: widget.taskId,
        receiptUrl: url,
        actualTotal: _actualTotal,
      );
      await _load();

      if (!mounted) return;
      ErrorUI.showSnack(
        context,
        AppError(
          title: _t('sh_receipt_captured'),
          message: _t('sh_ready_seal'),
          icon: Icons.check_circle_outline,
        ),
      );
    } catch (e) {
      if (!mounted) return;
      ErrorUI.showSnack(context, AppError.from(e));
    }
  }

  Future<void> _sealPackage() async {
    if (!_allPicked) {
      ErrorUI.showSnack(
        context,
        AppError(
          title: _t('sh_pick_all_first'),
          message: _t('sh_unpicked'),
          icon: Icons.info_outline,
        ),
      );
      return;
    }
    if (_receiptBytes == null && (_task?.receiptUrl == null)) {
      ErrorUI.showSnack(
        context,
        AppError(
          title: _t('sh_capture_receipt_t'),
          message: _t('sh_need_receipt'),
          icon: Icons.receipt_long_outlined,
        ),
      );
      return;
    }

    try {
      final qr = await ShopperService.instance.sealPackage(
        taskId: widget.taskId,
        orderId: widget.orderId,
      );

      if (!mounted) return;
      await showDialog<void>(
        context: context,
        builder: (_) => AlertDialog(
          shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(16)),
          title: Row(
            children: [
              const Icon(Icons.qr_code_2,
                  color: EfuridePalette.shopperAccent),
              const SizedBox(width: 10),
              Text(_t('sh_package_sealed')),
            ],
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 160,
                height: 160,
                decoration: BoxDecoration(
                  color: EfuridePalette.cream,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: EfuridePalette.divider),
                ),
                child: const Center(
                  child: Icon(Icons.qr_code_2,
                      size: 100, color: EfuridePalette.ink),
                ),
              ),
              const SizedBox(height: 12),
              Text(qr,
                  style: const TextStyle(
                      fontSize: 14, fontWeight: FontWeight.w700)),
              const SizedBox(height: 6),
              Text(
                _t('sh_attach_label'),
                textAlign: TextAlign.center,
                style: const TextStyle(
                    fontSize: 13,
                    color: EfuridePalette.inkMuted,
                    height: 1.4),
              ),
            ],
          ),
          actions: [
            ElevatedButton.icon(
              onPressed: () {
                Navigator.pop(context);
                _requestDriver();
              },
              icon: const KIcon(Icons.delivery_dining),
              style: ElevatedButton.styleFrom(
                backgroundColor: EfuridePalette.shopperAccent,
                foregroundColor: Colors.white,
              ),
              label: Text(_t('sp_request_driver')),
            ),
          ],
        ),
      );
      await _load();
    } catch (e) {
      if (!mounted) return;
      ErrorUI.showSnack(context, AppError.from(e));
    }
  }

  // ═══════════════════════════════════════════════════════════
  // BUILD
  // ═══════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: EfuridePalette.cream,
      body: Column(
        children: [
          _header(),
          Expanded(child: _body()),
          if (!_isLoading && _task != null) _bottomBar(),
        ],
      ),
    );
  }

  Widget _header() {
    final taskIdShort = widget.taskId.length >= 8
        ? widget.taskId.substring(0, 8)
        : widget.taskId;

    return Container(
      decoration: const BoxDecoration(
        color: EfuridePalette.cream,
      ),
      child: SafeArea(
        bottom: false,
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(8, 8, 16, 12),
              child: Row(
                children: [
                  IconButton(
                    onPressed: () => Navigator.pop(context),
                    icon: const Icon(Icons.arrow_back,
                        color: EfuridePalette.ink),
                  ),
                  const SizedBox(width: 4),
                  Container(
                    width: 36,
                    height: 36,
                    decoration: const BoxDecoration(
                      color: Colors.white,
                      shape: BoxShape.circle,
                    ),
                    child: const Center(
                      child: Icon(Icons.shopping_bag_rounded,
                          color: EfuridePalette.shopperAccent, size: 20),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(tr('KO!NGO'),
                            style: TextStyle(
                              color: EfuridePalette.ink,
                              fontSize: 16,
                              fontWeight: FontWeight.w900,
                              letterSpacing: 1.2,
                              height: 1.05,
                            )),
                        const SizedBox(height: 2),
                        Text(
                          _tf('sh_task_hash', {'id': taskIdShort}),
                          style: const TextStyle(
                            color: EfuridePalette.inkMuted,
                            fontSize: 13,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.fromLTRB(16, 14, 16, 18),
              decoration: const BoxDecoration(
                color: EfuridePalette.cream,
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(24),
                  topRight: Radius.circular(24),
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(widget.storeName,
                      style: const TextStyle(
                          color: EfuridePalette.ink,
                          fontSize: 18,
                          fontWeight: FontWeight.w900)),
                  const SizedBox(height: 10),
                  if (_task != null) ...[
                    Row(
                      children: [
                        const Icon(Icons.list_alt_outlined,
                            size: 14, color: EfuridePalette.inkMuted),
                        const SizedBox(width: 6),
                        Text(
                          _tf('sh_items_count', {
                            'picked': _pickedCount,
                            'total': _items.length,
                          }),
                          style: const TextStyle(
                              color: EfuridePalette.inkMuted,
                              fontSize: 13.5,
                              fontWeight: FontWeight.w600),
                        ),
                        const SizedBox(width: 14),
                        const KIcon(Icons.payments_outlined,
                            size: 14, color: EfuridePalette.inkMuted),
                        const SizedBox(width: 6),
                        Text(CountryConfig.money(_actualTotal),
                            style: const TextStyle(
                                color: EfuridePalette.inkMuted,
                                fontSize: 13.5,
                                fontWeight: FontWeight.w600)),
                      ],
                    ),
                    const SizedBox(height: 12),
                    ClipRRect(
                      borderRadius: BorderRadius.circular(4),
                      child: LinearProgressIndicator(
                        value: _progress,
                        minHeight: 6,
                        backgroundColor:
                            EfuridePalette.ink.withValues(alpha: 0.06),
                        valueColor: const AlwaysStoppedAnimation(
                            EfuridePalette.shopperAccent),
                      ),
                    ),
                  ],
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _body() {
    if (_isLoading) {
      return const Center(
        child: CircularProgressIndicator(
            color: EfuridePalette.shopperAccent),
      );
    }
    if (_error != null) return ErrorUI.inline(_error!);

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
      children: [
        if (_store != null &&
            (_task?.status == 'accepted' ||
                _task?.status == 'in_progress' ||
                _task?.status == 'substitution_pending'))
          _goToStoreCard(),
        if (_task?.status == 'accepted') _startShoppingBanner(),
        if (_substitutions.isNotEmpty) ...[
          const SizedBox(height: 4),
          ..._substitutions.map(_substitutionBanner),
          const SizedBox(height: 12),
        ],
        Padding(
          padding: const EdgeInsets.only(left: 4, bottom: 10),
          child: Text(_t('sh_shopping_list'),
              style: const TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w800,
                  color: EfuridePalette.ink)),
        ),
        if (_items.isEmpty)
          Container(
            padding: const EdgeInsets.all(24),
            alignment: Alignment.center,
            child: Text(_t('sh_no_items'),
                style: const TextStyle(
                    fontSize: 14, color: EfuridePalette.inkMuted)),
          )
        else
          ..._items.map(_itemTile),
      ],
    );
  }

  Widget _goToStoreCard() {
    final s = _store!;
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: EfuridePalette.divider),
      ),
      child: Row(
        children: [
          const Icon(Icons.storefront, color: EfuridePalette.shopperAccent),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(s.name,
                    style: const TextStyle(
                        fontWeight: FontWeight.w800, fontSize: 14.5)),
                if (s.address.isNotEmpty)
                  Text(s.address,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                          fontSize: 13.5, color: EfuridePalette.inkMuted)),
              ],
            ),
          ),
          TextButton.icon(
            onPressed: _openStoreInMaps,
            icon: const Icon(Icons.directions, size: 18),
            label: Text(_t('sp_go_to_store')),
          ),
        ],
      ),
    );
  }

  /// After sealing: request a driver, then show the pickup code and the
  /// driver's progress until the package is collected.
  Widget _deliveryPanel() {
    final d = _delivery;
    final status = d?['status']?.toString();
    final code = d?['pickup_otp']?.toString() ?? '';

    if (d == null || status == 'cancelled') {
      return SizedBox(
        width: double.infinity,
        child: ElevatedButton.icon(
          onPressed: _requestingDriver ? null : _requestDriver,
          icon: _requestingDriver
              ? const SizedBox(
                  width: 18,
                  height: 18,
                  child: CircularProgressIndicator(
                      strokeWidth: 2, color: Colors.white))
              : const KIcon(Icons.delivery_dining, size: 20),
          label: Text(_t('sp_request_driver'),
              style:
                  const TextStyle(fontSize: 15, fontWeight: FontWeight.w900)),
          style: ElevatedButton.styleFrom(
            backgroundColor: EfuridePalette.shopperAccent,
            foregroundColor: Colors.white,
            minimumSize: const Size(0, 52),
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(14)),
            elevation: 0,
          ),
        ),
      );
    }

    String line;
    IconData icon;
    switch (status) {
      case 'pending':
        line = _t('sp_looking_driver');
        icon = Icons.search;
        break;
      case 'accepted':
        line = _t('sp_driver_coming');
        icon = Icons.delivery_dining;
        break;
      default:
        line = _t('sp_collected');
        icon = Icons.check_circle;
    }

    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Row(
          children: [
            Icon(icon, size: 18, color: EfuridePalette.shopperAccent),
            const SizedBox(width: 8),
            Expanded(
              child: Text(line,
                  style: const TextStyle(
                      fontSize: 14, fontWeight: FontWeight.w700)),
            ),
          ],
        ),
        if (!_deliveryCollected && code.isNotEmpty) ...[
          const SizedBox(height: 10),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(vertical: 12),
            decoration: BoxDecoration(
              color: EfuridePalette.shopperAccent.withValues(alpha: 0.08),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                  color: EfuridePalette.shopperAccent.withValues(alpha: 0.3)),
            ),
            child: Column(
              children: [
                Text(_t('sp_pickup_code'),
                    style: const TextStyle(
                        fontSize: 13, color: EfuridePalette.inkMuted)),
                const SizedBox(height: 4),
                Text(code,
                    style: const TextStyle(
                        fontSize: 28,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 6)),
                Text(_t('sp_pickup_code_hint'),
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                        fontSize: 13, color: EfuridePalette.inkMuted)),
              ],
            ),
          ),
        ],
      ],
    );
  }

  Widget _startShoppingBanner() {
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: EfuridePalette.shopperAccent.withValues(alpha: 0.10),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
            color: EfuridePalette.shopperAccent.withValues(alpha: 0.4),
            width: 1.4),
      ),
      child: Row(
        children: [
          const Icon(Icons.directions_walk,
              size: 20, color: EfuridePalette.shopperAccent),
          const SizedBox(width: 10),
          Expanded(
            child: Text(_t('sh_ready_start_q'),
                style: const TextStyle(
                    fontSize: 14.5,
                    fontWeight: FontWeight.w800,
                    color: EfuridePalette.ink)),
          ),
          ElevatedButton(
            onPressed: _startShopping,
            style: ElevatedButton.styleFrom(
              backgroundColor: EfuridePalette.shopperAccent,
              foregroundColor: Colors.white,
              minimumSize: const Size(0, 40),
              padding: const EdgeInsets.symmetric(horizontal: 16),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10)),
              elevation: 0,
            ),
            child: Text(_t('sh_start'),
                style: const TextStyle(
                    fontSize: 14, fontWeight: FontWeight.w900)),
          ),
        ],
      ),
    );
  }

  /// The customer didn't answer in time: close the swap so the shopper
  /// can pick the original item or leave it out.
  Future<void> _closeUnansweredSwap(Substitution s) async {
    try {
      await Supabase.instance.client.rpc('respond_substitution',
          params: {'p_sub': s.id, 'p_action': 'timeout'});
    } catch (e) {
      debugPrint('close swap failed: $e');
    }
    if (mounted) setState(() {});
  }

  Widget _substitutionBanner(Substitution s) {
    final expired = s.status == 'pending' && s.secondsLeft <= 0;
    final pending = s.status == 'pending' && !expired;
    final approved = s.status == 'approved';
    final color = pending
        ? EfuridePalette.shopperAccent
        : approved
            ? EfuridePalette.online
            : EfuridePalette.inkMuted;
    final label = expired
        ? tr('NO ANSWER')
        : pending
        ? _t('sh_s_waiting')
        : approved
            ? _t('sh_s_approved')
            : s.status == 'rejected'
                ? _t('sh_s_rejected')
                : _t('sh_s_timeout');

    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.08),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: color.withValues(alpha: 0.4), width: 1.3),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(
                pending
                    ? Icons.hourglass_top
                    : approved
                        ? Icons.check_circle
                        : Icons.cancel_outlined,
                color: color,
                size: 18,
              ),
              const SizedBox(width: 8),
              Text(_t('sh_substitution'),
                  style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w900,
                      color: color)),
              const Spacer(),
              Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: 8, vertical: 3),
                decoration: BoxDecoration(
                  color: color,
                  borderRadius: BorderRadius.circular(6),
                ),
                child: Text(label,
                    style: const TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w900,
                        color: Colors.white,
                        letterSpacing: 0.5)),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('→ ${s.proposedName}',
                        style: const TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w800,
                            color: EfuridePalette.ink)),
                    const SizedBox(height: 2),
                    Text(
                      '${s.originalName} (${CountryConfig.money(s.originalPrice)})',
                      style: const TextStyle(
                          fontSize: 13,
                          color: EfuridePalette.inkMuted,
                          decoration: TextDecoration.lineThrough),
                    ),
                  ],
                ),
              ),
              Text(
                CountryConfig.money(s.proposedPrice),
                style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w900,
                    color: color),
              ),
            ],
          ),
          if (expired) ...[
            const SizedBox(height: 8),
            Text(
              tr('The customer didn\'t answer. Pick the original item or leave it out.'),
              style: const TextStyle(
                  fontSize: 14, color: EfuridePalette.ink, height: 1.3),
            ),
            const SizedBox(height: 8),
            OutlinedButton(
              onPressed: () => _closeUnansweredSwap(s),
              child: Text(tr('OK, continue shopping')),
            ),
          ],
          if (pending) ...[
            const SizedBox(height: 8),
            Row(
              children: [
                const Icon(Icons.timer_outlined,
                    size: 12, color: EfuridePalette.inkMuted),
                const SizedBox(width: 4),
                Text(_tf('sh_secs_left', {'s': s.secondsLeft}),
                    style: const TextStyle(
                        fontSize: 13,
                        color: EfuridePalette.inkMuted,
                        fontWeight: FontWeight.w700)),
              ],
            ),
          ],
        ],
      ),
    );
  }

  Widget _itemTile(Map<String, dynamic> item) {
    final id = item['id'].toString();
    final name = (item['name'] ?? '').toString();
    final qty = ((item['qty'] ?? 1) as num).toInt();
    final unitPrice = ((item['unit_price'] ?? 0) as num).toDouble();
    final actualPrice = item['actual_price'] as num?;
    final picked = actualPrice != null;
    final pendingSub = _substitutionFor(id);

    final approvedSub = _substitutions.firstWhere(
      (s) => s.orderItemId == id && s.status == 'approved',
      orElse: () => Substitution(
        id: '',
        taskId: '',
        orderItemId: '',
        originalName: '',
        originalPrice: 0,
        proposedName: '',
        proposedPrice: 0,
        priceDelta: 0,
        status: '',
        expiresAt: DateTime.now(),
      ),
    );

    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
          color: picked
              ? EfuridePalette.online.withValues(alpha: 0.5)
              : pendingSub != null
                  ? EfuridePalette.shopperAccent.withValues(alpha: 0.5)
                  : EfuridePalette.divider,
          width: picked || pendingSub != null ? 1.4 : 1,
        ),
      ),
      child: Row(
        children: [
          Container(
            width: 26,
            height: 26,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: picked
                  ? EfuridePalette.online
                  : Colors.transparent,
              shape: BoxShape.circle,
              border: Border.all(
                color: picked
                    ? EfuridePalette.online
                    : EfuridePalette.inkMuted,
                width: 1.6,
              ),
            ),
            child: picked
                ? const Icon(Icons.check, size: 16, color: Colors.white)
                : null,
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(name,
                    style: const TextStyle(
                        fontSize: 14, fontWeight: FontWeight.w800)),
                const SizedBox(height: 2),
                Text('$qty × ${CountryConfig.money(unitPrice)}',
                    style: const TextStyle(
                        fontSize: 13.5,
                        color: EfuridePalette.inkMuted)),
                if (pendingSub != null) ...[
                  const SizedBox(height: 4),
                  Row(
                    children: [
                      const Icon(Icons.swap_horiz,
                          size: 12,
                          color: EfuridePalette.shopperAccent),
                      const SizedBox(width: 4),
                      Expanded(
                        child: Text(
                          _tf('sh_pending_paren',
                              {'name': pendingSub.proposedName}),
                          style: const TextStyle(
                            fontSize: 13,
                            color: EfuridePalette.shopperAccent,
                            fontWeight: FontWeight.w700,
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                    ],
                  ),
                ] else if (approvedSub.id.isNotEmpty) ...[
                  const SizedBox(height: 4),
                  Row(
                    children: [
                      const Icon(Icons.check_circle,
                          size: 12, color: EfuridePalette.online),
                      const SizedBox(width: 4),
                      Expanded(
                        child: Text(
                          '→ ${approvedSub.proposedName}',
                          style: const TextStyle(
                            fontSize: 13,
                            color: EfuridePalette.online,
                            fontWeight: FontWeight.w700,
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                    ],
                  ),
                ],
              ],
            ),
          ),
          const SizedBox(width: 10),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              if (picked)
                Text(
                  '${actualPrice.toStringAsFixed(0)}',
                  style: const TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w900,
                      color: EfuridePalette.online),
                )
              else
                Text('~${(unitPrice * qty).toStringAsFixed(0)}',
                    style: const TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w900,
                        color: EfuridePalette.inkMuted)),
              const SizedBox(height: 2),
              Text(CountryConfig.currencyCode,
                  style: const TextStyle(
                      fontSize: 12, color: EfuridePalette.inkMuted)),
            ],
          ),
          const SizedBox(width: 10),
          if (!picked && pendingSub == null)
            OutlinedButton(
              onPressed: () => _openPickSheet(item),
              style: OutlinedButton.styleFrom(
                minimumSize: const Size(0, 34),
                padding:
                    const EdgeInsets.symmetric(horizontal: 12),
                side: const BorderSide(
                    color: EfuridePalette.shopperAccent),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8)),
              ),
              child: Text(_t('sh_pick'),
                  style: const TextStyle(
                    color: EfuridePalette.shopperAccent,
                    fontSize: 13.5,
                    fontWeight: FontWeight.w800,
                  )),
            )
          else if (!picked && pendingSub != null)
            const Icon(Icons.hourglass_top,
                size: 18, color: EfuridePalette.shopperAccent)
          else
            GestureDetector(
              onTap: () async {
                try {
                  await ShopperService.instance.markItemUnpicked(
                    taskId: widget.taskId,
                    orderItemId: id,
                  );
                  await _load();
                } catch (e) {
                  if (!mounted) return;
                  ErrorUI.showSnack(context, AppError.from(e));
                }
              },
              child: const Icon(Icons.refresh,
                  size: 18, color: EfuridePalette.inkMuted),
            ),
        ],
      ),
    );
  }

  Widget _bottomBar() {
    final showPick = _task?.status == 'in_progress';
    final allPicked = _allPicked;
    final hasReceipt = _receiptBytes != null ||
        (_task?.receiptUrl != null && _task!.receiptUrl!.isNotEmpty);

    return Container(
      padding: EdgeInsets.fromLTRB(
        16,
        12,
        16,
        12 + MediaQuery.of(context).padding.bottom,
      ),
      decoration: BoxDecoration(
        color: Colors.white,
        border:
            const Border(top: BorderSide(color: EfuridePalette.divider)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.04),
            blurRadius: 10,
            offset: const Offset(0, -3),
          ),
        ],
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (_task?.status == 'packed' || _task?.status == 'completed')
            _deliveryPanel()
          else if (showPick && allPicked && !hasReceipt)
            SizedBox(
              width: double.infinity,
              child: OutlinedButton.icon(
                onPressed: _captureReceipt,
                icon: const KIcon(Icons.receipt_long_outlined, size: 18),
                label: Text(_t('sh_capture_receipt'),
                    style: const TextStyle(fontWeight: FontWeight.w800)),
                style: OutlinedButton.styleFrom(
                  minimumSize: const Size(0, 46),
                  foregroundColor: EfuridePalette.ink,
                  side: const BorderSide(color: EfuridePalette.divider),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12)),
                ),
              ),
            )
          else if (showPick && hasReceipt && allPicked) ...[
            Row(
              children: [
                const KIcon(Icons.receipt_long,
                    size: 16, color: EfuridePalette.online),
                const SizedBox(width: 6),
                Expanded(
                  child: Text(_t('sh_receipt_captured'),
                      style: const TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w700,
                          color: EfuridePalette.online)),
                ),
                TextButton(
                  onPressed: _captureReceipt,
                  child: Text(_t('sh_retake'),
                      style: const TextStyle(fontSize: 13.5)),
                ),
              ],
            ),
            const SizedBox(height: 10),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                onPressed: _sealPackage,
                icon: const Icon(Icons.qr_code_2, size: 20),
                label: Text(_t('sh_seal_qr'),
                    style: const TextStyle(
                        fontSize: 15, fontWeight: FontWeight.w900)),
                style: ElevatedButton.styleFrom(
                  backgroundColor: EfuridePalette.shopperAccent,
                  foregroundColor: Colors.white,
                  minimumSize: const Size(0, 52),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(14)),
                  elevation: 0,
                ),
              ),
            ),
          ] else if (showPick) ...[
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: EfuridePalette.cream,
                borderRadius: BorderRadius.circular(10),
              ),
              child: Row(
                children: [
                  const Icon(Icons.info_outline,
                      size: 16, color: EfuridePalette.inkMuted),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      (_items.length - _pickedCount) == 1
                          ? _t('sh_pick_remaining_one')
                          : _tf('sh_pick_remaining_many',
                              {'n': _items.length - _pickedCount}),
                      style: const TextStyle(
                          fontSize: 13.5,
                          color: EfuridePalette.inkMuted),
                    ),
                  ),
                ],
              ),
            ),
          ] else
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                onPressed: _startShopping,
                icon: const Icon(Icons.play_arrow, size: 18),
                label: Text(_t('sh_start_shopping'),
                    style: const TextStyle(
                        fontSize: 15, fontWeight: FontWeight.w900)),
                style: ElevatedButton.styleFrom(
                  backgroundColor: EfuridePalette.shopperAccent,
                  foregroundColor: Colors.white,
                  minimumSize: const Size(0, 52),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(14)),
                  elevation: 0,
                ),
              ),
            ),
        ],
      ),
    );
  }
}

// ══════════════════════════════════════════════════════════════
// PICK SHEET
// ══════════════════════════════════════════════════════════════
class _PickSheet extends StatefulWidget {
  final Map<String, dynamic> item;
  final void Function(double price, double? weight, String? notes)
      onConfirm;
  final VoidCallback onSubstitute;

  const _PickSheet({
    required this.item,
    required this.onConfirm,
    required this.onSubstitute,
  });

  @override
  State<_PickSheet> createState() => _PickSheetState();
}

class _PickSheetState extends State<_PickSheet> {
  String _t(String key) => S.of(context).t(key);
  String _tf(String key, Map<String, Object> args) =>
      S.of(context).tf(key, args);

  late final TextEditingController _priceCtrl;
  final _weightCtrl = TextEditingController();
  final _notesCtrl = TextEditingController();

  @override
  void initState() {
    super.initState();
    _priceCtrl = TextEditingController(
      text: ((widget.item['unit_price'] ?? 0) as num)
          .toStringAsFixed(0),
    );
  }

  @override
  void dispose() {
    _priceCtrl.dispose();
    _weightCtrl.dispose();
    _notesCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final name = (widget.item['name'] ?? '').toString();
    final qty = widget.item['qty'] ?? 1;

    return Padding(
      padding: EdgeInsets.only(
        left: 20,
        right: 20,
        top: 20,
        bottom: MediaQuery.of(context).viewInsets.bottom + 24,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Center(
            child: Container(
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                color: Colors.grey.shade300,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
          ),
          const SizedBox(height: 18),
          Text(name,
              style: const TextStyle(
                  fontSize: 17,
                  fontWeight: FontWeight.w900,
                  color: EfuridePalette.ink)),
          const SizedBox(height: 4),
          Text(_tf('sh_quantity', {'qty': qty.toString()}),
              style: const TextStyle(
                  fontSize: 13.5, color: EfuridePalette.inkMuted)),
          const SizedBox(height: 18),

          TextField(
            controller: _priceCtrl,
            keyboardType: TextInputType.number,
            inputFormatters: [
              FilteringTextInputFormatter.digitsOnly,
            ],
            decoration: InputDecoration(
              labelText: _tf('sh_actual_price',
                  {'cur': CountryConfig.currencyCode}),
              filled: true,
              fillColor: EfuridePalette.cream,
              contentPadding: const EdgeInsets.symmetric(
                  horizontal: 14, vertical: 12),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide.none,
              ),
            ),
          ),
          const SizedBox(height: 10),
          TextField(
            controller: _weightCtrl,
            keyboardType:
                const TextInputType.numberWithOptions(decimal: true),
            decoration: InputDecoration(
              labelText: _t('sh_weight_opt'),
              filled: true,
              fillColor: EfuridePalette.cream,
              contentPadding: const EdgeInsets.symmetric(
                  horizontal: 14, vertical: 12),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide.none,
              ),
            ),
          ),
          const SizedBox(height: 10),
          TextField(
            controller: _notesCtrl,
            maxLines: 2,
            decoration: InputDecoration(
              labelText: _t('sh_notes_opt'),
              filled: true,
              fillColor: EfuridePalette.cream,
              contentPadding: const EdgeInsets.symmetric(
                  horizontal: 14, vertical: 12),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide.none,
              ),
            ),
          ),
          const SizedBox(height: 20),

          Row(
            children: [
              Expanded(
                child: OutlinedButton(
                  onPressed: widget.onSubstitute,
                  style: OutlinedButton.styleFrom(
                    minimumSize: const Size(0, 50),
                    side: const BorderSide(
                        color: EfuridePalette.shopperAccent),
                    foregroundColor: EfuridePalette.shopperAccent,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12)),
                  ),
                  child: Text(_t('sh_substitute'),
                      style: const TextStyle(fontWeight: FontWeight.w800)),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                flex: 2,
                child: ElevatedButton(
                  onPressed: () {
                    final price =
                        double.tryParse(_priceCtrl.text.trim());
                    if (price == null) return;
                    final weight = double.tryParse(
                        _weightCtrl.text.trim());
                    final notes = _notesCtrl.text.trim();
                    widget.onConfirm(
                      price,
                      weight,
                      notes.isEmpty ? null : notes,
                    );
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: EfuridePalette.shopperAccent,
                    foregroundColor: Colors.white,
                    minimumSize: const Size(0, 50),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12)),
                    elevation: 0,
                  ),
                  child: Text(_t('sh_confirm_pick'),
                      style: const TextStyle(
                          fontSize: 14, fontWeight: FontWeight.w900)),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
