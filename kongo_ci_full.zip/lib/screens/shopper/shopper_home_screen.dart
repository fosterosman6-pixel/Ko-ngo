// lib/screens/shopper/shopper_home_screen.dart
//
// Shopper home. Shows new tasks, stats, and active tasks.
// Refreshes on app resume + pull-to-refresh.
// Notifications icon wired to /notifications.

import 'dart:async';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:efuride_app/providers/auth_provider.dart';
import 'package:efuride_app/widgets/kongo_brand.dart';
import 'package:efuride_app/screens/shared/messages_screen.dart';
import 'package:efuride_app/config/efuride_palette.dart';
import 'package:efuride_app/config/country_config.dart';
import 'package:efuride_app/l10n/app_strings.dart';
import 'package:efuride_app/services/shopper_service.dart';
import 'package:efuride_app/screens/shopper/shopper_task_detail_screen.dart';
import 'package:efuride_app/utils/app_error.dart';
import 'package:efuride_app/utils/error_ui.dart';
import 'package:supabase_flutter/supabase_flutter.dart' show RealtimeChannel;
import 'package:efuride_app/widgets/k_icon.dart';

class ShopperHomeScreen extends StatefulWidget {
  const ShopperHomeScreen({super.key});

  @override
  State<ShopperHomeScreen> createState() => _ShopperHomeScreenState();
}

class _ShopperHomeScreenState extends State<ShopperHomeScreen>
    with WidgetsBindingObserver {
  String _t(String key) => S.of(context).t(key);
  String _tf(String key, Map<String, Object> args) =>
      S.of(context).tf(key, args);

  String _greetingLine() {
    final h = DateTime.now().hour;
    final k = h < 12
        ? 'good_morning'
        : h < 17
            ? 'good_afternoon'
            : 'good_evening';
    return '${S.of(context).t(k)},';
  }

  StreamSubscription<List<ShopperTask>>? _tasksSub;
  List<ShopperTask> _tasks = [];
  bool _isLoading = true;
  AppError? _error;

  String _firstName = 'Shopper';
  ShopperStats? _stats;

  bool _online = false;
  bool _togglingOnline = false;

  // ── Open orders pool ──
  List<OpenOrder> _openOrders = [];
  bool _loadingPool = false;
  String? _claimingId;
  RealtimeChannel? _poolChannel;
  Timer? _poolDebounce;
  Timer? _poolPoll;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _loadProfileName();
    _loadOnline();
    _subscribeToTasks();
    _loadStats();
    _loadOpenOrders();
    _poolChannel = ShopperService.instance.watchOpenOrders(() {
      // Many order updates arrive together — refresh once.
      _poolDebounce?.cancel();
      _poolDebounce =
          Timer(const Duration(milliseconds: 800), _loadOpenOrders);
    });
    // New orders from customers: refresh the pool while online.
    _poolPoll = Timer.periodic(const Duration(seconds: 20), (_) {
      if (_online && mounted) _loadOpenOrders();
    });
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _tasksSub?.cancel();
    _poolChannel?.unsubscribe();
    _poolDebounce?.cancel();
    _poolPoll?.cancel();
    super.dispose();
  }

  Future<void> _loadOpenOrders() async {
    if (!mounted) return;
    setState(() => _loadingPool = true);
    try {
      final list = await ShopperService.instance.loadOpenOrders();
      if (!mounted) return;
      setState(() => _openOrders = list);
    } catch (e) {
      debugPrint('loadOpenOrders failed: $e');
    } finally {
      if (mounted) setState(() => _loadingPool = false);
    }
  }

  Future<void> _claim(OpenOrder o) async {
    if (_claimingId != null) return;
    setState(() => _claimingId = o.id);
    try {
      final taskId = await ShopperService.instance.claimOrder(o.id);
      if (!mounted) return;
      setState(() => _openOrders.removeWhere((x) => x.id == o.id));
      ErrorUI.showSnack(
        context,
        AppError(
          title: _t('sh_task_accepted'),
          message: _t('sh_head_to_store'),
          icon: Icons.check_circle_outline,
        ),
      );
      await Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => ShopperTaskDetailScreen(
            taskId: taskId,
            orderId: o.id,
            storeName: o.storeName,
          ),
        ),
      );
    } catch (e) {
      if (!mounted) return;
      ErrorUI.showSnack(
        context,
        AppError(
          title: _t('sp_taken_title'),
          message: _t('sp_taken_hint'),
          icon: Icons.info_outline,
        ),
      );
      _loadOpenOrders();
    } finally {
      if (mounted) setState(() => _claimingId = null);
    }
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      _manualRefresh();
    }
  }

  // ═══════════════════════════════════════════════════════════
  // LOAD
  // ═══════════════════════════════════════════════════════════
  Future<void> _loadProfileName() async {
    try {
      final profile = await ShopperService.instance.loadProfileFirstName();
      if (!mounted || profile == null) return;
      setState(() => _firstName = profile);
    } catch (e) {
      debugPrint('loadProfileName failed: $e');
    }
  }

  Future<void> _loadOnline() async {
    final v = await ShopperService.instance.loadOnline();
    if (!mounted) return;
    setState(() => _online = v);
  }

  bool get _hasTaskInProgress =>
      _tasks.any((t) => t.isActive && t.status != 'assigned');

  Future<void> _toggleOnline() async {
    if (_togglingOnline) return;
    final next = !_online;

    if (!next && _hasTaskInProgress) {
      ErrorUI.showSnack(
        context,
        AppError(
          title: _t('sh_task_in_progress'),
          message: _t('sh_finish_before_offline'),
          icon: Icons.info_outline,
        ),
      );
      return;
    }

    setState(() {
      _togglingOnline = true;
      _online = next;
    });
    try {
      await ShopperService.instance.setOnline(next);
    } catch (e) {
      if (!mounted) return;
      setState(() => _online = !next);
      ErrorUI.showSnack(
        context,
        AppError.from(e, onRetry: _toggleOnline),
      );
    } finally {
      if (mounted) setState(() => _togglingOnline = false);
    }
  }

  Future<void> _loadStats() async {
    try {
      final stats = await ShopperService.instance.loadStats();
      if (!mounted) return;
      setState(() => _stats = stats);
    } catch (e) {
      debugPrint('loadStats failed: $e');
    }
  }

  void _subscribeToTasks() {
    setState(() {
      _isLoading = true;
      _error = null;
    });

    _tasksSub?.cancel();
    _tasksSub = ShopperService.instance.streamTasks().listen(
      (tasks) {
        if (!mounted) return;
        setState(() {
          _tasks = tasks.where((t) => t.isActive || t.isPacked).toList();
          _isLoading = false;
        });
      },
      onError: (e) {
        if (!mounted) return;
        setState(() {
          _isLoading = false;
          _error = AppError.from(e, onRetry: _subscribeToTasks);
        });
      },
    );
  }

  Future<void> _manualRefresh() async {
    await Future.wait([
      _loadStats(),
      _loadProfileName(),
      _loadOnline(),
      _loadOpenOrders(),
    ]);
  }

  // ═══════════════════════════════════════════════════════════
  // ACTIONS
  // ═══════════════════════════════════════════════════════════
  Future<void> _acceptTask(ShopperTask task) async {
    try {
      await ShopperService.instance.acceptTask(task.id);
      if (!mounted) return;
      ErrorUI.showSnack(
        context,
        AppError(
          title: _t('sh_task_accepted'),
          message: _t('sh_head_to_store'),
          icon: Icons.check_circle_outline,
        ),
      );
    } catch (e) {
      if (!mounted) return;
      ErrorUI.showSnack(
        context,
        AppError.from(e, onRetry: () => _acceptTask(task)),
      );
    }
  }

  Future<void> _declineTask(ShopperTask task) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16)),
        title: Text(_t('sh_decline_q')),
        content: Text(_t('sh_reassigned')),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: Text(_t('sh_keep')),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
                backgroundColor: EfuridePalette.dropoff),
            onPressed: () => Navigator.pop(context, true),
            child: Text(_t('sh_decline')),
          ),
        ],
      ),
    );
    if (confirmed != true) return;

    try {
      await ShopperService.instance
          .declineTask(task.id, reason: 'Declined from app');
    } catch (e) {
      if (!mounted) return;
      ErrorUI.showSnack(context, AppError.from(e));
    }
  }

  void _openTask(ShopperTask task) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => ShopperTaskDetailScreen(
          taskId: task.id,
          orderId: task.orderId,
          storeName: task.storeName,
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // BUILD
  // ═══════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        _header(),
        Expanded(
          child: RefreshIndicator(
            color: EfuridePalette.shopperAccent,
            onRefresh: _manualRefresh,
            child: ListView(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
              physics: const AlwaysScrollableScrollPhysics(),
              children: [
                _newTaskSection(),
                if (_online) ...[
                  const SizedBox(height: 4),
                  _categoryChips(),
                  const SizedBox(height: 14),
                  _openOrdersSection(),
                ],
                const SizedBox(height: 20),
                _statsSection(),
                const SizedBox(height: 20),
                _activeTasksSection(),
                const SizedBox(height: 20),
              ],
            ),
          ),
        ),
      ],
    );
  }

  // ═══════════════════════════════════════════════════════════
  // HEADER
  // ═══════════════════════════════════════════════════════════
  Widget _header() {
    return Container(
      decoration: const BoxDecoration(
        color: EfuridePalette.cream,
      ),
      child: SafeArea(
        bottom: false,
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 10, 16, 12),
              child: Row(
                children: [
                  KongoBrand(role: _t('sh_role')),
                  const Spacer(),
                  const MessagesIconButton(color: EfuridePalette.ink),
                  IconButton(
                    onPressed: () =>
                        Navigator.pushNamed(context, '/notifications'),
                    icon: const Icon(Icons.notifications_none_rounded,
                        color: EfuridePalette.ink, size: 24),
                  ),
                ],
              ),
            ),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 18),
              decoration: const BoxDecoration(
                color: EfuridePalette.cream,
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(24),
                  topRight: Radius.circular(24),
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(_greetingLine(),
                      style: const TextStyle(
                        color: EfuridePalette.inkMuted,
                        fontSize: 14,
                        fontWeight: FontWeight.w500,
                      )),
                  const SizedBox(height: 2),
                  Row(
                    children: [
                      Expanded(
                        child: Text(_firstName,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              color: EfuridePalette.ink,
                              fontSize: 22,
                              fontWeight: FontWeight.w900,
                              letterSpacing: -0.3,
                            )),
                      ),
                      const SizedBox(width: 10),
                      _onlineChip(),
                      const SizedBox(width: 12),
                        GestureDetector(
                          onTap: () => Navigator.pushNamedAndRemoveUntil(
                              context, '/shopper?tab=settings', (_) => false),
                          child: Builder(builder: (ctx) {
                            final pic = ctx.watch<AuthProvider>().avatarUrl;
                            return CircleAvatar(
                              radius: 26,
                              backgroundColor: EfuridePalette.greyBg,
                              backgroundImage: (pic != null && pic.isNotEmpty)
                                  ? NetworkImage(pic)
                                  : null,
                              child: (pic == null || pic.isEmpty)
                                  ? const KIcon(Icons.person,
                                      size: 26, color: EfuridePalette.inkMuted)
                                  : null,
                            );
                          }),
                        ),
                    ],
                  ),
                  const SizedBox(height: 4),
                  Text(_t('sh_pick_weigh_pack'),
                      style: const TextStyle(
                          color: EfuridePalette.inkMuted, fontSize: 14)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _onlineChip() {
    return GestureDetector(
      onTap: _toggleOnline,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 250),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
        decoration: BoxDecoration(
          color: _online
              ? EfuridePalette.onlineDeep
              : EfuridePalette.inkMuted,
          borderRadius: BorderRadius.circular(20),
          boxShadow: _online
              ? [
                  BoxShadow(
                    color: EfuridePalette.online.withValues(alpha: 0.35),
                    blurRadius: 10,
                    spreadRadius: 1,
                  ),
                ]
              : null,
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            _togglingOnline
                ? const SizedBox(
                    width: 10,
                    height: 10,
                    child: CircularProgressIndicator(
                        strokeWidth: 2, color: Colors.white),
                  )
                : Container(
                    width: 8,
                    height: 8,
                    decoration: const BoxDecoration(
                      color: Colors.white,
                      shape: BoxShape.circle,
                    ),
                  ),
            const SizedBox(width: 8),
            Text(_online ? _t('sh_online') : _t('sh_offline'),
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 13,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 0.8,
                )),
          ],
        ),
      ),
    );
  }

  Widget _offlineCard() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: EfuridePalette.divider),
      ),
      child: Row(
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              color: EfuridePalette.shopperAccent.withValues(alpha: 0.12),
              borderRadius: BorderRadius.circular(12),
            ),
            child: const Icon(Icons.power_settings_new,
                color: EfuridePalette.shopperAccent),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(_t('sh_offline_title'),
                    style: const TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w800,
                        color: EfuridePalette.ink)),
                const SizedBox(height: 2),
                Text(_t('sh_offline_hint'),
                    style: const TextStyle(
                        fontSize: 13.5, color: EfuridePalette.inkMuted)),
              ],
            ),
          ),
          TextButton(
            onPressed: _toggleOnline,
            child: Text(_t('sh_go_online'),
                style: const TextStyle(
                    fontWeight: FontWeight.w800,
                    color: EfuridePalette.shopperAccent)),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // OPEN ORDERS (waiting for a shopper)
  // ═══════════════════════════════════════════════════════════
  IconData _serviceIcon(String s) {
    switch (s) {
      case 'Grocery':
        return Icons.shopping_basket_rounded;
      case 'Pharmacy':
        return Icons.medical_services_rounded;
      default:
        return Icons.restaurant_rounded;
    }
  }

  String _ago(DateTime? t) {
    if (t == null) return '';
    final m = DateTime.now().difference(t).inMinutes;
    if (m < 1) return _t('just_now');
    if (m < 60) return '$m min';
    return '${m ~/ 60} h';
  }


  // ── Category filter (what kind of orders to show) ──
  String _filter = 'all';

  List<OpenOrder> get _filteredOrders {
    if (_filter == 'all') return _openOrders;
    return _openOrders
        .where((o) => o.serviceType.toLowerCase() == _filter)
        .toList();
  }

  Widget _categoryChips() {
    final chips = <(String, String)>[
      ('all', tr('All')),
      ('grocery', tr('Groceries')),
      ('food', tr('Restaurant')),
      ('pharmacy', tr('Pharmacy')),
    ];
    return SizedBox(
      height: 44,
      child: ListView(
        scrollDirection: Axis.horizontal,
        children: [
          for (final c in chips)
            Padding(
              padding: const EdgeInsets.only(right: 8),
              child: ChoiceChip(
                label: Text(c.$2,
                    style: TextStyle(
                        fontWeight: FontWeight.w700,
                        color: _filter == c.$1
                            ? Colors.white
                            : EfuridePalette.ink)),
                selected: _filter == c.$1,
                selectedColor: EfuridePalette.ink,
                backgroundColor: Colors.white,
                showCheckmark: false,
                onSelected: (_) => setState(() => _filter = c.$1),
              ),
            ),
        ],
      ),
    );
  }

  Widget _openOrdersSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Expanded(
              child: Text(
                '${_t('sp_open_orders')} (${_filteredOrders.length})',
                style: const TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.w900,
                    color: EfuridePalette.ink),
              ),
            ),
            if (_loadingPool)
              const SizedBox(
                width: 16,
                height: 16,
                child: CircularProgressIndicator(
                    strokeWidth: 2, color: EfuridePalette.shopperAccent),
              )
            else
              IconButton(
                tooltip: _t('retry'),
                onPressed: _loadOpenOrders,
                icon: const Icon(Icons.refresh, size: 20),
              ),
          ],
        ),
        const SizedBox(height: 6),
        if (_filteredOrders.isEmpty && !_loadingPool)
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: EfuridePalette.divider),
            ),
            child: Text(_t('sp_none'),
                style: const TextStyle(
                    fontSize: 14, color: EfuridePalette.inkMuted)),
          )
        else
          ..._filteredOrders.map(_openOrderCard),
      ],
    );
  }

  Widget _openOrderCard(OpenOrder o) {
    final busy = _claimingId == o.id;
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: EfuridePalette.divider),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              CircleAvatar(
                radius: 18,
                backgroundColor:
                    EfuridePalette.shopperAccent.withValues(alpha: 0.12),
                child: Icon(_serviceIcon(o.serviceType),
                    size: 18, color: EfuridePalette.shopperAccent),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(o.storeName,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                            fontWeight: FontWeight.w800, fontSize: 14)),
                    if (o.storeAddress.isNotEmpty)
                      Text(o.storeAddress,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                              fontSize: 13.5,
                              color: EfuridePalette.inkMuted)),
                  ],
                ),
              ),
              Text(_ago(o.createdAt),
                  style: const TextStyle(
                      fontSize: 13, color: EfuridePalette.inkMuted)),
            ],
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              const Icon(Icons.shopping_bag_outlined,
                  size: 14, color: EfuridePalette.inkMuted),
              const SizedBox(width: 4),
              Text(_tf('sp_items', {'n': o.itemCount}),
                  style: const TextStyle(fontSize: 13.5)),
              const SizedBox(width: 12),
              Text(CountryConfig.money(o.subtotal),
                  style: const TextStyle(
                      fontSize: 13.5, fontWeight: FontWeight.w700)),
            ],
          ),
          if (o.deliveryAddress.isNotEmpty) ...[
            const SizedBox(height: 4),
            Row(
              children: [
                const KIcon(Icons.location_on_outlined,
                    size: 14, color: EfuridePalette.dropoff),
                const SizedBox(width: 4),
                Expanded(
                  child: Text('${_t('sp_deliver_to')} ${o.deliveryAddress}',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                          fontSize: 13.5, color: EfuridePalette.inkMuted)),
                ),
              ],
            ),
          ],
          const SizedBox(height: 10),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: busy || _claimingId != null ? null : () => _claim(o),
              icon: busy
                  ? const SizedBox(
                      width: 16,
                      height: 16,
                      child: CircularProgressIndicator(
                          strokeWidth: 2, color: Colors.white))
                  : const Icon(Icons.check, size: 18),
              label: Text(_t('sp_take'),
                  style: const TextStyle(fontWeight: FontWeight.w900)),
              style: ElevatedButton.styleFrom(
                backgroundColor: EfuridePalette.shopperAccent,
                foregroundColor: Colors.white,
                minimumSize: const Size(0, 44),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12)),
                elevation: 0,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // NEW TASK SECTION
  // ═══════════════════════════════════════════════════════════
  Widget _newTaskSection() {
    final newTasks = _tasks.where((t) => t.status == 'assigned').toList();

    if (_isLoading) {
      return const Padding(
        padding: EdgeInsets.symmetric(vertical: 40),
        child: Center(
          child: CircularProgressIndicator(
              color: EfuridePalette.shopperAccent),
        ),
      );
    }

    if (_error != null) return ErrorUI.inline(_error!);

    if (newTasks.isEmpty) {
      return _online ? const SizedBox.shrink() : _offlineCard();
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(left: 4, bottom: 10),
          child: Text(_t('sh_new_task'),
              style: const TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w800,
                  color: EfuridePalette.ink)),
        ),
        ...newTasks.map(_newTaskCard),
      ],
    );
  }

  Widget _newTaskCard(ShopperTask task) {
    final shortId = task.orderId.length >= 8
        ? task.orderId.substring(0, 8)
        : task.orderId;

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            EfuridePalette.shopperAccent.withValues(alpha: 0.12),
            EfuridePalette.shopperAccent.withValues(alpha: 0.03),
          ],
        ),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(
            color:
                EfuridePalette.shopperAccent.withValues(alpha: 0.4),
            width: 1.5),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: EfuridePalette.shopperAccent,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: const Icon(Icons.shopping_bag,
                    color: Colors.white, size: 20),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Text(_t('sh_new_task'),
                    style: const TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w900,
                        color: EfuridePalette.ink)),
              ),
              Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: 8, vertical: 3),
                decoration: BoxDecoration(
                  color: EfuridePalette.shopperAccent
                      .withValues(alpha: 0.15),
                  borderRadius: BorderRadius.circular(6),
                ),
                child: Text(shortId,
                    style: const TextStyle(
                        fontSize: 12.5,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 0.4,
                        color: EfuridePalette.shopperAccent)),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Text(task.storeName,
              style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w900,
                  color: EfuridePalette.ink)),
          const SizedBox(height: 4),
          Text(
            _tf('sh_items_est', {
              'n': task.itemCount,
              'amt': CountryConfig.money(task.estimatedTotal),
            }),
            style: const TextStyle(
                fontSize: 14, color: EfuridePalette.inkMuted),
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(
                child: OutlinedButton(
                  onPressed: () => _declineTask(task),
                  style: OutlinedButton.styleFrom(
                    foregroundColor: EfuridePalette.dropoff,
                    side: const BorderSide(color: EfuridePalette.dropoff),
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12)),
                  ),
                  child: Text(_t('sh_decline'),
                      style: const TextStyle(fontWeight: FontWeight.w800)),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                flex: 2,
                child: ElevatedButton(
                  onPressed: () => _acceptTask(task),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: EfuridePalette.shopperAccent,
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12)),
                    elevation: 0,
                  ),
                  child: Text(_t('sh_accept'),
                      style: const TextStyle(fontWeight: FontWeight.w900)),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // STATS
  // ═══════════════════════════════════════════════════════════
  Widget _statsSection() {
    final s = _stats;
    return Row(
      children: [
        _statTile(_t('sh_tasks_today'), '${s?.tasksToday ?? 0}'),
        const SizedBox(width: 10),
        _statTile(_t('sh_hours'),
            (s?.hoursThisWeek ?? 0).toStringAsFixed(1)),
        const SizedBox(width: 10),
        _statTile(_t('sh_rating'),
            (s?.rating ?? 5.0).toStringAsFixed(1)),
      ],
    );
  }

  Widget _statTile(String label, String value) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: EfuridePalette.divider),
        ),
        child: Column(
          children: [
            Text(value,
                style: const TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.w900,
                    color: EfuridePalette.ink)),
            const SizedBox(height: 2),
            Text(label,
                style: const TextStyle(
                    fontSize: 13, color: EfuridePalette.inkMuted)),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // ACTIVE TASKS
  // ═══════════════════════════════════════════════════════════
  Widget _activeTasksSection() {
    final active = _tasks.where((t) => t.status != 'assigned').toList();

    if (active.isEmpty) {
      return const SizedBox.shrink();
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(left: 4, bottom: 10),
          child: Text(_t('sh_active_tasks'),
              style: const TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w800,
                  color: EfuridePalette.ink)),
        ),
        ...active.map(_activeTaskCard),
      ],
    );
  }

  Widget _activeTaskCard(ShopperTask task) {
    final shortId = task.orderId.length >= 8
        ? task.orderId.substring(0, 8)
        : task.orderId;

    final statusLabel = task.isPacked
        ? _t('sh_packed_status')
        : task.status == 'in_progress'
            ? _tf('sh_picking', {
                'picked': task.itemsPicked,
                'total': task.itemCount,
              })
            : task.status == 'substitution_pending'
                ? _t('sh_wait_customer')
                : _t('sh_heading_store');

    return InkWell(
      onTap: () => _openTask(task),
      borderRadius: BorderRadius.circular(14),
      child: Container(
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: EfuridePalette.divider),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(Icons.shopping_cart_outlined,
                    size: 20, color: EfuridePalette.shopperAccent),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(shortId,
                          style: const TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.w800,
                              color: EfuridePalette.ink)),
                      Text(task.storeName,
                          style: const TextStyle(
                              fontSize: 13,
                              color: EfuridePalette.inkMuted)),
                    ],
                  ),
                ),
                const Icon(Icons.chevron_right,
                    color: EfuridePalette.inkMuted, size: 20),
              ],
            ),
            const SizedBox(height: 12),
            ClipRRect(
              borderRadius: BorderRadius.circular(4),
              child: LinearProgressIndicator(
                value: task.progress,
                minHeight: 6,
                backgroundColor: EfuridePalette.divider,
                valueColor: const AlwaysStoppedAnimation(
                    EfuridePalette.shopperAccent),
              ),
            ),
            const SizedBox(height: 6),
            Text(
              statusLabel,
              style: const TextStyle(
                  fontSize: 13, color: EfuridePalette.inkMuted),
            ),
          ],
        ),
      ),
    );
  }
}
