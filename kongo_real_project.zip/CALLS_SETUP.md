# In-app calls: setup (one time)

1. pubspec.yaml → dependencies:
       flutter_webrtc: ^0.12.5
2. android/app/src/main/AndroidManifest.xml → inside <manifest>:
       <uses-permission android:name="android.permission.RECORD_AUDIO"/>
       <uses-permission android:name="android.permission.MODIFY_AUDIO_SETTINGS"/>
       <uses-permission android:name="android.permission.BLUETOOTH"/>
       <uses-permission android:name="android.permission.BLUETOOTH_CONNECT"/>
   android/app/build.gradle → minSdkVersion 23 (or higher)
3. iOS (later): NSMicrophoneUsageDescription in Info.plist.
4. Run step29 SQL (adds app_settings.call_ice_servers).
5. For calls to connect on every mobile network, add a TURN server
   (e.g. from Metered, Twilio or your own coturn) in SQL:

   update app_settings set call_ice_servers = '[
     {"urls":"stun:stun.l.google.com:19302"},
     {"urls":"turn:YOUR-TURN-HOST:3478","username":"USER","credential":"PASSWORD"}
   ]'::jsonb where id = 1;

Both people need the trip open in the app (customer: tracking screen,
driver: active trip). Calls go over the internet, no phone minutes.
