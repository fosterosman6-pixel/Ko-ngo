// web/firebase-messaging-sw.js

importScripts('https://www.gstatic.com/firebasejs/10.12.0/firebase-app-compat.js');
importScripts('https://www.gstatic.com/firebasejs/10.12.0/firebase-messaging-compat.js');

firebase.initializeApp({
  apiKey: 'AIzaSyCXMWlWMsA3SzKz9DEz0PDAO-_2yoLmAkc',
  authDomain: 'efuride-a29f1.firebaseapp.com',
  projectId: 'efuride-a29f1',
  storageBucket: 'efuride-a29f1.firebasestorage.app',
  messagingSenderId: '171726157114',
  appId: '1:171726157114:web:ab1d3d66e88c8397f8cc03',
  measurementId: 'G-9T69PW4YZ0',
});

const messaging = firebase.messaging();

messaging.onBackgroundMessage((payload) => {
  console.log('[SW] Background message:', payload);

  const title = payload.data?.title || payload.notification?.title || 'eFuride';
  const body = payload.data?.body || payload.notification?.body || '';

  self.registration.showNotification(title, {
    body: body,
    icon: '/icons/Icon-192.png',
    badge: '/icons/Icon-192.png',
    data: payload.data || {},
    tag: payload.data?.ride_id || 'default',
  });
});

self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  event.waitUntil(
    clients.matchAll({ type: 'window', includeUncontrolled: true }).then((list) => {
      for (const client of list) {
        if ('focus' in client) return client.focus();
      }
      if (clients.openWindow) return clients.openWindow('/');
    })
  );
});
