// lib/services/realtime_notifications_service.dart

import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:efuride_app/services/ring_service.dart' show activeChatRideId, RingService;
import 'package:efuride_app/utils/log.dart';

class _Palette {
  static const ink = Color(0xFF1A1A1A);
  static const inkMuted = Color(0xFF575047);
  static const accent = Color(0xFFF2B705);
  static const accentInk = Color(0xFF0B1220);
  static const divider = Color(0xFFE8E2D5);
  static const blue = Color(0xFF1E88E5);
}

class RealtimeNotifications {
  RealtimeNotifications._();
  static final RealtimeNotifications instance = RealtimeNotifications._();
  static const _tag = 'RealtimeNotifications';

  RealtimeChannel? _channel;

  void start({
    required GlobalKey<ScaffoldMessengerState> messengerKey,
    required String role, // <--- REQUIRED ROLE
  }) {
    final user = Supabase.instance.client.auth.currentUser;
    if (user == null) return;

    _channel?.unsubscribe();
    _channel = Supabase.instance.client
        .channel(
          'notifications_${user.id}_$role',
        )
        .onPostgresChanges(
          event: PostgresChangeEvent.insert,
          schema: 'public',
          table: 'notifications',
          filter: PostgresChangeFilter(
            type: PostgresChangeFilterType.eq,
            column: 'user_id',
            value: user.id,
          ),
          callback: (payload) {
            final n = payload.newRecord;
            // rows written without a role are for whoever is signed in (the app
            // never sets one), so only filter when a role is really present
            final notifRole = n['role']?.toString() ?? role;

            // 🛑 IGNORE notifications meant for other roles
            if (notifRole != role) return;

            final title = (n['title'] ?? '').toString();
            final body = (n['body'] ?? '').toString();
            final type = (n['type'] ?? '').toString();
            if (title.isEmpty) return;

            // 🎵 Trigger Ringing for High Priority Actions
            if (type == 'ride_request' || type == 'order_status' || type == 'task_assigned') {
              try {
                RingService.instance.showBackgroundRingNotification(
                  rideId: n['data']?['params']?['ride_id']?.toString() ?? '',
                  title: title,
                  body: body,
                );
              } catch (e) {
                debugPrint('RingService failed: $e');
              }
            }

            // 🔔 Short loud alert: driver accepted / nearby / arrived / chat
            const alertTypes = {
              'ride_accepted', 'driver_nearby', 'driver_arrived',
              'ride_arrived', 'chat_message', 'ride_returning', 'ride_returned',
            };
            if (alertTypes.contains(type)) {
              final d = n['data'];
              final rid = (d is Map ? (d['ride_id'] ?? d['params']?['ride_id']) : null)?.toString();
              final viewing = type == 'chat_message' && rid != null && rid == activeChatRideId.value;
              if (!viewing) {
                RingService.instance.showAlertNotification(
                  title: title, body: body, payload: rid, id: type.hashCode & 0x7fffffff,
                );
              }
            }

            // Don't pop a SnackBar for a chat message the user is already viewing
            if (type == 'chat_message') {
              final data = n['data'];
              final rideId = (data is Map ? data['ride_id'] : null)?.toString();
              if (rideId != null && rideId == activeChatRideId.value) {
                return;
              }
            }

            final messenger = messengerKey.currentState;
            if (messenger == null) return;

            messenger.showSnackBar(
              SnackBar(
                behavior: SnackBarBehavior.floating,
                backgroundColor: Colors.white,
                elevation: 6,
                margin: const EdgeInsets.all(12),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(14),
                  side: const BorderSide(color: _Palette.divider),
                ),
                duration: const Duration(seconds: 5),
                content: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: _Palette.blue.withOpacity(0.12),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: const Icon(
                        Icons.notifications_none,
                        color: _Palette.blue,
                        size: 20,
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(
                            title,
                            style: const TextStyle(
                              color: _Palette.ink,
                              fontWeight: FontWeight.bold,
                              fontSize: 14,
                            ),
                          ),
                          if (body.isNotEmpty) ...[
                            const SizedBox(height: 2),
                            Text(
                              body,
                              style: const TextStyle(
                                color: _Palette.inkMuted,
                                fontSize: 14,
                              ),
                            ),
                          ],
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        )
        .subscribe();

    Log.i(_tag, 'subscribed for user ${user.id} role $role');
  }

  void stop() {
    _channel?.unsubscribe();
    _channel = null;
    Log.i(_tag, 'unsubscribed');
  }
}
