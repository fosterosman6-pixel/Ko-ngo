// lib/main.dart
//
// ko!ngo · App entry point
// Firebase + Supabase init, FCM handlers, NotificationRouter,
// MultiProvider wiring, full route table.

import 'dart:async';

import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:provider/provider.dart';

import 'package:efuride_app/config/app_lang.dart';
import 'package:efuride_app/services/ring_launcher.dart';
import 'package:efuride_app/config/app_config.dart';
import 'package:efuride_app/config/readability.dart';
import 'package:efuride_app/l10n/app_strings.dart';
import 'package:efuride_app/providers/auth_provider.dart';
import 'package:efuride_app/providers/cart_provider.dart';
import 'package:efuride_app/providers/notification_provider.dart';
import 'package:efuride_app/providers/ride_provider.dart';
import 'package:efuride_app/services/ring_service.dart';
import 'package:efuride_app/services/device_guard.dart';
import 'package:efuride_app/services/app_control.dart';
import 'package:efuride_app/services/google_maps_service.dart';
import 'package:efuride_app/services/ride_watchdog_service.dart';
import 'package:efuride_app/services/notification_service.dart';
import 'package:efuride_app/services/notification_router.dart';
import 'package:efuride_app/services/realtime_notifications_service.dart';
import 'package:efuride_app/utils/log.dart';
import 'package:efuride_app/widgets/role_gate.dart';

// ── Auth ──
import 'package:efuride_app/screens/auth/auth_screen.dart';
import 'package:efuride_app/screens/auth/splash_screen.dart';
import 'package:efuride_app/screens/auth/role_select_screen.dart';

// ── Shells ──
import 'package:efuride_app/screens/customer/customer_shell.dart';
import 'package:efuride_app/screens/driver/driver_shell.dart';
import 'package:efuride_app/screens/shopper/shopper_shell.dart';
import 'package:efuride_app/screens/merchant/merchant_shell.dart';

// ── Customer ──
import 'package:efuride_app/screens/customer/customer_home_screen.dart' hide LatLng;
import 'package:efuride_app/screens/customer/customer_account_screen.dart';
import 'package:efuride_app/screens/customer/customer_profile_screen.dart';
import 'package:efuride_app/screens/customer/customer_settings_screen.dart';
import 'package:efuride_app/screens/customer/customer_privacy_screen.dart';
import 'package:efuride_app/screens/customer/trip_complete_screen.dart';
import 'package:efuride_app/screens/customer/favorite_places_screen.dart';
import 'package:efuride_app/screens/customer/scheduled_rides_screen.dart';
import 'package:efuride_app/screens/customer/loyalty_screen.dart';
import 'package:efuride_app/screens/customer/referral_screen.dart';
import 'package:efuride_app/screens/customer/ride_history_screen.dart';
import 'package:efuride_app/screens/customer/corporate_screen.dart';
import 'package:efuride_app/screens/customer/analytics_screen.dart';
import 'package:efuride_app/screens/customer/customer_food_screen.dart';
import 'package:efuride_app/screens/customer/customer_restaurant_menu_screen.dart';
import 'package:efuride_app/screens/customer/customer_store_menu_screen.dart';
import 'package:efuride_app/screens/customer/customer_grocery_screen.dart';
import 'package:efuride_app/screens/customer/customer_pharmacy_screen.dart';
import 'package:efuride_app/screens/customer/hiring_hub_screen.dart';
import 'package:efuride_app/screens/customer/customer_category_screen.dart';
import 'package:efuride_app/screens/customer/customer_cart_screen.dart';
import 'package:efuride_app/screens/customer/customer_substitution_approval_screen.dart';
import 'package:efuride_app/screens/customer/order_tracking_screen.dart';
import 'package:efuride_app/screens/customer/booking_summary_screen.dart';
import 'package:efuride_app/screens/customer/select_destination_screen.dart';

// ── Driver ──
import 'package:efuride_app/screens/driver/driver_home_screen.dart';
import 'package:efuride_app/screens/driver/driver_onboarding_screen.dart';
import 'package:efuride_app/screens/driver/driver_bank_details_screen.dart';
import 'package:efuride_app/screens/driver/driver_document_upload_screen.dart';
import 'package:efuride_app/screens/driver/driver_profile_screen.dart';
import 'package:efuride_app/screens/driver/driver_earnings_screen.dart';
import 'package:efuride_app/screens/driver/driver_settings_screen.dart';
import 'package:efuride_app/screens/driver/driver_training_screen.dart';
import 'package:efuride_app/screens/driver/incoming_ride_ring_screen.dart';
import 'package:efuride_app/screens/driver/trip_ended_screen.dart';
import 'package:efuride_app/screens/driver/vehicle_management_screen.dart';
import 'package:efuride_app/screens/driver/active_trip_execution_screen.dart';

// ── Shopper ──
import 'package:efuride_app/screens/shopper/shopper_home_screen.dart';
import 'package:efuride_app/screens/shopper/shopper_tasks_screen.dart';
import 'package:efuride_app/screens/shopper/shopper_pay_screen.dart';
import 'package:efuride_app/screens/shopper/shopper_settings_screen.dart';
import 'package:efuride_app/screens/shopper/shopper_task_detail_screen.dart';

// ── Merchant ──
import 'package:efuride_app/screens/merchant/merchant_home_screen.dart';
import 'package:efuride_app/screens/merchant/merchant_orders_screen.dart';
import 'package:efuride_app/screens/merchant/merchant_menu_editor_screen.dart';
import 'package:efuride_app/screens/merchant/merchant_payouts_screen.dart';
import 'package:efuride_app/screens/merchant/merchant_stats_screen.dart';
import 'package:efuride_app/screens/merchant/merchant_bank_details_screen.dart';
import 'package:efuride_app/screens/merchant/merchant_store_profile_screen.dart';
import 'package:efuride_app/screens/merchant/merchant_settings_screen.dart';
import 'package:efuride_app/screens/merchant/merchant_promote_screen.dart';
import 'package:efuride_app/screens/shared/verify_screen.dart';

// ── Shared ──
import 'package:efuride_app/screens/shared/pending_approval_screen.dart';
import 'package:efuride_app/screens/shared/support_screen.dart';
import 'package:efuride_app/screens/shared/messages_screen.dart';
import 'package:efuride_app/screens/shared/rating_screen.dart';
import 'package:efuride_app/screens/shared/sos_screen.dart';
import 'package:efuride_app/screens/shared/sos_setup_screen.dart';
import 'package:efuride_app/screens/shared/promotions_screen.dart';
import 'package:efuride_app/screens/shared/notifications_screen.dart';
import 'package:efuride_app/screens/chat/trip_chat_screen.dart';
import 'package:efuride_app/screens/driver/live_photo_check_screen.dart';
import 'package:efuride_app/screens/shared/profile_photo_required_screen.dart';

// ── Wallet ──
import 'package:efuride_app/screens/wallet/wallet_screen.dart';

import 'firebase_options.dart';
import 'package:efuride_app/services/connection_service.dart';

// ════════════════════════════════════════════════════════════════
// GLOBAL KEYS
// ════════════════════════════════════════════════════════════════
final GlobalKey<ScaffoldMessengerState> globalMessengerKey =
    GlobalKey<ScaffoldMessengerState>();
final GlobalKey<NavigatorState> globalNavigatorKey =
    GlobalKey<NavigatorState>();

Timer? _ringGuardTimer;
const _tag = 'Main';

// ════════════════════════════════════════════════════════════════
// GLOBAL RING STATE
// ════════════════════════════════════════════════════════════════
final ValueNotifier<bool> globalRingShowing = ValueNotifier<bool>(false);

// ════════════════════════════════════════════════════════════════
// ROLE OBSERVER
// Tracks the current active role based on navigation, so we can
// filter notifications automatically without touching the shells.
// ════════════════════════════════════════════════════════════════
class RoleRouteObserver extends NavigatorObserver {
  static const _roleRoutes = {
    '/customer': 'customer',
    '/driver': 'driver',
    '/shopper': 'shopper',
    '/merchant': 'merchant',
  };

  void _sync(String? routeName) {
    if (routeName == null) return;
    final path = Uri.parse(routeName).path;
    final role = _roleRoutes[path];
    if (role == null) return;
    if (NotificationProvider.instance.currentRole == role) return;
    Log.i(_tag, 'Switching notification role → $role');
    NotificationProvider.instance.setRole(role);
    if (!kIsWeb) {
      RealtimeNotifications.instance.start(
        messengerKey: globalMessengerKey,
        role: role,
      );
    }
  }

  @override
  void didPush(Route route, Route? previousRoute) {
    super.didPush(route, previousRoute);
    _sync(route.settings.name);
  }

  @override
  void didPop(Route route, Route? previousRoute) {
    super.didPop(route, previousRoute);
    _sync(previousRoute?.settings.name);
  }

  @override
  void didReplace({Route? newRoute, Route? oldRoute}) {
    super.didReplace(newRoute: newRoute, oldRoute: oldRoute);
    _sync(newRoute?.settings.name);
  }

  @override
  void didRemove(Route route, Route? previousRoute) {
    super.didRemove(route, previousRoute);
    _sync(previousRoute?.settings.name);
  }
}

final RoleRouteObserver globalRoleObserver = RoleRouteObserver();

// ════════════════════════════════════════════════════════════════
// LANGUAGE
// ════════════════════════════════════════════════════════════════
final ValueNotifier<AppLang> appLanguageNotifier =
    ValueNotifier<AppLang>(AppLang.en);

const List<Locale> _supportedLocales = [
  Locale('en'),
  Locale('fr'),
  Locale('sw'),
  Locale('ny'),
  Locale('af'),
  Locale('ya'),
  Locale('ln'),
];

// ════════════════════════════════════════════════════════════════
// FCM BACKGROUND HANDLER
// ════════════════════════════════════════════════════════════════
@pragma('vm:entry-point')
Future<void> _firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  try {
    await Firebase.initializeApp(
      options: DefaultFirebaseOptions.currentPlatform,
    );
  } catch (e) {
    Log.e(_tag, 'bg Firebase init failed', e);
  }

  final type   = message.data['type']?.toString();
  final role   = message.data['role']?.toString() ?? 'customer';
  final title  = message.data['title']?.toString()
      ?? message.notification?.title
      ?? 'ko!ngo';
  final body   = message.data['body']?.toString()
      ?? message.notification?.body
      ?? '';
  final rideId = message.data['ride_id']?.toString() ?? '';

  await PushDiag.note('push arrived: type=$type role=$role');

  try {
    await RingService.instance.init();

    // High-priority role-specific ringing
    final isRideRing  = type == 'ride_request' && role == 'driver';
    final isOrderRing = (type == 'order_status' || type == 'order_new') &&
        role == 'merchant';
    final isTaskRing  = (type == 'task_assigned' || type == 'task_new') &&
        role == 'shopper';

    final orderId = message.data['order_id']?.toString() ?? '';
    if (isOrderRing && orderId.isNotEmpty) {
      // New store order: rings up to 3 minutes; tapping opens Orders.
      await RingService.instance.showBackgroundRingNotification(
        rideId: '',
        payload: 'order:$orderId',
        title: title,
        body: body,
        ringFor: const Duration(minutes: 3),
      );
    } else if (isTaskRing && orderId.isNotEmpty) {
      // A shopping task waiting: rings like a call; tapping opens Home.
      await RingService.instance.showBackgroundRingNotification(
        rideId: '',
        payload: 'shop:$orderId',
        title: title,
        body: body,
        ringFor: const Duration(minutes: 3),
      );
    } else if (isRideRing || isOrderRing || isTaskRing) {
      await RingService.instance.showBackgroundRingNotification(
        rideId: rideId,
        title: title,
        body: body,
      );
      // Driver ride request: also open the app over whatever is on screen
      // (works when "Display over other apps" is on for ko!ngo).
      await PushDiag.note('ring notification shown');
      if (isRideRing && rideId.isNotEmpty) {
        await RingLauncher.wakeApp(rideId);
        await PushDiag.note('asked Android to open the app');
      }
    } else if (type == 'chat_message') {
      await RingService.instance.showAlertNotification(
        title: title, body: body, payload: rideId, id: 7010,
      );
    } else {
      // ride accepted / nearby / arrived and anything else: loud short alert
      await RingService.instance.showAlertNotification(
        title: title, body: body, payload: rideId.isEmpty ? null : rideId,
      );
    }
  } catch (e, s) {
    Log.e(_tag, 'bg notify failed', e, s);
    await PushDiag.note('ERROR: $e');
  }
}

// ════════════════════════════════════════════════════════════════
// IN-APP FCM HANDLERS
// ════════════════════════════════════════════════════════════════
Future<void> _handleIncomingRidePush(String rideId) async {
  if (rideId.isEmpty) return;

  // Only drivers respond to ride rings
  if (NotificationProvider.instance.currentRole != 'driver') {
    Log.i(_tag, 'Ignoring ride ring — current role is not driver');
    return;
  }
  if (globalRingShowing.value) return;

  globalRingShowing.value = true;
  _ringGuardTimer?.cancel();
  _ringGuardTimer = Timer(const Duration(seconds: 90), () {
    globalRingShowing.value = false;
  });

  try {
    final ride = await Supabase.instance.client
        .from('rides')
        .select()
        .eq('id', rideId)
        .maybeSingle();

    if (ride == null || ride['status'] != 'pending') return;

    final ctx = globalNavigatorKey.currentContext;
    if (ctx == null) return;

    await Navigator.of(ctx).push(
      IncomingRideRingScreen.route(ride),
    );
  } catch (e, s) {
    Log.e(_tag, 'handleIncomingRidePush failed', e, s);
  } finally {
    globalRingShowing.value = false;
    _ringGuardTimer?.cancel();
    _ringGuardTimer = null;
  }
}

bool _roleReady = false;

void _onRingTapped() {
  final p = pendingRideFromNotification.value;
  if (p == null || p.isEmpty) return;
  unawaited(_openRing(p));
}

Future<void> _openRing(String payload) async {
  // On a cold start (phone was locked, app closed) wait until the app has
  // signed in and knows the role.
  for (var i = 0; i < 30; i++) {
    if (globalNavigatorKey.currentContext != null && _roleReady) break;
    await Future.delayed(const Duration(milliseconds: 500));
  }
  if (pendingRideFromNotification.value == payload) {
    pendingRideFromNotification.value = null;
  }
  if (!_roleReady) return; // not signed in

  if (payload.startsWith('order:')) {
    await RingService.instance.cancelRingNotification();
    if (NotificationProvider.instance.currentRole != 'merchant') return;
    // Let the start-up screen finish first, then open Orders.
    await Future.delayed(const Duration(milliseconds: 1200));
    globalNavigatorKey.currentState
        ?.pushNamedAndRemoveUntil('/merchant?tab=orders', (_) => false);
    return;
  }
  if (payload.startsWith('shop:')) {
    await RingService.instance.cancelRingNotification();
    if (NotificationProvider.instance.currentRole != 'shopper') return;
    await Future.delayed(const Duration(milliseconds: 1200));
    globalNavigatorKey.currentState
        ?.pushNamedAndRemoveUntil('/shopper', (_) => false);
    return;
  }
  await _handleIncomingRidePush(payload);
}

void _openChatForRide(String rideId) {
  if (rideId.isEmpty) return;
  globalNavigatorKey.currentState?.pushNamed(
    '/chat',
    arguments: {'chatId': rideId, 'rideId': rideId},
  );
}

// ════════════════════════════════════════════════════════════════
// AUTH-SCOPED SERVICES
// ════════════════════════════════════════════════════════════════
bool _servicesStarted = false;

Future<void> _startAuthScopedServices() async {
  if (_servicesStarted) return;
  _servicesStarted = true;

  try {
    RideWatchdogService.instance.start();
  } catch (e, s) {
    Log.e(_tag, 'watchdog start failed', e, s);
  }

  try {
    NotificationRouter.instance.init();
  } catch (e, s) {
    Log.e(_tag, 'NotificationRouter init failed', e, s);
  }

  final uid = Supabase.instance.client.auth.currentUser?.id;
  if (uid != null) {
    // Detect the user's role from profiles so we start with the right inbox.
    String initialRole = 'customer';
    try {
      final row = await Supabase.instance.client
          .from('profiles')
          .select('role')
          .eq('id', uid)
          .maybeSingle();
      final dbRole = (row?['role'] ?? '').toString().toLowerCase();
      if (dbRole == 'driver' ||
          dbRole == 'merchant' ||
          dbRole == 'shopper') {
        initialRole = dbRole;
      }
    } catch (e) {
      Log.w(_tag, 'role read failed: $e');
    }

    try {
      NotificationProvider.instance.setRole(initialRole);
    } catch (e, s) {
      Log.e(_tag, 'NotificationProvider setRole failed', e, s);
    }
    _roleReady = true;

    // Ask for notification + lock-screen ring permission (once).
    if (!kIsWeb) unawaited(RingService.instance.requestRingPermissions());

    if (!kIsWeb) {
      try {
        RealtimeNotifications.instance.start(
          messengerKey: globalMessengerKey,
          role: initialRole,
        );
      } catch (e, s) {
        Log.e(_tag, 'RealtimeNotifications start failed', e, s);
      }
    }
  }
}

void _stopAuthScopedServices() {
  if (!_servicesStarted) return;
  _servicesStarted = false;
  RideWatchdogService.instance.stop();
  NotificationProvider.instance.stop();
  if (!kIsWeb) {
    RealtimeNotifications.instance.stop();
  }
}

Future<void> _loadLanguageFromProfile() async {
  final userId = Supabase.instance.client.auth.currentUser?.id;
  if (userId == null) return;

  try {
    final row = await Supabase.instance.client
        .from('profiles')
        .select('language')
        .eq('id', userId)
        .maybeSingle();

    final code = row?['language']?.toString();
    if (code != null && code.isNotEmpty) {
      final next = AppLang.fromCode(code);
      appLanguageNotifier.value = next;
      NotificationProvider.instance.setLanguage(next);
    }
  } catch (e) {
    Log.w(_tag, 'language load failed: $e');
  }
}

// ════════════════════════════════════════════════════════════════
// MAIN
// ════════════════════════════════════════════════════════════════
Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Phones and tablets: portrait only, the app never turns sideways.
  // (Web and the Windows admin can still resize freely.)
  if (!kIsWeb) {
    await SystemChrome.setPreferredOrientations(
        [DeviceOrientation.portraitUp]);
  }
  await Readability.load(); // app text size (low-vision support)

  if (!kIsWeb) {
    try {
      await Firebase.initializeApp(
        options: DefaultFirebaseOptions.currentPlatform,
      );
      FirebaseMessaging.onBackgroundMessage(
          _firebaseMessagingBackgroundHandler);
    } catch (e, s) {
      Log.e(_tag, 'Firebase init failed (continuing)', e, s);
    }
  } else {
    Log.i(_tag, 'Web build — Firebase Messaging skipped');
  }

  await Supabase.initialize(
    url: AppConfig.supabaseUrl,
    publishableKey: AppConfig.supabaseAnonKey,
    authOptions: const FlutterAuthClientOptions(autoRefreshToken: true),
  );

  // Admin switches (maintenance, paused apps/services, support contacts).
  // Not awaited: the app must start even if this is slow.
  unawaited(AppControl.start());

  try {
    await RingService.instance.init();
  } catch (e, s) {
    Log.e(_tag, 'RingService init failed (continuing)', e, s);
  }

  // Tapping the ring — or the ring opening the app full-screen over the
  // lock screen — opens the request (driver) or the Orders tab (store).
  if (!kIsWeb) {
    pendingRideFromNotification.addListener(_onRingTapped);
    try {
      final launched = await RingService.instance.launchPayload();
      if (launched != null) pendingRideFromNotification.value = launched;
    } catch (e, s) {
      Log.e(_tag, 'ring launch check failed', e, s);
    }
    unawaited(RingLauncher.consumePending());
  }

  if (!kIsWeb) {
    NotificationService.instance
      ..onRideRequest = _handleIncomingRidePush
      ..onChatOpen = _openChatForRide;

    try {
      await NotificationService.instance.register();
    } catch (e, s) {
      Log.e(_tag, 'NotificationService.register failed', e, s);
    }

    try {
      final initial = await FirebaseMessaging.instance.getInitialMessage();
      if (initial != null) {
        final type   = initial.data['type']?.toString();
        final role   = initial.data['role']?.toString() ?? 'customer';
        final rideId = initial.data['ride_id']?.toString() ?? '';
        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (type == 'ride_request' &&
              role == 'driver' &&
              rideId.isNotEmpty) {
            _handleIncomingRidePush(rideId);
          } else if (type == 'chat_message' && rideId.isNotEmpty) {
            _openChatForRide(rideId);
          }
        });
      }
    } catch (e, s) {
      Log.e(_tag, 'getInitialMessage failed', e, s);
    }
  }

  Supabase.instance.client.auth.onAuthStateChange.listen((event) async {
    if (event.session != null) {
      await _startAuthScopedServices();
      await _loadLanguageFromProfile();
      if (!kIsWeb) {
        try {
          await NotificationService.instance.register();
        } catch (e, s) {
          Log.e(_tag, 're-register push failed', e, s);
        }
      }
    } else {
      if (!kIsWeb) {
        try {
          await NotificationService.instance.unregister();
        } catch (e, s) {
          Log.e(_tag, 'unregister failed', e, s);
        }
      }
      _stopAuthScopedServices();
      // Keep the language picked on this phone (or the phone's own
      // language) instead of jumping back to English on sign-out.
      appLanguageNotifier.value = AppLangStore.resolve(
          explicitChoice: await AppLangStore.loadUserChoice());
    }
  });

  if (Supabase.instance.client.auth.currentSession != null) {
    await _startAuthScopedServices();
    await _loadLanguageFromProfile();
  }

  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => AuthProvider()),
        ChangeNotifierProvider(create: (_) => RideProvider()),
        ChangeNotifierProvider(create: (_) => CartProvider()),
        // One shared instance (also used as NotificationProvider.instance),
        // so the Notifications screen can listen to it.
        ChangeNotifierProvider<NotificationProvider>.value(
            value: NotificationProvider.instance),
      ],
      child: const EFurideApp(),
    ),
  );
}

// ════════════════════════════════════════════════════════════════
// APP ROOT
// ════════════════════════════════════════════════════════════════
class EFurideApp extends StatefulWidget {
  const EFurideApp({super.key});

  @override
  State<EFurideApp> createState() => _EFurideAppState();
}

class _EFurideAppState extends State<EFurideApp>
    with WidgetsBindingObserver {
  AppLang _lang = appLanguageNotifier.value;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    appLanguageNotifier.addListener(_onLanguageChanged);
    GoogleMapsService.languageCode = _lang.code;
    _sessionCheck = Timer.periodic(
        const Duration(seconds: 60), (_) => _verifySession());
  }

  Timer? _sessionCheck;

  // An admin can sign a person out everywhere. The server then deletes the
  // session, so ask the server whether ours is still valid and, if it is
  // not, sign out on this phone too.
  Future<void> _verifySession() async {
    final auth = Supabase.instance.client.auth;
    if (auth.currentSession == null) return;
    DeviceGuard.instance.check(); // one phone per account (not customers)
    try {
      await auth.getUser();
    } on AuthException catch (e) {
      final code = (e.statusCode ?? '').toString();
      final msg = e.message.toLowerCase();
      final looksEnded = code == '401' || code == '403' ||
          msg.contains('session') || msg.contains('jwt') ||
          msg.contains('refresh token');
      if (!looksEnded) return; // offline or a temporary problem: stay in
      // The access pass may simply be out of date (the phone was asleep).
      // Get a new one first; only sign out if the server really ended it.
      try {
        await auth.refreshSession();
      } on AuthException catch (e2) {
        final m2 = e2.message.toLowerCase();
        final gone = m2.contains('refresh token') ||
            m2.contains('session_not_found') ||
            m2.contains('session not found') ||
            m2.contains('user_not_found') ||
            m2.contains('user not found');
        if (gone) {
          Log.w(_tag, 'session ended by the server, signing out');
          try {
            await auth.signOut(scope: SignOutScope.local);
          } catch (_) {}
        }
      } catch (_) {
        // no connection: keep the session
      }
    } catch (_) {
      // offline or a temporary problem: keep the session
    }
  }

  @override
  void dispose() {
    appLanguageNotifier.removeListener(_onLanguageChanged);
    WidgetsBinding.instance.removeObserver(this);
    _sessionCheck?.cancel();
    super.dispose();
  }

  void _onLanguageChanged() {
    final next = appLanguageNotifier.value;
    if (next == _lang) return;
    GoogleMapsService.languageCode = next.code;
    currentAppLang = next; // tr() reads this
    AppLangStore.saveUserChoice(next); // remembered on this phone
    if (!mounted) return;
    setState(() => _lang = next);
    // Screens written with tr('…') don't listen for language changes, so
    // they kept the old language until the user signed out and in again.
    // Rebuild every open screen now (their state is kept).
    WidgetsBinding.instance.addPostFrameCallback((_) {
      void rebuild(Element el) {
        el.markNeedsBuild();
        el.visitChildren(rebuild);
      }
      if (mounted) (context as Element).visitChildren(rebuild);
    });
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state != AppLifecycleState.resumed) return;
    // Back in the app: see straight away whether we're online.
    unawaited(ConnectionService.instance.check());
    final session = Supabase.instance.client.auth.currentSession;
    if (session != null) {
      unawaited(
        Supabase.instance.client.auth.refreshSession().then(
          (_) {},
          onError: (e) {
            Log.w(_tag, 'session refresh failed: $e');
            unawaited(_verifySession());
          },
        ),
      );
      unawaited(_verifySession());
    }
    if (!kIsWeb) {
      NotificationService.instance.register();
      unawaited(RingLauncher.consumePending());
    }
    NotificationProvider.instance.refresh();
  }

  @override
  Widget build(BuildContext context) {
    currentAppLang = _lang; // used by tr() for text written in screens
    return SProvider(
      lang: _lang,
      child: MaterialApp(
        title: tr('ko!ngo'),
        debugShowCheckedModeBanner: false,
        scaffoldMessengerKey: globalMessengerKey,
        navigatorKey: globalNavigatorKey,
        navigatorObservers: [globalRoleObserver], // <-- role detection
        themeMode: ThemeMode.light,
        theme: _buildTheme(),
        localizationsDelegates: const [
          GlobalMaterialLocalizations.delegate,
          GlobalWidgetsLocalizations.delegate,
          GlobalCupertinoLocalizations.delegate,
        ],
        supportedLocales: _supportedLocales,
        builder: (context, child) {
          ErrorWidget.builder = (FlutterErrorDetails details) {
            Log.e(_tag, 'widget error: ${details.exception}');
            final title   = S.of(context).t('error_title');
            final message = S.of(context).t('error_restart');
            return Container(
              color: const Color(0xFFFAF6EE),
              padding: const EdgeInsets.all(24),
              child: Center(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(Icons.sentiment_dissatisfied,
                        size: 48, color: Color(0xFF575047)),
                    const SizedBox(height: 16),
                    Text(title,
                        style: const TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          color: Color(0xFF1A1A1A),
                        )),
                    const SizedBox(height: 8),
                    Text(message,
                        style: const TextStyle(
                            fontSize: 14, color: Color(0xFF575047))),
                  ],
                ),
              ),
            );
          };
          // Phone text size × the app's own "Text size" choice.
          // "No internet. Reconnecting…" bar on every screen when offline.
          return Readability.apply(
              context, OfflineBanner(child: child ?? const SizedBox.shrink()));
        },
        initialRoute: '/splash',
        onGenerateRoute: _onGenerateRoute,
      ),
    );
  }

  ThemeData _buildTheme() {
    // Readability: Atkinson Hyperlegible everywhere, generous default
    // sizes and line height, and dark-enough secondary text (≥ 7:1).
    const ink = Color(0xFF1A1A1A);
    const muted = Color(0xFF575047);
    final base = ThemeData(
      useMaterial3: true,
      fontFamily: Readability.fontFamily,
      colorScheme: ColorScheme.fromSeed(
        seedColor: const Color(0xFFF2B705),
        brightness: Brightness.light,
      ).copyWith(onSurface: ink, onSurfaceVariant: muted),
    );
    final text = base.textTheme
        .copyWith(
          bodyLarge: base.textTheme.bodyLarge
              ?.copyWith(fontSize: 17, height: 1.45),
          bodyMedium: base.textTheme.bodyMedium
              ?.copyWith(fontSize: 16, height: 1.45),
          bodySmall: base.textTheme.bodySmall
              ?.copyWith(fontSize: 14, height: 1.4, color: muted),
          labelLarge: base.textTheme.labelLarge?.copyWith(fontSize: 16),
          labelMedium: base.textTheme.labelMedium?.copyWith(fontSize: 14),
          labelSmall: base.textTheme.labelSmall?.copyWith(fontSize: 13),
          titleMedium: base.textTheme.titleMedium?.copyWith(fontSize: 17),
          titleSmall: base.textTheme.titleSmall?.copyWith(fontSize: 15),
        )
        .apply(
          fontFamily: Readability.fontFamily,
          bodyColor: ink,
          displayColor: ink,
        );
    return base.copyWith(
      textTheme: text,
      primaryTextTheme: base.primaryTextTheme
          .apply(fontFamily: Readability.fontFamily),
      inputDecorationTheme: const InputDecorationTheme(
        hintStyle: TextStyle(fontSize: 16, color: muted),
        labelStyle: TextStyle(fontSize: 16, color: muted),
        helperStyle: TextStyle(fontSize: 14, color: muted),
        errorStyle: TextStyle(fontSize: 14, height: 1.3),
      ),
      snackBarTheme: const SnackBarThemeData(
        contentTextStyle: TextStyle(
            fontFamily: Readability.fontFamily, fontSize: 16, height: 1.35),
      ),
      tooltipTheme: const TooltipThemeData(
        textStyle: TextStyle(
            fontFamily: Readability.fontFamily,
            fontSize: 15,
            color: Colors.white),
      ),
      appBarTheme: const AppBarTheme(
        elevation: 0,
        centerTitle: true,
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          padding:
              const EdgeInsets.symmetric(vertical: 14, horizontal: 24),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
      ),
      progressIndicatorTheme: const ProgressIndicatorThemeData(
        color: Color(0xFFF2B705),
      ),
    );
  }
}

// ════════════════════════════════════════════════════════════════
// ROUTER
// ════════════════════════════════════════════════════════════════
Route<dynamic>? _onGenerateRoute(RouteSettings settings) {
  final uri  = Uri.parse(settings.name ?? '/');
  final args = settings.arguments;

  // ── Role shells ──
  switch (uri.path) {
    case '/customer':
      return _page(settings, buildCustomerShell(uri, args));
    case '/driver':
      return _page(settings, buildDriverShell(uri));
    case '/shopper':
      return _page(settings, buildShopperShell(uri));
    case '/merchant':
      return _page(settings, buildMerchantShell(uri));
  }

  // ── Auth ──
  switch (uri.path) {
    case '/':
    case '/splash':
      return _page(settings, const SplashScreen());
    case '/role_select':
      return _page(settings, const RoleSelectScreen());
    case '/auth':
      return _page(
        settings,
        AuthScreen(
          role: (args is Map ? args['role'] : 'customer')?.toString()
              ?? 'customer',
          mode: (args is Map ? args['mode'] : 'signin')?.toString()
              ?? 'signin',
        ),
      );
    case '/phone_otp':
      // Phone OTP is not wired to Supabase yet (the screen accepts any
      // code), so send people to the real email sign-in until it is.
      return _page(
        settings,
        AuthScreen(
          role: (args is Map ? args['role'] : 'customer')?.toString()
              ?? 'customer',
          mode: 'signin',
        ),
      );
  }

  // ── Customer ──
  switch (uri.path) {
    case '/customer_home':
      return _page(settings, const CustomerHomeScreen());

    case '/customer_search':
      return _page(
        settings,
        SelectDestinationScreen(
          initialServiceMode:
              (args is Map ? args['service'] : 'Ride')?.toString() ?? 'Ride',
          pickupLatLng: (args is Map && args['pickup'] != null)
              ? args['pickup'] as LatLng
              : const LatLng(-4.2634, 15.2429),
        ),
      );

    case '/customer_food':
      return _page(settings, const CustomerFoodScreen());

    case '/customer_restaurant':
      return _page(
        settings,
        CustomerRestaurantMenuScreen(
          restaurantId:
              (args is Map ? args['id'] : '')?.toString() ?? '',
          restaurantName:
              (args is Map ? args['name'] : '')?.toString() ?? '',
          restaurantAddress:
              (args is Map ? args['address'] : '')?.toString() ?? '',
        ),
      );

    case '/customer_grocery':
      return _page(settings, const CustomerGroceryScreen());

    case '/hiring':
      return _page(
        settings,
        HiringHubScreen(
          initialTab: (args is Map ? args['tab'] : 'find')?.toString() ?? 'find',
        ),
      );

    case '/customer_pharmacy':
      return _page(settings, const CustomerPharmacyScreen());

    case '/customer_category':
      return _page(
        settings,
        CustomerCategoryScreen(
          category: (args is Map ? args['category'] : 'other')?.toString() ?? 'other',
          title: (args is Map ? args['title'] : '')?.toString() ?? '',
        ),
      );

    case '/customer_store':
      return _page(
        settings,
        CustomerStoreMenuScreen(
          storeId:
              (args is Map ? args['id'] : '')?.toString() ?? '',
          storeName:
              (args is Map ? args['name'] : '')?.toString() ?? '',
          storeAddress:
              (args is Map ? args['address'] : '')?.toString() ?? '',
          serviceType:
              (args is Map ? args['service_type'] : 'Grocery')?.toString()
                  ?? 'Grocery',
        ),
      );

    case '/customer_cart':
      return _page(settings, const CustomerCartScreen());

    case '/customer_wallet':
    case '/wallet':
      return _page(settings, const WalletScreen());

    case '/customer_account':
      return _page(settings, const CustomerAccountScreen());
    case '/customer_settings':
      return _page(settings, const CustomerSettingsScreen());
    case '/customer_privacy':
      return _page(settings, const CustomerPrivacyScreen());
    case '/customer_profile':
      return _page(settings, const CustomerProfileScreen());

    case '/favorites':
      return _page(settings, const FavoritePlacesScreen());
    case '/schedule':
    case '/scheduled_rides':
      return _page(settings, const ScheduledRidesScreen());
    case '/loyalty':
      return _page(settings, const LoyaltyScreen());
    case '/referral':
      return _page(settings, const ReferralScreen());
    case '/ride_history':
      return _page(settings, const RideHistoryScreen());
    case '/corporate':
      return _page(settings, const CorporateScreen());
    case '/analytics':
      return _page(settings, const AnalyticsScreen());

    case '/booking_summary':
      return _page(
        settings,
        BookingSummaryScreen(
          vehicle:
              (args is Map ? args['vehicle'] : 'Economy')?.toString()
                  ?? 'Economy',
          pickup:  (args is Map ? args['pickup']  : '')?.toString() ?? '',
          dropoff: (args is Map ? args['dropoff'] : '')?.toString() ?? '',
          fare: ((args is Map ? args['fare'] : 0) as num?)?.toDouble() ?? 0,
          distance: ((args is Map ? args['distance'] : 0) as num?)
                  ?.toDouble() ?? 0,
          etaMinutes: args is Map ? args['eta'] as int? : null,
          pickupLatLng: (args is Map && args['pickupLatLng'] != null)
              ? args['pickupLatLng'] as LatLng
              : const LatLng(-4.2634, 15.2429),
          dropoffLatLng: (args is Map && args['dropoffLatLng'] != null)
              ? args['dropoffLatLng'] as LatLng
              : const LatLng(-4.2634, 15.2429),
          serviceType:
              (args is Map ? args['serviceType'] : 'Ride')?.toString()
                  ?? 'Ride',
        ),
      );

    case '/order_tracking':
      return _page(
        settings,
        OrderTrackingScreen(
          orderId:
              (args is Map ? args['order_id'] : '')?.toString() ?? '',
          serviceType:
              (args is Map ? args['service_type'] : 'Food')?.toString()
                  ?? 'Food',
          storeName:
              (args is Map ? args['store_name'] : '')?.toString() ?? '',
          storeAddress:
              (args is Map ? args['store_address'] : '')?.toString() ?? '',
          dropoffAddress:
              (args is Map ? args['dropoff'] : '')?.toString() ?? '',
          total: ((args is Map ? args['total'] : 0) as num?)?.toDouble()
              ?? 0,
        ),
      );

    case '/substitution':
      return _page(
        settings,
        SubstitutionApprovalScreen(
          substitutionId:
              (args is Map ? args['substitution_id'] : null)?.toString(),
          orderId:
              (args is Map ? args['order_id'] : '')?.toString() ?? '',
          originalItem:
              (args is Map ? args['original'] : '')?.toString() ?? '',
          originalQty: (args is Map ? args['qty'] : '')?.toString() ?? '',
          originalPrice:
              ((args is Map ? args['original_price'] : 0) as num?)
                      ?.toDouble() ?? 0,
          proposedItem:
              (args is Map ? args['proposed'] : '')?.toString() ?? '',
          proposedPrice:
              ((args is Map ? args['proposed_price'] : 0) as num?)
                      ?.toDouble() ?? 0,
          shopperName:
              (args is Map ? args['shopper_name'] : '')?.toString() ?? '',
        ),
      );

    case '/trip_complete':
      return _page(
        settings,
        TripCompleteScreen(
          finalFare:
              ((args is Map ? args['fare'] : 0) as num?)?.toDouble() ?? 0,
          tripDistance:
              (args is Map ? args['distance'] : '')?.toString() ?? '',
          rideId: (args is Map ? args['rideId'] : null)?.toString(),
          driverId: (args is Map ? args['driverId'] : null)?.toString(),
          driverName:
              (args is Map ? args['driverName'] : null)?.toString(),
        ),
      );
  }

  // ── Driver ──
  switch (uri.path) {
    case '/driver_home':
      return _page(settings, const DriverHomeScreen());
    case '/driver_onboarding':
      return _page(settings, const DriverOnboardingScreen());
    case '/driver_bank':
      return _page(settings, const DriverBankDetailsScreen());
    case '/driver_photo_check':
      return _page(settings, const LivePhotoCheckScreen());
    case '/driver_documents':
      return _page(settings, const DriverDocumentUploadScreen());
    case '/driver_profile':
      return _page(settings, const DriverProfileScreen());
    case '/driver_earnings':
      return _page(settings, const DriverEarningsScreen());
    case '/driver_settings':
      return _page(settings, const DriverSettingsScreen());
    case '/driver_training':
      return _page(settings, const DriverTrainingScreen());
    case '/vehicles':
      return _page(settings, const VehicleManagementScreen());
    case '/pending_approval':
      return _page(settings, const PendingApprovalScreen());

    case '/driver_active_trip':
      final rideId =
          (args is Map ? args['rideId'] : '')?.toString() ?? '';
      if (rideId.isEmpty) {
        return _page(settings, const DriverHomeScreen());
      }
      return _page(
        settings,
        ActiveTripExecutionView(
          rideId: rideId,
          serviceType:
              (args is Map ? args['serviceType'] : 'Ride')?.toString()
                  ?? 'Ride',
          pickupOtp: (args is Map ? args['pickupOtp'] : null)?.toString(),
        ),
      );

    case '/trip_ended':
      return _page(
        settings,
        TripEndedScreen(
          finalFare:
              ((args is Map ? args['fare'] : 0) as num?)?.toDouble() ?? 0,
          tripDistance:
              (args is Map ? args['distance'] : '')?.toString() ?? '',
          rideId: (args is Map ? args['rideId'] : null)?.toString(),
          customerId: (args is Map ? args['customerId'] : null)?.toString(),
          customerName:
              (args is Map ? args['customerName'] : null)?.toString(),
        ),
      );
  }

  // ── Shopper ──
  switch (uri.path) {
    case '/shopper_home':
      return _page(settings, const ShopperHomeScreen());
    case '/shopper_tasks':
      return _page(settings, const ShopperTasksScreen());
    case '/shopper_task':
      return _page(
        settings,
        ShopperTaskDetailScreen(
          taskId: (args is Map ? args['task_id'] : '')?.toString() ?? '',
          orderId: (args is Map ? args['order_id'] : '')?.toString() ?? '',
          storeName:
              (args is Map ? args['store_name'] : '')?.toString() ?? '',
        ),
      );
    case '/shopper_pay':
      return _page(settings, const ShopperPayScreen());
    case '/shopper_settings':
      return _page(settings, const ShopperSettingsScreen());
  }

  // ── Merchant ──
  switch (uri.path) {
    case '/merchant_home':
      return _page(settings, const MerchantHomeScreen());
    case '/merchant_orders':
      return _page(settings, const MerchantOrdersScreen());
    case '/merchant_menu':
      return _page(settings, const MerchantMenuEditorScreen());
    case '/merchant_payouts':
      return _page(settings, const MerchantPayoutsScreen());
    case '/merchant_stats':
      return _page(settings, const MerchantStatsScreen());
    case '/merchant_bank':
      return _page(settings, const MerchantBankDetailsScreen());
    case '/merchant_profile':
      return _page(
          settings,
          MerchantStoreProfileScreen(
              newShop: args is Map && args['new'] == true));
    case '/merchant_settings':
      return _page(settings, const MerchantSettingsScreen());
    case '/merchant_promote':
      return _page(settings, const MerchantPromoteScreen());
  }

  // ── Shared ──
  switch (uri.path) {
    case '/verify':
      return _page(settings, const VerifyScreen());
    case '/messages':
      return _page(settings, const MessagesScreen());
    case '/support':
      return _page(settings, const SupportScreen());
    case '/notifications':
      return _page(settings, const NotificationsScreen());
    case '/promotions':
      return _page(settings, const PromotionsScreen());

    case '/rating':
      return _page(
        settings,
        RatingScreen(
          rideId: (args is Map ? args['rideId'] : null)?.toString(),
          rateeId: (args is Map ? args['rateeId'] : null)?.toString(),
          rateeName: (args is Map ? args['rateeName'] : null)?.toString(),
          rateeAvatarUrl:
              (args is Map ? args['rateeAvatar'] : null)?.toString(),
          raterRole: (args is Map ? args['raterRole'] : null)?.toString(),
        ),
      );

    case '/sos':
      return _page(
        settings,
        SOSScreen(
          role: (args is Map ? args['role'] : 'customer')?.toString()
              ?? 'customer',
          rideId: (args is Map ? args['rideId'] : null)?.toString(),
        ),
      );
    case '/sos_setup':
      return _page(settings, const SOSSetupScreen());

    case '/chat':
      final chatId =
          (args is Map ? args['chatId'] : null)?.toString() ??
          (args is Map ? args['rideId'] : null)?.toString() ??
          '';
      if (chatId.isEmpty) {
        return _page(
          settings,
          Scaffold(
            appBar: AppBar(title: Text(tr('Chat'))),
            body: Center(
              child: Padding(
                padding: EdgeInsets.all(24),
                child: Text(tr('No active conversation.'),
                    textAlign: TextAlign.center),
              ),
            ),
          ),
        );
      }
      return _page(
        settings,
        ChatScreen(rideId: chatId),
      );
  }

  // ── Fallback 404 ──
  Log.w(_tag, 'No route for: ${uri.path}');
  return _page(
    settings,
    Scaffold(
      backgroundColor: const Color(0xFFFAF6EE),
      body: SafeArea(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(32),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(Icons.error_outline,
                    size: 64, color: Color(0xFF575047)),
                const SizedBox(height: 20),
                Text(tr('Page not found'),
                    style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w900,
                        color: Color(0xFF1A1A1A))),
                const SizedBox(height: 8),
                Text(uri.path,
                    style: const TextStyle(
                        fontSize: 13.5, color: Color(0xFF575047)),
                    textAlign: TextAlign.center),
                const SizedBox(height: 24),
                ElevatedButton(
                  onPressed: () {
                    final ctx = globalNavigatorKey.currentContext;
                    if (ctx == null) return;
                    Navigator.pushNamedAndRemoveUntil(
                      ctx,
                      '/role_select',
                      (r) => false,
                    );
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFFF2B705),
                    foregroundColor: const Color(0xFF0B1220),
                    minimumSize: const Size(180, 48),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12)),
                  ),
                  child: Text(tr('Back to start')),
                ),
              ],
            ),
          ),
        ),
      ),
    ),
  );
}

/// Screens that belong to one role. Opening them checks the signed-in
/// account's real role (see RoleGate) — the door picked on the start
/// screen, a typed web URL or the back button can't open the wrong app.
/// Onboarding, documents and approval screens are left open so drivers
/// awaiting approval can still complete them.
const Map<String, String> _gatedRoutes = {
  '/customer': 'customer',
  '/customer_home': 'customer',
  '/driver': 'driver',
  '/driver_home': 'driver',
  '/driver_active_trip': 'driver',
  '/driver_earnings': 'driver',
  '/trip_ended': 'driver',
  '/shopper': 'shopper',
  '/shopper_home': 'shopper',
  '/shopper_tasks': 'shopper',
  '/shopper_task': 'shopper',
  '/shopper_pay': 'shopper',
  '/shopper_settings': 'shopper',
  '/merchant': 'merchant',
  '/merchant_home': 'merchant',
  '/merchant_orders': 'merchant',
  '/merchant_menu': 'merchant',
  '/merchant_payouts': 'merchant',
  '/merchant_stats': 'merchant',
  '/merchant_profile': 'merchant',
  '/merchant_settings': 'merchant',
  '/merchant_promote': 'merchant',
  '/merchant_bank': 'merchant',
};

Route<dynamic> _page(RouteSettings settings, Widget child) {
  final path = Uri.parse(settings.name ?? '/').path;
  final gateRole = _gatedRoutes[path];
  return MaterialPageRoute(
    settings: settings,
    builder: (_) =>
        gateRole == null ? child : RoleGate(role: gateRole, child: child),
  );
}
