﻿// lib/screens/customer/customer_home_screen.dart
//
// ko!ngo — Customer Home
//
// i18n-clean, currency-clean, uses AuthProvider for identity.
// Realtime ride listener, live driver tracking, radar dialog,
// pickup confirmation, OTP display, cancel flow.

import 'dart:async';
import 'dart:math' as math;
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:efuride_app/services/ring_service.dart';
import 'package:efuride_app/models/partner.dart';
import 'package:efuride_app/utils/search_match.dart';
import 'package:efuride_app/widgets/verified_badge.dart';
import 'package:efuride_app/widgets/voice_mic_button.dart';
import 'package:flutter/services.dart';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:latlong2/latlong.dart' hide LatLng;
import 'package:google_maps_flutter/google_maps_flutter.dart' as gmaps;
import 'package:geolocator/geolocator.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:intl/intl.dart' show DateFormat;
import 'package:efuride_app/widgets/kongo_brand.dart';
import 'package:efuride_app/widgets/picture_tile.dart';
import 'package:efuride_app/screens/customer/hiring_hub_screen.dart';
import 'package:share_plus/share_plus.dart';
import 'package:provider/provider.dart';

import 'package:efuride_app/services/pricing_service.dart';
import 'package:efuride_app/config/app_images.dart';
import 'package:efuride_app/config/country_config.dart';
import 'package:efuride_app/config/efuride_palette.dart';
import 'package:efuride_app/l10n/app_strings.dart';
import 'package:efuride_app/widgets/app_image.dart';
import 'package:efuride_app/widgets/debouncer.dart';
import 'package:efuride_app/utils/app_error.dart';
import 'package:efuride_app/utils/error_ui.dart';
import 'package:efuride_app/services/google_maps_service.dart';
import 'package:efuride_app/services/app_control.dart';
import 'package:efuride_app/screens/customer/select_destination_screen.dart';
import 'package:efuride_app/screens/customer/booking_summary_screen.dart';
import 'package:efuride_app/screens/customer/customer_account_screen.dart';
import 'package:efuride_app/screens/shared/notifications_screen.dart';
import 'package:efuride_app/screens/shared/profile_photo_required_screen.dart';
import 'package:efuride_app/services/ride_watchdog_service.dart';
import 'package:efuride_app/services/notification_service.dart';
import 'package:efuride_app/services/trip_share_service.dart';
import 'package:efuride_app/services/favorite_places_service.dart';
import 'package:efuride_app/providers/auth_provider.dart';
import 'package:efuride_app/models/order.dart';
import 'package:efuride_app/services/order_service.dart';
import 'package:efuride_app/services/call_service.dart';
import 'package:efuride_app/screens/shared/in_app_call_screen.dart';
import 'package:efuride_app/screens/shared/messages_screen.dart';
import 'package:efuride_app/widgets/k_icon.dart';

typedef LatLng = gmaps.LatLng;

class _LocalColors {
  static const meBlue = Color(0xFF1A73E8);
  static const success = Color(0xFF2E7D4F);

  static const svcRide = Color(0xFFF2B705);
  static const svcFood = Color(0xFFE88A1A);
  static const svcGrocery = Color(0xFF7B5BD6);
  static const svcPharmacy = Color(0xFFE53935);
  static const svcParcel = Color(0xFF1565C0);
}

bool _vehicleServesMode(Map<String, dynamic> v, String mode) {
  final target = mode.trim().toLowerCase();
  final raw = v['service_types'];
  if (raw is List && raw.isNotEmpty) {
    return raw.map((e) => e.toString().trim().toLowerCase()).contains(target);
  }
  final single =
      (v['service_type'] ?? 'Ride').toString().trim().toLowerCase();
  return single == target;
}

class CustomerHomeScreen extends StatefulWidget {
  const CustomerHomeScreen({super.key});

  @override
  State<CustomerHomeScreen> createState() => _CustomerHomeScreenState();
}

class _CustomerHomeScreenState extends State<CustomerHomeScreen>
    with WidgetsBindingObserver {
  gmaps.GoogleMapController? _mapController;
  final DraggableScrollableController _sheetController =
      DraggableScrollableController();

  String serviceMode = 'Ride';
  List<Map<String, dynamic>> _allVehicles = [];
  String selectedVehicleName = '';

  LatLng? customerLocation;
  LatLng? dropoffLatLng;
  LatLng? activeDriverLocation;

  List<Map<String, dynamic>> _nearbyDrivers = [];
  RealtimeChannel? _nearbyDriversChannel;
  Timer? _nearbyDriversTimer;
  Timer? _etaRefreshTimer;
  Timer? _tripStatusPoll;
  Map<String, dynamic>? _acceptedDriverDetails;

  List<LatLng> routePoints = [];
  double estimatedDistanceKm = 0.0;
  double estimatedFare = 0.0;
  double _currentBid = 0.0;
  int? _driverEtaMinutes;
  double? _driverDistanceToPickupKm;
  double _driverHeading = 0.0;

  final Map<String, double> _driverHeadings = {};
  final Map<String, LatLng> _lastDriverPos = {};

  String _pickupAddress = '';
  String _pickupSuburb = '';
  String _dropoffAddress = '';

  RealtimeChannel? _rideStatusChannel;
  RealtimeChannel? _driverLocationChannel;
  String? activeRideId;
  String? _currentRideStatus;
  bool isSearchingRide = false;
  bool _isTripActive = false;
  bool _isTrackingDriver = false;
  bool _hasAcceptedModalShown = false;
  bool _hasNotifiedPickupArrival = false;
  bool _hasNotifiedNearby = false;
  bool _hasNotifiedDestinationArrival = false;

  BuildContext? _radarDialogContext;
  BuildContext? _counterDialogContext;
  String? _counterShownKey;
  String? _lastRowStatus;
  Timer? _scheduledDispatchTimer;
  bool _scheduleNextBooking = false;
  Timer? _etaCountdownTimer;
  int _etaCountdownSeconds = 180;
  String? _pickupOtp;
  bool _otpVerified = false;
  bool _photoGateChecked = false;
  bool _isRefreshingLocation = false;

  List<Map<String, dynamic>> _recentDestinations = [];

  // Home screen extras (layout C): saved places, live shop orders, an offer.
  List<Map<String, dynamic>> _favorites = [];
  List<Order> _activeOrders = [];
  final Map<String, String> _storeNames = {};
  Map<String, dynamic>? _promo;
  int _unreadCount = 0;
  RealtimeChannel? _messagesChannel;
  final Set<String> _notifiedEvents = {};

  double _adminBaseFare = 25.0;
  double _adminPerKmRate = 12.0;
  double _adminMinFare = 25.0;
  double _adminSurge = 1.0;

  gmaps.BitmapDescriptor? _meDotIcon;
  gmaps.BitmapDescriptor? _carIcon;
  bool _pendingCenterOnCustomer = false;
  LatLng? _lastCenteredOn;

  // Real-time location tracking variables
  StreamSubscription<Position>? _positionStreamSubscription;
  DateTime _lastDbUpdate = DateTime.now();

  static const double _collapsedSheetFraction = 0.60;

  // Trip mode only while a real trip exists. (The old status checks could
  // stay true after a cancel and leave the home stuck in trip mode.)
  bool get _isMapLocked =>
      _isTripActive || isSearchingRide || activeRideId != null;

  // ════════════════════════════════════════════════════════════
  // LIFECYCLE
  // ════════════════════════════════════════════════════════════
  @override
  void initState() {
    super.initState();
    PricingService.changes.addListener(_onPricesChanged);
    WidgetsBinding.instance.addObserver(this);
    _loadMeDotIcon();
    _loadCarIcon();
    _loadVehicleTypes();
    _loadPricingSettings();
    _initCustomerLocation();
    _startLocationUpdates();
    _subscribeToNearbyDrivers();
    _loadRecentDestinations();
    _loadHomeExtras();
    _restoreActiveRideState();
    _loadUnreadCount();
    _subscribeToMessages();
    _nearbyDriversTimer = Timer.periodic(
      const Duration(seconds: 5),
      (_) => _fetchNearbyDrivers(),
    );
    // Safety net: if a live update is missed, a cancelled trip still
    // disappears within 10 seconds.
    _tripStatusPoll = Timer.periodic(
      const Duration(seconds: 10),
      (_) => _checkTripStillActive(),
    );
    _dispatchDueScheduled();
    _scheduledDispatchTimer = Timer.periodic(
      const Duration(seconds: 60),
      (_) => _dispatchDueScheduled(),
    );
    _checkProfilePhotoGate();
  }

  void _onPricesChanged() {
    if (mounted) _loadPricingSettings();
  }

  @override
  void dispose() {
    _marketDebounce?.cancel();
    _marketSearchCtl.dispose();
    PricingService.changes.removeListener(_onPricesChanged);
    CallService.instance.detach();
    WidgetsBinding.instance.removeObserver(this);
    _positionStreamSubscription?.cancel(); // Cancel real-time location stream
    _rideStatusChannel?.unsubscribe();
    _driverLocationChannel?.unsubscribe();
    _nearbyDriversChannel?.unsubscribe();
    _messagesChannel?.unsubscribe();
    _nearbyDriversTimer?.cancel();
    _tripStatusPoll?.cancel();
    _scheduledDispatchTimer?.cancel();
    _etaRefreshTimer?.cancel();
    _etaCountdownTimer?.cancel();
    _sheetController.dispose();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state != AppLifecycleState.resumed) return;
    if (customerLocation != null) {
      _fetchNearbyDrivers();
      _centerMapOnCustomer();
    }
    if (activeRideId != null) {
      _refetchPickupOtp(activeRideId!);
    } else {
      _restoreActiveRideState();
    }
    _loadUnreadCount();
    _loadPricingSettings();
    _loadHomeExtras();
    context.read<AuthProvider>().refresh();
  }

  // ════════════════════════════════════════════════════════════
  // MAP ICON BUILDERS
  // ════════════════════════════════════════════════════════════
  Future<void> _loadMeDotIcon() async {
    try {
      if (kIsWeb) {
        _meDotIcon = await gmaps.BitmapDescriptor.asset(
          const ImageConfiguration(size: Size(28, 28)),
          AppImages.mapPinUser,
        );
        if (mounted) setState(() {});
        return;
      }
      _meDotIcon = await _buildCircleMarker(
        size: 20,
        fillColor: _LocalColors.meBlue,
        borderColor: Colors.white,
        borderWidth: 3,
      );
      if (mounted) setState(() {});
    } catch (e) {
      debugPrint('me dot icon build failed: $e');
    }
  }

  Future<void> _loadCarIcon() async {
    try {
      if (kIsWeb) {
        _carIcon = await gmaps.BitmapDescriptor.asset(
          const ImageConfiguration(size: Size(32, 32)),
          AppImages.driverCar,
        );
      } else {
        _carIcon = await _buildVehicleMarker(
          size: 36,
          assetPath: AppImages.driverCar,
        );
      }
      if (mounted) setState(() {});
    } catch (e) {
      debugPrint('car icon load failed, using fallback: $e');
      _carIcon = null;
    }
  }

  Future<gmaps.BitmapDescriptor> _buildCircleMarker({
    required double size,
    required Color fillColor,
    required Color borderColor,
    required double borderWidth,
  }) async {
    final recorder = ui.PictureRecorder();
    final canvas = Canvas(recorder);
    final center = Offset(size / 2, size / 2);

    canvas.drawCircle(
      center.translate(0, 1),
      (size / 2) - 1,
      Paint()
        ..color = Colors.black.withValues(alpha: 0.18)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 2),
    );
    canvas.drawCircle(center, size / 2, Paint()..color = borderColor);
    final innerR = (size - borderWidth * 2) / 2;
    canvas.drawCircle(center, innerR, Paint()..color = fillColor);

    final picture = recorder.endRecording();
    final image = await picture.toImage(size.toInt(), size.toInt());
    final bytes = await image.toByteData(format: ui.ImageByteFormat.png);
    return gmaps.BitmapDescriptor.fromBytes(bytes!.buffer.asUint8List());
  }

  Future<gmaps.BitmapDescriptor> _buildVehicleMarker({
    required double size,
    required String assetPath,
  }) async {
    final recorder = ui.PictureRecorder();
    final canvas = Canvas(recorder);
    final center = Offset(size / 2, size / 2);
    final radius = size / 2;

    canvas.drawCircle(
      center.translate(0, 1.5),
      radius - 1,
      Paint()
        ..color = Colors.black.withValues(alpha: 0.22)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 3),
    );
    canvas.drawCircle(center, radius, Paint()..color = Colors.white);
    canvas.drawCircle(
      center,
      radius - 2.5,
      Paint()..color = const Color(0xFFF1F3F4),
    );

    try {
      final data = await rootBundle.load(assetPath);
      final codec = await ui.instantiateImageCodec(data.buffer.asUint8List());
      final frame = await codec.getNextFrame();
      final img = frame.image;

      final innerSize = size * 0.62;
      final dst = Rect.fromCenter(
        center: center,
        width: innerSize,
        height: innerSize,
      );
      final src = Rect.fromLTWH(
        0,
        0,
        img.width.toDouble(),
        img.height.toDouble(),
      );
      canvas.drawImageRect(img, src, dst, Paint());
    } catch (_) {
      canvas.drawCircle(
        center,
        radius * 0.5,
        Paint()..color = _LocalColors.success,
      );
    }

    final picture = recorder.endRecording();
    final out = await picture.toImage(size.toInt(), size.toInt());
    final bytes = await out.toByteData(format: ui.ImageByteFormat.png);
    return gmaps.BitmapDescriptor.fromBytes(bytes!.buffer.asUint8List());
  }

  // ════════════════════════════════════════════════════════════
  // MAP HELPERS
  // ════════════════════════════════════════════════════════════
  void _centerMapOnCustomer({double zoom = 16.0}) {
    if (customerLocation == null) return;
    _animateTo(customerLocation!, zoom);
  }

  void _animateTo(LatLng point, double zoom) {
    final ctrl = _mapController;
    if (ctrl == null) return;
    final last = _lastCenteredOn;
    if (last != null) {
      final dLat = (last.latitude - point.latitude).abs();
      final dLng = (last.longitude - point.longitude).abs();
      if (dLat < 0.00005 && dLng < 0.00005) return;
    }
    ctrl.animateCamera(
      gmaps.CameraUpdate.newLatLngZoom(
        gmaps.LatLng(point.latitude, point.longitude),
        zoom,
      ),
    );
    _lastCenteredOn = point;
  }

  void _deferredCenterOnCustomer({double zoom = 16.0}) {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      _centerMapOnCustomer(zoom: zoom);
    });
  }

  void _expandSheet({double size = 0.88}) {
    if (!_sheetController.isAttached) return;
    _sheetController.animateTo(size,
        duration: const Duration(milliseconds: 320),
        curve: Curves.easeOutCubic);
  }

  void _collapseSheet({double size = _collapsedSheetFraction}) {
    if (!_sheetController.isAttached) return;
    _sheetController.animateTo(size,
        duration: const Duration(milliseconds: 260),
        curve: Curves.easeOutCubic);
  }

  void _refitCameraSoon() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) _fitCameraToRoute();
    });
  }

  void _fitCameraToRoute() {
    if (!mounted) return;
    final points = <LatLng>[];
    if (routePoints.isNotEmpty) points.addAll(routePoints);
    if (activeDriverLocation != null) points.add(activeDriverLocation!);
    if (customerLocation != null) points.add(customerLocation!);
    if (dropoffLatLng != null && _currentRideStatus == 'in_progress') {
      points.add(dropoffLatLng!);
    }
    if (points.length < 2) return;

    _lastCenteredOn = null;
    try {
      double minLat = points.first.latitude, maxLat = points.first.latitude;
      double minLng = points.first.longitude, maxLng = points.first.longitude;
      for (final p in points) {
        if (p.latitude < minLat) minLat = p.latitude;
        if (p.latitude > maxLat) maxLat = p.latitude;
        if (p.longitude < minLng) minLng = p.longitude;
        if (p.longitude > maxLng) maxLng = p.longitude;
      }
      final bounds = gmaps.LatLngBounds(
        southwest: gmaps.LatLng(minLat, minLng),
        northeast: gmaps.LatLng(maxLat, maxLng),
      );
      _mapController?.animateCamera(
        gmaps.CameraUpdate.newLatLngBounds(bounds, 80),
      );
    } catch (_) {
      if (activeDriverLocation != null) {
        _animateTo(activeDriverLocation!, 15.0);
      }
    }
  }

  double _distanceInMeters(LatLng a, LatLng b) {
    const R = 6371000.0;
    final dLat = (b.latitude - a.latitude) * math.pi / 180;
    final dLng = (b.longitude - a.longitude) * math.pi / 180;
    final h = math.sin(dLat / 2) * math.sin(dLat / 2) +
        math.cos(a.latitude * math.pi / 180) *
            math.cos(b.latitude * math.pi / 180) *
            math.sin(dLng / 2) *
            math.sin(dLng / 2);
    return 2 * R * math.asin(math.sqrt(h));
  }

  String _formatDistance(double km) {
    if (km < 1) return '${(km * 1000).round()} m';
    return '${km.toStringAsFixed(1)} km';
  }

  // ════════════════════════════════════════════════════════════
  // PRICING
  // ════════════════════════════════════════════════════════════
  Future<void> _loadPricingSettings() async {
    // Prices for the user's country, in its own currency.
    try {
      final p = await PricingService.current();
      if (!mounted) return;
      setState(() {
        _adminBaseFare = p.baseFare;
        _adminPerKmRate = p.perKmRate;
        _adminMinFare = p.minimumFare;
        _adminSurge = p.surge;
      });
      _recomputeFare();
    } catch (e) {
      debugPrint('loadPricingSettings failed (using defaults): $e');
    }
  }

  // ════════════════════════════════════════════════════════════
  // REFRESH LOCATION
  // ════════════════════════════════════════════════════════════
  Future<void> _refreshLocation() async {
    if (_isRefreshingLocation) return;
    final t = S.of(context);
    if (_isMapLocked) {
      ErrorUI.showSnack(
        context,
        AppError(
          title: t.t('location_locked'),
          message: t.t('location_locked_hint'),
          icon: Icons.lock_outline,
        ),
      );
      return;
    }
    setState(() => _isRefreshingLocation = true);
    try {
      final serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!serviceEnabled) throw Exception('Location services are off');
      LocationPermission permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
      }
      if (permission == LocationPermission.denied ||
          permission == LocationPermission.deniedForever) {
        throw Exception('Location permission denied');
      }
      final position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.best,
        timeLimit: const Duration(seconds: 15),
      );
      if (!mounted) return;
      final newLoc = LatLng(position.latitude, position.longitude);
      setState(() {
        customerLocation = newLoc;
        _pendingCenterOnCustomer = true;
      });
      _animateTo(newLoc, 16.0);
      await _fetchReverseGeocodeAddress(newLoc.latitude, newLoc.longitude);
      final userId = Supabase.instance.client.auth.currentUser?.id;
      if (userId != null) {
        try {
          await Supabase.instance.client.from('profiles').update({
            'lat': newLoc.latitude,
            'lng': newLoc.longitude,
          }).eq('id', userId);
        } catch (_) {}
      }
      if (!mounted) return;
      ErrorUI.showSnack(
        context,
        AppError(
          title: t.t('location_updated'),
          message: t.t('location_updated_hint'),
          icon: Icons.check_circle_outline,
        ),
      );
    } catch (e) {
      if (!mounted) return;
      final t2 = S.of(context);
      ErrorUI.showSnack(
        context,
        AppError(
          title: t2.t('location_error'),
          message: t2.t('location_error_hint'),
          icon: Icons.location_off_outlined,
          actionLabel: t2.t('retry'),
          onRetry: _refreshLocation,
        ),
      );
    } finally {
      if (mounted) setState(() => _isRefreshingLocation = false);
    }
  }

  // ════════════════════════════════════════════════════════════
  // UNREAD COUNT + MESSAGES
  // ════════════════════════════════════════════════════════════
  Future<void> _loadUnreadCount() async {
    final userId = Supabase.instance.client.auth.currentUser?.id;
    if (userId == null) return;
    try {
      final res = await Supabase.instance.client
          .from('notifications')
          .select('id')
          .eq('user_id', userId)
          .eq('read', false);
      if (!mounted) return;
      setState(() => _unreadCount = (res as List).length);
    } catch (e) {
      debugPrint('loadUnreadCount failed: $e');
    }
  }

  void _subscribeToMessages() {
    final userId = Supabase.instance.client.auth.currentUser?.id;
    if (userId == null) return;
    _messagesChannel?.unsubscribe();
    _messagesChannel = Supabase.instance.client
        .channel('messages_badge_$userId')
        .onPostgresChanges(
          event: PostgresChangeEvent.all,
          schema: 'public',
          table: 'notifications',
          filter: PostgresChangeFilter(
            type: PostgresChangeFilterType.eq,
            column: 'user_id',
            value: userId,
          ),
          callback: (_) => _loadUnreadCount(),
        )
        .subscribe();
  }

  // ════════════════════════════════════════════════════════════
  // RESTORE ACTIVE RIDE
  // ════════════════════════════════════════════════════════════
  Future<void> _restoreActiveRideState() async {
    try {
      final userId = Supabase.instance.client.auth.currentUser?.id;
      if (userId == null) return;
      final row = await Supabase.instance.client
          .from('rides')
          .select(
            'id, status, pickup_otp, pickup_otp_verified, driver_id, '
            'fare, distance_km, dropoff_address, dropoff_lat, dropoff_lng, '
            'customer_bid, is_bidding, bid_status, driver_counter, '
            'counter_driver_id',
          )
          .eq('customer_id', userId)
          .filter('order_id', 'is', null)
          .inFilter('status', ['pending', 'accepted', 'in_progress', 'returning'])
          .order('created_at', ascending: false)
          .limit(1)
          .maybeSingle();

      if (row == null || !mounted) return;
      final status = (row['status'] ?? '').toString();
      final otp = row['pickup_otp']?.toString();
      final verified = row['pickup_otp_verified'] == true;
      final dl = row['dropoff_lat'];
      final dg = row['dropoff_lng'];

      _lastRowStatus = status;
      _counterShownKey = null;
      setState(() {
        activeRideId = row['id']?.toString();
        _currentRideStatus = status;
        isSearchingRide = status == 'pending';
        _pickupOtp = otp;
        _otpVerified = verified;
        _isTripActive = true;
        _currentBid = (row['customer_bid'] as num?)?.toDouble() ??
            (row['fare'] as num?)?.toDouble() ??
            0.0;
        estimatedFare = (row['fare'] as num?)?.toDouble() ?? 0.0;
        estimatedDistanceKm = (row['distance_km'] as num?)?.toDouble() ?? 0.0;
        _dropoffAddress = (row['dropoff_address'] ?? '').toString();
        if (dl != null && dg != null) {
          dropoffLatLng =
              LatLng((dl as num).toDouble(), (dg as num).toDouble());
        }
      });

      if (otp == null || otp.isEmpty) {
        await _refetchPickupOtp(row['id'].toString());
      }
      if (status != 'pending' && row['driver_id'] != null) {
        _hasAcceptedModalShown = true;
        await _loadDriverDetails(row['driver_id'].toString());
        await _loadInitialDriverLocation(row['driver_id'].toString());
      }
      if (activeRideId != null) {
        _setupDriverLocationListener(activeRideId!);
        _listenToRideStatus(activeRideId!);
        _expandSheet();
        _refitCameraSoon();
        if (status == 'pending' && mounted) {
          if (_radarDialogContext == null) _showSearchingDialog();
          final counter = (row['driver_counter'] as num?)?.toDouble() ?? 0;
          if (row['bid_status'] == 'countered' && counter > 0) {
            _counterShownKey = '${row['counter_driver_id']}_$counter';
            _showCounterOfferFromDriver(counter);
          }
        }
      }
    } catch (e) {
      debugPrint('restoreActiveRideState failed: $e');
    }
  }

  Future<void> _loadDriverDetails(String driverId) async {
    final rideId = activeRideId;
    if (rideId != null) {
      _attachCall();
      try {
        final d = await Supabase.instance.client
            .rpc('get_trip_driver', params: {'p_ride': rideId});
        if (d is Map && mounted) {
          final name = (d['name'] ?? '').toString().trim();
          setState(() {
            _acceptedDriverDetails = {
              'id': driverId,
              'first_name': name.isNotEmpty
                  ? name
                  : (d['full_name'] ?? '').toString(),
              'surname': '',
              'average_rating': d['rating'],
              'vehicle_make': d['make'],
              'vehicle_model': d['model'],
              'vehicle_plate': d['plate'],
              'vehicle_color': d['color'],
              'profile_picture_url': d['photo'],
              'phone': d['phone'],
              'verified': d['verified'] == true,
            };
            _isTrackingDriver = true;
          });
          final dl = d['lat'], dg = d['lng'];
          if (dl is num && dg is num) {
            unawaited(_onDriverPosition(LatLng(dl.toDouble(), dg.toDouble())));
          }
          return;
        }
      } catch (e) {
        debugPrint('get_trip_driver failed, using profile: $e');
      }
    }
    try {
      final driverProfile = await Supabase.instance.client
          .from('profiles')
          .select(
              'id, first_name, surname, average_rating, total_ratings, '
              'vehicle_make, vehicle_model, vehicle_plate, '
              'vehicle_color, profile_picture_url')
          .eq('id', driverId)
          .maybeSingle();
      if (!mounted || driverProfile == null) return;
      setState(() {
        _acceptedDriverDetails = driverProfile;
        _isTrackingDriver = true;
      });
    } catch (e) {
      debugPrint('loadDriverDetails failed: $e');
    }
  }

  Future<void> _loadInitialDriverLocation(String driverId) async {
    try {
      final row = await Supabase.instance.client
          .from('profiles')
          .select('lat, lng')
          .eq('id', driverId)
          .maybeSingle();
      final lat = row?['lat'];
      final lng = row?['lng'];
      if (lat == null || lng == null || !mounted) return;
      final pos = LatLng((lat as num).toDouble(), (lng as num).toDouble());
      setState(() => activeDriverLocation = pos);
      if (customerLocation != null) {
        await _fetchRouteBetweenTwoPoints(pos, customerLocation!);
        _fitCameraToRoute();
      }
    } catch (e) {
      debugPrint('loadInitialDriverLocation failed: $e');
    }
  }

  Future<void> _refetchPickupOtp(String rideId) async {
    try {
      final row = await Supabase.instance.client
          .from('rides')
          .select('pickup_otp, pickup_otp_verified, status')
          .eq('id', rideId)
          .maybeSingle();
      if (!mounted || row == null) return;
      final otp = row['pickup_otp']?.toString();
      final verified = row['pickup_otp_verified'] == true;
      final status = (row['status'] ?? '').toString();
      setState(() {
        if (otp != null && otp.isNotEmpty) _pickupOtp = otp;
        _otpVerified = verified;
        if (status.isNotEmpty) _currentRideStatus = status;
      });
    } catch (e) {
      debugPrint('OTP refetch failed: $e');
    }
  }

  // ════════════════════════════════════════════════════════════
  // RECENTS
  // ════════════════════════════════════════════════════════════
  Future<void> _loadRecentDestinations() async {
    try {
      final userId = Supabase.instance.client.auth.currentUser?.id;
      if (userId == null) return;
      final rows = await Supabase.instance.client
          .from('rides')
          .select('dropoff_address, dropoff_lat, dropoff_lng')
          .eq('customer_id', userId)
          .eq('status', 'completed')
          .order('created_at', ascending: false)
          .limit(6)
          .timeout(const Duration(seconds: 30));

      final seen = <String>{};
      final list = <Map<String, dynamic>>[];
      for (final r in rows) {
        final addr = (r['dropoff_address'] ?? '').toString().trim();
        if (addr.isEmpty || seen.contains(addr)) continue;
        seen.add(addr);
        list.add({
          'address': addr,
          'lat': r['dropoff_lat'],
          'lng': r['dropoff_lng'],
        });
        if (list.length >= 4) break;
      }
      if (mounted) setState(() => _recentDestinations = list);
    } catch (e) {
      debugPrint('loadRecentDestinations failed: $e');
    }
  }

  // ════════════════════════════════════════════════════════════
  // PHOTO GATE
  // ════════════════════════════════════════════════════════════
  Future<void> _checkProfilePhotoGate() async {
    if (_photoGateChecked) return;
    _photoGateChecked = true;
    final userId = Supabase.instance.client.auth.currentUser?.id;
    if (userId == null) return;
    try {
      final profile = await Supabase.instance.client
          .from('profiles')
          .select('profile_picture_url, avatar_url')
          .eq('id', userId)
          .maybeSingle();
      if (!mounted) return;
      final url = (profile?['profile_picture_url'] ?? profile?['avatar_url'])
          ?.toString()
          .trim();
      if (url == null || url.isEmpty) {
        await Navigator.push<bool>(
          context,
          MaterialPageRoute(
            builder: (_) => const ProfilePhotoRequiredScreen(),
          ),
        );
      }
    } catch (e) {
      debugPrint('photo gate check failed: $e');
    }
  }

  // ════════════════════════════════════════════════════════════
  // ARRIVAL BANNER
  // ════════════════════════════════════════════════════════════
  // Full photo of the driver, shown when they arrive so the customer
  // knows who to look for.
  void _showDriverPhoto() {
    final d = _acceptedDriverDetails;
    final url = d?['profile_picture_url']?.toString() ?? '';
    if (!mounted || d == null) return;
    final name = '${d['first_name'] ?? ''} ${d['surname'] ?? ''}'.trim();
    final plate = '${d['vehicle_plate'] ?? ''}';
    showDialog(
      context: context,
      builder: (ctx) => Dialog(
        clipBehavior: Clip.antiAlias,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (url.isNotEmpty)
              InteractiveViewer(
                child: Image.network(url,
                    height: 360,
                    width: double.infinity,
                    fit: BoxFit.cover,
                    errorBuilder: (_, __, ___) => const SizedBox(
                        height: 200,
                        child: Center(child: KIcon(Icons.person, size: 80)))),
              )
            else
              const SizedBox(
                  height: 200,
                  child: Center(child: KIcon(Icons.person, size: 80))),
            Padding(
              padding: const EdgeInsets.all(16),
              child: Column(children: [
                Text(tr('Your driver has arrived'),
                    style: const TextStyle(
                        fontSize: 18, fontWeight: FontWeight.w800)),
                if (name.isNotEmpty) Text(name),
                if (plate.isNotEmpty)
                  Text(plate,
                      style: const TextStyle(fontWeight: FontWeight.w700)),
                const SizedBox(height: 8),
                TextButton(
                    onPressed: () => Navigator.pop(ctx), child: Text(tr('OK'))),
              ]),
            ),
          ],
        ),
      ),
    );
  }

  void _callDriver() {
    final n = '${_acceptedDriverDetails?['first_name'] ?? ''}'.trim();
    CallService.instance.call(toName: n.isEmpty ? tr('Driver') : n);
  }

  void _attachCall() {
    final id = activeRideId;
    if (id == null) return;
    final svc = CallService.instance;
    svc.onIncoming = () {
      if (mounted) InAppCallScreen.show(context);
    };
    svc.onOutgoing = () {
      if (mounted) InAppCallScreen.show(context);
    };
    svc.attach(id, myName: tr('Customer'));
  }

  void _showArrivalBanner(String message,
      {Color color = _LocalColors.success}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            const Icon(Icons.check_circle, color: Colors.white),
            const SizedBox(width: 12),
            Expanded(
                child: Text(message,
                    style: const TextStyle(fontWeight: FontWeight.bold))),
          ],
        ),
        backgroundColor: color,
        duration: const Duration(seconds: 5),
        behavior: SnackBarBehavior.floating,
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      ),
    );
  }

  // ════════════════════════════════════════════════════════════
  // TRACKING CLEANUP
  // ════════════════════════════════════════════════════════════
  void _stopTrackingAndClear() {
    _driverLocationChannel?.unsubscribe();
    _driverLocationChannel = null;
    _etaRefreshTimer?.cancel();
    _etaRefreshTimer = null;
    if (mounted) {
      setState(() {
        activeDriverLocation = null;
        routePoints = [];
        _isTrackingDriver = false;
        _driverEtaMinutes = null;
        _driverDistanceToPickupKm = null;
        _driverHeading = 0.0;
      });
    }
  }

  void _startEtaCountdown() {
    _etaCountdownTimer?.cancel();
    _etaCountdownSeconds = 180;
    _etaCountdownTimer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (!mounted) return;
      if (_etaCountdownSeconds <= 0) {
        t.cancel();
        return;
      }
      setState(() => _etaCountdownSeconds--);
    });
  }

  void _stopEtaCountdown() {
    _etaCountdownTimer?.cancel();
    _etaCountdownTimer = null;
  }

  void _startEtaRefresh() {
    _etaRefreshTimer?.cancel();
    _etaRefreshTimer = Timer.periodic(const Duration(seconds: 30), (_) async {
      if (!mounted) return;
      if (_currentRideStatus != 'accepted') return;
      if (activeDriverLocation == null || customerLocation == null) return;
      await _fetchRouteBetweenTwoPoints(
          activeDriverLocation!, customerLocation!);
    });
  }

  // ════════════════════════════════════════════════════════════
  // ROUTE
  // ════════════════════════════════════════════════════════════
  /// Road route via Google (through the ko!ngo Maps proxy).
  Future<Map<String, dynamic>?> _getRouteInfo(LatLng from, LatLng to) async {
    final route = await GoogleMapsService.route(from, to);
    if (route == null || route.points.isEmpty) return null;
    return {
      'points': route.points,
      'distance_km': route.distanceKm,
      'duration_min': route.durationMin,
    };
  }

  // ════════════════════════════════════════════════════════════
  // PICKUP CONFIRM
  // ════════════════════════════════════════════════════════════
  /// Short readable name for an address: "22, Oak St, …" → "22 Oak St".
  String _placeLabel(String address) {
    final parts = address
        .split(',')
        .map((p) => p.trim())
        .where((p) => p.isNotEmpty)
        .toList();
    if (parts.isEmpty) return address;
    if (RegExp(r'^\d+[a-zA-Z]?$').hasMatch(parts.first) && parts.length > 1) {
      return '${parts[0]} ${parts[1]}';
    }
    return parts.first;
  }

  Future<void> _confirmPickupPoint() async {
    if (_isMapLocked) return;
    final result = await showModalBottomSheet<Map<String, dynamic>>(
      context: context,
      isScrollControlled: true,
      isDismissible: true,
      enableDrag: true,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (_) => _PickupConfirmSheet(
        initialAddress: _pickupAddress,
        initialLocation: customerLocation,
        pickupLatLng: customerLocation,
      ),
    );
    if (result == null || !mounted) return;
    setState(() {
      _pickupAddress = result['address'] as String;
      if (result['lat'] != null && result['lng'] != null) {
        customerLocation =
            LatLng(result['lat'] as double, result['lng'] as double);
      }
    });
    _animateTo(customerLocation!, 16.0);
    _refitCameraSoon();
  }

  // ════════════════════════════════════════════════════════════
  // CANCEL FLOW
  // ════════════════════════════════════════════════════════════
  Future<void> _showCancelReasonDialog(BuildContext radarContext) async {
    final t = S.of(context);
    final reasons = [
      t.t('cancel_reason_changed_mind'),
      t.t('cancel_reason_waiting'),
      t.t('cancel_reason_found_another'),
      t.t('cancel_reason_wrong_pickup'),
      t.t('cancel_reason_driver_far'),
      t.t('cancel_reason_other'),
    ];
    String? selected;
    final otherController = TextEditingController();

    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setSt) => AlertDialog(
          title: Text(t.t('why_cancelling')),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                ...reasons.map((r) => RadioListTile<String>(
                      title: Text(r),
                      value: r,
                      groupValue: selected,
                      contentPadding: EdgeInsets.zero,
                      onChanged: (v) => setSt(() => selected = v),
                    )),
                if (selected == t.t('cancel_reason_other'))
                  TextField(
                    controller: otherController,
                    decoration: InputDecoration(
                      hintText: t.t('tell_more_optional'),
                      border: const OutlineInputBorder(),
                    ),
                  ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: Text(t.t('keep_searching')),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                  backgroundColor: EfuridePalette.dropoff),
              onPressed:
                  selected == null ? null : () => Navigator.pop(ctx, true),
              child: Text(t.t('confirm_cancel')),
            ),
          ],
        ),
      ),
    );

    if (confirmed != true) return;
    final reasonText = selected == t.t('cancel_reason_other')
        ? (otherController.text.trim().isEmpty
            ? t.t('cancel_reason_other')
            : otherController.text.trim())
        : selected!;

    if (activeRideId != null) {
      try {
        await Supabase.instance.client.from('rides').update({
          'status': 'cancelled',
          'cancellation_reason': reasonText,
          'cancelled_by': 'customer',
          'cancelled_at': DateTime.now().toIso8601String(),
        }).eq('id', activeRideId!);
        TripShareService.revokeAllForRide(activeRideId!);
      } catch (e) {
        debugPrint('cancel from dialog failed: $e');
      }
    }

    _stopTrackingAndClear();
    _stopEtaCountdown();
    if (radarContext.mounted) Navigator.pop(radarContext);
    _radarDialogContext = null;
    if (mounted) {
      setState(() {
        isSearchingRide = false;
        _isTripActive = false;
        dropoffLatLng = null;
        _dropoffAddress = '';
        _acceptedDriverDetails = null;
        _pickupOtp = null;
        _otpVerified = false;
        activeRideId = null;
        _currentRideStatus = 'cancelled';
      });
      _rideStatusChannel?.unsubscribe();
      _rideStatusChannel = null;
      _collapseSheet();
      _deferredCenterOnCustomer();
    }
  }

  Future<void> _checkTripStillActive() async {
    final id = activeRideId;
    if (id == null || !mounted) return;
    try {
      final row = await Supabase.instance.client
          .from('rides')
          .select()
          .eq('id', id)
          .maybeSingle();
      final st = (row?['status'] ?? '').toString();
      if (row != null && st != 'cancelled') {
        // Realtime can miss a step (weak signal): catch up here.
        final counterKey = row['bid_status'] == 'countered'
            ? '${row['counter_driver_id']}_${(row['driver_counter'] as num?)?.toDouble() ?? 0}'
            : null;
        final counterChanged = counterKey != _counterShownKey &&
            (counterKey != null || _counterDialogContext != null);
        if (st != _lastRowStatus || counterChanged) {
          await _onRideRow(id, Map<String, dynamic>.from(row));
        }
        final dl = row['driver_lat'], dg = row['driver_lng'];
        if (dl != null && dg != null &&
            (st == 'accepted' || st == 'in_progress')) {
          final p = LatLng((dl as num).toDouble(), (dg as num).toDouble());
          if (activeDriverLocation == null ||
              _distanceInMeters(activeDriverLocation!, p) > 15 ||
              routePoints.isEmpty) {
            await _onDriverPosition(p);
          }
        }
        return;
      }
      if (!mounted || activeRideId != id) return;
      _stopTrackingAndClear();
      _stopEtaCountdown();
      TripShareService.revokeAllForRide(id);
      if (_radarDialogContext != null) {
        Navigator.of(_radarDialogContext!).pop();
        _radarDialogContext = null;
      }
      setState(() {
        isSearchingRide = false;
        _isTripActive = false;
        _isTrackingDriver = false;
        _hasAcceptedModalShown = false;
        dropoffLatLng = null;
        _dropoffAddress = '';
        _acceptedDriverDetails = null;
        _pickupOtp = null;
        _otpVerified = false;
        activeRideId = null;
        _currentRideStatus = 'cancelled';
      });
      ErrorUI.showSnack(
        context,
        AppError(
          title: S.of(context).t('ride_cancelled'),
          message: tr('This trip was cancelled.'),
          icon: Icons.cancel_outlined,
        ),
      );
    } catch (_) {}
  }

  Future<void> _cancelActiveTrip() async {
    final t = S.of(context);
    if (_currentRideStatus == 'in_progress') {
      ErrorUI.showSnack(
        context,
        AppError(
          title: tr('Trip already started'),
          message: tr('Your trip has started. Only the driver can end it now.'),
          icon: Icons.info_outline,
        ),
      );
      return;
    }
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(t.t('cancel_trip_q')),
        content: Text(t.t('cancel_trip_hint')),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: Text(t.t('keep_trip'))),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
                backgroundColor: EfuridePalette.dropoff),
            onPressed: () => Navigator.pop(ctx, true),
            child: Text(t.t('cancel_trip')),
          ),
        ],
      ),
    );
    if (confirmed != true) return;
    if (activeRideId == null) return;
    try {
      await Supabase.instance.client.from('rides').update({
        'status': 'cancelled',
        'cancelled_by': 'customer',
        'cancellation_reason': 'Customer cancelled after driver accepted',
        'cancelled_at': DateTime.now().toIso8601String(),
      }).eq('id', activeRideId!);

      final driverId = _acceptedDriverDetails?['id'];
      if (driverId != null) {
        _notifyOnce(
          eventKey: 'cancel_$activeRideId',
          toUserId: driverId.toString(),
          title: t.t('ride_cancelled'),
          body: t.t('ride_cancelled_hint'),
          type: 'ride_cancelled',
          data: {'ride_id': activeRideId},
        );
      }
      TripShareService.revokeAllForRide(activeRideId!);
      _stopTrackingAndClear();
      _stopEtaCountdown();
      if (mounted) {
        setState(() {
          isSearchingRide = false;
          _isTripActive = false;
          activeRideId = null;
          _currentRideStatus = 'cancelled';
          _acceptedDriverDetails = null;
          _pickupOtp = null;
          _otpVerified = false;
        });
        _collapseSheet();
        _deferredCenterOnCustomer();
      }
    } catch (e) {
      if (!mounted) return;
      ErrorUI.showSnack(context, AppError.from(e, onRetry: _cancelActiveTrip));
    }
  }

  // ════════════════════════════════════════════════════════════
  // SHARE LIVE TRIP
  // ════════════════════════════════════════════════════════════
  Future<void> _shareLiveTrip() async {
    if (activeRideId == null) return;
    final t = S.of(context);
    final code = await TripShareService.createShareLink(rideId: activeRideId!);
    if (!mounted) return;
    if (code == null) return;
    final url = TripShareService.buildUrl(code);

    await showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Row(
          children: [
            const KIcon(Icons.ios_share, color: EfuridePalette.blue),
            const SizedBox(width: 8),
            Text(t.t('share_live_trip')),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              t.t('share_live_hint'),
              style: const TextStyle(fontSize: 14, color: Colors.black54),
            ),
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: Colors.grey.shade100,
                borderRadius: BorderRadius.circular(8),
              ),
              child: SelectableText(
                url,
                style: const TextStyle(
                    fontSize: 13.5, fontWeight: FontWeight.w600),
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () async {
              await Clipboard.setData(ClipboardData(text: url));
              if (ctx.mounted) Navigator.pop(ctx);
            },
            child: Text(t.t('copy_link')),
          ),
          ElevatedButton(
            onPressed: () {
              Share.share(
                '${t.t('share_live_message')} $url',
                subject: t.t('share_live_subject'),
              );
              Navigator.pop(ctx);
            },
            style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFFF2B705),
        foregroundColor: const Color(0xFF0B1220)),
            child: Text(t.t('share'),
                style: TextStyle(color: Color(0xFF0B1220))),
          ),
        ],
      ),
    );
  }

  // ════════════════════════════════════════════════════════════
  // NEARBY DRIVERS
  // ════════════════════════════════════════════════════════════
  void _subscribeToNearbyDrivers() {
    _nearbyDriversChannel?.unsubscribe();
    _nearbyDriversChannel = Supabase.instance.client
        .channel('nearby_drivers_live')
        .onPostgresChanges(
          event: PostgresChangeEvent.all,
          schema: 'public',
          table: 'profiles',
          callback: (payload) {
            final record = payload.newRecord;
            if (record.isEmpty) return;
            if ((record['role'] ?? '').toString().toLowerCase() != 'driver') {
              return;
            }
            final id = record['id'];
            if (id == null) return;

            if (record['is_online'] != true) {
              if (mounted) {
                setState(() {
                  _nearbyDrivers.removeWhere((d) => d['id'] == id);
                  _driverHeadings.remove(id.toString());
                  _lastDriverPos.remove(id.toString());
                });
              }
              return;
            }
            final lat = record['lat'];
            final lng = record['lng'];
            if (lat == null || lng == null) return;

            final newPos =
                LatLng((lat as num).toDouble(), (lng as num).toDouble());
            final key = id.toString();
            final prev = _lastDriverPos[key];
            if (prev != null) {
              final d = _distanceInMeters(prev, newPos);
              if (d > 5) {
                _driverHeadings[key] = Geolocator.bearingBetween(
                  prev.latitude, prev.longitude,
                  newPos.latitude, newPos.longitude,
                );
              }
            }
            _lastDriverPos[key] = newPos;

            if (mounted) {
              setState(() {
                final idx = _nearbyDrivers.indexWhere((d) => d['id'] == id);
                final updated = {
                  'id': id,
                  'lat': newPos.latitude,
                  'lng': newPos.longitude,
                };
                if (idx >= 0) {
                  _nearbyDrivers[idx] = updated;
                } else {
                  _nearbyDrivers.add(updated);
                }
              });
            }
          },
        )
        .subscribe();
    _fetchNearbyDrivers();
  }

  Future<void> _fetchNearbyDrivers() async {
    final center = customerLocation;
    if (center == null) return;
    try {
      const radiusKm = 5.0;
      const kmPerDegLat = 111.0;
      final kmPerDegLng =
          111.0 * math.cos(center.latitude * math.pi / 180.0).abs();
      final latDelta = radiusKm / kmPerDegLat;
      final lngDelta =
          radiusKm / (kmPerDegLng == 0 ? kmPerDegLat : kmPerDegLng);

      final response = await Supabase.instance.client
          .from('profiles')
          .select('id, lat, lng')
          .eq('role', 'driver')
          .eq('is_online', true)
          .gte('lat', center.latitude - latDelta)
          .lte('lat', center.latitude + latDelta)
          .gte('lng', center.longitude - lngDelta)
          .lte('lng', center.longitude + lngDelta);

      if (!mounted) return;
      setState(() =>
          _nearbyDrivers = List<Map<String, dynamic>>.from(response));
    } catch (e) {
      debugPrint('Nearby drivers error: $e');
    }
  }

  Future<void> _loadVehicleTypes() async {
    try {
      final response = await Supabase.instance.client
          .from('vehicle_types')
          .select()
          .eq('is_active', true)
          .order('display_order', ascending: true);
      final list = List<Map<String, dynamic>>.from(response);
      if (!mounted) return;
      setState(() {
        _allVehicles = list;
        final filtered =
            list.where((v) => _vehicleServesMode(v, serviceMode)).toList();
        if (filtered.isNotEmpty) {
          selectedVehicleName = filtered.first['name'];
        }
      });
      _recomputeFare();
    } catch (_) {}
  }

  List<Map<String, dynamic>> get _filteredVehicles {
    return _allVehicles
        .where((v) => _vehicleServesMode(v, serviceMode))
        .toList();
  }

  void _recomputeFare() {
    final vehicle = _filteredVehicles.firstWhere(
      (v) => v['name'] == selectedVehicleName,
      orElse: () => _filteredVehicles.isNotEmpty
          ? _filteredVehicles.first
          : <String, dynamic>{},
    );
    if (vehicle.isEmpty) return;

    final multiplier = (vehicle['multiplier'] as num?)?.toDouble() ?? 1.0;
    double fare =
        (_adminBaseFare + (estimatedDistanceKm * _adminPerKmRate)) *
            _adminSurge *
            multiplier;
    if (fare < _adminMinFare) fare = _adminMinFare;
    estimatedFare = fare;
  }

  // ════════════════════════════════════════════════════════════
  // LOCATION INIT & REAL-TIME UPDATES
  // ════════════════════════════════════════════════════════════
  Future<void> _initCustomerLocation() async {
    try {
      final serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!serviceEnabled) {
        _showLocationBlocked('Location services are off');
        return;
      }
      LocationPermission permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
        if (permission == LocationPermission.denied) {
          _showLocationBlocked('Grant location permission');
          return;
        }
      }
      if (permission == LocationPermission.deniedForever) {
        _showLocationBlocked('Location permission denied forever');
        return;
      }
      // Show the last known spot straight away (no endless "Detecting
      // location"), then refine with a fresh GPS fix.
      Position? last;
      if (!kIsWeb) {
        // Not available in browsers (it throws there).
        try {
          last = await Geolocator.getLastKnownPosition();
        } catch (_) {}
      }
      if (last != null && mounted && customerLocation == null) {
        setState(() {
          customerLocation = LatLng(last!.latitude, last!.longitude);
          _pendingCenterOnCustomer = true;
        });
        unawaited(_fetchReverseGeocodeAddress(last!.latitude, last!.longitude));
      }
      Position? position;
      try {
        position = await Geolocator.getCurrentPosition(
          desiredAccuracy: LocationAccuracy.high,
          timeLimit: const Duration(seconds: 25),
        );
      } catch (_) {
        if (last == null) {
          // Second try with lower accuracy (browsers / indoors).
          try {
            position = await Geolocator.getCurrentPosition(
              desiredAccuracy: LocationAccuracy.medium,
              timeLimit: const Duration(seconds: 20),
            );
          } catch (e) {
            debugPrint('Location completely unavailable: $e');
          }
        } else {
          position = last; // indoors / weak GPS: keep the last known spot
        }
      }
      if (!mounted || position == null) return;
      setState(() {
        customerLocation = LatLng(position!.latitude, position!.longitude);
        _pendingCenterOnCustomer = true;
      });
      _animateTo(customerLocation!, 16.0);
      // Country (currency + prices) follows where the customer actually is.
      context
          .read<AuthProvider>()
          .updateCountryFromPosition(position.latitude, position.longitude);
      await _loadPricingSettings();
      await _fetchReverseGeocodeAddress(position.latitude, position.longitude);
      await _fetchRouteAndFare();
      await _fetchNearbyDrivers();
    } catch (e) {
      debugPrint('initCustomerLocation failed: $e');
      _showLocationBlocked('Couldn\'t get your location');
    }
  }

  /// Real-time location tracking stream.
  /// Updates the map instantly but throttles DB writes to every 5 seconds.
  void _startLocationUpdates() {
    _positionStreamSubscription?.cancel();

    _positionStreamSubscription = Geolocator.getPositionStream(
      locationSettings: const LocationSettings(
        accuracy: LocationAccuracy.bestForNavigation,
        distanceFilter: 0, // Update on every tiny movement
      ),
    ).listen((Position position) {
      if (!mounted) return;

      final newLoc = LatLng(position.latitude, position.longitude);

      // Avoid excessive rebuilds if location hasn't changed significantly (e.g. < 1 meter)
      if (customerLocation != null &&
          _distanceInMeters(customerLocation!, newLoc) < 1.0) {
        return;
      }

      setState(() {
        customerLocation = newLoc;
      });

      // Instantly snap the map to the new location (No animation = no lag)
      _mapController?.moveCamera(
        gmaps.CameraUpdate.newLatLngZoom(
          gmaps.LatLng(newLoc.latitude, newLoc.longitude),
          16.5, // Locked zoom level
        ),
      );

      // Throttled DB update
      _updateLocationInDatabase(newLoc);
    });
  }

  Future<void> _updateLocationInDatabase(LatLng loc) async {
    final now = DateTime.now();
    if (now.difference(_lastDbUpdate).inSeconds < 5) return;
    _lastDbUpdate = now;

    try {
      final userId = Supabase.instance.client.auth.currentUser?.id;
      if (userId != null) {
        await Supabase.instance.client.from('profiles').update({
          'lat': loc.latitude,
          'lng': loc.longitude,
        }).eq('id', userId);
      }
    } catch (_) {}
  }

  void _showLocationBlocked(String reason) {
    if (!mounted) return;
    final t = S.of(context);
    ErrorUI.showSnack(
      context,
      AppError(
        title: t.t('location_needed'),
        message: '$reason — ${t.t('location_needed_hint')}',
        icon: Icons.location_off_outlined,
        actionLabel: t.t('retry'),
        onRetry: _initCustomerLocation,
      ),
    );
  }

  /// Pickup address for a GPS point, via Google.
  Future<void> _fetchReverseGeocodeAddress(double lat, double lng) async {
    final place = await GoogleMapsService.reverseGeocode(LatLng(lat, lng));
    if (place == null || !mounted) return;
    setState(() {
      final short = place.shortLabel;
      final ctx = place.contextLabel;
      _pickupAddress = ctx.isEmpty || short == place.formattedAddress
          ? place.displayAddress
          : '$short, $ctx';
      _pickupSuburb = place.suburb ?? place.city ?? '';
    });
  }

  Future<void> _fetchRouteAndFare() async {
    if (customerLocation == null || dropoffLatLng == null) return;
    final info = await _getRouteInfo(customerLocation!, dropoffLatLng!);
    if (info != null && mounted) {
      setState(() {
        routePoints = info['points'];
        estimatedDistanceKm = info['distance_km'];
        _recomputeFare();
      });
    }
  }

  Future<void> _fetchRouteBetweenTwoPoints(LatLng start, LatLng end) async {
    final info = await _getRouteInfo(start, end);
    if (info != null && mounted) {
      setState(() {
        routePoints = info['points'];
        _driverEtaMinutes = info['duration_min'] as int;
        _driverDistanceToPickupKm = (info['distance_km'] as num).toDouble();
      });
      _refitCameraSoon();
    }
  }

  void _setupDriverLocationListener(String rideId) {
    _driverLocationChannel?.unsubscribe();
    _driverLocationChannel = Supabase.instance.client
        .channel(
            'driver_location_listener_${DateTime.now().millisecondsSinceEpoch}')
        .onPostgresChanges(
          event: PostgresChangeEvent.update,
          schema: 'public',
          table: 'rides',
          filter: PostgresChangeFilter(
              type: PostgresChangeFilterType.eq,
              column: 'id',
              value: rideId),
          callback: (payload) async {
            final status = payload.newRecord['status'];
            if (status == 'completed' || status == 'cancelled') {
              _stopTrackingAndClear();
              return;
            }
            final lat = payload.newRecord['driver_lat'];
            final lng = payload.newRecord['driver_lng'];
            if (lat == null || lng == null) return;
            await _onDriverPosition(
                LatLng((lat as num).toDouble(), (lng as num).toDouble()));
          },
        )
        .subscribe();
  }

  /// The driver moved (realtime, or the 10 s check when realtime is
  /// quiet): move the car, redraw the line and update the ETA.
  bool _routingDriver = false;
  Future<void> _onDriverPosition(LatLng newDriverPos) async {
    if (_routingDriver) return;
    _routingDriver = true;
    try {
            double heading = _driverHeading;
            if (activeDriverLocation != null) {
              final d = _distanceInMeters(activeDriverLocation!, newDriverPos);
              if (d > 5) {
                heading = Geolocator.bearingBetween(
                  activeDriverLocation!.latitude,
                  activeDriverLocation!.longitude,
                  newDriverPos.latitude,
                  newDriverPos.longitude,
                );
              }
            }

            if (!mounted) return;
            setState(() {
              activeDriverLocation = newDriverPos;
              _driverHeading = heading;
            });

            if (_currentRideStatus == 'accepted' && customerLocation != null) {
              final info =
                  await _getRouteInfo(newDriverPos, customerLocation!);
              if (info != null && mounted) {
                setState(() {
                  routePoints = info['points'];
                  _driverEtaMinutes = info['duration_min'] as int;
                  _driverDistanceToPickupKm =
                      (info['distance_km'] as num).toDouble();
                });
              }
              _fitCameraToRoute();

              final s = S.of(context);
              if (!_hasNotifiedPickupArrival) {
                final d = _distanceInMeters(newDriverPos, customerLocation!);
                if (d < 100) {
                  _hasNotifiedPickupArrival = true;
                  _showArrivalBanner(s.t('driver_arrived'));
                  RingService.instance.showAlertNotification(
                      title: s.t('driver_arrived'), body: 'ko!ngo', id: 7002);
                  _showDriverPhoto();
                } else if (d < 300 && !_hasNotifiedNearby) {
                  _hasNotifiedNearby = true;
                  _showArrivalBanner(
                      '${s.t('driver_nearby')} ${_formatDistance(d / 1000)}',
                      color: EfuridePalette.blue);
                  RingService.instance.showAlertNotification(
                      title: s.t('driver_nearby'),
                      body: _formatDistance(d / 1000), id: 7001);
                }
              }
            } else if (_currentRideStatus == 'in_progress' &&
                dropoffLatLng != null) {
              await _fetchRouteBetweenTwoPoints(newDriverPos, dropoffLatLng!);
              _fitCameraToRoute();
              if (!_hasNotifiedDestinationArrival) {
                final d = _distanceInMeters(newDriverPos, dropoffLatLng!);
                if (d < 100) {
                  _hasNotifiedDestinationArrival = true;
                  _showArrivalBanner(
                      S.of(context).t('arrived_at_dest'),
                      color: EfuridePalette.blue);
                  RingService.instance.showAlertNotification(
                      title: S.of(context).t('arrived_at_dest'),
                      body: 'ko!ngo', id: 7003);
                }
              }
            }
    } finally {
      _routingDriver = false;
    }
  }

  void _notifyOnce({
    required String eventKey,
    required String toUserId,
    required String title,
    required String body,
    required String type,
    Map<String, dynamic>? data,
  }) {
    if (_notifiedEvents.contains(eventKey)) return;
    _notifiedEvents.add(eventKey);
    Future.delayed(const Duration(seconds: 30), () {
      _notifiedEvents.remove(eventKey);
    });
    NotificationService.send(
      toUserId: toUserId,
      type: type,
      title: title,
      body: body,
      route: '/driver',
      tab: 'home',
      params: data,
    );
  }

  // ════════════════════════════════════════════════════════════
  // BOOKING FLOW
  // ════════════════════════════════════════════════════════════
  /// Ride entry points (search bar, Ride tile): open on the Ride tab.
  Future<void> _openScheduledRides() async {
    final r = await Navigator.pushNamed(context, '/scheduled_rides');
    if (r == 'book' && mounted) {
      _scheduleNextBooking = true;
      await _openRideFlow();
      _scheduleNextBooking = false;
    }
  }

  /// Ask the server to send out any scheduled ride that is due (pg_cron
  /// normally does this every minute; this is the backup).
  Future<void> _dispatchDueScheduled() async {
    if (activeRideId != null) return;
    try {
      final n = await Supabase.instance.client.rpc('kongo_dispatch_scheduled');
      if ((n is num) && n > 0) await _restoreActiveRideState();
    } catch (_) {}
  }

  Future<void> _openRideFlow() async {
    if (serviceMode != 'Ride') setState(() => serviceMode = 'Ride');
    await _openBookingFlow();
  }

  Future<void> _openBookingFlow() async {
    if (_isTripActive || isSearchingRide || activeRideId != null) return;
    if (customerLocation == null) {
      _showLocationBlocked('Pickup not set yet');
      return;
    }
    try {
      // Pickup is confirmed / changed on the Where-to screen itself.
      final result = await Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => SelectDestinationScreen(
            initialServiceMode: serviceMode,
            pickupAddress: _pickupAddress,
            pickupLatLng: gmaps.LatLng(
              customerLocation!.latitude,
              customerLocation!.longitude,
            ),
          ),
        ),
      );
      if (result == null || !mounted || customerLocation == null) return;
      // The customer may have changed the pickup on that screen.
      final pickupLat = (result['pickup_lat'] as num?)?.toDouble() ??
          customerLocation!.latitude;
      final pickupLng = (result['pickup_lng'] as num?)?.toDouble() ??
          customerLocation!.longitude;
      final pickupText =
          (result['pickup'] as String?)?.trim().isNotEmpty == true
              ? result['pickup'] as String
              : _pickupAddress;
      // Parcels are booked on that screen; just start tracking.
      final parcel = result['parcel_booking'];
      if (parcel is Map) {
        setState(() {
          dropoffLatLng = LatLng(result['lat'], result['lng']);
          _dropoffAddress = result['dropoff'];
          serviceMode = 'Delivery';
          estimatedDistanceKm = (result['distance'] ?? 0).toDouble();
          estimatedFare = (result['fare'] ?? 0).toDouble();
        });
        _handleBookingResult(Map<String, dynamic>.from(parcel));
        return;
      }
      setState(() {
        dropoffLatLng = LatLng(result['lat'], result['lng']);
        _dropoffAddress = result['dropoff'];
        selectedVehicleName = result['vehicle'];
        serviceMode = result['serviceType'] ?? serviceMode;
        estimatedDistanceKm = (result['distance'] ?? 0).toDouble();
        estimatedFare = (result['fare'] ?? 0).toDouble();
      });

      final bookingResult = await Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => BookingSummaryScreen(
            vehicle: result['vehicle'],
            pickup: pickupText,
            dropoff: result['dropoff'],
            fare: result['fare'],
            distance: result['distance'],
            etaMinutes: result['eta'],
            pickupLatLng: gmaps.LatLng(pickupLat, pickupLng),
            dropoffLatLng: gmaps.LatLng(
              (result['lat'] as num).toDouble(),
              (result['lng'] as num).toDouble(),
            ),
            serviceType: result['serviceType'],
            startScheduled: _scheduleNextBooking,
          ),
        ),
      );
      if (bookingResult != null && mounted) _handleBookingResult(bookingResult);
    } catch (e) {
      if (!mounted) return;
      ErrorUI.showSnack(context, AppError.from(e));
    }
  }

  void _handleBookingResult(Map<String, dynamic> bookingResult) {
    if (bookingResult['scheduled'] == true) {
      setState(() {
        dropoffLatLng = null;
        _dropoffAddress = '';
      });
      final when = DateTime.tryParse(
              (bookingResult['scheduled_at'] ?? '').toString())
          ?.toLocal();
      ErrorUI.showSnack(
        context,
        AppError(
          title: tr('Ride booked'),
          message: when == null
              ? tr('We\'ll start finding a driver 10 minutes before.')
              : tr('{0}. We\'ll start finding a driver 10 minutes before.',
                  [DateFormat('EEE d MMM, HH:mm').format(when)]),
          icon: Icons.event_available,
        ),
      );
      return;
    }
    activeRideId = bookingResult['ride_id']?.toString();
    _lastRowStatus = 'pending';
    _counterShownKey = null;
    _pickupOtp = bookingResult['pickup_otp']?.toString();
    _otpVerified = false;
    _currentRideStatus = 'pending';
    _currentBid = (bookingResult['fare'] ?? 0).toDouble();
    _hasAcceptedModalShown = false;
    _hasNotifiedPickupArrival = false;
    _hasNotifiedNearby = false;
    _hasNotifiedDestinationArrival = false;
    _driverEtaMinutes = null;
    _driverDistanceToPickupKm = null;

    RideWatchdogService.instance.watchForTimeout(activeRideId!);
    setState(() {
      isSearchingRide = true;
      _isTripActive = true;
    });
    _expandSheet();

    WidgetsBinding.instance.addPostFrameCallback((_) async {
      await Future.delayed(const Duration(milliseconds: 300));
      if (mounted && isSearchingRide) _showSearchingDialog();
    });

    if (_pickupOtp == null || _pickupOtp!.isEmpty) {
      _refetchPickupOtp(activeRideId!);
    }
    _setupDriverLocationListener(activeRideId!);
    _listenToRideStatus(activeRideId!);
  }

  void _listenToRideStatus(String rideId) {
    _rideStatusChannel?.unsubscribe();
    _rideStatusChannel = Supabase.instance.client
        .channel('ride_status_$rideId')
        .onPostgresChanges(
          event: PostgresChangeEvent.update,
          schema: 'public',
          table: 'rides',
          filter: PostgresChangeFilter(
              type: PostgresChangeFilterType.eq,
              column: 'id',
              value: rideId),
          callback: (payload) =>
              _onRideRow(rideId, Map<String, dynamic>.from(payload.newRecord)),
        )
        .subscribe();
  }

  /// One place that reacts to a change of the customer's trip — used by
  /// realtime and by the 10 s safety poll (realtime can miss events).
  Future<void> _onRideRow(String rideId, Map<String, dynamic> row) async {
    if (activeRideId != rideId) return;
    final updatedStatus = (row['status'] ?? '').toString();
    final bidStatus = row['bid_status'];
    final otpVerifiedNow = row['pickup_otp_verified'] == true;
    final prevStatus = _lastRowStatus;
    _lastRowStatus = updatedStatus;
    _currentRideStatus = updatedStatus;
    if (otpVerifiedNow && !_otpVerified && mounted) {
      setState(() => _otpVerified = true);
    }

    // A driver's price offer: show it once; close it when it is gone.
    final counter = (row['driver_counter'] as num?)?.toDouble() ?? 0;
    if (updatedStatus == 'pending' && bidStatus == 'countered' && counter > 0) {
      final key = '${row['counter_driver_id']}_$counter';
      if (_counterShownKey != key) {
        _closeCounterDialog();
        _counterShownKey = key;
        _showCounterOfferFromDriver(counter);
      }
      return;
    }
    if (_counterDialogContext != null) {
      _closeCounterDialog();
      if (updatedStatus == 'pending' && bidStatus == 'withdrawn' && mounted) {
        ErrorUI.showSnack(
          context,
          AppError(
            title: tr('Price offer withdrawn'),
            message: tr('We\'re still looking for a driver at your price.'),
            icon: Icons.info_outline,
          ),
        );
      }
    }
    if (bidStatus != 'countered') _counterShownKey = null;

    // Driver locations also update this row — only act on a new step.
    if (updatedStatus == prevStatus) return;

    if (updatedStatus == 'pending' && prevStatus != null) {
      // The driver let the trip go before pickup: find another driver.
      _stopEtaCountdown();
      _etaRefreshTimer?.cancel();
      _etaRefreshTimer = null;
      if (!mounted) return;
      setState(() {
        _acceptedDriverDetails = null;
        _isTrackingDriver = false;
        activeDriverLocation = null;
        routePoints = [];
        _hasAcceptedModalShown = false;
        isSearchingRide = true;
      });
      ErrorUI.showSnack(
        context,
        AppError(
          title: tr('Your driver had to cancel'),
          message: tr('We\'re finding you another driver.'),
          icon: Icons.refresh,
        ),
      );
      if (_radarDialogContext == null) _showSearchingDialog();
      return;
    }

    if (updatedStatus == 'accepted') {
      if (_hasAcceptedModalShown) return;
      _hasAcceptedModalShown = true;
      _hasNotifiedNearby = false;
      _hasNotifiedPickupArrival = false;

      try {
        HapticFeedback.mediumImpact();
        SystemSound.play(SystemSoundType.click);
      } catch (_) {}

      if (_pickupOtp == null || _pickupOtp!.isEmpty) {
        await _refetchPickupOtp(rideId);
      }
      if (mounted && _radarDialogContext != null) {
        Navigator.of(_radarDialogContext!).pop();
        _radarDialogContext = null;
      }

      final driverId = row['driver_id']?.toString();
      if (driverId != null) {
        await _loadDriverDetails(driverId);
        await _loadInitialDriverLocation(driverId);
      }

      if (!mounted) return;
      setState(() {
        _isTrackingDriver = true;
        isSearchingRide = false;
      });
      _startEtaCountdown();
      _startEtaRefresh();
      _expandSheet();

      if (activeDriverLocation != null && customerLocation != null) {
        await _fetchRouteBetweenTwoPoints(
            activeDriverLocation!, customerLocation!);
        _fitCameraToRoute();
      }

      if (mounted) {
        _showArrivalBanner(
            S.of(context).t('driver_accepted_banner'));
      }
    } else if (updatedStatus == 'in_progress') {
      _stopEtaCountdown();
      _etaRefreshTimer?.cancel();
      _etaRefreshTimer = null;
      if (mounted) {
        setState(() {
          _hasNotifiedPickupArrival = false;
          _hasNotifiedNearby = false;
          _hasNotifiedDestinationArrival = false;
          _driverEtaMinutes = null;
          _driverDistanceToPickupKm = null;
        });
        if (activeDriverLocation != null && dropoffLatLng != null) {
          await _fetchRouteBetweenTwoPoints(
              activeDriverLocation!, dropoffLatLng!);
        }
        _refitCameraSoon();
      }
    } else if (updatedStatus == 'completed') {
      _stopTrackingAndClear();
      _stopEtaCountdown();
      if (_dropoffAddress.isNotEmpty && dropoffLatLng != null) {
        FavoritePlacesService.recordRecent(
          address: _dropoffAddress,
          lat: dropoffLatLng!.latitude,
          lng: dropoffLatLng!.longitude,
        );
      }
      TripShareService.revokeAllForRide(activeRideId ?? '');
      if (mounted && _radarDialogContext != null) {
        Navigator.of(_radarDialogContext!).pop();
        _radarDialogContext = null;
      }
      if (mounted) {
        final completedFare =
            (row['fare_after_discount'] as num?)?.toDouble() ??
                (row['fare'] as num?)?.toDouble() ??
                _currentBid;
        final completedDistance = estimatedDistanceKm;
        final completedDriverId =
            _acceptedDriverDetails?['id']?.toString();
        final completedDriverName =
            '${_acceptedDriverDetails?['first_name'] ?? ''} ${_acceptedDriverDetails?['surname'] ?? ''}'
                .trim();
        setState(() {
          isSearchingRide = false;
          _isTripActive = false;
          _isTrackingDriver = false;
          _hasAcceptedModalShown = false;
          dropoffLatLng = null;
          _dropoffAddress = '';
          _acceptedDriverDetails = null;
          _pickupOtp = null;
          _otpVerified = false;
          activeRideId = null;
        });
        _collapseSheet();
        _loadRecentDestinations();
        _deferredCenterOnCustomer();
        Navigator.pushNamed(
          context,
          '/trip_complete',
          arguments: {
            'fare': completedFare,
            'distance': '${completedDistance.toStringAsFixed(1)} km',
            'rideId': rideId,
            'driverId': completedDriverId,
            'driverName': completedDriverName.isEmpty
                ? null
                : completedDriverName,
          },
        );
      }
    } else if (updatedStatus == 'returning') {
      // Parcel couldn't be delivered — driver takes it to the
      // nearest ko!ngo office. Keep tracking the driver.
      _showReturnNotice(
        returned: false,
        reason: row['return_reason']?.toString(),
        place: row['return_address']?.toString(),
      );
    } else if (updatedStatus == 'cancelled' ||
        updatedStatus == 'returned') {
      if (updatedStatus == 'returned') {
        _showReturnNotice(
          returned: true,
          reason: row['return_reason']?.toString(),
          place: row['return_address']?.toString(),
        );
      }
      _stopTrackingAndClear();
      _stopEtaCountdown();
      TripShareService.revokeAllForRide(activeRideId ?? '');
      if (mounted && _radarDialogContext != null) {
        Navigator.of(_radarDialogContext!).pop();
        _radarDialogContext = null;
      }
      if (mounted) {
        setState(() {
          isSearchingRide = false;
          _isTripActive = false;
          _isTrackingDriver = false;
          _hasAcceptedModalShown = false;
          dropoffLatLng = null;
          _dropoffAddress = '';
          _acceptedDriverDetails = null;
          _pickupOtp = null;
          _otpVerified = false;
          activeRideId = null;
        });
        _closeCounterDialog();
        _collapseSheet();
        _deferredCenterOnCustomer();
        if (updatedStatus == 'cancelled') {
          final by = (row['cancelled_by'] ?? '').toString();
          if (by == 'system' || by == 'driver' || by == 'admin') {
            ErrorUI.showSnack(
              context,
              AppError(
                title: by == 'system'
                    ? tr('No driver found')
                    : tr('Trip cancelled'),
                message: by == 'system'
                    ? tr('No driver was free just now. Please try again.')
                    : by == 'driver'
                        ? tr('Your driver cancelled the trip.')
                        : tr('ko!ngo support cancelled this trip.'),
                icon: Icons.cancel_outlined,
              ),
            );
          }
        }
      }
    }
  }

  void _showReturnNotice({
    required bool returned,
    String? reason,
    String? place,
  }) {
    if (!mounted) return;
    final t = S.of(context);
    final where = (place ?? '').trim().isEmpty ? t.t('ret_office') : place!;
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Row(
          children: [
            Icon(returned ? Icons.inventory_2 : Icons.keyboard_return,
                color: Colors.deepOrange),
            const SizedBox(width: 10),
            Expanded(
              child: Text(returned
                  ? t.t('ret_done_notif_title')
                  : t.t('ret_notif_title')),
            ),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if ((reason ?? '').trim().isNotEmpty) ...[
              Text(reason!,
                  style: const TextStyle(fontWeight: FontWeight.w600)),
              const SizedBox(height: 8),
            ],
            Text(
                '${returned ? t.t('ret_done_notif_body') : t.t('ret_notif_body')} $where'),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: Text(t.t('ok')),
          ),
        ],
      ),
    );
  }

  void _closeCounterDialog() {
    final c = _counterDialogContext;
    _counterDialogContext = null;
    if (c != null && c.mounted) Navigator.of(c).pop();
  }

  Future<void> _answerCounter(BuildContext ctx, bool accept) async {
    final id = activeRideId;
    if (id == null) return;
    try {
      if (accept) _hasAcceptedModalShown = false;
      await Supabase.instance.client.rpc('ride_respond_counter',
          params: {'p_ride': id, 'p_accept': accept});
      if (_counterDialogContext == ctx) _counterDialogContext = null;
      if (ctx.mounted) Navigator.pop(ctx);
      if (!accept && mounted) {
        ErrorUI.showSnack(
          context,
          AppError(
            title: tr('Offer declined'),
            message: tr('We\'re still looking for a driver at your price.'),
            icon: Icons.radar,
          ),
        );
      }
    } catch (e) {
      if (!mounted) return;
      ErrorUI.showSnack(context, AppError.from(e));
      // The offer is gone (taken back, or another driver accepted).
      if (e.toString().contains('kongo_counter_gone')) {
        if (_counterDialogContext == ctx) _counterDialogContext = null;
        if (ctx.mounted) Navigator.pop(ctx);
      }
    }
  }

  void _showCounterOfferFromDriver(double counter) {
    final t = S.of(context);
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (ctx) {
        _counterDialogContext = ctx;
        return AlertDialog(
        title: Row(
          children: [
            const Icon(Icons.gavel_rounded, color: EfuridePalette.accent),
            const SizedBox(width: 10),
            Text(t.t('driver_counter')),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('${t.t('your_bid')} ${CountryConfig.money(_currentBid)}'),
            const SizedBox(height: 8),
            Text('${t.t('driver_wants')} ${CountryConfig.money(counter)}',
                style: const TextStyle(
                    fontWeight: FontWeight.bold, fontSize: 18)),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => _answerCounter(ctx, false),
            child: Text(t.t('decline'),
                style: const TextStyle(color: Colors.red)),
          ),
          ElevatedButton(
            onPressed: () => _answerCounter(ctx, true),
            style: ElevatedButton.styleFrom(
                backgroundColor: EfuridePalette.onlineDeep),
            child: Text(t.t('accept_counter')),
          ),
        ],
      );
      },
    ).then((_) {
      if (_counterDialogContext != null &&
          !(_counterDialogContext!.mounted)) {
        _counterDialogContext = null;
      }
    });
  }

  void _showSearchingDialog() {
    final t = S.of(context);
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (dialogContext) {
        _radarDialogContext = dialogContext;
        return PopScope(
          canPop: false,
          child: AlertDialog(
            title: Row(
              children: [
                const Icon(Icons.radar, color: EfuridePalette.blue),
                const SizedBox(width: 10),
                Text(t.t('finding_driver')),
              ],
            ),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const CircularProgressIndicator(),
                const SizedBox(height: 16),
                Text(t.t('connecting_drivers')),
              ],
            ),
            actions: [
              TextButton(
                onPressed: () => _showCancelReasonDialog(dialogContext),
                child: Text(t.t('cancel'),
                    style: const TextStyle(color: Colors.red)),
              ),
            ],
          ),
        );
      },
    );
  }

  // ════════════════════════════════════════════════════════════
  // GREETING
  // ════════════════════════════════════════════════════════════
  String _greetingText(BuildContext ctx) {
    final hour = DateTime.now().hour;
    final s = S.of(ctx);
    if (hour < 12) return '${s.t('good_morning')},';
    if (hour < 17) return '${s.t('good_afternoon')},';
    return '${s.t('good_evening')},';
  }

  // ════════════════════════════════════════════════════════════
  // BUILD
  // ════════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    // No trip going on: the simple home (layout C). During a trip the
    // big map with the trip panel takes over, as before.
    if (!_isMapLocked) {
      return Scaffold(
        backgroundColor: EfuridePalette.cream,
        body: _idleHome(),
      );
    }
    return Scaffold(
      backgroundColor: Colors.white,
      body: Column(
        children: [
          _homeHeader(),
          Expanded(
            child: LayoutBuilder(
              builder: (context, constraints) {
                final sheetH =
                    constraints.maxHeight * _collapsedSheetFraction;
                return Stack(
                  children: [
                    Positioned.fill(child: _buildFullMap()),
                    Positioned(
                      right: 16,
                      bottom: sheetH + 16,
                      child: Material(
                        color: Colors.white,
                        shape: const CircleBorder(),
                        elevation: 3,
                        shadowColor: Colors.black.withValues(alpha: 0.15),
                        child: InkWell(
                          customBorder: const CircleBorder(),
                          onTap: () => _centerMapOnCustomer(zoom: 16.0),
                          child: const Padding(
                            padding: EdgeInsets.all(12),
                            child: Icon(Icons.my_location,
                                size: 22, color: EfuridePalette.ink),
                          ),
                        ),
                      ),
                    ),
                    DraggableScrollableSheet(
                      controller: _sheetController,
                      initialChildSize: _collapsedSheetFraction,
                      minChildSize: 0.14,
                      maxChildSize: 0.90,
                      snap: true,
                      snapSizes: const [
                        0.14,
                        _collapsedSheetFraction,
                        0.90,
                      ],
                      builder: (context, scrollController) {
                        return _bottomSheet(scrollController);
                      },
                    ),
                  ],
                );
              },
            ),
          ),
        ],
      ),
    );
  }


  // ════════════════════════════════════════════════════════════
  // HOME (layout C) — shown when no trip is running
  // ════════════════════════════════════════════════════════════
  Future<void> _loadHomeExtras() async {
    final uid = Supabase.instance.client.auth.currentUser?.id;
    if (uid == null) return;
    try {
      final favs = await FavoritePlacesService.listFavorites();
      if (mounted) setState(() => _favorites = favs);
    } catch (_) {}
    try {
      final orders = await OrderService.instance.fetchActiveOrders(uid);
      final ids = {
        for (final o in orders)
          if (o.partnerId != null && !_storeNames.containsKey(o.partnerId))
            o.partnerId!
      };
      if (ids.isNotEmpty) {
        final rows = await Supabase.instance.client
            .from('partners')
            .select('id, name')
            .inFilter('id', ids.toList());
        for (final r in rows) {
          _storeNames[r['id'].toString()] = (r['name'] ?? '').toString();
        }
      }
      if (mounted) setState(() => _activeOrders = orders);
    } catch (_) {}
    try {
      final rows = List<Map<String, dynamic>>.from(await Supabase
          .instance.client
          .from('promotions')
          .select()
          .order('created_at', ascending: false)
          .limit(10));
      final now = DateTime.now().toUtc();
      Map<String, dynamic>? pick;
      for (final p in rows) {
        if (p['is_active'] == false) continue;
        final st = (p['status'] ?? 'active').toString().toLowerCase();
        if (st == 'inactive' || st == 'expired' || st == 'disabled') continue;
        final end = DateTime.tryParse(
            '${p['expiry_date'] ?? p['expires_at'] ?? ''}');
        if (end != null && now.isAfter(end.toUtc())) continue;
        if ((p['code'] ?? '').toString().trim().isEmpty) continue;
        pick = p;
        break;
      }
      if (mounted) setState(() => _promo = pick);
    } catch (_) {}
  }

  Widget _idleHome() {
    return RefreshIndicator(
      onRefresh: () async {
        await Future.wait([
          _loadHomeExtras(),
          _loadRecentDestinations(),
          _loadUnreadCount(),
        ]);
      },
      child: GestureDetector(
        behavior: HitTestBehavior.translucent,
        // Swipe left/right to move between Transport, Marketplace, Hiring.
        onHorizontalDragEnd: (d) {
          final v = d.primaryVelocity ?? 0;
          if (v < -300 && _homeTab < 2) setState(() => _homeTab++);
          if (v > 300 && _homeTab > 0) setState(() => _homeTab--);
        },
        child: ListView(
        padding: EdgeInsets.zero,
        children: [
          _homeHeader(),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                for (final o in _activeOrders.take(2)) ...[
                  _liveOrderCard(o),
                  const SizedBox(height: 10),
                ],
                _homeTabs(),
                const SizedBox(height: 14),
                if (_homeTab == 0) ...[
                  _whereToCard(),
                  const SizedBox(height: 10),
                  _placeChips(),
                  const SizedBox(height: 14),
                  _rideBanner(),
                  const SizedBox(height: 14),
                  _transportCards(),
                  const SizedBox(height: 14),
                  _mapPreview(),
                ] else if (_homeTab == 1) ...[
                  _marketBanner(),
                  const SizedBox(height: 12),
                  _marketSearch(),
                  const SizedBox(height: 14),
                  _marketGrid(),
                ] else ...[
                  const HiringHomeSection(),
                ],
                const SizedBox(height: 14),
                _offerCard(),
              ],
            ),
          ),
        ],
      ),
      ),
    );
  }

  /// Plain header: photo, greeting, current street (tap to change),
  /// notifications.
  Widget _homeHeader() {
    final auth = context.watch<AuthProvider>();
    final first = (auth.profile?['first_name'] ?? '').toString().trim();
    final hello = _greetingText(context).replaceAll(',', '');
    final street = _pickupAddress.isNotEmpty
        ? _pickupAddress.split(',').take(2).join(',').trim()
        : (_pickupSuburb.isNotEmpty
            ? _pickupSuburb
            : S.of(context).t('detecting_location'));
    final pic = auth.avatarUrl;
    return Material(
      color: EfuridePalette.cream,
      child: SafeArea(
        bottom: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 10, 8, 10),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
          // ── ko!ngo logo + messages + notifications ──
          Row(
            children: [
              const KongoBrand(),
              const Spacer(),
              const MessagesIconButton(),
              IconButton(
                onPressed: () async {
                  await Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (_) => const NotificationsScreen()),
                  );
                  _loadUnreadCount();
                },
                icon: Badge(
                  isLabelVisible: _unreadCount > 0,
                  label: Text(_unreadCount > 9 ? '9+' : '$_unreadCount'),
                  child: const Icon(Icons.notifications_none_rounded,
                      size: 28, color: EfuridePalette.ink),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              GestureDetector(
                onTap: () =>
                    Navigator.pushNamed(context, '/customer_profile'),
                child: CircleAvatar(
                  radius: 22,
                  backgroundColor: EfuridePalette.greyBg,
                  backgroundImage:
                      (pic != null && pic.isNotEmpty) ? NetworkImage(pic) : null,
                  child: (pic == null || pic.isEmpty)
                      ? const KIcon(Icons.person, color: EfuridePalette.inkMuted)
                      : null,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(first.isEmpty ? hello : '$hello, $first',
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                            fontSize: 19,
                            fontWeight: FontWeight.w800,
                            color: EfuridePalette.ink)),
                    const SizedBox(height: 2),
                    InkWell(
                      onTap: _isMapLocked ? null : _confirmPickupPoint,
                      child: Row(
                        children: [
                          const KIcon(Icons.location_on,
                              size: 16, color: EfuridePalette.dropoff),
                          const SizedBox(width: 4),
                          Flexible(
                            child: Text(street,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(
                                    fontSize: 14.5,
                                    fontWeight: FontWeight.w700,
                                    color: EfuridePalette.ink)),
                          ),
                          const Icon(Icons.keyboard_arrow_down_rounded,
                              size: 18, color: EfuridePalette.inkMuted),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _liveOrderCard(Order o) {
    final name = o.partnerName ?? _storeNames[o.partnerId] ?? tr(o.serviceType);
    final String status;
    switch (o.status) {
      case OrderStatus.pickedUp:
      case OrderStatus.inTransit:
        status = tr('On the way');
        break;
      case OrderStatus.ready:
        status = tr('Ready for pickup');
        break;
      case OrderStatus.shopping:
      case OrderStatus.preparing:
        status = tr('Being prepared');
        break;
      default:
        status = tr('Order placed');
    }
    return Material(
      color: EfuridePalette.ink,
      borderRadius: BorderRadius.circular(16),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: () => Navigator.pushNamed(context, '/order_tracking',
            arguments: {
              'order_id': o.id,
              'service_type': o.serviceType,
              'store_name': name,
              'store_address': '',
              'dropoff': o.deliveryAddress ?? '',
              'total': o.total,
            }).then((_) => _loadHomeExtras()),
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Row(
            children: [
              Image.asset(
                o.serviceType.toLowerCase() == 'grocery'
                    ? 'assets/images/grocery.png'
                    : o.serviceType.toLowerCase() == 'pharmacy'
                        ? 'assets/images/pharmacy.png'
                        : 'assets/images/food.png',
                width: 40,
                height: 40,
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(status,
                        style: const TextStyle(
                            color: Colors.white,
                            fontSize: 16,
                            fontWeight: FontWeight.w800)),
                    Text(name,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                            color: Colors.white70, fontSize: 14)),
                  ],
                ),
              ),
              const Icon(Icons.chevron_right, color: Colors.white70),
            ],
          ),
        ),
      ),
    );
  }

  Widget _whereToCard() {
    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(16),
      elevation: 1,
      shadowColor: Colors.black.withValues(alpha: 0.08),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: _openRideFlow,
        child: Container(
          padding: const EdgeInsets.fromLTRB(14, 12, 10, 12),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: EfuridePalette.divider),
          ),
          child: Row(
            children: [
              Container(
                width: 40,
                height: 40,
                decoration: const BoxDecoration(
                    color: EfuridePalette.accent, shape: BoxShape.circle),
                child: const Icon(Icons.search,
                    color: EfuridePalette.accentInk),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Text(tr('Where to?'),
                    style: const TextStyle(
                        fontSize: 19,
                        fontWeight: FontWeight.w800,
                        color: EfuridePalette.ink)),
              ),
              Material(
                color: EfuridePalette.greyBg,
                borderRadius: BorderRadius.circular(18),
                child: InkWell(
                  borderRadius: BorderRadius.circular(18),
                  onTap: _openScheduledRides,
                  child: Padding(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 10, vertical: 8),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const KIcon(Icons.schedule, size: 16),
                        const SizedBox(width: 4),
                        Text(tr('Later'),
                            style: const TextStyle(
                                fontSize: 14, fontWeight: FontWeight.w700)),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  /// Saved places first (Home, Work, …), then recent destinations.
  Widget _placeChips() {
    Widget chip(IconData icon, String label, VoidCallback onTap) => Padding(
          padding: const EdgeInsets.only(right: 8),
          child: ActionChip(
            avatar: Icon(icon, size: 18, color: EfuridePalette.ink),
            label: Text(label,
                style: const TextStyle(
                    fontSize: 14.5, fontWeight: FontWeight.w700)),
            backgroundColor: Colors.white,
            side: const BorderSide(color: EfuridePalette.divider),
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(20)),
            onPressed: onTap,
          ),
        );

    IconData favIcon(String label) {
      final l = label.toLowerCase();
      if (l.contains('home') || l.contains('maison') || l.contains('nyumba')) {
        return Icons.home_outlined;
      }
      if (l.contains('work') || l.contains('travail') || l.contains('kazi')) {
        return Icons.work_outline;
      }
      return Icons.star_border;
    }

    final hasHome = _favorites.any((f) =>
        favIcon((f['label'] ?? f['name'] ?? '').toString()) ==
        Icons.home_outlined);

    final chips = <Widget>[
      for (final f in _favorites.take(4))
        if (f['lat'] != null && f['lng'] != null)
          chip(
            favIcon((f['label'] ?? f['name'] ?? '').toString()),
            (f['label'] ?? f['name'] ?? '').toString(),
            () => _useRecentDestination({
              'address': f['address'],
              'lat': f['lat'],
              'lng': f['lng'],
            }),
          ),
      if (!hasHome)
        chip(Icons.add_home_outlined, tr('Add home'), () async {
          await Navigator.pushNamed(context, '/favorites');
          _loadHomeExtras();
        }),
      for (final r in _recentDestinations.take(3))
        chip(Icons.history, _placeLabel(r['address'] as String),
            () => _useRecentDestination(r)),
    ];
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(children: chips),
    );
  }

  /// Ride · Parcel · Food · Grocery · Pharmacy on one line.
  Widget _serviceRow() {
    final t = S.of(context);
    return ValueListenableBuilder<AppControlState>(
      valueListenable: AppControl.state,
      builder: (context, control, _) {
        Widget item(String label, IconData icon, Color color, VoidCallback onTap) {
          return Expanded(
            child: InkWell(
              borderRadius: BorderRadius.circular(16),
              onTap: onTap,
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 4),
                child: Column(
                  children: [
                    Container(
                      width: 58,
                      height: 58,
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(18),
                        border: Border.all(color: EfuridePalette.divider),
                      ),
                      padding: const EdgeInsets.all(7),
                      child: _svcIcon(icon, color, 44),
                    ),
                    const SizedBox(height: 6),
                    FittedBox(
                      fit: BoxFit.scaleDown,
                      child: Text(label,
                          maxLines: 1,
                          style: const TextStyle(
                              fontSize: 13.5,
                              fontWeight: FontWeight.w700,
                              color: EfuridePalette.ink)),
                    ),
                  ],
                ),
              ),
            ),
          );
        }

        final items = <Widget>[
          if (control.serviceEnabled('ride'))
            item(t.t('svc_ride'), Icons.local_taxi_rounded,
                _LocalColors.svcRide, _openRideFlow),
          if (control.serviceEnabled('parcel'))
            item(t.t('svc_parcel'), Icons.inventory_2_rounded,
                _LocalColors.svcParcel, () {
              setState(() => serviceMode = 'Delivery');
              _openBookingFlow();
            }),
          if (control.serviceEnabled('food'))
            item(t.t('svc_food'), Icons.restaurant_rounded,
                _LocalColors.svcFood,
                () => _openService('/customer_food')),
          if (control.serviceEnabled('grocery'))
            item(t.t('svc_grocery'), Icons.shopping_bag_rounded,
                _LocalColors.svcGrocery,
                () => _openService('/customer_grocery')),
          if (control.serviceEnabled('pharmacy'))
            item(t.t('svc_pharmacy'), Icons.medical_services_rounded,
                _LocalColors.svcPharmacy,
                () => _openService('/customer_pharmacy')),
        ];
        if (items.isEmpty) return const SizedBox.shrink();
        return Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: items,
        );
      },
    );
  }


  // ════════════════════════════════════════════════════════════
  // TRANSPORT / MARKETPLACE TABS
  // ════════════════════════════════════════════════════════════
  int _homeTab = 0; // 0 = Transport, 1 = Marketplace, 2 = Hiring
  String _marketQuery = '';
  final TextEditingController _marketSearchCtl = TextEditingController();

  Widget _homeTabs() {
    Widget seg(int i, String pic, String label) {
      final on = _homeTab == i;
      return Expanded(
        child: GestureDetector(
          onTap: () => setState(() => _homeTab = i),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 180),
            padding: const EdgeInsets.symmetric(vertical: 13, horizontal: 2),
            decoration: BoxDecoration(
              color: on ? EfuridePalette.accent : Colors.transparent,
              borderRadius: BorderRadius.circular(14),
            ),
            child: FittedBox(
              fit: BoxFit.scaleDown,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Opacity(
                    opacity: on ? 1 : 0.7,
                    child: Image.asset(pic, width: 26, height: 26),
                  ),
                  const SizedBox(width: 6),
                  Text(label,
                      style: TextStyle(
                          fontSize: 15,
                          fontWeight: on ? FontWeight.w900 : FontWeight.w700,
                          color: on
                              ? EfuridePalette.ink
                              : EfuridePalette.inkMuted)),
                ],
              ),
            ),
          ),
        ),
      );
    }

    return Container(
      padding: const EdgeInsets.all(4),
      decoration: BoxDecoration(
        color: const Color(0xFFF1EBDD),
        borderRadius: BorderRadius.circular(18),
      ),
      child: Row(
        children: [
          seg(0, 'assets/images/ride.png', tr('Transport')),
          seg(1, 'assets/images/grocery.png', tr('Marketplace')),
          seg(2, 'assets/images/briefcase.png', tr('Hiring')),
        ],
      ),
    );
  }

  /// Picture banner: a ko!ngo taxi, "Get around with KO!NGO", Book a Ride.
  Widget _rideBanner() {
    return ValueListenableBuilder<AppControlState>(
      valueListenable: AppControl.state,
      builder: (context, control, _) {
        if (!control.serviceEnabled('ride')) return const SizedBox.shrink();
        return GestureDetector(
          onTap: _openRideFlow,
          child: ClipRRect(
            borderRadius: BorderRadius.circular(22),
            child: SizedBox(
              height: 150,
              child: Stack(
                fit: StackFit.expand,
                children: [
                  Image.asset('assets/images/banner_ride.jpg',
                      fit: BoxFit.cover,
                      alignment: Alignment.centerRight,
                      errorBuilder: (_, __, ___) =>
                          Container(color: const Color(0xFFFFF1CC))),
                  // Soft cream fade so the words stay easy to read.
                  Container(
                    decoration: const BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.centerLeft,
                        end: Alignment.centerRight,
                        stops: [0.0, 0.42, 0.75],
                        colors: [
                          Color(0xF2FAF6EE),
                          Color(0xB3FAF6EE),
                          Color(0x00FAF6EE),
                        ],
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.fromLTRB(16, 14, 16, 14),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(tr('Get around with KO!NGO'),
                            style: const TextStyle(
                                fontSize: 21,
                                fontWeight: FontWeight.w900,
                                height: 1.1,
                                color: EfuridePalette.ink)),
                        const SizedBox(height: 4),
                        Text(
                            '${tr('Fast')}  •  ${tr('Safe')}  •  ${tr('Reliable')}',
                            style: const TextStyle(
                                fontSize: 13.5,
                                fontWeight: FontWeight.w700,
                                color: EfuridePalette.ink)),
                        const SizedBox(height: 10),
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 16, vertical: 9),
                          decoration: BoxDecoration(
                            color: EfuridePalette.accent,
                            borderRadius: BorderRadius.circular(22),
                          ),
                          child: Text('${tr('Book a Ride')}  ›',
                              style: const TextStyle(
                                  fontSize: 14.5,
                                  fontWeight: FontWeight.w900,
                                  color: EfuridePalette.ink)),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  /// Picture banner for the Marketplace tab.
  Widget _marketBanner() {
    return ClipRRect(
      borderRadius: BorderRadius.circular(22),
      child: SizedBox(
        height: 140,
        child: Stack(
          fit: StackFit.expand,
          children: [
            Image.asset('assets/images/banner_market.jpg',
                fit: BoxFit.cover,
                alignment: Alignment.centerRight,
                errorBuilder: (_, __, ___) =>
                    Container(color: const Color(0xFFFFF1CC))),
            Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.centerLeft,
                  end: Alignment.centerRight,
                  stops: [0.0, 0.5, 0.7],
                  colors: [
                    Color(0xCCFFF4D6),
                    Color(0x80FFF4D6),
                    Color(0x00FFF4D6),
                  ],
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 14, 130, 14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(tr('Shop from a wide range'),
                      style: const TextStyle(
                          fontSize: 21,
                          fontWeight: FontWeight.w900,
                          height: 1.1,
                          color: EfuridePalette.ink)),
                  const SizedBox(height: 6),
                  Text(
                      tr('Groceries, food, pharmacy, fashion and more, brought to your door'),
                      maxLines: 3,
                      style: const TextStyle(
                          fontSize: 13.5,
                          fontWeight: FontWeight.w600,
                          height: 1.25,
                          color: EfuridePalette.ink)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  /// Ride and Parcel as two big cards.
  Widget _transportCards() {
    final t = S.of(context);
    return ValueListenableBuilder<AppControlState>(
      valueListenable: AppControl.state,
      builder: (context, control, _) {
        Widget card(String pic, String title, String sub, VoidCallback onTap) {
          return Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: Material(
              color: Colors.white,
              borderRadius: BorderRadius.circular(18),
              child: InkWell(
                borderRadius: BorderRadius.circular(18),
                onTap: onTap,
                child: Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(18),
                    border:
                        Border.all(color: EfuridePalette.accent, width: 1.8),
                  ),
                  child: Row(
                    children: [
                      Container(
                        width: 64,
                        height: 64,
                        padding: const EdgeInsets.all(6),
                        decoration: BoxDecoration(
                            color: const Color(0xFFFFF1CC),
                            borderRadius: BorderRadius.circular(18)),
                        child: Image.asset(pic, fit: BoxFit.contain),
                      ),
                      const SizedBox(width: 14),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(title,
                                style: const TextStyle(
                                    fontSize: 20,
                                    fontWeight: FontWeight.w900,
                                    color: EfuridePalette.ink)),
                            const SizedBox(height: 2),
                            Text(sub,
                                style: const TextStyle(
                                    fontSize: 14,
                                    color: EfuridePalette.inkMuted)),
                          ],
                        ),
                      ),
                      const Icon(Icons.chevron_right,
                          color: EfuridePalette.inkMuted),
                    ],
                  ),
                ),
              ),
            ),
          );
        }

        return Column(
          children: [
            if (control.serviceEnabled('ride'))
              card('assets/images/ride.png', t.t('svc_ride'),
                  tr('Book a ride in minutes · Fast & reliable'),
                  _openRideFlow),
            if (control.serviceEnabled('parcel'))
              card('assets/images/parcel.png', t.t('svc_parcel'),
                  tr('Send a package · Track delivery'), () {
                setState(() => serviceMode = 'Delivery');
                _openBookingFlow();
              }),
          ],
        );
      },
    );
  }

  // Shops found by name or by a product they sell.
  List<Partner> _marketHits = [];
  bool _marketSearching = false;
  Timer? _marketDebounce;

  void _runMarketSearch(String q) {
    _marketDebounce?.cancel();
    if (q.length < 2) {
      setState(() {
        _marketHits = [];
        _marketSearching = false;
      });
      return;
    }
    setState(() => _marketSearching = true);
    _marketDebounce = Timer(const Duration(milliseconds: 350), () async {
      final found = await OrderService.instance.searchPartners(q);
      if (!mounted || _marketQuery != q) return;
      setState(() {
        _marketHits = found;
        _marketSearching = false;
      });
    });
  }

  void _openFoundShop(Partner p) {
    final cat = p.category.toLowerCase();
    if (cat == 'restaurant' || cat == 'food') {
      Navigator.pushNamed(context, '/customer_restaurant', arguments: {
        'id': p.id,
        'name': p.name,
        'address': p.address ?? '',
      });
    } else {
      Navigator.pushNamed(context, '/customer_store', arguments: {
        'id': p.id,
        'name': p.name,
        'address': p.address ?? '',
        'service_type': cat == 'pharmacy' ? 'Pharmacy' : 'Grocery',
      });
    }
  }

  Widget _marketShopResults() {
    if (_marketSearching && _marketHits.isEmpty) {
      return const Padding(
        padding: EdgeInsets.all(20),
        child: Center(child: CircularProgressIndicator()),
      );
    }
    if (_marketHits.isEmpty) return const SizedBox.shrink();
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(top: 14, bottom: 6),
          child: Text(tr('Shops'),
              style:
                  const TextStyle(fontSize: 17, fontWeight: FontWeight.w900)),
        ),
        for (final p in _marketHits)
          Card(
            margin: const EdgeInsets.only(bottom: 8),
            elevation: 0,
            color: Colors.white,
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(14)),
            child: ListTile(
              onTap: () => _openFoundShop(p),
              leading: CircleAvatar(
                backgroundColor: const Color(0xFFFFF1CC),
                backgroundImage:
                    (p.logoUrl ?? '').isNotEmpty ? NetworkImage(p.logoUrl!) : null,
                child: (p.logoUrl ?? '').isEmpty
                    ? const Icon(Icons.storefront_outlined,
                        color: EfuridePalette.ink)
                    : null,
              ),
              title: Text(p.name,
                  style: const TextStyle(fontWeight: FontWeight.w800)),
              subtitle: Text(
                  [p.category, if ((p.address ?? '').isNotEmpty) p.address!]
                      .join(' · '),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis),
              trailing: Text(p.isOpen ? tr('Open') : tr('Closed'),
                  style: TextStyle(
                      fontWeight: FontWeight.w800,
                      color: p.isOpen
                          ? const Color(0xFF16803C)
                          : EfuridePalette.inkMuted)),
            ),
          ),
      ],
    );
  }

  Widget _marketSearch() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: EfuridePalette.divider),
      ),
      child: Row(
        children: [
          const Icon(Icons.search, color: EfuridePalette.ink),
          const SizedBox(width: 10),
          Expanded(
            child: TextField(
              controller: _marketSearchCtl,
              onChanged: (v) {
                setState(() => _marketQuery = v.trim());
                _runMarketSearch(v.trim());
              },
              decoration: InputDecoration(
                hintText: tr('Search shops and categories'),
                border: InputBorder.none,
                hintStyle: const TextStyle(color: EfuridePalette.inkMuted),
              ),
              style: const TextStyle(fontSize: 16),
            ),
          ),
          VoiceMicButton(onText: (t) {
            _marketSearchCtl.text = t;
            _marketSearchCtl.selection =
                TextSelection.collapsed(offset: t.length);
            setState(() => _marketQuery = t.trim());
            _runMarketSearch(t.trim());
          }),
        ],
      ),
    );
  }

  /// The shop categories. Food, groceries and pharmacy keep their own
  /// screens; the rest share one list screen.
  Widget _marketGrid() {
    return ValueListenableBuilder<AppControlState>(
      valueListenable: AppControl.state,
      builder: (context, control, _) {
        final t = S.of(context);
        final cats = <_MarketCat>[
          if (control.serviceEnabled('grocery'))
            _MarketCat(tr('Groceries'), Icons.shopping_basket_outlined,
                () => _openService('/customer_grocery'),
                pic: 'assets/images/grocery.png', bg: const Color(0xFFDDF6E7)),
          if (control.serviceEnabled('food'))
            _MarketCat(t.t('svc_food'), Icons.restaurant_outlined,
                () => _openService('/customer_food'),
                pic: 'assets/images/food.png', bg: const Color(0xFFFFE6D0)),
          if (control.serviceEnabled('pharmacy'))
            _MarketCat(t.t('svc_pharmacy'), Icons.add_box_outlined,
                () => _openService('/customer_pharmacy'),
                pic: 'assets/images/pharmacy.png', bg: const Color(0xFFFFE0E0)),
          _MarketCat.other(tr('Fashion'), Icons.checkroom_outlined, 'fashion',
              _openCategory),
          _MarketCat.other(tr('Electronics'), Icons.smartphone_outlined,
              'electronics', _openCategory),
          _MarketCat.other(tr('Home & Living'), Icons.weekend_outlined,
              'home_living', _openCategory),
          _MarketCat.other(
              tr('Beauty'), Icons.face_retouching_natural, 'beauty',
              _openCategory),
          _MarketCat.other(tr('Butchery'), Icons.kebab_dining_outlined,
              'butchery', _openCategory),
          _MarketCat.other(tr('Bakery'), Icons.bakery_dining_outlined,
              'bakery', _openCategory),
          _MarketCat.other(tr('General Retail'), Icons.shopping_bag_outlined,
              'general_retail', _openCategory),
          _MarketCat.other(tr('Other'), Icons.more_horiz, 'other',
              _openCategory),
        ];
        final q = _marketQuery.toLowerCase();
        final shown = q.isEmpty
            ? cats
            : cats.where((c) => searchMatches(q, [c.label])).toList();
        if (shown.isEmpty) {
          if (_marketHits.isNotEmpty || _marketSearching) {
            return _marketShopResults();
          }
          return Padding(
            padding: const EdgeInsets.all(24),
            child: Center(
              child: Text(tr('Nothing found. Try another word.'),
                  style: const TextStyle(color: EfuridePalette.inkMuted)),
            ),
          );
        }
        final grid = GridView.count(
          crossAxisCount: 3,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          mainAxisSpacing: 10,
          crossAxisSpacing: 10,
          childAspectRatio: 0.92,
          children: [
            for (final c in shown)
              PictureTile(
                label: c.label,
                asset: c.asset,
                tint: c.tint,
                imageSize: 62,
                onTap: () => c.open(this),
              ),
          ],
        );
        if (q.isEmpty) return grid;
        return Column(children: [grid, _marketShopResults()]);
      },
    );
  }

  void _openCategory(String key, String title) {
    Navigator.pushNamed(context, '/customer_category',
        arguments: {'category': key, 'title': title}).then((_) {
      if (mounted) _loadHomeExtras();
    });
  }

  /// Small map: where you are and how many cars are around. Tap = book.
  Widget _mapPreview() {
    final cars = _nearbyDrivers.length;
    return ClipRRect(
      borderRadius: BorderRadius.circular(16),
      child: SizedBox(
        height: 170,
        child: Stack(
          children: [
            Positioned.fill(child: IgnorePointer(child: _buildFullMap())),
            Positioned.fill(
              child: Material(
                color: Colors.transparent,
                child: InkWell(onTap: _openRideFlow),
              ),
            ),
            Positioned(
              left: 10,
              bottom: 10,
              child: Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(12),
                  boxShadow: [
                    BoxShadow(
                        color: Colors.black.withValues(alpha: 0.12),
                        blurRadius: 6),
                  ],
                ),
                child: Text(
                  cars > 0
                      ? tr('Nearby drivers · {0} nearby', ['$cars'])
                      : tr('You are here'),
                  style: const TextStyle(
                      fontSize: 13.5, fontWeight: FontWeight.w700),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _offerCard() {
    final p = _promo;
    String title;
    String sub;
    if (p != null) {
      final v = (p['discount_value'] as num?)?.toDouble() ?? 0;
      final percent =
          (p['discount_type'] ?? 'percent').toString().toLowerCase() ==
              'percent';
      final off = percent
          ? tr('{0}% off', [v.toStringAsFixed(v % 1 == 0 ? 0 : 1)])
          : tr('{0} off', [CountryConfig.money(v)]);
      title = '$off · ${(p['code'] ?? '').toString().toUpperCase()}';
      sub = tr('Tap to copy the code');
    } else {
      title = tr('Offers and promo codes');
      sub = tr('See what is on today');
    }
    return Material(
      color: const Color(0xFFFEF3C7),
      borderRadius: BorderRadius.circular(16),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: () async {
          if (p != null) {
            final code = (p['code'] ?? '').toString().toUpperCase();
            await Clipboard.setData(ClipboardData(text: code));
            if (!mounted) return;
            ScaffoldMessenger.of(context).showSnackBar(SnackBar(
              behavior: SnackBarBehavior.floating,
              content: Text(
                  tr('Code {0} copied. Paste it when you book or check out.',
                      [code])),
            ));
          } else {
            Navigator.pushNamed(context, '/promotions');
          }
        },
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Row(
            children: [
              const KIcon(Icons.local_offer_outlined,
                  color: Color(0xFF92400E)),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title,
                        style: const TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w800,
                            color: EfuridePalette.ink)),
                    Text(sub,
                        style: const TextStyle(
                            fontSize: 14, color: Color(0xFF92400E))),
                  ],
                ),
              ),
              IconButton(
                onPressed: () => Navigator.pushNamed(context, '/promotions'),
                icon: const Icon(Icons.chevron_right),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ════════════════════════════════════════════════════════════
  // HEADER
  // ════════════════════════════════════════════════════════════
  Widget _header() {
    final t = S.of(context);
    final auth = context.watch<AuthProvider>();

    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          colors: [EfuridePalette.blue, EfuridePalette.blueDeep],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
      ),
      child: SafeArea(
        bottom: false,
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 10, 16, 14),
              child: Row(
                children: [
                  // ── LEOPARD LOGO (No text) ──
                  Container(
                    width: 40,
                    height: 40,
                    decoration: const BoxDecoration(
                      color: Colors.white,
                      shape: BoxShape.circle,
                    ),
                    child: ClipOval(
                      child: Image.asset(
                        'assets/images/leopard_logo.png',
                        fit: BoxFit.cover,
                        errorBuilder: (_, __, ___) => const Icon(
                            Icons.pets, // Fallback icon
                            color: EfuridePalette.blue,
                            size: 22),
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // ── BRAND NAME: ko!ngo ──
                      RichText(
                        text: const TextSpan(
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 18,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 1.4,
                            height: 1.05,
                          ),
                          children: [
                            TextSpan(text: 'ko'),
                            TextSpan(
                              text: '!',
                              style: TextStyle(color: EfuridePalette.accent),
                            ),
                            TextSpan(text: 'ngo'),
                          ],
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        t.t('role_customer'),
                        style: const TextStyle(
                          color: Colors.white70,
                          fontSize: 13.5,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ],
                  ),
                  const Spacer(),
                  _headerIcon(
                    Icons.search_rounded,
                    onTap: _openRideFlow,
                  ),
                  const SizedBox(width: 12),
                  _headerIcon(
                    Icons.notifications_none_rounded,
                    badge: _unreadCount > 0
                        ? (_unreadCount > 9 ? '9+' : '$_unreadCount')
                        : null,
                    onTap: () async {
                      await Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => const NotificationsScreen(),
                        ),
                      );
                      _loadUnreadCount();
                    },
                  ),
                ],
              ),
            ),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 18),
              decoration: const BoxDecoration(
                color: EfuridePalette.navy,
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(24),
                  topRight: Radius.circular(24),
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // ── FLAGS ROW (Same Level) ──
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      // Congo Brazzaville Flag
                      Container(
                        width: 32,
                        height: 20,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(4),
                          image: const DecorationImage(
                            image: AssetImage('assets/flags/congo.png'),
                            fit: BoxFit.cover,
                          ),
                        ),
                      ),
                      // DRC Flag
                      Container(
                        width: 32,
                        height: 20,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(4),
                          image: const DecorationImage(
                            image: AssetImage('assets/flags/drc.png'),
                            fit: BoxFit.cover,
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  // ── GREETING & WALLET (photo on the right) ──
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              _greetingText(context),
                              style: const TextStyle(
                                color: Colors.white70,
                                fontSize: 14,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                            const SizedBox(height: 2),
                            Text(
                              '${auth.displayName} 👋',
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 22,
                                fontWeight: FontWeight.w900,
                                letterSpacing: -0.3,
                                height: 1.1,
                              ),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                            const SizedBox(height: 8),
                            _walletPill(auth),
                          ],
                        ),
                      ),
                      const SizedBox(width: 12),
                      GestureDetector(
                        onTap: () => Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => const CustomerAccountScreen(),
                          ),
                        ),
                        child: Container(
                          width: 56,
                          height: 56,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            border: Border.all(
                              color: Colors.white.withValues(alpha: 0.6),
                              width: 2,
                            ),
                          ),
                          child: ClipOval(
                            child: (auth.avatarUrl?.isNotEmpty == true)
                                ? Image.network(
                                    auth.avatarUrl!,
                                    width: 56,
                                    height: 56,
                                    fit: BoxFit.cover,
                                    errorBuilder: (_, __, ___) => const KIcon(
                                        Icons.person,
                                        color: Colors.white,
                                        size: 30),
                                  )
                                : const KIcon(Icons.person,
                                    color: Colors.white, size: 30),
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  _landmarkChip(),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _headerIcon(IconData icon,
      {VoidCallback? onTap, String? badge}) {
    return GestureDetector(
      onTap: onTap,
      child: Stack(
        clipBehavior: Clip.none,
        children: [
          Icon(icon, color: Colors.white, size: 24),
          if (badge != null)
            Positioned(
              right: -4,
              top: -3,
              child: Container(
                padding: const EdgeInsets.all(4),
                constraints:
                    const BoxConstraints(minWidth: 18, minHeight: 18),
                decoration: const BoxDecoration(
                  color: EfuridePalette.dropoff,
                  shape: BoxShape.circle,
                ),
                child: Center(
                  child: Text(
                    badge,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 12,
                      fontWeight: FontWeight.w900,
                      height: 1.0,
                    ),
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _walletPill(AuthProvider auth) {
    return GestureDetector(
      onTap: () => Navigator.pushNamed(context, '/wallet'),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(
          color: EfuridePalette.accent.withValues(alpha: 0.18),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: EfuridePalette.accent.withValues(alpha: 0.6),
            width: 1.2,
          ),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            const KIcon(Icons.account_balance_wallet_outlined,
                size: 14, color: EfuridePalette.accent),
            const SizedBox(width: 6),
            Text(
              CountryConfig.money(auth.walletBalance),
              style: const TextStyle(
                color: EfuridePalette.accent,
                fontSize: 13.5,
                fontWeight: FontWeight.w900,
                letterSpacing: 0.2,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _landmarkChip() {
    final label = _pickupSuburb.isNotEmpty
        ? _pickupSuburb
        : _pickupAddress.split(',').first.trim();
    final display =
        label.isEmpty ? S.of(context).t('detecting_location') : label;

    return InkWell(
      onTap: _isMapLocked ? null : _confirmPickupPoint,
      borderRadius: BorderRadius.circular(20),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(
          color: Colors.white.withValues(alpha: 0.10),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: Colors.white.withValues(alpha: 0.15),
          ),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            const KIcon(Icons.location_on,
                size: 14, color: EfuridePalette.accent),
            const SizedBox(width: 8),
            Flexible(
              child: Text(
                display,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 14,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
            const SizedBox(width: 6),
            const Icon(Icons.keyboard_arrow_down_rounded,
                size: 16, color: Colors.white70),
          ],
        ),
      ),
    );
  }

  // ════════════════════════════════════════════════════════════
  // SERVICE GRID
  // ════════════════════════════════════════════════════════════
  Widget _serviceGrid() {
    final t = S.of(context);
    // Services an admin has paused are hidden (App Control).
    return ValueListenableBuilder<AppControlState>(
      valueListenable: AppControl.state,
      builder: (context, control, _) {
        final tiles = <Widget>[
          if (control.serviceEnabled('ride'))
            _serviceTile(
              label: t.t('svc_ride'),
              subtitle: t.t('svc_ride_sub'),
              icon: Icons.local_taxi_rounded,
              color: _LocalColors.svcRide,
              onTap: _openRideFlow,
            ),
          if (control.serviceEnabled('food'))
            _serviceTile(
              label: t.t('svc_food'),
              subtitle: t.t('svc_food_sub'),
              icon: Icons.restaurant_rounded,
              color: _LocalColors.svcFood,
              onTap: () => _openService('/customer_food'),
            ),
          if (control.serviceEnabled('grocery'))
            _serviceTile(
              label: t.t('svc_grocery'),
              subtitle: t.t('svc_grocery_sub'),
              icon: Icons.shopping_bag_rounded,
              color: _LocalColors.svcGrocery,
              onTap: () => _openService('/customer_grocery'),
            ),
          if (control.serviceEnabled('pharmacy'))
            _serviceTile(
              label: t.t('svc_pharmacy'),
              subtitle: t.t('svc_pharmacy_sub'),
              icon: Icons.medical_services_rounded,
              color: _LocalColors.svcPharmacy,
              onTap: () => _openService('/customer_pharmacy'),
            ),
          if (control.serviceEnabled('parcel'))
            _serviceTile(
              label: t.t('svc_parcel'),
              subtitle: t.t('svc_parcel_sub'),
              icon: Icons.inventory_2_rounded,
              color: _LocalColors.svcParcel,
              // Same screen as rides, opened on the Parcel tab.
              onTap: () {
                setState(() => serviceMode = 'Delivery');
                _openBookingFlow();
              },
            ),
        ];
        if (tiles.isEmpty) return const SizedBox.shrink();

        // Rows of three; short rows are padded so tiles keep their width.
        final rows = <Widget>[];
        for (var i = 0; i < tiles.length; i += 3) {
          final row = tiles.sublist(i, (i + 3).clamp(0, tiles.length));
          final cells = <Widget>[];
          for (var j = 0; j < 3; j++) {
            if (j > 0) cells.add(const SizedBox(width: 10));
            cells.add(j < row.length
                ? row[j]
                : const Expanded(child: SizedBox.shrink()));
          }
          if (rows.isNotEmpty) rows.add(const SizedBox(height: 10));
          rows.add(Row(children: cells));
        }

        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.only(left: 4, bottom: 10),
              child: Text(
                t.t('our_services'),
                style: const TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w800,
                  color: EfuridePalette.ink,
                ),
              ),
            ),
            ...rows,
          ],
        );
      },
    );
  }

  Widget _serviceTile({
    required String label,
    required String subtitle,
    required IconData icon,
    required Color color,
    String? badge,
    required VoidCallback onTap,
  }) {
    return Expanded(
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(16),
        child: Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
                color: color.withValues(alpha: 0.30), width: 1.4),
            boxShadow: [
              BoxShadow(
                color: color.withValues(alpha: 0.08),
                blurRadius: 10,
                offset: const Offset(0, 3),
              ),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    width: 40,
                    height: 40,
                    decoration: BoxDecoration(
                      color: color.withValues(alpha: 0.15),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    padding: const EdgeInsets.all(4),
                    child: _svcIcon(icon, color, 32),
                  ),
                  const Spacer(),
                  if (badge != null)
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(
                        color: color,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Text(
                        badge,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 12,
                          fontWeight: FontWeight.w900,
                          height: 1.2,
                        ),
                      ),
                    ),
                ],
              ),
              const SizedBox(height: 10),
              // One line each, shrunk to fit — big text sizes used to
              // break words in half ("Restauran / ts").
              FittedBox(
                fit: BoxFit.scaleDown,
                alignment: Alignment.centerLeft,
                child: Text(
                  label,
                  maxLines: 1,
                  style: const TextStyle(
                    fontSize: 14.5,
                    fontWeight: FontWeight.w900,
                    color: EfuridePalette.ink,
                    letterSpacing: -0.2,
                  ),
                ),
              ),
              const SizedBox(height: 2),
              FittedBox(
                fit: BoxFit.scaleDown,
                alignment: Alignment.centerLeft,
                child: Text(
                  subtitle,
                  maxLines: 1,
                  style: const TextStyle(
                    fontSize: 12.5,
                    color: EfuridePalette.inkMuted,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _openService(String route) {
    Navigator.pushNamed(context, route).then((_) {
      if (mounted) _loadHomeExtras(); // a new order shows on top
    });
  }

  // ════════════════════════════════════════════════════════════
  // WHERE TO BAR
  // ════════════════════════════════════════════════════════════
  Widget _whereToBar() {
    final t = S.of(context);
    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(16),
      child: InkWell(
        onTap: _openRideFlow,
        borderRadius: BorderRadius.circular(16),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 15),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: EfuridePalette.divider, width: 1.2),
          ),
          child: Row(
            children: [
              Container(
                width: 36,
                height: 36,
                decoration: const BoxDecoration(
                  color: EfuridePalette.ink,
                  shape: BoxShape.circle,
                ),
                child: const Icon(Icons.search, size: 18, color: Colors.white),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Text(
                  t.t('where_going'),
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                    color: EfuridePalette.ink,
                  ),
                ),
              ),
              const Icon(Icons.arrow_forward_ios,
                  size: 14, color: EfuridePalette.inkMuted),
            ],
          ),
        ),
      ),
    );
  }

  // ════════════════════════════════════════════════════════════
  // MAP
  // ════════════════════════════════════════════════════════════
  Widget _buildFullMap() {
    final showRealRoute = routePoints.isNotEmpty &&
        _currentRideStatus != 'completed' &&
        _currentRideStatus != 'cancelled';
    final showDashedPlaceholder = !showRealRoute &&
        activeDriverLocation != null &&
        customerLocation != null &&
        _isTrackingDriver;
    final initialCenter = customerLocation ?? const LatLng(-33.9249, 18.4241);

    final markers = <gmaps.Marker>{
      if (customerLocation != null)
        gmaps.Marker(
          markerId: const gmaps.MarkerId('me_dot'),
          position: gmaps.LatLng(
            customerLocation!.latitude,
            customerLocation!.longitude,
          ),
          anchor: const Offset(0.5, 0.5),
          flat: true,
          zIndex: 10,
          icon: _meDotIcon ??
              gmaps.BitmapDescriptor.defaultMarkerWithHue(
                  gmaps.BitmapDescriptor.hueAzure),
        ),
      if (dropoffLatLng != null)
        gmaps.Marker(
          markerId: const gmaps.MarkerId('dropoff'),
          position:
              gmaps.LatLng(dropoffLatLng!.latitude, dropoffLatLng!.longitude),
          icon: gmaps.BitmapDescriptor.defaultMarkerWithHue(
              gmaps.BitmapDescriptor.hueRed),
        ),
      if (activeDriverLocation != null &&
          _isTrackingDriver &&
          _currentRideStatus != 'completed' &&
          _currentRideStatus != 'cancelled')
        gmaps.Marker(
          markerId: const gmaps.MarkerId('active_driver'),
          position: gmaps.LatLng(
              activeDriverLocation!.latitude, activeDriverLocation!.longitude),
          rotation: _driverHeading,
          anchor: const Offset(0.5, 0.5),
          flat: true,
          zIndex: 5,
          icon: _carIcon ??
              gmaps.BitmapDescriptor.defaultMarkerWithHue(
                  gmaps.BitmapDescriptor.hueGreen),
        ),
      if (!_isTrackingDriver)
        ..._nearbyDrivers
            .where((d) => d['lat'] != null && d['lng'] != null)
            .map((d) {
          final lat = (d['lat'] as num).toDouble();
          final lng = (d['lng'] as num).toDouble();
          final id = d['id'].toString();
          return gmaps.Marker(
            markerId: gmaps.MarkerId('nearby_$id'),
            position: gmaps.LatLng(lat, lng),
            anchor: const Offset(0.5, 0.5),
            flat: true,
            rotation: _driverHeadings[id] ?? 0.0,
            zIndex: 1,
            icon: _carIcon ??
                gmaps.BitmapDescriptor.defaultMarkerWithHue(
                    gmaps.BitmapDescriptor.hueAzure),
          );
        }),
    };

    final polylines = <gmaps.Polyline>{
      if (showRealRoute)
        gmaps.Polyline(
          polylineId: const gmaps.PolylineId('route'),
          points: routePoints
              .map((p) => gmaps.LatLng(p.latitude, p.longitude))
              .toList(),
          width: 5,
          color: _currentRideStatus == 'in_progress'
              ? _LocalColors.success
              : EfuridePalette.blue,
        ),
      if (showDashedPlaceholder)
        gmaps.Polyline(
          polylineId: const gmaps.PolylineId('placeholder'),
          points: [
            gmaps.LatLng(activeDriverLocation!.latitude,
                activeDriverLocation!.longitude),
            gmaps.LatLng(
                customerLocation!.latitude, customerLocation!.longitude),
          ],
          width: 4,
          color: EfuridePalette.blue.withValues(alpha: 0.5),
          patterns: [
            gmaps.PatternItem.dot,
            gmaps.PatternItem.gap(8),
          ],
        ),
    };

    final circles = <gmaps.Circle>{
      if (customerLocation != null)
        gmaps.Circle(
          circleId: const gmaps.CircleId('me_halo_outer'),
          center: gmaps.LatLng(
            customerLocation!.latitude,
            customerLocation!.longitude,
          ),
          radius: 40,
          fillColor: _LocalColors.meBlue.withValues(alpha: 0.10),
          strokeWidth: 0,
          zIndex: 1,
        ),
      if (customerLocation != null)
        gmaps.Circle(
          circleId: const gmaps.CircleId('me_halo_inner'),
          center: gmaps.LatLng(
            customerLocation!.latitude,
            customerLocation!.longitude,
          ),
          radius: 18,
          fillColor: _LocalColors.meBlue.withValues(alpha: 0.16),
          strokeWidth: 0,
          zIndex: 2,
        ),
    };

    return gmaps.GoogleMap(
      initialCameraPosition: gmaps.CameraPosition(
        target: gmaps.LatLng(initialCenter.latitude, initialCenter.longitude),
        zoom: 16.0,
      ),
      onMapCreated: (controller) {
        _mapController = controller;
        // The map is rebuilt when the home switches between the simple
        // layout and the trip layout: put the camera back in place.
        _lastCenteredOn = null;
        if (_isMapLocked) {
          _refitCameraSoon();
        } else if (customerLocation != null) {
          _deferredCenterOnCustomer();
        }
        if (_pendingCenterOnCustomer && customerLocation != null) {
          _pendingCenterOnCustomer = false;
          _lastCenteredOn = customerLocation;
          controller.animateCamera(
            gmaps.CameraUpdate.newLatLngZoom(
              gmaps.LatLng(
                customerLocation!.latitude,
                customerLocation!.longitude,
              ),
              16.0,
            ),
          );
        }
      },
      onTap: null,
      onCameraMove: null,
      onCameraIdle: null,
      // ── MAP IS NOW COMPLETELY LOCKED ──
      scrollGesturesEnabled: false,
      zoomGesturesEnabled: false,
      rotateGesturesEnabled: false,
      tiltGesturesEnabled: false,
      myLocationButtonEnabled: false,
      zoomControlsEnabled: false,
      markers: markers,
      polylines: polylines,
      circles: circles,
    );
  }

  // ════════════════════════════════════════════════════════════
  // BOTTOM SHEET
  // ════════════════════════════════════════════════════════════
  Widget _bottomSheet(ScrollController scrollController) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.08),
            blurRadius: 16,
            offset: const Offset(0, -4),
          ),
        ],
      ),
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.only(top: 10, bottom: 6),
            child: Container(
              width: 36,
              height: 4,
              decoration: BoxDecoration(
                color: Colors.grey.shade300,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
          ),
          Expanded(
            child: ListView(
              controller: scrollController,
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
              children: [
                if (_isTripActive && activeRideId != null) ...[
                  const SizedBox(height: 4),
                  _activeTripStrip(),
                  const SizedBox(height: 14),
                ],
                if (_showOtpInSheet) ...[
                  _buildOtpCard(),
                  const SizedBox(height: 14),
                ],
                if (!_isTripActive) ...[
                  _serviceGrid(),
                  const SizedBox(height: 16),
                  _whereToBar(),
                  const SizedBox(height: 20),
                  _savedPlacesSection(),
                  if (_recentDestinations.isNotEmpty) ...[
                    const SizedBox(height: 20),
                    _recentSection(),
                  ],
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }

  bool get _showOtpInSheet =>
      _currentRideStatus == 'accepted' &&
      _pickupOtp != null &&
      _pickupOtp!.isNotEmpty &&
      !_otpVerified;

  // ════════════════════════════════════════════════════════════
  // ACTIVE TRIP STRIP
  // ════════════════════════════════════════════════════════════
  Widget _activeTripStrip() {
    final t = S.of(context);
    final driver = _acceptedDriverDetails ?? {};
    final name =
        '${driver['first_name'] ?? t.t('role_driver')} ${driver['surname'] ?? ''}'
            .trim();

    String status;
    Color statusColor = Colors.white70;
    if (_currentRideStatus == 'accepted') {
      if (_driverEtaMinutes != null && _driverDistanceToPickupKm != null) {
        status =
            '${t.t('arriving_in')} $_driverEtaMinutes ${t.t('min')} · ${_formatDistance(_driverDistanceToPickupKm!)}';
      } else if (activeDriverLocation != null) {
        status = t.t('calculating_arrival');
      } else {
        status = t.t('locating_driver');
      }
    } else if (_currentRideStatus == 'in_progress') {
      status = t.t('on_way_destination');
      statusColor = const Color(0xFF6EE7A8);
    } else {
      status = t.t('finding_driver');
    }

    final pic = driver['profile_picture_url']?.toString();
    final vehicle =
        '${driver['vehicle_make'] ?? ''} ${driver['vehicle_model'] ?? ''}'
            .trim();
    final plate = (driver['vehicle_plate'] ?? '').toString().trim();

    return Material(
      color: EfuridePalette.ink,
      borderRadius: BorderRadius.circular(16),
      child: InkWell(
        onTap: () => _showActiveTripModal({}),
        borderRadius: BorderRadius.circular(16),
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  CircleAvatar(
                    radius: 24,
                    backgroundColor: Colors.white,
                    backgroundImage: (pic != null && pic.isNotEmpty)
                        ? NetworkImage(pic)
                        : null,
                    child: (pic == null || pic.isEmpty)
                        ? const KIcon(Icons.person,
                            color: EfuridePalette.ink, size: 24)
                        : null,
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          name.isEmpty ? t.t('your_driver') : name,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                            fontSize: 15,
                            height: 1.15,
                          ),
                        ),
                        const SizedBox(height: 3),
                        Text(
                          status,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            color: statusColor,
                            fontSize: 13.5,
                            height: 1.25,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 6),
                  IconButton(
                    icon: const Icon(Icons.call, color: Colors.white, size: 22),
                    onPressed: _callDriver,
                    padding: EdgeInsets.zero,
                    constraints:
                        const BoxConstraints(minWidth: 36, minHeight: 36),
                  ),
                  IconButton(
                    icon: AppImage(
                      AppImages.chatBubble,
                      size: 22,
                      tint: Colors.white,
                      fallbackIcon: Icons.chat_bubble_outline,
                    ),
                    onPressed: () {
                      Navigator.pushNamed(context, '/chat',
                          arguments: {'rideId': activeRideId});
                    },
                    padding: EdgeInsets.zero,
                    constraints:
                        const BoxConstraints(minWidth: 36, minHeight: 36),
                  ),
                  const Icon(Icons.chevron_right, color: Colors.white70),
                ],
              ),
              if (vehicle.isNotEmpty || plate.isNotEmpty) ...[
                const SizedBox(height: 10),
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                  decoration: BoxDecoration(
                    color: Colors.white.withValues(alpha: 0.08),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const KIcon(Icons.directions_car,
                          size: 14, color: Colors.white70),
                      const SizedBox(width: 6),
                      Flexible(
                        child: Text(
                          [vehicle, plate]
                              .where((s) => s.isNotEmpty)
                              .join(' • '),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 13.5,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }

  // ════════════════════════════════════════════════════════════
  // SAVED PLACES
  // ════════════════════════════════════════════════════════════
  Widget _savedPlacesSection() {
    final t = S.of(context);
    if (_recentDestinations.isEmpty) {
      return Column(
        children: [
          _quickRow(
            icon: Icons.home_outlined,
            label: t.t('add_home'),
            onTap: _addHomeAddress,
            iconBg: EfuridePalette.blue,
          ),
          const SizedBox(height: 4),
          _quickRow(
            icon: Icons.work_outline,
            label: t.t('add_work'),
            onTap: _addWorkAddress,
            iconBg: EfuridePalette.ink,
          ),
        ],
      );
    }
    return Column(
      children: [
        for (final r in _recentDestinations.take(2))
          Padding(
            padding: const EdgeInsets.only(bottom: 4),
            child: _quickRow(
              icon: Icons.history,
              label: (r['address'] as String).split(',').first.trim(),
              subtitle: (r['address'] as String)
                  .split(',')
                  .skip(1)
                  .join(',')
                  .trim(),
              onTap: () => _useRecentDestination(r),
            ),
          ),
      ],
    );
  }

  Widget _recentSection() {
    final t = S.of(context);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(left: 8, bottom: 8),
          child: Text(
            t.t('recent'),
            style: const TextStyle(
              fontSize: 13.5,
              fontWeight: FontWeight.w700,
              color: EfuridePalette.inkMuted,
            ),
          ),
        ),
        for (final r in _recentDestinations.skip(2))
          Padding(
            padding: const EdgeInsets.only(bottom: 4),
            child: _quickRow(
              icon: Icons.access_time,
              label: (r['address'] as String).split(',').first.trim(),
              subtitle: (r['address'] as String)
                  .split(',')
                  .skip(1)
                  .join(',')
                  .trim(),
              onTap: () => _useRecentDestination(r),
            ),
          ),
      ],
    );
  }

  Widget _quickRow({
    required IconData icon,
    required String label,
    String? subtitle,
    Color? iconBg,
    required VoidCallback onTap,
  }) {
    final hasBg = iconBg != null;
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(14),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 10),
        child: Row(
          children: [
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: iconBg ?? EfuridePalette.greyBg,
                shape: BoxShape.circle,
              ),
              child: Icon(icon,
                  size: 19,
                  color: hasBg ? Colors.white : EfuridePalette.ink),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    label,
                    style: const TextStyle(
                      fontSize: 14.5,
                      fontWeight: FontWeight.w600,
                      color: EfuridePalette.ink,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  if (subtitle != null && subtitle.isNotEmpty)
                    Padding(
                      padding: const EdgeInsets.only(top: 2),
                      child: Text(
                        subtitle,
                        style: const TextStyle(
                          fontSize: 13.5,
                          color: EfuridePalette.inkMuted,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                ],
              ),
            ),
            const Icon(Icons.north_east,
                size: 16, color: EfuridePalette.inkMuted),
          ],
        ),
      ),
    );
  }

  Future<void> _addHomeAddress() async {
    if (!mounted) return;
    final t = S.of(context);
    ErrorUI.showSnack(
      context,
      AppError(
        title: t.t('coming_soon'),
        message: t.t('saved_places_coming_soon'),
        icon: Icons.home_outlined,
      ),
    );
  }

  Future<void> _addWorkAddress() async {
    if (!mounted) return;
    final t = S.of(context);
    ErrorUI.showSnack(
      context,
      AppError(
        title: t.t('coming_soon'),
        message: t.t('saved_places_coming_soon'),
        icon: Icons.work_outline,
      ),
    );
  }

  Future<void> _useRecentDestination(Map<String, dynamic> r) async {
    final lat = r['lat'];
    final lng = r['lng'];
    if (lat == null || lng == null) return;
    if (customerLocation == null) return;
    setState(() {
      dropoffLatLng = LatLng((lat as num).toDouble(), (lng as num).toDouble());
      _dropoffAddress = (r['address'] ?? '').toString();
    });
    await _openBookingFlowWithDestination(
      address: _dropoffAddress,
      lat: dropoffLatLng!.latitude,
      lng: dropoffLatLng!.longitude,
    );
  }

  Future<void> _openBookingFlowWithDestination({
    required String address,
    required double lat,
    required double lng,
  }) async {
    if (_isTripActive || isSearchingRide || activeRideId != null) return;
    if (customerLocation == null) return;
    try {
      await _confirmPickupPoint();
      if (!mounted) return;
      final target = LatLng(lat, lng);
      final info = await _getRouteInfo(customerLocation!, target);
      final km = (info?['distance_km'] as num?)?.toDouble() ??
          (_distanceInMeters(customerLocation!, target) * 1.3 / 1000);
      final etaMin = (info?['duration_min'] as int?) ??
          ((km / 30) * 60).round();
      if (!mounted) return;
      setState(() {
        estimatedDistanceKm = km;
        _recomputeFare();
      });
      final bookingResult = await Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => BookingSummaryScreen(
            vehicle: selectedVehicleName,
            pickup: _pickupAddress,
            dropoff: address,
            fare: estimatedFare,
            distance: km,
            etaMinutes: etaMin,
            pickupLatLng: gmaps.LatLng(
              customerLocation!.latitude,
              customerLocation!.longitude,
            ),
            dropoffLatLng: gmaps.LatLng(lat, lng),
            serviceType: serviceMode,
          ),
        ),
      );
      if (bookingResult == null || !mounted) return;
      _handleBookingResult(bookingResult);
    } catch (e) {
      if (!mounted) return;
      ErrorUI.showSnack(context, AppError.from(e));
    }
  }

  // ════════════════════════════════════════════════════════════
  // ACTIVE TRIP MODAL
  // ════════════════════════════════════════════════════════════
  void _showActiveTripModal(Map<String, dynamic> rideData) {
    final t = S.of(context);
    final driver = _acceptedDriverDetails ?? {};
    final driverName =
        '${driver['first_name'] ?? t.t('your')} ${driver['surname'] ?? t.t('role_driver')}'
            .trim();
    final vehicle =
        '${driver['vehicle_make'] ?? ''} ${driver['vehicle_model'] ?? ''}'
            .trim();
    final plate = driver['vehicle_plate'] ?? '—';
    final rating = (driver['average_rating'] ?? 5.0).toDouble();
    final driverPic = driver['profile_picture_url']?.toString();

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (context) {
        return Padding(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(t.t('driver_en_route'),
                  style: const TextStyle(
                      fontSize: 18, fontWeight: FontWeight.bold)),
              const SizedBox(height: 16),
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                    color: Colors.grey.shade50,
                    borderRadius: BorderRadius.circular(14)),
                child: Row(
                  children: [
                    CircleAvatar(
                      radius: 32,
                      backgroundColor: EfuridePalette.blue,
                      backgroundImage:
                          (driverPic != null && driverPic.isNotEmpty)
                              ? NetworkImage(driverPic)
                              : null,
                      child: (driverPic == null || driverPic.isEmpty)
                          ? const KIcon(Icons.person,
                              color: Colors.white, size: 32)
                          : null,
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(children: [
                            Flexible(
                              child: Text(driverName,
                                  style: const TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 16)),
                            ),
                            if (driver['verified'] == true) ...[
                              const SizedBox(width: 5),
                              const VerifiedBadge(),
                            ],
                          ]),
                          const SizedBox(height: 4),
                          Row(children: [
                            const Icon(Icons.star,
                                color: Colors.amber, size: 16),
                            const SizedBox(width: 4),
                            Text(rating.toStringAsFixed(1),
                                style: const TextStyle(
                                    fontSize: 14,
                                    fontWeight: FontWeight.w600)),
                          ]),
                          if (vehicle.isNotEmpty) ...[
                            const SizedBox(height: 6),
                            Text('$vehicle • $plate',
                                style: const TextStyle(
                                    fontSize: 13.5,
                                    fontWeight: FontWeight.w500)),
                          ],
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 16),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: () {
                        Navigator.pop(context);
                        _callDriver();
                      },
                      icon: const Icon(Icons.call),
                      label: Text(tr('Call')),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: ElevatedButton.icon(
                      style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFFF2B705),
                          foregroundColor: const Color(0xFF0B1220),
                          padding: const EdgeInsets.symmetric(vertical: 14)),
                      onPressed: () {
                        Navigator.pop(context);
                        Navigator.pushNamed(context, '/chat',
                            arguments: {'rideId': activeRideId});
                      },
                      icon: const Icon(Icons.chat),
                      label: Text(t.t('chat')),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: () {
                        Navigator.pop(context);
                        Navigator.pushNamed(
                          context,
                          '/sos',
                          arguments: {
                            'role': 'customer',
                            'rideId': activeRideId,
                          },
                        );
                      },
                      icon: const Icon(Icons.sos, color: Colors.red),
                      label: Text(t.t('sos'),
                          style: const TextStyle(color: Colors.red)),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              TextButton.icon(
                onPressed: () async {
                  Navigator.pop(context);
                  await _shareLiveTrip();
                },
                icon: const KIcon(Icons.ios_share,
                    color: EfuridePalette.blue),
                label: Text(t.t('share_live_trip'),
                    style: const TextStyle(color: EfuridePalette.blue)),
              ),
              // Customers can cancel only before pickup; once the trip
              // has started only the driver can end it.
              if (_currentRideStatus != 'in_progress')
                TextButton.icon(
                  onPressed: () async {
                    Navigator.pop(context);
                    await _cancelActiveTrip();
                  },
                  icon: const Icon(Icons.cancel_outlined, color: Colors.red),
                  label: Text(t.t('cancel_trip'),
                      style: const TextStyle(color: Colors.red)),
                )
              else
                Padding(
                  padding: const EdgeInsets.only(top: 6),
                  child: Text(
                    tr('Your trip has started. Only the driver can end it now.'),
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                        fontSize: 14, color: EfuridePalette.inkMuted),
                  ),
                ),
            ],
          ),
        );
      },
    );
  }

  // ════════════════════════════════════════════════════════════
  // OTP CARD
  // ════════════════════════════════════════════════════════════
  Widget _buildOtpCard() {
    final t = S.of(context);
    if (_pickupOtp == null || _pickupOtp!.isEmpty) {
      return const SizedBox.shrink();
    }
    final digits = _pickupOtp!.split('');
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: EfuridePalette.accent.withValues(alpha: 0.5),
          width: 1.5,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(6),
                decoration: BoxDecoration(
                  color: EfuridePalette.accent.withValues(alpha: 0.15),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: AppImage(
                  AppImages.shieldCheck,
                  size: 18,
                  tint: EfuridePalette.accent,
                  fallbackIcon: Icons.shield_outlined,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  t.t('pickup_verification_code'),
                  style: const TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 14,
                    color: EfuridePalette.ink,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            t.t('otp_hint'),
            style: const TextStyle(
                fontSize: 13, color: EfuridePalette.inkMuted),
          ),
          const SizedBox(height: 14),
          Center(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: digits.map((d) {
                return Container(
                  margin: const EdgeInsets.symmetric(horizontal: 3),
                  width: 38,
                  height: 52,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: EfuridePalette.greyBg,
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(
                      color: EfuridePalette.accent,
                      width: 1.6,
                    ),
                  ),
                  child: Text(
                    d,
                    style: const TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                      color: EfuridePalette.accent,
                      letterSpacing: 1.5,
                    ),
                  ),
                );
              }).toList(),
            ),
          ),
        ],
      ),
    );
  }
}

// ════════════════════════════════════════════════════════════════
// PICKUP CONFIRM SHEET
// ════════════════════════════════════════════════════════════════
class _PickupConfirmSheet extends StatefulWidget {
  final String initialAddress;
  final LatLng? initialLocation;
  final LatLng? pickupLatLng;

  const _PickupConfirmSheet({
    required this.initialAddress,
    required this.initialLocation,
    required this.pickupLatLng,
  });

  @override
  State<_PickupConfirmSheet> createState() => _PickupConfirmSheetState();
}

class _PickupConfirmSheetState extends State<_PickupConfirmSheet> {
  final TextEditingController _searchCtrl = TextEditingController();
  final Debouncer _debouncer = Debouncer(milliseconds: 300);
  final FocusNode _focus = FocusNode();

  List<PlacePrediction> _suggestions = [];
  bool _searching = false;
  int _requestId = 0;

  LatLng? _selectedLatLng;
  String _selectedAddress = '';

  @override
  void initState() {
    super.initState();
    _searchCtrl.text = widget.initialAddress;
    _selectedAddress = widget.initialAddress;
    _selectedLatLng = widget.initialLocation;
  }

  @override
  void dispose() {
    _debouncer.dispose();
    _searchCtrl.dispose();
    _focus.dispose();
    super.dispose();
  }

  void _onSearch(String query) {
    final trimmed = query.trim();
    if (trimmed.isEmpty) {
      _requestId++;
      setState(() {
        _suggestions = [];
        _searching = false;
      });
      return;
    }
    setState(() => _searching = true);
    final rid = ++_requestId;

    _debouncer.debounce(() async {
      try {
        // The location only makes nearby places come first; search
        // still works without it (e.g. GPS off, or in a browser).
        final origin = widget.pickupLatLng ??
            widget.initialLocation ??
            _selectedLatLng ??
            const LatLng(-15.0, 25.0); // middle of the countries we serve
        final preds = await GoogleMapsService.autocomplete(
          query: trimmed,
          origin: origin,
          radiusMeters: 20000,
          // No GPS: keep results in the customer's own country.
          // Only places in the country the customer is in.
          countryCode: CountryConfig.servedIso,
        );
        if (rid != _requestId || !mounted) return;
        setState(() {
          _suggestions = preds;
          _searching = false;
        });
      } catch (e) {
        debugPrint('pickup autocomplete failed: $e');
        if (rid == _requestId && mounted) {
          setState(() => _searching = false);
        }
      }
    });
  }

  bool _locating = false;

  /// Use where the phone is right now as the pickup.
  Future<void> _useMyLocation() async {
    setState(() => _locating = true);
    try {
      var perm = await Geolocator.checkPermission();
      if (perm == LocationPermission.denied) {
        perm = await Geolocator.requestPermission();
      }
      if (perm == LocationPermission.denied ||
          perm == LocationPermission.deniedForever) {
        throw Exception('permission');
      }
      final pos = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.medium,
        timeLimit: const Duration(seconds: 20),
      );
      final point = LatLng(pos.latitude, pos.longitude);
      final place = await GoogleMapsService.reverseGeocode(point);
      if (!mounted) return;
      setState(() {
        _selectedLatLng = point;
        _selectedAddress = place?.displayAddress ??
            '${pos.latitude.toStringAsFixed(5)}, ${pos.longitude.toStringAsFixed(5)}';
        _searchCtrl.text = place?.shortLabel ?? _selectedAddress;
        _suggestions = [];
      });
    } catch (_) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text(tr(
            'Couldn\'t get your location. Allow location for ko!ngo, or type your street above.')),
      ));
    } finally {
      if (mounted) setState(() => _locating = false);
    }
  }

  Future<void> _onPick(PlacePrediction p) async {
    setState(() => _searching = true);
    final details = await GoogleMapsService.details(p.placeId);
    if (!mounted) return;
    setState(() => _searching = false);
    if (details == null) return;
    setState(() {
      _selectedAddress = details.formattedAddress.isNotEmpty
          ? details.formattedAddress
          : p.fullDescription;
      _selectedLatLng = details.latLng;
      _searchCtrl.text = details.shortLabel;
      _suggestions = [];
    });
    _focus.unfocus();
  }

  @override
  Widget build(BuildContext context) {
    final t = S.of(context);
    final bottom = MediaQuery.of(context).viewInsets.bottom;
    return Padding(
      padding:
          EdgeInsets.only(left: 16, right: 16, top: 20, bottom: bottom + 20),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Center(
            child: Container(
              width: 50,
              height: 5,
              decoration: BoxDecoration(
                color: Colors.grey[300],
                borderRadius: BorderRadius.circular(10),
              ),
            ),
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              const Icon(Icons.my_location, color: EfuridePalette.pickup),
              const SizedBox(width: 8),
              Text(t.t('confirm_pickup'),
                  style: const TextStyle(
                      fontSize: 16, fontWeight: FontWeight.bold)),
            ],
          ),
          const SizedBox(height: 6),
          Text(
            t.t('search_street_hint'),
            style: const TextStyle(
                fontSize: 13.5, color: EfuridePalette.inkMuted),
          ),
          const SizedBox(height: 14),
          TextField(
            controller: _searchCtrl,
            focusNode: _focus,
            onChanged: _onSearch,
            decoration: InputDecoration(
              hintText: t.t('search_street_example'),
              border: const OutlineInputBorder(),
              prefixIcon: const Icon(Icons.search),
              suffixIcon: _searchCtrl.text.isNotEmpty
                  ? IconButton(
                      icon: const Icon(Icons.close),
                      onPressed: () {
                        setState(() {
                          _searchCtrl.clear();
                          _suggestions = [];
                        });
                      },
                    )
                  : null,
            ),
          ),
          const SizedBox(height: 6),
          Align(
            alignment: Alignment.centerLeft,
            child: TextButton.icon(
              onPressed: _locating ? null : _useMyLocation,
              icon: _locating
                  ? const SizedBox(
                      width: 16,
                      height: 16,
                      child: CircularProgressIndicator(strokeWidth: 2))
                  : const Icon(Icons.my_location,
                      size: 18, color: EfuridePalette.pickup),
              label: Text(tr('Use my current location'),
                  style: const TextStyle(
                      color: EfuridePalette.ink,
                      fontWeight: FontWeight.w700)),
            ),
          ),
          if (_searching || _suggestions.isNotEmpty) ...[
            const SizedBox(height: 8),
            Container(
              constraints: const BoxConstraints(maxHeight: 260),
              decoration: BoxDecoration(
                color: Colors.grey.shade50,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: Colors.grey.shade300),
              ),
              child: _searching && _suggestions.isEmpty
                  ? const Padding(
                      padding: EdgeInsets.all(20),
                      child: Center(
                        child: SizedBox(
                          width: 22,
                          height: 22,
                          child: CircularProgressIndicator(strokeWidth: 2),
                        ),
                      ),
                    )
                  : ListView.separated(
                      shrinkWrap: true,
                      itemCount: _suggestions.length,
                      separatorBuilder: (_, __) => const Divider(height: 1),
                      itemBuilder: (_, i) {
                        final p = _suggestions[i];
                        return ListTile(
                          leading: const KIcon(Icons.location_on,
                              color: Colors.grey, size: 20),
                          title: Text(
                            p.primaryText,
                            style: const TextStyle(fontSize: 14),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                          subtitle: p.secondaryText.isEmpty
                              ? null
                              : Text(
                                  p.secondaryText,
                                  style: const TextStyle(fontSize: 13),
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                ),
                          onTap: () => _onPick(p),
                        );
                      },
                    ),
            ),
          ],
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(
                child: OutlinedButton(
                  onPressed: () => Navigator.pop(context),
                  child: Text(t.t('cancel')),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFFF2B705),
                    foregroundColor: const Color(0xFF0B1220),
                  ),
                  onPressed: () {
                    if (_selectedAddress.trim().isEmpty ||
                        _selectedLatLng == null) {
                      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                        content: Text(tr(
                            'Pick an address from the list, or tap "Use my current location".')),
                      ));
                      return;
                    }
                    Navigator.pop(context, {
                      'address': _selectedAddress.trim(),
                      'lat': _selectedLatLng?.latitude,
                      'lng': _selectedLatLng?.longitude,
                    });
                  },
                  child: Text(t.t('confirm_pickup_point'),
                      style: const TextStyle(
                          color: const Color(0xFF0B1220),
                          fontWeight: FontWeight.bold)),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

/// One tile in the Marketplace grid.
class _MarketCat {
  final String label;
  final IconData icon;
  final String? _pic;
  final Color? _bg;
  String get asset => _pic ?? _marketAsset(key ?? '');
  Color get tint => _bg ?? _marketTint(key ?? '');
  final VoidCallback? _go;
  final String? key;
  final void Function(String key, String title)? _openOther;

  _MarketCat(this.label, this.icon, VoidCallback go,
      {String? pic, Color? bg})
      : _go = go,
        key = null,
        _pic = pic,
        _bg = bg,
        _openOther = null;

  _MarketCat.other(this.label, this.icon, String this.key,
      void Function(String key, String title) open)
      : _go = null,
        _pic = null,
        _bg = null,
        _openOther = open;

  void open(Object _) {
    final go = _go;
    if (go != null) {
      go();
    } else {
      _openOther?.call(key!, label);
    }
  }
}


// Pictures for the Marketplace tiles live in widgets/picture_tile.dart.
String _marketAsset(String k) => marketPictureAsset(k);
Color _marketTint(String k) => marketPictureTint(k);

/// Service pictures: the small icon is swapped for a picture when one exists.
String? _svcPic(IconData icon) {
  if (icon == Icons.local_taxi_rounded) return 'assets/images/ride.png';
  if (icon == Icons.inventory_2_rounded) return 'assets/images/parcel.png';
  if (icon == Icons.restaurant_rounded) return 'assets/images/food.png';
  if (icon == Icons.shopping_bag_rounded) return 'assets/images/grocery.png';
  if (icon == Icons.medical_services_rounded) {
    return 'assets/images/pharmacy.png';
  }
  return null;
}

Widget _svcIcon(IconData icon, Color color, double size) {
  final pic = _svcPic(icon);
  if (pic == null) return Icon(icon, color: color, size: size);
  return Image.asset(pic, width: size, height: size, fit: BoxFit.contain);
}
