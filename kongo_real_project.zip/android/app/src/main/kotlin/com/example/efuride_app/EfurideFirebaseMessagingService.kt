// android/app/src/main/kotlin/com/example/efuride_app/EfurideFirebaseMessagingService.kt
package com.example.efuride_app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

/**
 * Receives data-only FCM pushes (from supabase/functions/send-push) and
 * turns ride-request pushes into a full-screen-intent notification so the
 * device rings and wakes even when the screen is locked.
 */
class EfurideFirebaseMessagingService : FirebaseMessagingService() {

    companion object {
        private const val TAG = "EfurideFCM"
        private const val RIDE_CHANNEL_ID = "incoming_ride_channel"
        private const val RIDE_CHANNEL_NAME = "Incoming ride requests"
        private const val NOTIFICATION_ID = 9001
    }

    override fun onNewToken(token: String) {
        super.onNewToken(token)
        // Handled in Dart via FirebaseMessaging.instance.onTokenRefresh.
        Log.d(TAG, "New FCM token: $token")
    }

    override fun onMessageReceived(remoteMessage: RemoteMessage) {
        super.onMessageReceived(remoteMessage)

        val data = remoteMessage.data
        Log.d(TAG, "onMessageReceived data=$data")

        // Only ride-request pushes get the full-screen treatment.
        val rideId = data["ride_id"] ?: data["rideId"]
        val type = data["type"] ?: ""
        val isRideRequest = rideId != null &&
            (type.isEmpty() ||
             type.contains("ride", ignoreCase = true) ||
             type.contains("trip", ignoreCase = true))

        if (!isRideRequest) {
            // Fall back to a normal notification for other push types.
            showSimpleNotification(
                title = data["title"] ?: "eFuride",
                body = data["body"] ?: ""
            )
            return
        }

        showRideRequestNotification(
            rideId = rideId!!,
            title = data["title"] ?: "New ride request",
            body = data["body"] ?: "Tap to view"
        )
    }

    // ── Ride request → full-screen-intent notification ─────────────
    private fun showRideRequestNotification(rideId: String, title: String, body: String) {
        createRideChannel()

        val launchIntent = packageManager.getLaunchIntentForPackage(packageName)?.apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra("ride_id", rideId)
            putExtra("from_push", true)
        } ?: return

        val contentPending = PendingIntent.getActivity(
            this,
            rideId.hashCode(),
            launchIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        // Full-screen intent launches straight into MainActivity over the lock screen.
        val fullScreenPending = PendingIntent.getActivity(
            this,
            rideId.hashCode() + 1,
            launchIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val builder = NotificationCompat.Builder(this, RIDE_CHANNEL_ID)
            .setSmallIcon(applicationInfo.icon)
            .setContentTitle(title)
            .setContentText(body)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_CALL)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setAutoCancel(true)
            .setOngoing(true)
            .setContentIntent(contentPending)
            .setFullScreenIntent(fullScreenPending, true)
            .setSound(
                RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
            )

        try {
            NotificationManagerCompat.from(this)
                .notify(NOTIFICATION_ID, builder.build())
        } catch (e: SecurityException) {
            Log.e(TAG, "POST_NOTIFICATIONS permission missing: ${e.message}")
        }
    }

    private fun showSimpleNotification(title: String, body: String) {
        createRideChannel()
        val launchIntent = packageManager.getLaunchIntentForPackage(packageName)
        val contentPending = PendingIntent.getActivity(
            this,
            0,
            launchIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val builder = NotificationCompat.Builder(this, RIDE_CHANNEL_ID)
            .setSmallIcon(applicationInfo.icon)
            .setContentTitle(title)
            .setContentText(body)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .setContentIntent(contentPending)

        try {
            NotificationManagerCompat.from(this).notify(
                NOTIFICATION_ID + 1, builder.build()
            )
        } catch (e: SecurityException) {
            Log.e(TAG, "POST_NOTIFICATIONS permission missing: ${e.message}")
        }
    }

    private fun createRideChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (manager.getNotificationChannel(RIDE_CHANNEL_ID) != null) return

        val channel = NotificationChannel(
            RIDE_CHANNEL_ID,
            RIDE_CHANNEL_NAME,
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = "Full-screen alerts for incoming ride requests"
            lockscreenVisibility = NotificationCompat.VISIBILITY_PUBLIC
            setShowBadge(true)
            enableVibration(true)
            setSound(
                RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE),
                AudioAttributes.Builder()
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .setUsage(AudioAttributes.USAGE_NOTIFICATION_RINGTONE)
                    .build()
            )
        }
        manager.createNotificationChannel(channel)
    }
}
