package com.example.efuride_app

import android.app.Application
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.embedding.engine.dart.DartExecutor
import io.flutter.plugins.GeneratedPluginRegistrant

class MainApplication : Application() {
    override fun onCreate() {
        super.onCreate()

        // Create a FlutterEngine to run background plugins
        val flutterEngine = FlutterEngine(this)
        
        // Register all plugins (including flutter_local_notifications)
        // for the background isolate used by FCM.
        GeneratedPluginRegistrant.registerWith(flutterEngine)
        
        // Start the background Dart isolate
        flutterEngine.dartExecutor.executeDartEntrypoint(
            DartExecutor.DartEntrypoint.createDefault()
        )
    }
}
