// supabase/functions/google-maps/index.ts
//
// ko!ngo · Google Maps proxy
//
// One server-side entry point for every Google call the apps make:
//   action = "autocomplete" | "details" | "reverse" | "route"
//
// Why a proxy:
//   • The app's Maps key is Android-restricted, which Google rejects for
//     Places / Geocoding / Routes web-service calls.
//   • Browsers (Flutter web) block direct calls to those APIs (CORS).
//   • The server key never ships inside the app.
//
// Uses the current Google APIs:
//   Places API (New)  – places:autocomplete, places/{id}
//   Geocoding API     – reverse geocoding
//   Routes API        – directions/v2:computeRoutes (with turn steps)
//
// Deploy:
//   supabase secrets set GOOGLE_MAPS_SERVER_KEY=<server key>
//   supabase functions deploy google-maps
//
// The server key needs these APIs enabled in Google Cloud:
//   Places API (New), Geocoding API, Routes API.
// Restrict it by API (not by app), since it is only used server-side.

const KEY = Deno.env.get("GOOGLE_MAPS_SERVER_KEY") ?? "";

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

function json(body: unknown, status = 200): Response {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...CORS, "Content-Type": "application/json" },
  });
}

type Body = {
  action?: string;
  input?: string;
  lat?: number;
  lng?: number;
  radius?: number;
  region?: string; // ISO-3166 alpha-2, e.g. "cg"
  language?: string; // e.g. "fr"
  session?: string;
  place_id?: string;
  origin?: { lat: number; lng: number };
  destination?: { lat: number; lng: number };
  mode?: string; // "drive" | "two_wheeler"
};

// ── Autocomplete ─────────────────────────────────────────────────
async function autocomplete(b: Body) {
  const input = (b.input ?? "").trim();
  if (!input) return { predictions: [] };

  const req: Record<string, unknown> = {
    input,
    languageCode: b.language || "en",
    sessionToken: b.session,
  };
  if (b.lat != null && b.lng != null) {
    req.locationBias = {
      circle: {
        center: { latitude: b.lat, longitude: b.lng },
        radius: Math.min(Math.max(b.radius ?? 40000, 1000), 50000),
      },
    };
    req.origin = { latitude: b.lat, longitude: b.lng };
  }
  if (b.region) req.includedRegionCodes = [b.region.toLowerCase()];

  const r = await fetch("https://places.googleapis.com/v1/places:autocomplete", {
    method: "POST",
    headers: { "Content-Type": "application/json", "X-Goog-Api-Key": KEY },
    body: JSON.stringify(req),
  });
  const data = await r.json();
  if (!r.ok) throw new Error(data?.error?.message ?? `autocomplete ${r.status}`);

  // deno-lint-ignore no-explicit-any
  const predictions = (data.suggestions ?? []).flatMap((s: any) => {
    const p = s.placePrediction;
    if (!p) return [];
    return [{
      place_id: p.placeId,
      primary: p.structuredFormat?.mainText?.text ?? p.text?.text ?? "",
      secondary: p.structuredFormat?.secondaryText?.text ?? "",
      description: p.text?.text ?? "",
      types: p.types ?? [],
      distance_m: p.distanceMeters ?? null,
    }];
  });
  return { predictions };
}

// ── Place details ────────────────────────────────────────────────
async function details(b: Body) {
  if (!b.place_id) throw new Error("place_id required");
  const url = new URL(
    `https://places.googleapis.com/v1/places/${encodeURIComponent(b.place_id)}`,
  );
  if (b.session) url.searchParams.set("sessionToken", b.session);
  url.searchParams.set("languageCode", b.language || "en");

  const r = await fetch(url, {
    headers: {
      "X-Goog-Api-Key": KEY,
      "X-Goog-FieldMask":
        "id,location,formattedAddress,displayName,addressComponents",
    },
  });
  const p = await r.json();
  if (!r.ok) throw new Error(p?.error?.message ?? `details ${r.status}`);
  return {
    place_id: p.id,
    lat: p.location?.latitude,
    lng: p.location?.longitude,
    formatted_address: p.formattedAddress ?? "",
    name: p.displayName?.text ?? null,
    components: componentsFromNew(p.addressComponents ?? []),
  };
}

// deno-lint-ignore no-explicit-any
function componentsFromNew(list: any[]) {
  const out: Record<string, string> = {};
  for (const c of list) {
    for (const t of c.types ?? []) {
      if (!out[t]) out[t] = c.longText ?? "";
    }
  }
  return out;
}

// ── Reverse geocode ──────────────────────────────────────────────
async function reverse(b: Body) {
  if (b.lat == null || b.lng == null) throw new Error("lat/lng required");
  const url = new URL("https://maps.googleapis.com/maps/api/geocode/json");
  url.searchParams.set("latlng", `${b.lat},${b.lng}`);
  url.searchParams.set("language", b.language || "en");
  url.searchParams.set("key", KEY);
  const r = await fetch(url);
  const data = await r.json();
  if (data.status !== "OK" && data.status !== "ZERO_RESULTS") {
    throw new Error(data.error_message ?? `reverse ${data.status}`);
  }
  const first = (data.results ?? [])[0];
  if (!first) return { formatted_address: "", components: {} };
  const components: Record<string, string> = {};
  for (const c of first.address_components ?? []) {
    for (const t of c.types ?? []) {
      if (!components[t]) components[t] = c.long_name ?? "";
    }
  }
  return {
    place_id: first.place_id,
    formatted_address: first.formatted_address ?? "",
    lat: first.geometry?.location?.lat ?? b.lat,
    lng: first.geometry?.location?.lng ?? b.lng,
    components,
  };
}

// ── Route (with turn-by-turn steps) ──────────────────────────────
async function route(b: Body) {
  if (!b.origin || !b.destination) throw new Error("origin/destination required");
  const req = {
    origin: { location: { latLng: { latitude: b.origin.lat, longitude: b.origin.lng } } },
    destination: {
      location: { latLng: { latitude: b.destination.lat, longitude: b.destination.lng } },
    },
    travelMode: b.mode === "two_wheeler" ? "TWO_WHEELER" : "DRIVE",
    routingPreference: "TRAFFIC_AWARE",
    languageCode: b.language || "en",
    units: "METRIC",
  };
  const r = await fetch(
    "https://routes.googleapis.com/directions/v2:computeRoutes",
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-Goog-Api-Key": KEY,
        "X-Goog-FieldMask": [
          "routes.distanceMeters",
          "routes.duration",
          "routes.polyline.encodedPolyline",
          "routes.legs.steps.distanceMeters",
          "routes.legs.steps.staticDuration",
          "routes.legs.steps.navigationInstruction",
          "routes.legs.steps.endLocation",
        ].join(","),
      },
      body: JSON.stringify(req),
    },
  );
  const data = await r.json();
  if (!r.ok) throw new Error(data?.error?.message ?? `route ${r.status}`);
  const rt = (data.routes ?? [])[0];
  if (!rt) return { found: false };

  // deno-lint-ignore no-explicit-any
  const steps = (rt.legs ?? []).flatMap((l: any) => l.steps ?? []).map((s: any) => ({
    distance_m: s.distanceMeters ?? 0,
    duration_s: parseInt(String(s.staticDuration ?? "0").replace("s", "")) || 0,
    instruction: s.navigationInstruction?.instructions ?? "",
    maneuver: s.navigationInstruction?.maneuver ?? "",
    end_lat: s.endLocation?.latLng?.latitude ?? null,
    end_lng: s.endLocation?.latLng?.longitude ?? null,
  }));

  return {
    found: true,
    distance_m: rt.distanceMeters ?? 0,
    duration_s: parseInt(String(rt.duration ?? "0").replace("s", "")) || 0,
    polyline: rt.polyline?.encodedPolyline ?? "",
    steps,
  };
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: CORS });
  if (!KEY) return json({ error: "GOOGLE_MAPS_SERVER_KEY not set" }, 500);

  let b: Body;
  try {
    b = await req.json();
  } catch {
    return json({ error: "invalid JSON" }, 400);
  }

  try {
    switch (b.action) {
      case "autocomplete":
        return json(await autocomplete(b));
      case "details":
        return json(await details(b));
      case "reverse":
        return json(await reverse(b));
      case "route":
        return json(await route(b));
      default:
        return json({ error: `unknown action ${b.action}` }, 400);
    }
  } catch (e) {
    return json({ error: (e as Error).message }, 502);
  }
});
