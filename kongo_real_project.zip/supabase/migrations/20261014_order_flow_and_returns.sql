-- ════════════════════════════════════════════════════════════════════
-- ko!ngo · Order flow + delivery returns
-- 2026-10-14
--
-- Flow this enables:
--   Customer orders from a merchant's products
--   → a shopper takes the order (claim_order) and buys it at the store
--   → shopper seals it and requests a driver (request_order_delivery)
--   → a driver delivers it (a rides row linked by order_id)
--   → if the customer can't receive it, the driver returns it to the
--     nearest company office (status 'returning' → 'returned').
--
-- Safe to run more than once. Run it in the Supabase SQL editor.
-- ════════════════════════════════════════════════════════════════════


-- ── 0. Helper: allow new status values whether the column is an enum
--       or a text column with a CHECK constraint. Lives in pg_temp, so
--       it disappears when the session ends.
create or replace function pg_temp.kongo_allow_values(
  p_table text, p_column text, p_values text[]
) returns void language plpgsql as $$
declare
  v_type text;
  v_udt  text;
  v_val  text;
  v_con  record;
  v_all  text[];
begin
  select data_type, udt_name into v_type, v_udt
  from information_schema.columns
  where table_schema = 'public' and table_name = p_table and column_name = p_column;

  if v_type is null then
    raise notice 'kongo: %.% not found, skipped', p_table, p_column;
    return;
  end if;

  if v_type = 'USER-DEFINED' then
    -- Postgres enum: add any missing labels.
    foreach v_val in array p_values loop
      execute format('alter type public.%I add value if not exists %L', v_udt, v_val);
    end loop;
  else
    -- Text column: replace any CHECK constraint that lists statuses.
    for v_con in
      select c.conname, pg_get_constraintdef(c.oid) as def
      from pg_constraint c
      join pg_class t on t.oid = c.conrelid
      join pg_namespace n on n.oid = t.relnamespace
      where n.nspname = 'public' and t.relname = p_table and c.contype = 'c'
        and pg_get_constraintdef(c.oid) ilike '%' || p_column || '%'
    loop
      -- Keep every value already allowed, plus the new ones. The
      -- definition is either  status = ANY (ARRAY['a'::text, 'b'::text])
      -- or (after a previous run)  status = ANY ('{a,b}'::text[]).
      select array_agg(distinct trim(both '"' from v)) into v_all
      from regexp_matches(v_con.def, '''([^'']+)''', 'g') as m,
           lateral unnest(
             case when m[1] like '{%}'
                  then string_to_array(trim(both '{}' from m[1]), ',')
                  else array[m[1]] end) as v;
      v_all := array(select distinct x from unnest(coalesce(v_all, '{}') || p_values) as x
                     order by x);
      execute format('alter table public.%I drop constraint %I', p_table, v_con.conname);
      execute format(
        'alter table public.%I add constraint %I check (%I = any (%L::text[])) not valid',
        p_table, v_con.conname, p_column, v_all);
    end loop;
  end if;
end $$;


-- ── 1. Company offices (where failed deliveries go back to) ──────────
create table if not exists public.company_offices (
  id           uuid primary key default gen_random_uuid(),
  name         text not null,
  address      text,
  city         text,
  country_code text,
  lat          double precision not null,
  lng          double precision not null,
  phone        text,
  is_active    boolean not null default true,
  created_at   timestamptz not null default now()
);

alter table public.company_offices enable row level security;

drop policy if exists "offices readable by signed-in users" on public.company_offices;
create policy "offices readable by signed-in users"
  on public.company_offices for select to authenticated
  using (is_active);

drop policy if exists "admins manage offices" on public.company_offices;
create policy "admins manage offices"
  on public.company_offices for all to authenticated
  using (public.is_admin()) with check (public.is_admin());

-- Example (edit, then run once per office):
-- insert into public.company_offices (name, address, city, country_code, lat, lng, phone)
-- values ('ko!ngo Brazzaville', 'Avenue ..., Poto-Poto', 'Brazzaville', 'CG', -4.2634, 15.2429, '+242 ...');


-- ── 2. Columns the apps now use ──────────────────────────────────────

-- rides.order_id: same type as orders.id, whatever that is.
do $$
declare v_type text;
begin
  if not exists (select 1 from information_schema.columns
                 where table_schema='public' and table_name='rides' and column_name='order_id') then
    select case data_type when 'USER-DEFINED' then udt_name else data_type end
      into v_type
    from information_schema.columns
    where table_schema='public' and table_name='orders' and column_name='id';
    execute format(
      'alter table public.rides add column order_id %s references public.orders(id) on delete set null',
      v_type);
  end if;
end $$;

create index if not exists rides_order_id_idx on public.rides(order_id);

alter table public.rides
  add column if not exists dispatched_at     timestamptz,
  add column if not exists return_reason     text,
  add column if not exists return_started_at timestamptz,
  add column if not exists returned_at       timestamptz,
  add column if not exists return_office_id  uuid references public.company_offices(id),
  add column if not exists return_lat        double precision,
  add column if not exists return_lng        double precision,
  add column if not exists return_address    text,
  add column if not exists driver_lat        double precision,
  add column if not exists driver_lng        double precision;

alter table public.orders
  add column if not exists shopper_id      uuid,
  add column if not exists delivery_lat    double precision,
  add column if not exists delivery_lng    double precision,
  add column if not exists recipient_name  text,
  add column if not exists recipient_phone text,
  add column if not exists actual_subtotal numeric,
  add column if not exists ready_at        timestamptz,
  add column if not exists picked_up_at    timestamptz,
  add column if not exists delivered_at    timestamptz,
  add column if not exists returned_at     timestamptz;

alter table public.partners
  add column if not exists lat double precision,
  add column if not exists lng double precision;

alter table public.shopping_tasks
  add column if not exists store_name      text,
  add column if not exists item_count      integer default 0,
  add column if not exists items_picked    integer default 0,
  add column if not exists estimated_total numeric default 0,
  add column if not exists assigned_at     timestamptz,
  add column if not exists accepted_at     timestamptz,
  add column if not exists completed_at    timestamptz;


-- ── 3. Status values ─────────────────────────────────────────────────
select pg_temp.kongo_allow_values('rides', 'status',
  array['pending','accepted','in_progress','completed','cancelled','returning','returned']);

select pg_temp.kongo_allow_values('orders', 'status',
  array['pending','confirmed','shopping','preparing','ready','picked_up',
        'in_transit','delivered','cancelled','refunded','returning','returned']);

select pg_temp.kongo_allow_values('shopping_tasks', 'status',
  array['assigned','accepted','in_progress','substitution_pending','packed',
        'completed','cancelled']);


-- ── 4. Shopper: list open orders ─────────────────────────────────────
-- Shoppers can't read other people's orders directly. This returns only
-- what a shopper needs to choose an order (no customer name or phone).
create or replace function public.list_open_orders()
returns setof json
language sql stable security definer
set search_path = public
as $$
  select json_build_object(
    'id',               o.id,
    'service_type',     o.service_type,
    'store_name',       p.name,
    'store_address',    p.address,
    'store_lat',        p.lat,
    'store_lng',        p.lng,
    'delivery_address', o.delivery_address,
    'item_count',       (select count(*) from order_items i where i.order_id = o.id),
    'subtotal',         o.subtotal,
    'created_at',       o.created_at
  )
  from orders o
  left join partners p on p.id = o.partner_id
  where o.shopper_id is null
    and o.status::text in ('pending', 'confirmed')
    and exists (
      select 1 from profiles me
      where me.id = auth.uid()
        and lower(coalesce(me.role, '')) = 'shopper'
        and coalesce(me.is_active, false)
        and not coalesce(me.is_blocked, false)
    )
  order by o.created_at asc
  limit 50;
$$;


-- ── 5. Shopper: take an order (atomic) ───────────────────────────────
-- Returns the new shopping task id, or null if another shopper got it.
create or replace function public.claim_order(p_order_id text)
returns text
language plpgsql security definer
set search_path = public
as $$
declare
  v_uid     uuid := auth.uid();
  v_order   orders%rowtype;
  v_store   text;
  v_items   integer;
  v_task_id text;
begin
  if v_uid is null then
    raise exception 'Not signed in';
  end if;

  if not exists (
    select 1 from profiles
    where id = v_uid
      and lower(coalesce(role, '')) = 'shopper'
      and coalesce(is_active, false)
      and not coalesce(is_blocked, false)
  ) then
    raise exception 'Only active shoppers can take orders';
  end if;

  update orders
     set shopper_id = v_uid,
         status     = 'shopping'
   where id::text = p_order_id
     and shopper_id is null
     and status::text in ('pending', 'confirmed')
  returning * into v_order;

  if not found then
    return null;  -- taken by someone else, or cancelled
  end if;

  select name into v_store from partners where id = v_order.partner_id;
  select count(*) into v_items from order_items where order_id = v_order.id;

  insert into shopping_tasks (
    order_id, shopper_id, store_name, status,
    item_count, items_picked, estimated_total, assigned_at, accepted_at
  ) values (
    v_order.id, v_uid, coalesce(v_store, ''), 'accepted',
    v_items, 0, coalesce(v_order.subtotal, 0), now(), now()
  )
  returning id::text into v_task_id;

  return v_task_id;
end $$;


-- ── 6. Shopper: request a driver for a sealed order ──────────────────
-- Creates the delivery job (store → customer) that drivers are offered.
-- Idempotent: asking twice returns the same job.
create or replace function public.request_order_delivery(
  p_order_id   text,
  p_pickup_lat double precision default null,
  p_pickup_lng double precision default null
)
returns json
language plpgsql security definer
set search_path = public
as $$
declare
  v_uid      uuid := auth.uid();
  o          orders%rowtype;
  v_name     text;
  v_address  text;
  v_plat     double precision;
  v_plng     double precision;
  v_ride_id  text;
  v_otp      text;
  v_km       numeric;
begin
  select * into o from orders where id::text = p_order_id;
  if not found then
    raise exception 'Order not found';
  end if;
  if o.shopper_id is distinct from v_uid and not public.is_admin() then
    raise exception 'This order is not yours';
  end if;

  -- Already requested? Return the live job.
  select r.id::text, r.pickup_otp into v_ride_id, v_otp
  from rides r
  where r.order_id = o.id and r.status::text <> 'cancelled'
  order by r.created_at desc
  limit 1;
  if v_ride_id is not null then
    return json_build_object('ride_id', v_ride_id, 'pickup_otp', v_otp);
  end if;

  if o.delivery_lat is null or o.delivery_lng is null then
    raise exception 'The delivery address has no map position';
  end if;

  select name, address, lat, lng into v_name, v_address, v_plat, v_plng
  from partners where id = o.partner_id;

  -- Store without a map position: use where the shopper is standing.
  v_plat := coalesce(v_plat, p_pickup_lat);
  v_plng := coalesce(v_plng, p_pickup_lng);
  if v_plat is null or v_plng is null then
    raise exception 'The store has no map position. Turn on location and try again.';
  end if;

  v_otp := lpad((floor(random() * 1000000))::int::text, 6, '0');
  v_km  := round((6371 * 2 * asin(sqrt(
             power(sin(radians(o.delivery_lat - v_plat) / 2), 2) +
             cos(radians(v_plat)) * cos(radians(o.delivery_lat)) *
             power(sin(radians(o.delivery_lng - v_plng) / 2), 2))))::numeric, 2);

  insert into rides (
    customer_id, order_id, service_type, vehicle_type,
    pickup_address, dropoff_address,
    pickup_lat, pickup_lng, dropoff_lat, dropoff_lng,
    status, fare, original_fare,
    is_bidding, bid_status, pricing_mode, dispatch_mode, negotiation_state,
    surge_multiplier, distance_km,
    pickup_otp, pickup_otp_verified,
    recipient_name, recipient_phone, customer_note,
    dispatched_at
  ) values (
    o.customer_id, o.id, coalesce(o.service_type, 'Food'), 'Delivery',
    trim(both ' ·' from coalesce(v_name, '') || ' · ' || coalesce(v_address, '')),
    o.delivery_address,
    v_plat, v_plng, o.delivery_lat, o.delivery_lng,
    'pending', coalesce(o.delivery_fee, 0), coalesce(o.delivery_fee, 0),
    false, 'none', 'algorithmic', 'assign', 'none',
    1.0, v_km,
    v_otp, false,
    o.recipient_name, o.recipient_phone, o.delivery_note,
    now()
  )
  returning id::text into v_ride_id;

  update orders
     set status = 'ready', ready_at = coalesce(ready_at, now())
   where id = o.id and status::text in ('pending', 'confirmed', 'shopping', 'preparing');

  return json_build_object('ride_id', v_ride_id, 'pickup_otp', v_otp);
end $$;


-- ── 7. Keep the order and shopper task in step with the delivery job ─
create or replace function public.sync_order_from_delivery()
returns trigger
language plpgsql security definer
set search_path = public
as $$
begin
  if new.order_id is null then
    return new;
  end if;
  if new.status is not distinct from old.status
     and new.driver_id is not distinct from old.driver_id then
    return new;
  end if;

  case new.status::text
    when 'accepted' then
      update orders set driver_id = new.driver_id where id = new.order_id;

    when 'pending' then
      -- released by a driver before pickup: back to "waiting for driver"
      update orders set driver_id = null
       where id = new.order_id and status::text = 'ready';

    when 'in_progress' then
      update orders
         set status = 'picked_up', picked_up_at = now(), driver_id = new.driver_id
       where id = new.order_id;
      update shopping_tasks
         set status = 'completed', completed_at = now()
       where order_id = new.order_id
         and status::text not in ('completed', 'cancelled');

    when 'completed' then
      update orders set status = 'delivered', delivered_at = now()
       where id = new.order_id;

    when 'returning' then
      update orders set status = 'returning' where id = new.order_id;

    when 'returned' then
      update orders set status = 'returned', returned_at = now()
       where id = new.order_id;

    else
      null;
  end case;

  return new;
end $$;

drop trigger if exists trg_sync_order_from_delivery on public.rides;
create trigger trg_sync_order_from_delivery
  after update of status, driver_id on public.rides
  for each row execute function public.sync_order_from_delivery();


-- ── 8. Permissions ───────────────────────────────────────────────────
revoke all on function public.list_open_orders()                                          from public, anon;
revoke all on function public.claim_order(text)                                           from public, anon;
revoke all on function public.request_order_delivery(text, double precision, double precision) from public, anon;
grant execute on function public.list_open_orders()                                       to authenticated;
grant execute on function public.claim_order(text)                                        to authenticated;
grant execute on function public.request_order_delivery(text, double precision, double precision) to authenticated;

-- Realtime: the apps listen for changes on these tables.
do $$
begin
  begin
    alter publication supabase_realtime add table public.rides;
  exception when duplicate_object then null;
  end;
  begin
    alter publication supabase_realtime add table public.orders;
  exception when duplicate_object then null;
  end;
end $$;
